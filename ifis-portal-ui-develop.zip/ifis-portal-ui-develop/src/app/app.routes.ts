import { Routes } from '@angular/router';
import { LandingComponent } from './modules/core/landing/landing';
import { AdminComponent } from './modules/core/admin/admin';
import { AuthGuard } from './auth.guard';
import { LayoutComponent } from './modules/core/layout/layout';

export const routes: Routes = [
    {
        path: '',
        component: LayoutComponent,
        canActivate: [AuthGuard],
        children: [
            {
                path: '',
                component: LandingComponent,
                data: {
                    hideMenu: true
                }
            },
            {
                path: 'Landing',
                component: LandingComponent,
                data:{
                    activeLink:true
                }
            },
            {
                path: 'Administration',
                component: AdminComponent,
                data: {
                    activeLink: true
                }
            },
                {
                path:'**',
                pathMatch:'full',
                redirectTo:''
            },
            {
                path: 'login/callback',
                pathMatch:'full',
                redirectTo: '',
            }
        ],

    },
    {
        path: '**',
        redirectTo: '',
    }

]
