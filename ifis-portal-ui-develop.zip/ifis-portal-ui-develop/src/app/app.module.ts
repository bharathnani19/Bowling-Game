import { CommonModule, HashLocationStrategy, LocationStrategy } from '@angular/common';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app';
import { provideAnimations  } from '@angular/platform-browser/animations';
import { CoreModule } from './modules/core/core-module';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { OktaInterceptor } from './utilities/oktainterceptor';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { CustomDateAdapter } from './utilities/custom-date-adapter';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ScrollingModule } from '@angular/cdk/scrolling';

import moment from 'moment';
const COMMON_MODULES = [BrowserModule, CommonModule, AppRoutingModule, CoreModule];

const COMMON_COMPONENT = [AppComponent];

export const APP_DATE_FORMATS = {
  parse: {
    dateInput: 'YYYY-MM-DD',
  },
  display: {
    dateInput: 'YYYY-MM-DD',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'YYYY-MM-DD',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@NgModule({
  declarations: [...COMMON_COMPONENT],
  imports: [...COMMON_MODULES, ScrollingModule],
  exports: [],
  bootstrap: [AppComponent],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: OktaInterceptor,
      multi: true,
    },
    { provide: DateAdapter, useClass: CustomDateAdapter },
    { provide: MAT_DATE_LOCALE, useValue: 'en-GB' },
    {
      provide: MAT_DATE_FORMATS,
      useValue: {
        parse: { dateInput: 'yyyy/MM/dd' },
        display: {
          dateInput: 'yyyy/MM/dd',
          monthYearLabel: 'MMM yyyy',
          dateA11yLabel: 'LL',
          monthYearA11yLabel: 'MMMM yyyy',
        },
      },
    },
  ],
})
export class AppModule {}
