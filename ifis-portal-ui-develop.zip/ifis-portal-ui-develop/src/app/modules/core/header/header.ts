import {
  Component,
  effect,
  ElementRef,
  EventEmitter,
  HostListener,
  OnInit,
  Output,
} from '@angular/core';
import { OktaService } from '../../../services/okta';
import { environment } from '../../../environments/environment.shared';
import { User } from '../../../models/user.model';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { HomePageService } from '../../../services/homepage.service';
import { ToastService } from '../../../services/toaster.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.html',
  styleUrl: './header.scss',
  standalone: false,
})
export class HeaderComponent implements OnInit {
  isAuthenticated: boolean = false;

  private readonly supportRoleAllowList = new Set<string>([
    'CPI IFIS CMS Program Oversight - CMS - cmspoDISM',
    'CPI IFIS System Maintainer - Peraton - smDefault',
    'CPI IFIS System Maintainer - Peraton - smFas',
    'CPI IFIS System Maintainer - Peraton - smDido',
    'CPI IFIS System Maintainer - Peraton - smLCm',
    'CPI IFIS System Maintainer - Peraton - smEmlMo',
    'CPI IFIS System Maintainer - Peraton - smElmEo',
    'CPI IFIS System Maintainer - Index - smDefault',
    'CPI IFIS System Maintainer - Index - smFas',
    'CPI IFIS System Maintainer - Index - smDido',
    'CPI IFIS System Maintainer - Index - smLCm',
    'CPI IFIS System Maintainer - SkySolutions - smDefault',
    'CPI IFIS System Maintainer - SkySolutions - smFas',
    'CPI IFIS System Maintainer - SkySolutions - smDido',
    'CPI IFIS System Maintainer - SkySolutions - smLCm',
    'CPI IFIS System Maintainer - Sky Solutions - smDefault',
    'CPI IFIS System Maintainer - Sky Solutions - smFas',
    'CPI IFIS System Maintainer - Sky Solutions - smDido',
    'CPI IFIS System Maintainer - Sky Solutions - smLCm',
  ]);

  hideMenu: boolean = false;
  defaultAsrView: string = '';

  constructor(
    private router: Router,
    private route: ActivatedRoute,

    public dialog: MatDialog,

    private homePageService: HomePageService,
    private eRef: ElementRef,
    public okta: OktaService,
    private toaster: ToastService,
  ) {
    effect(() => {
      this.user = this.okta.user();
    });
    this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        const firstChild = this.route.firstChild;
        firstChild?.data.subscribe((data: any) => {
          this.hideMenu = data['hideMenu'] || false;
          this.activeLink = data.activeLink || false;
        });
      }
    });
  }
  @Output() showLink = new EventEmitter<string>();
  user!: User;
  systemMessages: any;
  wsHost = environment.wsHost;
  appUrl = environment.appUrl;
  activeLink: boolean = false;
  msgCount: number = 0;

  currentOpen: string | null = null;

  //508 purpose
  onDefaultViewRowKeydown(event: KeyboardEvent, selectEl: HTMLSelectElement): void {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      event.stopPropagation();

      setTimeout(() => {
        if (selectEl) {
          selectEl.focus();
        }
      });
    }
  }

  async ngOnInit(): Promise<void> {
    this.isAuthenticated = await this.okta.oktaAuth.isAuthenticated();
  }

  skipToMainContent() {
    const element = document.getElementById('main-content');
    if (element) {
      element.focus();
    }
  }

  home() {
    this.router.navigate(['/']);
  }

  toggleDropdown(name: string) {
    this.currentOpen = this.currentOpen === name ? null : name;
  }

  @HostListener('document:click', ['$event'])
  clickOutside(event: MouseEvent) {
    const target = event.target as HTMLElement;
    if (!this.eRef.nativeElement.contains(target) && !target.classList.contains('show-toggle')) {
      this.currentOpen = null;
    }
  }

  openExternalLink(link: string) {
    this.currentOpen = null;
    let url = '';

    if (url.length > 0) {
      window.open(url, '_blank');
    }
  }

  markMsgsAsReadByUser() {}

  newRequest() {
    window.open(environment.newUserRoleRequestUrl, '_blank');
  }

  async logout() {
    console.log('logout triggered!');
    this.okta.signOut();
  }

  canAccessSupport(): boolean {
    const groups = this.user?.groups ?? [];

    return groups.some((group) => this.supportRoleAllowList.has(group));
  }

  isAuthorizedEndUser(): boolean {
    return this.user !== undefined;
    /*
    return !!(
      this.user?.groups?.includes(allRoleTypes.ROLE_INQUIRY) ||
      this.user?.groups?.includes(allRoleTypes.ROLE_PRIORITY_SUP) ||
      this.user?.groups?.includes(allRoleTypes.ROLE_MAC) ||
      this.user?.groups?.includes(allRoleTypes.ROLE_ADMIN)
    );
    */
  }

  skipToMain(event: Event): void {
    event.preventDefault();

    const firstTileLink = document.querySelector('#ifis-home-tiles a') as HTMLElement | null;

    if (firstTileLink) {
      firstTileLink.focus();
    }
  }
}
