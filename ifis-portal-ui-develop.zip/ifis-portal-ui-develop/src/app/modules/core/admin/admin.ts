import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ToastService } from '../../../services/toaster.service';
import { OktaService } from '../../../services/okta';
import { Card } from '../../../shared/interface';
import {
  SystemAnnouncementDialogComponent,
  SystemAnnouncementDialogResult,
} from './system-announcement-dialog/system-announcement-dialog';

interface SystemAnnouncementRow {
  id: number;
  title: string;
  description: string;
  startDate: string;
  endDate: string;
  system: string;
  status: string;
  createdBy: string;
  createdOn: string;
}

interface AuditTrailRow {
  id: number;
  fieldName: string;
  currentValue: string;
  previousValue: string;
  modifiedBy: string;
  modifiedOn: string;
}

@Component({
  selector: 'app-admin',
  templateUrl: './admin.html',
  styleUrl: './admin.scss',
  standalone: false,
})
export class AdminComponent {
  private readonly allSystemAccessGroup = 'CPI IFIS CMS Program Oversight - CMS - cmspoDISM';

  readonly announcementsPaneCard: Card = {
    title: 'Announcements',
    tableId: 'ifis-system-announcements-table',
  };

  readonly auditTrailPaneCard: Card = {
    title: 'Audit Trail',
    tableId: 'ifis-audit-trail-table',
  };

  readonly announcementColumns = [
    { key: 'id', label: 'ID', sortable: true },
    { key: 'title', label: 'Title', sortable: true },
    { key: 'description', label: 'Description', sortable: true },
    { key: 'startDate', label: 'Start Date', sortable: true },
    { key: 'endDate', label: 'End Date', sortable: true },
    { key: 'system', label: 'System', sortable: true },
    { key: 'status', label: 'Status', sortable: true },
    { key: 'createdBy', label: 'Created By', sortable: true },
    { key: 'createdOn', label: 'Created On', sortable: true },
    { key: 'action', label: 'Action', custom: true, sortable: false },
  ];

  readonly auditColumns = [
    { key: 'id', label: 'ID', sortable: true },
    { key: 'fieldName', label: 'Field Name', sortable: true },
    { key: 'currentValue', label: 'Current Value', sortable: true },
    { key: 'previousValue', label: 'Previous Value', sortable: true },
    { key: 'modifiedBy', label: 'Modified By', sortable: true },
    { key: 'modifiedOn', label: 'Modified On', sortable: true },
  ];

  readonly announcementRows: SystemAnnouncementRow[] = [
    {
      id: 1001,
      title: 'Planned Maintenance',
      description: 'IFIS maintenance window this weekend.',
      startDate: '2026-08-02 10:00 AM',
      endDate: '2026-08-02 12:00 PM',
      system: 'IFIS',
      status: 'Draft',
      createdBy: 'System Maintainer',
      createdOn: '2026-07-30 09:18 AM',
    },
    {
      id: 1002,
      title: 'Release Notification',
      description: 'New dashboard updates available for all users.',
      startDate: '2026-08-05 08:00 AM',
      endDate: '2026-08-15 06:00 PM',
      system: 'IFIS',
      status: 'Published',
      createdBy: 'CMS Program Oversight',
      createdOn: '2026-07-29 04:42 PM',
    },
  ];

  readonly auditRows: AuditTrailRow[] = [
    {
      id: 2001,
      fieldName: 'Description',
      currentValue: 'IFIS maintenance window this weekend.',
      previousValue: 'Planned window in progress.',
      modifiedBy: 'System Maintainer',
      modifiedOn: '2026-07-30 10:04 AM',
    },
    {
      id: 2002,
      fieldName: 'Status',
      currentValue: 'Published',
      previousValue: 'Draft',
      modifiedBy: 'CMS Program Oversight',
      modifiedOn: '2026-07-29 05:01 PM',
    },
  ];

  constructor(
    private readonly toaster: ToastService,
    private readonly dialog: MatDialog,
    private readonly okta: OktaService,
  ) {}

  addSystemMessage(): void {
    const dialogRef = this.dialog.open(SystemAnnouncementDialogComponent, {
      width: '760px',
      maxWidth: '95vw',
      panelClass: ['ip-dialog-panel', 'announcement-dialog-panel'],
      data: {
        title: 'Add Announcements',
        allowAllSystem: this.canAccessAllSystem(),
      },
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result: SystemAnnouncementDialogResult | undefined) => {
      if (!result) {
        return;
      }

      const nextId = this.nextAnnouncementId();

      const formattedStart = this.formatDateTime(
        result.startDate,
        result.startHour,
        result.startMinute,
        result.startAmPm,
      );

      const formattedEnd = this.formatDateTime(
        result.endDate,
        result.endHour,
        result.endMinute,
        result.endAmPm,
      );

      const normalizedTitle = result.title.trim();
      const normalizedDescription = result.announcementDescription.trim();

      this.announcementRows.unshift({
        id: nextId,
        title: normalizedTitle,
        description: normalizedDescription,
        startDate: formattedStart,
        endDate: formattedEnd,
        system: result.system,
        status: 'Draft',
        createdBy: 'Current User',
        createdOn: this.formatTimestamp(new Date()),
      });

      this.auditRows.unshift({
        id: this.nextAuditId(),
        fieldName: 'Announcement Description',
        currentValue: normalizedDescription,
        previousValue: '-',
        modifiedBy: 'Current User',
        modifiedOn: this.formatTimestamp(new Date()),
      });

      this.toaster.success('System announcement added successfully.');
    });
  }

  editSystemMessage(row: SystemAnnouncementRow): void {
    this.toaster.info(`Edit selected for message ID ${row.id}.`);
  }

  publishSystemMessage(row: SystemAnnouncementRow): void {
    this.toaster.success(`Publish selected for message ID ${row.id}.`);
  }

  deleteSystemMessage(row: SystemAnnouncementRow): void {
    this.toaster.error(`Delete selected for message ID ${row.id}.`);
  }

  private nextAnnouncementId(): number {
    const maxId = this.announcementRows.reduce((max, row) => Math.max(max, row.id), 1000);

    return maxId + 1;
  }

  private nextAuditId(): number {
    const maxId = this.auditRows.reduce((max, row) => Math.max(max, row.id), 2000);

    return maxId + 1;
  }

  private formatDateTime(date: Date, hour: string, minute: string, amPm: string): string {
    const datePart = date.toLocaleDateString('en-CA');

    return `${datePart} ${hour}:${minute} ${amPm}`;
  }

  private formatTimestamp(value: Date): string {
    const datePart = value.toLocaleDateString('en-CA');
    const timePart = value.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });

    return `${datePart} ${timePart}`;
  }

  private canAccessAllSystem(): boolean {
    const groups = this.okta.user()?.groups ?? [];

    return groups.includes(this.allSystemAccessGroup);
  }
}
