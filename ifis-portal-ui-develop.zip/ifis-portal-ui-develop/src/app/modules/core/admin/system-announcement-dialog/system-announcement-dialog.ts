import { Component, Inject } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, ValidationErrors, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

export interface SystemAnnouncementDialogData {
  title: string;
  allowAllSystem?: boolean;
}

export interface SystemAnnouncementDialogResult {
  title: string;
  announcementDescription: string;
  system: 'All' | 'FPS' | 'OnePI' | 'UCM';
  startDate: Date;
  startHour: string;
  startMinute: string;
  startAmPm: 'AM' | 'PM';
  endDate: Date;
  endHour: string;
  endMinute: string;
  endAmPm: 'AM' | 'PM';
}

@Component({
  selector: 'app-system-announcement-dialog',
  templateUrl: './system-announcement-dialog.html',
  styleUrl: './system-announcement-dialog.scss',
  standalone: false,
})
export class SystemAnnouncementDialogComponent {
  readonly hours = Array.from({ length: 13 }, (_, index) => String(index).padStart(2, '0'));

  readonly minutes = Array.from({ length: 61 }, (_, index) => String(index).padStart(2, '0'));

  readonly systems: Array<{ value: 'All' | 'FPS' | 'OnePI' | 'UCM'; disabled: boolean }>;

  readonly form;

  saveAttempted = false;

  readonly saveAttemptMatcher: ErrorStateMatcher = {
    isErrorState: (control: FormControl | null) => !!control && control.invalid && this.saveAttempted,
  };

  constructor(
    private readonly fb: FormBuilder,
    private readonly dialogRef: MatDialogRef<SystemAnnouncementDialogComponent>,
    @Inject(MAT_DIALOG_DATA) readonly data: SystemAnnouncementDialogData,
  ) {
    this.systems = [
      { value: 'All', disabled: !data.allowAllSystem },
      { value: 'FPS', disabled: false },
      { value: 'OnePI', disabled: false },
      { value: 'UCM', disabled: false },
    ];

    this.form = this.fb.group(
      {
        title: this.fb.nonNullable.control('', [Validators.required, Validators.maxLength(250)]),
        announcementDescription: this.fb.nonNullable.control('', [Validators.required, Validators.maxLength(5000)]),
        system: this.fb.control<'All' | 'FPS' | 'OnePI' | 'UCM' | null>(null, [Validators.required]),
        startDate: this.fb.control<Date | null>(null, [Validators.required]),
        startHour: this.fb.nonNullable.control('', [Validators.required]),
        startMinute: this.fb.nonNullable.control('', [Validators.required]),
        startAmPm: this.fb.nonNullable.control('', [Validators.required]),
        endDate: this.fb.control<Date | null>(null, [Validators.required]),
        endHour: this.fb.nonNullable.control('', [Validators.required]),
        endMinute: this.fb.nonNullable.control('', [Validators.required]),
        endAmPm: this.fb.nonNullable.control('', [Validators.required]),
      },
      { validators: this.dateRangeValidator },
    );
  }

  cancel(): void {
    this.dialogRef.close();
  }

  save(): void {
    this.saveAttempted = true;

    if (this.form.invalid) {
      return;
    }

    const value = this.form.getRawValue();

    if (
      !value.startDate ||
      !value.endDate ||
      !this.isValidSystem(value.system) ||
      !this.isValidAmPm(value.startAmPm) ||
      !this.isValidAmPm(value.endAmPm)
    ) {
      return;
    }

    const result: SystemAnnouncementDialogResult = {
      title: value.title.trim(),
      announcementDescription: value.announcementDescription.trim(),
      system: value.system,
      startDate: value.startDate,
      startHour: value.startHour,
      startMinute: value.startMinute,
      startAmPm: value.startAmPm,
      endDate: value.endDate,
      endHour: value.endHour,
      endMinute: value.endMinute,
      endAmPm: value.endAmPm,
    };

    this.dialogRef.close(result);
  }

  get rangeError(): boolean {
    return this.saveAttempted && !!this.form.errors?.['dateRange'];
  }

  private dateRangeValidator = (control: AbstractControl): ValidationErrors | null => {
    const startDate = control.get('startDate')?.value;
    const startHour = control.get('startHour')?.value;
    const startMinute = control.get('startMinute')?.value;
    const startAmPm = control.get('startAmPm')?.value;

    const endDate = control.get('endDate')?.value;
    const endHour = control.get('endHour')?.value;
    const endMinute = control.get('endMinute')?.value;
    const endAmPm = control.get('endAmPm')?.value;

    if (
      !startDate ||
      !startHour ||
      !startMinute ||
      !startAmPm ||
      !endDate ||
      !endHour ||
      !endMinute ||
      !endAmPm
    ) {
      return null;
    }

    const start = this.composeDate(startDate, startHour, startMinute, startAmPm);
    const end = this.composeDate(endDate, endHour, endMinute, endAmPm);

    if (!start || !end) {
      return null;
    }

    if (end <= start) {
      return { dateRange: true };
    }

    return null;
  };

  private composeDate(date: Date, hour: string, minute: string, ampm: string): Date | null {
    const safeDate = new Date(date);

    if (Number.isNaN(safeDate.getTime())) {
      return null;
    }

    let parsedHour = Number(hour);

    if (ampm === 'PM' && parsedHour !== 12) {
      parsedHour += 12;
    }

    if (ampm === 'AM' && parsedHour === 12) {
      parsedHour = 0;
    }

    safeDate.setHours(parsedHour, Number(minute), 0, 0);

    return safeDate;
  }

  private isValidSystem(system: unknown): system is SystemAnnouncementDialogResult['system'] {
    return system === 'All' || system === 'FPS' || system === 'OnePI' || system === 'UCM';
  }

  private isValidAmPm(value: string): value is 'AM' | 'PM' {
    return value === 'AM' || value === 'PM';
  }
}
