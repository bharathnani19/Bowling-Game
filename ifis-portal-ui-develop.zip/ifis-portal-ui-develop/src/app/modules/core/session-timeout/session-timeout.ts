import { CommonModule } from '@angular/common';
import { Component, Inject, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';

import { Subscription, interval } from 'rxjs';

@Component({
  selector: 'session-inactive-modal',
  templateUrl: './session-timeout.html',
  styleUrls: ['./session-timeout.scss'],
  standalone: false,

})
export class SessionInactiveModalComponent implements OnInit, OnDestroy {
  totalWaitTime: number;
  private timerSub!: Subscription;
  modalLoadTime = new Date();

  constructor(
    public dialogRef: MatDialogRef<SessionInactiveModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.totalWaitTime = this.data.timer;
  }

  ngOnInit() {
    this.modalLoadTime = new Date();
    this.startTimer();
    window.addEventListener('storage', this.syncDialogsAcrossTabs.bind(this));
  }

  ngOnDestroy() {
    if (this.timerSub) {
      this.timerSub.unsubscribe();
    }
    window.removeEventListener('storage', this.syncDialogsAcrossTabs.bind(this));
  }

  startTimer() {
    const source = interval(1000);
    this.timerSub = source.subscribe(() => {
      const currentTime = Date.now();
      if ((this.getSessionExpirationTime() - currentTime) > 0) {
        this.totalWaitTime = Math.floor((this.getSessionExpirationTime() - currentTime) / 1000);
      } else {
        this.timerSub.unsubscribe();
        this.closeAllDialogs();
      }
    });
  }

  syncDialogsAcrossTabs(event: StorageEvent) {
    if (event.key === 'dialogClosed' && event.newValue === 'true') {
      this.dialogRef.close();
    }
  }

  get minutes(): number {
    return Math.floor(this.totalWaitTime / 60);
  }

  get seconds(): number {
    return this.totalWaitTime % 60;
  }

  logout() {
    this.dialogRef.close('logout');
    localStorage.setItem('dialogClosed', 'true');
  }

  extend(): void {
    this.dialogRef.close('extend');
  }

  closeAllDialogs() {
    localStorage.setItem('dialogClosed', 'true');
  }

  getSessionExpirationTime() {
    const sessionTimeOutTime = new Date(this.modalLoadTime.getTime() + (this.data.timer))
    return sessionTimeOutTime.getTime();
  }
}
