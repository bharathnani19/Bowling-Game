import { Component, effect, OnInit } from '@angular/core';
import { OktaService } from '../../../services/okta';
import { HomePageService } from '../../../services/homepage.service';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Title } from '@angular/platform-browser';
import { UtilService } from '../../../services/util.service';
import { User } from '../../../models/user.model';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.html',
  styleUrl: './landing.scss',
  standalone: false,
})
export class LandingComponent implements OnInit {
  homepageTiles: any[] = [];
  cols = 4;
  isLoading = true;
  systemMessages: any;
  msgCount: number = 0;
  systemMessageEnabled: boolean = false;
  user!: User;
  constructor(
    private title: Title,
    public okta: OktaService,
    private homePageService: HomePageService,
    private breakpointObserver: BreakpointObserver,
    private utilService: UtilService,
  ) {
    this.title.setTitle('IFIS');
     effect(() => {
      this.user = this.okta.user();
    });
  }
ngOnInit(){
    const searchUniqueId = Math.floor(Math.random() * 1000) + Date.now();
    this.logSla("Landing Page - Start: "+searchUniqueId);
    this.fetchHomeTiles();
    this.logSla("Landing Page - End: " +searchUniqueId);
    this.breakpointObserver
      .observe([
        Breakpoints.XSmall,
        Breakpoints.Small,
        Breakpoints.Medium,
        Breakpoints.Large,
        Breakpoints.XLarge,
      ])
      .subscribe((state) => {
        if (state.breakpoints[Breakpoints.XSmall]) {
          this.cols = 1;
        } else if (state.breakpoints[Breakpoints.Small]) {
          this.cols = 2;
        } else if (state.breakpoints[Breakpoints.Medium]) {
          this.cols = 3;
        } else {
          this.cols = 4;
        }
      });
      
  }

  fetchHomeTiles(): void {
    this.isLoading = true;
    this.homePageService.getHomePageToolbar().subscribe((response) => {
      this.systemMessages = response.messages || [];
      this.msgCount = response.newSysMsgCt;
    });
    this.homePageService.getHomeTiles().subscribe({
      next: (response) => {
        this.homepageTiles = response.homepageTiles || [];
        this.isLoading = false;
      },
      error: () => {
        this.homepageTiles = [];
        this.isLoading = false;
      },
    });
  }
  getTileAriaLabel(name: string): string {
  const ariaLabels: Record<string, string> = {
    FPS: 'F P S',
    UCM: 'U C M',
    OnePI: 'One P I'
  };

  return ariaLabels[name.trim()] || name;
}

  trackUserActivity(type: string): void {
    //TODO
  }
  logSla(type: string): void {
    this.utilService.logSla(this.user?.preferred_username || 'N/A', type, this.user?.organization || 'N/A');
  }
}
