import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header';
import { LandingComponent } from './landing/landing';
import { AdminComponent } from './admin/admin';
import { AppRoutingModule } from '../../app-routing.module';
import { RouterModule } from '@angular/router';
import { LayoutComponent } from './layout/layout';
import { MaterialModule } from '../../shared/material.module';
import { SharedModule } from '../../shared/shared.module';
import { SessionInactiveModalComponent } from './session-timeout/session-timeout';
import { SystemAnnouncementDialogComponent } from './admin/system-announcement-dialog/system-announcement-dialog';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppLoaderComponent } from '../../shared/app-loader/app-loader';
import { SystemmessageComponent } from '../../shared/systemmessage/systemmessage';
import { ScrollingModule } from '@angular/cdk/scrolling';
const COMPONENTS = [
  
  HeaderComponent,
  LandingComponent,
  AdminComponent,
  SystemAnnouncementDialogComponent,
  SessionInactiveModalComponent,
  LayoutComponent,
  AppLoaderComponent,
  SystemmessageComponent
];

@NgModule({
  declarations: [...COMPONENTS],
  imports: [
    CommonModule,
    AppRoutingModule,
    RouterModule,
    HttpClientModule,
    MaterialModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    ScrollingModule
  ],
  exports: [...COMPONENTS],
})
export class CoreModule {}
