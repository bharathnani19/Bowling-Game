export const ws_host = 'https://cloud.fpsportal.cms.cmsval/fps';
export const app_url = 'https://cloud.fpsportal.cms.cmsval';
export const environmentExtended = {
  wsHost: ws_host,
  appUrl: app_url,
  production: false,
  env: 'val',
  appBaseHref: '/',
  okta: {
    pkce: true,
    issuer: 'https://impl.idp.idm.cms.gov/oauth2/aus12kil84eGFh52c298',
    clientId: '0oa12kijzfbN8XyGN298',
    redirectUri: window.location.origin +'/login/callback',
    postLogoutRedirectUri: window.location.origin,
  state: 'ifis-auth-state',
    scopes: ['openid', 'profile', 'email', 'groups', 'offline_access'],
    tokenManager: {
      autoRenew: true,
    },
  },
  slaLoggingEnabled: true,
  splunkUrl:'https://cloud.fpsportal.cms.cmsval:8443/services/collector/event',
  splunkToken: '8d6687c6-f26c-42a0-93b5-93179d4adaac'
};
