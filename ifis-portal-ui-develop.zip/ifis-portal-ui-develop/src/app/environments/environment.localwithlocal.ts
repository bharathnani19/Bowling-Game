export const ws_host = 'http://localhost:9082/fps';
export const app_url = 'http://localhost:4200/';

export const environmentExtended = {
    wsHost: ws_host,
    appUrl: app_url,
  production: false,
  env: 'local',
  appBaseHref: '/',
  okta: {
    issuer: 'https://test.idp.idm.cms.gov/oauth2/aus11dsknd8PKBNVH298',
    clientId: '0oa11dsljqjv1uH3D298',
    redirectUri:
      'http://localhost:4200/login/callback',
    postLogoutRedirectUri:
      'http://localhost:4200',
    scopes: ['openid', 'profile', 'email', 'groups', 'offline_access'],
    state: 'ifis-auth-state',
    devMode: true,
  },
  slaLoggingEnabled: true,
  splunkUrl:'http://localhost:9080',
  splunkToken: '1'
};
