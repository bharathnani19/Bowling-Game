import { app_url, environmentExtended } from './environment';

export const environment = {
  extended: environmentExtended,
  wsUrls: {
    homePageTileService: environmentExtended.wsHost + '/rest/home/',
    homePageToolbarService: environmentExtended.wsHost + '/rest/landingpage/messages',
    navbarData: environmentExtended.wsHost + '/rest/landingpage/header/{userId}/{zoneId}',
    fileDownload: environmentExtended.wsHost + '/rest/modeldocs/{fileName}?userId={userId}',

    getLandingPageData: environmentExtended.wsHost + '/rest/landingpage/{userId}/{zoneId}',
    saveUserPrefs: environmentExtended.wsHost + '/rest/preferences',
    workbenchItems: environmentExtended.wsHost + '/rest/provider/lists/user/{userId}',
    watchlistData: environmentExtended.wsHost + '/rest/landingpage/watchlist/{userId}/{zoneId}',
    reportsData: environmentExtended.wsHost + '/rest/landingpage/reportsdata/{userId}/{zoneId}',
    checkExistName:
      environmentExtended.wsHost + '/rest/provider/{asrType}lists/user/{userId}/{workbenchType}',
    renameWorkbench: environmentExtended.wsHost + '/rest/provider/{workbenchType}/{listId}',
    deleteWorkbench:
      environmentExtended.wsHost + '/rest/provider/{workbenchType}/{listId}?userId={userId}',
    sharableUsers:
      environmentExtended.wsHost + '/rest/provider/{asrType}groups/{groupId}?userId={userId}',
    shareToGroup: environmentExtended.wsHost + '/rest/provider/groups?userId={userId}',
    availableReports: environmentExtended.wsHost + '/rest/landingpage/reports/{userId}/{zoneId}',
    archive: environmentExtended.wsHost + '/rest/provider/lists/{groupId}/archive/{userId}',
    updatepubpriaction:
      environmentExtended.wsHost + '/rest/provider/exclusions/{userId}/visible/{actionBool}',
    getCriminalDetails:
      environmentExtended.wsHost + '/rest/asr/detail/{asrId}/{searchType}?userId={userId}',
    watchlistSubscribe: environmentExtended.wsHost + '/rest/service/subscribe',
    editInfo: environmentExtended.wsHost + '/rest/landing/editinfo?userId={userId}',
    getAsrSearchRefdata: environmentExtended.wsHost + '/rest/refdata/ASRLEVEL?userId={userId}',
    getSavedSearchRefdata: environmentExtended.wsHost + '/rest/provider/lists/user/{userId}/search',
    verifyAsrs: environmentExtended.wsHost + '/rest/{asrType}asr/search/verify',
    asrSearch: environmentExtended.wsHost + '/rest/asr/search',
    //Triage
    retrieveUserPrefs:  environmentExtended.wsHost + '/rest/preferences/{userId}/{type}',
    getAddToExistInputVals: environmentExtended.wsHost + '/rest/provider/{searchType}lists/user/{userId}/asr'
  },
  upHome: environmentExtended.appUrl + '/ifis',
  umLink: environmentExtended.appUrl + '/UserManagement',
  vulMgmt: environmentExtended.appUrl + '/VulnerabilityManagement',
  editInq: environmentExtended.appUrl + '/ProblemReportingTool',
  emlLink: environmentExtended.appUrl + '/eml/',
  newUserRoleRequestUrl: environmentExtended.appUrl + '/UserManagement/#/userprofile',
  wsHost: environmentExtended.wsHost,
  appUrl: environmentExtended.appUrl,
};
