export const ws_host = 'http://localhost:9082/ifis';
export const app_url = 'http://localhost:4200';

export const environmentExtended = {
  wsHost: ws_host,
  appUrl: app_url,
  production: false,
  appBaseHref: '/',
  env: 'dev',
  okta: {
    issuer: 'https://test.idp.idm.cms.gov/oauth2/aus11dsknd8PKBNVH298',
    clientId: '0oa11dsljqjv1uH3D298',
    redirectUri: 'http://localhost:4200/login/callback',
    postLogoutRedirectUri: 'http://localhost:4200/',

    scopes: ['openid', 'profile', 'email', 'groups','offline_access'],
    state: 'ifis-auth-state', // used to validate the OAuth response
    tokenManager: {
      autoRenew: true,
      autoRemove: true,
    },
    devMode: true,
  },
  trainingUrls: { lms: 'https://dtzvspmvvhxbl.cloudfront.net/' },
  tableauBase: 'https://cloud.fpsreports.cmsnet/t/Prod',
  slaLoggingEnabled: false,
  splunkUrl:'https://cloud.fpsportal.cms.cmsval:8443/services/collector/event',
  splunkToken: '8d6687c6-f26c-42a0-93b5-93179d4adaac'
};
