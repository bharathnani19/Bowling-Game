export const ws_host = 'https://cloud.fpsportalmodeldev.cms.cmsval/fps';
export const app_url = 'https://cloud.fpsportalmodeldev.cms.cmsval';
export const environmentExtended = {
  wsHost: ws_host,
  appUrl: app_url,
  production: false,
  env: 'mte',
  appBaseHref: '/',
  okta: {
    pkce: true,
    issuer: 'https://impl.idp.idm.cms.gov/oauth2/ausc24l2w5nTQczdY297',
    clientId: '0oac24ih3eJjmcmlk297',
    redirectUri: 'https://cloud.fpsportalmodeldev.cms.cmsval/ifis/',
    postLogoutRedirectUri: 'https://cloud.fpsportalmodeldev.cms.cmsval/ifis/',

    scopes: ['openid', 'profile', 'email', 'groups', 'offline_access'],
    tokenManager: {
      autoRenew: true,
      autoRemove: true,
    },
  },
  trainingUrls: { lms: 'https://dtzvspmvvhxbl.cloudfront.net/' },
  tableauBase: 'https://cloud.fpsreportsmodeldev.cms.cmsval/t/MTE/projects',
  slaLoggingEnabled: false,
  splunkUrl:'',
  splunkToken: ''
};
