export const ws_host =
  'https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com/fps';
export const app_url = 'https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com';

export const environmentExtended = {
  wsHost: ws_host,
  appUrl: app_url,
  production: false,
  env: 'dev',
  appBaseHref: '/',
  okta: {
    issuer: 'https://test.idp.idm.cms.gov/oauth2/aus11dsknd8PKBNVH298',
    clientId: '0oa11dsljqjv1uH3D298',
    redirectUri:
      window.location.origin +'/login/callback',
    postLogoutRedirectUri:
      window.location.origin ,
    scopes: ['openid', 'profile', 'email', 'groups', 'offline_access'],
    state: 'ifis-auth-state',
    devMode: true,
  },
  slaLoggingEnabled: false,
  splunkUrl:'',
  splunkToken: ''
};
