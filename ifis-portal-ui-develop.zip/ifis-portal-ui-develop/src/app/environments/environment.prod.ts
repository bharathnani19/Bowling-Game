export const ws_host = 'https://cloud.fpsportal.cmsnet/fps';
export const app_url = 'https://cloud.fpsportal.cmsnet';
export const environmentExtended = {
  wsHost: ws_host,
  appUrl: app_url,
  production: false,
  env: 'prod',
  appBaseHref: '/',
  okta: {
    pkce: true,
    issuer: 'https://idm.cms.gov/oauth2/aus12z4givq1v3CZ0298',
    clientId: '0oa12z4eevvyQhZwu298',
    redirectUri: window.location.origin +'/login/callback',
    postLogoutRedirectUri: window.location.origin,
    state: 'ifis-auth-state',
    scopes: ['openid', 'profile', 'email', 'groups', 'offline_access'],
    tokenManager: {
      autoRenew: true,
    },
  },
    slaLoggingEnabled: true,
  splunkUrl:'https://cloud.fpsportal.cmsnet:8443/services/collector/event',
  splunkToken: 'f7e233b3-0c1b-41a7-8c5b-ea07f2a67943'
};
