export const ws_host = 'http://dcatdata0.awscloud.cms.local:9082/fps';
export const app_url = 'http://localhost:9080/eml';

export const environmentExtended = {
  wsHost: ws_host,
  appUrl: app_url,
  production: false,
  env: 'local',
  appBaseHref: '/',
  okta: {
    issuer: 'https://test.idp.idm.cms.gov/oauth2/aus11dsknd8PKBNVH298',
    clientId: '0oa11dsljqjv1uH3D298',
    redirectUri:
      'https://nlb-ifis-dev-f5c099364638a9e9.elb.us-east-1.amazonaws.com/login/callback',
    postLogoutRedirectUri:
      'https://nlb-ifis-dev-f5c099364638a9e9.elb.us-east-1.amazonaws.com',
    scopes: ['openid', 'profile', 'email', 'groups', 'offline_access'],
    state: 'ifis-auth-state',
    devMode: true,
  },
  trainingUrls: {
    lms: 'https://d1anwjvf3tiqib.cloudfront.net',
  },
  tableauBase: 'http://dtab1.awscloud.cms.local:8000',
  slaLoggingEnabled: false,
  splunkUrl:'',
  splunkToken: ''
};
