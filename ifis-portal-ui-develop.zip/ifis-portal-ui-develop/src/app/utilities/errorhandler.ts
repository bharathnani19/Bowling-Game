import { ErrorHandler, Injectable } from '@angular/core';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
  handleError(error: any): void {
    // Log to console for development
    console.error('Global Error:', error);

    // Custom logic: show a toast/alert or send to a logging service like Sentry
    alert('An unexpected error occurred. Please try again.');
  }
}