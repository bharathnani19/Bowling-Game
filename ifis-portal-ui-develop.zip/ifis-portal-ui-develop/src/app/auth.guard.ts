import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { IDToken } from '@okta/okta-auth-js';
import { OktaService } from './services/okta';
import { SessionService } from './services/session-timeout-service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {

  constructor(
    private okta: OktaService,
    private router: Router,
    private sessionService:SessionService
  ) { }
  private getBaseHref(): string {
    const baseHref = document.querySelector('base')?.getAttribute('href')?.trim() || '/';

    if (baseHref === '.' || baseHref === './') {
      return '/';
    }

    return baseHref.endsWith('/') ? baseHref.slice(0, -1) : baseHref;
  }

  private isUserNotAssignedOAuthError(error: unknown): boolean {
    if (!error || typeof error !== 'object') {
      return false;
    }

    const oauthError = error as { name?: string; message?: string; error_description?: string };
    const combinedMessage = `${oauthError.message ?? ''} ${oauthError.error_description ?? ''}`.toLowerCase();

    return oauthError.name === 'OAuthError' &&
      combinedMessage.includes('user is not assigned to the client application');
  }

  async canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean> {

    const hasCallbackParams =
      window.location.search.includes('code=') ||
      window.location.search.includes('state=');

    if (hasCallbackParams) {
      try {
        const { tokens } = await this.okta.oktaAuth.token.parseFromUrl();

        const idToken = tokens.idToken as IDToken | undefined;
        if (!idToken) {
          console.error('AuthGuard: missing idToken in auth callback response.');
          await this.okta.handleTokenTamperingDetected('Missing idToken in callback response');
          return false;
        }

        try {
          await this.okta.oktaAuth.token.verify(idToken);
        } catch (error) {
          console.error('AuthGuard: rejected invalid/tampered idToken during callback validation.', error);
          await this.okta.handleTokenTamperingDetected(error);
          return false;
        }

        this.okta.oktaAuth.tokenManager.setTokens(tokens);

        const originalUri = await this.okta.oktaAuth.getOriginalUri();
        this.okta.oktaAuth.removeOriginalUri();

        this.router.navigateByUrl(originalUri || this.getBaseHref());
        this.sessionService.startSessionTimeout();

        return false;
      } catch (error) {
        if (this.isUserNotAssignedOAuthError(error)) {
          console.error('OAuthError: User is not assigned to the client application.', error);
          return false;
        }

        throw error;
      }
    }

    const authenticated = await this.okta.oktaAuth.isAuthenticated();

    if (!authenticated) {
      await this.okta.oktaAuth.setOriginalUri(state.url);
      await this.okta.oktaAuth.signInWithRedirect();
      return false;
    }

    await this.okta.loadUser();
    return true;
  }

}
