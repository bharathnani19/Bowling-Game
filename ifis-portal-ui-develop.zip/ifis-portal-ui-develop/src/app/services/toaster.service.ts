import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root'
})
export class ToastService {

  constructor(private snackBar: MatSnackBar) {}

  success(message: string, duration: number = 3000) {
    this.snackBar.open(message, '', {
      duration,
      panelClass: ['toast-success'],
      horizontalPosition: 'center',
      verticalPosition: 'top'
    });
  }

  error(message: string, duration: number = 3000) {
    this.snackBar.open(message, '', {
      duration,
      panelClass: ['toast-error'],
      horizontalPosition: 'center',
      verticalPosition: 'top'
    });
  }

  info(message: string, duration: number = 3000) {
    this.snackBar.open(message, '', {
      duration,
      panelClass: ['toast-info'],
      horizontalPosition: 'center',
      verticalPosition: 'top'
    });
  }
}
