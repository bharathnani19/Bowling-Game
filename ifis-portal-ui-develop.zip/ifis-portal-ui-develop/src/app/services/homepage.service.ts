import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../environments/environment.shared';
import { Observable, of, tap } from 'rxjs';
import { formatMessage } from '../utilities/utils';
import { OktaService } from './okta';
import { homepageTiles, navBarData } from '../utilities/constants';

@Injectable({
  providedIn: 'root',
})
export class HomePageService {
  constructor(private http: HttpClient, private okta: OktaService) {}

  public getHomeTiles(): Observable<any> {
    let filteredTiles:any[] = homepageTiles.homepageTiles.sort((a:any, b:any) => a.homepageSqncNum- b.homepageSqncNum);
  //  console.log(filteredTiles.filter(t=>t.roles.some((r:string)=>this.okta.user().groups.includes(r)) &&  (t.homepageEnvCd === undefined || t.homepageEnvCd === environment.extended.env.toUpperCase())));
    return of({homepageTiles:filteredTiles.filter(t=>t.roles.some((r:string)=>this.okta.user().groups.includes(r) ) &&  (t.homepageEnvCd === undefined || t.homepageEnvCd === environment.extended.env.toUpperCase()))})
   // const headers = { 'Content-Type': 'application/json' };
  //  return this.http.get<any>(environment.wsUrls.homePageTileService, { headers });
  }

  
 
  public getHomePageToolbar(): Observable<any> {
    const url = formatMessage(environment.wsUrls.navbarData, {
      userId: this.okta.user().oktaDetails?.preferred_username,
      zoneId: this.okta.user().oldOrganizationVal,
    });
    return of(navBarData)
   /* const headers = { 'Content-Type': 'application/json' };
    return this.http.get<any>(url, { headers }).pipe(
      tap((res: any) => {
        const status = res.requests?.map((e: any) => e.status).join(',');
        this.okta.user.update((u) => {
          return {
            ...u,
            userRequest: status,
          };
        });
      })
    );
    */
  }

}
