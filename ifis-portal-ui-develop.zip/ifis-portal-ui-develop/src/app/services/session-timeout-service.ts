import { Inject, Injectable } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MatDialogState
} from '@angular/material/dialog';
import { fromEvent, merge } from 'rxjs';
import { OktaService } from './okta';
import { SessionInactiveModalComponent } from '../modules/core/session-timeout/session-timeout';

@Injectable({
  providedIn: 'root',
})
export class SessionService {
  private dialogRef!: MatDialogRef<SessionInactiveModalComponent>;

  private readonly LAST_ACTIVITY_KEY = 'lastPageActivity';
  private readonly SESSION_TIMEOUT_KEY = 'idleTimeExp';
  private readonly SESSION_TIMEOUT_DURATION = 30  * 60 * 1000; // 30 minutes
  private readonly REMINDER_TIME = 5  * 60 * 1000; // Pop up 5 min berfore session expire
  BLOCK_RENEW: boolean = false
  memoryStore = new Map<string, string>();
  constructor(private dialog: MatDialog,  private okta: OktaService) { }
  startSessionTimeout() {
    this.updateActivityTime(true)
    this.checkSessionTimeout();
    this.trackUserActivity();
  }

  updateActivityTime(onlySessionTimeout: boolean = false) {
    if (this.BLOCK_RENEW) { return }
    const now = new Date();
    const sesstionTimeoutTime = new Date();
    sesstionTimeoutTime.setTime(now.getTime() + this.SESSION_TIMEOUT_DURATION);
    const expTime = sesstionTimeoutTime.toString();
    this.safeSet(this.SESSION_TIMEOUT_KEY, expTime);
    // For startSessionTimeout we dont want it to update. 
    if (!onlySessionTimeout) {
      this.safeSet(this.LAST_ACTIVITY_KEY, Date.now().toString());
    }
  }

  private trackUserActivity() {
    const events = [
      fromEvent(document, 'keydown'),
      fromEvent(document, 'click'),
    ];
    merge(...events).subscribe(() => {
      this.updateActivityTime();
    });
  }

  private checkSessionTimeout() {
    setInterval(async () => {
      const userIsActive = await this.refreshIfActivityDetected();
      if (!userIsActive) {
        await this.checkIdleTimeExpiration();
      }
    }, 10 * 1000); // Check every 10 secs, reduced so that other tabs are also kicked out after session killed
  }

  private async refreshIfActivityDetected(): Promise<boolean> {
    const lastActivityTimeString = this.safeGet(this.LAST_ACTIVITY_KEY);
    const storedSessionTime = this.safeGet('LAST_RENEW_STAMP');
    const now = new Date().getTime();
    const timeDifference = now - parseInt(storedSessionTime ?? '', 10);
    // Convert milliseconds to minutes and return the value
    const lastRenewedTime = timeDifference / 60000;
    if (lastActivityTimeString) {
      const last = parseInt(lastActivityTimeString || '0', 10)
      const now = Date.now();
      const minutesSince = (now - last) / 60000
      if (minutesSince < 5 && lastRenewedTime > 2) {
        await this.renewToken();
        return true;
      }
    }
    return false;
  }

  private async checkIdleTimeExpiration() {
    const sessionTimeOutTime = this.safeGet(this.SESSION_TIMEOUT_KEY);
    const currentTime = Date.now();
    if (!sessionTimeOutTime) {
      console.error('sessionTimeOutTime not found - Redirecting ... ')
      await this.logout();
      return
    }
    const expireTime = new Date(sessionTimeOutTime).getTime();
    const reminderTime = expireTime - this.REMINDER_TIME;
    const idleTime = expireTime - currentTime;
    if (Math.floor(idleTime / (60 * 1000)) < 5) {
      console.info(this.getCurrentTimeFormatted() + 'Session will expire in -', Math.floor(idleTime / (60 * 1000)), ' minutes.');
    }
    if (currentTime >= expireTime) {
      this.BLOCK_RENEW = true;
      this.dialogRef?.close();
      this.logout();
    } else if (currentTime > reminderTime && !this.isDialogOpen()) {
      this.BLOCK_RENEW = true;
      this.showSessionExpirationDialog(this.REMINDER_TIME);
    } else if (currentTime < reminderTime && this.isDialogOpen()) {
      this.BLOCK_RENEW = true;
      this.dialogRef?.close(); // closes opened dialogs in other tabs;
    }
  }

  isDialogOpen(): boolean {
    return this.dialogRef && this.dialogRef?.getState() === MatDialogState.OPEN;
  }

  private showSessionExpirationDialog(_reminder_time: number) {
    console.log(this.getCurrentTimeFormatted() + ' OPENING SESSION DIALOG = ')
    this.BLOCK_RENEW = true;
    this.dialogRef = this.dialog.open(SessionInactiveModalComponent, {
      data: { timer: _reminder_time },
    });
    this.dialogRef.disableClose = true;
    this.dialogRef?.afterClosed().subscribe(async (result: any) => {
      console.log(this.getCurrentTimeFormatted() + ' CLOSING SESSION DIALOG = ')
      if (result === 'extend') {
        this.BLOCK_RENEW = false;
        this.dialogRef?.close();
        this.updateActivityTime();
        await this.renewToken();
        console.log(this.getCurrentTimeFormatted() + ' Session extended');
      } else if (result === 'logout') {
        this.BLOCK_RENEW = true;
        this.dialogRef?.close();
        console.log(this.getCurrentTimeFormatted() + ' User Logged out from Modal')
        this.logout();
      }
    });
  }

  async logout(): Promise<void> {
    this.BLOCK_RENEW = true;
    if (this.dialogRef && this.dialogRef?.getState() === MatDialogState.OPEN) {
      this.dialogRef?.close();
    }
    console.log(this.getCurrentTimeFormatted() + ' logout triggered!');
    this.okta.signOut();
  }

  private async renewToken(): Promise<void> {
    // If not blocked make sure Modal is closed.
    if (!this.BLOCK_RENEW) {
      this.BLOCK_RENEW = this.isDialogOpen();
    }

    if (!this.BLOCK_RENEW) {
      try {
        this.safeSet('LAST_RENEW_STAMP', new Date().getTime().toString());
        const newTokens = await this.okta.oktaAuth.token.renewTokens();
        this.okta.oktaAuth.tokenManager.setTokens(newTokens);
        console.log(this.getCurrentTimeFormatted() + ' ============== Silent RENEWWED =====================================  ');
      } catch (error) {
        console.log(this.getCurrentTimeFormatted() + ' ==OKTA==   refeshing page for signin with redirect');
        this.okta.oktaAuth.signInWithRedirect({
          originalUri: window.location.href, // Custom URI after successful login
        });
        console.log(this.getCurrentTimeFormatted() + ' ============== Session RENEWWED With Redirect ===================================== ');
      }
    } else {
      console.log(this.getCurrentTimeFormatted() + ' ============== Renew Skipped ===================================== ');
    }
  }

  getCurrentTimeFormatted(): string {
    const now = new Date();
    // Get hours, minutes, and seconds
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();
    // Pad single-digit numbers with a leading zero
    const formattedHours = hours < 10 ? '0' + hours : hours;
    const formattedMinutes = minutes < 10 ? '0' + minutes : minutes;
    const formattedSeconds = seconds < 10 ? '0' + seconds : seconds;
    // Combine into the hh:mm:ss format
    return `${formattedHours}:${formattedMinutes}:${formattedSeconds}`;
  }

  private safeSet(key: string, value: string): void {
    try {
      localStorage.setItem(key, value);
    } catch {
      try {
        sessionStorage.setItem(key, value);
      } catch {
        this.memoryStore.set(key, value);
      }
    }
  }

  private safeGet(key: string): string | null {
    try {
      return localStorage.getItem(key);
    } catch {
      try {
        return sessionStorage.getItem(key);
      } catch {
        return this.memoryStore.get(key) || null;
      }
    }
  }

}
