import { Injectable, signal } from '@angular/core';
import { AccessToken, IDToken, OktaAuth } from '@okta/okta-auth-js';
import { environment } from '../environments/environment.shared';
import { User } from '../models/user.model';

@Injectable({ providedIn: 'root' })
export class OktaService {
  user = signal<any>({});
  userInfo = signal<any>(null)
  isAuthenticated = signal(false);

  oktaAuth = new OktaAuth({
    clientId: environment.extended.okta.clientId,
    issuer: environment.extended.okta.issuer,
    redirectUri: environment.extended.okta.redirectUri,
    postLogoutRedirectUri: environment.extended.okta.postLogoutRedirectUri,
    scopes: ['openid', 'email', 'profile', 'groups', 'offline_access'],
    tokenManager: {
      storage: 'localStorage',
      autoRenew: true,
      autoRemove: true,
    },
  });

  async validateStoredIdToken(): Promise<boolean> {
    const idToken = await this.oktaAuth.tokenManager.get('idToken') as IDToken | undefined;

    if (!idToken) {
      console.error('OktaService: idToken missing from token manager.');
      return false;
    }

    try {
      await this.oktaAuth.token.verify(idToken);
      return true;
    } catch (error) {
      console.error('OktaService: detected invalid or tampered idToken.', error);
      await this.handleTokenTamperingDetected(error);
      return false;
    }
  }

  async handleTokenTamperingDetected(error: unknown): Promise<void> {
    console.error('OktaService: forcing sign-out due to token integrity failure.', error);
    this.oktaAuth.tokenManager.clear();

    try {
      await this.signOut();
    } catch (signOutError) {
      console.error('OktaService: sign-out failed after token integrity failure.', signOutError);
    }
  }

  async loadUser() {
    const auth = await this.oktaAuth.isAuthenticated();
    this.isAuthenticated.set(auth);

    if (auth) {
      const idTokenValid = await this.validateStoredIdToken();
      if (!idTokenValid) {
        this.isAuthenticated.set(false);
        return;
      }

      const userInfo = await this.oktaAuth.getUser();
      const accessToken = await this.oktaAuth.tokenManager.get('accessToken') as AccessToken;
      const idToken = await this.oktaAuth.tokenManager.get('idToken') as IDToken;
console.log(accessToken);
console.log(idToken);
      const userData: User = {}
      userData.groups = userInfo['groups'] as string[];
      this.userInfo.set(userInfo);
      // this.userService.setUserGroups(userInfo.groups);
      userData.userDisplayName = userInfo.name;
      userData.oktaDetails = userInfo;
      userData.rolesArray = [];
      userData.userAttrArray = [];
      userData.zonesArray = [];
      let groupsArray: string[] = [];
      if (userData.groups.length > 0) {
        let ifisGroupsArray = userData.groups.filter((g:any)=>g.startsWith('CPI IFIS'))  as string[] ;
        userData.groups = ifisGroupsArray;
      }

      for (let i = 0; i < groupsArray.length; i++) {
        const groupObj = groupsArray[i];
        // populate role array
        if (groupObj.search('FPSUI Role') !== -1) {
          userData.rolesArray.push(groupObj.replace('FPSUI Role', '').trim());
        }
        // populate the zone Array
        if (groupObj.search('FPSUI Zone') !== -1) {
          userData.zonesArray.push(groupObj.replace('FPSUI Zone', '').trim());
        }
        // populate the attributes Array
        if (groupObj.search('FPSUI Attrib') !== -1) {
          userData.userAttrArray.push(groupObj.replace('FPSUI Attrib', '').trim());
        }
        // populate the attributes Array
        if (groupObj.search('FPSUI EML') != -1) {
          userData.userAttrArray.push(groupObj.replace('FPSUI', '').trim());
        }
      }
      if (localStorage.getItem('firstTimeVisit') === null) {
        // this.metricsService.recordLogin(
        //   new UserMetrics(
        //     userInfo,
        //     userData.rolesArray.length > 0 ? userData.rolesArray[0] : '',
        //     userData.zonesArray.length > 0 ? userData.zonesArray[0] : '',
        //     userData.userAttrArray
        //   )
        // );
        localStorage.setItem('firstTimeVisit', 'true');
      }

      // if the user has a role, then let them proceed, else redirect them to UM
 //     if (!userData.rolesArray || userData.rolesArray.length === 0) {
 //        window.location.href = environment.umLink;
 //      } else {
        // user has a role so proceed to load the navigation bar
        // valid token... proceed to load navigation bar
        userData.rolesStr = userData.rolesArray.toString();
        userData.oldOrganizationVal = userData.zonesArray[0];
        // map old org values to new org values
        if (userData.oldOrganizationVal === 'UPIC 1') {
          userData.organization = 'UPIC MW';
        } else if (userData.oldOrganizationVal === 'UPIC 2') {
          userData.organization = 'UPIC NE';
        } else if (userData.oldOrganizationVal === 'UPIC 3') {
          userData.organization = 'UPIC W';
        } else if (userData.oldOrganizationVal === 'UPIC 4') {
          userData.organization = 'UPIC SW';
        } else if (userData.oldOrganizationVal === 'UPIC 5') {
          userData.organization = 'UPIC SE';
        } else {
          userData.organization = userData.oldOrganizationVal;
        }
        userInfo['organization'] = userData.organization as any;
        this.userInfo.set(userInfo);

        //if the user attributes array is not empty, then display attributes
        //return user attributes to the DOM
        if (userData.userAttrArray.length > 0) {
          //display the attributes component
          userData.showAttributes = true;
          //set the value of the attributes field
          userData.attributes = userData.userAttrArray.toString();
        } else {
          //don't display the attributes component
          userData.showAttributes = false;
        }





 //     }

     
      
      this.user.set(userData);

    }else{
      console.log("invalid IFIS Okta user")
      this.oktaAuth.signOut();
    }
  }



  signIn(): void {
    this.oktaAuth.signInWithRedirect();
  }

  async signOut(): Promise<void> {

    await this.oktaAuth.signOut({
      revokeAccessToken: true,
      clearTokensBeforeRedirect: true
    });
  }
}
