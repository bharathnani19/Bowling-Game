import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MaterialModule } from '../../material.module';

export interface ConfirmationDialogData {
  title?: string;
  message?: string; // supports HTML
  confirmText?: string;
  cancelText?: string;
  showCheckbox?: boolean;
  checkboxLabel?: string;
  danger?: boolean; // confirm button red
  icon?: string; // ex: "warning", "info", "error"
}

@Component({
  selector: 'app-confirmation-dialog',
  templateUrl: './confirmation-dialog.html',
  //   styleUrls: ['./confirmation-dialog.scss'],
  standalone: true,
  imports:[MaterialModule]
})
export class ConfirmationDialogComponent {
  checked = false;

  constructor(
    public dialogRef: MatDialogRef<ConfirmationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ConfirmationDialogData
  ) {}

  cancel() {
    this.dialogRef.close({ confirmed: false });
  }

  confirm() {
    this.dialogRef.close({
      confirmed: true,
      checkbox: this.checked,
    });
  }
}
