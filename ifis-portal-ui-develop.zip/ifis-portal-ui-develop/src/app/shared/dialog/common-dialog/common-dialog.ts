import { Component, Inject, Injector, Input } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ComponentType } from '@angular/cdk/portal';
import { MaterialModule } from '../../material.module';
import {MatIconModule} from  '@angular/material/icon';
export interface CommonDialogData {
  title?: string;
  info?: string;
  component: ComponentType<any>; // <-- dynamic component
  componentData?: any;
  enableAction?: boolean; // <-- data passed to component
}

@Component({
  selector: 'app-common-dialog',
  standalone: true,
  templateUrl: './common-dialog.html',
  styleUrl: './common-dialog.scss',
  imports:[MaterialModule]

})
export class CommonDialogComponent {
    childInjector!: Injector;
  constructor(
    public dialogRef: MatDialogRef<CommonDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: CommonDialogData
  ) {

    this.childInjector =  Injector.create({
      providers: [{ provide: 'componentData', useValue: this.data.componentData }],
    });
  }

}
