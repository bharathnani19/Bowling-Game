import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { LoaderService } from '../../services/loader.service';

@Component({
    selector: 'app-loader',
    // changeDetection: ChangeDetectionStrategy.OnPush,
    template: `
        <div class="app-loader-overlay" [class.active]="show" [attr.aria-hidden]="!show">
            <div class="app-loader-panel" role="status" aria-live="polite">
                <div class="spinner-container" role="status" aria-busy="true" data-test-id="tbl-loading">
                    <div class="spinner" aria-hidden="true"></div>
                    <span class="sr-only">Loading...</span>
                </div>
                @if(message){
                <div class="message">{{ message }}</div>
                }
            </div>
        </div>
    `,
    styles:[
        `
        /* Overlay */
        .app-loader-overlay {
            position: fixed;
            inset: 0; /* top:0; right:0; bottom:0; left:0; */
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(0, 0, 0, 0.35);
            opacity: 0;
            visibility: hidden;
            transition: opacity 200ms ease, visibility 200ms ease;
            z-index: 10000;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .app-loader-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        /* Panel */
        .app-loader-panel {
            display: flex;
            align-items: center;
            gap: 1rem;
            min-width: 220px;
            max-width: 92%;
            padding: 0.75rem 1rem;
            border-radius: 8px;
            // box-shadow: 0 8px 24px rgba(11, 15, 20, 0.2);
            // color: #222;
            pointer-events: auto;
        }

     

        /* Message text */
        .message {
            font-size: 0.95rem;
            color: #333;
            line-height: 1.2;
            word-break: break-word;
            max-width: 48ch;
        }
 
        `
    ],
    standalone:false,
})
export class AppLoaderComponent {
    /**
     * Controls visibility of the global loader.
     * Bind [show] from your app state or a loader service.
     */
    @Input() show = false;

    /**
     * Optional message displayed under the spinner.
     */
    @Input() message?: string;

    constructor(private loaderService: LoaderService) {
        this.loaderService.state$?.subscribe((state: any) => {
            // support boolean or object payloads
            if (state) {
                this.show = state.show;
                if (!state) this.message = undefined;
                return;
            }

            if (!state) {
                this.show = false;
                this.message = undefined;
                return;
            }

        });
    }
}
