
export interface Card {
  title: string;
  hoverText?:string;
  tableId?:string;
}

export interface SearchLookup {
  zones: any[];
  zoneNoMacs: any[];
  alerts: any[];
  models: any[];
  p1Models: any[];
  mdcdModels: any[];
  states: any[];
  rulings: any[];
  exclusions: any[];
  exclusionsMdcd: any[];
  prioritizationTypes: any[];
  edits: any[];
  enrollments: any[];
  exclusionCategories: any[];
  specialties: any[];
  mdcdSvcCats: any[];
  mdcdSvcSubCats: any[];
  mdcdSpecialties: any[];
  mdcdSvcTypes: any[];
  mdcdRoles: any[];
  p1EnabledInd: boolean;
}