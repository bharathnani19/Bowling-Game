import { NgModule } from '@angular/core';
import { PaneComponent } from './pane/pane';
import { MaterialModule } from './material.module';
import { CommonModule } from '@angular/common';
import { GridComponent } from './grid/grid';
import { GridItemComponent } from './grid/grid-item';
import { TableComponent } from './table/table';
import { CellTemplateDirective } from './table/cell.directive';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AlertBoxComponent } from './error-box/error-box';

import { MatOption } from "@angular/material/core";
import { MatDatepickerInput } from "@angular/material/datepicker";


const COMPONENTS = [
  PaneComponent,
  GridComponent,
  GridItemComponent,
  TableComponent,
  CellTemplateDirective,
  AlertBoxComponent,

];

@NgModule({
  declarations: [...COMPONENTS],
  imports: [CommonModule, MaterialModule, FormsModule, ReactiveFormsModule, RouterModule, MatOption, MatDatepickerInput],
  exports: [...COMPONENTS, RouterModule],
})
export class SharedModule {}
