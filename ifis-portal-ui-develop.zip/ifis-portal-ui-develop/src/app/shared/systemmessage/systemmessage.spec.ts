import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SystemmessageComponent } from './systemmessage';

describe('SystemmessageComponent', () => {
  let component: SystemmessageComponent;
  let fixture: ComponentFixture<SystemmessageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SystemmessageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SystemmessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
