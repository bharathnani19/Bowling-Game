import { Component, ElementRef, Input, signal, TrackByFunction, ViewChild } from '@angular/core';

@Component({
  selector: 'app-systemmessage',
  templateUrl: './systemmessage.html',
  styleUrl: './systemmessage.scss',
  standalone:false
})
export class SystemmessageComponent {

  @Input() msgs:any;
  @Input() newMsgCnt:any;
  @ViewChild('scrollContainer', { static: false }) scrollContainer!: ElementRef<HTMLElement>;
  private animationFrameId: number = 0;
  private targetScrollLeft: number = 0;
  private animationSpeed = 0.05; // Controls the "elastic" feel (higher = faster/less elastic)
  // test system message scroller, hide for now
  scrollerEnabled: boolean = false;

  updateFormView(arg0: string) {
    throw new Error('Method not implemented.');
    }
  getMaxScrollLeft(): number {
    const container = this.scrollContainer.nativeElement;
    return container.scrollWidth - container.clientWidth + 56;
  }

  scrollUp(element: HTMLElement) {
    element.scrollBy({ 
      top: -this.scrollStep, 
      behavior: 'smooth' // Provides smooth scrolling
    });
  }

  scrollDown(element: HTMLElement) {
    element.scrollBy({ 
      top: this.scrollStep, 
      behavior: 'smooth' 
    });
  }
  scrollLeft(): void {
    if (this.targetScrollLeft > 0) {
      this.targetScrollLeft -= 165;
      this.targetScrollLeft = Math.max(0, this.targetScrollLeft);
    }
    this.animateScroll();
  }

  scrollRight(): void {
    const maxScroll = this.getMaxScrollLeft();
    if (this.targetScrollLeft < maxScroll) {
      this.targetScrollLeft += 165;
      this.targetScrollLeft = Math.min(maxScroll, this.targetScrollLeft);
    }
    this.animateScroll();
  }
  private animateScroll(): void {
    const container = this.scrollContainer.nativeElement;

    this.animationFrameId = requestAnimationFrame(() => this.animateScroll());
    const currentScrollLeft = container.scrollLeft;
    // Calculate the difference between current and target position
    const difference = this.targetScrollLeft - currentScrollLeft;

    // Stop the animation if we are very close to the target position
    if (Math.abs(difference) < 1) {
      container.scrollLeft = this.targetScrollLeft;
      cancelAnimationFrame(this.animationFrameId);
      return;
    }

    // Apply easing move a fraction of the remaining distance each frame
    container.scrollLeft += difference * this.animationSpeed;
  }

  trackById: TrackByFunction<{ id: number; message: string; startDt: string; endDt: string }> = (index, sysMsg) => sysMsg.id;

  ngOnDestroy() {
  //  if (this.animationFrameId) {
  //    cancelAnimationFrame(this.animationFrameId);
  //  }
  //  this.viewportRef.nativeElement.removeEventListener('scroll', this.onScroll);
 //   window.removeEventListener('resize', this.onScroll);
  }

  
 /**
   * Items to display. Each one renders inside its own <div>.
   * You can pass strings, or objects and customize the template.
   */
 @Input() items: any[] = [];

 /**
  * Number of pixels to scroll per click. Defaults to 200.
  * Set to the approximate height of your item for snap-like behavior.
  */
 @Input() scrollStep = 100;

 /** Optional: Smooth scrolling on click */
 @Input() smooth = true;

 @ViewChild('systemMessageViewport', { static: true }) viewportRef!: ElementRef<HTMLDivElement>;

 // Signals for button disabled state
 canScrollUp = signal(false);
 canScrollDown = signal(false);

 //private onScroll = () => this.updateScrollState();

 ngAfterViewInit(): void {
   // Initialize button states
   //this.updateScrollState();
   // Recompute on scroll and on resize
   //this.viewportRef.nativeElement.addEventListener('scroll', this.onScroll, { passive: true });
   //window.addEventListener('resize', this.onScroll);
 }



 scrollUp2(): void {
   const el = this.viewportRef.nativeElement;
   el.scrollBy({
     top: -this.scrollStep,
     left: 0,
     behavior: this.smooth ? 'smooth' : 'auto',
   });
 }

 scrollDown2(): void {
   const el = this.viewportRef.nativeElement;
   el.scrollBy({
     top: this.scrollStep,
     left: 0,
     behavior: this.smooth ? 'smooth' : 'auto',
   });
 }

 trackByIndex = (_: number, __: unknown) => _;

 private updateScrollState(): void {
   const el = this.viewportRef.nativeElement;
   const maxScrollTop = el.scrollHeight - el.clientHeight;

   // Add a tiny epsilon to account for fractional pixels
   const epsilon = 1;

   this.canScrollUp.set(el.scrollTop > epsilon);
   this.canScrollDown.set(el.scrollTop < maxScrollTop - epsilon);
 }

}