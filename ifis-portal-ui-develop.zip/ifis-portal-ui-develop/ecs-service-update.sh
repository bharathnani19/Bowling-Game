#!/bin/bash

if ! command -v aws &>/dev/null; then
  echo "AWS CLI is not installed. Please install it to proceed."
  exit 1
fi

# Function to display usage
usage() {
  echo "Usage: $0 -t <task_definition> -s <service_name> -c <cluster_name> -i <new_image_tag> -p <aws_profile> -a <aws_account>"
  echo "  -t    ECS task definition family name"
  echo "  -s    ECS service name"
  echo "  -c    ECS cluster name"
  echo "  -i    New ECR image Tag"
  echo "  -p    AWS profile"
  echo "  -a    AWS account"
  exit 1
}

# Parse arguments
while getopts "t:s:c:i:p:a:" opt; do
  case $opt in
    t) TASK_DEFINITION=$OPTARG ;;
    s) SERVICE_NAME=$OPTARG ;;
    c) CLUSTER_NAME=$OPTARG ;;
    i) NEW_IMAGE_TAG=$OPTARG ;;
    p) AWS_PROFILE=$OPTARG ;;
    a) AWS_ACCOUNT=$OPTARG ;;

    *) usage ;;
  esac
done

# Validate input
if [ -z "$TASK_DEFINITION" ] || [ -z "$SERVICE_NAME" ] || [ -z "$CLUSTER_NAME" ] || [ -z "$NEW_IMAGE_TAG" ] || [ -z "$AWS_PROFILE" ]  || [ -z "$AWS_ACCOUNT" ]; then
  usage
fi

echo "Fetching current task definition for $TASK_DEFINITION..."
CURRENT_TASK_DEF=$(aws ecs describe-task-definition \
  --task-definition "$TASK_DEFINITION" \
  --query 'taskDefinition' \
  --profile "$AWS_PROFILE" \
  --output json)

if [ -z "$CURRENT_TASK_DEF" ]; then
  echo "Failed to fetch the task definition. Please check the task definition name."
  exit 1
fi

# Validate task definition structure
echo "Validating task definition structure..."
CONTAINER_DEFINITIONS=$(echo "$CURRENT_TASK_DEF" | jq '.containerDefinitions')
if [ -z "$CONTAINER_DEFINITIONS" ] || [ "$CONTAINER_DEFINITIONS" == "null" ]; then
  echo "Task definition does not contain valid container configurations."
  exit 1
fi

# Extract container definitions and update the image for the matching container
UPDATED_TASK_DEF=$(echo "$CURRENT_TASK_DEF" | jq --arg IMAGE "${AWS_ACCOUNT}.dkr.ecr.us-east-1.amazonaws.com/$NEW_IMAGE_TAG" --arg TASK_NAME "$TASK_DEFINITION" '.containerDefinitions |= map(if .name == $TASK_NAME then .image = $IMAGE else . end)')

# Register the updated task definition
echo "Registering new task definition..."
NEW_TASK_DEF=$(echo "$UPDATED_TASK_DEF" | jq 'del(.status, .taskDefinitionArn, .revision, .requiresAttributes, .compatibilities, .registeredAt, .registeredBy)')
NEW_TASK_DEF_ARN=$(aws ecs register-task-definition \
  --cli-input-json "$NEW_TASK_DEF" \
  --query 'taskDefinition.taskDefinitionArn' \
  --output text \
  --profile "$AWS_PROFILE")

if [ -z "$NEW_TASK_DEF_ARN" ]; then
  echo "Failed to register the updated task definition."
  exit 1
fi

echo "New task definition registered: $NEW_TASK_DEF_ARN"

# Update the ECS service
echo "Updating ECS service $SERVICE_NAME to use the new task definition..."
aws ecs update-service \
  --cluster "$CLUSTER_NAME" \
  --service "$SERVICE_NAME" \
  --task-definition "$NEW_TASK_DEF_ARN" \
  --profile "$AWS_PROFILE"

if [ $? -ne 0 ]; then
  echo "Failed to update the ECS service."
  exit 1
fi

echo "Service updated successfully. A new task will be launched with the updated image."
exit 0
