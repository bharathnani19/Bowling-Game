package com.cms.fps.service.fileupload;

public class FpsFileStore {
	
	private int id;
	private int recId;
	private String appName;
	private String fileName;
	private int fileVersion;
	private String actInd;
	private String fileType;
	private byte[] fileContent;
	private Long fileSize;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getRecId() {
		return recId;
	}
	public void setRecId(int recId) {
		this.recId = recId;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public int getFileVersion() {
		return fileVersion;
	}
	public void setFileVersion(int fileVersion) {
		this.fileVersion = fileVersion;
	}
	public String getActInd() {
		return actInd;
	}
	public void setActInd(String actInd) {
		this.actInd = actInd;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public byte[] getFileContent() {
		return fileContent;
	}
	public void setFileContent(byte[] fileContent) {
		this.fileContent = fileContent;
	}
	public Long getFileSize() {
		return fileSize;
	}
	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}
	
	

}
