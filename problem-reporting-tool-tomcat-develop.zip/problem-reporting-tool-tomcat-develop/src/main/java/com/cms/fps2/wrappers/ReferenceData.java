package com.cms.fps2.wrappers;

import java.util.List;

/**
 * @author madabas
 *
 */
public class ReferenceData {
	private List<AffectedSystems> affectedSystems;
	private List<ClaimCountRanges> claimCountRanges;
	private List<CmsCreqs> cmsCreqs;
	private List<DefectCategories> defectCategories;
	private List<EditNumbers> editNumbers;
	private List<IssueCategories> issueCategories;
	private List<Macs> macs;
	private List<ProblemPriorities> problemPriorities;
	private List<Statuses> statuses;
	private List<Pocs> pocs;

	public List<Pocs> getPocs() {
		return pocs;
	}

	public void setPocs(List<Pocs> pocs) {
		this.pocs = pocs;
	}

	public List<AffectedSystems> getAffectedSystems() {
		return affectedSystems;
	}

	public void setAffectedSystems(List<AffectedSystems> affectedSystems) {
		this.affectedSystems = affectedSystems;
	}

	public List<ClaimCountRanges> getClaimCountRanges() {
		return claimCountRanges;
	}

	public void setClaimCountRanges(List<ClaimCountRanges> claimCountRanges) {
		this.claimCountRanges = claimCountRanges;
	}

	public List<CmsCreqs> getCmsCreqs() {
		return cmsCreqs;
	}

	public void setCmsCreqs(List<CmsCreqs> cmsCreqs) {
		this.cmsCreqs = cmsCreqs;
	}

	public List<DefectCategories> getDefectCategories() {
		return defectCategories;
	}

	public void setDefectCategories(List<DefectCategories> defectCategories) {
		this.defectCategories = defectCategories;
	}

	public List<EditNumbers> getEditNumbers() {
		return editNumbers;
	}

	public void setEditNumbers(List<EditNumbers> editNumbers) {
		this.editNumbers = editNumbers;
	}

	public List<IssueCategories> getIssueCategories() {
		return issueCategories;
	}

	public void setIssueCategories(List<IssueCategories> issueCategories) {
		this.issueCategories = issueCategories;
	}

	public List<Macs> getMacs() {
		return macs;
	}

	public void setMacs(List<Macs> macs) {
		this.macs = macs;
	}

	public List<ProblemPriorities> getProblemPriorities() {
		return problemPriorities;
	}

	public void setProblemPriorities(List<ProblemPriorities> problemPriorities) {
		this.problemPriorities = problemPriorities;
	}

	public List<Statuses> getStatuses() {
		return statuses;
	}

	public void setStatuses(List<Statuses> statuses) {
		this.statuses = statuses;
	}

}
