package com.cms.fps2.wrappers;

/**
 * @author madabas
 *
 */
public class DefectCategories {

	private String dfctCtgryCd;
	private String dfctCtgryDesc;
	private String actvInd;
	private String loggedInUserId;

	public String getLoggedInUserId() {
		return loggedInUserId;
	}

	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}

	public String getActvInd() {
		return actvInd;
	}

	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}

	public String getDfctCtgryCd() {
		return dfctCtgryCd;
	}

	public void setDfctCtgryCd(String dfctCtgryCd) {
		this.dfctCtgryCd = dfctCtgryCd;
	}

	public String getDfctCtgryDesc() {
		return dfctCtgryDesc;
	}

	public void setDfctCtgryDesc(String dfctCtgryDesc) {
		this.dfctCtgryDesc = dfctCtgryDesc;
	}

}
