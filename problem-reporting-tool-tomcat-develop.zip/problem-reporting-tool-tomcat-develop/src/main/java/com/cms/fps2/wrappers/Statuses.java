package com.cms.fps2.wrappers;

public class Statuses {
	
	private String prodnPrblmRptStusCd;
	private String prodnPrblmRptStusDesc;	
	private String actvInd;
	private String loggedInUserId;

	public String getLoggedInUserId() {
		return loggedInUserId;
	}

	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}
	
	public String getProdnPrblmRptStusCd() {
		return prodnPrblmRptStusCd;
	}
	public void setProdnPrblmRptStusCd(String prodnPrblmRptStusCd) {
		this.prodnPrblmRptStusCd = prodnPrblmRptStusCd;
	}
	public String getProdnPrblmRptStusDesc() {
		return prodnPrblmRptStusDesc;
	}
	public void setProdnPrblmRptStusDesc(String prodnPrblmRptStusDesc) {
		this.prodnPrblmRptStusDesc = prodnPrblmRptStusDesc;
	}
	public String getActvInd() {
		return actvInd;
	}
	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}
	
	
	

}
