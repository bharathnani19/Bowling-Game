package com.cms.fps2.okta;

/*issuer: 'https://test.idp.idm.cms.gov/oauth2/ausbbjql1yRIpm9yt297',
clientId: '0oabbjqacsMm5sZO2297',
redirectUri: 'http://localhost:9080/ProblemReportingTool/',
postLogoutRedirectUri: 'http://localhost:9080/ProblemReportingTool/',
scopes: ['openid', 'profile', 'email'],
state: 'fps-auth-state', // used to validate the OAuth response		    

// set responseType and pkce to use authorization code flow
// responseType: 'code',
// pkce: false,
devMode: true*/

public class OktaConfig {
	private String issuer;
	private String clientId;
	private String redirectUri;
	private String postLogoutRedirectUri;
	private String[] scopes;
	private String state;
	private String devMode;

	public String[] getScopes() {
		return scopes;
	}

	public void setScopes(String[] scopes) {
		this.scopes = scopes;
	}

	public String getIssuer() {
		return issuer;
	}

	public void setIssuer(String issuer) {
		this.issuer = issuer;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getRedirectUri() {
		return redirectUri;
	}

	public void setRedirectUri(String redirectUri) {
		this.redirectUri = redirectUri;
	}

	public String getPostLogoutRedirectUri() {
		return postLogoutRedirectUri;
	}

	public void setPostLogoutRedirectUri(String postLogoutRedirectUri) {
		this.postLogoutRedirectUri = postLogoutRedirectUri;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDevMode() {
		return devMode;
	}

	public void setDevMode(String devMode) {
		this.devMode = devMode;
	}

}
