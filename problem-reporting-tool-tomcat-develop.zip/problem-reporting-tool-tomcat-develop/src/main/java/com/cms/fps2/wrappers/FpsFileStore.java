package com.cms.fps2.wrappers;

public class FpsFileStore {
	
	private String filStoreId;
	private String appName;
	private String appRecId	;
	private String filType;
	private String filName;
	private String filSize;
	private String actvInd	;
	private String filCntnt;	
	private String audtInsrtTs;
	private String audtInsrtId;
	
	
	public String getFilStoreId() {
		return filStoreId;
	}
	public void setFilStoreId(String filStoreId) {
		this.filStoreId = filStoreId;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getAppRecId() {
		return appRecId;
	}
	public void setAppRecId(String appRecId) {
		this.appRecId = appRecId;
	}
	public String getFilType() {
		return filType;
	}
	public void setFilType(String filType) {
		this.filType = filType;
	}
	public String getFilName() {
		return filName;
	}
	public void setFilName(String filName) {
		this.filName = filName;
	}
	public String getFilSize() {
		return filSize;
	}
	public void setFilSize(String filSize) {
		this.filSize = filSize;
	}
	public String getActvInd() {
		return actvInd;
	}
	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}
	public String getFilCntnt() {
		return filCntnt;
	}
	public void setFilCntnt(String filCntnt) {
		this.filCntnt = filCntnt;
	}
	public String getAudtInsrtTs() {
		return audtInsrtTs;
	}
	public void setAudtInsrtTs(String audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}	
	
}