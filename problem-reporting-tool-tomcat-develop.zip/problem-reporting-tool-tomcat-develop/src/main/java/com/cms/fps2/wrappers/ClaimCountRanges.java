package com.cms.fps2.wrappers;

public class ClaimCountRanges {

	private String clmCntRngCd;
	private String clmCntRngDesc;
	private String actvInd;

	private String loggedInUserId;

	public String getLoggedInUserId() {
		return loggedInUserId;
	}

	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}

	public String getClmCntRngCd() {
		return clmCntRngCd;
	}

	public void setClmCntRngCd(String clmCntRngCd) {
		this.clmCntRngCd = clmCntRngCd;
	}

	public String getClmCntRngDesc() {
		return clmCntRngDesc;
	}

	public void setClmCntRngDesc(String clmCntRngDesc) {
		this.clmCntRngDesc = clmCntRngDesc;
	}

	public String getActvInd() {
		return actvInd;
	}

	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}

}
