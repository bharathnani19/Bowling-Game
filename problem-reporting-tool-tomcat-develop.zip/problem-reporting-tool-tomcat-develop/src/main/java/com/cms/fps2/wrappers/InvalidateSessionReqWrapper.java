package com.cms.fps2.wrappers;

public class InvalidateSessionReqWrapper {
	private String tokenId;
	
	//constructor
	public InvalidateSessionReqWrapper(){}
	
	//tokenId
	public String getTokenId() {
		return tokenId;
	}
	
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
}
