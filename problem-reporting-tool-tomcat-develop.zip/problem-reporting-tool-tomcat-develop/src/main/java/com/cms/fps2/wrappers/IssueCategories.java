package com.cms.fps2.wrappers;

/**
 * @author madabas
 *
 */
public class IssueCategories {

	private String issCtgryCd;
	private String issCtgryDesc;
	private String actvInd;
	private String loggedInUserId;

	public String getLoggedInUserId() {
		return loggedInUserId;
	}

	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}

	public String getIssCtgryCd() {
		return issCtgryCd;
	}

	public void setIssCtgryCd(String issCtgryCd) {
		this.issCtgryCd = issCtgryCd;
	}

	public String getIssCtgryDesc() {
		return issCtgryDesc;
	}

	public void setIssCtgryDesc(String issCtgryDesc) {
		this.issCtgryDesc = issCtgryDesc;
	}

	public String getActvInd() {
		return actvInd;
	}

	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}

}
