package com.cms.fps2.wrappers;

import java.util.ArrayList;
import java.util.List;



public class NavBarRespWrapper {
	private List<Messages> messages = new ArrayList<Messages>();
	private List<PortalUserRequests> requests = new ArrayList<PortalUserRequests>();
	private String newSysMsgCt;
	
	//constructor
	public NavBarRespWrapper (){}
	
	
	
	//messages
	public List<Messages> getMessages() {
		return messages;
	}
	
	public void setMessages(List<Messages> messages) {
		this.messages = messages;
	}
	
	//requests
	public List<PortalUserRequests> getRequests() {
		return requests;
	}
		
	public void setRequests(List<PortalUserRequests> requests) {
		this.requests = requests;
	}
	
	//newSysMsgCt
	public String getNewSysMsgCt() {
		return newSysMsgCt;
	}
	
	public void setNewSysMsgCt(String newSysMsgCt) {
		this.newSysMsgCt = newSysMsgCt;
	}
}
