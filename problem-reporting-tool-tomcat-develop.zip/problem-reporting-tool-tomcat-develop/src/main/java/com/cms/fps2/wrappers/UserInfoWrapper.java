package com.cms.fps2.wrappers;


import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)  //ignore properties where the values are not needed 
public class UserInfoWrapper {
	private String username;
	private String userId;
	private String tokenId;
	List<String> givenName = new ArrayList<String>();
	List<String> sn = new ArrayList<String>();
	List<String> employeeType = new ArrayList<String>();
	List<String> businessCategory = new ArrayList<String>();
	@JsonProperty("ds-pwp-last-login-time")	
	List<String> lastLogin = new ArrayList<String>();
	@JsonProperty("asr-prioritization")	
	List<String> asrPrioritization = new ArrayList<String>();	
	@JsonProperty("master-approver")
	List<String> masterApprover = new ArrayList<String>();
	@JsonProperty("vm-admin")
	List<String> vmAdmin = new ArrayList<String>();
	@JsonProperty("vm-create")
	List<String> vmCreate = new ArrayList<String>();
	@JsonProperty("vm-update-edit")
	List<String> vmUpdateEdit = new ArrayList<String>();
	@JsonProperty("prt-admin")
	List<String> prtAdmin = new ArrayList<String>();
	@JsonProperty("prt-read")
	List<String> prtRead = new ArrayList<String>();
	@JsonProperty("prt-write")
	List<String> prtWrite = new ArrayList<String>();
	@JsonProperty("vm-read")
	List<String> vmRead = new ArrayList<String>();
	@JsonProperty("io-approver")
	List<String> ioApprover = new ArrayList<String>();
	@JsonProperty("dma-approver")
	List<String> dmaApprover = new ArrayList<String>();
	@JsonProperty("mac-approver")
	List<String> macApprover = new ArrayList<String>();
	@JsonProperty("mail")
	List<String> mail = new ArrayList<String>();
	
	
	
	
	
	
	
	
	public List<String> getMail() {
		return mail;
	}

	public void setMail(List<String> mail) {
		this.mail = mail;
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	//constructor
	public UserInfoWrapper(){}
	
	//username
	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	//givenName
	public List<String> getGivenName() {
		return givenName;
	}
	
	public void setGivenName(List<String> givenName) {
		this.givenName = givenName;
	}
	
	//sn (last name)
	public List<String> getSn() {
		return sn;
	}
	
	public void setSn(List<String> sn) {
		this.sn = sn;
	}
	
	//employeeType
	public List<String> getEmployeeType() {
		return employeeType;
	}
	
	public void setEmployeeType(List<String> employeeType) {
		this.employeeType = employeeType;
	}
	
	//businessCategory
	public List<String> getBusinessCategory() {
		return businessCategory;
	}
	
	public void setBusinessCategory(List<String> businessCategory) {
		this.businessCategory = businessCategory;
	}
	
	//lastLogin		
	public List<String> getLastLogin() {
		return lastLogin;
	}
	
	public void setLastLogin(List<String> lastLogin) {
		this.lastLogin = lastLogin;
	}
	
	//asrPrioritization
	public List<String> getAsrPrioritization() {
		return asrPrioritization;
	}
	
	public void setAsrPrioritization(List<String> asrPrioritization) {
		this.asrPrioritization = asrPrioritization;
	}
	
	//masterApprover
	public List<String> getMasterApprover() {
		return masterApprover;
	}
	
	public void setMasterApprover(List<String> masterApprover) {
		this.masterApprover = masterApprover;
	}
	
	//vmAdmin
	public List<String> getVmAdmin() {
		return vmAdmin;
	}
	
	public void setVmAdmin(List<String> vmAdmin) {
		this.vmAdmin = vmAdmin;
	}
	
	//vmCreate
	public List<String> getVmCreate() {
		return vmCreate;
	}
	
	public void setVmCreate(List<String> vmCreate) {
		this.vmCreate = vmCreate;
	}
	
	//vmUpdateEdit
	public List<String> getVmUpdateEdit() {
		return vmUpdateEdit;
	}
	
	public void setVmUpdateEdit(List<String> vmUpdateEdit) {
		this.vmUpdateEdit = vmUpdateEdit;
	}
	
	//prtAdmin	
	public List<String> getPrtAdmin() {
		return prtAdmin;
	}
	
	public void setPrtAdmin(List<String> prtAdmin) {
		this.prtAdmin = prtAdmin;
	}
	
	//prtRead
	public List<String> getPrtRead() {
		return prtRead;
	}
	
	public void setPrtRead(List<String> prtRead) {
		this.prtRead = prtRead;
	}
	
	//prtWrite
	public List<String> getPrtWrite() {
		return prtWrite;
	}
	
	public void setPrtWrite(List<String> prtWrite) {
		this.prtWrite = prtWrite;
	}
	
	//vmRead
	public List<String> getVmRead() {
		return vmRead;
	}
	
	public void setVmRead(List<String> vmRead) {
		this.vmRead = vmRead;
	}
	
	//ioApprover
	public List<String> getIoApprover() {
		return ioApprover;
	}
	
	public void setIoApprover(List<String> ioApprover) {
		this.ioApprover = ioApprover;
	}
	
	//dmaApprover
	public List<String> getDmaApprover() {
		return dmaApprover;
	}
	
	public void setDmaApprover(List<String> dmaApprover) {
		this.dmaApprover = dmaApprover;
	}
	
	// macApprover
	public List<String> getMacApprover() {
		return macApprover;
	}

	public void setMacApprover(List<String> macApprover) {
		this.macApprover = macApprover;
	}
	
}
