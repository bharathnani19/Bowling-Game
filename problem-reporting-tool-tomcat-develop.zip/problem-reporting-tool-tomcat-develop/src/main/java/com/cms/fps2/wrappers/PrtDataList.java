package com.cms.fps2.wrappers;

/**
 * @author madabas
 *
 */
public class PrtDataList {
	
	private String prodnPrblmRptId;
	private String rptTitleTxt;
	private String prblmSbmtdDt;
	private String fpsEditNum;
	private String fpsEditName;
	private String prblmDesc;
	private String macInfoTxt;
	private String prblmStusDesc;
	private String prblmFixCreqNum;
	private String prblmFixdDt;;
	private String prblmRptDocNum;
	private String modelCntrctr;
	private String fpsEditOwner;

	
	private String dfctCtgryDesc;
	private String clmCntRngDesc;
	private String prblmPrrtyDesc;
	private String issCtgryDesc;
	private String stusDesc;
	private String affectedSystems;
	private String macJrsdctnDesc;
	private String audtInsrtId;
	private String audtInsrtTs;
	private String audtUpdtTs;
	private String audtUpdtId;
	
	public String getMacJrsdctnDesc() {
		return macJrsdctnDesc;
	}
	public void setMacJrsdctnDesc(String macJrsdctnDesc) {
		this.macJrsdctnDesc = macJrsdctnDesc;
	}
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	public String getAudtInsrtTs() {
		return audtInsrtTs;
	}
	public void setAudtInsrtTs(String audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	public String getAudtUpdtTs() {
		return audtUpdtTs;
	}
	public void setAudtUpdtTs(String audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
	public String getAudtUpdtId() {
		return audtUpdtId;
	}
	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	
	
	public String getProdnPrblmRptId() {
		return prodnPrblmRptId;
	}
	public void setProdnPrblmRptId(String prodnPrblmRptId) {
		this.prodnPrblmRptId = prodnPrblmRptId;
	}
	public String getRptTitleTxt() {
		return rptTitleTxt;
	}
	public void setRptTitleTxt(String rptTitleTxt) {
		this.rptTitleTxt = rptTitleTxt;
	}
	public String getPrblmSbmtdDt() {
		return prblmSbmtdDt;
	}
	public void setPrblmSbmtdDt(String prblmSbmtdDt) {
		this.prblmSbmtdDt = prblmSbmtdDt;
	}
	public String getFpsEditNum() {
		return fpsEditNum;
	}
	public void setFpsEditNum(String fpsEditNum) {
		this.fpsEditNum = fpsEditNum;
	}
	public String getFpsEditName() {
		return fpsEditName;
	}
	public void setFpsEditName(String fpsEditName) {
		this.fpsEditName = fpsEditName;
	}
	public String getPrblmDesc() {
		return prblmDesc;
	}
	public void setPrblmDesc(String prblmDesc) {
		this.prblmDesc = prblmDesc;
	}
	public String getMacInfoTxt() {
		return macInfoTxt;
	}
	public void setMacInfoTxt(String macInfoTxt) {
		this.macInfoTxt = macInfoTxt;
	}
	public String getPrblmStusDesc() {
		return prblmStusDesc;
	}
	public void setPrblmStusDesc(String prblmStusDesc) {
		this.prblmStusDesc = prblmStusDesc;
	}
	public String getPrblmFixCreqNum() {
		return prblmFixCreqNum;
	}
	public void setPrblmFixCreqNum(String prblmFixCreqNum) {
		this.prblmFixCreqNum = prblmFixCreqNum;
	}
	public String getPrblmFixdDt() {
		return prblmFixdDt;
	}
	public void setPrblmFixdDt(String prblmFixdDt) {
		this.prblmFixdDt = prblmFixdDt;
	}
	public String getPrblmRptDocNum() {
		return prblmRptDocNum;
	}
	public void setPrblmRptDocNum(String prblmRptDocNum) {
		this.prblmRptDocNum = prblmRptDocNum;
	}
	public String getModelCntrctr() {
		return modelCntrctr;
	}
	public void setModelCntrctr(String modelCntrctr) {
		this.modelCntrctr = modelCntrctr;
	}
	public String getFpsEditOwner() {
		return fpsEditOwner;
	}
	public void setFpsEditOwner(String fpsEditOwner) {
		this.fpsEditOwner = fpsEditOwner;
	}
	public String getDfctCtgryDesc() {
		return dfctCtgryDesc;
	}
	public void setDfctCtgryDesc(String dfctCtgryDesc) {
		this.dfctCtgryDesc = dfctCtgryDesc;
	}
	public String getClmCntRngDesc() {
		return clmCntRngDesc;
	}
	public void setClmCntRngDesc(String clmCntRngDesc) {
		this.clmCntRngDesc = clmCntRngDesc;
	}
	public String getPrblmPrrtyDesc() {
		return prblmPrrtyDesc;
	}
	public void setPrblmPrrtyDesc(String prblmPrrtyDesc) {
		this.prblmPrrtyDesc = prblmPrrtyDesc;
	}
	public String getIssCtgryDesc() {
		return issCtgryDesc;
	}
	public void setIssCtgryDesc(String issCtgryDesc) {
		this.issCtgryDesc = issCtgryDesc;
	}
	public String getStusDesc() {
		return stusDesc;
	}
	public void setStusDesc(String stusDesc) {
		this.stusDesc = stusDesc;
	}
	public String getAffectedSystems() {
		return affectedSystems;
	}
	public void setAffectedSystems(String affectedSystems) {
		this.affectedSystems = affectedSystems;
	}
	
	
	
	
	

}
