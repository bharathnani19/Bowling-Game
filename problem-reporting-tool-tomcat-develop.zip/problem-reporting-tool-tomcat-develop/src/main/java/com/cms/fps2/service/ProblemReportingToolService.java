package com.cms.fps2.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ProblemReportingToolService extends HttpServlet {
private static final long serialVersionUID = 1L;
	
	//constructor
	public ProblemReportingToolService() {
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("Here I am!");
		
	}
}
