package com.cms.fps2.wrappers;


public class AccessInfo {

	private String userId;
	private String tokenId;
	private String role;
	
	
	private String access;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
		
	public String getAccess() {
		return access;
	}

	public void setAccess(String access) {
		this.access = access;
	}

	

	
	

}
