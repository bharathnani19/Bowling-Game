package com.cms.fps2.wrappers;

/**
 * @author madabas
 *
 */
public class Pocs {

	private String pocOrg;
	private String pocEmailAdr;
	private String actvInd;
	private String loggedInUserId;
	private String prodnPrblmRptOrgPocId;

	public String getProdnPrblmRptOrgPocId() {
		return prodnPrblmRptOrgPocId;
	}

	public void setProdnPrblmRptOrgPocId(String prodnPrblmRptOrgPocId) {
		this.prodnPrblmRptOrgPocId = prodnPrblmRptOrgPocId;
	}

	public String getLoggedInUserId() {
		return loggedInUserId;
	}

	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}

	public String getPocOrg() {
		return pocOrg;
	}

	public void setPocOrg(String pocOrg) {
		this.pocOrg = pocOrg;
	}

	public String getPocEmailAdr() {
		return pocEmailAdr;
	}

	public void setPocEmailAdr(String pocEmailAdr) {
		this.pocEmailAdr = pocEmailAdr;
	}

	public String getActvInd() {
		return actvInd;
	}

	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}

}
