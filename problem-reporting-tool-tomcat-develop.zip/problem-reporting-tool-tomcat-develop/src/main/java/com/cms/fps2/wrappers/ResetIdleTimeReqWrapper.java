package com.cms.fps2.wrappers;

public class ResetIdleTimeReqWrapper {
	private String tokenId;
	
	//constructor
	public ResetIdleTimeReqWrapper(){}
	
	//tokenId
	public String getTokenId() {
		return tokenId;
	}
	
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
}
