package com.cms.fps2.wrappers;

public class Properties {
	//constructor
	public Properties(){}
}
