package com.cms.fps2.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.io.FilenameUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.InputStreamBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.logging.LoggingFeature;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import com.cms.fps2.okta.OktaConfig;
import com.cms.fps2.wrappers.AccessInfo;
import com.cms.fps2.wrappers.AffectedSystems;
import com.cms.fps2.wrappers.ClaimCountRanges;
import com.cms.fps2.wrappers.CurrentUserAccessWrapper;
import com.cms.fps2.wrappers.DefectCategories;
import com.cms.fps2.wrappers.EditNumbers;
import com.cms.fps2.wrappers.FpsFileStore;
import com.cms.fps2.wrappers.InvalidateSessionReqWrapper;
import com.cms.fps2.wrappers.InvalidateSessionRespWrapper;
import com.cms.fps2.wrappers.IssueCategories;
import com.cms.fps2.wrappers.Macs;
import com.cms.fps2.wrappers.NavBarReqWrapper;
import com.cms.fps2.wrappers.NavBarRespWrapper;
import com.cms.fps2.wrappers.Pocs;
import com.cms.fps2.wrappers.ProblemPriorities;
import com.cms.fps2.wrappers.PrtData;
import com.cms.fps2.wrappers.PrtDataList;
import com.cms.fps2.wrappers.ReadMsgsReqWrapper;
import com.cms.fps2.wrappers.ReadMsgsRespWrapper;
import com.cms.fps2.wrappers.ReferenceData;
import com.cms.fps2.wrappers.ResetIdleTimeReqWrapper;
import com.cms.fps2.wrappers.ResetIdleTimeRespWrapper;
import com.cms.fps2.wrappers.SessionInfoReqWrapper;
import com.cms.fps2.wrappers.SessionInfoRespWrapper;
import com.cms.fps2.wrappers.Statuses;
import com.cms.fps2.wrappers.UserInfoWrapper;
import com.cms.util.FASScanner;
import com.cms.util.OktaLoginToken;
import com.cms.util.OktaLoginTokenFields;
import com.cms.util.PropertyFileHandler;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.Invocation;
import jakarta.ws.rs.client.Invocation.Builder;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.ResponseBuilder;

@Path("/prt")
public class ProblemReportingToolRestService {

	final static Logger logger = LogManager.getLogger(ProblemReportingToolRestService.class);
	@Context
	private HttpHeaders httpHeaders;

	@GET
	@Path("/{message}")
	public Response getMsg(@PathParam("message") String msg) {
		String output = "This methode does not exists in the rest service : " + msg;
		// Simply return the parameter passed as message
		return Response.status(200).entity(output).build();
	}

	@POST
	@Path("/getReferenceData")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public ReferenceData getReferenceData() {

		logger.debug("--> getReferenceData() REST Request initiated!");

		ReferenceData referenceData = new ReferenceData();

		try {

			String restURL = this.getWebServiceURL() + "/rest/prt/refdata";
			logger.debug("restURL = " + restURL);
			Invocation.Builder invocationBuilder = buildClientConfig(restURL);

			Response responseMsgs = invocationBuilder.header("Authorization", "Bearer " + getToken()).get();
			if (responseMsgs.getStatus() != 200 && responseMsgs.getStatus() != 202) {
				responseMsgs.close();
				throw new RuntimeException("Failed : HTTP error code : " + responseMsgs.getStatus() + ": "
						+ responseMsgs.getStatusInfo().getReasonPhrase());
			}
			referenceData = responseMsgs.readEntity(ReferenceData.class);

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		logger.debug("--> getReferenceData() REST Request Ended!");
		return referenceData;

	}

	@POST
	@Path("/getAdminReferenceData")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public ReferenceData getAdminReferenceData() {

		logger.debug("--> getAdminReferenceData() REST Request initiated!");
		ReferenceData referenceData = new ReferenceData();

		try {

			String restURL = this.getWebServiceURL() + "/rest/prt/refdata/admin";
			logger.debug("restURL = " + restURL);
			Invocation.Builder invocationBuilder = buildClientConfig(restURL);
			Response responseMsgs = invocationBuilder.get();
			;
			referenceData = responseMsgs.readEntity(ReferenceData.class);

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		logger.debug("--> getAdminReferenceData() REST Request Ended!");
		return referenceData;

	}

	@POST
	@Path("/getPRTData")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public PrtData getPRTData(PrtData data) {

		logger.debug("--> getPRTData() REST Request initiated!");
		PrtData prtData = new PrtData();

		logger.debug("Request -> ");

		try {
			// get the ucm Host name from the portal.properties file

			String restURL = this.getWebServiceURL() + "/rest/prt/" + data.getProdnPrblmRptId();
			logger.debug("restURL = " + restURL);
			;
			Invocation.Builder invocationBuilder = buildClientConfig(restURL);
			Response responseMsgs = invocationBuilder.get();
			prtData = responseMsgs.readEntity(PrtData.class);

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		logger.debug("--> getPRTData() REST Request Ended!");
		return prtData;

	}

	@POST
	@Path("/getSummaryData")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public List<PrtDataList> getSummaryData(PrtData data) {

		logger.debug("--> getSummaryData() REST Request initiated!");
		List<PrtDataList> prtData = new ArrayList<PrtDataList>();

		logger.debug("Request -> ");

		try {
			// get the ucm Host name from the portal.properties file

			String restURL = this.getWebServiceURL() + "/rest/prt/summary";
			logger.debug("restURL = " + restURL);
			Invocation.Builder invocationBuilder = buildClientConfig(restURL);
			Response responseMsgs = invocationBuilder.get();
			prtData = responseMsgs.readEntity(new GenericType<List<PrtDataList>>() {
			});
			;

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		logger.debug("--> getSummaryData() REST Request Ended!");
		return prtData;

	}

	@POST
	@Path("/putPRTData")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public PrtData putPRTData(PrtData data) {

		logger.debug("--> postPRTData() REST Request initiated!");
		PrtData prtData = new PrtData();

		logger.debug("Request -> ");

		try {
			// get the ucm Host name from the portal.properties file

			String restURL = this.getWebServiceURL() + "/rest/prt/";
			logger.debug("restURL = " + restURL);
			WebTarget target = buildWebTarget(restURL);

			Response response = target.request().accept("application/json").header("Content-Type", "application/json")
					.header("Authorization", "Bearer " + getToken())
					.put(Entity.entity(data, MediaType.APPLICATION_JSON));
			prtData = response.readEntity(PrtData.class);
			;
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		logger.debug("--> postPRTData() REST Request Ended!");
		return prtData;
	}

	@POST
	@Path("/postPRTData")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public PrtData postPRTData(PrtData data) {

		logger.debug("--> postPRTData() REST Request initiated!");
		PrtData prtData = new PrtData();

		logger.debug("Request -> ");

		try {
			// get the ucm Host name from the portal.properties file

			String restURL = this.getWebServiceURL() + "/rest/prt/";
			logger.debug("restURL = " + restURL);
			WebTarget target = buildWebTarget(restURL);

			Response response = target.request().accept("application/json").header("Content-Type", "application/json")
					.header("Authorization", "Bearer " + getToken())
					.post(Entity.entity(data, MediaType.APPLICATION_JSON));
			prtData = response.readEntity(PrtData.class);

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		logger.debug("--> postPRTData() REST Request Ended!");
		return prtData;
	}

	@POST
	@Path("/postDefectCategories")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public DefectCategories postDefectCategories(DefectCategories input) {

		logger.debug("--> postDefectCategories() REST Request initiated!");
		DefectCategories output = new DefectCategories();

		logger.debug("Request -> ");

		try {
			// get the ucm Host name from the portal.properties file

			String restURL = this.getWebServiceURL() + "/rest/prt/refdata/dfct";
			logger.debug("restURL = " + restURL);
			WebTarget target = buildWebTarget(restURL);

			Response response = target.request().accept("application/json").header("Content-Type", "application/json")
					.header("Authorization", "Bearer " + getToken())
					.post(Entity.entity(input, MediaType.APPLICATION_JSON));
			output = response.readEntity(DefectCategories.class);

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		logger.debug("--> postDefectCategories() REST Request Ended!");
		return output;

	}

	@POST
	@Path("/postClaimCount")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public ClaimCountRanges postClaimCount(ClaimCountRanges input) {

		logger.debug("--> postClaimCount() REST Request initiated!");
		ClaimCountRanges output = new ClaimCountRanges();

		logger.debug("Request -> ");

		try {
			// get the ucm Host name from the portal.properties file

			String restURL = this.getWebServiceURL() + "/rest/prt/refdata/clmcnt";
			logger.debug("restURL = " + restURL);

			WebTarget target = buildWebTarget(restURL);

			Response response = target.request().accept("application/json").header("Content-Type", "application/json")
					.header("Authorization", "Bearer " + getToken())
					.post(Entity.entity(input, MediaType.APPLICATION_JSON));
			output = response.readEntity(ClaimCountRanges.class);

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		logger.debug("--> postClaimCount() REST Request Ended!");
		return output;

	}

	@POST
	@Path("/postIssueCategory")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public IssueCategories postIssueCategory(IssueCategories input) {

		logger.debug("--> postIssueCategory() REST Request initiated!");
		IssueCategories output = new IssueCategories();

		logger.debug("Request -> ");

		try {
			// get the ucm Host name from the portal.properties file

			String restURL = this.getWebServiceURL() + "/rest/prt/refdata/issctgry";
			logger.debug("restURL = " + restURL);

			WebTarget target = buildWebTarget(restURL);

			Response response = target.request().accept("application/json").header("Content-Type", "application/json")
					.header("Authorization", "Bearer " + getToken())
					.post(Entity.entity(input, MediaType.APPLICATION_JSON));
			output = response.readEntity(IssueCategories.class);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		logger.debug("--> postIssueCategory() REST Request Ended!");
		return output;

	}

	@POST
	@Path("/postProblemPriority")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public ProblemPriorities postProblemPriority(ProblemPriorities input) {

		logger.debug("--> postProblemPriority() REST Request initiated!");
		ProblemPriorities output = new ProblemPriorities();

		logger.debug("Request -> ");

		try {
			// get the ucm Host name from the portal.properties file

			String restURL = this.getWebServiceURL() + "/rest/prt/refdata/prblmprrty";
			logger.debug("restURL = " + restURL);

			WebTarget target = buildWebTarget(restURL);

			Response response = target.request().accept("application/json").header("Content-Type", "application/json")
					.header("Authorization", "Bearer " + getToken())
					.post(Entity.entity(input, MediaType.APPLICATION_JSON));
			output = response.readEntity(ProblemPriorities.class);

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		logger.debug("--> postIssueCategory() REST Request Ended!");
		return output;

	}

	@POST
	@Path("/postMacs")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Macs postMacs(Macs input) {

		logger.debug("--> postMacs() REST Request initiated!");
		Macs output = new Macs();

		logger.debug("Request -> ");

		try {
			// get the ucm Host name from the portal.properties file

			String restURL = this.getWebServiceURL() + "/rest/prt/refdata/mac";
			logger.debug("restURL = " + restURL);

			WebTarget target = buildWebTarget(restURL);

			Response response = target.request().accept("application/json").header("Content-Type", "application/json")
					.header("Authorization", "Bearer " + getToken())
					.post(Entity.entity(input, MediaType.APPLICATION_JSON));
			output = response.readEntity(Macs.class);

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		logger.debug("--> postMacs() REST Request Ended!");
		return output;

	}

	@POST
	@Path("/postStatuses")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Statuses postStatuses(Statuses input) {

		logger.debug("--> postStatuses() REST Request initiated!");
		Statuses output = new Statuses();

		logger.debug("Request -> ");

		try {
			// get the ucm Host name from the portal.properties file

			String restURL = this.getWebServiceURL() + "/rest/prt/refdata/status";
			logger.debug("restURL = " + restURL);

			WebTarget target = buildWebTarget(restURL);

			Response response = target.request().accept("application/json").header("Content-Type", "application/json")
					.header("Authorization", "Bearer " + getToken())
					.post(Entity.entity(input, MediaType.APPLICATION_JSON));
			output = response.readEntity(Statuses.class);

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		logger.debug("--> postStatuses() REST Request Ended!");
		return output;
	}

	@POST
	@Path("/postAffectedSystems")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public AffectedSystems postAffectedSystems(AffectedSystems input) {

		logger.debug("--> postAffectedSystems() REST Request initiated!");
		AffectedSystems output = new AffectedSystems();

		logger.debug("Request -> ");

		try {
			// get the ucm Host name from the portal.properties file

			String restURL = this.getWebServiceURL() + "/rest/prt/refdata/afctdsys";
			logger.debug("restURL = " + restURL);

			WebTarget target = buildWebTarget(restURL);

			Response response = target.request().accept("application/json").header("Content-Type", "application/json")
					.header("Authorization", "Bearer " + getToken())
					.post(Entity.entity(input, MediaType.APPLICATION_JSON));
			output = response.readEntity(AffectedSystems.class);

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		logger.debug("--> postAffectedSystems() REST Request Ended!");
		return output;
	}

	@POST
	@Path("/postEditNumbers")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public EditNumbers postEditNumbers(EditNumbers input) {

		logger.debug("--> postEditNumbers() REST Request initiated!");
		EditNumbers output = new EditNumbers();

		logger.debug("Request -> ");

		try {
			// get the ucm Host name from the portal.properties file

			String restURL = this.getWebServiceURL() + "/rest/prt/refdata/edit";
			logger.debug("restURL = " + restURL);

			WebTarget target = buildWebTarget(restURL);

			Response response = target.request().accept("application/json").header("Content-Type", "application/json")
					.header("Authorization", "Bearer " + getToken())
					.post(Entity.entity(input, MediaType.APPLICATION_JSON));
			output = response.readEntity(EditNumbers.class);

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		logger.debug("--> postEditNumbers() REST Request Ended!");
		return output;
	}

	@POST
	@Path("/postEmailNotify")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Pocs postEmailNotify(Pocs input) {

		logger.debug("--> postClaimCount() REST Request initiated!");
		Pocs output = new Pocs();

		logger.debug("Request -> ");

		try {
			// get the ucm Host name from the portal.properties file

			String restURL = this.getWebServiceURL() + "/rest/prt/refdata/poc";
			logger.debug("restURL = " + restURL);

			WebTarget target = buildWebTarget(restURL);

			Response response = target.request().accept("application/json").header("Content-Type", "application/json")
					.header("Authorization", "Bearer " + getToken())
					.post(Entity.entity(input, MediaType.APPLICATION_JSON));
			output = response.readEntity(Pocs.class);

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		logger.debug("--> postClaimCount() REST Request Ended!");
		return output;

	}

	@POST
	@Path("/deletePRTList")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public PrtData deletePRTList(PrtData[] data) {

		logger.debug("--> deletePRTList() REST Request initiated!");
		PrtData prtData = new PrtData();

		logger.debug("Request -> " + data.length);

		try {
			// get the ucm Host name from the portal.properties file

			for (int i = 0; i < data.length; i++) {
				logger.debug("id -> " + data[i]);
				String restURL = this.getWebServiceURL() + "/rest/prt/" + data[i].getProdnPrblmRptId();
				logger.debug("restURL = " + restURL);
				Invocation.Builder invocationBuilder = buildClientConfig(restURL);
				Response responseMsgs = invocationBuilder.get();
				prtData = responseMsgs.readEntity(PrtData.class);
				prtData.setActvInd("N");
				prtData.setLoggedInUserId(data[i].getLoggedInUserId());
				this.postPRTData(prtData);

			}

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		logger.debug("--> deletePRTList() REST Request Ended!");
		return prtData;

	}

	@GET
	@Path("/getServiceURL")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String getServiceURL() {

		logger.debug("--> getServiceURL() REST Request initiated!");

		logger.debug("Request -> ");

		try {
			return this.getAppServiceURL();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		logger.debug("--> getServiceURL() REST Request Ended!");
		return null;

	}

	@POST
	@Path("/getUserInfo")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public UserInfoWrapper getUserInfo(UserInfoWrapper req) {

		UserInfoWrapper res = new UserInfoWrapper();

		logger.debug("Inside ProblemReportingTool.getUserInfo(). TokenId = " + req.getTokenId());

		try {
			// get the OpenAm Host name from the portal.properties file
			String openAmUrl = this.getOpenAmURL();

			logger.debug("openamURL property = " + openAmUrl);
			if (!req.getTokenId().isEmpty()) {
				// config needed for PoJo mapping
				Invocation.Builder invocationBuilder = buildClientConfig(openAmUrl + "/json/users/" + req.getUserId());
				invocationBuilder.header("iPlanetDirectoryPro", req.getTokenId());
				Response clientRes = invocationBuilder.get();

				if (clientRes.getStatus() != 200) {
					// close the response due to bad connection
					clientRes.close();

					throw new RuntimeException("Failed : HTTP error code : " + clientRes.getStatus() + ": "
							+ clientRes.getStatusInfo().getReasonPhrase());
				} else {

					// REST Call was successful
					res = clientRes.readEntity(UserInfoWrapper.class);
					logger.debug("User Info REST Output from Server .... \n" + clientRes);

					// close the response
					clientRes.close();
				}

			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		return res;
	}

	@POST
	@Path("/getAccessInfo")
	@Produces({ "application/json" })
	@Consumes({ "application/json" })
	public AccessInfo getAccessInfo(AccessInfo req) {
		UserInfoWrapper res = new UserInfoWrapper();

		logger.debug("Inside ProblemReportingTool.getAccessInfo(). TokenId = " + req.getTokenId());
		try {
			String openAmUrl = getOpenAmURL();
			logger.debug("openamURL property = " + openAmUrl);
			if (!req.getTokenId().isEmpty()) {

				Invocation.Builder invocationBuilder = buildClientConfig(openAmUrl + "/json/users/" + req.getUserId());
				invocationBuilder.header("iPlanetDirectoryPro", req.getTokenId());
				Response clientRes = invocationBuilder.get();
				if (clientRes.getStatus() != 200) {
					clientRes.close();
					throw new RuntimeException("Failed : HTTP error code : " + clientRes.getStatus() + ": "
							+ clientRes.getStatusInfo().getReasonPhrase());
				}
				res = (UserInfoWrapper) clientRes.readEntity(UserInfoWrapper.class);

				logger.debug("User Info REST Output from Server .... \n" + req);
				logger.debug("User Info REST Output from Server .... \n" + req.toString());
				clientRes.close();

				logger.debug("User Info REST Output from Server .... \n" + req);
				logger.debug("User Info REST Output from Server .... \n" + req.toString());
				clientRes.close();

				logger.debug("Role = " + req.getRole());
				logger.debug("EmpType = " + res.getEmployeeType().get(0));
				logger.debug("Admin = " + res.getPrtAdmin().get(0));
				logger.debug("Write = " + res.getPrtWrite().get(0));
				logger.debug("Read = " + res.getPrtRead().get(0));
				// logger.debug("VmCreate = " + res.getVmCreate().get(0));

				boolean admin = res.getEmployeeType().get(0) != null && res.getEmployeeType().size() > 0
						&& res.getEmployeeType().get(0).equalsIgnoreCase("Admin") ? true : false;
				boolean padmin = res.getPrtAdmin().get(0) != null && res.getPrtAdmin().size() > 0
						&& res.getPrtAdmin().get(0).equalsIgnoreCase("1") ? true : false;

				boolean write = res.getPrtWrite().get(0) != null && res.getPrtWrite().size() > 0
						&& res.getPrtWrite().get(0).equalsIgnoreCase("1") ? true : false;
				boolean read = res.getPrtRead().get(0) != null && res.getPrtRead().size() > 0
						&& res.getPrtRead().get(0).equalsIgnoreCase("1") ? true : false;
				// boolean reate = res.getVmCreate().get(0) != null && res.getVmCreate().size()
				// > 0 && res.getVmCreate().get(0).equalsIgnoreCase("1")?true:false;

				if (req.getRole().equalsIgnoreCase("a")) {
					logger.debug("Admin check  ");
					if (admin || padmin) {
						req.setAccess("Y");
						return req;
					}

				} else if (req.getRole().equalsIgnoreCase("w")) {
					logger.debug("Update EDit  ");

					if (admin || padmin || write) {
						req.setAccess("Y");
						return req;
					}

				} else if (req.getRole().equalsIgnoreCase("r")) {
					logger.debug("Read check  ");
					if (read) {
						req.setAccess("Y");
						return req;
					}
				} else if (req.getRole().equalsIgnoreCase("any")) {
					logger.debug("Any check  ");
					if (admin || padmin || write || read) {
						req.setAccess("Y");
						return req;
					}

				}
			}
		} catch (IOException e1) {
			e1.printStackTrace();

		}

		return null;

	}

	@POST
	@Path("/sessionInfo")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public SessionInfoRespWrapper getSessionInfo(SessionInfoReqWrapper pSessionInfoReq) {
		SessionInfoRespWrapper oSessionInfoResponse = new SessionInfoRespWrapper();

		try {
			// get the ucm Host name from the portal.properties file

			String openAmUrlStr = this.getOpenAmURL();
			logger.debug("openAmUrlStr = " + openAmUrlStr);

			if (!openAmUrlStr.isEmpty()) {

				Invocation.Builder invocationBuilder = buildClientConfig(
						openAmUrlStr + "/json/sessions/?_action=getSessionInfo");
				invocationBuilder.header("Accept-API-Version", "resource=3.0");
				Response response = invocationBuilder.get();

				if (response.getStatus() != 200 && response.getStatus() != 202) {
					// close the response due to bad connection
					response.close();

					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				} else {
					// response is a String rather than JSON, so capture it as such
					oSessionInfoResponse = response.readEntity(SessionInfoRespWrapper.class);

					logger.debug("sessionInfo REST Output from Server .... \n");

					// close the response
					response.close();

					// use the values from the response to calculate the remaining idle time
					try {
						// convert the Max Idle Expiration Time from the response to a Date object
						Date maxIdleTimeDt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
								.parse(oSessionInfoResponse.getMaxIdleExpirationTime().replace("Z", ""));
						// get the current date and time
						Date currentTimeDt = new Date();

						logger.debug("maxIdleTimeDt = " + maxIdleTimeDt.toString() + ", currentTimeDt = "
								+ currentTimeDt.toString());

						// subtract the max idle time from the current time, and then convert to minutes
						long idleTimeLeft = maxIdleTimeDt.getTime() - currentTimeDt.getTime();
						long idleTimeLeftMins = idleTimeLeft / (60 * 1000) % 60;

						logger.debug("***Idle Time Remaining (Minutes) = " + idleTimeLeftMins);

						// populate the response's timeRemainingMins property with the idle time minutes
						oSessionInfoResponse.setRemainingIdleTime(String.valueOf(idleTimeLeftMins));

					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					logger.debug("sessionInfo REST Output from Server .... \n");
				}

			}
			// } catch (SocketException se1) {
			// TODO Auto-generated catch block
			// se1.printStackTrace();
		} catch (IOException ie1) {
			ie1.printStackTrace();
		}

		return oSessionInfoResponse;
	}

	@POST
	@Path("/getAllFiles/{id}")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public FpsFileStore[] getAllFiles(@PathParam("id") String id

	) {
		FpsFileStore[] output = null;

		try {

			String restURL = this.getWebServiceURL() + "/rest/prt/" + id + "/files";

			logger.debug("restURL = " + restURL);

			Invocation.Builder invocationBuilder = buildClientConfig(restURL);
			Response responseMsgs = invocationBuilder.get();
			output = responseMsgs.readEntity(FpsFileStore[].class);
			return output;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return output;
	}

	@POST
	@Path("/deleteFile/{id}/{userid}")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public String deleteFile(@PathParam("id") String id, @PathParam("userid") String userid

	) {

		try {
			// String restURL =
			// "http://ustlvcmsp2338.prod:9082/fps/rest/prt/file/"+id+"/"+userid;
			String restURL = this.getWebServiceURL() + "/rest/prt/file/" + id + "/" + userid;

			logger.debug("restURL = " + restURL);
			WebTarget target = buildWebTarget(restURL);

			Response response = target.request().accept("application/json").header("Content-Type", "application/json")
					.header("Authorization", "Bearer " + getToken())
					.delete();

			return response.getStatus() + "";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}

	@POST
	@Path("/uploadFile/{id}/{userid}")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public String uploadFile(@FormDataParam("file") InputStream fileInputStream,
			@FormDataParam("file") FormDataContentDisposition fileMetaData,
			@PathParam("id") String id, @PathParam("userid") String userid

	) throws FpsException {
		System.out.println("Received File!!!" + fileMetaData.getFileName());

		// using for-each loop for iteration over Map.entrySet()
		for (Map.Entry<String, String> entry : fileMetaData.getParameters().entrySet()) {
			System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
		}

		// String restURL = "http://ustlvcmsp2338.prod:9082/fps/rest/prt/" + id +
		// "/file/" + userid;

		try {
			// fis = fileInputStream;
			String restURL = this.getWebServiceURL() + "/rest/prt/" + id + "/file/" + userid;
			DefaultHttpClient httpclient = new DefaultHttpClient(new BasicHttpParams());

			String fileName = fileMetaData.getFileName();
			if (fileName != null) {
				fileName = FilenameUtils.getName(fileName);
				if (!(fileName.toLowerCase().endsWith(".docx") || fileName.toLowerCase().endsWith(".xlsx")
						|| fileName.toLowerCase().endsWith(".pdf"))) {
					return "Failed";
				}
			} else {
				return "Failed";
			}

			FASScanner scan = new FASScanner();
			int i;
			byte buff[] = new byte[1024];
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			logger.debug("baos size==>" + baos.size());
			while (-1 != (i = fileInputStream.read(buff, 0, buff.length))) {
				baos.write(buff, 0, i);
			}
			logger.debug("No of bytes==>" + baos.size());

			String encodedfileName = URLEncoder.encode(fileName, StandardCharsets.UTF_8.toString());
			int fileScanResponse = scan.analyzeFileStreamForVirus(baos, encodedfileName);

			if (fileScanResponse == 200) {
				// server back-end URL
				HttpPost httppost = new HttpPost(restURL);
				MultipartEntity entity = new MultipartEntity();
				entity.addPart("file",
						(ContentBody) new InputStreamBody(new ByteArrayInputStream(baos.toByteArray()), fileName));
				httppost.setEntity(entity);
				httppost.addHeader (new BasicHeader("Authorization", "Bearer " + getToken()));	
				// execute the request
				HttpResponse response = httpclient.execute(httppost);
				int statusCode = response.getStatusLine().getStatusCode();
				HttpEntity responseEntity = response.getEntity();
				String responseString = EntityUtils.toString(responseEntity, "UTF-8");
				logger.debug("******************** Response ******************** ");
				logger.debug("[" + statusCode + "] " + responseString);
				logger.debug("******************** ******************** ******************** ");

				return statusCode + "";
			} else {
				logger.debug("File Scan response failed!  ");
				return "FAS connection/scan failed - return code -" + fileScanResponse;
			}

		} catch (ClientProtocolException e) {
			logger.error("Unable to make connection", e);
			e.printStackTrace();
			throw new RuntimeException("Unable to upload file : " + e.getMessage());
		} catch (IOException e) {
			logger.error("Unable to make connection", e);
			e.printStackTrace();
			throw new RuntimeException("Unable to upload file : " + e.getMessage());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("Unable to make connection", e);
			e.printStackTrace();
			throw new RuntimeException("Unable to upload file : " + e.getMessage());
		} finally {
			try {
				if (fileInputStream != null)
					fileInputStream.close();
			} catch (IOException e) {
			}
		}

	}

	@POST
	@Path("/downloadFile")
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response downloadFile(String url) {

		// String url = "http://ustlvcmsp2338:9082/fps/rest/prt/file/208";

		try {
			ResponseBuilder responseBuilder = null;

			if (!url.isEmpty()) {

				Integer.parseInt(url.trim());
				url = this.getWebServiceURL() + "/rest/prt/file/" + url;
				logger.debug(">>" + url);
				Invocation.Builder invocationBuilder = buildClientConfig(url);
				invocationBuilder.accept(MediaType.APPLICATION_OCTET_STREAM);
				invocationBuilder.header("Content-Type", "application/octet-stream");
				Response response = invocationBuilder.get();
				;

				if (response.getStatus() != 200) {
					// close the response due to bad connection
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				} else {

					logger.debug("Download file Successful! MediaType-" + MediaType.APPLICATION_OCTET_STREAM);
					logger.debug(" Content-Disposition-" + response.getHeaders().get("Content-Disposition").toString());
					responseBuilder = Response.ok((InputStream) response.getEntity(), "application/octet-stream");
					responseBuilder.header("Content-Disposition",
							((List) response.getHeaders().get("Content-Disposition")).toString());

					return responseBuilder.build();
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException("Unable to download file : " + e.getMessage());
		}

		return null;

	}

	@POST
	@Path("/test/{id}/{userid}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String Test(@PathParam("id") String id, @PathParam("userid") String userid) {
		System.out.println("TESTED!!" + id);
		System.out.println("TESTED!!" + userid);
		return userid;
	}

	/**
	 * This method calls the AM5 Session v3.0 post /sessions/?_action=validate web service
	 * to reset the idle time for the current portal user.  On success, the service returns
	 * timeout details of the session.
	 * 
	 * @param pSessionInfoReq
	 * @return
	 */
	@POST	
	@Path("/resetIdleTime")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public ResetIdleTimeRespWrapper getResetIdleTime(ResetIdleTimeReqWrapper pSessionInfoReq) {
		ResetIdleTimeRespWrapper oResetIdleTimeResponse = new ResetIdleTimeRespWrapper();

		try {
			//get the ucm Host name from the portal.properties file				
			//			PropertyFileHandler pfh = new PropertyFileHandler();
			//			String openAmUrlStr = pfh.getPortalProperty("openamURL");
			String openAmUrlStr = this.getOpenAmURL();

			if (!openAmUrlStr.isEmpty()) {
				//config needed for PoJo mapping

				WebTarget target = buildWebTarget(openAmUrlStr + "/json/sessions?_action=validate");
				Builder builder = target.request();
				
				
			;
				
				Response response =  builder
						.accept("application/json").header("Content-Type", "application/json")
						.header("Accept-API-Version", "resource=3.0")
						.header("Authorization", "Bearer " + getToken())
						.header("iPlanetDirectoryPro", pSessionInfoReq.getTokenId())
						.post(Entity.entity("", MediaType.APPLICATION_JSON));

				if(response.getStatus() != 200 && response.getStatus() != 202){
					//close the response due to bad connection
					response.close();

					throw new RuntimeException("Failed : HTTP error code : "
							+ response.getStatus() + ": " + response.getStatusInfo().getReasonPhrase());
				} else {
					//response is a String rather than JSON, so capture it as such
					oResetIdleTimeResponse = response.readEntity(ResetIdleTimeRespWrapper.class);

					logger.debug("sessionInfo REST Output from Server .... \n");	

					//close the response
					response.close();
				}
				
				
			}

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		return oResetIdleTimeResponse;
	}

	/**
	 * This method calls the AM5 Session v3.0 post /sessions/?_action=logout web
	 * service to invalidate the session of the Unified Portal user. On success, the
	 * service returns a result message that states that the user was successfully
	 * logged out of the system.
	 * 
	 * @param pInvalidSessionReq
	 * @return
	 */
	@POST
	@Path("/invalidateSession")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public InvalidateSessionRespWrapper getInvalidateSession(InvalidateSessionReqWrapper pInvalidSessionReq) {
		InvalidateSessionRespWrapper oInvalidSessionResp = new InvalidateSessionRespWrapper();

//		try {
//			// get the ucm Host name from the portal.properties file
//			// PropertyFileHandler pfh = new PropertyFileHandler();
//			// String openAmUrlStr = pfh.getPortalProperty("openamURL");
//			String openAmUrlStr = this.getOpenAmURL();
//
//			if (!openAmUrlStr.isEmpty()) {
//				// config needed for PoJo mapping
//				ClientConfig config = new DefaultClientConfig();
//				config.getClasses().add(JacksonJaxbJsonProvider.class);
//				config.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, Boolean.TRUE);
//
//				// call the ucm Reassign Lead service
//				Client client = buildClientConfig(config);
//				client.addFilter(new LoggingFilter(System.out)); // log the request
//
//				WebResource webResource = client.resource(openAmUrlStr + "/json/sessions?_action=logout");
//				ClientResponse response = webResource.accept("application/json")
//						.header("Content-Type", "application/json").header("Accept-API-Version", "resource=3.0")
//						.header("iPlanetDirectoryPro", pInvalidSessionReq.getTokenId()).post(ClientResponse.class);
//
//				if (response.getStatus() != 200 && response.getStatus() != 202) {
//					// close the response due to bad connection
//					response.close();
//
//					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
//							+ response.getStatusInfo().getReasonPhrase());
//				} else {
//					// response is a String rather than JSON, so capture it as such
//					oInvalidSessionResp = response.getEntity(InvalidateSessionRespWrapper.class);
//
//					logger.debug("Invalidate Session REST Output from Server .... \n");
//
//					// close the response
//					response.close();
//				}
//			}
//		} catch (IOException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}

		return oInvalidSessionResp;
	}

	@POST
	@Path("/getPropertyValue")
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.TEXT_PLAIN)
	public String getPropertyValue(String propName) {

		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			return pfh.getProperty(propName);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	@GET
	@Path("/getOktaConfig")
	@Produces(MediaType.APPLICATION_JSON)
	public OktaConfig getOktaConfig() {

		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			OktaConfig okc = new OktaConfig();
			okc.setIssuer(pfh.getProperty("issuer"));
			okc.setClientId(pfh.getProperty("clientId"));
			okc.setRedirectUri(pfh.getProperty("redirectUri"));
			okc.setPostLogoutRedirectUri(pfh.getProperty("postLogoutRedirectUri"));
			okc.setScopes(pfh.getProperty("scopes").split(","));
			okc.setState(pfh.getProperty("state"));
			okc.setDevMode(pfh.getProperty("devMode"));

			return okc;

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	@GET
	@Path("/currentUserAccess")
	@Produces(MediaType.APPLICATION_JSON)
	public CurrentUserAccessWrapper getCurrentUserAccess() {
		CurrentUserAccessWrapper access = new CurrentUserAccessWrapper();
		try {
			Map<String, Object> claims = parseAccessTokenClaims(getIdToken());
			if (claims.isEmpty()) {
				return access;
			}

			List<String> groups = asStringList(claims.get("groups"));
			List<String> roles = new ArrayList<String>();
			List<String> zones = new ArrayList<String>();
			List<String> userAttributes = new ArrayList<String>();

			for (String groupObj : groups) {
				if (groupObj == null) {
					continue;
				}

				if (groupObj.contains("FPSUI Role")) {
					roles.add(groupObj.replace("FPSUI Role", "").trim());
				}

				if (groupObj.contains("FPSUI Zone")) {
					zones.add(groupObj.replace("FPSUI Zone", "").trim());
				}

				if (groupObj.contains("FPSUI Attrib")) {
					userAttributes.add(groupObj.replace("FPSUI Attrib", "").trim());
				}

				if (groupObj.contains("FPSUI EML")) {
					userAttributes.add(groupObj.replace("FPSUI ", "").trim());
				}
			}

			access.setGroups(groups);
			access.setRoles(roles);
			access.setZones(zones);
			access.setUserAttributes(userAttributes);
			access.setEmail(asString(claims.get("email")));
			access.setName(asString(claims.get("name")));
			access.setPreferredUsername(asString(claims.get("preferred_username")));
			access.setFirstName(asString(claims.get("first_name")));
			access.setLastName(asString(claims.get("last_name")));
			access.setPrtRead(userAttributes.contains("PRT Read"));
			access.setPrtWrite(userAttributes.contains("PRT Write"));
			access.setPrtAdmin(userAttributes.contains("PRT Admin") || roles.contains("Admin"));
		} catch (Exception e) {
			logger.error("Unable to build currentUserAccess from access token", e);
		}

		return access;
	}

	private String getWebServiceURL() throws IOException {
		PropertyFileHandler pfh = new PropertyFileHandler();
		return pfh.getProperty("wsURL");
	}

	private String getAppServiceURL() throws IOException {
		PropertyFileHandler pfh = new PropertyFileHandler();
		return pfh.getProperty("serviceURL");
	}

	private String getOpenAmURL() throws IOException {
		PropertyFileHandler pfh = new PropertyFileHandler();
		return pfh.getProperty("openamURL");
	}

	private Invocation.Builder buildClientConfig(String url) {
		ClientConfig clientConfig = new ClientConfig();
		clientConfig.property(LoggingFeature.LOGGING_FEATURE_VERBOSITY_CLIENT, LoggingFeature.Verbosity.PAYLOAD_ANY);
		Client client = ClientBuilder.newClient(clientConfig);

		WebTarget webResourceMsgs = client.target(url);

		Invocation.Builder invocationBuilder = webResourceMsgs.request();
		invocationBuilder.header("Content-Type", "application/json");
		invocationBuilder.accept("application/json");
		invocationBuilder.header("Authorization", "Bearer " + getToken());

		return invocationBuilder;

	}

	private WebTarget buildWebTarget(String url) {
		ClientConfig clientConfig = new ClientConfig();
		clientConfig.property(LoggingFeature.LOGGING_FEATURE_VERBOSITY_CLIENT, LoggingFeature.Verbosity.PAYLOAD_ANY);
		Client client = ClientBuilder.newClient(clientConfig);

		WebTarget webTarget = client.target(url);

		return webTarget;

	}
	private String getToken() {
		String accessToken = this.httpHeaders.getRequestHeader("authorization").get(0);
		
		return accessToken;
	}
	private String getIdToken() {
		String accessToken = this.httpHeaders.getRequestHeader("fpsauthorization").get(0);
		
		return accessToken;
	}
	@POST
	@Path("/record")
	@Consumes({ "application/json" })
	public void recordLogin(OktaLoginTokenFields pOktaTokenFields) {
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String splunkURL = pfh.getProperty("splunkURL");
			String splunkToken = pfh.getProperty("splunkToken");
			String env = pfh.getProperty("env");
			if (!splunkURL.isEmpty()) {
				OktaLoginToken oktaToken = new OktaLoginToken();
				pOktaTokenFields.setTimestamp(new Date());
				pOktaTokenFields.setEnv(env);
				oktaToken.setEvent(pOktaTokenFields);
				logger.warn(oktaToken);

				Client client = buildClientConfig();
				WebTarget webResource = client.target(splunkURL);
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Content-Type", "application/json").header("Authorization", "Splunk " + splunkToken)
						.post(Entity.entity(oktaToken, MediaType.APPLICATION_JSON));

				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
//	        oUcmLeadDataResponse = (UCMLeadDataRespWrapper)response.getEntity(UCMLeadDataRespWrapper.class);
				logger.debug("recordLogin REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
	}
	@POST
	@Path("/navBarData")
	@Produces({ "application/json" })
	@Consumes({ "application/json" })
	public NavBarRespWrapper getNavMessagesData(NavBarReqWrapper pMsgsRequest) {
		NavBarRespWrapper oMsgsResponse = new NavBarRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = getWebServiceURL();
			//	("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceMsgs = client.target(
						String.valueOf(ucmUrlStr) + "/rest/landingpage/header/" + verifyUser(pMsgsRequest.getUserId())
								+ "/" + pMsgsRequest.getUserZone().replaceAll(" ", "%20"));

				Invocation.Builder invocationBuilder = webResourceMsgs.request();
				invocationBuilder.header("Content-Type", "application/json");
				invocationBuilder.header("Authorization", "Bearer " + getToken());

				
				invocationBuilder.accept("application/json");

				Response responseMsgs = invocationBuilder.get();
				if (responseMsgs.getStatus() != 200 && responseMsgs.getStatus() != 202) {
					responseMsgs.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseMsgs.getStatus() + ": "
							+ responseMsgs.getStatusInfo().getReasonPhrase());
				}
				oMsgsResponse = (NavBarRespWrapper) responseMsgs.readEntity(NavBarRespWrapper.class);
//				//logger.debug("Nav Bar REST Output from Server .... \n");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oMsgsResponse;
	}
	@POST
	@Path("/readMessages")
	@Produces({ "application/json" })
	public ReadMsgsRespWrapper getMsgsAsReadByUser(ReadMsgsReqWrapper pLandPageDataReq) {
		ReadMsgsRespWrapper oReadMsgsResponse = new ReadMsgsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = getWebServiceURL();
			//logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/landingpage/messages/read/"
						+ verifyUser(pLandPageDataReq.getUserId()));
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oReadMsgsResponse.setValidResponse("true");
				//logger.debug("Assign ASRs REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException ioe) {
			logger.error(ioe.getMessage(), ioe);
		}
		return oReadMsgsResponse;
	}
	private Client buildClientConfig() {
		ClientConfig clientConfig = new ClientConfig();
		clientConfig.property(LoggingFeature.LOGGING_FEATURE_VERBOSITY_CLIENT, LoggingFeature.Verbosity.PAYLOAD_ANY);
		clientConfig.property(ClientProperties.CONNECT_TIMEOUT, 360000);
		clientConfig.property(ClientProperties.READ_TIMEOUT, 360000);

		SSLContext sslcontext;
		try {
			sslcontext = SSLContext.getInstance("TLSv1.2");

			sslcontext.init(null, new TrustManager[] { new X509TrustManager() {
				@Override
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				@Override
				public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}

				@Override
				public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}

			} }, new java.security.SecureRandom());

			Client client = ClientBuilder.newBuilder().withConfig(clientConfig).sslContext(sslcontext)
					.hostnameVerifier((s1, s2) -> true).connectTimeout(6, TimeUnit.MINUTES)
					.readTimeout(6, TimeUnit.MINUTES).build();
			return client;
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;

	}
	private String verifyUser(String userId) {
//		String accessToken = this.httpHeaders.getRequestHeader("authorization").get(0);
////		logger.debug("Token = " + accessToken);
//		boolean valid = JwtUtil.getInstance().verifyUser(accessToken, userId);
//		String validUserId = userId;
//		if (!valid)
//			validUserId = "none";
//		return validUserId;
		return userId;
	}

	private Map<String, Object> parseAccessTokenClaims(String authHeader) throws IOException {
		String tokenValue = extractRawToken(authHeader);
		if (tokenValue == null || tokenValue.isEmpty()) {
			return Collections.emptyMap();
		}

		String[] tokenParts = tokenValue.split("\\.");
		if (tokenParts.length < 2) {
			return Collections.emptyMap();
		}

		String payload = tokenParts[1];
		byte[] decodedPayload = Base64.getUrlDecoder().decode(payload);
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(decodedPayload, new TypeReference<Map<String, Object>>() {
		});
	}

	private String extractRawToken(String authHeader) {
		if (authHeader == null) {
			return "";
		}

		if (authHeader.startsWith("Bearer ")) {
			return authHeader.substring(7);
		}

		if (authHeader.startsWith("Bearer")) {
			return authHeader.substring(6);
		}

		return authHeader;
	}

	private List<String> asStringList(Object input) {
		if (input == null) {
			return new ArrayList<String>();
		}

		List<String> output = new ArrayList<String>();
		if (input instanceof List<?>) {
			for (Object value : (List<?>) input) {
				if (value != null) {
					output.add(String.valueOf(value));
				}
			}
		}

		return output;
	}

	private String asString(Object value) {
		return value == null ? "" : String.valueOf(value);
	}

}
