package com.cms.fps2.wrappers;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({ "properties" }) // ignore properties response field since values are unknown
public class SessionInfoRespWrapper {
	private String username;
	private String universalId;
	private String realm;
	private String latestAccessTime;
	private String maxIdleExpirationTime;
	private String maxSessionExpirationTime;
	private Properties properties;
	private String remainingIdleTime;

	// constructor
	public SessionInfoRespWrapper() {
	}

	// username
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	// universalId
	public String getUniversalId() {
		return universalId;
	}

	public void setUniversalId(String universalId) {
		this.universalId = universalId;
	}

	// realm
	public String getRealm() {
		return realm;
	}

	public void setRealm(String realm) {
		this.realm = realm;
	}

	// latestAccessTime
	public String getLatestAccessTime() {
		return latestAccessTime;
	}

	public void setLatestAccessTime(String latestAccessTime) {
		this.latestAccessTime = latestAccessTime;
	}

	// maxIdleExpirationTime
	public String getMaxIdleExpirationTime() {
		return maxIdleExpirationTime;
	}

	public void setMaxIdleExpirationTime(String maxIdleExpirationTime) {
		this.maxIdleExpirationTime = maxIdleExpirationTime;
	}

	// maxIdleExpirationTime
	public String getMaxSessionExpirationTime() {
		return maxSessionExpirationTime;
	}

	public void setMaxSessionExpirationTime(String maxSessionExpirationTime) {
		this.maxSessionExpirationTime = maxSessionExpirationTime;
	}

	// properties
	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}

	// remainingIdleTime
	public String getRemainingIdleTime() {
		return remainingIdleTime;
	}

	public void setRemainingIdleTime(String remainingIdleTime) {
		this.remainingIdleTime = remainingIdleTime;
	}

}
