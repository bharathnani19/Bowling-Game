package com.cms.fps2.wrappers;

public class ProblemPriorities {

	private String prblmPrrtyCd;
	private String prblmPrrtyDesc;
	private String actvInd;
	private String loggedInUserId;

	public String getLoggedInUserId() {
		return loggedInUserId;
	}

	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}

	public String getPrblmPrrtyCd() {
		return prblmPrrtyCd;
	}

	public void setPrblmPrrtyCd(String prblmPrrtyCd) {
		this.prblmPrrtyCd = prblmPrrtyCd;
	}

	public String getPrblmPrrtyDesc() {
		return prblmPrrtyDesc;
	}

	public void setPrblmPrrtyDesc(String prblmPrrtyDesc) {
		this.prblmPrrtyDesc = prblmPrrtyDesc;
	}

	public String getActvInd() {
		return actvInd;
	}

	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}

}
