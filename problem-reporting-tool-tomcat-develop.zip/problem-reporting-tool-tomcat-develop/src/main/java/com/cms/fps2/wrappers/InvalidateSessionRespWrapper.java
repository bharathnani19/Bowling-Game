package com.cms.fps2.wrappers;

public class InvalidateSessionRespWrapper {
	private String result;
	
	//constructor
	public InvalidateSessionRespWrapper(){}
	
	//result
	public String getResult() {
		return result;
	}
	
	public void setResult(String result) {
		this.result = result;
	}
}
