package com.cms.fps2.wrappers;

/**
 * @author madabas
 *
 */
public class EditNumbers {

	private String fpsEditNum;
	private String fpsEditName;
	private String echimpName;
	private String modelCntrctr;
	private String editOwner;
	private String actvInd;
	private String audtInsrtId;
	private String audtInsrtTs;
	private String audtUpdtId;
	private String audtUpdtTs;
	private String macInfo;
	private String loggedInUserId;
	private String editDesc;
    private String editActnType;
    private String lineOfBusns;
    private String hstry;
    private String hstryLkbckPrd;
    private String echimpNum;
	
	public String getEditDesc() {
		return editDesc;
	}

	public void setEditDesc(String editDesc) {
		this.editDesc = editDesc;
	}

	public String getEditActnType() {
		return editActnType;
	}

	public void setEditActnType(String editActnType) {
		this.editActnType = editActnType;
	}

	public String getLineOfBusns() {
		return lineOfBusns;
	}

	public void setLineOfBusns(String lineOfBusns) {
		this.lineOfBusns = lineOfBusns;
	}

	public String getHstry() {
		return hstry;
	}

	public void setHstry(String hstry) {
		this.hstry = hstry;
	}

	public String getHstryLkbckPrd() {
		return hstryLkbckPrd;
	}

	public void setHstryLkbckPrd(String hstryLkbckPrd) {
		this.hstryLkbckPrd = hstryLkbckPrd;
	}

	public String getEchimpNum() {
		return echimpNum;
	}

	public void setEchimpNum(String echimpNum) {
		this.echimpNum = echimpNum;
	}

	


	public String getLoggedInUserId() {
		return loggedInUserId;
	}

	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}

	public String getMacInfo() {
		return macInfo;
	}

	public void setMacInfo(String macInfo) {
		this.macInfo = macInfo;
	}

	public String getFpsEditNum() {
		return fpsEditNum;
	}

	public void setFpsEditNum(String fpsEditNum) {
		this.fpsEditNum = fpsEditNum;
	}

	public String getFpsEditName() {
		return fpsEditName;
	}

	public void setFpsEditName(String fpsEditName) {
		this.fpsEditName = fpsEditName;
	}

	public String getModelCntrctr() {
		return modelCntrctr;
	}

	public void setModelCntrctr(String modelCntrctr) {
		this.modelCntrctr = modelCntrctr;
	}

	public String getEditOwner() {
		return editOwner;
	}

	public void setEditOwner(String editOwner) {
		this.editOwner = editOwner;
	}

	public String getActvInd() {
		return actvInd;
	}

	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}

	public String getAudtInsrtId() {
		return audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	public String getAudtInsrtTs() {
		return audtInsrtTs;
	}

	public void setAudtInsrtTs(String audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	public String getAudtUpdtId() {
		return audtUpdtId;
	}

	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}

	public String getAudtUpdtTs() {
		return audtUpdtTs;
	}

	public void setAudtUpdtTs(String audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}

	public String getEchimpName() {
		return echimpName;
	}

	public void setEchimpName(String echimpName) {
		this.echimpName = echimpName;
	}

}
