package com.cms.fps2.wrappers;

public class AffectedSystems {
	private String afctdSysCd;
	private String afctdSysDesc;
	private String actvInd;
	
	public String getAfctdSysCd() {
		return afctdSysCd;
	}
	public void setAfctdSysCd(String afctdSysCd) {
		this.afctdSysCd = afctdSysCd;
	}
	public String getAfctdSysDesc() {
		return afctdSysDesc;
	}
	public void setAfctdSysDesc(String afctdSysDesc) {
		this.afctdSysDesc = afctdSysDesc;
	}
	public String getActvInd() {
		return actvInd;
	}
	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}
	
	
	

}
