package com.cms.fps2.wrappers;

public class CmsCreqs {

	private String cmsCreqCd;
	private String creqDesc;
	private String audtInsrtId;
	private String audtInsrtTs;
	private String loggedInUserId;

	public String getLoggedInUserId() {
		return loggedInUserId;
	}

	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}

	public String getCmsCreqCd() {
		return cmsCreqCd;
	}

	public void setCmsCreqCd(String cmsCreqCd) {
		this.cmsCreqCd = cmsCreqCd;
	}

	public String getCreqDesc() {
		return creqDesc;
	}

	public void setCreqDesc(String creqDesc) {
		this.creqDesc = creqDesc;
	}

	public String getAudtInsrtId() {
		return audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	public String getAudtInsrtTs() {
		return audtInsrtTs;
	}

	public void setAudtInsrtTs(String audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

}
