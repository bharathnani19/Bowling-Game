package com.cms.fps2.wrappers;

public class ReadMsgsReqWrapper {
	
	private String userId;
	
	//constructor
	public ReadMsgsReqWrapper(){}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
