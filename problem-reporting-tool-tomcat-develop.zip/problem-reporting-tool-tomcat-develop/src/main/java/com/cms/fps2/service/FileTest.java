package com.cms.fps2.service;

import java.io.IOException;

import javax.ws.rs.core.Response;

import org.apache.http.client.ClientProtocolException;

public class FileTest {

	/**
	 * * @param args
	 * 
	 * @throws JSONException
	 * 
	 * @throws IOException
	 * @throws ClientProtocolException
	 */
	public static void main(String[] args) throws IOException {

//		test() ;
//		test1();
//		test3();
		test6();
	}
	/*
	 * public static void test3() throws IOException {
	 * 
	 * // System.out.println("--> "+form.toString()); // MultipartFile file ;
	 * 
	 * String restURL =
	 * "http://ustlvcmsp2338.prod:9082/fps/rest/prt/426/file/sriniiomax"; Client
	 * client = Client.create(); client.addFilter(new LoggingFilter(System.out));
	 * WebResource webResource = client.resource(restURL);
	 * 
	 * File f = (new File("C:\\Users\\madabas\\Documents\\srinitest.docx"));
	 * 
	 * 
	 * File uploadFile = new File("C:\\Users\\madabas\\Documents\\Tulips.jpg");
	 * FileInputStream fis = new FileInputStream(uploadFile); MultipartEntity entity
	 * = new MultipartEntity();
	 * 
	 * entity.addPart("file", new InputStreamBody(fis, f.getName()));
	 * 
	 * // MultipartFile file = null;
	 * 
	 * 
	 * 
	 * String response = webResource .type(MediaType.MULTIPART_FORM_DATA)
	 * 
	 * // .header("Content-Type",
	 * "multipart/form-data;boundary=gc0p4Jq0M2Yt08jU534c0p") .post(String.class,
	 * entity);
	 * 
	 * 
	 * System.out.println("--> "+ response); // return output;
	 * 
	 * }
	 * 
	 * public static void test1() throws IOException {
	 * 
	 * String restURL =
	 * "http://ustlvcmsp2338.prod:9082/fps/rest/prt/426/file/sriniiomax"; File file
	 * = (new File("C:\\Users\\madabas\\Documents\\srinitest.docx")); ClientConfig
	 * config = new DefaultClientConfig(); Client client = Client.create(config);
	 * WebResource webResource =
	 * client.resource(UriBuilder.fromUri(restURL).build());
	 * 
	 * // MultipartFile formData = null;
	 * 
	 * 
	 * DiskFileItem fileItem = new DiskFileItem("file",
	 * MediaType.MULTIPART_FORM_DATA, false, file.getName(), (int) file.length(),
	 * file.getParentFile()); fileItem.getOutputStream(); // MultipartFile
	 * multipartFile = new CommonsMultipartFile(fileItem);
	 * 
	 * 
	 * ClientResponse response =
	 * webResource.type("multipart/form-data;boundary=gc0p4Jq0M2Yt08jU534c0p").post(
	 * ClientResponse.class, multipartFile); System.out.println("Response " +
	 * response); System.out.println("Response " + response.getResponseDate());
	 * 
	 * }
	 * 
	 * public static void test( ) {
	 * 
	 * String restURL =
	 * "http://ustlvcmsp2338.prod:9082/fps/rest/prt/426/file/sriniiomax";
	 * 
	 * try { System.out.println("--> 1"); URL url = new URL(restURL);
	 * HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	 * conn.setDoOutput(true); conn.setRequestMethod("POST");
	 * conn.setRequestProperty("Content-Type", "multipart/form-data"); File file =
	 * (new File("C:\\Users\\madabas\\Documents\\srinitest.docx")); //init array
	 * with file length byte[] bytesArray = new byte[(int) file.length()];
	 * 
	 * FileInputStream fis = new FileInputStream(file); fis.read(bytesArray); //read
	 * file into bytes[] fis.close(); OutputStream os = conn.getOutputStream();
	 * os.write(bytesArray); os.flush(); conn.disconnect();
	 * 
	 * System.out.println("--> 2");
	 * 
	 * 
	 * } catch (MalformedURLException e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); } catch (ProtocolException e) { // TODO Auto-generated
	 * catch block e.printStackTrace(); } catch (FileNotFoundException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); } catch (IOException e) { //
	 * TODO Auto-generated catch block e.printStackTrace(); } }
	 */
	/*
	 * public static void test5() {
	 * 
	 * // the file we want to upload File inFile = new
	 * File("C:\\Users\\madabas\\Documents\\srinitest.docx"); // File inFile = new
	 * File("C:\\Users\\madabas\\Documents\\Tulips.jpg"); String restURL =
	 * "http://ustlvcmsp2338.prod:9082/fps/rest/prt/426/file/sriniiomax";
	 * FileInputStream fis = null; try { fis = new FileInputStream(inFile);
	 * DefaultHttpClient httpclient = new DefaultHttpClient(new BasicHttpParams());
	 * 
	 * // server back-end URL HttpPost httppost = new HttpPost(restURL);
	 * MultipartEntity entity = new MultipartEntity(); // set the file input stream
	 * and file name as arguments entity.addPart("file", new InputStreamBody(fis,
	 * inFile.getName())); httppost.setEntity(entity); // execute the request
	 * HttpResponse response = httpclient.execute(httppost); int statusCode =
	 * response.getStatusLine().getStatusCode(); HttpEntity responseEntity =
	 * response.getEntity(); String responseString =
	 * EntityUtils.toString(responseEntity, "UTF-8");
	 * 
	 * // System.out.println("[" + statusCode + "] " + responseString);
	 * 
	 * } catch (ClientProtocolException e) {
	 * System.err.println("Unable to make connection"); e.printStackTrace(); } catch
	 * (IOException e) { System.err.println("Unable to read file");
	 * e.printStackTrace(); } finally { try { if (fis != null) fis.close(); } catch
	 * (IOException e) {} }
	 * 
	 * }
	 */

	public static Response test6() {
		

//		String url = "http://ustlvcmsp2338:9082/fps/rest/prt/file/208";
//		ResponseBuilder responseBuilder = null;
//
//		if (!url.isEmpty()) {
//			// config needed for PoJo mapping
//			ClientConfig config = new DefaultClientConfig();
//			config.getClasses().add(JacksonJaxbJsonProvider.class);
//			config.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, Boolean.TRUE);
//
//			// call Web service to download the document
//			Client client = Client.create(config);
//			client.addFilter(new LoggingFilter(System.out)); // log the request
//			WebResource webResource = client.resource(url);
//			ClientResponse response = webResource.header("Content-Type", "application/json").get(ClientResponse.class);
//
//			if (response.getStatus() != 200) {
//				// close the response due to bad connection
//				response.close();
//				throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
//			} else {
//
//				System.out.println("Success");
//
//				responseBuilder = Response.ok(response.getEntityInputStream(), MediaType.APPLICATION_OCTET_STREAM);
//				responseBuilder.header("Content-Disposition",
//						response.getHeaders().get("Content-Disposition").toString());
//	             return responseBuilder.build();
//			}
//		}
		return null;
	}
}

/*
 * HttpURLConnection connection = (HttpURLConnection) url.openConnection();
 * connection.setRequestMethod("GET"); connection.setDoOutput(true);
 * 
 * // convert the response to an Input Stream is = connection.getInputStream();
 * 
 * // logger.debug("Response Code:  " + connection.getResponseCode()); if
 * (connection.getResponseCode() == 200) {
 * 
 * int length = 10240;
 * 
 * // create a byte array with estimated length of the file byte[] bytes = new
 * byte[length];
 * 
 * 
 * String fileName = ""; String disposition =
 * connection.getHeaderField("Content-Disposition"); String contentType =
 * connection.getContentType(); int contentLength =
 * connection.getContentLength();
 * 
 * if (disposition != null) { // extracts file name from header field int index
 * = disposition.indexOf("filename="); if (index > 0) { fileName =
 * disposition.substring(index + 10, disposition.length() ); } } else { //
 * extracts file name from URL // fileName =
 * fileURL.substring(fileURL.lastIndexOf("/") + 1, // fileURL.length()); }
 * 
 * System.out.println("Content-Type = " + contentType);
 * System.out.println("Content-Disposition = " + disposition);
 * System.out.println("Content-Length = " + contentLength);
 * System.out.println("fileName = " + fileName);
 * 
 * System.out.println("Success");
 * 
 * } else { // invalid response from server received
 * 
 * }
 * 
 * } catch (IOException ex) { System.out.println("Error: " + ex);
 * 
 * }
 */
