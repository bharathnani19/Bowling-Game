package com.cms.fps2.wrappers;

/**
 * @author madabas
 *
 */
public class AffectedSystemsData {
	

    	
	private String prblmAfctdSysId;
	private String prodnPrblmRptId;
	private String afctdSysCd;
	private String audtInsrtId;
	private String audtInsrtTs;
	private String audtUpdtId;
	private String audtUpdtTs;
	public String getPrblmAfctdSysId() {
		return prblmAfctdSysId;
	}
	public void setPrblmAfctdSysId(String prblmAfctdSysId) {
		this.prblmAfctdSysId = prblmAfctdSysId;
	}
	public String getProdnPrblmRptId() {
		return prodnPrblmRptId;
	}
	public void setProdnPrblmRptId(String prodnPrblmRptId) {
		this.prodnPrblmRptId = prodnPrblmRptId;
	}
	public String getAfctdSysCd() {
		return afctdSysCd;
	}
	public void setAfctdSysCd(String afctdSysCd) {
		this.afctdSysCd = afctdSysCd;
	}
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	public String getAudtInsrtTs() {
		return audtInsrtTs;
	}
	public void setAudtInsrtTs(String audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	public String getAudtUpdtId() {
		return audtUpdtId;
	}
	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	public String getAudtUpdtTs() {
		return audtUpdtTs;
	}
	public void setAudtUpdtTs(String audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
	
	
	

}
