package com.cms.fps2.wrappers;



public class SessionInfoReqWrapper {
	private String tokenId;
	
	//constructor
	SessionInfoReqWrapper(){}
	
	//tokenId
	public String getTokenId() {
		return tokenId;
	}
	
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
		
}
