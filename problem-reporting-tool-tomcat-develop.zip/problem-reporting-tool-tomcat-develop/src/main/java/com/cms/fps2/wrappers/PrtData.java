package com.cms.fps2.wrappers;

/**
 * @author madabas
 *
 */
public class PrtData {
	private String prodnPrblmRptId;
	private String rptTitleTxt;
	private String prblmSbmtdDt;
	private String fpsEditNum;
	private String fpsEditName;
	private String dfctCtgryCd;
	private String clmCntRngCd;
	private String prblmDesc;
	private String prblmPrrtyCd;;
	private String macJrsdctnCd;
	private String macInfoTxt;
	private String prblmStusDesc;
	private String prblmFixCreqNum;
	private String prblmFixdDt;;
	private String issCtgryCd;
	private String stusCd;
	private String prblmRptDocNum;
	private String modelCntrctr;
	private String fpsEditOwner;
	private String fpsRltdPrblms[];
	private CmsCreqs fpsPrblmCmsCreqs[];
	private AffectedSystemsData fpsPrblmAfctdSys[];
	private String actvInd;
	private String loggedInUserId;
	private String audtInsrtId;

	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	/*	private FpsFileStore fpsFilStore[];
		
	
	public FpsFileStore[] getFpsFilStore() {
		return fpsFilStore;
	}
	public void setFpsFilStore(FpsFileStore[] fpsFilStore) {
		this.fpsFilStore = fpsFilStore;
	}*/
	public String getLoggedInUserId() {
		return loggedInUserId;
	}
	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}
	public String getActvInd() {
		return actvInd;
	}
	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}
	public String[] getFpsRltdPrblms() {
		return fpsRltdPrblms;
	}
	public void setFpsRltdPrblms(String[] fpsRltdPrblms) {
		this.fpsRltdPrblms = fpsRltdPrblms;
	}
	public CmsCreqs[] getFpsPrblmCmsCreqs() {
		return fpsPrblmCmsCreqs;
	}
	public void setFpsPrblmCmsCreqs(CmsCreqs[] fpsPrblmCmsCreqs) {
		this.fpsPrblmCmsCreqs = fpsPrblmCmsCreqs;
	}
	public AffectedSystemsData[] getFpsPrblmAfctdSys() {
		return fpsPrblmAfctdSys;
	}
	public void setFpsPrblmAfctdSys(AffectedSystemsData[] fpsPrblmAfctdSys) {
		this.fpsPrblmAfctdSys = fpsPrblmAfctdSys;
	}
	public String getProdnPrblmRptId() {
		return prodnPrblmRptId;
	}
	public void setProdnPrblmRptId(String prodnPrblmRptId) {
		this.prodnPrblmRptId = prodnPrblmRptId;
	}
	public String getRptTitleTxt() {
		return rptTitleTxt;
	}
	public void setRptTitleTxt(String rptTitleTxt) {
		this.rptTitleTxt = rptTitleTxt;
	}
	public String getPrblmSbmtdDt() {
		return prblmSbmtdDt;
	}
	public void setPrblmSbmtdDt(String prblmSbmtdDt) {
		this.prblmSbmtdDt = prblmSbmtdDt;
	}
	public String getFpsEditNum() {
		return fpsEditNum;
	}
	public void setFpsEditNum(String fpsEditNum) {
		this.fpsEditNum = fpsEditNum;
	}
	public String getFpsEditName() {
		return fpsEditName;
	}
	public void setFpsEditName(String fpsEditName) {
		this.fpsEditName = fpsEditName;
	}
	public String getDfctCtgryCd() {
		return dfctCtgryCd;
	}
	public void setDfctCtgryCd(String dfctCtgryCd) {
		this.dfctCtgryCd = dfctCtgryCd;
	}
	public String getClmCntRngCd() {
		return clmCntRngCd;
	}
	public void setClmCntRngCd(String clmCntRngCd) {
		this.clmCntRngCd = clmCntRngCd;
	}
	public String getPrblmDesc() {
		return prblmDesc;
	}
	public void setPrblmDesc(String prblmDesc) {
		this.prblmDesc = prblmDesc;
	}
	public String getPrblmPrrtyCd() {
		return prblmPrrtyCd;
	}
	public void setPrblmPrrtyCd(String prblmPrrtyCd) {
		this.prblmPrrtyCd = prblmPrrtyCd;
	}
	public String getMacJrsdctnCd() {
		return macJrsdctnCd;
	}
	public void setMacJrsdctnCd(String macJrsdctnCd) {
		this.macJrsdctnCd = macJrsdctnCd;
	}
	public String getMacInfoTxt() {
		return macInfoTxt;
	}
	public void setMacInfoTxt(String macInfoTxt) {
		this.macInfoTxt = macInfoTxt;
	}
	public String getPrblmStusDesc() {
		return prblmStusDesc;
	}
	public void setPrblmStusDesc(String prblmStusDesc) {
		this.prblmStusDesc = prblmStusDesc;
	}
	public String getPrblmFixCreqNum() {
		return prblmFixCreqNum;
	}
	public void setPrblmFixCreqNum(String prblmFixCreqNum) {
		this.prblmFixCreqNum = prblmFixCreqNum;
	}
	public String getPrblmFixdDt() {
		return prblmFixdDt;
	}
	public void setPrblmFixdDt(String prblmFixdDt) {
		this.prblmFixdDt = prblmFixdDt;
	}
	public String getIssCtgryCd() {
		return issCtgryCd;
	}
	public void setIssCtgryCd(String issCtgryCd) {
		this.issCtgryCd = issCtgryCd;
	}
	public String getStusCd() {
		return stusCd;
	}
	public void setStusCd(String stusCd) {
		this.stusCd = stusCd;
	}
	public String getPrblmRptDocNum() {
		return prblmRptDocNum;
	}
	public void setPrblmRptDocNum(String prblmRptDocNum) {
		this.prblmRptDocNum = prblmRptDocNum;
	}
	public String getModelCntrctr() {
		return modelCntrctr;
	}
	public void setModelCntrctr(String modelCntrctr) {
		this.modelCntrctr = modelCntrctr;
	}
	public String getFpsEditOwner() {
		return fpsEditOwner;
	}
	public void setFpsEditOwner(String fpsEditOwner) {
		this.fpsEditOwner = fpsEditOwner;
	}
	
	

}
