package com.cms.fps2.wrappers;

public class Macs {
	
	private String macJrsdctnCd;
	private String macJrsdctnDesc;
	private String actvInd	;
	private String loggedInUserId;
	
	
	public String getLoggedInUserId() {
		return loggedInUserId;
	}
	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}
	public String getMacJrsdctnCd() {
		return macJrsdctnCd;
	}
	public void setMacJrsdctnCd(String macJrsdctnCd) {
		this.macJrsdctnCd = macJrsdctnCd;
	}
	public String getMacJrsdctnDesc() {
		return macJrsdctnDesc;
	}
	public void setMacJrsdctnDesc(String macJrsdctnDesc) {
		this.macJrsdctnDesc = macJrsdctnDesc;
	}
	public String getActvInd() {
		return actvInd;
	}
	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}
	
	

}
