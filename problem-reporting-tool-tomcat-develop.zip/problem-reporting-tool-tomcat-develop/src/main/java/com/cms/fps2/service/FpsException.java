package com.cms.fps2.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.Provider;

@Provider
public class FpsException extends Throwable implements jakarta.ws.rs.ext.ExceptionMapper<Throwable> {
	private static Logger logger = LogManager.getLogger(); // Example log4j2.

    public FpsException() {
        super("No File found with given name !!");
    }

    public FpsException(String string) {
        super(string);
    }

    @Override
    public Response toResponse(Throwable exception) {
    	logger.error("error", exception);
        return Response.status(500).entity(exception.getMessage())
                .type(MediaType.TEXT_PLAIN).build();
    }

	
}