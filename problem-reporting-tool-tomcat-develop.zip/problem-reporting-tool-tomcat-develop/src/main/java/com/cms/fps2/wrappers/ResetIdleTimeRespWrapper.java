package com.cms.fps2.wrappers;

public class ResetIdleTimeRespWrapper {
	private String valid;
	private String realm;
	private String uid;
	private String sessionUid;
	
	//constructor
	public ResetIdleTimeRespWrapper(){}
	
	//valid
	public String getValid() {
		return valid;
	}
	
	public void setValid(String valid) {
		this.valid = valid;
	}
	
	//realm
	public String getRealm() {
		return realm;
	}
	
	public void setRealm(String realm) {
		this.realm = realm;
	}
	
	//uid
	public String getUid() {
		return uid;
	}
	
	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getSessionUid() {
		return sessionUid;
	}

	public void setSessionUid(String sessionUid) {
		this.sessionUid = sessionUid;
	}
	
}
