package com.cms.fps2.wrappers;

import java.util.ArrayList;
import java.util.List;

public class CurrentUserAccessWrapper {

	private String email;
	private String name;
	private String preferredUsername;
	private String firstName;
	private String lastName;
	private List<String> groups = new ArrayList<String>();
	private List<String> roles = new ArrayList<String>();
	private List<String> zones = new ArrayList<String>();
	private List<String> userAttributes = new ArrayList<String>();
	private boolean prtRead;
	private boolean prtWrite;
	private boolean prtAdmin;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPreferredUsername() {
		return preferredUsername;
	}

	public void setPreferredUsername(String preferredUsername) {
		this.preferredUsername = preferredUsername;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public List<String> getGroups() {
		return groups;
	}

	public void setGroups(List<String> groups) {
		this.groups = groups;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public List<String> getZones() {
		return zones;
	}

	public void setZones(List<String> zones) {
		this.zones = zones;
	}

	public List<String> getUserAttributes() {
		return userAttributes;
	}

	public void setUserAttributes(List<String> userAttributes) {
		this.userAttributes = userAttributes;
	}

	public boolean isPrtRead() {
		return prtRead;
	}

	public void setPrtRead(boolean prtRead) {
		this.prtRead = prtRead;
	}

	public boolean isPrtWrite() {
		return prtWrite;
	}

	public void setPrtWrite(boolean prtWrite) {
		this.prtWrite = prtWrite;
	}

	public boolean isPrtAdmin() {
		return prtAdmin;
	}

	public void setPrtAdmin(boolean prtAdmin) {
		this.prtAdmin = prtAdmin;
	}
}
