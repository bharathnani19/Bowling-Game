package com.cms.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;


import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509ExtendedTrustManager;

import org.apache.http.Header;
import org.apache.http.HeaderElement;
import org.apache.http.HeaderElementIterator;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.BasicHttpClientConnectionManager;
import org.apache.http.message.BasicHeaderElementIterator;
import org.apache.http.protocol.HTTP;
import org.apache.http.protocol.HttpContext;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.SslConfigurator;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.logging.LoggingFeature;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

public class FASScanner {
	final static Logger logger = LogManager.getLogger(FASScanner.class);

	public int analyzeFileStreamForVirusOld(ByteArrayOutputStream baos, String fileName) throws Exception {

		String fasUrl = getProperty("fasurl") + "/api/Scan";
		logger.debug("FAS URL-" + fasUrl);

		TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
			@Override
			public boolean isTrusted(X509Certificate[] x509Certificates, String authType) throws CertificateException {
				return true;
			}
		};
		SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);

		Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
				.register("https", sslsf).register("http", new PlainConnectionSocketFactory()).build();

		BasicHttpClientConnectionManager connectionManager = new BasicHttpClientConnectionManager(
				socketFactoryRegistry);
		CloseableHttpClient client = HttpClients.custom().setSSLSocketFactory(sslsf)
				 .setKeepAliveStrategy(getKeepalive())
				.setConnectionManager(connectionManager).build();
		HttpPost httpPost = new HttpPost(fasUrl);

		ByteArrayEntity entity = new ByteArrayEntity(baos.toByteArray());
		httpPost.setEntity(entity);
		logger.debug("baos size==>" + baos.size());

		httpPost.setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + getAccessToken());
		httpPost.setHeader(HttpHeaders.CONTENT_TYPE, "application/octet-stream");
		httpPost.setHeader("Prefer", "response-async");
		HttpResponse response = client.execute(httpPost);
		HttpEntity responseEntity = response.getEntity();

		String responseString = EntityUtils.toString(responseEntity, "UTF-8");
		String ret = "No virus found";
		int status_code = response.getStatusLine().getStatusCode();

		logger.debug("******************** File upload response Code from  FAS Server******************** ");
		logger.debug("[" + response.getStatusLine().getStatusCode() + "] ");
		logger.debug("[  Actual response from FAS Server for file upload - " + responseString + "   ] ");
		logger.debug("******************** ******************** ******************** ");

		if (status_code != 200 && status_code != 201) {
			ret = " Did not return successful status code.";
			logger.debug("[ Status code " + status_code + ret + "] ");
			throw new RuntimeException("Failed @ FASScanner:analyzeFileStreamForVirus()" + ": Code: " + status_code
					+ ": Message: " + responseString);
		}

		JSONParser parser = new JSONParser();
		JSONObject responseJson = (JSONObject) parser.parse(responseString);
		Object results = responseJson.get("result");
		logger.debug("******************** File upload response String from  FAS Server******************** ");
		logger.debug("[" + responseString + "] ");
		logger.debug("******************** ******************** ******************** ");

		if (results != null) {
			if ("Infected".equalsIgnoreCase((String) results)) {
				status_code = 500;
				ret = "Virus found";
				logger.debug("[" + ret + "] ");
			}
		}

		client.close();
		return status_code;

	}
	public int analyzeFileStreamForVirus(ByteArrayOutputStream baos, String fileName) throws Exception {

		String fasUrl = getProperty("fasurl");
		logger.debug("FAS URL-" + fasUrl);

		
		
		Client client = buildClientConfig();
		WebTarget webTarget = client.target(String.valueOf(fasUrl) + "/api/Scan");

		logger.debug("baos size==>" + baos.size());
		Response response = webTarget.request().accept("application/json")
				.header("Content-Type", "application/octet-stream")
				.header(HttpHeaders.AUTHORIZATION, "Bearer " + getAccessToken())
				.header("Prefer", "response-async")
				.post(Entity.entity(new ByteArrayEntity(baos.toByteArray()), MediaType.APPLICATION_JSON));
		

		

	
		String responseString = response.readEntity(String.class);

		String ret = "No virus found";
		int status_code = response.getStatus();

		logger.debug("******************** File upload response Code from  FAS Server******************** ");
		logger.debug("[" + response.getStatus() + "] ");
		logger.debug("[  Actual response from FAS Server for file upload - " + responseString + "   ] ");
		logger.debug("******************** ******************** ******************** ");

		if (status_code != 200 && status_code != 201) {
			ret = " Did not return successful status code.";
			logger.debug("[ Status code " + status_code + ret + "] ");
			throw new RuntimeException("Failed @ FASScanner:analyzeFileStreamForVirus()" + ": Code: " + status_code
					+ ": Message: " + responseString);
		}

		JSONParser parser = new JSONParser();
		JSONObject responseJson = (JSONObject) parser.parse(responseString);
		Object results = responseJson.get("result");
		logger.debug("******************** File upload response String from  FAS Server******************** ");
		logger.debug("[" + responseString + "] ");
		logger.debug("******************** ******************** ******************** ");

		if (results != null) {
			if ("Infected".equalsIgnoreCase((String) results)) {
				status_code = 500;
				ret = "Virus found";
				logger.debug("[" + ret + "] ");
			}
		}

		client.close();
		return status_code;

	}

	private String getAccessTokenOld() throws Exception {
		TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
			@Override
			public boolean isTrusted(X509Certificate[] x509Certificates, String authType) throws CertificateException {
				return true;
			}
		};
		SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);

		Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
				.register("https", sslsf).register("http", new PlainConnectionSocketFactory()).build();

		BasicHttpClientConnectionManager connectionManager = new BasicHttpClientConnectionManager(
				socketFactoryRegistry);
		CloseableHttpClient client = HttpClients.custom().setSSLSocketFactory(sslsf)
				 .setKeepAliveStrategy(getKeepalive())
				.setConnectionManager(connectionManager).build();
		
		HttpPost httpPost = new HttpPost(getProperty("fasurl") + "/api/Token");

		JSONObject json = new JSONObject();

		json.put("username", getProperty("fasuser"));
		json.put("password", getProperty("faskey"));

		String access_token = "";
		StringEntity entity = new StringEntity(json.toJSONString(), ContentType.APPLICATION_JSON);

		httpPost.setEntity(entity);
		httpPost.setHeader("Accept", "application/json");
		httpPost.setHeader("Content-Type", "application/json");

		CloseableHttpResponse response = client.execute(httpPost);
		HttpEntity responseEntity = response.getEntity();
		String responseString = EntityUtils.toString(responseEntity, "UTF-8");

		logger.debug("[  Actual response from FAS Server for authentication - " + responseString + "   ] ");

		int status_code = response.getStatusLine().getStatusCode();
		logger.debug("******************** FAS Server Authentication ******************** ");
		logger.debug("[" + status_code + "] ");
		logger.debug("******************** ******************** ******************** ");

		if (status_code != 200 && status_code != 201) {
			// return "Did not return successful status code.";
			throw new RuntimeException("Failed @ FASScanner:getAccessToken():FAS Authentication  user : "
					+ getProperty("fasuser") + ": Code: " + status_code + ": Message: " + responseString);
		}

		JSONParser parser = new JSONParser();
		JSONObject responseJson = (JSONObject) parser.parse(responseString);
		access_token = responseJson.get("accessToken").toString();

		logger.debug("[ access_token  - " + access_token + "] ");

		client.close();
		return access_token;
	}
	private String getAccessToken() throws Exception {
	

		Client client = buildClientConfig();
		WebTarget webTarget = client.target(getProperty("fasurl") + "/api/Token");
		
		String access_token = "";
		Map<String,Object> postBody = new HashMap<String,Object>();
		postBody.put("username",  getProperty("fasuser"));
		postBody.put("password",  getProperty("faskey"));
		
		
		Response response = webTarget.request().accept("application/json")
				.header("Content-Type", "application/json")
//				.header(HttpHeaders.AUTHORIZATION, "Bearer " + getAccessToken())
				.header("Accept", "application/json")
				.post(Entity.entity(postBody, MediaType.APPLICATION_JSON));
		String responseString = response.readEntity(String.class);

	
		logger.debug("[  Actual response from FAS Server for authentication - " + responseString + "   ] ");

		int status_code = response.getStatus();
		logger.debug("******************** FAS Server Authentication ******************** ");
		logger.debug("[" + status_code + "] ");
		logger.debug("******************** ******************** ******************** ");

		if (status_code != 200 && status_code != 201) {
			// return "Did not return successful status code.";
			throw new RuntimeException("Failed @ FASScanner:getAccessToken():FAS Authentication  user : "
					+ getProperty("fasuser") + ": Code: " + status_code + ": Message: " + responseString);
		}

		JSONParser parser = new JSONParser();
		JSONObject responseJson = (JSONObject) parser.parse(responseString);
		access_token = responseJson.get("accessToken").toString();

		logger.debug("[ access_token  - " + access_token + "] ");

		client.close();
		return access_token;
	}

	private String getProperty(String key) throws IOException {
		PropertyFileHandler pfh = new PropertyFileHandler();
		return pfh.getProperty(key);
	}

	private ConnectionKeepAliveStrategy getKeepalive() {
		return new ConnectionKeepAliveStrategy() {
			@Override
			public long getKeepAliveDuration(HttpResponse response, HttpContext context) {
				HeaderElementIterator it = new BasicHeaderElementIterator(
						response.headerIterator(HTTP.CONN_KEEP_ALIVE));
				while (it.hasNext()) {
					HeaderElement he = it.nextElement();
					String param = he.getName();
					String value = he.getValue();
					if (value != null && param.equalsIgnoreCase("timeout")) {
						return Long.parseLong(value) * 1000;
					}
				}
				return 5 * 1000;
			}
		};
	}
	private void printRequest(HttpPost post) {
		for (Header h : post.getAllHeaders()) {
			logger.debug(h.getName() + "="+h.getValue());
		}
		
	}
	
	private Client buildClientConfig() {
		ClientConfig clientConfig = new ClientConfig();
		clientConfig.property(LoggingFeature.LOGGING_FEATURE_VERBOSITY_CLIENT, LoggingFeature.Verbosity.PAYLOAD_ANY);
		clientConfig.property(ClientProperties.CONNECT_TIMEOUT, 360000);
		clientConfig.property(ClientProperties.READ_TIMEOUT, 360000);
	
		SSLContext sslcontext;
		try {
			sslcontext = SSLContext.getInstance("TLSv1.3");
			SslConfigurator sslConfig = SslConfigurator.newInstance();
				   
			sslConfig.securityProtocol("TLSv1.3");
			sslcontext.init(null, new TrustManager[]  { new X509ExtendedTrustManager () {
				@Override
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				@Override
				public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}

				@Override
				public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}

				@Override
				public void checkClientTrusted(X509Certificate[] chain, String authType, Socket socket)
						throws CertificateException {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void checkServerTrusted(X509Certificate[] chain, String authType, Socket socket)
						throws CertificateException {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void checkClientTrusted(X509Certificate[] chain, String authType, SSLEngine engine)
						throws CertificateException {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void checkServerTrusted(X509Certificate[] chain, String authType, SSLEngine engine)
						throws CertificateException {
					// TODO Auto-generated method stub
					
				}
			
			} }, new java.security.SecureRandom());

			Client client = ClientBuilder.newBuilder().withConfig(clientConfig)
					.sslContext(sslcontext)
					.hostnameVerifier((s1, s2) -> true)
					 .connectTimeout(6, TimeUnit.MINUTES)
				        .readTimeout(6, TimeUnit.MINUTES)
					.build();
			return client;
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			logger.error("NoSuchAlgorithmException", e);
			
		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			logger.error("KeyManagementException", e);
		}

		return null;

	}
	
}
