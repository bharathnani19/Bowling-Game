package com.cms.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;




public class LoadPropertiesFileServlet extends HttpServlet{
	
	private static final long serialVersionUID = 1L;
	final Logger logger = LogManager.getLogger(LoadPropertiesFileServlet.class);
	
	//constructor
	public LoadPropertiesFileServlet () {
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//In a live project, it is suggested that you read environment value from server property file 
		//String environment = System.getProperty("environment");
		
		//Read the properties file		
		Properties properties = new Properties();
		
		String propFileName = "app.properties";
		
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
		
		if (inputStream != null) {
			properties.load(inputStream);
			String serviceURL = properties.getProperty("serviceURL");
			
			if (serviceURL != null) {
				logger.debug("serviceURL property = " + serviceURL);				
				response.getWriter().write(serviceURL);
			}
			
			inputStream.close();
		} else {
			throw new FileNotFoundException("Property file " + propFileName + " not found in the classpath.");
		}
		
	}
	
	protected void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
