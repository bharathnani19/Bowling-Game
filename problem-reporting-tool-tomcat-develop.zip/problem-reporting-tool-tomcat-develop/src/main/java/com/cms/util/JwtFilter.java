package com.cms.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nimbusds.jwt.proc.BadJWTException;
import com.nimbusds.oauth2.sdk.ParseException;
import com.okta.jwt.JoseException;
import com.okta.jwt.Jwt;
import com.okta.jwt.JwtHelper;
import com.okta.jwt.JwtVerifier;

@WebFilter(filterName = "jwtFilter", urlPatterns = "/rest/*")
public class JwtFilter implements Filter {
	private JwtVerifier jwtVerifier;
	private static final Logger logger = Logger.getLogger(JwtFilter.class.getName());


	@Override
	public void init(FilterConfig filterConfig) {
		String issuer = "";
		String client = "";
		try {
			Properties properties = new Properties();
			String propFileName = "app.properties";
			InputStream inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
			if (inputStream != null) {
				properties.load(inputStream);
				issuer = properties.getProperty("issuerUrl");
				client = properties.getProperty("clientId");
				inputStream.close();
			} else {
				throw new FileNotFoundException("Property file " + propFileName + " not found in the classpath.");
			}

			jwtVerifier = new JwtHelper().setIssuerUrl(issuer)
					.setClientId(client).setAudience("fraudps").build();
			logger.warning( "Configuring JWT Verifier success!");
		} catch (IOException e) {
			logger.log(Level.SEVERE, "Configuring JWT Verifier failed!", e);
			
		} catch (ParseException e) {
			logger.log(Level.SEVERE, "Configuring JWT Verifier failed!", e);
			
			
		}
	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;

		// Get access token from authorization header
		String authHeader = request.getHeader("authorization");
		if (authHeader == null) {
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access denied.");
			logger.warning( "Authorization header is null");
			return;
		} else {
			String accessToken = authHeader.substring(authHeader.indexOf("Bearer ") + 7);
			try {
				if (jwtVerifier == null) {
					logger.warning( "jwtVerifier null, reconfiguring");
					init(null);
				}
				Jwt jwt = jwtVerifier.decodeAccessToken(accessToken);

			} catch (JoseException e) {
				if (e.getCause() instanceof BadJWTException) {
					BadJWTException be = (BadJWTException) e.getCause();
					if (!"Expired JWT".equals(be.getMessage())) {
						logger.log(Level.SEVERE, "Error parsing token", e);
						response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access denied.");
						return;
					}
				}else {
					response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access denied.");
					return;
				}
			
			}
		}

		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {
	}
	
	public static void main(String[] args) throws ParseException, IOException {
		JwtVerifier jwtVerifier = new JwtHelper().setIssuerUrl("https://impl.idp.idm.cms.gov/oauth2/ausc24l2w5nTQczdY297")
				.setClientId("0oac24ih3eJjmcmlk297").setAudience("fraudps").build();
		String authHeader = "BearereyJraWQiOiJ4ekFxeGhjR09RckpjNWItQ3E2ckFNdDI2d1JmZ3BQQlBFdmNTaUx5dmZzIiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULmE0SHF0T2YyU1drTV9PbVVWREwyRWNSS0Q0RmlSMEpxUHQyOVM5cjZ2eVkiLCJpc3MiOiJodHRwczovL2ltcGwuaWRwLmlkbS5jbXMuZ292L29hdXRoMi9hdXNjMjRsMnc1blRRY3pkWTI5NyIsImF1ZCI6ImZyYXVkcHMiLCJpYXQiOjE2NjU1OTYxMDAsImV4cCI6MTY2NTU5NzkwMCwiY2lkIjoiMG9hYzI0aWgzZUpqbWNtbGsyOTciLCJ1aWQiOiIwMHVjanJ1c2ZzT3hJREtjeDI5NiIsInNjcCI6WyJlbWFpbCIsInByb2ZpbGUiLCJvcGVuaWQiXSwiYXV0aF90aW1lIjoxNjY1NTk2MDg2LCJzdWIiOiJ0aG9mZm1hbiJ9.fn19DIKwkNXWLOHhQUi3OTb_J9QLx6Wm6gE5a0-92sPm_MGiktx-v4_xbgiW5pZPbgWYRRBAuGSBv1aaf4fUGUDtWjC8eyPLlrEs_Q5rXc6RW08w9PZ2UMiITJnEnz8jpc3KMlqg1xz1YQkcHDWueqck-YOI1Po7TLgs94NcKHgDRPSnbxFYNsWz63YJcI0OxYL9LGURktdhUoqPWqD4Svj9G9FAE_pfGa2MWGlixADurxixEgOXfJZRCozkqEL7GPQeGlZU4dnTS_qR-KbsKHiDhyAf0FxqY0Uewmfv-n6gOmlkywaNC-gHyandmg-fOW6GbIvRVTN0ad-XUfYsSw";
		String accessToken = authHeader.substring(authHeader.indexOf("Bearer ") + 7);
		try {
			Jwt jwt = jwtVerifier.decodeAccessToken(accessToken);
			System.out.println(jwt.getIssuedAt());
		} catch (JoseException e) {
			e.printStackTrace();
			
			;
		}
	}
}
