(function (window) {
  window.__env = window.__env || {};
  window.__env.env="PROD";
  window.__env.oktaConfig = {
			
			issuer:	'https://idm.cms.gov/oauth2/auscoyy5hpZupmXGB297',
			clientId: '0oacoyv2pq9YMwnYe297',
			redirectUri: 'https://cloud.fpsportal.cmsnet/ProblemReportingTool/',
			postLogoutRedirectUri: 'https://cloud.fpsportal.cmsnet/ProblemReportingTool/',

			scopes: ['openid', 'profile', 'email'],
			state: 'fps-auth-state' // used to validate the OAuth response		   
		}
;
  
  window.__env.tableauRoot ="https://cloud.fpsreports.cmsnet";
  
  window.__env.lmsUrl  = "https://cmsifislearning.csodfed.com";
  window.__env.editsandModelsLifecycleUrl = "https://cloud.fpsportal.cmsnet/eml/";
 
}(this));