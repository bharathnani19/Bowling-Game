(function (window) {
  window.__env = window.__env || {};
  window.__env.env = "VAL";
    window.__env.oktaConfig =  {
			// CMS IMPL Okta
			issuer:	'https://impl.idp.idm.cms.gov/oauth2/ausc24l2w5nTQczdY297',
			clientId: '0oac24ih3eJjmcmlk297',
			redirectUri: 'https://cloud.fpsportal.cms.cmsval/ProblemReportingTool/',
			postLogoutRedirectUri: 'https://cloud.fpsportal.cms.cmsval/ProblemReportingTool/',

			scopes: ['openid', 'profile', 'email'],
			state: 'fps-auth-state' // used to validate the OAuth response		   
		}
		
;
  
  

  	window.__env.tableauRoot ="https://cloud.fpsreports.cms.cmsval/t/Val/projects";
  
    window.__env.lmsUrl = "https://cmsifislearning.csodfed.com";
	window.__env.editsandModelsLifecycleUrl = "https://cloud.fpsportal.cms.cmsval/eml/";


}(this));