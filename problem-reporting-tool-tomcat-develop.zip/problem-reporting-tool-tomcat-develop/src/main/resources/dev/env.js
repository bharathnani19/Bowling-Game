(function (window) {
  window.__env = window.__env || {};
  window.__env.env = "DEV";
  window.__env.oktaConfig = {
			
			// CMS Test Okta
			issuer:	'https://test.idp.idm.cms.gov/oauth2/ausbbjql1yRIpm9yt297',
			clientId: '0oabbjqacsMm5sZO2297',
		    //redirectUri: 'http://localhost:9080/FPS2UnifiedPortal/',
		    //postLogoutRedirectUri: 'http://localhost:9080/FPS2UnifiedPortal/',
			redirectUri: 'https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com/ProblemReportingTool/',
			postLogoutRedirectUri: 'https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com/ProblemReportingTool/',
		    scopes: ['openid', 'profile', 'email'],
		    state: 'fps-auth-state', // used to validate the OAuth response		    
//		    tokenManager: {
//		    	autoRenew: false,
//				autoRemove: false
//		    },
			
			// set responseType and pkce to use authorization code flow
		    // responseType: 'code',
		    // pkce: false,
		    devMode: true
		}
;
  
  


  window.__env.tableauRoot = "http://dtab1.awscloud.cms.local/#/signin?redirect=%2Fsite%2FVal/";
  window.__env.lmsUrl = "https://cmsifislearning.csodfed.com";
  window.__env.editsandModelsLifecycleUrl = "https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com/eml/";

  
  
  
  

}(this));