(function (window) {
  window.__env = window.__env || {};
  window.__env.env = "MODELDEV";
   window.__env.oktaConfig =   {
			// CMS Test Okta
			issuer:	'https://impl.idp.idm.cms.gov/oauth2/ausc24l2w5nTQczdY297',
			clientId: '0oac24ih3eJjmcmlk297',
			redirectUri: 'https://cloud.fpsreportsmodeldev.cms.cmsval/ProblemReportingTool/',
			postLogoutRedirectUri: 'https://cloud.fpsreportsmodeldev.cms.cmsval/ProblemReportingTool/',

			scopes: ['openid', 'profile', 'email'],
			state: 'fps-auth-state' // used to validate the OAuth response		   
		}
		
;
  


  

  window.__env.tableauRoot ="https://cloud.fpsreportsmodeldev.cms.cmsval/t/MTE/projects";
  
  
  window.__env.lmsUrl = "https://cmsifislearning.csodfed.com";
}(this));