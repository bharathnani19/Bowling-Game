(function (window) {
  window.__env = window.__env || {};
  window.__env.env="VAL2";
  window.__env.oktaConfig =  {
			// CMS IMPL Okta
			issuer:	'https://impl.idp.idm.cms.gov/oauth2/ausc24l2w5nTQczdY297',
			clientId: '0oac24ih3eJjmcmlk297',
			redirectUri: 'https://cloud.fpsportalval2.cms.cmsval/ProblemReportingTool/',
			postLogoutRedirectUri: 'https://cloud.fpsportalval2.cms.cmsval/ProblemReportingTool/',

			scopes: ['openid', 'profile', 'email'],
			state: 'fps-auth-state' // used to validate the OAuth response		   
		}
		
;
  
    window.__env.tableauRoot ="https://cloud.fpsreportsval2.cms.cmsvalt/Val/projects";
    
   window.__env.lmsUrl = "https://cmsifislearning.csodfed.com";


}(this));