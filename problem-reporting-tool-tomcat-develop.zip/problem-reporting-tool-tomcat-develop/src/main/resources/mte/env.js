(function (window) {
  window.__env = window.__env || {};
  window.__env.env="MTE";
   window.__env.oktaConfig =  {
			// CMS IMPL Okta
			issuer:	'https://impl.idp.idm.cms.gov/oauth2/ausc24l2w5nTQczdY297',
			clientId: '0oac24ih3eJjmcmlk297',
			redirectUri: 'https://cloud.fpsportalmte.cms.cmsval/ProblemReportingTool/',
			postLogoutRedirectUri: 'https://cloud.fpsportalmte.cms.cmsval/ProblemReportingTool/',
			scopes: ['openid', 'profile', 'email'],
			state: 'fps-auth-state' // used to validate the OAuth response		   
		}
		
;
  

  

  window.__env.tableauRoot ="https://cloud.fpsreportsmte.cms.cmsval/t/MTE/projects";
   
  window.__env.lmsUrl = "https://cmsifislearning.csodfed.com";
  window.__env.editsandModelsLifecycleUrl = "https://cloud.fpsportalmte.cms.cmsval/eml/";


}(this));