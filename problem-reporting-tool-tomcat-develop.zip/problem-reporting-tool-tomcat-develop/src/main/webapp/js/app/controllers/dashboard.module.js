var appList = angular.module('dashboard.module', ['ngRoute', 'ngSanitize']);

appList.controller('dashboardCtrl', [
	'$scope',
	'$http',
	'$location',
	'$timeout',
	'$cookies',
	'utilFactory',
	'utilService',
	'utilConstants',
	'$rootScope',
	function ($scope, $http, $location, $timeout, $cookies, utilFactory, utilService, utilConstants, $rootScope) {


		console.log('Inside the dashboard controller.');
		// create a new okta auth instance from the util method
		var authClient = utilService.getOktaAuth();
		// console.log('Inside the navController. AuthClient = ' + authClient);

		authClient.tokenManager.getTokens()
			.then(({ accessToken, idToken }) => {
				// handle accessToken and idToken
				if (accessToken) {
					// user has valid access token, so show page contents
					showPageContents(idToken);
				} else {
					// no token and not logged-in, so redirect to login screen               
					authClient.token.getWithRedirect({
						responseType: ['token', 'id_token']
					});
				}
			});


		// this function shows the page to users that have been authenticated via Okta
		showPageContents = function (pIdToken) {

			// parse the group claim array from the token
			// loop through the array to parse all of the values from the array						
			$scope.rolesArray = [];
			$scope.userAttrArray = [];
			$scope.zonesArray = [];
			$scope.logInUserAccess = {}
			var accessProfile = utilService.getCurrentUserAccessProfile() || {};
			$scope.rolesArray = accessProfile.roles || [];
			$scope.userAttrArray = accessProfile.userAttributes || [];
			$scope.zonesArray = accessProfile.zones || [];


			console.log($scope.userAttrArray)
			// // show the navbar Dom objects
			// $('#dashboardCtrl').removeAttr('hidden');

			// Loading Controller

			// $scope.serviceURL = "";
			// $scope.logoutURL = "";
			$scope.prtRead = false;
			$scope.prtWrite = false;
			$scope.prtAdmin = false;
			$scope.admin = false;

			$.LoadingOverlay("show");




			if ($scope.userAttrArray.indexOf("PRT Read") != -1) {
				$scope.prtRead = true;
			}
			if ($scope.userAttrArray.indexOf("PRT Write") != -1) {
				$scope.prtWrite = true;
			}

			if ($scope.userAttrArray.indexOf("PRT Admin") != -1 || $scope.rolesArray.indexOf("Admin") != -1) {
				$scope.prtAdmin = true;
			}


			if ($scope.prtAdmin ||
				$scope.prtWrite ||
				$scope.prtRead) {

					// show the navbar Dom objects
				$('#navbar').removeAttr('hidden');
				
				// show the Dashboard Dom objects
				$('#dashboardCtrl').removeAttr('hidden');

				console.log("I do have access to PRT!");
				// $scope.prtdata.macInfoTxt = pIdToken.claims.email;
				$scope.logInUserAccess.fullName = accessProfile.name || pIdToken.claims.name;
				// $scope.logInUserAccess.rqstrLastName = "";
				$scope.uid = accessProfile.preferredUsername || pIdToken.claims.preferred_username;


				utilFactory.getServiceURL().then(function (response) {
					// $.LoadingOverlay("show");
					$scope.serviceURL = response.data;
					console.log('Service URL -', $scope.serviceURL);


					// Initilize the page
					$scope.init();

				}).catch(function (err) {
					console.log('getServiceURL REST Error:' + err.data);
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Page could not be loaded due to ' + err.status, 'danger');
					$.LoadingOverlay("hide");
				});


			}

			$.LoadingOverlay("hide");

		}



		// show the add page Dom objects
		// $('#dashboardCtrl').removeAttr('hidden');

		//this function listens for the skip Nav link scope broadcast
		$scope.$on('skipNavEvent', function () {
			console.log('skipNavEvent detected!');

			//set the focus on the System Outages panel
			$("#summaryList").focus();
		});

		// On click/ UI function calls

		$scope.adminPage = function () {
			console.log("Inside adminPage method.....logging in");

			$timeout(function () {
				$location.path('/admin', true);
			}, 1);
		}


		$scope.viewPRT = function (reqID) {
			console.log("Inside viewPRT method.....");
			console.log("Req Id -" + reqID);
			$timeout(function () {
				$location.path('/view', true).search({
					id: reqID
				});
			}, 1);
		}


		$scope.viewEditPRT = function () {

			if ($scope.selectedList == undefined || $scope.selectedList == null || $scope.selectedList.length == 0) {
				alert("Please select a record to view/edit.");
			} else if ($scope.selectedList.length > 1) {
				alert("Please select one record.");
			} else {
				$timeout(function () {
					var id = $scope.selectedList.toString();
					$scope.viewPRT(id);
				}, 1);
			}

		}

		$scope.onClickCheckBox = function (id) {

			if ($scope.selectedList == undefined) {
				$scope.selectedList = [];
			}
			
			found = $scope.selectedList.indexOf(id);

	
			if (found>-1) {
				$scope.selectedList.splice( found, 1 );	
			} else {
				$scope.selectedList.push(id);
			}
			console.log("onClickCheckBox =>",$scope.selectedList);
		}





		$scope.deletePRT = function () {
			if ($scope.selectedList == undefined || $scope.selectedList == null || $scope.selectedList.length == 0) {
				confirm("Please select a record to delete.");
			} else if ($scope.selectedList.length > 1) {
				alert("Please select one record.");
			}else {
				
				console.log("selected list-", $scope.selectedList);

				var r = confirm("Are you sure, you want to delete the record(s) - " + $scope.selectedList + "?");
				if (r == true) {

					// Write Delete service call.
					utilFactory.deletePRTList($scope.serviceURL, $scope.selectedList.toString(), $scope.uid).then(function (resp) {
						console.log('Deleted Succesfully! ');
						// Reload data

						$scope.init();
						$scope.selectedList = [];
						showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Record(s) has been succesfully deleted. ', 'success');

					});

				}

			}

		}



		// Scope Initializer
		$scope.init = function () {
			
			$.LoadingOverlay("show");

			utilFactory.getSummaryData($scope.serviceURL).then(function (listdata) {


				$scope.summaryList = [];
				$scope.summaryList = listdata.data;
				console.log('Summary Data loadeded Succesfully! ');
				$scope.checkboxs = [];

				var dataSet = [];
				var i = 0;
				var len = $scope.summaryList.length;
				for (i; i < len; i++) {

					var checkbox = {};

					var obj = $scope.summaryList[i];
					var id = obj["prodnPrblmRptId"];
					var methodId = "angular.element('#dashboardCtrl').scope().viewPRT(" + id + ")";
					var deleteMethod = "angular.element('#dashboardCtrl').scope().onClickCheckBox(" + id + ")";

					//				        $scope.checkboxs[i] = {'id': id, 'value':false};

					var btnID = "Problem_report_ID_" + id;

					/* dataSet[i] = [
					 //					                                                    obj["prodnPrblmRptId"],
					 "<input type=\"checkbox\" onclick=" + deleteMethod + "  >",
					 "<button  class=\"btn btn-link\"  id=  " + btnID + " onclick=" + methodId + " >" + id + "</button>", obj["fpsEditNum"], obj["fpsEditName"], obj["modelCntrctr"],
							 obj["prblmSbmtdDt"], obj["dfctCtgryDesc"], obj["prblmDesc"], obj["stusDesc"], obj["prblmPrrtyDesc"], obj["prblmStusDesc"], obj["macJrsdctnDesc"],
							 obj["macInfoTxt"], obj["clmCntRngDesc"], obj["prblmFixdDt"], obj["fpsEditOwner"], obj["prblmFixCreqNum"], obj["issCtgryDesc"], obj["affectedSystems"],
							 obj["audtInsrtId"], obj["audtInsrtTs"], obj["audtUpdtId"], obj["audtUpdtTs"]

					 ]; */

					dataSet[i] = [
						//					                                                    obj["prodnPrblmRptId"],
						"<input type=\"checkbox\" onclick=" + deleteMethod + "  >",
						"<a  role='link' tabindex='0' href aria-label= "+ btnID +"  id=  " + btnID + " onclick=" + methodId + " >" + id + "</a>", obj["fpsEditNum"], obj["fpsEditName"], obj["modelCntrctr"],
						obj["prblmSbmtdDt"], obj["dfctCtgryDesc"], obj["prblmDesc"], obj["stusDesc"], obj["prblmPrrtyDesc"], obj["prblmStusDesc"], obj["macJrsdctnDesc"],
						obj["macInfoTxt"], obj["clmCntRngDesc"], obj["prblmFixdDt"], obj["fpsEditOwner"], obj["prblmFixCreqNum"], obj["issCtgryDesc"], obj["affectedSystems"],
						obj["audtInsrtId"], obj["audtInsrtTs"], obj["audtUpdtId"], obj["audtUpdtTs"]

					];
				}



				//			        setTimeout(function(){ 

				$(document).ready(function () {

					//			        	$("#summaryList").fnClearTable(this); 
					$("#summaryList").dataTable().fnDestroy();
					var table = $('#summaryList').DataTable({
						data: dataSet,
						order: [[1, 'desc']],
						"lengthChange": false,
						"columnDefs": [{
							//Submitted Date
							"render": function (data, type, row) {
								if (data == null || data == undefined || data == "")
									return "";

								return moment.utc(data, 'YYYY/MM/DD').format('MM/DD/YYYY');
							},
							"targets": 5,
							"type": "date",
							"width": "100px"
						}, {
							//FixDate
							"render": function (data, type, row) {
								if (data == null || data == undefined || data == "")
									return "";
								return moment.utc(data, 'YYYY/MM/DD').format('MM/DD/YYYY');
							},
							"targets": 14,
							"type": "date",
							"width": "100px"
						}, {
							//audtInsrtTs
							"render": function (data, type, row) {
								if (data == null || data == undefined || data == "")
									return "";
								return moment.utc(data, 'YYYY/MM/DD').format('MM/DD/YYYY');
							},
							"targets": 20,
							"type": "date"
						}, {
							//audtUpdtTs
							"render": function (data, type, row) {
								if (data == null || data == undefined || data == "")
									return "";
								return moment.utc(data, 'YYYY/MM/DD').format('MM/DD/YYYY');
							},
							"targets": 22,
							"type": "date",
							"width": "100px"
						},
						{
							//checkbox					                
							"targets": 0,
							"orderable": false,
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""
						},
						{
							//Edit Number					                
							"targets": 2,
							"width": "300px"
							, "render": $.fn.dataTable.render.text(),
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""

						},
						{
							//Edit Name					                
							"targets": 3,
							"width": "300px"
							, "render": $.fn.dataTable.render.text(),
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""

						},
						{
							//Modelling Contractor					                
							"targets": 4,
							"width": "300px"
							, "render": $.fn.dataTable.render.text(),
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""

						},{
							"targets": 5,
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""
						},
						{
							//Defect Cate					                
							"targets": 6,
							"width": "300px"
							, "render": $.fn.dataTable.render.text(),
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""

						},
						{
							//Issue Description					                
							"targets": 7,
							"width": "500px"
							, "render": $.fn.dataTable.render.text(),
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""

						},
						{
							//Status Description					                
							"targets": 8,
							"width": "300px"
							, "render": $.fn.dataTable.render.text(),
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""

						},
						{
							//Priority					                
							"targets": 9,
							"width": "300px"
							, "render": $.fn.dataTable.render.text(),
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""

						},
						{
							//Comments					                
							"targets": 10,
							"width": "500px"
							, "render": $.fn.dataTable.render.text(),
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""

						},
						{
							//MAC ID					                
							"targets": 11,
							"width": "300px"
							, "render": $.fn.dataTable.render.text(),
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""

						},
						{
							//MAC Contact info					                
							"targets": 12,
							"width": "300px"
							, "render": $.fn.dataTable.render.text(),
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""

						},
						{
							//Claims Example					                
							"targets": 13,
							"width": "300px",
							"render": $.fn.dataTable.render.text(),
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""

						},{
							"targets": 14,
							"width": "300px",
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""
						},
						{
							//Assigned user					                
							"targets": 15,
							"width": "300px"
							, "render": $.fn.dataTable.render.text(),
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""

						},
						{
							//Problem Fix cr #					                
							"targets": 16,
							"width": "300px"
							, "render": $.fn.dataTable.render.text(),
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""

						},
						{
							//Issue Cat					                
							"targets": 17,
							"width": "300px"
							, "render": $.fn.dataTable.render.text(),
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""

						},
						{
							//Systems Affected					                
							"targets": 18,
							"width": "300px"
							, "render": $.fn.dataTable.render.text(),
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""

						},
						{
							//Systems Affected					                
							"targets": 19,
							"width": "300px",
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""


						},{
							"targets": 20,
							"width": "300px",
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""
							
						},
						{
							//Systems Affected					                
							"targets": 21,
							"width": "300px",
							"render": $.fn.dataTable.render.text(),
							"fnCreatedCell": function ( cell ) {                           
//				                cell.setAttribute('aria-label', 'Vulnerability id ' );
				                cell.setAttribute('tabindex', 0);
				            },
							"defaultContent":""

						}


						],
						"scrollX": false
					});
					$.LoadingOverlay("hide");

				
					$("#summaryList_info").attr('tabindex', 0);
				});
			}).catch(function (err) {
			console.log('getServiceURL REST Error:' + err.data);
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Page could not be loaded due to ' + err.status, 'danger');
			$.LoadingOverlay("hide");
		});

			console.log("Initlization successful!")


		}



		// End of Controller

	}]);
