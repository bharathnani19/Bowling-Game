var appList = angular.module('admin.module', ['ngRoute', 'ngSanitize']);

appList.controller('adminCtrl', ['$scope', '$http', '$location', '$timeout', '$cookies', 'utilFactory', 'utilService', 'utilConstants', '$rootScope',
	function ($scope, $http, $location, $timeout, $cookies, utilFactory, utilService, utilConstants, $rootScope) {

		/*******************************************************************************************************************************************************************************************
		* Loading Controller
		******************************************************************************************************************************************************************************************/

		console.log('Inside the admin controller.');
		// create a new okta auth instance from the util method
		var authClient = utilService.getOktaAuth();
		// console.log('Inside the navController. AuthClient = ' + authClient);

		authClient.tokenManager.getTokens()
			.then(({ accessToken, idToken }) => {
				// handle accessToken and idToken
				if (accessToken) {
					// user has valid access token, so show page contents
					showPageContents(idToken);
				} else {
					// no token and not logged-in, so redirect to login screen               
					authClient.token.getWithRedirect({
						responseType: ['token', 'id_token']
					});
				}
			});

		// show the add page Dom objects
		// $('#AddCtrl').removeAttr('hidden');



		showPageContents = function (pIdToken) {

			$scope.serviceURL = "";
			$scope.selectedFpsPrblmAfctdSys = [];
			$scope.referenceData = {};
			$scope.prtdata = {};
			$scope.editNumbers = {};
			$scope.prtdata.fpsRltdPrblms = [];
			$scope.prtdata.fpsPrblmCmsCreqs = [];
			$scope.prtdata.fpsPrblmAfctdSys = [];
			$scope.attachements = [];
			$scope.fileDownloadURL = "";

			// parse the group claim array from the token
			// loop through the array to parse all of the values from the array						
			$scope.rolesArray = [];
			$scope.userAttrArray = [];
			$scope.zonesArray = [];
			$scope.logInUserAccess = {}
			var accessProfile = utilService.getCurrentUserAccessProfile() || {};
			$scope.rolesArray = accessProfile.roles || [];
			$scope.userAttrArray = accessProfile.userAttributes || [];
			$scope.zonesArray = accessProfile.zones || [];


			console.log($scope.userAttrArray)
			// // show the navbar Dom objects
			// $('#dashboardCtrl').removeAttr('hidden');

			// Loading Controller

			// $scope.serviceURL = "";
			// $scope.logoutURL = "";
			$scope.prtRead = false;
			$scope.prtWrite = false;
			$scope.prtAdmin = false;
			$scope.admin = false;

			$.LoadingOverlay("show");




			if ($scope.userAttrArray.indexOf("PRT Read") != -1) {
				$scope.prtRead = true;
			}
			if ($scope.userAttrArray.indexOf("PRT Write") != -1) {
				$scope.prtWrite = true;
			}

			if ($scope.userAttrArray.indexOf("PRT Admin") != -1 || $scope.rolesArray.indexOf("Admin") != -1) {
				$scope.prtAdmin = true;
			}

			// show the navbar Dom objects
				$('#navbar').removeAttr('hidden');


			if ($scope.prtAdmin) {

				console.log("I do have access to PRT!>>");
				$scope.logInUserAccess.fullName = accessProfile.name || pIdToken.claims.name;
				$scope.uid = accessProfile.preferredUsername || pIdToken.claims.preferred_username;


				utilFactory.getServiceURL().then(function (response) {
					// $.LoadingOverlay("show");
					$scope.serviceURL = response.data;
					console.log('Service URL -', $scope.serviceURL);


					// Initilize the page
					$scope.init();

				}).catch(function (err) {
					console.log('getServiceURL REST Error:' + err.data);
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Page could not be loaded due to ' + err.status, 'danger');
					$.LoadingOverlay("hide");
				});


			} else {
				console.log("You don't have access to Admin Edit Inquiry!");
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> You don\'t have access to Admin Edit Inquiry! ', 'danger');
				$timeout(function () {
					var str = $location.absUrl();
					window.location = "/ProblemReportingTool/";
					$.LoadingOverlay("hide");
				}, 500);
			}

			$.LoadingOverlay("hide");
		}

		// show the add page Dom objects
		$('#adminCtrl').removeAttr('hidden');


		// Reset Tabindex on load
		console.log("tabindex reset onload");
		$(".navbar-header").attr("tabindex", -1).focus();

		//this function listens for the skip Nav link scope broadcast
		$scope.$on('skipNavEvent', function () {
			console.log('skipNavEvent detected!');

			//set the focus on the System Outages panel
			$("#administration").focus();
		});


		/*******************************************************************************************************************************************************************************************
		 * OnClick/UI functions
		 ******************************************************************************************************************************************************************************************/

		$scope.initEditNumbersTable = function () {


		}




		/*******************************************************************************************************************************************************************************************
		 * Email Notification
		 ******************************************************************************************************************************************************************************************/
		$scope.addPOCS = function () {
			console.log('added');
			var rec = {};
			rec.actvInd = "Y";
			$scope.adminRefData.pocs.unshift(rec);
		}

		$scope.updatePOCS = function (record, ind) {
			if (!record) {
				return;
			}

			// Check duplicate email only when updating.
			if (ind === "Y") {
				var normalizedEmail = (record.pocEmailAdr || "").trim().toLowerCase();

				var duplicateRecords = $scope.adminRefData.pocs.filter(
					function (element) {
						return (
							element !== record &&
							element.actvInd === "Y" &&
							(element.pocEmailAdr || "").trim().toLowerCase() ===
							normalizedEmail
						);
					},
				);

				if (duplicateRecords.length > 0) {
					alert("Email already exists.");
					return;
				}
			}

			var action = ind === "N" ? "delete" : "update";

			var confirmed = confirm(
				"Are you sure you want to " + action + " this record?",
			);

			if (!confirmed) {
				return;
			}

			$.LoadingOverlay("show");

			var updatedRec = angular.copy(record);
			updatedRec.actvInd = ind;
			updatedRec.loggedInUserId = $scope.uid;

			utilFactory
				.postEmailNotify($scope.serviceURL, updatedRec)
				.then(
					function (out) {
						console.log(out.data);

						var message =
							ind === "N"
								? "Record has been successfully deleted."
								: "Record has been successfully updated.";

						showGrowl(
							'<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> ' +
							message,
							"success",
						);

						$scope.init();
					},
					function (error) {
						console.log(error.data);

						showGrowl(
							'<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Failed to ' +
							action +
							" the record.",
							"danger",
						);
					},
				)
				.finally(function () {
					$.LoadingOverlay("hide");
				});
		};



		/*******************************************************************************************************************************************************************************************
		 * Edit
		 ******************************************************************************************************************************************************************************************/
		$scope.addEditNumber = function () {
			console.log('added');
			var rec = {};
			rec.actvInd = "Y";
			$scope.adminRefData.editNumbers.unshift(rec);
		}
		$scope.updateEditNumber = function (id, ind) {

			console.log('Clicked ', id);
			var updatedRec = $scope.adminRefData.editNumbers.find(function (element) {
				return element.fpsEditNum == id;
			});

			console.log('Record ', updatedRec);
			console.log('Activ Ind - ', ind);

			var txt;
			var r = confirm("Are you sure, you want to update the record?");

			if (r == true) {
				txt = "You pressed OK!";
				console.log(txt);

				$.LoadingOverlay("show");
				if (ind != null && ind != '')
					updatedRec.actvInd = ind;

				updatedRec.loggedInUserId = $scope.uid;

				utilFactory.postEditNumbers($scope.serviceURL, updatedRec).then(function (out) {
					console.log(out.data)
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Record has been successfuly updated.', 'success');
					$scope.init();
					$.LoadingOverlay("hide");
				}, function (error) {
					console.log(error.data);
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Failed to update the data. ', 'danger');
					$.LoadingOverlay("hide");
				});

			} else {
				txt = "You pressed Cancel!";
				console.log(txt)
			}

		}



		// MAC

		/*******************************************************************************************************************************************************************************************
		 * MAC
		 ******************************************************************************************************************************************************************************************/
		$scope.addMAC = function () {
			console.log('added');
			var rec = {};
			rec.actvInd = "Y";
			$scope.adminRefData.macs.unshift(rec);
		}

		$scope.updateMac = function (id, ind) {

			console.log('Clicked ', id);
			var updatedRec = $scope.adminRefData.macs.find(function (element) {
				return element.macJrsdctnCd == id;
			});

			console.log('Record ', updatedRec);
			console.log('Activ Ind - ', ind);

			var txt;
			var r = confirm("Are you sure, you want to update the record?");

			if (r == true) {
				txt = "You pressed OK!";
				console.log(txt);

				$.LoadingOverlay("show");
				updatedRec.actvInd = ind;
				updatedRec.loggedInUserId = $scope.uid;

				utilFactory.postMacs($scope.serviceURL, updatedRec).then(function (out) {
					console.log(out.data)
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Record has been successfuly updated.', 'success');
					$scope.init();
					$.LoadingOverlay("hide");
				}, function (error) {
					console.log(error.data);
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Failed to update the data. ', 'danger');
					$.LoadingOverlay("hide");
				});

			} else {
				txt = "You pressed Cancel!";
				console.log(txt)
			}

		}


		/*******************************************************************************************************************************************************************************************
		 * Status
		 ******************************************************************************************************************************************************************************************/
		$scope.addStatuses = function () {
			console.log('added');
			var rec = {};
			rec.actvInd = "Y";
			$scope.adminRefData.statuses.unshift(rec);
		}


		$scope.updateStatuses = function (id, ind) {

			console.log('Clicked ', id);
			var updatedRec = $scope.adminRefData.statuses.find(function (element) {
				return element.prodnPrblmRptStusCd == id;
			});

			console.log('Record ', updatedRec);
			console.log('Activ Ind - ', ind);

			var txt;
			var r = confirm("Are you sure, you want to update the record?");

			if (r == true) {
				txt = "You pressed OK!";
				console.log(txt);

				$.LoadingOverlay("show");
				updatedRec.actvInd = ind;
				updatedRec.loggedInUserId = $scope.uid;

				utilFactory.postStatuses($scope.serviceURL, updatedRec).then(function (out) {
					console.log(out.data)
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Record has been successfuly updated.', 'success');
					$scope.init();
					$.LoadingOverlay("hide");
				}, function (error) {
					console.log(error.data);
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Failed to update the data. ', 'danger');
					$.LoadingOverlay("hide");
				});

			} else {
				txt = "You pressed Cancel!";
				console.log(txt)
			}

		}

		// Priority
		/*******************************************************************************************************************************************************************************************
		 * // Priority
		 ******************************************************************************************************************************************************************************************/
		$scope.addProblemPriorities = function () {
			console.log('added');
			var rec = {};
			rec.actvInd = "Y";
			$scope.adminRefData.problemPriorities.unshift(rec);
		}

		$scope.updateProblemPriorities = function (id, ind) {

			console.log('Clicked ', id);
			var updatedRec = $scope.adminRefData.problemPriorities.find(function (element) {
				return element.prblmPrrtyCd == id;
			});

			console.log('Record ', updatedRec);
			console.log('Activ Ind - ', ind);
			updatedRec.loggedInUserId = $scope.uid;

			var txt;
			var r = confirm("Are you sure, you want to update the record?");

			if (r == true) {
				txt = "You pressed OK!";
				console.log(txt);

				$.LoadingOverlay("show");
				updatedRec.actvInd = ind;
				updatedRec.loggedInUserId = $scope.uid;

				utilFactory.postProblemPriority($scope.serviceURL, updatedRec).then(function (out) {
					console.log(out.data)
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Record has been successfuly updated.', 'success');
					$scope.init();
					$.LoadingOverlay("hide");
				}, function (error) {
					console.log(error.data);
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Failed to update the data. ', 'danger');
					$.LoadingOverlay("hide");
				});

			} else {
				txt = "You pressed Cancel!";
				console.log(txt)
			}

		}

		// Issue Category



		/*******************************************************************************************************************************************************************************************
		 * // Issue Category
		 ******************************************************************************************************************************************************************************************/
		$scope.addIssueCategory = function () {
			console.log('added');
			var rec = {};
			rec.actvInd = "Y";
			$scope.adminRefData.issueCategories.unshift(rec);
		}
		$scope.updateIssueCategory = function (id, ind) {

			console.log('Clicked ', id);
			var updatedRec = $scope.adminRefData.issueCategories.find(function (element) {
				return element.issCtgryCd == id;
			});

			console.log('Record ', updatedRec);
			console.log('Activ Ind - ', ind);

			var txt;
			var r = confirm("Are you sure, you want to update the record?");

			if (r == true) {
				txt = "You pressed OK!";
				console.log(txt);

				$.LoadingOverlay("show");
				updatedRec.actvInd = ind;
				updatedRec.loggedInUserId = $scope.uid;


				utilFactory.postIssueCategory($scope.serviceURL, updatedRec).then(function (out) {
					console.log(out.data)
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Record has been successfuly updated.', 'success');
					$scope.init();
					$.LoadingOverlay("hide");
				}, function (error) {
					console.log(error.data);
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Failed to update the data. ', 'danger');
					$.LoadingOverlay("hide");
				});

			} else {
				txt = "You pressed Cancel!";
				console.log(txt)
			}

		}



		/*******************************************************************************************************************************************************************************************
		 * Defect Category
		 ******************************************************************************************************************************************************************************************/
		$scope.addDefectCategories = function () {
			console.log('added');
			var rec = {};
			rec.actvInd = "Y";
			$scope.adminRefData.defectCategories.unshift(rec);
		}
		$scope.updateDefectCategories = function (id, ind) {

			console.log('Clicked ', id);
			var updatedRec = $scope.adminRefData.defectCategories.find(function (element) {
				return element.dfctCtgryCd == id;
			});

			console.log('Record ', updatedRec);
			console.log('Activ Ind - ', ind);

			var txt;
			var r = confirm("Are you sure, you want to update the record?");

			if (r == true) {
				txt = "You pressed OK!";
				console.log(txt);

				$.LoadingOverlay("show");
				updatedRec.actvInd = ind;
				updatedRec.loggedInUserId = $scope.uid;

				utilFactory.postDefectCategories($scope.serviceURL, updatedRec).then(function (out) {
					console.log(out.data)
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Record has been successfuly updated.', 'success');
					$scope.init();
					$.LoadingOverlay("hide");
				}, function (error) {
					console.log(error.data);
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Failed to update the data. ', 'danger');
					$.LoadingOverlay("hide");
				});

			} else {
				txt = "You pressed Cancel!";
				console.log(txt)
			}

		}


		/*******************************************************************************************************************************************************************************************
		 * claims
		 ******************************************************************************************************************************************************************************************/
		$scope.addClaimCount = function () {
			console.log('added');
			var rec = {};
			rec.actvInd = "Y";
			$scope.adminRefData.claimCountRanges.unshift(rec);
		}
		$scope.updateClaimCount = function (id, ind) {

			console.log('Clicked ', id);
			var updatedRec = $scope.adminRefData.claimCountRanges.find(function (element) {
				return element.clmCntRngCd == id;
			});

			console.log('Record ', updatedRec);
			console.log('Activ Ind - ', ind);

			var txt;
			var r = confirm("Are you sure, you want to update the record?");

			if (r == true) {
				txt = "You pressed OK!";
				console.log(txt);

				$.LoadingOverlay("show");
				updatedRec.actvInd = ind;
				updatedRec.loggedInUserId = $scope.uid;

				utilFactory.postClaimCount($scope.serviceURL, updatedRec).then(function (out) {
					console.log(out.data)
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Record has been successfuly updated.', 'success');
					$scope.init();
					$.LoadingOverlay("hide");
				}, function (error) {
					console.log(error.data);
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Failed to update the data. ', 'danger');
					$.LoadingOverlay("hide");
				});

			} else {
				txt = "You pressed Cancel!";
				console.log(txt)
			}

		}

		/*******************************************************************************************************************************************************************************************
		 * Scope Initializer
		 ******************************************************************************************************************************************************************************************/

		$scope.init = function () {

			utilFactory.getServiceURL().then(function (response) {
				$scope.serviceURL = response.data;
				console.log($scope.serviceURL);
				console.log('Service URL loadeded Succesfully! ');

				// Load Reference Data
				utilFactory.getAdminReferenceData($scope.serviceURL).then(function (refdata) {
					console.log(refdata.data)
					$scope.adminRefData = refdata.data;
					console.log('Admin Data loadeded Succesfully! ');
					$scope.initEditNumbersTable();

				}, function (error) {

					console.log(error.data);
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Failed to load Admin Reference data ', 'danger');
					$.LoadingOverlay("hide");
				});
				console.log("Initlization successful!")
			}, function (error) {
				console.log(error.data);
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Failed to load Service URL ', 'danger');
				$.LoadingOverlay("hide");
			});

		}




		/*******************************************************************************************************************************************************************************************
		 * End of Controller
		 ******************************************************************************************************************************************************************************************/


	}]);
