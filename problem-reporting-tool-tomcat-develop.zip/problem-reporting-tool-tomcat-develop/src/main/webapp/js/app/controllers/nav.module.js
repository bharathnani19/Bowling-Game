var appNav = angular.module('nav.module', ['ngRoute', 'ngSanitize']);

appNav.controller('navbarController', ['$scope', '$http', '$location', '$timeout', '$cookies', 'utilFactory', 'utilService', 'utilConstants', '$rootScope', '$interval','$sanitize', '$sce',
	function ($scope, $http, $location, $timeout, $cookies, utilFactory, utilService, utilConstants, $rootScope, $interval, $sanitize, $sce) {
	

		// create a new okta auth instance from the util method
	
	
		var authClient = utilService.setOktaAuth();		
		$timeout(function () {

			console.log('Inside the navController. AuthClient = ' + authClient);

			// check to see if the user is logged-in by calling isLoginRedirect
			if (authClient.isLoginRedirect()) {
				// start the authClient as a service to support enable certain token features
				authClient.start();

				// Successful redirect from Okta login page, so parse token from redirect url
				authClient.token.parseFromUrl()
					.then(data => {

						const { idToken } = data.tokens;
						const { accessToken } = data.tokens;
						//console.log(`Hi ${idToken.claims.preferred_username}!`);

						var state = data.state; // passed to getWithRedirect(), can be any string
						console.log('state from LoginRedirect = ' + state);

						// Store parsed token in Token Manager
						authClient.tokenManager.add('idToken', idToken);
						authClient.tokenManager.add('accessToken', accessToken);
						console.log(idToken);
						console.log(accessToken);
						console.log('Inside the navController. recordLogin ');
						   if (localStorage.getItem('prt.firstTimeVisit') != null) {
					          console.log("firstTimeVisit exists")
					        }else{
								console.log("firstTimeVisit does not exist")
							}
						loadTrustedAccessProfile(function(accessProfile) {
							if (localStorage.getItem('prt.firstTimeVisit') === null) {
								recordLogin(accessProfile);
								localStorage.setItem('prt.firstTimeVisit', 'true');
							}
							showNavPageContents(idToken, accessProfile);
						});
						//var in30Minutes = new Date(new Date().getTime() + 30 * 60 * 1000);
						//if ($cookies.get('prt.firstlogin') === undefined) {
						//  $cookies.put('prt.firstlogin', 'true', { expires: in30Minutes, path: '/ProblemReportingTool' });
						//}

					})
					.catch(function (err) {
						// handle OAuthError
						console.log('parseFromUrl error: ' + err);

						// parse error could be from opening a new tab/window, so check for valid token
						// Attempt to retrieve ID Token from Token Manager
						authClient.tokenManager.get('idToken')
							.then(idToken => {
								console.log('parseURL error, but user has a token - ' + idToken);

								loadTrustedAccessProfile(function(accessProfile) {
									showNavPageContents(idToken, accessProfile);
								});
							})
					});
			} else {

				// Attempt to retrieve ID Token from Token Manager
				authClient.tokenManager.get('idToken')
					.then(idToken => {
						console.log(idToken);
						if (idToken) {

							//console.log(`Hi ${idToken.claims.email}!`);
							console.log("location = " + window.location.href);
							//if ($cookies.get('prt.firstlogin') === undefined) {
								
							//	var in30Minutes = new Date(new Date().getTime() + 30 * 60 * 1000);
								//recordLogin(idToken);
							  //	$cookies.put('prt.firstlogin', 'true', { expires: in30Minutes, path: '/ProblemReportingTool' });
							//}
							loadTrustedAccessProfile(function(accessProfile) {
								if (localStorage.getItem('prt.firstTimeVisit') === null) {
									recordLogin(accessProfile);
									localStorage.setItem('prt.firstTimeVisit', 'true');
								}
								showNavPageContents(idToken, accessProfile);
							});

						} else {
							// You're not logged in, you need a sessionToken
							console.log('User is not logged-in and does not have a token... redirect to login screen');
							authClient.token.getWithRedirect({
								responseType: ['token', 'id_token'],
								state: 'token-from-redirect '
							})
								.catch(function (err) {
									console.log('getWithRedirect error: ' + err);
								});
						}
					})
			}

		}, 1);

		loadTrustedAccessProfile = function(onReady) {
			utilFactory.getServiceURL().then(function(response) {
				$scope.serviceURL = response.data;
				utilFactory.getCurrentUserAccess($scope.serviceURL).then(function(accessResponse) {
					var accessProfile = accessResponse.data || {};
					utilService.setCurrentUserAccessProfile(accessProfile);
					onReady(accessProfile);
				}).catch(function(err) {
					console.log('getCurrentUserAccess REST Error:' + err.data);
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to validate user access.', 'danger');
				});
			}).catch(function(err) {
				console.log('getServiceURL REST Error:' + err.data);
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Page could not be loaded due to ' + err.status, 'danger');
			});
		}

		// sends the login to Splunk
	recordLogin = function(pAccessProfile) {
		$.LoadingOverlay("show");
		utilFactory.getServiceURL().then(function(response) {
				//declare a scope level variable for the URL used to make REST web service calls 
			$scope.restURL = response.data;			
			console.log("Inside .recordLogin "+pAccessProfile);
			var role = (pAccessProfile.roles && pAccessProfile.roles.length > 0) ? pAccessProfile.roles[0] : '';
			var zone = (pAccessProfile.zones && pAccessProfile.zones.length > 0) ? pAccessProfile.zones[0] : '';
			var attrs = pAccessProfile.userAttributes || [];
		
			//create the json request object
			var entryCriteria = {
				email: pAccessProfile.email,
				firstNm: pAccessProfile.firstName,
				lastNm: pAccessProfile.lastName,
				userId: pAccessProfile.preferredUsername,
				role:  role,
				zone: zone,
				attributes: attrs,
				system: "PRT"
			};
					  
			//create the JSON object to be used in the REST Request
			jsonData = JSON.stringify(entryCriteria);
			console.log('recordLogin REST request = ' + jsonData);
			
			//make the rest web service call to log the data
			$http.post($scope.restURL + '/rest/prt/record', jsonData);
			console.log('done recordLogin REST request = ' + jsonData);
			$.LoadingOverlay("hide");
		}).catch(function (err) {
		console.log('getServiceURL REST Error:' + err.data);
		showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Page could not be loaded due to ' + err.status, 'danger');
		$.LoadingOverlay("hide");
	});
	}

		
		


		// this function shows the page to users that have been authenticated via Okta
				showNavPageContents = function (pIdToken, pAccessProfile) {

			/*******************************************************************************************************************************************************************************************
			* Loading Controller
			******************************************************************************************************************************************************************************************/
			// $.LoadingOverlay("show");
			// parse the group claim array from the token
			// loop through the array to parse all of the values from the array						
			$scope.rolesArray = [];
			$scope.userAttrArray = [];
			$scope.zonesArray = [];
			$scope.logInUserAccess = {}
			pAccessProfile = pAccessProfile || {};
			$scope.rolesArray = pAccessProfile.roles || [];
			$scope.userAttrArray = pAccessProfile.userAttributes || [];
			$scope.zonesArray = pAccessProfile.zones || [];

			$scope.trainingUrl = utilService.getTrainingUrl();
			console.log($scope.userAttrArray)



			if ($scope.userAttrArray.indexOf("PRT Read") != -1) {
				$scope.prtRead = true;
			}
			if ($scope.userAttrArray.indexOf("PRT Write") != -1) {
				$scope.prtWrite = true;
			}

			if ($scope.userAttrArray.indexOf("PRT Admin") != -1 || $scope.rolesArray.indexOf("Admin") != -1) {
				$scope.prtAdmin = true;
			}


			if ($scope.prtAdmin  ||
				$scope.prtWrite ||
				$scope.prtRead) {

				// show the navbar Dom objects
				$('#navbar').removeAttr('hidden');

				

				console.log("I do have access to PRT!");
				$scope.fullName = pAccessProfile.name || pIdToken.claims.name;
				$scope.rolesStr = $scope.rolesArray.toString();
				$scope.attributes = $scope.userAttrArray.toString();
				$scope.oldOrganizationVal = $scope.zonesArray[0];
				$scope.firstname = pAccessProfile.firstName || pIdToken.claims.first_name;
				$scope.givenName = pAccessProfile.lastName || pIdToken.claims.last_name;
				$scope.scopeUserId = pAccessProfile.preferredUsername || pIdToken.claims.preferred_username;
				// map old org values to new org values
				if ($scope.oldOrganizationVal == 'UPIC 1') {
					$scope.organization = 'UPIC MW';
				} else if ($scope.oldOrganizationVal == 'UPIC 2') {
					$scope.organization = 'UPIC NE';
				} else if ($scope.oldOrganizationVal == 'UPIC 3') {
					$scope.organization = 'UPIC W';
				} else if ($scope.oldOrganizationVal == 'UPIC 4') {
					$scope.organization = 'UPIC SW';
				} else if ($scope.oldOrganizationVal == 'UPIC 5') {
					$scope.organization = 'UPIC SE';
				} else {
					$scope.organization = $scope.oldOrganizationVal;
				}
				
						
				utilFactory.getServiceURL().then(function (response) {
					
					$scope.uid = pAccessProfile.preferredUsername || pIdToken.claims.preferred_username;

					$scope.serviceURL = response.data;
					$scope.probReportLinkUrl = $scope.serviceURL.substring(0, $scope.serviceURL.lastIndexOf("/") + 1) + "ProblemReportingTool/#/dashboard";
					$scope.VMUrl = $scope.serviceURL.substring(0, $scope.serviceURL.lastIndexOf("/") + 1) + "VulnerabilityManagement/#/dashboard";
					$scope.supportUrl = $scope.serviceURL.substring(0, $scope.serviceURL.lastIndexOf("/") + 1) + "UserSupportPortal/index.html";
					$rootScope.umLinkUrl = $scope.serviceURL.substring(0, $scope.serviceURL.lastIndexOf("/") + 1) + "UserManagement/#/userprofile";
					$scope.ReportsUrl = window.__env.tableauRoot;
					$scope.editsandModelsLifecycleUrl = window.__env.editsandModelsLifecycleUrl;
	
					console.log('Service URL -', $scope.serviceURL);

					utilFactory.getPropertyValue($scope.serviceURL, "unifiedportalURL").then(function (propValue) {
						$scope.unifiedportalURL = propValue.data;
						console.log('UP URL->', $scope.unifiedportalURL);
					}).catch(function (err) { console.log('getPropertyValue REST Error:' + err.data); });
						
						// user management approver link is only accessible to approvers
						if ($scope.userAttrArray.indexOf("Master Approver") != -1 || $scope.userAttrArray.indexOf("DMA Approver") != -1
							|| $scope.userAttrArray.indexOf("MAC Approver") != -1 || $scope.userAttrArray.indexOf("IO Approver") != -1 || $scope.rolesArray.indexOf("Admin") != -1) {

							console.log("User is an Approver... so show the User Management link.");
							$('#umApproverLink').removeClass('hidden');
							$scope.umApprvrLinkUrl = $scope.serviceURL.substring(0, $scope.serviceURL.lastIndexOf("/") + 1) + "UserManagement/#/list";
						} else {
							console.log("****** NOT Showing UM Link ******");
						}

						// only show the VM link to Admin users, InquiryOnly users with (vm-admin, vm-read, vm-create, vm-update-edit),
						// PrioritizeSup users with (vm-read, vm-create), MAC users with (vm-read, vm-create)
						if ($scope.rolesArray.indexOf("Admin") != -1
							|| ($scope.rolesArray.indexOf("Inquiry Only") != -1 && ($scope.userAttrArray.indexOf("VM Admin") != -1 || $scope.userAttrArray.indexOf("VM Read") != -1 || $scope.userAttrArray.indexOf("VM Create") != -1 || $scope.userAttrArray.indexOf("VM Update Edit") != -1))
							|| ($scope.rolesArray.indexOf("Prioritize Sup") != -1 && ($scope.userAttrArray.indexOf("VM Read") != -1 || $scope.userAttrArray.indexOf("VM Create") != -1))
							|| ($scope.rolesArray.indexOf("MAC") != -1 && ($scope.userAttrArray.indexOf("VM Read") != -1 || $scope.userAttrArray.indexOf("VM Create") != -1))) {
							//show VM link
							console.log("****** Showing VM Link ******");
							$('#vmLink').removeClass('hidden');
						} else {
							//do NOT show VM link
							console.log("****** NOT Showing VM Link ******");
						}

						// only show the PRT link to Admin users, InquiryOnly users with (prt-admin, prt-read, prt-write),
						// PrioritizeSup users with (vprt-read, prt-write), MAC users with (vprt-read, prt-write), 				
						if ($scope.rolesArray.indexOf("Admin") != -1
							|| ($scope.rolesArray.indexOf("Inquiry Only") != -1 && ($scope.userAttrArray.indexOf("PRT Admin") != -1 || $scope.userAttrArray.indexOf("PRT Read") != -1 || $scope.userAttrArray.indexOf("PRT Write") != -1))
							|| ($scope.rolesArray.indexOf("Prioritize Sup") != -1 && ($scope.userAttrArray.indexOf("PRT Read") != -1 || $scope.userAttrArray.indexOf("PRT Write") != -1))
							|| ($scope.rolesArray.indexOf("MAC") != -1 && ($scope.userAttrArray.indexOf("PRT Read") != -1 || $scope.userAttrArray.indexOf("PRT Write") != -1))) {
							//show VM link
							console.log("****** Showing PRT Link ******");
							$('#prtLink').removeClass('hidden');
							$scope.probReportLinkUrl = $scope.serviceURL.substring(0, $scope.serviceURL.lastIndexOf("/") + 1) + "ProblemReportingTool/#/dashboard";
						} else {
							//do NOT show VM link
							console.log("****** NOT Showing PRT Link ******");
						}

						// lock the administration link if user is not a supervisor				
						if ($scope.rolesArray.indexOf("Admin") == -1) {
							console.log('User is not an Admin, so do NOT show Administration link');
						} else {
							console.log('User is an Admin, so show Administration link');
							$('#adminLink').removeClass('hidden');
							// set the URL for the admin link
							//	$('#adminLinkAnchor').attr("href", $scope.restURL + '#Administration');			
						}
						
						if (
							$scope.userAttrArray.indexOf("EML Model Developer") != -1 ||
							//										|| $scope.userAttrArray.indexOf("EML Edits Manager") != -1
							$scope.userAttrArray.indexOf("EML DMA") != -1 ||
							$scope.userAttrArray.indexOf("EML System Maintainer") != -1 ||
							//										|| $scope.userAttrArray.indexOf("EML Edits Developer") != -1
							$scope.userAttrArray.indexOf("EML DISM") != -1 ||
							$scope.userAttrArray.indexOf("EML Model Manager") != -1 ||
							$scope.userAttrArray.indexOf("EML Model Developer") != -1 ||
							//										|| $scope.userAttrArray.indexOf("VM Create") != -1
							$scope.userAttrArray.indexOf("EML Model Operations") != -1 ||
							$scope.userAttrArray.indexOf("EML Edit Operations") != -1
							//										|| $scope.userAttrArray.indexOf("EML FIG") != -1
						) {
							console.log("****** Showing EML Link ******");
							$("#emlLink").removeClass("hidden");
						} else if (
							($scope.rolesArray.indexOf("Inquiry Only") != -1 ||
								$scope.rolesArray.indexOf("Prioritize Sup") != -1) &&
							($scope.organization.includes("UPIC") ||
								$scope.organization.includes("Deloitte") ||
								$scope.organization.includes("GDIT") ||
								$scope.organization.includes("MEDIC"))
						) {
							// Keep the link open for VM proposal - FPS-26202 - AC1
							$("#emlLink").removeClass("hidden");
						}
						
					//call the /landingpage/header/{userId}/{userZone} web service to get the user requests and messages					
					utilFactory.getHeaderInfo($scope.serviceURL, $scope.oldOrganizationVal, $scope.scopeUserId).then(function(response) {
						// extract the messages and user requests from the response
						$scope.messages = response.data.messages;
						$scope.requests = response.data.requests;
						
						console.log("$scope.requests = " + $scope.requests);
																
						// set the badge number if messages isn't empty
						if (response.data.newSysMsgCt != "" && response.data.newSysMsgCt > 0 ){
							//show the badge
							$scope.showMsgsBadge = true;
							//set the badge number
							$scope.sysMsgsBadgeVal = response.data.newSysMsgCt;
						} else {
							//hide the badge
							$scope.showMsgsBadge = false;
							$scope.sysMsgsBadgeVal = "";
						}
						
						//build the user requests array
						var userRequestsArray = [];
						for (i = 0; i < $scope.requests.length; i++) {
							userRequestsArray.push($scope.requests[i].status);
						}
						
						if (userRequestsArray.length > 0) {
							//set the value of the attributes field
							$scope.userRequests = userRequestsArray.toString();
						} else {
							$scope.userRequests = "";
						}
						$rootScope.userRequests = $scope.userRequests;
						
						//only show the User Request table to PrioritizeSup users					
						if (userRequestsArray.length > 0) {
							
							//show the User Request table
							$scope.showUserRequests = true;
						} else {
							//show the User Request table
							$scope.showUserRequests = false;
						}
						
						
					}).catch(function(err) {
						console.log('getHeaderInfo REST Error:' + err.status);
						
						showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Navigation Bar info failed to load due to ' + err.status, 'danger');
					});

				}).catch(function (err) {
					console.log('getServiceURL REST Error:' + err.data);
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Page could not be loaded due to ' + err.status, 'danger');
					//$.LoadingOverlay("hide");

				});

				// redirect the user to the dashboard page to load controller
				console.log('Redirect to Index screen');
				window.location = "#/dashboard";


			} else {
				console.log("You don't have access to PRT!");
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> You don\'t have access to Edit Inquiry! ', 'danger');
				$timeout(function () {
					$scope.signOutOkta();
					localStorage.clear();
					//$.LoadingOverlay("hide");
				}, 3000);
				//$.LoadingOverlay("hide");
			}
		}

		//this method handles the skip Navigation link for 508 compliancy
		$scope.skipNavFunc = function () {
			console.log('Inside the skipNavFunc function.');

			//broadcast to all scopes that the user has clicked the skip nav link
			$rootScope.$broadcast("skipNavEvent");

		}


		$scope.clearSession = function () {
			window.sessionStorage.clear();
			console.log('Inside clearSession');

		}

		$scope.signOutOkta = function () {

			//stop the interval
			$interval.cancel($scope.intervalVar);

			// call the clear session method
			$scope.clearSession

			// sign the user out of Okta
			authClient.signOut();
			localStorage.clear();
		}

		// listen for a broadcast from the factory methods to reset the user's session
		$scope.$on('factoryMethodCalled', function (event, args) {
			//call the util factory's getResetIdleTime method to reset the user's session time
			console.log("^^^^^^^^^^^ Factory method called ^^^^^^^^^^^");

			//reset the interval to be as close to the beginning of the session reset as possible
			//$interval.cancel($scope.intervalVar);
			getSessionIdleTimeCheck('true');
		});
		
				$scope.readMoreLinkLenCheck = function(pTextStr) {
			console.log('Inside the readMoreLinkLenCheck function.');
			
			if (pTextStr.length > 101) {
				var oTextStr = pTextStr.substr(0,150) + "...&nbsp;<a tabindex='0' href='' title='show more' role='link' style='cursor:pointer;font-weight:normal;' class='moreLinkClass'>Show More</a>";
				
				return oTextStr;
			} else {
				return pTextStr;
			}
		}
			// this function notifies the web services that the user has read the System Messages
		$scope.markMsgsAsReadByUser = function() {
			console.log('Inside the markMsgsAsReadByUser function.');
			utilFactory.getServiceURL().then(function(response) {
				$scope.restURL = response.data;	
				//call /rest/landingpage/messages/view/{userId} to indicate the user has read the messages
				utilFactory.setMsgsAsReadByUser($scope.restURL, $scope.scopeUserId).then(function(response) {
					
					if (response.data.validResponse == 'true') {
						console.log("Messages have been marked as read by user " + $scope.scopeUserId + ".")
					} else {
						console.log("Messages have NOT been marked as read by user " + $scope.scopeUserId + ".")
					}
					
				}).catch(function(err) {
					console.log('Request setMsgsAsReadByUser REST Error:' + err.status);
				});
			}).catch(function (err) {
			});
		}
		
		$scope.showMoreClick = function(pMsgObjId, pLinkType) {
			console.log('Inside the showMoreClick function.' + pMsgObjId);
			var indexNum = pMsgObjId.substr(0, pMsgObjId.indexOf("message"));
			var msgArrayVal = $scope.messages[indexNum].message;
			//console.log("indexNum = " + $scope.messages[indexNum].message);
			
			if (pLinkType == "more") {
				//$("#" + pMsgObjId).html(msgArrayVal).append("&nbsp;<a style='cursor:pointer;' class='lessLinkClass'>Show Less</a>");
				$("#" + pMsgObjId).html(msgArrayVal + "&nbsp;<a style='cursor:pointer;font-weight:normal;' title='show less' href='' role='link' class='lessLinkClass'>Show Less</a>");
			} else {
				//$("#" + pMsgObjId).html(msgArrayVal.substr(0,100)).append("...&nbsp;<a style='cursor:pointer;' class='moreLinkClass'>Show More</a>");
				$("#" + pMsgObjId).html(msgArrayVal.substr(0,150) + "...&nbsp;<a tabindex='0' href='' title='show more' role='link' style='cursor:pointer;font-weight:normal;' class='moreLinkClass'>Show More</a>");
			}
			
		}

		// user to continue their session after 25 minutes of idle time.
		function getSessionIdleTimeCheck(pRefreshSession) {
			console.log('Inside getSessionIdleTimeCheck function. pRefreshSession = ' + pRefreshSession);

			if (pRefreshSession == 'true') {
				// set the idleTimeExp local storage object to the current time + 30 mins
				localStorage.setItem('idleTimeExp', moment().add(30, 'm'));

				// get the date from local storage		
				console.log('%%%%%%%%%%% Reset Idle Time Expiration to ' + localStorage.getItem('idleTimeExp') + ' %%%%%%%%%%%');
			}

			//reset the interval to help sync start times across browser tabs
			$interval.cancel($scope.intervalVar);

			//start interval to check the session idle time using Okta Access Token
			$scope.intervalVar = $interval(function () {
				console.log("getSessionIdleTimeCheck: Interval method called.");

				// get the date/time from local storage
				var idleTimeFromStorage = moment(localStorage.getItem('idleTimeExp'));

				// get the current date/time
				var currentTime = moment();

				// assign the remaining time (minutes) to scope variable
				$scope.remainingIdleTimeResp = idleTimeFromStorage.diff(currentTime, 'minutes');
				console.log("%%%%% Remaining Time until Idle Expiration = " + $scope.remainingIdleTimeResp + " %%%%%");

				//check to see if the user idle time is more than 10 minutes
				if ($scope.remainingIdleTimeResp <= 5) {
					//check to see if the timer reached zero
					if ($scope.remainingIdleTimeResp <= 0) {

						// sign out of Okta
						
						$scope.signOutOkta();
						localStorage.clear();

					} else {
						//set whether the messages says minutes or minute
						if ($scope.remainingIdleTimeResp <= 1) {
							$('#idleTimeSpanMsg').text($scope.remainingIdleTimeResp + ' minute');
						} else {
							$('#idleTimeSpanMsg').text($scope.remainingIdleTimeResp + ' minutes');
						}

						//do not let user escape modal
						$('#idleTimeModal').modal({
							backdrop: 'static',
							keyboard: false
						})

						//show the modal 
						$("#idleTimeModal").modal("show");
					}
				}
			}, 60000);	//check every 60 seconds
		}

		// user has engaged the session timeout modal buttons
		$scope.contSessBtnClick = function (pContinueSessBool) {
			console.log('Inside contSessBtnClick.  pContinueSessBool = ' + pContinueSessBool);

			if (pContinueSessBool == 'true') {

				console.log('Continue Session.');

				//reset the interval to be as close to the beginning of the session reset as possible
				//$interval.cancel($scope.intervalVar);
				getSessionIdleTimeCheck('true');

				//hide the warning dialog window
				$("#idleTimeModal").modal("hide");
			} else {
				console.log('End Session');
				//hide the warning dialog window
				$("#idleTimeModal").modal("hide");

				//stop the interval
				$interval.cancel($scope.intervalVar);

				// sign the user out of Okta
				authClient.signOut();
				localStorage.clear();
			}
		}

		// track global logout of okta
		$scope.$on('sessionKeepAlive', function (event, args) {
			console.log('Session Keep Alive callled! Message = ' + args.message);
		});
		
		$scope.loadDocument = function(pURL) {
			console.log("Inside loadDocument");
			var queryString = pURL.substring(pURL.lastIndexOf('?')+1, pURL.length-1);

			var urlParams = new URLSearchParams(queryString);
			if (!urlParams.get("userId")){
				pURL+="&userId="+$scope.uid;
			}
					console.log("qs "+pURL);

			console.log($scope.uid);
			// broadcast this event to the reset session listener
			$rootScope.$broadcast("factoryMethodCalled");
			config = {};

			utilFactory.loadDocument(pURL).success(function(response) {	
			
			}).catch(function(err) {
				console.log('loadDocument REST Error:' + err.data);			
			});;
			
		
			console.log('loadDocument REST request = ' + jsonData);
							
				
		
			
		
							
				
		};

		// listen for the authstate change
		authClient.authStateManager.subscribe(authState => {
			// handle emitted latest authState
			console.log('--- AuthState Change ---');
			console.log('is Authenticated = ' + authState.isAuthenticated);

			// if the user has been logged out of another tab, log them out of the current tab
			if (!authState.isAuthenticated) {
				console.log('isAuthenticated is false, so logout user...');
				//$scope.signOutOkta();

				//hide the warning dialog window
				$("#idleTimeModal").modal("hide");

				//press the logout button to redirect user to logout screen
				//$scope.signOutOkta();

				//stop the interval
				$interval.cancel($scope.intervalVar);

				// stop the authClient service
				//authClient.stop();

				// sign the user out of Okta
				authClient.signOut();
				authClient.signOut();
				localStorage.clear();
			} else {
				console.log('isAuthenticated is NOT false.');
			}
		});

		window.addEventListener('storage', function (e) {
			console.log("storage event occured here: " + e.key);

			if (e.key == 'continueSession') {
				// user clicked the continue session button in different tab, so call local continue session method			

			} else if (e.key == 'idleTimeExp') {
				// session was reset in another window, so hide modal				
				$("#idleTimeModal").modal("hide");

				//reset the interval to be as close to the beginning of the session reset as possible
				//$interval.cancel($scope.intervalVar);

				getSessionIdleTimeCheck('false');

			} else if (e.key == 'okta-token-storage'){	
				console.log('storage change detected');
				authClient.signOut();
			}
		}, false);

	
		/***************************************************************************************************************************************************************************************************
		 * End of Controller
		 **************************************************************************************************************************************************************************************************/


	}]);
	
$(function () {

	$("body").on("click", ".moreLinkClass", function(e){
		// alert($(this).parents(".messageClass").first().attr("id"));			 
		 var msgElementId = $(this).parents(".messageClass").first().attr("id");
		 angular.element('#navController').scope().showMoreClick(msgElementId, "more");
		 
		 e.preventDefault();
		 e.stopPropagation();
	 });
	 
	 $("body").on("click", ".lessLinkClass", function(e){
		 //alert($(this).parent(".messageClass").attr("id"));
		 var msgElementId = $(this).parents(".messageClass").first().attr("id");
		 angular.element('#navController').scope().showMoreClick(msgElementId, "less");
		 
		 e.preventDefault();
		 e.stopPropagation();
	 });
});