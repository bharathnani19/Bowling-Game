var appList = angular.module('view.module', ['ngRoute', 'ngSanitize']);

appList.controller('viewCtrl', [
	'$scope',
	'$http',
	'$location',
	'$timeout',
	'$window',
	'$cookies',
	'utilFactory',
	'utilService',
	'utilConstants',
	'$rootScope',
	function ($scope, $http, $location, $timeout, $window, $cookies, utilFactory, utilService, utilConstants, selectNgFiles, $rootScope) {

		console.log('Inside the view controller.');
		// create a new okta auth instance from the util method
		var authClient = utilService.getOktaAuth();
		// console.log('Inside the navController. AuthClient = ' + authClient);

		authClient.tokenManager.getTokens()
			.then(({ accessToken, idToken }) => {
				// handle accessToken and idToken
				if (accessToken) {
					// user has valid access token, so show page contents
					showPageContents(idToken);
				} else {
					// no token and not logged-in, so redirect to login screen               
					authClient.token.getWithRedirect({
						responseType: ['token', 'id_token']
					});
				}
			});

		// show the add page Dom objects
		// $('#AddCtrl').removeAttr('hidden');



		showPageContents = function (pIdToken) {

			$scope.serviceURL = "";
			$scope.selectedFpsPrblmAfctdSys = [];
			$scope.referenceData = {};
			$scope.prtdata = {};
			$scope.editNumbers = {};
			$scope.prtdata.fpsRltdPrblms = [];
			$scope.prtdata.fpsPrblmCmsCreqs = [];
			$scope.prtdata.fpsPrblmAfctdSys = [];
			$scope.attachements = [];
			$scope.fileDownloadURL = "";

			// parse the group claim array from the token
			// loop through the array to parse all of the values from the array						
			$scope.rolesArray = [];
			$scope.userAttrArray = [];
			$scope.zonesArray = [];
			var accessProfile = utilService.getCurrentUserAccessProfile() || {};
			$scope.firstname = accessProfile.firstName || pIdToken.claims.first_name;
			$scope.lastname = accessProfile.lastName || pIdToken.claims.last_name;
			$scope.givenName = accessProfile.firstName || pIdToken.claims.first_name;
			$scope.fullName = accessProfile.name || pIdToken.claims.name;
			$scope.logInUserAccess = {}
			$scope.rolesArray = accessProfile.roles || [];
			$scope.userAttrArray = accessProfile.userAttributes || [];
			$scope.zonesArray = accessProfile.zones || [];


			console.log($scope.userAttrArray)
			// // show the navbar Dom objects
			// $('#dashboardCtrl').removeAttr('hidden');

			// Loading Controller

			// $scope.serviceURL = "";
			// $scope.logoutURL = "";
			$scope.prtRead = false;
			$scope.prtWrite = false;
			$scope.prtAdmin = false;
			$scope.admin = false;

			$.LoadingOverlay("show");




			if ($scope.userAttrArray.indexOf("PRT Read") != -1) {
				$scope.prtRead = true;
			}
			if ($scope.userAttrArray.indexOf("PRT Write") != -1) {
				$scope.prtWrite = true;
			}

			if ($scope.userAttrArray.indexOf("PRT Admin") != -1 || $scope.rolesArray.indexOf("Admin") != -1) {
				$scope.prtAdmin = true;
			}


			if ($scope.prtAdmin ||
				$scope.prtWrite ||
				$scope.prtRead) {

				console.log("I do have access to PRT!>>");
				// $scope.prtdata.macInfoTxt = pIdToken.claims.email;
				$scope.logInUserAccess.fullName = accessProfile.name || pIdToken.claims.name;
				// $scope.logInUserAccess.rqstrLastName = "";
				$scope.uid = accessProfile.preferredUsername || pIdToken.claims.preferred_username;


				utilFactory.getServiceURL().then(function (response) {
					// $.LoadingOverlay("show");
					$scope.serviceURL = response.data;
					console.log('Service URL -', $scope.serviceURL);

					$scope.id = $location.search().id;
					console.log('id->', $scope.id);


					// Initilize the page
					$scope.init();

				}).catch(function (err) {
					console.log('getServiceURL REST Error:' + err.data);
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Page could not be loaded due to ' + err.status, 'danger');
					$.LoadingOverlay("hide");
				});


			}

			$.LoadingOverlay("hide");
		}
		// show the add page Dom objects
		$('#navbar').removeAttr('hidden');
		$('#viewCtrl').removeAttr('hidden');

		// Reset Tabindex on load
		console.log("tabindex reset onlad");
		$(".navbar-header").attr("tabindex", -1).focus();


		//this function listens for the skip Nav link scope broadcast
		$scope.$on('skipNavEvent', function () {
			console.log('skipNavEvent detected!');

			//set the focus on the System Outages panel
			$("#problemReportDetail").focus();
		});


		/*
		 * OnChange /UI Functions
		 */

		$scope.onChangeEditDetails = function () {
			console.log($scope.editNumbers);
			$scope.prtdata.fpsEditNum = $scope.editNumbers.fpsEditNum;
			$scope.prtdata.fpsEditName = $scope.editNumbers.fpsEditName;
			$scope.prtdata.modelCntrctr = $scope.editNumbers.modelCntrctr;
			// UAT fix : assign email id of MAc user.
			//		        $scope.prtdata.macInfoTxt = $scope.editNumbers.macInfo;
			$scope.prtdata.fpsEditOwner = $scope.editNumbers.editOwner;
		}
		$scope.onChangeClmCntRngDesc = function () {
			console.log($scope.claimCountRanges);
			$scope.prtdata.clmCntRngCd = $scope.claimCountRanges.clmCntRngCd;
		}

		$scope.onChangeDfctCtgryDesc = function () {
			console.log($scope.defectCategories);
			$scope.prtdata.dfctCtgryCd = $scope.defectCategories.dfctCtgryCd;
		}

		$scope.onChangeIssCtgryDesc = function () {
			console.log($scope.issueCategories);
			$scope.prtdata.issCtgryCd = $scope.issueCategories.issCtgryCd;
		}
		$scope.onChangeStatuses = function () {
			console.log($scope.statuses);
			$scope.prtdata.stusCd = $scope.statuses.prodnPrblmRptStusCd;
		}
		$scope.onChangeMacs = function () {
			console.log($scope.macs);
			$scope.prtdata.macJrsdctnCd = $scope.macs.macJrsdctnCd;
		}
		$scope.onChangeProblemPriorities = function () {
			console.log($scope.problemPriorities);
			$scope.prtdata.prblmPrrtyCd = $scope.problemPriorities.prblmPrrtyCd;
		}

		$scope.toggleSelectionAffectedSystems = function (index) {


			/*
							const idx = $scope.prtdata.fpsPrblmAfctdSys.findIndex(function(element) {
								return element.afctdSysCd == index;
							});
			*/
			var idx = -1;
			for (var i = 0; i < $scope.prtdata.fpsPrblmAfctdSys.length; i++) {
				if ($scope.prtdata.fpsPrblmAfctdSys[i].afctdSysCd == index) {
					idx = i;
					break;
				}
			}
			// is currently selected
			if (idx > -1) {
				$scope.prtdata.fpsPrblmAfctdSys.splice(idx, 1);
			} else {

				for (var i = 0; i < $scope.referenceData.affectedSystems.length; i++) {
					if ($scope.referenceData.affectedSystems[i].afctdSysCd == index) {
						$scope.prtdata.fpsPrblmAfctdSys.push($scope.referenceData.affectedSystems[i]);
						break;
					}
				}

				/*
				 const affectedSystem = $scope.referenceData.affectedSystems.find(function(element) {
					return element.afctdSysCd == index;
				});
				$scope.prtdata.fpsPrblmAfctdSys.push(affectedSystem);
				console.log('affectedSystem->', affectedSystem);
				*/
			}
			console.log("Selected affected systems - ", $scope.prtdata);
		}

		/*
		* On Submit Button - Save the record to   database
		*/

		$scope.onSubmit = function () {

			$.LoadingOverlay("show");

			//		        $scope.prtdata.prblmSbmtdDt = moment.utc($("#submitteddate")).format('YYYY/MM/DD');
			//		        $scope.prtdata.prblmFixdDt = moment.utc($("#fixDate")).format('YYYY/MM/DD');


			if ($scope.prtdata.prblmSbmtdDt == "" || $scope.prtdata.prblmSbmtdDt == null) {
				$scope.prtdata.prblmSbmtdDt = moment.utc(new Date(), 'MM/DD/YYYY').format('YYYY/MM/DD');
			} else {
				$scope.prtdata.prblmSbmtdDt = moment.utc($("#submitteddate").val(), 'MM/DD/YYYY').format('YYYY/MM/DD');
			}

			$scope.prtdata.prblmFixdDt = moment.utc($("#fixDate").val(), 'MM/DD/YYYY').format('YYYY/MM/DD');

			if ($scope.prtdata.prblmSbmtdDt == "Invalid date"
				|| new Date($scope.prtdata.prblmSbmtdDt) > new Date()) {
				alert("Invalid Submitted date")
				$scope.prtdata.prblmSbmtdDt = null;
				$.LoadingOverlay("hide");
				return;
			}
			if ($scope.prtdata.prblmFixdDt == "Invalid date")
				$scope.prtdata.prblmFixdDt = null;

			$scope.prtdata.actvInd = "Y";
			//		        $scope.prtdata.fpsPrblmAfctdSys = [];
			$scope.prtdata.loggedInUserId = $scope.uid;

			console.log('About to submit record! ', $scope.prtdata);

			utilFactory.postPRTData($scope.serviceURL, $scope.prtdata).then(function (prtdata) {
				console.log(prtdata.data)
				$scope.prtdata = prtdata.data;

				$scope.populateVaues();

				console.log('Record has been successfully Updated! ', prtdata.data);

				// Navigate back to
				// dashboard upon
				// successful submission
				// on the recrod.
				//			                          
				showGrowl(' Record has been succesfully submitted! ', 'success');
				$timeout(function () {
					//				        $location.path('/dashboard', true).search({});
					$.LoadingOverlay("hide");
				}, 2000);

			}, function (error) {

				console.log(error.data);
				showGrowl(' Record failed to submit ', 'danger');
				$.LoadingOverlay("hide");
			});

		}

		$scope.onSubmitValidation = function (prtdata) {

			/*if ($scope.nc(prtdata.stusCd) && $scope.nc(prtdata.issCtgryCd) && $scope.nc(prtdata.dfctCtgryCd) && $scope.nc(prtdata.fpsEditOwner) && $scope.nc(prtdata.macInfoTxt)
					&& $scope.nc(prtdata.modelCntrctr) && $scope.nc(prtdata.fpsEditName) && $scope.nc(prtdata.fpsEditNum)) {
				return true;
			}
			return false;*/

			if (prtdata != undefined)
				if ($scope.nc(prtdata.fpsEditOwner) && $scope.nc(prtdata.modelCntrctr) && $scope.nc(prtdata.fpsEditName) && $scope.nc(prtdata.fpsEditNum) && $scope.nc(prtdata.macInfoTxt)) {
					return true;
				}
			return false;
		}

		$scope.nc = function (str) {
			return (str != undefined && str != null && str != '') ? true : false;
		}

		/*
		 * JQuery Functions
		 * 
		 */


		$(function () {
			var date = new Date();
			var today = new Date(date.getFullYear(), date.getMonth(), date.getDate());
			var subdate = $("#submitteddate").datepicker(
				{ maxDate: today }
			);
			var fidate = $("#fixDate").datepicker({
				minDate: today
			});
		});

		/*
		 * Scope Initializer
		 */

		$scope.init = function () {

			// Load Reference Data
			utilFactory.getReferenceData($scope.serviceURL).then(function (refdata) {
				console.log(refdata.data)
				$scope.referenceData = refdata.data;
				console.log('Referencedata loadeded Succesfully! ');

				/*
				* Load the PRt data based on the id provided.
				*/
				//alert($scope.id)

				utilFactory.getPRTData($scope.serviceURL, $scope.id).then(function (prt) {
					console.log(prt.data)
					$scope.prtdata = prt.data;
					$scope.populateVaues();
					$scope.ifEditUdateAllowed = false;

					console.log('PRT Data loaded Successfully for the id - ', $scope.id);




					if ($scope.prtWrite || $scope.prtAdmin) {
						// Update/Edit allowed and His/Her OWN PR

						if ($scope.prtdata.audtInsrtId == $scope.uid) {
							$scope.ifEditUdateAllowed = true;
							console.log(" Update/Edit allowed and His/Her OWN PR");
						}

						// If Modeling Contractor listed in the PR
						if ($scope.prtdata.fpsEditOwner.indexOf($scope.fullName) != -1 ) {
							console.log("User is a Modeling Contractor listed in the PR");
							$scope.ifEditUdateAllowed = true;
						}
					}

					console.log('audtinsert id-', $scope.prtdata.audtInsrtId);
					console.log('uid -', $scope.uid);
					console.log("prtWrite -", $scope.prtWrite);
					console.log("prtAdmin -", $scope.prtAdmin);
					console.log("ifEditUdateAllowed -", $scope.ifEditUdateAllowed);
					console.log('fpsEditOwner -', $scope.prtdata.fpsEditOwner);
					console.log('Fn Lastname -', $scope.givenName, $scope.lastname);


				}, function (error) {
					console.log(error.data);
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Failed to load PRT data for the record id - ' + $scope.id, 'danger');
					$.LoadingOverlay("hide");
				});

			}, function (error) {

				console.log(error.data);
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Failed to load Reference data ', 'danger');
				$.LoadingOverlay("hide");
			});
			console.log("Initlization successful!");
		}


		$scope.upload = function () {

			if ($scope.filesArray != undefined && $scope.filesArray.length > 0 && undefined != $scope.filesArray[0].name) {

				console.log('File-->')
				console.dir($scope.filesArray[0]);


				//  	        		alert("FPS is a secure system, please upload unencrypted/not password protected documents not to exceed 1GB in size and in any of the following formats: .docx, .xlsx or .pdf only.");

				var fileName = $scope.filesArray[0].name;
				var nameLen = fileName.length;
				var lastDotPos = fileName.lastIndexOf(".");

				var fileNameExt = "";
				if ($scope.id == null || $scope.id == undefined) {
					alert("Please save the record and upload the document.");
				} else
					if (lastDotPos != -1) {
						//Remove +1 if you want the "." left too
						fileNameExt = fileName.substr(lastDotPos + 1, nameLen);
						console.log("Size =>", $scope.filesArray[0].size)

						if (fileNameExt == "xlsx" || fileNameExt == "pdf" || fileNameExt == "docx" || fileNameExt == "doc") {
							if ($scope.filesArray[0].size <= 1024 * 1024 * 1024) // 1 GB 
							{
								//  	 	        	    	alert($scope.filesArray[0].size <= 1024 * 1024 * 1024)
								var fd = new FormData();
								fd.append("file", $scope.filesArray[0]);

								utilFactory.uploadFile($scope.serviceURL, $scope.id, $scope.uid, fd).then(function (out) {
									console.log(out.data)
									if (out.data == "200" || out.data == "202")
										showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> File has been successfuly uploaded.', 'success');
									else showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Failed to upload. ', 'danger');

									$scope.loadAllDocuments();
									$.LoadingOverlay("hide");
									$scope.filesArray = [];
									$("#fileControl").val('');
									$window.document.getElementById('fileControl').focus();
								}, function (error) {
									console.log(error.data);
									showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Failed to upload. ', 'danger');
									$.LoadingOverlay("hide");
								});
							} else {
								alert("The file exceeds the file size limit of 1 GB.");
							}
						} else {
							alert("The file is not one of the acceptable following formats: .docx, .xlsx or .pdf only.");
						}
					}
			}
		};


		$scope.downloadFile = function (id, filename) {

			$.LoadingOverlay("show");

			console.log("==>", filename);
			//            	 var fileUrl =  $scope.fileDownloadURL+"/"+id;    
			var fileUrl = id;
			$timeout(function () {

				utilFactory.downloadFile($scope.serviceURL, fileUrl).then(function (filedownloadResp) {

					console.log(filedownloadResp);
					var octetStreamMime = 'application/octet-stream';


					//finally, download it
					try {
						//            			        var blob = new Blob([filedownloadResp.data], {type: filedownloadResp});
						var blob = filedownloadResp.data;
						//downloading the file depends on the browser
						//IE handles it differently than chrome/webkit
						if (window.navigator && window.navigator.msSaveOrOpenBlob) {
							window.navigator.msSaveOrOpenBlob(blob, filename);
							$.LoadingOverlay("hide");

						} else {
							var objectUrl = URL.createObjectURL(blob);
							//            			            window.open(objectUrl,'_blank');
							const link = document.createElement('a');
							link.href = objectUrl;
							link.setAttribute('download', filename);
							document.body.appendChild(link);
							link.click();
							$.LoadingOverlay("hide");
						}
					} catch (exc) {
						console.log("Save Blob method failed with the following exception.");
						console.log(exc);
						showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Failed to download the document', 'danger');
						$.LoadingOverlay("hide");
					}


				});
				//            		    window.open(utilFactory.downloadFile($scope.serviceURL, fileUrl), '_blank');
			}, 1);
		}


		$scope.deleteFile = function (id) {

			var r = confirm("Are you sure, you want to delete the file?");

			if (r == true) {

				$.LoadingOverlay("show");
				console.log("==>", id);
				var fileUrl = $scope.fileDownloadURL + "/" + id;
				// load URL
				utilFactory.deleteFile($scope.serviceURL, id, $scope.uid).then(function (deleteResp) {

					console.log("Delete File Resp=>", deleteResp);
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Document has been deleted successfully ', 'success');

					$scope.loadAllDocuments();
					$.LoadingOverlay("hide");


				}).catch(function (err) {
					console.log('deleteFile REST Error:' + err.data);
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Failed to upload the document', 'danger');
					$.LoadingOverlay("hide");
				});

			}
		}


		$scope.loadAllDocuments = function () {

			utilFactory.getAllFiles($scope.serviceURL, $scope.id).then(function (getAllFilesResp) {
				$scope.attachements = getAllFilesResp.data;
				for (x in $scope.attachements) {
					$scope.attachements[x].audtInsrtTs = moment.utc($scope.attachements[x].audtInsrtTs, 'YYYY-MM-DD').format('MM/DD/YYYY');
				}



			}).catch(function (err) {
			});

		}


		$scope.populateVaues = function () {
			// Populating dropdown values on
			// the screen
			$scope.problemPriorities = $scope.referenceData.problemPriorities.find(function (element) {
				return $scope.prtdata.prblmPrrtyCd == element.prblmPrrtyCd
			});

			$scope.statuses = $scope.referenceData.statuses.find(function (element) {
				return $scope.prtdata.stusCd == element.prodnPrblmRptStusCd;
			});
			$scope.issueCategories = $scope.referenceData.issueCategories.find(function (element) {
				return $scope.prtdata.issCtgryCd == element.issCtgryCd;
			});
			$scope.defectCategories = $scope.referenceData.defectCategories.find(function (element) {
				return $scope.prtdata.dfctCtgryCd == element.dfctCtgryCd;
			});
			$scope.claimCountRanges = $scope.referenceData.claimCountRanges.find(function (element) {
				return $scope.prtdata.clmCntRngCd == element.clmCntRngCd;
			});
			$scope.editNumbers = $scope.referenceData.editNumbers.find(function (element) {
				return $scope.prtdata.fpsEditNum == element.fpsEditNum;
			});
			$scope.macs = $scope.referenceData.macs.find(function (element) {
				return $scope.prtdata.macJrsdctnCd == element.macJrsdctnCd;
			});

			$scope.prtdata.prblmSbmtdDt = moment.utc($scope.prtdata.prblmSbmtdDt, 'YYYY/MM/DD').format('MM/DD/YYYY');
			$scope.prtdata.prblmFixdDt = moment.utc($scope.prtdata.prblmFixdDt, 'YYYY/MM/DD').format('MM/DD/YYYY');
			if ($scope.prtdata.prblmSbmtdDt == "Invalid date")
				$scope.prtdata.prblmSbmtdDt = null;
			if ($scope.prtdata.prblmFixdDt == "Invalid date")
				$scope.prtdata.prblmFixdDt = null;


			//		        console.log("AffectedSys-->",$scope.prtdata.fpsPrblmAfctdSys.length)		        
			for (x in $scope.prtdata.fpsPrblmAfctdSys) {

				var affSys = $scope.prtdata.fpsPrblmAfctdSys[x];
				const affectedSystem = $scope.referenceData.affectedSystems.find(function (element) {
					if (element.afctdSysCd == affSys.afctdSysCd) {
						element.isChecked = true;
						return true;
					} else return false;
				});
			}


			console.log("====>>>", $scope.prtdata.fpsFilStore);
			$scope.loadAllDocuments();
			//		        $scope.attachements = $scope.prtdata.fpsFilStore;
			for (x in $scope.attachements) {
				//		        		$scope.attachements[x].audtInsrtTs = moment.utc($scope.attachements[x].audtInsrtTs, 'YYYY/MM/DD').local().format('MM/DD/YYYY: mm:ss')
			}


		}



	}]);
