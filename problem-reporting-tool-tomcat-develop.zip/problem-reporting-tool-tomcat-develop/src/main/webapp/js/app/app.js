 var env = {};
  
// Import variables if present (from env.js)
if(window){
  Object.assign(env, window.__env);
}
var app = angular.module('prtApp', 
			[ 
			'app.routes', 
			'app.services', 
			'app.factory', 
			'app.constants', 
			'nav.module', 
			'admin.module',
			'dashboard.module',
			'add.module',
			'view.module',
			'file.directive'
			]);
app.constant('__env', env);