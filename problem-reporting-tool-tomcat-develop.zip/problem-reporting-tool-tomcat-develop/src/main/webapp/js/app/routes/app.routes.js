var app = angular.module('app.routes', [ 'ngRoute' ]);

app.config([ '$routeProvider', '$locationProvider',
        function ($routeProvider, $locationProvider) {

            $routeProvider.when('/dashboard', {
                templateUrl : "views/dashboard.html"
            }).when('/admin', {
                templateUrl : "views/admin.html"
            }).when('/view', {
                templateUrl : "views/view.html"
            }).when('/navbar', {
                templateUrl : "views/navbar.html"
            }).when('/add', {
                templateUrl : "views/add.html"
//            }).when('/', {
//                templateUrl : "views/dashboard.html"
//            }) .otherwise({
//                redirectTo : '/'  
            })
        } ]);



app.config([ '$httpProvider', function($httpProvider) {
	$httpProvider.interceptors.push('APIInterceptor');	
} ]);


app.service('APIInterceptor', function() {
var service = this;
service.request = function(config) {

	config.headers = config.headers || {};


   if (localStorage.getItem("okta-token-storage") != null
				&& localStorage.getItem("okta-token-storage") != undefined) {
		var oktatoken = JSON.parse(localStorage
				.getItem("okta-token-storage"));
		var accessToken = oktatoken["accessToken"]["accessToken"];
		var idToken = oktatoken["idToken"]["idToken"];

		if (accessToken) {
			config.headers.Authorization = 'Bearer ' + accessToken;
		}
		if (idToken) {
			config.headers.FPSAuthorization = 'Bearer ' + idToken;
		}

	}
	return config;

};
});