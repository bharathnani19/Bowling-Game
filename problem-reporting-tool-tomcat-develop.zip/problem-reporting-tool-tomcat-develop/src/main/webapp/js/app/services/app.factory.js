var app = angular.module('app.factory', []);

app.factory('utilFactory', [ '$http', '$timeout', '$rootScope', function($http, $timeout, $rootScope) {

	var factory = {

	    getServiceURL : function() {
			var config = {headers:  {
		        'Content-Type': 'text/plain',
		        'Accept': 'text/plain'
		   	 }
			};
		    return $http.get('LoadPropertiesFileServlet', config).success(function(data, status, headers, config) {
		    });
	    },

	    getCurrentUserAccess : function(sURL) {
	    	var restURL = sURL + '/rest/prt/currentUserAccess';
	    	console.log('factory.getCurrentUserAccess(). URL=>', restURL);
	    	return $http.get(restURL);
	    },

	    getPRTData : function(sURL, id) {
	    	
	    	//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
		    // create the json request object
		    var requestObj = {
			    prodnPrblmRptId : id
		    };
		    var restURL = sURL + '/rest/prt/getPRTData'
		    console.log('factory.getPRTData().  URL=>', restURL);
		    return $http.post(restURL, requestObj);
	    },

	    postPRTData : function(sURL, req) {
	    	//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		
		    var restURL = sURL + '/rest/prt/postPRTData'
		    console.log('factory.postPRTData().  URL=>', restURL);
		    return $http.post(restURL, req);
	    },
	    putPRTData : function(sURL, req) {
	    	//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		
		    var restURL = sURL + '/rest/prt/putPRTData'
		    console.log('factory.postPRTData().  URL=>', restURL);
		    return $http.post(restURL, req);
	    },


	    getReferenceData : function(sURL) {
	    	
		    var restURL = sURL + '/rest/prt/getReferenceData'
		    console.log('factory.getReferenceData().  URL=>', restURL);
		    return $http.post(restURL);
	    },

	    getAdminReferenceData : function(sURL) {
	    	//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		
		    var restURL = sURL + '/rest/prt/getAdminReferenceData'
		    console.log('factory.getAdminReferenceData().  URL=>', restURL);
		    return $http.post(restURL);
	    },

	    getSummaryData : function(sURL) {
	    	
	    	//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");

		    var restURL = sURL + '/rest/prt/getSummaryData'
		    console.log('factory.getSummaryData().  URL=>', restURL);
		    var req = {};
		    return $http.post(restURL, req);
	    },

	    postEditNumbers : function(sURL, req) {
	    	//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
		    var restURL = sURL + '/rest/prt/postEditNumbers'
		    console.log('factory.postEditNumbers().  URL=>', restURL);
		    return $http.post(restURL, req);
	    },
	    postAffectedSystems : function(sURL, req) {
	    	//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
		    var restURL = sURL + '/rest/prt/postAffectedSystems'
		    console.log('factory.postAffectedSystems().  URL=>', restURL);
		    return $http.post(restURL, req);
	    },
	    postStatuses : function(sURL, req) {
	    	//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
		    var restURL = sURL + '/rest/prt/postStatuses'
		    console.log('factory.postStatuses().  URL=>', restURL);
		    return $http.post(restURL, req);
	    },
	    postMacs : function(sURL, req) {
	    	//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		
		    var restURL = sURL + '/rest/prt/postMacs'
		    console.log('factory.postMacs().  URL=>', restURL);
		    return $http.post(restURL, req);
	    },
	    postProblemPriority : function(sURL, req) {
	    	//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
		    var restURL = sURL + '/rest/prt/postProblemPriority'
		    console.log('factory.postProblemPriority().  URL=>', restURL);
		    return $http.post(restURL, req);
	    },
	    postIssueCategory : function(sURL, req) {
	    	//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
		    var restURL = sURL + '/rest/prt/postIssueCategory'
		    console.log('factory.postIssueCategory().  URL=>', restURL);
		    return $http.post(restURL, req);
	    },
	    postClaimCount : function(sURL, req) {
	    	//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
		    var restURL = sURL + '/rest/prt/postClaimCount'
		    console.log('factory.postClaimCount().  URL=>', restURL);
		    return $http.post(restURL, req);
	    },
	    postDefectCategories : function(sURL, req) {
	    	//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
		    var restURL = sURL + '/rest/prt/postDefectCategories'
		    console.log('factory.postDefectCategories().  URL=>', restURL);
		    return $http.post(restURL, req);
	    },
	    postEmailNotify : function(sURL, req) {
	    	//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
		    var restURL = sURL + '/rest/prt/postEmailNotify'
		    console.log('factory.postEmailNotify().  URL=>', restURL);
		    return $http.post(restURL, req);
	    },
	    deletePRTList : function(sURL, req, uid) {
	    	
	    	//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
	    	
	    	// Split the list values to array
	    	var ids = req.toString().split(',');
        	var prtidsList = [];
	    
	    	
	    	for(i in ids) {				    		
	    		var obj = {
	    				prodnPrblmRptId : ids[i].toString(),
	    				loggedInUserId : uid
	    			};
	    		prtidsList.push(obj);
	    	}
	    	
		    console.log('prtidsList.  =>', prtidsList);
		    var restURL = sURL + '/rest/prt/deletePRTList'
		 	console.log('factory.deletePRTList().  URL=>', restURL);
		 	return  $http.post(restURL, prtidsList);		 
	    },
/* 
	    getUserInfo : function(sURL,token, cmsuserid) {
		    //create the json request object
		    var entryCriteria = {
			    userId : cmsuserid,
			    tokenId : token
		    };
		    //create the JSON object to be used in the REST Request
		    jsonData = JSON.stringify(entryCriteria);
		    //console.log('getDashboad REST request = ' + jsonData);
		    console.log('factory.getUserInfo => ' + sURL + '/rest/prt/getUserDetails');

		    //make the rest web service call to get the data
		    return $http.post(sURL + '/rest/prt/getUserInfo', jsonData);
	    },
	    
	    getAccessInfo : function(sURL, token, cmsuserid, ai) {
	    	//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
		    //create the json request object
		    var entryCriteria = {
		        userId : cmsuserid,
		        tokenId : token,
		        role : ai
		    };
		    //create the JSON object to be used in the REST Request
		    jsonData = JSON.stringify(entryCriteria);
		    //console.log('getDashboad REST request = ' + jsonData);
		    console.log('factory.getUserInfo => ' + sURL + '/rest/prt/getAccessInfo');

		    //make the rest web service call to get the data
		    return $http.post(sURL + '/rest/prt/getAccessInfo', jsonData);
	    },
	    
	    
	    getSessionInfo : function(pUrl, pToken) {
			//create the json request object
			var entryCriteria = {
				tokenId : pToken
			};

			//create the JSON object to be used in the REST Request
			console.log('factory.getSessionInfo() => ' + pUrl+'/rest/prt/sessionInfo');
			var jsonData = JSON.stringify(entryCriteria);
			return $http.post(pUrl + '/rest/prt/sessionInfo', jsonData);
		},
		 */
		
		uploadFile : function(pUrl,id, uid, form) {
			
			//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
			
			console.log("FORM =>",form)
			
			 var config = { headers: {'Content-Type': undefined},
                     transformRequest: angular.identity
                   }
			 var url = pUrl + '/rest/prt/uploadFile/'+id+"/"+uid;
			console.log('factory.uploadFile() => ' + url);
			return $http.post(url, form, config);	
		},
		
		deleteFile : function(pUrl,id, uid) {
			//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
			 var url = pUrl + '/rest/prt/deleteFile/'+id+"/"+uid;
			console.log('factory.deleteFile() => ' + url);
			return $http.post(url);	
		},
		
		getAllFiles : function(pUrl,prtid) {
			//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
			 var url = pUrl + '/rest/prt/getAllFiles/'+prtid;
			console.log('factory.getAllFile() => ' + url);
			return $http.post(url);	
		},
		downloadFile: function (pUrl,downladurl){
			//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		
			var url = pUrl + '/rest/prt/downloadFile';
			console.log('Download file initiated!',url);
			console.log('Download file from->',downladurl);
			return $http.post(url,downladurl,{responseType: "blob"});	
		},
		
		getPropertyValue: function (pURL, propName){
			
    		console.log('URL = ' + pURL + '/rest/prt/getPropertyValue');
    		console.log('Property Name = ' + propName );
    		//make the rest web service call to get the data
    		var config = {headers:  {
		        'Content-Type': 'text/plain',
		        'Accept': 'text/plain'
		   	 }
			};
    		return $http.post(pURL + '/rest/prt/getPropertyValue', propName, config);
		},
		
		getResetIdleTime: function(pUrl, pToken) {
			console.log("Inside appfactory.getResetIdleTime. pUrl = " + pUrl + ", pToken = " + pToken);
			
			//create the json request object
    		var entryCriteria = {
    			tokenId: pToken
    		};
    		
    		//create the JSON object to be used in the REST Request
    		var jsonData = JSON.stringify(entryCriteria);
    		console.log('getSessionInfo REST request = ' + jsonData);
    		
    		return $http.post(pUrl + '/rest/prt/resetIdleTime', jsonData);
		},
		getInvalidateSession: function(pUrl, pToken) {
			console.log("Inside appfactory.getInvalidateSession. pUrl = " + pUrl + ", pToken = " + pToken);
			
			//create the json request object
    		var entryCriteria = {
    			tokenId: pToken
    		};
    		
    		//create the JSON object to be used in the REST Request
    		var jsonData = JSON.stringify(entryCriteria);
    		console.log('getInvalidateSession REST request = ' + jsonData);
    		
    		return $http.post(pUrl + '/rest/prt/invalidateSession', jsonData);
		},
		
		getOktaConfig: function(url) {
			console.log("Inside appfactory.getOktaConfig. " ); 
			var url =url+ '/rest/prt/getOktaConfig';
			console.log("getOktaConfig->",url)
			return $http.get(url);
		},getHeaderInfo: function(pURL, pUserZone, pUserId) {
    		console.log("Inside navFactory.getHeaderInfo");
    		
    		//create the json request object
    		var entryCriteria = {
    			userZone: pUserZone,
    			userId: pUserId
    		};
    		  		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getHeaderInfo REST request = ' + jsonData);
    		
    		//make the rest web service call to get the data
    		return $http.post(pURL + '/rest/prt/navBarData', jsonData);
    	},
    	setMsgsAsReadByUser: function(pURL, pUserId) {
    		//notify web services that user clicked the sys msgs link in nav bar
    		console.log("Inside navFactory.setMsgsAsReadByUser");
    		
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {    			
    			userId: pUserId
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('setMsgsAsReadByUser REST request = ' + jsonData);
    		
    		//make the rest web service call to get the data
    		return $http.post(pURL + '/rest/prt/readMessages', jsonData);
    	},
		loadDocument: function(pURL) {
				console.log("Inside navFactory.loadDocument");
				
				// broadcast this event to the reset session listener
				$rootScope.$broadcast("factoryMethodCalled");
				config = {};
				
				$http.get(pURL,{ responseType: 'arraybuffer' }).then(function (response) {
					console.log("response " + response);

					var a = document.createElement("a");
					document.body.appendChild(a);
					a.style = "display: none";
					a.target = "_blank";
					//console.log(response.headers());
					var blobFileName = "";
					//var headerVal = response.headers('Content-Disposition');
					//if (headerVal){
					//	 headerVal.substring(headerVal.lastIndexOf('=')+1, headerVal.length-1);
					//}else{
						
						var queryString = pURL.substring(pURL.lastIndexOf('?')+1, pURL.length-1);
						var urlParams = new URLSearchParams(queryString);
						blobFileName = urlParams.get("fileName");
						//blobFileName= blobFileName.replace("\"", "");
					//}
					//var queryString = pURL.substring(pURL.lastIndexOf('?')+1, pURL.length-1);
					//var urlParams = new URLSearchParams(queryString);
					//var blobFileName = urlParams.get("fileName");
					//blobFileName= blobFileName.replace("\"", "");
					console.log(blobFileName);

					var contentType = response.headers('Content-Type');
					if (!contentType){
						contentType = "application/pdf";
					}
					console.log("contentType = " + contentType);

					var binaryData = response.data;
					if (navigator.msSaveBlob){
						//IE Browsers
						navigator.msSaveBlob(blob, blobFileName);
					} else {

					
						var blob = new Blob([binaryData], {type: contentType})
						var u = URL.createObjectURL(blob);
						a.href = u;
						a.download = blobFileName;
						a.click();
						URL.revokeObjectURL(u);
					}
			
				}).catch(function(e) {
					console.log('Error: ', e);
					throw e;
				});
				console.log('loadDocument REST request = ' + jsonData);
    		    		
    		
		},
		

	};

	return factory;
} ]);