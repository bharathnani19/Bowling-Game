var app = angular.module('app.constants', []);

app
		.constant(
				'utilConstants',
				{
					"getMACZones" : [  {
						name : "J5",
						value : "J5"
					}, {
						name : "J6",
						value : "J6"
					}, {
						name : "J8",
						value : "J8"
					}, {
						name : "J15",
						value : "J15"
					}, {
						name : "JA",
						value : "JA"
					}, {
						name : "JB",
						value : "JB"
					}, {
						name : "JC",
						value : "JC"
					}, {
						name : "JD",
						value : "JD"
					}, {
						name : "JE",
						value : "JE"
					}, {
						name : "JF",
						value : "JF"
					}, {
						name : "JH",
						value : "JH"
					}, {
						name : "JJ",
						value : "JJ"
					}, {
						name : "JK",
						value : "JK"
					}, {
						name : "JL",
						value : "JL"
					}, {
						name : "JM",
						value : "JM"
					}, {
						name : "JN",
						value : "JN"
					}, {
						name : "RRBSMAC",
						value : "RRBSMAC"
					} ],

					"getZones" : [ {
						name : "CMS",
						value : "CMS"
					}, {
						name : "CMS Admin User",
						value : "CMS Admin User"
					}, {
						name : "CSRA",
						value : "CSRA"
					}, {
						name : "IBM",
						value : "IBM"
					},  {
						name : "NG",
						value : "NG"
					}, {
						name : "UPIC MW",
						value : "UPIC MW"
					}, {
						name : "UPIC NE",
						value : "UPIC NE"
					}, {
						name : "UPIC SE",
						value : "UPIC SE"
					}, {
						name : "UPIC SW",
						value : "UPIC SW"
					}, {
						name : "UPIC W",
						value : "UPIC W"
					}, {
						name : "Other",
						value : "Other"
					} ],

					"getStates" : [ {
						name : "Alabama",
						value : "Alabama"
					}, {
						name : "Alaska",
						value : "Alaska"
					}, {
						name : "American Samoa",
						value : "American Samoa"
					}, {
						name : "Arizona",
						value : "Arizona"
					}, {
						name : "Arkansas",
						value : "Arkansas"
					}, {
						name : "California",
						value : "California"
					}, {
						name : "Colorado",
						value : "Colorado"
					}, {
						name : "Connecticut",
						value : "Connecticut"
					}, {
						name : "Delaware",
						value : "Delaware"
					}, {
						name : "District Of Columbia",
						value : "District Of Columbia"
					}, {
						name : "Federated results Of Micronesia",
						value : "Federated results Of Micronesia"
					}, {
						name : "Florida",
						value : "Florida"
					}, {
						name : "Georgia",
						value : "Georgia"
					}, {
						name : "Guam",
						value : "Guam"
					}, {
						name : "Hawaii",
						value : "Hawaii"
					}, {
						name : "Idaho",
						value : "Idaho"
					}, {
						name : "Illinois",
						value : "Illinois"
					}, {
						name : "Indiana",
						value : "Indiana"
					}, {
						name : "Iowa",
						value : "Iowa"
					}, {
						name : "Kansas",
						value : "Kansas"
					}, {
						name : "Kentucky",
						value : "Kentucky"
					}, {
						name : "Louisiana",
						value : "Louisiana"
					}, {
						name : "Maine",
						value : "Maine"
					}, {
						name : "Marshall Islands",
						value : "Marshall Islands"
					}, {
						name : "Maryland",
						value : "Maryland"
					}, {
						name : "Massachusetts",
						value : "Massachusetts"
					}, {
						name : "Michigan",
						value : "Michigan"
					}, {
						name : "Minnesota",
						value : "Minnesota"
					}, {
						name : "Mississippi",
						value : "Mississippi"
					}, {
						name : "Missouri",
						value : "Missouri"
					}, {
						name : "Montana",
						value : "Montana"
					}, {
						name : "Nebraska",
						value : "Nebraska"
					}, {
						name : "Nevada",
						value : "Nevada"
					}, {
						name : "New Hampshire",
						value : "New Hampshire"
					}, {
						name : "New Jersey",
						value : "New Jersey"
					}, {
						name : "New Mexico",
						value : "New Mexico"
					}, {
						name : "New York",
						value : "New York"
					}, {
						name : "North Carolina",
						value : "North Carolina"
					}, {
						name : "North Dakota",
						value : "North Dakota"
					}, {
						name : "Northern Mariana Islands",
						value : "Northern Mariana Islands"
					}, {
						name : "Ohio",
						value : "Ohio"
					}, {
						name : "Oklahoma",
						value : "Oklahoma"
					}, {
						name : "Oregon",
						value : "Oregon"
					}, {
						name : "Palau",
						value : "Palau"
					}, {
						name : "Pennsylvania",
						value : "Pennsylvania"
					}, {
						name : "Puerto Rico",
						value : "Puerto Rico"
					}, {
						name : "Rhode Island",
						value : "Rhode Island"
					}, {
						name : "South Carolina",
						value : "South Carolina"
					}, {
						name : "South Dakota",
						value : "South Dakota"
					}, {
						name : "Tennessee",
						value : "Tennessee"
					}, {
						name : "Texas",
						value : "Texas"
					}, {
						name : "Utah",
						value : "Utah"
					}, {
						name : "Vermont",
						value : "Vermont"
					}, {
						name : "Virgin Islands",
						value : "Virgin Islands"
					}, {
						name : "Virginia",
						value : "Virginia"
					}, {
						name : "Washington",
						value : "Washington"
					}, {
						name : "West Virginia",
						value : "West Virginia"
					}, {
						name : "Wisconsin",
						value : "Wisconsin"
					}, {
						name : "Wyoming",
						value : "Wyoming"
					} ],

					"getTypeOfAccess" : [ {
						name : "Inquiry Only",
						value : "Inquiry Only"
					}, {
						name : "PriortizeSup",
						value : "PriortizeSup"
					}, {
						name : "MAC",
						value : "MAC"
					} ],

					"getMACOptions" : [
							{
								name : "FPS ASR Prioritization",
								value : "rqstPrivFpsAsrInd",
								description : "Authorized to Prioritize ASRs.",
								selected : false
							},
							{
								name : "Vulnerability Management - Create",
								value : "rqstPrivVmCreateInd",
								description : "Create a Vulnerability Management Proposal Submitter can update only their Vulnerability in the Open and Information Needed Workflow status. Once the Vulnerability is sent to the CPI Lab, the Submitter cannot change it, unless CMS changes the status to Information Needed status.",
								selected : false
							}, {
								name : "Vulnerability Management - Read",
								value : "rqstPrivVmReadInd",
								description : "Read all Vulnerability Management Proposals that have been submitted in all Vulnerability Management Workflow status.",
								selected : false
							}, {
								name : "Edit Inquiry - Read",
								value : "rqstPrivPrtReadInd",
								description : "Read any Edit Inquiry submitted by the end-user. (MAC, CMS, Modeling contractor and NGC/CGS users only)",
								selected : false
							}, {
								name : "Edit Inquiry - Write",
								value : "rqstPrivPrtWriteInd",
								description : "Update a Edit Inquiry submitted by the end-user (MACs, CMS, NG/CGS, and Modeling Contractors users only) ",
								selected : false
							},

					],

					"getPriortizeSupOptions" : [
							{
								name : "Vulnerability Management - Create",
								value : "rqstPrivVmCreateInd",
								description : "Create a Vulnerability Management Proposal Submitter can update only their Vulnerability in the Open and Information Needed Workflow status. Once the Vulnerability is sent to the CPI Lab, the Submitter cannot change it, unless CMS changes the status to Information Needed status.",
								selected : false
							}, {
								name : "Vulnerability Management - Read",
								value : "rqstPrivVmReadInd",
								description : "Read all Vulnerability Management Proposals that have been submitted in all Vulnerability Management Workflow status.",
								selected : false
							}, {
								name : "Edit Inquiry - Read",
								value : "rqstPrivPrtReadInd",
								description : "Read any Edit Inquiry submitted by the end-user. (MAC, CMS, Modeling contractor and NGC/CGS users only)",
								selected : false
							}, {
								name : "Edit Inquiry - Write",
								value : "rqstPrivPrtWriteInd",
								description : "Update a Edit Inquiry submitted by the end-user (MACs, CMS, NG/CGS, and Modeling Contractors users only) ",
								selected : false
							},

					],
					"getInquiryOnlyOptions" : [

							{
								name : "Vulnerability Management - Create",
								value : "rqstPrivVmCreateInd",
								description : "Create a Vulnerability Management Proposal Submitter can update only their Vulnerability in the Open and Information Needed Workflow status. Once the Vulnerability is sent to the CPI Lab, the Submitter cannot change it, unless CMS changes the status to Information Needed status.",
								selected : false
							},
							{
								name : "Vulnerability Management - Read",
								value : "rqstPrivVmReadInd",
								description : "Read all Vulnerability Management Proposals that have been submitted in all Vulnerability Management Workflow status.",
								selected : false
							},
							{
								name : "Vulnerability Management - Update/Edit",
								value : "rqstPrivVmUpdateeditInd",
								description : "CMS User to Create, Read and Update All Vulnerability Management Proposals; the access can only allow user to move the Vulnerability forward in the workflow only.",
								selected : false
							},
							{
								name : "Vulnerability Management - Admin",
								value : "rqstPrivVmAdminInd",
								description : "CMS User and as an Administrator access to a Vulnerability Management Proposal data; user is authorized to Create, Read, Update and Delete all Vulnerability Management Proposals; role has the authorization to change the workflow status of a VM Proposal to any status regardless of workflow.",
								selected : false
							}, {
								name : "Edit Inquiry - Read",
								value : "rqstPrivPrtReadInd",
								description : "Read any Edit Inquiry submitted by the end-user. (MAC, CMS, Modeling contractor and NGC/CGS users only)",
								selected : false
							}, {
								name : "Edit Inquiry - Write",
								value : "rqstPrivPrtWriteInd",
								description : "Update a Edit Inquiry submitted by the end-user (MACs, CMS, NG/CGS, and Modeling Contractors users only) ",
								selected : false
							}, {
								name : "Edit Inquiry - Admin",
								value : "rqstPrivPrtAdminInd",
								description : "Create, Read, Update and Delete a Edit Inquiry (MACs, CMS, NG/CGS, and Modeling Contractors users only)",
								selected : false
							} ]

				});