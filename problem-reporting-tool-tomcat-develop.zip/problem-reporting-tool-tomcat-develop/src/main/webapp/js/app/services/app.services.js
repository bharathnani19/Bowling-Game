var app = angular.module('app.services', ['ngRoute', 'ngCookies']);

app.service('utilService', ['$cookies', '$http', 'utilFactory', function ($cookies, $http, utilFactory) {

	
	var authClient;
	var currentUserAccessProfile = null;
	// set the okta authClient object for use in all modules
	this.setOktaAuth = function () {
		// required okta config. SPA applications should use PKCE (default) flow, which doesn't use a client secret
			var config = angular.copy(__env.oktaConfig);
		config.tokenManager = config.tokenManager || {};
		//config.tokenManager.storage = 'sessionStorage';
		// invoke the okta auth client
		authClient = new OktaAuth(config);

		// check if the browser supports PKCE
		var pkceSupport = authClient.features.isPKCESupported();
		console.log('PKCE Support = ' + pkceSupport);

		return authClient;
	}
	
	/*this.setOktaAuth1 = function (config) {

		// invoke the okta auth client
		authClient = new OktaAuth(config);
		// check if the browser supports PKCE
		var pkceSupport = authClient.features.isPKCESupported();
		console.log('PKCE Support = ' + pkceSupport);
		return authClient;
	}
	utilFactory.getServiceURL().then(function (url) {
		console.log("url->",url.data);
		utilFactory.getOktaConfig(url.data).then(function (oktaconfig) {
			console.log("Okta ->",oktaconfig.data );
			
			// set the appropriate environment config
			var config = oktaconfig.data;
			var authClient = utilService.setOktaAuth1(config);
			oktaRedirect(authClient)			
			
		}).catch(function (err) {
			console.log(err)
		});
	}).catch(function (err) {
		console.log(err)
	});*/

	// get the okta token for use in other modules
	this.getOktaAuth = function () {
		return authClient;
	}

	this.setCurrentUserAccessProfile = function (profile) {
		currentUserAccessProfile = profile || null;
	}

	this.getCurrentUserAccessProfile = function () {
		return currentUserAccessProfile;
	}
	
	this.getTrainingUrl = function() {
		
		return __env.lmsUrl;
	}

}]);
