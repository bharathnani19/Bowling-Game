(function (window) {
  window.__env = window.__env || {};
  window.__env.env = "MODELDEV";
   window.__env.oktaConfig =   {
			// CMS Test Okta
			issuer:	'https://impl.idp.idm.cms.gov/oauth2/ausc24l2w5nTQczdY297',
			clientId: '0oac24ih3eJjmcmlk297',
			redirectUri: 'https://cloud.fpsportalmodeldev.cms.cmsval/FPS2UnifiedPortal/',
			postLogoutRedirectUri: 'https://cloud.fpsportalmodeldev.cms.cmsval/FPS2UnifiedPortal/',

			scopes: ['openid', 'profile', 'email'],
			state: 'fps-auth-state' // used to validate the OAuth response		   
		}
		
;
  


  

  window.__env.tableauRoot ="https://cloud.fpsreportsmodeldev.cms.cmsval/t/MTE/projects";
  
  window.__env.tableauVizURL =  "https://cloud.fpsreportsmodeldev.cms.cmsval/t/MTE/views/RiskScoreTrendingReport/RiskScoreTrendChart?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no&:jsdebug=n";
  
  window.__env.tableauModelAttr =  "https://cloud.fpsreportsmodeldev.cms.cmsval/t/MTE/views/ModelAttributeComparisonReport/ModelAttributeComparisonReport-TabularList?NPI=";

  window.__env.tableauEditTrend = "https://cloud.fpsreportsmodeldev.cms.cmsval/t/MTE/views/EditsTrendReport/EditsTrendReport?NPI=";
  
  window.__env.tableauProviderProfile = "https://cloud.fpsreportsmodeldev.cms.cmsval/t/MTE/views/ProviderProfile/ProviderInfo?ASRPTID=";
  
  window.__env.tableauChow = "https://cloud.fpsreportsmodeldev.cms.cmsval/t/MTE/views/ChangeinOwnershipCHOWReport/ChangeinOwnership?NPI=";
  
  window.__env.tableauProviderEdu = "https://cloud.fpsreportsmodeldev.cms.cmsval/t/MTE/views/ProviderEducationandModelAttribute/ProviderEducationReport?NPI=";
  
  window.__env.tableauProviderEduAttr = "https://cloud.fpsreportsmodeldev.cms.cmsval/t/MTE/views/ProviderEducationandModelAttribute/ProviderEducationandModelAttributeReport?NPI=";
  
  window.__env.lmsUrl = "https://cmsifislearning.csodfed.com/";
}(this));