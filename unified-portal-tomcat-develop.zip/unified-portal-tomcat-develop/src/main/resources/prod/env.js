(function (window) {
  window.__env = window.__env || {};
  window.__env.env="PROD";
  window.__env.oktaConfig = {
			
			issuer:	'https://idm.cms.gov/oauth2/auscoyy5hpZupmXGB297',
			clientId: '0oacoyv2pq9YMwnYe297',
			redirectUri: 'https://cloud.fpsportal.cmsnet/FPS2UnifiedPortal/',
			postLogoutRedirectUri: 'https://cloud.fpsportal.cmsnet/FPS2UnifiedPortal/',

			scopes: ['openid', 'profile', 'email'],
			state: 'fps-auth-state' // used to validate the OAuth response		   
		}
;
  
  window.__env.tableauRoot ="https://cloud.fpsreports.cmsnet";
  
  window.__env.tableauVizURL =  "https://cloud.fpsreports.cmsnet/t/Prod/views/RiskScoreTrendingReport/RiskScoreTrendChart?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no&:jsdebug=n";
  
  window.__env.tableauModelAttr =  "https://cloud.fpsreports.cmsnet/t/Prod/views/ModelAttributeComparisonReport/ModelAttributeComparisonReport-TabularList?NPI=";

  window.__env.tableauEditTrend = "https://cloud.fpsreports.cmsnet/t/Prod/views/EditsTrendReport/EditsTrendReport?NPI=";
  
  window.__env.tableauProviderProfile = "https://cloud.fpsreports.cmsnet/t/Prod/views/ProviderProfile/ProviderInfo?ASRPTID=";
  
  window.__env.tableauChow = "https://cloud.fpsreports.cmsnet/t/Prod/views/ChangeinOwnershipCHOWReport/ChangeinOwnership?NPI=";
  
  window.__env.tableauProviderEdu = "https://cloud.fpsreports.cmsnet/t/Prod/views/ProviderEducationandModelAttribute/ProviderEducationReport?NPI=";
  
  window.__env.tableauProviderEduAttr = "https://cloud.fpsreports.cmsnet/t/Prod/views/ProviderEducationandModelAttribute/ProviderEducationandModelAttributeReport?NPI=";
  
  window.__env.lmsUrl = "https://cmsifislearning.csodfed.com/";
    
  window.__env.editsandModelsLifecycleUrl = "https://cloud.fpsportal.cmsnet/eml/";

 
}(this));