(function (window) {
  window.__env = window.__env || {};
  window.__env.env = "VAL";
    window.__env.oktaConfig =  {
			// CMS IMPL Okta
			issuer:	'https://impl.idp.idm.cms.gov/oauth2/ausc24l2w5nTQczdY297',
			clientId: '0oac24ih3eJjmcmlk297',
			redirectUri: 'https://cloud.fpsportal.cms.cmsval/unified-portal/',
			postLogoutRedirectUri: 'https://cloud.fpsportal.cms.cmsval/unified-portal/',

			scopes: ['openid', 'profile', 'email'],
			state: 'fps-auth-state' // used to validate the OAuth response		   
		}
		
;
  
  

  window.__env.tableauRoot ="https://cloud.fpsreports.cms.cmsval/t/Val/projects";
  
  window.__env.tableauVizURL =  "https://cloud.fpsreports.cms.cmsval/t/Val/views/RiskScoreTrendingReport/RiskScoreTrendChart?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no&:jsdebug=n";
  
  window.__env.tableauModelAttr =  "https://cloud.fpsreports.cms.cmsval/t/Val/views/ModelAttributeComparisonReport/ModelAttributeComparisonReport-TabularList?NPI=";

  window.__env.tableauEditTrend = "https://cloud.fpsreports.cms.cmsval/t/Val/views/EditsTrendReport/EditsTrendReport?NPI=";
  
  window.__env.tableauProviderProfile = "https://cloud.fpsreports.cms.cmsval/t/Val/views/ProviderProfile/ProviderInfo?ASRPTID=";
  
  window.__env.tableauChow = "https://cloud.fpsreports.cms.cmsval/t/Val/views/ChangeinOwnershipCHOWReport/ChangeinOwnership?NPI=";
  
  window.__env.tableauProviderEdu = "https://cloud.fpsreports.cms.cmsval/t/Val/views/ProviderEducationandModelAttribute/ProviderEducationReport?NPI=";
  
  window.__env.tableauProviderEduAttr = "https://cloud.fpsreports.cms.cmsval/t/Val/views/ProviderEducationandModelAttribute/ProviderEducationandModelAttributeReport?NPI=";
  
    window.__env.lmsUrl = "https://cmsifislearning.csodfed.com/";
    
    window.__env.editsandModelsLifecycleUrl = "https://cloud.fpsportal.cms.cmsval/eml/";

}(this));