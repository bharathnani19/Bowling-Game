(function (window) {
  window.__env = window.__env || {};
  window.__env.env = "DEV";
  window.__env.oktaConfig = {

			// CMS Test Okta
			issuer:	'https://test.idp.idm.cms.gov/oauth2/ausbbjql1yRIpm9yt297',
			clientId: '0oabbjqacsMm5sZO2297',
			redirectUri: 'https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com/unified-portal/',
			postLogoutRedirectUri: 'https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com/unified-portal/',
		    scopes: ['openid', 'profile', 'email'],
		    state: 'fps-auth-state', // used to validate the OAuth response		    
//		    tokenManager: {
//		    	autoRenew: false,
//				autoRemove: false
//		    },
			
			// set responseType and pkce to use authorization code flow
		    // responseType: 'code',
		    // pkce: false,
		    devMode: true
		}
;
  
  


  window.__env.tableauRoot = "http://dtab1.awscloud.cms.local:8000/#/signin?redirect=%2Fsite%2FVal/";
  
  window.__env.tableauVizURL  = "https://reports.fpsportal.cms.cmstest/#/views/RiskScoreTrendingReport/RiskScoreTrendChart?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no&:jsdebug=n"; 
  
  window.__env.tableauModelAttr =  "http://dtab1.awscloud.cms.local:8000/#/views/ModelAttributeComparisonReport/ModelAttributeComparisonReport-TabularList?NPI=";

  window.__env.tableauEditTrend  = "http://dtab1.awscloud.cms.local:8000/#/views/EditsTrendReport/EditsTrendReport?NPI=";
  
  window.__env.tableauProviderProfile  = "http://dtab1.awscloud.cms.local:8000/#/views/ProviderProfile/ProviderInfo?ASRPTID=";
  
  window.__env.tableauChow = "http://dtab1.awscloud.cms.local:8000/#/views/ChangeinOwnershipCHOWReport/ChangeinOwnership?NPI=";
  
  window.__env.tableauProviderEdu = "http://dtab1.awscloud.cms.local:8000/#/views/ProviderEducation/ProviderEducationReport?NPI=";
  
  window.__env.tableauProviderEduAttr = "http://dtab1.awscloud.cms.local:8000/#/views/ProviderEducation/ProviderEducationandModelAttributeReport?NPI=";
  
  window.__env.lmsUrl = "https://cmsifislearning.csodfed.com/";
  
  window.__env.editsandModelsLifecycleUrl = "https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com/eml/";

  
  

}(this));