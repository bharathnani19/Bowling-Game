package com.cms.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nimbusds.jwt.proc.BadJWTException;
import com.nimbusds.oauth2.sdk.ParseException;
import com.okta.jwt.JoseException;
import com.okta.jwt.Jwt;
import com.okta.jwt.JwtHelper;
import com.okta.jwt.JwtVerifier;

@WebFilter(filterName = "jwtFilter", urlPatterns = {"/rest/*", "/js/*"})
public class JwtFilter implements Filter {
	private JwtVerifier jwtVerifier;
	private static final Logger logger = Logger.getLogger(JwtFilter.class.getName());


	public void init(FilterConfig filterConfig) {
		String issuer = "";
		String client = "";
		try {
			Properties properties = new Properties();
			String propFileName = "portal.properties";
			InputStream inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
			if (inputStream != null) {
				properties.load(inputStream);
				issuer = properties.getProperty("issuerUrl");
				client = properties.getProperty("clientId");
				inputStream.close();
			} else {
				throw new FileNotFoundException("Property file " + propFileName + " not found in the classpath.");
			}

			jwtVerifier = new JwtHelper().setIssuerUrl(issuer)
					.setClientId(client).setAudience("fraudps").build();
			logger.warning( "Configuring JWT Verifier success!");
		} catch (IOException e) {
			logger.log(Level.SEVERE, "Configuring JWT Verifier failed!", e);
			
		} catch (ParseException e) {
			logger.log(Level.SEVERE, "Configuring JWT Verifier failed!", e);
			
			
		}
	}

	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;
		logger.fine("In JwtFilter, path: " + request.getRequestURI());

		// Get access token from authorization header
		String authHeader = request.getHeader("authorization");
		if (authHeader == null) {
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access denied.");
			logger.warning( "Authorization header is null");
			return;
		} else {
			String accessToken = authHeader.substring(authHeader.indexOf("Bearer ") + 7);
			try {
				if (jwtVerifier == null) {
					logger.warning( "jwtVerifier null, reconfiguring");
					init(null);
				}
				Jwt jwt = jwtVerifier.decodeAccessToken(accessToken);

			} catch (JoseException e) {
				if (e.getCause() instanceof BadJWTException) {
					BadJWTException be = (BadJWTException) e.getCause();
					if (!"Expired JWT".equals(be.getMessage())) {
						logger.log(Level.SEVERE, "Error parsing token", e);
						response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access denied.");
						return;
					}
				}else {
					response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access denied.");
					return;
				}
			}
		}
		
		chain.doFilter(request, response);
	}

	public void destroy() {
	}
	
	public static void main(String[] args) throws ParseException, IOException {
		
	}
}
