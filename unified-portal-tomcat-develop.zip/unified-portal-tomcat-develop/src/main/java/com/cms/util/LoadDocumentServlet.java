package com.cms.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LoadDocumentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final Logger logger = LogManager.getLogger(LoadDocumentServlet.class);
//	private static final String FILE_DIRECTORY = "c:/portalDocs/";  //local testing
//	private static final String FILE_DIRECTORY = "portalDocs/";  //WAS Dev, VAL, MTE, PROD servers
	
	//constructor
	public LoadDocumentServlet(){}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		logger.debug("Inside LoadDocumentServlet.doGet()");
		boolean auth = JwtUtil.getInstance().verifyUser(request.getHeader("Authorization"), request.getParameter("userId"));
		if (!auth) {
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
//			response.getWriter().write("Unauthorized.");
		}

		//get the ucmURL property from the portal properties file
		PropertyFileHandler pfh = new PropertyFileHandler();
		String ucmUrlStr = pfh.getPortalProperty("ucmURL");
		
		if (!ucmUrlStr.isEmpty()) {
			//get the filename parameter from the URL
			String pFilenameParam = request.getParameter("fileName");
			String pUserId = request.getParameter("userId");
			
			//check to see if the filename parameter exists
			if (pFilenameParam != null && !pFilenameParam.isEmpty()) {
				//process the parameter and retreive the file
				logger.debug("Doc URL = " + ucmUrlStr + "/rest/modeldocs/" + pFilenameParam + "?userId=" + pUserId);
				
				//only retrieve files if the parameter request is for 
				if ((pFilenameParam.contains(".pdf") || pFilenameParam.contains(".docx") || pFilenameParam.contains(".xlsx")) && (!pFilenameParam.contains(".."))) {
					
					//make a connection to the web services model guidance documents servlet
					URL url = new URL(ucmUrlStr + "/rest/modeldocs/" + pFilenameParam + "?userId=" + pUserId);
					HttpURLConnection connection = (HttpURLConnection)url.openConnection();
					connection.setRequestMethod("GET");
					connection.setRequestProperty("Authorization", request.getHeader("Authorization"));
					connection.setDoOutput(true);
					
					InputStream is = null;
					
					try {
						//convert the response to an Input Stream
						is = connection.getInputStream();
						
						logger.debug("Response Code:  " + connection.getResponseCode());
						if (connection.getResponseCode() == 200) {
							
							//valid response from server received
							int length = 10240;
							
							//create a byte array with estimated length of the file
							byte[] bytes =  new byte[length];
							
							if(pFilenameParam.contains(".xlsx")){
								response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
								response.setHeader("Content-Disposition", "inline; filename=\"" + pFilenameParam + "\"");
								//response.setContentLength(length);
							}else {
								response.setContentType("application/pdf");
								response.setHeader("Content-Disposition", "inline; filename=\"" + pFilenameParam + "\"");
	
							}
							
							//create the output stream attached to the response
							ServletOutputStream os = response.getOutputStream();						
							
							//write the file until all the bytes are empty
							while ((length = is.read(bytes)) != -1) {
								os.write(bytes, 0, length);
							}
							os.flush();
							os.close();
												
							
						} else {
							//invalid response from server received
							logger.debug("Did not receive 200 response from web services");
							response.getWriter().write("File not found.");
						}
						
					} catch (FileNotFoundException ex) {
						logger.debug("Error: " + ex);
						response.getWriter().write("File not found.");
					} finally {
						try {
							if (is != null){
								logger.debug("is equals null.");
								is.close();
							}
												
						} catch (IOException ex) {
							logger.debug("Error: " + ex);
						}
					}	
					
				} else {				
					logger.debug("Access to that file type is unauthorized");
					response.getWriter().write("Unauthorized.");
				}
			}
		}
	
	}
}
