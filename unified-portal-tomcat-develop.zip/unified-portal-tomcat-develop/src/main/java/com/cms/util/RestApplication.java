package com.cms.util;



import com.cms.fps2.service.UnifiedPortalRestService;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

import java.util.HashSet;
import java.util.Set;

//@ApplicationPath("/rest/*")
public class RestApplication {//extends Application {
    public RestApplication() {
    	System.out.println("application started");
    }

   // @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> s = new HashSet<Class<?>>();
        s.add(UnifiedPortalRestService.class);
        System.out.println("application started2");
        return s;
    }

}
