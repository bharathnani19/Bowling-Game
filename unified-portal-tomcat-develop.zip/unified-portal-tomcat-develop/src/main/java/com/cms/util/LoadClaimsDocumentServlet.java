package com.cms.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;

import jakarta.servlet.ServletException;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.logging.LoggingFeature;

import com.fasterxml.jackson.jaxrs.json.JacksonJaxbJsonProvider;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response.Status;




public class LoadClaimsDocumentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final Logger logger = LogManager.getLogger(LoadDocumentServlet.class);

	// constructor
	public LoadClaimsDocumentServlet() {
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String token = request.getParameter("token");
		boolean goodToken = JwtUtil.INSTANCE.verifyToken(token);
		if (!goodToken) {
			logger.info("invalid token");
			response.sendError(403, "Unable to access resource");
			return;
		}
		
		// get the ucmURL property from the portal properties file
		PropertyFileHandler pfh = new PropertyFileHandler();
		String ucmUrlStr = pfh.getPortalProperty("ucmURL");

		if (!ucmUrlStr.isEmpty()) {
			// get the ASR Id parameter from the URL
			String pAsrIdParam = request.getParameter("asrId");
			String pUserId = request.getParameter("userId");
			String pSearchType = request.getParameter("searchType");
			String pSearchObj = request.getParameter("searchObj");
			String pProgramType = request.getParameter("programType");

			// decode the filename parameter
			byte[] decodedFileNameObj = Base64.getDecoder().decode(request.getParameter("fileName"));
			String pFileName = new String(decodedFileNameObj);
			String urlPrefix = "/rest/asr";
			if ("medicaid".equals(pProgramType)) {
				urlPrefix = "/rest/mdcd/asr";
			}
			// check to see if the filename parameter exists
			if (pAsrIdParam != null && !pAsrIdParam.isEmpty()) {
				 ClientConfig defaultClientConfig = new ClientConfig();
//		        defaultClientConfig.getClasses().add(JacksonJaxbJsonProvider.class);
		        //defaultClientConfig.getFeatures().put("com.sun.jersey.api.json.POJOMappingFeature", Boolean.TRUE);
				ClientConfig clientConfig = new ClientConfig();
				clientConfig.property(LoggingFeature.LOGGING_FEATURE_VERBOSITY_CLIENT,
						LoggingFeature.Verbosity.PAYLOAD_ANY);
		        Client client = ClientBuilder.newClient(defaultClientConfig);


				WebTarget webResource = null;

				jakarta.ws.rs.core.Response clientResponse = null;

				// check the search type to determine which web service to call
				if ("claimsAtRisk".equals(pSearchType)) {
					// conduct claims at risk claims search
					webResource = client
							.target(ucmUrlStr + urlPrefix + "/claims/" + pAsrIdParam + "?userId=" + pUserId);
					
					clientResponse = webResource.request().header("Content-Type", "application/json").get();
				} else if ("latest".equals(pSearchType)) {
					// decode the search request
					byte[] decodedSearchObj = Base64.getDecoder().decode(pSearchObj);
					// logger.debug("Decoded Search Obj = " + decodedSearchObj);

					// conduct latest claims search
					webResource = client.target(ucmUrlStr + urlPrefix + "/claimsexport" + "?userId=" + pUserId);

					

					clientResponse = webResource.request().header("Content-Type", "application/json")
							.post(Entity.entity(new String(decodedSearchObj), MediaType.APPLICATION_JSON));
				}
				else if ("latestP1".equals(pSearchType)) {
					 logger.debug("Latest p1");
					// conduct latest claims search
					webResource = client.target(ucmUrlStr + urlPrefix + "/claims/p1/"  + pAsrIdParam + "?userId=" + pUserId);
				
					clientResponse = webResource.request().header("Content-Type", "application/json").get();
				}
				else if ("p1cost".equals(pSearchType)) {
					logger.debug("P1Cost");
					// conduct latest claims search
					webResource = client.target(ucmUrlStr + urlPrefix + "/claims/p1cost/"  + pAsrIdParam + "?userId=" + pUserId);
				
					clientResponse = webResource.request().header("Content-Type", "application/json").get();
				} else if ("partd".equals(pSearchType)) {
					// conduct part d claims search
					webResource = client
							.target(ucmUrlStr + urlPrefix + "/claims/partd/" + pAsrIdParam + "?userId=" + pUserId);
				
					clientResponse = webResource.request().header("Content-Type", "application/json").get();
				} else if ("drilly".equals(pSearchType)) {
					// get the drill URL params
					String pNpi = request.getParameter("npi");
					String pModelId = request.getParameter("modelId");
					String pAttrNum = request.getParameter("attrNum");

					// conduct drill claims export
					webResource = client.target(ucmUrlStr + urlPrefix + "/rptcard/" + pModelId + "/" + pNpi
							+ "/claimsd/" + pAttrNum + "/csv?userId=" + pUserId);

					clientResponse = webResource.request().header("Content-Type", "application/json").get();
				} else if ("drilln".equals(pSearchType)) {
					// get the drill URL params
					String pNpi = request.getParameter("npi");
					String pModelId = request.getParameter("modelId");
					String pAttrNum = request.getParameter("attrNum");
					String pState = request.getParameter("state");
					String urlPrefix2 = "/rptcard/" + pModelId + "/" + pNpi + "/claims";
					if ("medicaid".equals(pProgramType)) {
						urlPrefix2 += "/" + pState;
					}
					urlPrefix2 += "/" + pAttrNum;
					// conduct drill claims export
					webResource = client.target(ucmUrlStr + urlPrefix + urlPrefix2 + "/csv?userId=" + pUserId);

					
					clientResponse = webResource.request().header("Content-Type", "application/json").get();
				} else if ("alerty".equals(pSearchType)) {
					// get the alert URL params
					String pModelId = request.getParameter("modelId");

					webResource = client.target(ucmUrlStr + urlPrefix + "/claims/partd/" + pModelId + "/" + pAsrIdParam
							+ "/csv?userId=" + pUserId);

					clientResponse = webResource.request().header("Content-Type", "application/json").get();
				} else if ("alertn".equals(pSearchType)) {
					// get the drill URL params
					String pModelId = request.getParameter("modelId");
					String pState = request.getParameter("state");
					String urlPrefix2 = "/claims/" + pModelId + "/" + pAsrIdParam;
					if ("medicaid".equals(pProgramType)) {
						urlPrefix2 += "/" + pState;
					}
					webResource = client.target(ucmUrlStr + urlPrefix + urlPrefix2 + "/csv?userId=" + pUserId);

					clientResponse = webResource.request().header("Content-Type", "application/json").get();

				}

				// process the response
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					// close the response due to bad connection
					clientResponse.close();

					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ clientResponse.getStatusInfo().getReasonPhrase());
				} else {
					// REST Call was successful
					String allClaimsFileRespStr = clientResponse.readEntity(String.class);
					// logger.debug("allClaimsFileRespStr = " + allClaimsFileRespStr);

					// turn the base64 file into a byte array
					byte[] decodedBytes = Base64.getDecoder().decode(allClaimsFileRespStr);

					InputStream is = new ByteArrayInputStream(decodedBytes);
					int length = 10240;

					response.setContentType("text/csv");
					response.setHeader("Content-Disposition", "attachment; filename=\"" + pFileName + "\"");

					// create the output stream attached to the response
					ServletOutputStream os = response.getOutputStream();

					// write the file until all the bytes are empty
					while ((length = is.read(decodedBytes)) != -1) {
						os.write(decodedBytes, 0, length);
					}
					os.flush();
					os.close();
				}
			}
		}
	}

}
