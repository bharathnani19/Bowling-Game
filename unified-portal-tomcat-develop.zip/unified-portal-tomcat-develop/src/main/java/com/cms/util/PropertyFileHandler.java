package com.cms.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cms.fps2.service.UnifiedPortalRestService;

public class PropertyFileHandler {
	
	final static String propFileName = "portal.properties";
	final static Logger logger = LogManager.getLogger(UnifiedPortalRestService.class);
	
	//empty constructor
	public PropertyFileHandler() {}
	
	public String getPortalProperty(String pPropertyName) throws IOException {
		String oPropertyValue = "";
		InputStream inputStream = null;
		
		try {
			
			Properties properties = new Properties();			
			inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
			
			if (inputStream != null) {
				properties.load(inputStream);
				oPropertyValue = properties.getProperty(pPropertyName);
				logger.debug(pPropertyName + " property value from file = " + oPropertyValue);
				//inputStream.close();
			} else {
				throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath.");
			}
			
		} finally {
			//close input stream if not null
		//	if (inputStream != null) {
		//		inputStream.close();
		//	}			
		}
		
		return oPropertyValue;
		
	}

}
