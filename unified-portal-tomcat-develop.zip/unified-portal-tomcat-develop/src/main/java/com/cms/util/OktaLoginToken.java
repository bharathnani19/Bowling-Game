package com.cms.util;

import java.io.Serializable;

public class OktaLoginToken implements Serializable {

	private OktaLoginTokenFields event;
	private String sourcetype="_json";
	
	public OktaLoginTokenFields getEvent() {
		return event;
	}
	public void setEvent(OktaLoginTokenFields event) {
		this.event = event;
	}
	public String getSourcetype() {
		return sourcetype;
	}
	public void setSourcetype(String sourcetype) {
		this.sourcetype = sourcetype;
	}
}
