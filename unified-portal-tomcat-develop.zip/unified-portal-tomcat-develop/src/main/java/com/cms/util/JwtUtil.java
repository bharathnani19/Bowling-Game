package com.cms.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.nimbusds.jwt.proc.BadJWTException;
import com.nimbusds.oauth2.sdk.ParseException;
import com.okta.jwt.JoseException;
import com.okta.jwt.Jwt;
import com.okta.jwt.JwtHelper;
import com.okta.jwt.JwtVerifier;

//@Component(value="jwtUtil")
public class JwtUtil {
	private  JwtVerifier jwtVerifier;
	final static Logger logger = LogManager.getLogger(JwtUtil.class);
	public static JwtUtil INSTANCE = new JwtUtil();
	private JwtUtil() {
		String issuer = "";
		String client = "";

		try {
			Properties properties = new Properties();
			String propFileName = "portal.properties";
			InputStream inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
			if (inputStream != null) {
				properties.load(inputStream);
				issuer = properties.getProperty("issuerUrl");
				client = properties.getProperty("clientId");
				inputStream.close();
			} else {
				throw new FileNotFoundException("Property file " + propFileName + " not found in the classpath.");
			}

			jwtVerifier = new JwtHelper().setIssuerUrl(issuer).setClientId(client).setAudience("fraudps").build();
		logger.warn( "Configuring JWT Verifier success!");
		} catch (IOException e) {
		logger.log(Level.ERROR, "Configuring JWT Verifier failed!", e);

		} catch (ParseException e) {
		logger.log(Level.ERROR, "Configuring JWT Verifier failed!", e);

		}
	}
	public  boolean verifyUser(String accessToken, String userId) {
		try {
			if (accessToken == null) {
				return false;
			}
			String parsedToken = accessToken.substring(accessToken.indexOf("Bearer ") + 7);
			Jwt jwt = jwtVerifier.decodeAccessToken(parsedToken);
			Object tokenUser =  jwt.getClaims().get("sub");
//			logger.debug("token = " + parsedToken);
			if (tokenUser != null) {
				if (userId.equals(tokenUser.toString())) {
					return true;
				}
			}

		} catch (JoseException e) {
			if (e.getCause() instanceof BadJWTException) {
				BadJWTException be = (BadJWTException) e.getCause();
				if (!"Expired JWT".equals(be.getMessage())) {
					logger.error("Error parsing jwt", e);
				}else {
					return true;
				}
			}else {
				logger.error("Error parsing jwt", e);

			}
		}
		return false;
	}
	public String getUser(String accessToken) {

		try {
			String parsedToken = accessToken.substring(accessToken.indexOf("Bearer ") + 7);
			Jwt jwt = jwtVerifier.decodeAccessToken(parsedToken);
			Object tokenUser = jwt.getClaims().get("preferred_username");
			return tokenUser.toString();
		} catch (JoseException e) {
			e.printStackTrace();
			
		}
		return "";

	}
	public boolean verifyToken(String accessToken) {
		if (StringUtils.isBlank(accessToken)) {
			return false;
		}
		try {
			Jwt jwt = jwtVerifier.decodeAccessToken(accessToken);
			Object tokenUser = jwt.getClaims().get("sub");
			return true;
		} catch (JoseException e) {
			if (e.getCause() instanceof BadJWTException) {
				BadJWTException be = (BadJWTException) e.getCause();
				if (!"Expired JWT".equals(be.getMessage())) {
					logger.error("Error parsing jwt", e);
				}else {
					return true;
				}
			}else {
				logger.error("Error parsing jwt", e);

			}
			
		}
		return false;

	}
	public static JwtUtil getInstance() {
		return INSTANCE;
	}
	
}
