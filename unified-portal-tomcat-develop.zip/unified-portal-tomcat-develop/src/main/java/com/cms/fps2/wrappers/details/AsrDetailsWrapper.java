package com.cms.fps2.wrappers.details;


import com.cms.fps2.wrappers.details.ResponseData;


public class AsrDetailsWrapper {
	private ResponseData responseData = new ResponseData();
	private String transactionID;
	private String status;
	private String responseType;
	
	//constructor
	public AsrDetailsWrapper() {}
	
	//responseData
	public ResponseData getResponseData() {
		return responseData;
	}
	
	public void setResponseData(ResponseData responseData) {
		this.responseData = responseData;
	}
	
	//transactionID	
	public String getTransactionID() {
		return transactionID;
	}
	
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	
	//status
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	//responseType
	public String getResponseType() {
		return responseType;
	}
	
	public void setResponseType(String responseType) {
		this.responseType = responseType;
	}
	
	
}
