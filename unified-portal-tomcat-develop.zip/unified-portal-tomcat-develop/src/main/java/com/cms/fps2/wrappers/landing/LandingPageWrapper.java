package com.cms.fps2.wrappers.landing;

import java.util.ArrayList;
import java.util.List;
//import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.cms.fps2.wrappers.details.Models;
import com.cms.fps2.wrappers.nav.Requests;

//@JsonIgnoreProperties(ignoreUnknown=true)
public class LandingPageWrapper {
	
	private List<Outages> outages = new ArrayList<Outages>();
	private List<Messages> messages = new ArrayList<Messages>();
	private AsrManagementReport asrManagementReport;
	private List<Statuses> statuses = new ArrayList<Statuses>();
	private List<Models> models = new ArrayList<Models>();
	private List<Requests> requests = new ArrayList<Requests>();
	private String newSysMsgCt;
	private List<Models> nonActiveModels = new ArrayList<Models>();
	private List<Reports> reports = new ArrayList<Reports>();
	private List<Faqs> faqs = new ArrayList<Faqs>();
	private List<Watchlist> watchlists = new ArrayList<Watchlist>();
	private List<Models> modelsMdcd = new ArrayList<Models>();
	private List<Models> nonActiveModelsMdcd = new ArrayList<Models>();
	
	private String defaultAsrView;
	
	//constructor
	public LandingPageWrapper(){}
	
	//outages
	public List<Outages> getOutages() {
		return outages;
	}
	
	public void setOutages(List<Outages> outages) {
		this.outages = outages;
	}
	
	//outages
	public List<Messages> getMessages() {
		return messages;
	}
	
	public void setMessages(List<Messages> messages) {
		this.messages = messages;
	}
	
	//asrManagementReport
	public AsrManagementReport getAsrManagementReport() {
		return asrManagementReport;
	}
	
	public void setAsrManagementReport(AsrManagementReport asrManagementReport) {
		this.asrManagementReport = asrManagementReport;
	}
	
	//statuses
	public List<Statuses> getStatuses() {
		return statuses;
	}
	
	public void setStatuses(List<Statuses> statuses) {
		this.statuses = statuses;
	}
	
	//models
	public List<Models> getModels() {
		return models;
	}
	
	public void setModels(List<Models> models) {
		this.models = models;
	}
	
	//requests
	public List<Requests> getRequests() {
		return requests;
	}
	
	public void setRequests(List<Requests> requests) {
		this.requests = requests;
	}
	
	//newSysMsgCt
	public String getNewSysMsgCt() {
		return newSysMsgCt;
	}
	
	public void setNewSysMsgCt(String newSysMsgCt) {
		this.newSysMsgCt = newSysMsgCt;
	}
	
	//nonActiveModels
	public List<Models> getNonActiveModels() {
		return nonActiveModels;
	}
	
	public void setNonActiveModels(List<Models> nonActiveModels) {
		this.nonActiveModels = nonActiveModels;
	}
	
	//reports
	public List<Reports> getReports() {
		return reports;
	}
	
	public void setReports(List<Reports> reports) {
		this.reports = reports;
	}	
	
	//faqs
	public List<Faqs> getFaqs() {
		return faqs;
	}
	
	public void setFaqs(List<Faqs> faqs) {
		this.faqs = faqs;
	}	
	
	// watchlists
	public List<Watchlist> getWatchlists() {
		return watchlists;
	}
	
	public void setWatchlists(List<Watchlist> watchlists) {
		this.watchlists = watchlists;
	}

	/**
	 * @return the modelsMdcd
	 */
	public List<Models> getModelsMdcd() {
		return modelsMdcd;
	}

	/**
	 * @return the nonActiveModelsMdcd
	 */
	public List<Models> getNonActiveModelsMdcd() {
		return nonActiveModelsMdcd;
	}

	/**
	 * @param modelsMdcd the modelsMdcd to set
	 */
	public void setModelsMdcd(List<Models> modelsMdcd) {
		this.modelsMdcd = modelsMdcd;
	}

	/**
	 * @param nonActiveModelsMdcd the nonActiveModelsMdcd to set
	 */
	public void setNonActiveModelsMdcd(List<Models> nonActiveModelsMdcd) {
		this.nonActiveModelsMdcd = nonActiveModelsMdcd;
	}

	/**
	 * @return the defaultAsrView
	 */
	public String getDefaultAsrView() {
		return defaultAsrView;
	}

	/**
	 * @param defaultAsrView the defaultAsrView to set
	 */
	public void setDefaultAsrView(String defaultAsrView) {
		this.defaultAsrView = defaultAsrView;
	}
	
	
	
}
