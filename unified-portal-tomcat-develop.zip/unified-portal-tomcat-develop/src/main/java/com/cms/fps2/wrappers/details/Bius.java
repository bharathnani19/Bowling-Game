package com.cms.fps2.wrappers.details;

public class Bius {
	private String timeType;
	private String claimType;
	private String count;
	
	//constructor
	public Bius(){}
	
	//timeType 	
	public String getTimeType() {
		return timeType;
	}
	
	public void setTimeType(String timeType) {
		this.timeType = timeType;
	}
		
	//claimType 	
	public String getClaimType() {
		return claimType;
	}
	
	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}
	
	//count 	
	public String getCount() {
		return count;
	}
	
	public void setCount(String count) {
		this.count = count;
	}
}
