package com.cms.fps2.wrappers.summary.workitems;

public class AddToExclusionListWrapper {
	// constructor
	public AddToExclusionListWrapper() {}
}
