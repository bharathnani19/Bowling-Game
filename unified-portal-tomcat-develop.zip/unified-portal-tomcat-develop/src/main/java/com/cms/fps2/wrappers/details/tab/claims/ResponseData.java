package com.cms.fps2.wrappers.details.tab.claims;

import com.cms.fps2.wrappers.details.ClaimLines;

public class ResponseData {
	private ClaimLines claimLines; 
	private String prioritized;
	
	//constructor
	public ResponseData(){}
	
	//claimLines
	public ClaimLines getClaimLines() {
		return claimLines;
	}
	
	public void setClaimLines(ClaimLines claimLines) {
		this.claimLines = claimLines;
	}
	
	//prioritized - this field is not used by the claims tab
	public String getPrioritized() {
		return prioritized;
	}
	
	public void setPrioritized(String prioritized) {
		this.prioritized = prioritized;
	}
	
}
