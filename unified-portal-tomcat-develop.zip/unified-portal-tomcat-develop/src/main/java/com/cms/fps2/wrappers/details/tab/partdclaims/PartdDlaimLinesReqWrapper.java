package com.cms.fps2.wrappers.details.tab.partdclaims;

public class PartdDlaimLinesReqWrapper {
	private String asrptId;
	private String modelId;
	private String userId;
	
	//constructor
	public PartdDlaimLinesReqWrapper(){}
	
	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	//modelId
	public String getModelId() {
		return modelId;
	}
	
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
