package com.cms.fps2.wrappers.summary;

public class Alerts {
	private String alertTypeCd;
	private String alertId;
	private String alertTypeDesc;
	private String alertStatusCd;
	private String alertDesc;
	
	//constructor
	public Alerts() {}
	
	//alertTypeCd
	public String getAlertTypeCd() {
		return alertTypeCd;
	}
	
	public void setAlertTypeCd(String alertTypeCd) {
		this.alertTypeCd = alertTypeCd;
	}
	
	//alertTypeCd
	public String getAlertId() {
		return alertId;
	}
	
	public void setAlertId(String alertId) {
		this.alertId = alertId;
	}
	
	//alertTypeDesc
	public String getAlertTypeDesc() {
		return alertTypeDesc;
	}
	
	public void setAlertTypeDesc(String alertTypeDesc) {
		this.alertTypeDesc = alertTypeDesc;
	}
	
	//alertStatusCd
	public String getAlertStatusCd() {
		return alertStatusCd;
	}
	
	public void setAlertStatusCd(String alertStatusCd) {
		this.alertStatusCd = alertStatusCd;
	}
	
	//alertDesc
	public String getAlertDesc() {
		return alertDesc;
	}
	
	public void setAlertDesc(String alertDesc) {
		this.alertDesc = alertDesc;
	}
}
