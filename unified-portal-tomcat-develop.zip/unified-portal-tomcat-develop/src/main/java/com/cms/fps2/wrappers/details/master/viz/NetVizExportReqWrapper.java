package com.cms.fps2.wrappers.details.master.viz;

public class NetVizExportReqWrapper {
	private String asrptId;
	private String userId;
	private String modelName;
	private String modelType;
	
	//constructor
	public NetVizExportReqWrapper() {}
	
	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//modelName
	public String getModelName() {
		return modelName;
	}
	
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	
	//modelType
	public String getModelType() {
		return modelType;
	}
	
	public void setModelType(String modelType) {
		this.modelType = modelType;
	}
}
