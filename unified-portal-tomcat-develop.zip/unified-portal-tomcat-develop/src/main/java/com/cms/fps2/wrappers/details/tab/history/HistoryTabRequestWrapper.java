package com.cms.fps2.wrappers.details.tab.history;

public class HistoryTabRequestWrapper {
	private String asrptId; 
	
	//constructor
	public HistoryTabRequestWrapper(){}
	
	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
}
