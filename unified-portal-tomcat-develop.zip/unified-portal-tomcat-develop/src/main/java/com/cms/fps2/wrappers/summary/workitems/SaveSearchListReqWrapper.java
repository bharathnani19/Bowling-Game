package com.cms.fps2.wrappers.summary.workitems;

public class SaveSearchListReqWrapper {
	private String userId;
	
	// constructor
	public SaveSearchListReqWrapper() {}

	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
