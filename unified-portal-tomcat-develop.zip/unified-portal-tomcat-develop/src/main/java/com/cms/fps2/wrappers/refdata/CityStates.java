package com.cms.fps2.wrappers.refdata;

public class CityStates {
	private String code;
		
	//constructor
	public CityStates(){}
	
	//code
	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}
}
