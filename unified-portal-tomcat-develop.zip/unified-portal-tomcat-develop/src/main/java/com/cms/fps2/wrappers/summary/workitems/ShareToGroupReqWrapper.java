package com.cms.fps2.wrappers.summary.workitems;

public class ShareToGroupReqWrapper {
	private String userId;
	private PrioritizationShareGrp prioritizationShareGrp;
		
	// constructor
	public ShareToGroupReqWrapper() {}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	// prioritizationShareGrp
	public PrioritizationShareGrp getPrioritizationShareGrp() {
		return prioritizationShareGrp;
	}
	
	public void setPrioritizationShareGrp(PrioritizationShareGrp prioritizationShareGrp) {
		this.prioritizationShareGrp = prioritizationShareGrp;
	}
}
