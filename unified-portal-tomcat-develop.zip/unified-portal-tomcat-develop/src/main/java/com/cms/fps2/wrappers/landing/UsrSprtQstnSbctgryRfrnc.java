package com.cms.fps2.wrappers.landing;

public class UsrSprtQstnSbctgryRfrnc {
	
	private String usrSprtQstnSbctgryCd;
	private String usrSprtQstnSbctgryDesc;
	private String actvInd;
	
	//constructor
	public UsrSprtQstnSbctgryRfrnc() {}
	
	//fpsUsrSprtQstnSbctgryRfrnc
	public String getUsrSprtQstnSbctgryCd() {
		return usrSprtQstnSbctgryCd;
	}
	
	public void setUsrSprtQstnSbctgryCd(String usrSprtQstnSbctgryCd) {
		this.usrSprtQstnSbctgryCd = usrSprtQstnSbctgryCd;
	}
	
	//usrSprtQstnSbctgryDesc
	public String getUsrSprtQstnSbctgryDesc() {
		return usrSprtQstnSbctgryDesc;
	}
	
	public void setUsrSprtQstnSbctgryDesc(String usrSprtQstnSbctgryDesc) {
		this.usrSprtQstnSbctgryDesc = usrSprtQstnSbctgryDesc;
	}
	
	//actvInd
	public String getActvInd() {
		return actvInd;
	}
	
	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}
	
}
