package com.cms.fps2.wrappers.details;

public class Models {
	private String modelName;
	private String implDt;
	private String updateDt;
	private String modelDesc;
	private String type;
	private String fpsVersion;
	private String version;
	private String ownerName;
	private String ownerEmail;
	private String ownerPhone;
	private String activeStatus;
	private String lastUpdateUser;
	private String modelLongName;
	private String modelId;
	private String claimType;
	private String docFile;
	private String cpiInd;
	private String lookback;
	private String priorityInd;
	private String lastProcessedTime;
	private String statusDt;
	private String priorityDt;
	private String statusChangedBy;
	private String lookbackDates;
	private String pathToEduInd;
	private String cadence;
	private String p1Ind;
		
	//constructor
	public Models(){}
	
	//modelName
	public String getModelName() {
		return modelName;
	}
	
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	
	//implDt
	public String getImplDt() {
		return implDt;
	}
	
	public void setImplDt(String implDt) {
		this.implDt = implDt;
	}
	
	//updateDt
	public String getUpdateDt() {
		return updateDt;
	}
	
	public void setUpdateDt(String updateDt) {
		this.updateDt = updateDt;
	}
	
	//modelDesc
	public String getModelDesc() {
		return modelDesc;
	}
	
	public void setModelDesc(String modelDesc) {
		this.modelDesc = modelDesc;
	}
	
	//type
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	//fpsVersion
	public String getFpsVersion() {
		return fpsVersion;
	}
	
	public void setFpsVersion(String fpsVersion) {
		this.fpsVersion = fpsVersion;
	}
	
	//version
	public String getVersion() {
		return version;
	}
	
	public void setVersion(String version) {
		this.version = version;
	}
	
	//ownerName
	public String getOwnerName() {
		return ownerName;
	}
	
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	
	//ownerEmail
	public String getOwnerEmail() {
		return ownerEmail;
	}
	
	public void setOwnerEmail(String ownerEmail) {
		this.ownerEmail = ownerEmail;
	}
	
	//ownerPhone
	public String getOwnerPhone() {
		return ownerPhone;
	}
	
	public void setOwnerPhone(String ownerPhone) {
		this.ownerPhone = ownerPhone;
	}
	
	
	//activeStatus
	public String getActiveStatus() {
		return activeStatus;
	}
	
	public void setActiveStatus(String activeStatus) {
		this.activeStatus = activeStatus;
	}
	
	//lastUpdateUser
	public String getLastUpdateUser() {
		return lastUpdateUser;
	}
	
	public void setLastUpdateUser(String lastUpdateUser) {
		this.lastUpdateUser = lastUpdateUser;
	}
	
	//modelLongName
	public String getModelLongName() {
		return modelLongName;
	}
	
	public void setModelLongName(String modelLongName) {
		this.modelLongName = modelLongName;
	}
	
	//modelId
	public String getModelId() {
		return modelId;
	}
	
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	
	//claimType
	public String getClaimType() {
		return claimType;
	}
	
	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}
	
	//docFile
	public String getDocFile() {
		return docFile;
	}
	
	public void setDocFile(String docFile) {
		this.docFile = docFile;
	}
	
	//cpiInd
	public String getCpiInd() {
		return cpiInd;
	}
	
	public void setCpiInd(String cpiInd) {
		this.cpiInd = cpiInd;
	}
	
	//lookback
	public String getLookback() {
		return lookback;
	}
	
	public void setLookback(String lookback) {
		this.lookback = lookback;
	}
	
	//priorityInd
	public String getPriorityInd() {
		return priorityInd;
	}
	
	public void setPriorityInd(String priorityInd) {
		this.priorityInd = priorityInd;
	}
	
	//lastProcessedTime
	public String getLastProcessedTime() {
		return lastProcessedTime;
	}
	
	public void setLastProcessedTime(String lastProcessedTime) {
		this.lastProcessedTime = lastProcessedTime;
	}
	
	//statusDt
	public String getStatusDt() {
		return statusDt;
	}
	
	public void setStatusDt(String statusDt) {
		this.statusDt = statusDt;
	}
	
	//priorityDt
	public String getPriorityDt() {
		return priorityDt;
	}
	
	public void setPriorityDt(String priorityDt) {
		this.priorityDt = priorityDt;
	}
	
	//statusChangedBy
	public String getStatusChangedBy() {
		return statusChangedBy;
	}
	
	public void setStatusChangedBy(String statusChangedBy) {
		this.statusChangedBy = statusChangedBy;
	}
	
	// lookbackDates
	public String getLookbackDates() {
		return lookbackDates;
	}
	
	public void setLookbackDates(String lookbackDates) {
		this.lookbackDates = lookbackDates;
	}

	//pathToEduInd
	
	public String getPathToEduInd() {
		return pathToEduInd;
	}

	public void setPathToEduInd(String pathToEduInd) {
		this.pathToEduInd = pathToEduInd;
	}

	//cadence
	
	public String getCadence() {
		return cadence;
	}

	public void setCadence(String cadence) {
		this.cadence = cadence;
	}

	public String getP1Ind() {
		return p1Ind;
	}

	public void setP1Ind(String p1Ind) {
		this.p1Ind = p1Ind;
	}
}


