package com.cms.fps2.wrappers.landing;

public class Outages {
	
	private String id;
	private String startDate;
	private String endDate;
	private String jurisdiction;
	private String title;
	private String message;
	private String loggedInUserId;
	private String zonesAffected;
	
	//constructor
	public Outages(){}
	
	//id
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	//startDate
	public String getStartDate() {
		return startDate;
	}
	
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	
	//endDate
	public String getEndDate() {
		return endDate;
	}
	
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
			
	//jurisdiction
	public String getJurisdiction() {
		return jurisdiction;
	}
	
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}
	
	//title
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	//message
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	//loggedInUserId
	public String getLoggedInUserId() {
		return loggedInUserId;
	}
	
	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}
	
	//zonesAffected
	public String getZonesAffected() {
		return zonesAffected;
	}
	
	public void setZonesAffected(String zonesAffected) {
		this.zonesAffected = zonesAffected;
	}
}
