package com.cms.fps2.wrappers.admin;

public class AdminSysMsgsReqWrapper {
	
	private String id;
	private String message;
	private String dateAdded;
//	private String concatMsg;
	private String loggedInUserId;
	private String startDt;
	private String endDt;
	
	public AdminSysMsgsReqWrapper(){}
	
	//id
		public String getId() {
			return id;
		}
		
		public void setId(String id) {
			this.id = id;
		}
		
		//message
		public String getMessage() {
			return message;
		}
		
		public void setMessage(String message) {
			this.message = message;
		}
		
		//dateAdded
		public String getDateAdded() {
			return dateAdded;
		}
		
		public void setDateAdded(String dateAdded) {
			this.dateAdded = dateAdded;
		}
		
		//concatMsg
//		public String getConcatMsg() {
//			concatMsg = message + " - " + dateAdded;
//			return concatMsg;
//		}
		
//		public void setConcatMsg(String concatMsg) {
//			this.concatMsg = concatMsg;
//		}
		
		//loggedInUserId
		public String getLoggedInUserId() {		
			return loggedInUserId;
		}
		
		public void setLoggedInUserId(String loggedInUserId) {
			this.loggedInUserId = loggedInUserId;
		}
		
		//startDt
		public String getStartDt() {		
			return startDt;
		}
		
		public void setStartDt(String startDt) {
			this.startDt = startDt;
		}
		
		//endDt
		public String getEndDt() {		
			return endDt;
		}
		
		public void setEndDt(String endDt) {
			this.endDt = endDt;
		}
}
