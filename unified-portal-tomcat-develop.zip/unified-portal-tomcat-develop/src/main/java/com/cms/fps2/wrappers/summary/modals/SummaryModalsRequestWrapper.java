package com.cms.fps2.wrappers.summary.modals;

public class SummaryModalsRequestWrapper {
	private String asrptId;
	private String userId;
	private String linkType;
	private String programType;
	
	//constructor
	public SummaryModalsRequestWrapper(){}
	
	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//linkType
	public String getLinkType() {
		return linkType;
	}
	
	public void setLinkType(String linkType) {
		this.linkType = linkType;
	}

	// programType
	
	public String getProgramType() {
		return programType;
	}

	// programType
	
	public void setProgramType(String programType) {
		this.programType = programType;
	}
}
