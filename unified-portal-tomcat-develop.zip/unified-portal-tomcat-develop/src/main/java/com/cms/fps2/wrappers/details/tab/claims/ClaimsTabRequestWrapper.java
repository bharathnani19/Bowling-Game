package com.cms.fps2.wrappers.details.tab.claims;

public class ClaimsTabRequestWrapper {
	private String asrptId; 
	private String userId;
	
	//constructor
	public ClaimsTabRequestWrapper(){}
	

	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
