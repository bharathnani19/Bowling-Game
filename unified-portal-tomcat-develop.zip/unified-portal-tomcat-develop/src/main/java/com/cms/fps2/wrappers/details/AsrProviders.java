package com.cms.fps2.wrappers.details;

import java.util.ArrayList;
import java.util.List;
import com.cms.fps2.wrappers.details.asrproviders.SysTags;

public class AsrProviders {
	
	private String npi;
	private String uniqueAlertsCnt;
	private String specialtiesCnt;
	private String benesCnt;
	private String proceduresCnt;
	private String asrProviderCnt;
	private String submitterIdCnt;
	private List<String> subjectRoleCd = new ArrayList<String>();
	private String fidNumberCnt;
	private String ucmCaseDataCnt;
	private String biu4WeekCnt;
	private String biu1YearCnt;
	private SysTags sysTags;
	private String providerName;
	private String role;
	
	//constructor
	public AsrProviders(){}
	
	//npi 	
	public String getNpi() {
		return npi;
	}
	
	public void setNpi(String npi) {
		this.npi = npi;
	}
	
	//uniqueAlertsCnt 	
	public String getUniqueAlertsCnt() {
		return uniqueAlertsCnt;
	}
	
	public void setUniqueAlertsCnt(String uniqueAlertsCnt) {
		this.uniqueAlertsCnt = uniqueAlertsCnt;
	}
	
	//specialtiesCnt 	
	public String getSpecialtiesCnt() {
		return specialtiesCnt;
	}
	
	public void setSpecialtiesCnt(String specialtiesCnt) {
		this.specialtiesCnt = specialtiesCnt;
	}
	
	//benesCnt 	
	public String getBenesCnt() {
		return benesCnt;
	}
	
	public void setBenesCnt(String benesCnt) {
		this.benesCnt = benesCnt;
	}
	
	//proceduresCnt 	
	public String getProceduresCnt() {
		return proceduresCnt;
	}
	
	public void setProceduresCnt(String proceduresCnt) {
		this.proceduresCnt = proceduresCnt;
	}
	
	//asrProviderCnt 	
	public String getAsrProviderCnt() {
		return asrProviderCnt;
	}
	
	public void setAsrProviderCnt(String asrProviderCnt) {
		this.asrProviderCnt = asrProviderCnt;
	}
	
	//submitterIdCnt 	
	public String getSubmitterIdCnt() {
		return submitterIdCnt;
	}
	
	public void setSubmitterIdCnt(String submitterIdCnt) {
		this.submitterIdCnt = submitterIdCnt;
	}
	
	//subjectRoleCd 	
	public List<String> getSubjectRoleCd() {
		return subjectRoleCd;
	}
	
	public void setSubjectRoleCd(List<String> subjectRoleCd) {
		this.subjectRoleCd = subjectRoleCd;
	}
	
	//fidNumberCnt 	
	public String getFidNumberCnt() {
		return fidNumberCnt;
	}
	
	public void setFidNumberCnt(String fidNumberCnt) {
		this.fidNumberCnt = fidNumberCnt;
	}
	
	//ucmCaseDataCnt 	
	public String getUcmCaseDataCnt() {
		return ucmCaseDataCnt;
	}
	
	public void setUcmCaseDataCnt(String ucmCaseDataCnt) {
		this.ucmCaseDataCnt = ucmCaseDataCnt;
	}
	
	//biu4WeekCnt 	
	public String getBiu4WeekCnt() {
		return biu4WeekCnt;
	}
	
	public void setBiu4WeekCnt(String biu4WeekCnt) {
		this.biu4WeekCnt = biu4WeekCnt;
	}
	
	//biu1YearCnt 	
	public String getBiu1YearCnt() {
		return biu1YearCnt;
	}
	
	public void setBiu1YearCnt(String biu1YearCnt) {
		this.biu1YearCnt = biu1YearCnt;
	}
	
	//sysTags 	
	public SysTags getSysTags() {
		return sysTags;
	}
	
	public void setSysTags(SysTags sysTags) {
		this.sysTags = sysTags;
	}
	
	//providerName 	
	public String getProviderName() {
		return providerName;
	}
	
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	
	//role 	
	public String getRole() {
		return role;
	}
	
	public void setRole(String role) {
		this.role = role;
	}

}
