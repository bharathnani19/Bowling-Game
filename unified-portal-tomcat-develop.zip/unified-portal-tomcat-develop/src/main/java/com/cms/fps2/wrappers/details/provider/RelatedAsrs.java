package com.cms.fps2.wrappers.details.provider;

public class RelatedAsrs {
	private String npi;
	private String asrptId;
	private String name;
	private String relationships;
	private String riskScore;
	private String priorityScore;
	private String asrCost;
	private String agedModels;
	private String newModels;
	
	// constructor
	public RelatedAsrs() {}
	
	// npi
	public String getNpi() {
		return npi;
	}
	
	public void setNpi(String npi) {
		this.npi = npi;
	}
	
	// asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	// name
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	// relationships
	public String getRelationships() {
		return relationships;
	}
	
	public void setRelationships(String relationships) {
		this.relationships = relationships;
	}
	
	// riskScore
	public String getRiskScore() {
		return riskScore;
	}
	
	public void setRiskScore(String riskScore) {
		this.riskScore = riskScore;
	}
	
	// priorityScore
	public String getPriorityScore() {
		return priorityScore;
	}
	
	public void setPriorityScore(String priorityScore) {
		this.priorityScore = priorityScore;
	}
	
	// asrCost
	public String getAsrCost() {
		return asrCost;
	}
	
	public void setAsrCost(String asrCost) {
		this.asrCost = asrCost;
	}
	
	// agedModels
	public String getAgedModels() {
		return agedModels;
	}
	
	public void setAgedModels(String agedModels) {
		this.agedModels = agedModels;
	}
	
	// newModels
	public String getNewModels() {
		return newModels;
	}
	
	public void setNewModels(String newModels) {
		this.newModels = newModels;
	}
}
