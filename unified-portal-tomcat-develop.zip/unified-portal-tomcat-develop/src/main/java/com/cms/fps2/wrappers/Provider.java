package com.cms.fps2.wrappers;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.summary.Procedures;
import com.cms.fps2.wrappers.summary.Specialties;
import com.cms.fps2.wrappers.summary.SystemTags;

public class Provider {
	private String npi;
	private String providerName;
	private String riskScoreNum;
	private String totalCost;
	private String uniqueAlertsCnt;
	private String createdDt;
	private String updateDt;
	private String assignedTo;
	private String specialtiesCnt;
	private List<Specialties> specialties = new ArrayList<Specialties>();
	private String benesCnt;
	private String benes;
	private String proceduresCnt; 
	private List<Procedures> procedures = new ArrayList<Procedures>();
	private String asrProviderCnt;
	private String asrProviders;
	private String submitterIdCnt;
	private String submitterIds;
	private String subjectStateCd;
	private String subjectJurisdiction;
	private String roles;
	private String fidNumberCnt;
	private List<String> fidNumbers = new ArrayList<String>();
	private List<String> ucmCaseData = new ArrayList<String>();
	private String ucmCaseDataCnt;
	private String biu4WeekCnt;
	private String biu1YearCnt;
	private String inWorkload;
	private String inWorkloadDt;
	private String barrierToAction;
	private List<SystemTags> sysTags = new ArrayList<SystemTags>();
	
	//constructor
	public Provider(){}
	
	//npi 	
	public String getNpi() {
		return npi;
	}
	
	public void setNpi(String npi) {
		this.npi = npi;
	}
	
	//providerName 	
	public String getProviderName() {
		return providerName;
	}
	
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}	
	
	//riskScoreNum 	
	public String getRiskScoreNum() {
		return riskScoreNum;
	}
	
	public void setRiskScoreNum(String riskScoreNum) {
		this.riskScoreNum = riskScoreNum;
	}
	
	//totalCost 	
	public String getTotalCost() {
		return totalCost;
	}
	
	public void setTotalCost(String totalCost) {
		this.totalCost = totalCost;
	}
	
	//uniqueAlertsCnt 	
	public String getUniqueAlertsCnt() {
		return uniqueAlertsCnt;
	}
	
	public void setUniqueAlertsCnt(String uniqueAlertsCnt) {
		this.uniqueAlertsCnt = uniqueAlertsCnt;
	}
	
	//createdDt 	
	public String getCreatedDt() {
		return createdDt;
	}
	
	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}
	
	//updateDt 	
	public String getUpdateDt() {
		return updateDt;
	}
	
	public void setUpdateDt(String updateDt) {
		this.updateDt = updateDt;
	}
	
	//assignedTo 	
	public String getAssignedTo() {
		return assignedTo;
	}
	
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	
	//specialtiesCnt 	
	public String getSpecialtiesCnt() {
		return specialtiesCnt;
	}
	
	public void setSpecialtiesCnt(String specialtiesCnt) {
		this.specialtiesCnt = specialtiesCnt;
	}
	
	//specialties
	public List<Specialties> getSpecialties() {
		return specialties;
	}
	
	public void setSpecialties(List<Specialties> specialties) {
		this.specialties = specialties;
	}
	
	//benesCnt 	
	public String getBenesCnt() {
		return benesCnt;
	}
	
	public void setBenesCnt(String benesCnt) {
		this.benesCnt = benesCnt;
	}
	
	//benes 	
	public String getBenes() {
		return benes;
	}
	
	public void setBenes(String benes) {
		this.benes = benes;
	}
	
	//proceduresCnt 	
	public String getProceduresCnt() {
		return proceduresCnt;
	}
	
	public void setProceduresCnt(String proceduresCnt) {
		this.proceduresCnt = proceduresCnt;
	}
	
	//procedures
	public List<Procedures> getProcedures() {
		return procedures;
	}
	
	public void setProcedures(List<Procedures> procedures) {
		this.procedures = procedures;
	}
	
	//asrProviderCnt
	public String getAsrProviderCnt() {
		return asrProviderCnt;
	}
	
	public void setAsrProviderCnt(String asrProviderCnt) {
		this.asrProviderCnt = asrProviderCnt;
	}
	
	//asrProviders
	public String getAsrProviders() {
		return asrProviders;
	}
	
	public void setAsrProviders(String asrProviders) {
		this.asrProviders = asrProviders;
	}
	
	//submittedIdCnt 	
	public String getSubmittedIdCnt() {
		return submitterIdCnt;
	}
	
	public void setSubmittedIdCnt(String submitterIdCnt) {
		this.submitterIdCnt = submitterIdCnt;
	}
	
	//submitterIds 	
	public String getSubmitterIds() {
		return submitterIds;
	}
	
	public void setSubmitterIds(String submitterIds) {
		this.submitterIds = submitterIds;
	}
	
	//subjectStateCd 	
	public String getSubjectStateCd() {
		return subjectStateCd;
	}
	
	public void setSubjectStateCd(String subjectStateCd) {
		this.subjectStateCd = subjectStateCd;
	}
	
	//subjectJurisdiction 	
	public String getSubjectJurisdiction() {
		return subjectJurisdiction;
	}
	
	public void setSubjectJurisdiction(String subjectJurisdiction) {
		this.subjectJurisdiction = subjectJurisdiction;
	}
	
	//roles 	
	public String getRoles() {
		return roles;
	}
	
	public void setRoles(String roles) {
		this.roles = roles;
	}
	
	//fidNumberCnt 	
	public String getFidNumberCnt() {
		return fidNumberCnt;
	}
	
	public void setFidNumberCnt(String fidNumberCnt) {
		this.fidNumberCnt = fidNumberCnt;
	}
	
	//fidNumbers 	
	public List<String> getFidNumbers() {
		return fidNumbers;
	}
	
	public void setFidNumbers(List<String> fidNumbers) {
		this.fidNumbers = fidNumbers;
	}
	
	//ucmCaseData 	
	public List<String> getUcmCaseData() {
		return ucmCaseData;
	}
	
	public void setUcmCaseData(List<String> ucmCaseData) {
		this.ucmCaseData = ucmCaseData;
	}
	
	//ucmCaseDataCnt 	
	public String getUcmCaseDataCnt() {
		return ucmCaseDataCnt;
	}
	
	public void setUcmCaseDataCnt(String ucmCaseDataCnt) {
		this.ucmCaseDataCnt = ucmCaseDataCnt;
	}
	
	//biu4WeekCnt 	
	public String getBiu4WeekCnt() {
		return biu4WeekCnt;
	}
	
	public void setBiu4WeekCnt(String biu4WeekCnt) {
		this.biu4WeekCnt = biu4WeekCnt;
	}
	
	//biu1YearCnt 	
	public String getBiu1YearCnt() {
		return biu1YearCnt;
	}
	
	public void setBiu1YearCnt(String biu1YearCnt) {
		this.biu1YearCnt = biu1YearCnt;
	}
	
	//inWorkload 	
	public String getInWorkload() {
		return inWorkload;
	}
	
	public void setInWorkload(String inWorkload) {
		this.inWorkload = inWorkload;
	}
	
	//inWorkloadDt 	
	public String getInWorkloadDt() {
		return inWorkloadDt;
	}
	
	public void setInWorkloadDt(String inWorkloadDt) {
		this.inWorkloadDt = inWorkloadDt;
	}
	
	//barrierToAction 	
	public String getBarrierToAction() {
		return barrierToAction;
	}
	
	public void setBarrierToAction(String barrierToAction) {
		this.barrierToAction = barrierToAction;
	}
	
	//sysTags 	
	public List<SystemTags> getSysTags() {
		return sysTags;
	}
	
	public void setSysTags(List<SystemTags> sysTags) {
		this.sysTags = sysTags;
	}
}
