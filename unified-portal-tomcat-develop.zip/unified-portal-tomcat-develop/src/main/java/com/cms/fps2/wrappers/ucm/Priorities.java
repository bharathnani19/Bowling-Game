package com.cms.fps2.wrappers.ucm;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.details.priortization.PrioritizeStates;
import com.cms.fps2.wrappers.details.priortization.PriortizeAlerts;

public class Priorities {
	
	private String userId;
	private String zone;
	private String comments;
	private String asrDbId;
	private String addedDt;
	private String asrId;
	private String cmsPriorityAsrInd;
	private String source;
	private String modelList;
	private String programType;
	private String state;

	
	private List<PrioritizeStates> states = new ArrayList<PrioritizeStates>();
	
	private List<PriortizeAlerts> asrPrioritizationModelItems = new ArrayList<PriortizeAlerts>();

	
	//empty constructor
	public Priorities(){}
	
	//programType
	public String getProgramType() {
		return programType;
	}
	
	public void SetProgramType(String programType) {
		this.programType = programType;
	}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//zone
	public String getZone() {
		return zone;
	}
	
	public void setZone(String zone) {
		this.zone = zone;
	}	
	
	//comments
	public String getComments() {
		return comments;
	}
	
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	//asrDbId
	public String getAsrDbId() {
		return asrDbId;
	}
	
	public void setAsrDbId(String asrDbId) {
		this.asrDbId = asrDbId;
	}
	


	/**
	 * @return the asrPrioritizationModelItems
	 */
	public List<PriortizeAlerts> getAsrPrioritizationModelItems() {
		return asrPrioritizationModelItems;
	}

	/**
	 * @param asrPrioritizationModelItems the asrPrioritizationModelItems to set
	 */
	public void setAsrPrioritizationModelItems(List<PriortizeAlerts> asrPrioritizationModelItems) {
		this.asrPrioritizationModelItems = asrPrioritizationModelItems;
	}



	/**
	 * @return the addedDt
	 */
	public String getAddedDt() {
		return addedDt;
	}



	/**
	 * @return the asrId
	 */
	public String getAsrId() {
		return asrId;
	}



	/**
	 * @return the cmsPriorityAsrInd
	 */
	public String getCmsPriorityAsrInd() {
		return cmsPriorityAsrInd;
	}



	/**
	 * @return the source
	 */
	public String getSource() {
		return source;
	}



	/**
	 * @return the modelList
	 */
	public String getModelList() {
		return modelList;
	}



	/**
	 * @param addedDt the addedDt to set
	 */
	public void setAddedDt(String addedDt) {
		this.addedDt = addedDt;
	}



	/**
	 * @param asrId the asrId to set
	 */
	public void setAsrId(String asrId) {
		this.asrId = asrId;
	}



	/**
	 * @param cmsPriorityAsrInd the cmsPriorityAsrInd to set
	 */
	public void setCmsPriorityAsrInd(String cmsPriorityAsrInd) {
		this.cmsPriorityAsrInd = cmsPriorityAsrInd;
	}



	/**
	 * @param source the source to set
	 */
	public void setSource(String source) {
		this.source = source;
	}



	/**
	 * @param modelList the modelList to set
	 */
	public void setModelList(String modelList) {
		this.modelList = modelList;
	}

	// states
	
	public List<PrioritizeStates> getStates() {
		return states;
	}

	// programType
	
	public void setProgramType(String programType) {
		this.programType = programType;
	}

	// states
	
	public void setStates(List<PrioritizeStates> states) {
		this.states = states;
	}

	// state
	
	public String getState() {
		return state;
	}

	// state
	 
	public void setState(String state) {
		this.state = state;
	}


}
