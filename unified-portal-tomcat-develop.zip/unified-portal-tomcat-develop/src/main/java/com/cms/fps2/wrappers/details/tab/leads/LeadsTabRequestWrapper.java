package com.cms.fps2.wrappers.details.tab.leads;

public class LeadsTabRequestWrapper {
	
	private String asrptId; 
	private String userId;
	private String programType="medicare";
	
	//constructor
	public LeadsTabRequestWrapper(){}
	
	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getProgramType() {
		return programType;
	}

	public void setProgramType(String programType) {
		this.programType = programType;
	}
}
