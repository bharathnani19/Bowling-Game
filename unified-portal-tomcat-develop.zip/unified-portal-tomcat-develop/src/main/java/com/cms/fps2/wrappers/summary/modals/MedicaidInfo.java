package com.cms.fps2.wrappers.summary.modals;

import java.util.ArrayList;
import java.util.List;

public class MedicaidInfo {
	
	private String state;
	private String npi;
	private String prvdrName;
	private String reason;
	private String asOfDate;
	private String claimCnt;
	private String dollars;
	private String number;
	private List<Data> data = new ArrayList<Data>();
	
	//constructor
	public MedicaidInfo() {}
	
	//state
	public String getState() {
		return state;
	}
	
	public void setState(String state) {
		this.state = state;
	}
	
	//npi
	public String getNpi() {
		return npi;
	}
	
	public void setNpi(String npi) {
		this.npi = npi;
	}
	
	//prvdrName
	public String getPrvdrName() {
		return prvdrName;
	}
	
	public void setPrvdrName(String prvdrName) {
		this.prvdrName = prvdrName;
	}
	
	//reason
	public String getReason() {
		return reason;
	}
	
	public void setReason(String reason) {
		this.reason = reason;
	}
	
	//asOfDate
	public String getAsOfDate() {
		return asOfDate;
	}
	
	public void setAsOfDate(String asOfDate) {
		this.asOfDate = asOfDate;
	}
	
	//claimCnt
	public String getClaimCnt() {
		return claimCnt;
	}
	
	public void setClaimCnt(String claimCnt) {
		this.claimCnt = claimCnt;
	}
	
	//dollars
	public String getDollars() {
		return dollars;
	}
	
	public void setDollars(String dollars) {
		this.dollars = dollars;
	}
	
	//number
	public String getNumber() {
		return number;
	}
	
	public void setNumber(String number) {
		this.number = number;
	}
	
	//data
	public List<Data> getData() {
		
		return data;
	}
	
	public void setData(List<Data> data) {
		this.data = data;
	}
}
