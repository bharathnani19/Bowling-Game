package com.cms.fps2.wrappers.details.master.viz;

import java.util.ArrayList;
import java.util.List;

public class Edges {
	private String from;
	private String to;
	private String title;
	private String clstrSize;
	private String flag;
	private String modelBusnsId;
	private String rltdNpiName;
	private String rltdPrvdrClstrPct;
	private String rltdPrvdrNpi;
	private String rltdPrvdrNumBene;
	private String rltdPrvdrRskRsnDesc;
	private String rltdPrvdrType;
	private String subjNpiName;
	private String subjPrvdrClstrPct;
	private String subjPrvdrNpi;
	private String subjPrvdrNumBene;
	private String alertCstAmt;
	private String modelRunDt;
	private List<RltdPrvdrRskRsns> rltdPrvdrRskRsns = new ArrayList<RltdPrvdrRskRsns>();
	private String label;
	private String ranking;
	private String weight;
	private String subjPrvdrRole;
	private String rltdPrvdrRole;
	private String pecosRltnshp;
	private String rltdPrvdrNum;
	private String badRltdPrvdrNum;
	private String badRltdPrvdrPct;
	
	//constructor
	public Edges(){}
	
	//to
	public String getTo() {
		return to;
	}
	
	public void setTo(String to) {
		this.to = to;
	}
	
	//from
	public String getFrom() {
		return from;
	}
	
	public void setFrom(String from) {
		this.from = from;
	}
	
	//title
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	//clstrSize
	public String getClstrSize() {
		return clstrSize;
	}
	
	public void setClstrSize(String clstrSize) {
		this.clstrSize = clstrSize;
	}
	
	//flag
	public String getFlag() {
		return flag;
	}
	
	public void setFlag(String flag) {
		this.flag = flag;
	}
	
	//modelBusnsId
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	
	//rltdNpiName
	public String getRltdNpiName() {
		return rltdNpiName;
	}
	
	public void setRltdNpiName(String rltdNpiName) {
		this.rltdNpiName = rltdNpiName;
	}
	
	//rltdPrvdrClstrPct
	public String getRltdPrvdrClstrPct() {
		return rltdPrvdrClstrPct;
	}
	
	public void setRltdPrvdrClstrPct(String rltdPrvdrClstrPct) {
		this.rltdPrvdrClstrPct = rltdPrvdrClstrPct;
	}
	
	//rltdPrvdrNpi
	public String getRltdPrvdrNpi() {
		return rltdPrvdrNpi;
	}
	
	public void setRltdPrvdrNpi(String rltdPrvdrNpi) {
		this.rltdPrvdrNpi = rltdPrvdrNpi;
	}
	
	//rltdPrvdrNumBene
	public String getRltdPrvdrNumBene() {
		return rltdPrvdrNumBene;
	}
	
	public void setRltdPrvdrNumBene(String rltdPrvdrNumBene) {
		this.rltdPrvdrNumBene = rltdPrvdrNumBene;
	}
	
	//rltdPrvdrRskRsnDesc
	public String getRltdPrvdrRskRsnDesc() {
		return rltdPrvdrRskRsnDesc;
	}
	
	public void setRltdPrvdrRskRsnDesc(String rltdPrvdrRskRsnDesc) {
		this.rltdPrvdrRskRsnDesc = rltdPrvdrRskRsnDesc;
	}
	
	//rltdPrvdrType
	public String getRltdPrvdrType() {
		return rltdPrvdrType;
	}
	
	public void setRltdPrvdrType(String rltdPrvdrType) {
		this.rltdPrvdrType = rltdPrvdrType;
	}
	
	//subjNpiName
	public String getSubjNpiName() {
		return subjNpiName;
	}
	
	public void setSubjNpiName(String subjNpiName) {
		this.subjNpiName = subjNpiName;
	}
	
	//subjPrvdrClstrPct
	public String getSubjPrvdrClstrPct() {
		return subjPrvdrClstrPct;
	}
	
	public void setSubjPrvdrClstrPct(String subjPrvdrClstrPct) {
		this.subjPrvdrClstrPct = subjPrvdrClstrPct;
	}
	
	//subjPrvdrNpi
	public String getSubjPrvdrNpi() {
		return subjPrvdrNpi;
	}
	
	public void setSubjPrvdrNpi(String subjPrvdrNpi) {
		this.subjPrvdrNpi = subjPrvdrNpi;
	}
	
	//subjPrvdrNumBene
	public String getSubjPrvdrNumBene() {
		return subjPrvdrNumBene;
	}
	
	public void setSubjPrvdrNumBene(String subjPrvdrNumBene) {
		this.subjPrvdrNumBene = subjPrvdrNumBene;
	}
	
	//alertCstAmt
	public String getAlertCstAmt() {
		return alertCstAmt;
	}
	
	public void setAlertCstAmt(String alertCstAmt) {
		this.alertCstAmt = alertCstAmt;
	}
	
	//modelRunDt
	public String getModelRunDt() {
		return modelRunDt;
	}
	
	public void setModelRunDt(String modelRunDt) {
		this.modelRunDt = modelRunDt;
	}
	
	//rltdPrvdrRskRsns
	public List<RltdPrvdrRskRsns> getRltdPrvdrRskRsns() {
		return rltdPrvdrRskRsns;
	}
	
	public void setRltdPrvdrRskRsns(List<RltdPrvdrRskRsns> rltdPrvdrRskRsns) {
		this.rltdPrvdrRskRsns = rltdPrvdrRskRsns;
	}
	
	//label
	public String getLabel() {
		return label;
	}
	
	public void setLabel(String label) {
		this.label = label;
	}
	
	//ranking
	public String getRanking() {
		return ranking;
	}
	
	public void setRanking(String ranking) {
		this.ranking = ranking;
	}
	
	//weight
	public String getWeight() {
		return weight;
	}
	
	public void setWeight(String weight) {
		this.weight = weight;
	}
	
	//subjPrvdrRole
	public String getSubjPrvdrRole() {
		return subjPrvdrRole;
	}
	
	public void setSubjPrvdrRole(String subjPrvdrRole) {
		this.subjPrvdrRole = subjPrvdrRole;
	}
	
	//rltdPrvdrRole
	public String getRltdPrvdrRole() {
		return rltdPrvdrRole;
	}
	
	public void setRltdPrvdrRole(String rltdPrvdrRole) {
		this.rltdPrvdrRole = rltdPrvdrRole;
	}
	
	// pecosRltnshp
	public String getPecosRltnshp() {
		return pecosRltnshp;
	}
	
	public void setPecosRltnshp(String pecosRltnshp) {
		this.pecosRltnshp = pecosRltnshp;
	}
	
	// rltdPrvdrNum
	public String getRltdPrvdrNum() {
		return rltdPrvdrNum;
	}
	
	public void setRltdPrvdrNum(String rltdPrvdrNum) {
		this.rltdPrvdrNum = rltdPrvdrNum;
	}
	
	// badRltdPrvdrNum
	public String getBadRltdPrvdrNum() {
		return badRltdPrvdrNum;
	}
	
	public void setBadRltdPrvdrNum(String badRltdPrvdrNum) {
		this.badRltdPrvdrNum = badRltdPrvdrNum;
	}
	
	// badRltdPrvdrPct
	public String getBadRltdPrvdrPct() {
		return badRltdPrvdrPct;
	}
	
	public void setBadRltdPrvdrPct(String badRltdPrvdrPct) {
		this.badRltdPrvdrPct = badRltdPrvdrPct;
	}
}
