package com.cms.fps2.wrappers.details.export;

public class Hicns {
	private String hicn;
	
	//constructor
	public Hicns(){}
	
	//hicn
	public String getHicn() {
		return hicn;
	}
	
	public void setHicn(String hicn) {
		this.hicn = hicn;
	}
}
