package com.cms.fps2.wrappers.nav;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.landing.Messages;
import com.cms.fps2.wrappers.landing.Outages;

public class NavSysMsgsRespWrapper {
	private List<Outages> outages = new ArrayList<Outages>();
	private List<Messages> messages = new ArrayList<Messages>();
	private List<Requests> requests = new ArrayList<Requests>();
	private String newSysMsgCt;
	
	//constructor
	public NavSysMsgsRespWrapper (){}
	
	//outages
	public List<Outages> getOutages() {
		return outages;
	}
	
	public void setOutages(List<Outages> outages) {
		this.outages = outages;
	}
	
	//messages
	public List<Messages> getMessages() {
		return messages;
	}
	
	public void setMessages(List<Messages> messages) {
		this.messages = messages;
	}
	
	//requests
	public List<Requests> getRequests() {
		return requests;
	}
		
	public void setRequests(List<Requests> requests) {
		this.requests = requests;
	}
	
	//newSysMsgCt
	public String getNewSysMsgCt() {
		return newSysMsgCt;
	}
	
	public void setNewSysMsgCt(String newSysMsgCt) {
		this.newSysMsgCt = newSysMsgCt;
	}
}
