package com.cms.fps2.wrappers.details.export;

import java.util.ArrayList;
import java.util.List;

public class ClaimsHicnResponseWrapper {
	
	private List<Hicns> hicns = new ArrayList<Hicns>();
 	
	//constructor
	public ClaimsHicnResponseWrapper(){}
	
	//hicns
	public List<Hicns> getHicns() {
		return hicns;
	}
	
	public void setHicns(List<Hicns> hicns) {
		this.hicns = hicns;
	}
}
