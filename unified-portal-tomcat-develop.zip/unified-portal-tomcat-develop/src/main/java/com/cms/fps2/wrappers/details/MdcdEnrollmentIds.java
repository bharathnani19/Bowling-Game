package com.cms.fps2.wrappers.details;

public class MdcdEnrollmentIds {
	
	
	private String mdcdId;
	private String state;
	private String status;
	private String efctvDt;
	private String termDt;
	// mdcdId
	
	public String getMdcdId() {
		return mdcdId;
	}
	// state
	
	public String getState() {
		return state;
	}
	// status
	
	public String getStatus() {
		return status;
	}
	// efctvDt
	
	public String getEfctvDt() {
		return efctvDt;
	}
	// termDt
	
	public String getTermDt() {
		return termDt;
	}
	// mdcdId
	
	public void setMdcdId(String mdcdId) {
		this.mdcdId = mdcdId;
	}
	// state
	
	public void setState(String state) {
		this.state = state;
	}
	// status
	
	public void setStatus(String status) {
		this.status = status;
	}
	// efctvDt
	
	public void setEfctvDt(String efctvDt) {
		this.efctvDt = efctvDt;
	}
	// termDt
	
	public void setTermDt(String termDt) {
		this.termDt = termDt;
	}
	
	

}
