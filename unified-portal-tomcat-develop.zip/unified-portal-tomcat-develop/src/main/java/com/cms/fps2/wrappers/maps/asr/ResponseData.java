package com.cms.fps2.wrappers.maps.asr;

import com.cms.fps2.wrappers.details.Provider;

public class ResponseData {
	private Provider provider = new Provider();
	private String prioritized;
	private String recentAlerts;
	private String recentEdits;
	private String recentInv;
	private String hasEdits;
	private String hasInv;
	private String hasSysTags;
	private String hasNotes;
	private String hasPartD;
	
	//constructor
	public ResponseData(){}
	
	//provider
	public Provider getProvider() {
		return provider;
	}
	
	public void setProvider(Provider provider) {
		this.provider = provider;
	}
	
	//prioritized
	public String getPrioritized() {
		return prioritized;
	}
	
	public void setPrioritized(String prioritized) {
		this.prioritized = prioritized;
	}
	
	//recentAlerts
	public String getRecentAlerts() {
		return recentAlerts;
	}
	
	public void setRecentAlerts(String recentAlerts) {
		this.recentAlerts = recentAlerts;
	}
	
	//recentEdits
	public String getRecentEdits() {
		return recentEdits;
	}
	
	public void setRecentEdits(String recentEdits) {
		this.recentEdits = recentEdits;
	}
	
	//recentInv
	public String getRecentInv() {
		return recentInv;
	}
	
	public void setRecentInv(String recentInv) {
		this.recentInv = recentInv;
	}
	
	//hasEdits
	public String getHasEdits() {
		return hasEdits;
	}
	
	public void setHasEdits(String hasEdits) {
		this.hasEdits = hasEdits;
	}
	
	//hasInv
	public String getHasInv() {
		return hasInv;
	}
	
	public void setHasInv(String hasInv) {
		this.hasInv = hasInv;
	}
	
	//hasSysTags
	public String getHasSysTags() {
		return hasSysTags;
	}
	
	public void setHasSysTags(String hasSysTags) {
		this.hasSysTags = hasSysTags;
	}
	
	//hasNotes
	public String getHasNotes() {
		return hasNotes;
	}
	
	public void setHasNotes(String hasNotes) {
		this.hasNotes = hasNotes;
	}
	
	//hasPartD
	public String getHasPartD() {
		return hasPartD;
	}
	
	public void setHasPartD(String hasPartD) {
		this.hasPartD = hasPartD;
	}
}
