package com.cms.fps2.wrappers.landing;

public class WorkItem {
	
	private String ownerId;
	private String listId;
	private String listType;
	private String listNm;
	private String ownerNm;
	private String sharedInd;
	private String createDt;
	private String listCnt;
	private String prioritizedCnt;
	private String grpId;
	private String grpNm;
	private String publicInd;
	private String removedInd;
	private String asrType;
	
	// constructor
	public WorkItem() {}
	
	// ownerId
	public String getOwnerId() {
		return ownerId;
	}
	
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
	
	// listId
	public String getListId() {
		return listId;
	}
	
	public void setListId(String listId) {
		this.listId = listId;
	}
	
	// listType
	public String getListType() {
		return listType;
	}
	
	public void setListType(String listType) {
		this.listType = listType;
	}
	
	// listNm
	public String getListNm() {
		return listNm;
	}
	
	public void setListNm(String listNm) {
		this.listNm = listNm;
	}
	
	// ownerNm
	public String getOwnerNm() {
		return ownerNm;
	}
	
	public void setOwnerNm(String ownerNm) {
		this.ownerNm = ownerNm;
	}
	
	// sharedInd
	public String getSharedInd() {
		return sharedInd;
	}
	
	public void setSharedInd(String sharedInd) {
		this.sharedInd = sharedInd;
	}
	
	// createDt
	public String getCreateDt() {
		return createDt;
	}
	
	public void setCreateDt(String createDt) {
		this.createDt = createDt;
	}
	
	// listCnt
	public String getListCnt() {
		return listCnt;
	}
	
	public void setListCnt(String listCnt) {
		this.listCnt = listCnt;
	}
	
	// prioritizedCnt
	public String getPrioritizedCnt() {
		return prioritizedCnt;
	}
	
	public void setPrioritizedCnt(String prioritizedCnt) {
		this.prioritizedCnt = prioritizedCnt;
	}
	
	// grpId
	public String getGrpId() {
		return grpId;
	}
	
	public void setGrpId(String grpId) {
		this.grpId = grpId;
	}
	
	// grpNm
	public String getGrpNm() {
		return grpNm;
	}
	
	public void setGrpNm(String grpNm) {
		this.grpNm = grpNm;
	}
	
	// publicInd
	public String getPublicInd() {
		return publicInd;
	}
	
	public void setPublicInd(String publicInd) {
		this.publicInd = publicInd;
	}
	
	// removedInd
	public String getRemovedInd() {
		return removedInd;
	}
	
	public void setRemovedInd(String removedInd) {
		this.removedInd = removedInd;
	}

	// asrType
	public String getAsrType() {
		return asrType;
	}
	
	public void setAsrType(String asrType) {
		this.asrType = asrType;
	}
}

