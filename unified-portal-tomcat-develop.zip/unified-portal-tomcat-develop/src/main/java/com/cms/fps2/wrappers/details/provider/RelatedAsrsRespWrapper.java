package com.cms.fps2.wrappers.details.provider;

public class RelatedAsrsRespWrapper {
	private RelatedAsrsResponseData responseData = new RelatedAsrsResponseData();
	
	// constructor
	public RelatedAsrsRespWrapper() {}
	
	//responseData
	public RelatedAsrsResponseData getResponseData() {
		return responseData;
	}
	
	public void setResponseData(RelatedAsrsResponseData responseData) {
		this.responseData = responseData;
	}
}
