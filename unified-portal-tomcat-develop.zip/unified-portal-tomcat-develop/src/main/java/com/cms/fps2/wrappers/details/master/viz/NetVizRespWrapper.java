package com.cms.fps2.wrappers.details.master.viz;

import java.util.ArrayList;
import java.util.List;


public class NetVizRespWrapper {
	private List<Nodes> nodes = new ArrayList<Nodes>();
	private List<Edges> edges = new ArrayList<Edges>();
	private List<Attributes> attributes = new ArrayList<Attributes>();
	
	//constructor
	public NetVizRespWrapper(){}
	
	//nodes
	public List<Nodes> getNodes() {
		return nodes;
	}
	
	public void setNodes(List<Nodes> nodes) {
		this.nodes = nodes;
	}
	
	//edges
	public List<Edges> getEdges() {
		return edges;
	}
	
	public void setEdges(List<Edges> edges) {
		this.edges = edges;
	}
	
	//attributes
	public List<Attributes> getAttributes() {
		return attributes;
	}
	
	public void setAttributes(List<Attributes> attributes) {
		this.attributes = attributes;
	}
}
