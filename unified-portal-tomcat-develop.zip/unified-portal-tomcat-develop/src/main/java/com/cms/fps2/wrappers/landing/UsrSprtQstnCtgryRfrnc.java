package com.cms.fps2.wrappers.landing;

public class UsrSprtQstnCtgryRfrnc {
	
	private String usrSprtQstnCtgryCd;
	private String usrSprtQstnCtgryDesc;
	private String actvInd;
	private UsrSprtQstnSbctgryRfrnc fpsUsrSprtQstnSbctgryRfrnc;
	
	//constructor
	public UsrSprtQstnCtgryRfrnc() {}
	
	//usrSprtQstnCtgryCd
	public String getUsrSprtQstnCtgryCd() {
		return usrSprtQstnCtgryCd;
	}
	
	public void setUsrSprtQstnCtgryCd(String usrSprtQstnCtgryCd) {
		this.usrSprtQstnCtgryCd = usrSprtQstnCtgryCd;
	}
	
	//usrSprtQstnCtgryDesc
	public String getUsrSprtQstnCtgryDesc() {
		return usrSprtQstnCtgryDesc;
	}
	
	public void setUsrSprtQstnCtgryDesc(String usrSprtQstnCtgryDesc) {
		this.usrSprtQstnCtgryDesc = usrSprtQstnCtgryDesc;
	}
	
	//actvInd
	public String getActvInd() {
		return actvInd;
	}
	
	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}
	
	//fpsUsrSprtQstnSbctgryRfrnc
	public UsrSprtQstnSbctgryRfrnc getFpsUsrSprtQstnSbctgryRfrnc() {
		return fpsUsrSprtQstnSbctgryRfrnc;
	}
	
	public void setFpsUsrSprtQstnSbctgryRfrnc(UsrSprtQstnSbctgryRfrnc fpsUsrSprtQstnSbctgryRfrnc) {
		this.fpsUsrSprtQstnSbctgryRfrnc = fpsUsrSprtQstnSbctgryRfrnc;
	}
}
