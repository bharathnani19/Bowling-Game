package com.cms.fps2.wrappers.refdata;

import java.util.ArrayList;
import java.util.List;

public class RefDataWrapper {
	
	private List<Models> models = new ArrayList<Models>();
	private List<Zones> zones = new ArrayList<Zones>();
	private List<Users> users = new ArrayList<Users>();
	private List<Alerts> alerts = new ArrayList<Alerts>();
	private List<States> states = new ArrayList<States>();
	private List<Rulings> rulings = new ArrayList<Rulings>();
	private List<Actions> actions = new ArrayList<Actions>();
	private List<Activities> activities = new ArrayList<Activities>();
	private List<ZoneNoMacs> zoneNoMacs = new ArrayList<ZoneNoMacs>();
	
	//constructor
	public RefDataWrapper(){}
	
	//models
	public List<Models> getModels() {
		return models;		
	}
		
	public void setModels(List<Models> models) {
		this.models = models;
	}
	
	//zones 	
	public List<Zones> getZones() {
		return zones;
	}
	
	public void setZones(List<Zones> zones) {
		this.zones = zones;
	}
	
	//users 	
	public List<Users> getUsers() {
		return users;
	}
	
	public void setUsers(List<Users> users) {
		this.users = users;
	}
	
	//alerts 	
	public List<Alerts> getAlerts() {
		return alerts;
	}
	
	public void setAlerts(List<Alerts> alerts) {
		this.alerts = alerts;
	}
	
	//states
	public List<States> getStates() {
		return states;
	}
	
	public void setStates(List<States> states) {
		this.states = states;
	}
	
	//rulings
	public List<Rulings> getRulings() {
		return rulings;
	}
		
	public void setRulings(List<Rulings> rulings) {
		this.rulings = rulings;
	}
		
	//activities
	public List<Activities> getActivities() {
		return activities;
	}
		
	public void setActivities(List<Activities> activities) {
		this.activities = activities;
	}
		
	//actions
	public List<Actions> getActions() {
		return actions;
	}
		
	public void setActions(List<Actions> actions) {
		this.actions = actions;
	}
	
	//zones no macs	
	public List<ZoneNoMacs> getZoneNoMacs() {
		return zoneNoMacs;
	}
	
	public void setZoneNoMacs(List<ZoneNoMacs> zoneNoMacs) {
		this.zoneNoMacs = zoneNoMacs;
	}
}
