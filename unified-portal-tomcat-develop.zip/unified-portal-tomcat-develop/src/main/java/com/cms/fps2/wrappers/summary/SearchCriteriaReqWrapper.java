package com.cms.fps2.wrappers.summary;

public class SearchCriteriaReqWrapper {
	
	private String userId;
	private String searchId;
	
	// constructor
	public SearchCriteriaReqWrapper() {}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	// searchId
	public String getSearchId() {
		return searchId;
	}
	
	public void setSearchId(String searchId) {
		this.searchId = searchId;
	}
}
