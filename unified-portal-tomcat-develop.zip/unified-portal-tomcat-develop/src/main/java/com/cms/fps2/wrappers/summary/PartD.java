package com.cms.fps2.wrappers.summary;

import java.util.ArrayList;
import java.util.List;

public class PartD {
	private String count;
	private List<Items> items = new ArrayList<Items>();
	
	//empty constructor
	public PartD(){}
	
	//count
	public String getCount() {
		return count;
	}
	
	public void setCount(String count) {
		this.count = count;
	}
	
	//items
	public List<Items> getItems() {
		return items;
	}
	
	public void setItems(List<Items> items) {
		this.items = items;
	}

}
