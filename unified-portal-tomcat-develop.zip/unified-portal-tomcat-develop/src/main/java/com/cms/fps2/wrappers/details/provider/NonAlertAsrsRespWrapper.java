package com.cms.fps2.wrappers.details.provider;

public class NonAlertAsrsRespWrapper {
	private NonAlertAsrsResponseData responseData = new NonAlertAsrsResponseData();
	
	// constructor
	public NonAlertAsrsRespWrapper(){}
	
	// responseData
	public NonAlertAsrsResponseData getResponseData() {
		return responseData;
	}
	
	public void setResponseData(NonAlertAsrsResponseData responseData) {
		this.responseData = responseData;
	}
}
