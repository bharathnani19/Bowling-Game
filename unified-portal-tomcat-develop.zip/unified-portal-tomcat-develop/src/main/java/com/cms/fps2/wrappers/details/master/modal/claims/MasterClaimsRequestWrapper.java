package com.cms.fps2.wrappers.details.master.modal.claims;

public class MasterClaimsRequestWrapper {
	
	private String npi;
	private String modelId;
	private String userId;
	private String insertDt;
	private String claimsType;
	
	//constructor
	public MasterClaimsRequestWrapper(){};
	
	//npi
	public String getNpi() {
		return npi;
	}
	
	public void setNpi(String npi) {
		this.npi = npi;
	}
	
	//modelId
	public String getModelId() {
		return modelId;
	}
	
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//insertDt
	public String getInsertDt() {
		return insertDt;
	}
	
	public void setInsertDt(String insertDt) {
		this.insertDt = insertDt;
	}
	
	// claimsType
	public String getClaimsType() {
		return claimsType;
	}
	
	public void setClaimsType(String claimsType) {
		this.claimsType = claimsType;
	}
}
