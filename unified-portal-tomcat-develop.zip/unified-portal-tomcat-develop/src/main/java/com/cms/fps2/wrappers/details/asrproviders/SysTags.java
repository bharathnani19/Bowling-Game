package com.cms.fps2.wrappers.details.asrproviders;

import java.util.ArrayList;
import java.util.List;

public class SysTags {
	
	private List<String> fids = new ArrayList<String>();
	private List<String> bius = new ArrayList<String>();
	private List<String> ucms = new ArrayList<String>();
	private List<String> sysTags = new ArrayList<String>();
	
	//constructor
	public SysTags(){}
	
	//fids 	
	public List<String> getFids() {
		return fids;
	}
	
	public void setFids(List<String> fids) {
		this.fids = fids;
	}
	
	//bius 	
	public List<String> getBius() {
		return bius;
	}
	
	public void setBius(List<String> bius) {
		this.bius = bius;
	}
	
	//ucms 	
	public List<String> getUcms() {
		return ucms;
	}
	
	public void setUcms(List<String> ucms) {
		this.ucms = ucms;
	}
	
	//sysTags 	
	public List<String> getSysTags() {
		return sysTags;
	}
	
	public void setSysTags(List<String> sysTags) {
		this.sysTags = sysTags;
	}
}
