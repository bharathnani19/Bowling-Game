package com.cms.fps2.wrappers.details.tab.edits;

import java.util.ArrayList;
import java.util.List;

public class EditDetailsRespWrapper {
	List<ActiveEditInfos> activeEditInfos = new ArrayList<ActiveEditInfos>();
	
	// constructor
	public EditDetailsRespWrapper() {}
	
	// activeEditInfos
	public List<ActiveEditInfos> getActiveEditInfos() {
		return activeEditInfos;
	}
	
	public void setActiveEditInfos(List<ActiveEditInfos> activeEditInfos) {
		this.activeEditInfos = activeEditInfos;
	}
	
	
}
