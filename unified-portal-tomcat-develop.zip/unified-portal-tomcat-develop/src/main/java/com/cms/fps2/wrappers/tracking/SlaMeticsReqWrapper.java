package com.cms.fps2.wrappers.tracking;

public class SlaMeticsReqWrapper {
	
	private String userId;
	private String dateTime;
	private String eventType;
	private String zone;
	
	
	// constructor
	public SlaMeticsReqWrapper() {}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	// dateTime
	public String getDateTime() {
		return dateTime;
	}
	
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}
	
	// eventType
	public String getEventType() {
		return eventType;
	}
	
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	// zone
	
	public String getZone() {
		return zone;
	}

	// zone
	 
	public void setZone(String zone) {
		this.zone = zone;
	}
	
}
