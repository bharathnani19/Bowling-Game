package com.cms.fps2.wrappers.details.tab.edits;

public class EditAllClaimsReqWrapper {
	private String editName;	
	private String userId;
	private String npi;
	
	// constructor
	public EditAllClaimsReqWrapper() {}
	
	// editName
	public String getEditName() {
		return editName;
	}
	
	public void setEditName(String editName) {
		this.editName = editName;
	}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	// npi
	public String getNpi() {
		return npi;
	}
	
	public void setNpi(String npi) {
		this.npi = npi;
	}
	
}
