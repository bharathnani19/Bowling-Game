package com.cms.fps2.wrappers.rptcard;

import java.util.ArrayList;
import java.util.List;

public class DataRows {
	private List<Data> data = new ArrayList<Data>();
	
	//constructor
	public DataRows() {}
	
	//data
	public List<Data> getData() {
		return data;
	}
	
	public void setData(List<Data> data) {
		this.data = data;
	}
}
