package com.cms.fps2.wrappers.details.tab.partdrpt;

public class ResponseData {
	private String prioritized;
	private PartD partD;
	
	//constructor
	public ResponseData(){}
	
	//prioritized
	public String getPrioritized() {
		return prioritized;
	}
	
	public void setPrioritized(String prioritized) {
		this.prioritized = prioritized;
	}
	
	//partD
	public PartD getPartD() {
		return partD;
	}
	
	public void setPartD(PartD partD) {
		this.partD = partD;
	}

}
