package com.cms.fps2.wrappers.summary.workitems;

public class AddtoExclusionListReq {
	private String userId;
	private String reqStr;
	
	// constructor
	public AddtoExclusionListReq() {}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	// reqStr
	public String getReqStr() {
		return reqStr;
	}
	
	public void setReqStr(String reqStr) {
		this.reqStr = reqStr;
	}

}
