package com.cms.fps2.wrappers.ucm.leads;

import java.util.ArrayList;
import java.util.List;

public class Leads {
	
	private String id;
	private String activities;
	private String actions;
	private String ucmId;
	private List<UcmActions> ucmActions = new ArrayList<UcmActions>(); 
	private List<UcmActivities> ucmActivities = new ArrayList<UcmActivities>();
	private List<UcmBarriers> ucmBarriers = new ArrayList<UcmBarriers>();
	private List<UcmRulings> ucmRulings = new ArrayList<UcmRulings>();
	private List<UcmModelRatings> ucmModelRatings = new ArrayList<UcmModelRatings>();
	private String ruling;
		
	//empty constructor
	public Leads(){}
	
	//id
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	//activities
	public String getActivities() {
		return activities;
	}
	
	public void setActivities(String activities) {
		this.activities = activities;
	}
	
	//actions
	public String getActions() {
		return actions;
	}
	
	public void setActions(String actions) {
		this.actions = actions;
	}
	
	//ucmId
	public String getUcmId() {
		return ucmId;
	}
	
	public void setUcmId(String ucmId) {
		this.ucmId = ucmId;
	}
	
	//ucmActions
	public List<UcmActions> getUcmActions() {
		return ucmActions;
	}
	
	public void setUcmActions(List<UcmActions> ucmActions) {
		this.ucmActions = ucmActions;
	}
	
	//ucmActivities
	public List<UcmActivities> getUcmActivities() {
		return ucmActivities;
	}
	
	public void setUcmActivities(List<UcmActivities> ucmActivities) {
		this.ucmActivities = ucmActivities;
	}
	
	//ucmBarriers
	public List<UcmBarriers> getUcmBarriers() {
		return ucmBarriers;
	}
	
	public void setUcmBarriers(List<UcmBarriers> ucmBarriers) {
		this.ucmBarriers = ucmBarriers;
	}
	
	//ucmRulings
	public List<UcmRulings> getUcmRulings() {
		return ucmRulings;
	}
	
	public void setUcmRulings(List<UcmRulings> ucmRulings) {
		this.ucmRulings = ucmRulings;
	}
	
	//ucmModelRatings
	public List<UcmModelRatings> getUcmModelRatings() {
		return ucmModelRatings;
	}
	
	public void setUcmModelRatings(List<UcmModelRatings> ucmModelRatings) {
		this.ucmModelRatings = ucmModelRatings;
	}
	
	//ruling
	public String getRuling() {
		return ruling;
	}
	
	public void setRuling(String ruling) {
		this.ruling = ruling;
	}
}
