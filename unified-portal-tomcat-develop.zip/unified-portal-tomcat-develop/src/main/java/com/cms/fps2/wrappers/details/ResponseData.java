package com.cms.fps2.wrappers.details;

import java.util.ArrayList;
import java.util.List;
//import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.cms.fps2.wrappers.details.tab.partdrpt.PartD;
import com.cms.fps2.wrappers.summary.medicaid.MdcdTotalPayments;


//@JsonIgnoreProperties(ignoreUnknown=true)
public class ResponseData {
	private ClaimLines claimLines; 
	private List<Edits> edits = new ArrayList<Edits>();
	private List<History> history = new ArrayList<History>();
	private List<BillSummary> billSummary = new ArrayList<BillSummary>();
	private List<Leads> leads = new ArrayList<Leads>();
	private List<MasterAlert> masterAlert = new ArrayList<MasterAlert>();
	private List<MasterAlert> currentP1Alert = new  ArrayList<MasterAlert>();
	private List<Notes> notes = new ArrayList<Notes>();
	private Provider provider = new Provider();
	private Systags systags = new Systags();
	private List<TotalCostZones> totalCostZones = new ArrayList<TotalCostZones>();
	private List<TotalCostZones> p1TotalCostZones = new ArrayList<TotalCostZones>();
	private String prioritized;
	private String partDInd;
	private String recentAlerts;
	private String recentEdits;
	private String recentInv;
	private List<String> claimTypes = new ArrayList<String>();
	private PartD partD; 
	private String hasEdits;
	private String hasInv;
	private String hasSysTags;
	private String hasNotes;
	private String hasPartD;
	private String hasP1Alerts;
	private String hasClaims;
	private List<MasterAlert> oldAlert = new ArrayList<MasterAlert>();
	private List<MasterAlert> historyP1Alert = new ArrayList<MasterAlert>();
	private String hasLegacyInv;
	private List<ApsRecs> aps = new ArrayList<ApsRecs>();
	private AvailableClaims availableClaims = new AvailableClaims();
	private String asrDbId;
	private String mdcdAsrDbId;
	
	private List<MdcdTotalPayments> mdcdTotalPayments = new ArrayList<MdcdTotalPayments>();
	private List<MdcdUserStates> mdcdUserStates = new ArrayList<MdcdUserStates>();
	private String mdcdPrrtyEnabledInd;
	
	
	
	

	public String getMdcdPrrtyEnabledInd() {
		return mdcdPrrtyEnabledInd;
	}

	public void setMdcdPrrtyEnabledInd(String mdcdPrrtyEnabledInd) {
		this.mdcdPrrtyEnabledInd = mdcdPrrtyEnabledInd;
	}

	//constructor
	public ResponseData(){}
	
	//claimLines
	public ClaimLines getClaimLines() {
		return claimLines;
	}
	
	public void setClaimLines(ClaimLines claimLines) {
		this.claimLines = claimLines;
	}
	
	//edits
	public List<Edits> getEdits() {
		return edits;
	}
	
	public void setEdits(List<Edits> edits) {
		this.edits = edits;
	}
	
	//history
	public List<History> getHistory() {
		return history;
	}
	
	public void setHistory(List<History> history) {
		this.history = history;
	}

	//Bill Summary
	public List<BillSummary> getbillSummary() {
		return billSummary;
	}
	
	public void setbillSummary(List<BillSummary> billSummary) {
		this.billSummary = billSummary;
	}
	
	//leads
	public List<Leads> getLeads() {
		return leads;
	}
	
	public void setLeads(List<Leads> leads) {
		this.leads = leads;
	}

	//masterAlert
	public List<MasterAlert> getMasterAlert() {
		return masterAlert;
	}
	
	public void setMasterAlert(List<MasterAlert> masterAlert) {
		this.masterAlert = masterAlert;
	}

	//currentP1Alert
	public List<MasterAlert> getcurrentP1Alert() {
		return currentP1Alert;
	}
	
	public void setcurrentP1Alert(List<MasterAlert> currentP1Alert) {
		this.currentP1Alert = currentP1Alert;
	}
	
	//notes
	public List<Notes> getNotes() {
		return notes;
	}
	
	public void setNotes(List<Notes> notes) {
		this.notes = notes;
	}
	
	//provider
	public Provider getProvider() {
		return provider;
	}
	
	public void setProvider(Provider provider) {
		this.provider = provider;
	}
	
	//systags
	public Systags getSystags() {
		return systags;
	}
	
	public void setSystags(Systags systags) {
		this.systags = systags;
	}
	
	//totalCostZones
	public List<TotalCostZones> getTotalCostZones() {
		return totalCostZones;
	}
	
	public void setTotalCostZones(List<TotalCostZones> totalCostZones) {
		this.totalCostZones = totalCostZones;
	}

	//p1TotalCostZones
	public List<TotalCostZones> getP1TotalCostZones() {
		return p1TotalCostZones;
	}
	
	public void setP1TotalCostZones(List<TotalCostZones> p1TotalCostZones) {
		this.p1TotalCostZones = p1TotalCostZones;
	}
	
	
	//prioritized
	public String getPrioritized() {
		return prioritized;
	}
	
	public void setPrioritized(String prioritized) {
		this.prioritized = prioritized;
	}
	
	//partDInd
	public String getPartDInd() {
		return partDInd;
	}
	
	public void setPartDInd(String partDInd) {
		this.partDInd = partDInd;
	}
	
	//recentAlerts
	public String getRecentAlerts() {
		
		return recentAlerts;
	}
	
	public void setRecentAlerts(String recentAlerts) {
		this.recentAlerts = recentAlerts;
	}
	
	//recentEdits
	public String getRecentEdits() {
		
		return recentEdits;
	}
	
	public void setRecentEdits(String recentEdits) {
		this.recentEdits = recentEdits;
	}
	
	//recentInv
	public String getRecentInv() {
		
		return recentInv;
	}
	
	public void setRecentInv(String recentInv) {
		this.recentInv = recentInv;
	}
	
	//claimTypes
	public List<String> getClaimTypes() {
		return claimTypes;
	}
	
	public void setClaimTypes(List<String> claimTypes) {
		this.claimTypes = claimTypes;
	}
	
	// availableClaims
	public AvailableClaims getAvailableClaims() {
		return availableClaims;
	}
	
	public void setAvailableClaims(AvailableClaims availableClaims) {
		this.availableClaims = availableClaims;
	}
	
	//partD
	public PartD getPartD() {		
		return partD;
	}
	
	public void setPartD(PartD partD) {
		this.partD = partD;
	}
	//hasEdits
	public String getHasEdits() {		
		return hasEdits;
	}
	
	public void setHasEdits(String hasEdits) {
		this.hasEdits = hasEdits;
	}
	
	//hasInv
	public String getHasInv() {		
		return hasInv;
	}
	
	public void setHasInv(String hasInv) {
		this.hasInv = hasInv;
	}
	
	//hasSysTags
	public String getHasSysTags() {		
		return hasSysTags;
	}
	
	public void setHasSysTags(String hasSysTags) {
		this.hasSysTags = hasSysTags;
	}
	
	//hasNotes
	public String getHasNotes() {		
		return hasNotes;
	}
	
	public void setHasNotes(String hasNotes) {
		this.hasNotes = hasNotes;
	}
	
	//hasPartD
	public String getHasPartD() {		
		return hasPartD;
	}
	
	public void setHasPartD(String hasPartD) {
		this.hasPartD = hasPartD;
	}

	//hasP1Alerts
	public String getHasP1Alerts() {		
		return hasP1Alerts;
	}
	
	public void setHasP1Alerts(String hasP1Alerts) {
		this.hasP1Alerts = hasP1Alerts;
	}
	
	// hasClaims

	public String getHasClaims() {		
		return hasClaims;
	}
	
	public void setHasClaims(String hasClaims) {
		this.hasClaims = hasClaims;
	}
	
	// oldAlert
	public List<MasterAlert> getOldAlert() {
		return oldAlert;
	}

	public void setOldAlert(List<MasterAlert> oldAlert) {
		this.oldAlert = oldAlert;
	}

	// historyP1Alert
	public List<MasterAlert> getHistoryP1Alert() {
		return historyP1Alert;
	}

	public void setHistoryP1Alert(List<MasterAlert> historyP1Alert) {
		this.historyP1Alert = historyP1Alert;
	}
	
	//hasLegacyInv
	public String getHasLegacyInv() {		
		return hasLegacyInv;
	}
	
	public void setHasLegacyInv(String hasLegacyInv) {
		this.hasLegacyInv = hasLegacyInv;
	}
	
	// aps
	public List<ApsRecs> getAps() {
		return aps;
	}
	
	public void setAps(List<ApsRecs> aps) {
		this.aps = aps;
	}
	
	// asrDbId
	public String getAsrDbId() {
		return asrDbId;
	}
	
	public void setAsrDbId(String asrDbId) {
		this.asrDbId = asrDbId;
	}

	// mdcdTotalPayments
	
	public List<MdcdTotalPayments> getMdcdTotalPayments() {
		return mdcdTotalPayments;
	}

	// mdcdTotalPayments
	
	public void setMdcdTotalPayments(List<MdcdTotalPayments> mdcdTotalPayments) {
		this.mdcdTotalPayments = mdcdTotalPayments;
	}

	// mdcdAsrDbId
	
	public String getMdcdAsrDbId() {
		return mdcdAsrDbId;
	}

	// mdcdAsrDbId
	
	public void setMdcdAsrDbId(String mdcdAsrDbId) {
		this.mdcdAsrDbId = mdcdAsrDbId;
	}

	// mdcdUserStates
	
	public List<MdcdUserStates> getMdcdUserStates() {
		return mdcdUserStates;
	}

	// mdcdUserStates
	
	public void setMdcdUserStates(List<MdcdUserStates> mdcdUserStates) {
		this.mdcdUserStates = mdcdUserStates;
	}


}
