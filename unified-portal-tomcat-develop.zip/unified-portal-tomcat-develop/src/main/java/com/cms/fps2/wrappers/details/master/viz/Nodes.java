package com.cms.fps2.wrappers.details.master.viz;

public class Nodes {
	private String id;
    private String label;
	private String title;
	private Color color;    
	private String alertCstAmt;
	private String modelBusnsId;
	private String modelRunDt;
	private String prvdrNm;
	private String prvdrAddr1;
	private String prvdrAddr2;
	private String prvdrCity;
	private String prvdrState;
	private String prvdrZip;
	private String npi;
	private String subjPrvdrRole;
	private String prvdr1stNm;
	private String prvdrLastNm;
	private String borderWidth;
	private String claimType;
	private String totalPymt;
	private String alertStatus;
	private String investigations;
	private String lastAlertDt;
	private String riskScore;
	private String priorityScore;
	private String mac;
	private String upic;
	private String zr;
	private String leadInd;
	
	//constructor
	public Nodes(){}
	
	//id
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	//label
	public String getLabel() {
		return label;
	}
	
	public void setLabel(String label) {
		this.label = label;
	}
	
	//title
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	//color
	public Color getColor() {
		return color;
	}
	
	public void setColor(Color color) {
		this.color = color;
	}
	
	//alertCstAmt
	public String getAlertCstAmt() {
		return alertCstAmt;
	}
	
	public void setAlertCstAmt(String alertCstAmt) {
		this.alertCstAmt = alertCstAmt;
	}
	
	//modelBusnsId
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	
	//modelRunDt
	public String getModelRunDt() {
		return modelRunDt;
	}
	
	public void setModelRunDt(String modelRunDt) {
		this.modelRunDt = modelRunDt;
	}
	
	//prvdrNm
	public String getPrvdrNm() {
		return prvdrNm;
	}
	
	public void setPrvdrNm(String prvdrNm) {
		this.prvdrNm = prvdrNm;
	}
	
	//prvdrAddr1
	public String getPrvdrAddr1() {
		return prvdrAddr1;
	}
	
	public void setPrvdrAddr1(String prvdrAddr1) {
		this.prvdrAddr1 = prvdrAddr1;
	}
	
	//prvdrAddr2
	public String getPrvdrAddr2() {
		return prvdrAddr2;
	}
	
	public void setPrvdrAddr2(String prvdrAddr2) {
		this.prvdrAddr2 = prvdrAddr2;
	}
	
	//prvdrCity
	public String getPrvdrCity() {
		return prvdrCity;
	}
	
	public void setPrvdrCity(String prvdrCity) {
		this.prvdrCity = prvdrCity;
	}
	
	//prvdrState
	public String getPrvdrState() {
		return prvdrState;
	}
	
	public void setPrvdrState(String prvdrState) {
		this.prvdrState = prvdrState;
	}
	
	//prvdrZip
	public String getPrvdrZip() {
		return prvdrZip;
	}
	
	public void setPrvdrZip(String prvdrZip) {
		this.prvdrZip = prvdrZip;
	}
	
	//npi
	public String getNpi() {
		return npi;
	}
	
	public void setNpi(String npi) {
		this.npi = npi;
	}
	
	//subjPrvdrRole
	public String getSubjPrvdrRole() {
		return subjPrvdrRole;
	}
	
	public void setSubjPrvdrRole(String subjPrvdrRole) {
		this.subjPrvdrRole = subjPrvdrRole;
	}
	
	//prvdr1stNm
	public String getPrvdr1stNm() {
		return prvdr1stNm;
	}
	
	public void setPrvdr1stNm(String prvdr1stNm) {
		this.prvdr1stNm = prvdr1stNm;
	}
	
	//prvdrLastNm
	public String getPrvdrLastNm() {
		return prvdrLastNm;
	}
	
	public void setPrvdrLastNm(String prvdrLastNm) {
		this.prvdrLastNm = prvdrLastNm;
	}
	
	// borderWidth
	public String getBorderWidth() {
		return borderWidth;
	}
	
	public void setBorderWidth(String borderWidth) {
		this.borderWidth = borderWidth;
	}
	
	// claimType
	public String getClaimType() {
		return claimType;
	}
	
	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}
	
	// totalPymt
	public String getTotalPymt() {
		return totalPymt;
	}
	
	public void setTotalPymt(String totalPymt) {
		this.totalPymt = totalPymt;
	}
	
	// alertStatus
	public String getAlertStatus() {
		return alertStatus;
	}
	
	public void setAlertStatus(String alertStatus) {
		this.alertStatus = alertStatus;
	}
	
	// investigations
	public String getInvestigations() {
		return investigations;
	}
	
	public void setInvestigations(String investigations) {
		this.investigations = investigations;
	}
	
	// lastAlertDt
	public String getLastAlertDt() {
		return lastAlertDt;
	}
	
	public void setLastAlertDt(String lastAlertDt) {
		this.lastAlertDt = lastAlertDt;
	}
	
	// riskScore
	public String getRiskScore() {
		return riskScore;
	}
	
	public void setRiskScore(String riskScore) {
		this.riskScore = riskScore;
	}
	
	// priorityScore
	public String getPriorityScore() {
		return priorityScore;
	}
	
	public void setPriorityScore(String priorityScore) {
		this.priorityScore = priorityScore;
	}
	
	// mac
	public String getMac() {
		return mac;
	}
	
	public void setMac(String mac) {
		this.mac = mac;
	}
	
	// upic
	public String getUpic() {
		return upic;
	}
	
	public void setUpic(String upic) {
		this.upic = upic;
	}
	
	// zr
	public String getZr() {
		return zr;
	}
	
	public void setZr(String zr) {
		this.zr = zr;
	}
	
	// leadInd
	public String getLeadInd() {
		return leadInd;
	}
	
	public void setLeadInd(String leadInd) {
		this.leadInd = leadInd;
	}
	
}
