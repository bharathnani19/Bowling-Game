package com.cms.fps2.wrappers.landing;

import java.util.ArrayList;
import java.util.List;

public class ReportFavsRespWrapper {
	private String newSysMsgCt;
	private List<Reports> reports = new ArrayList<Reports>();
	
	//constructor
	public ReportFavsRespWrapper() {}
	
	//newSysMsgCt
	public String getNewSysMsgCt() {
		return newSysMsgCt;
	}
	
	public void setNewSysMsgCt(String newSysMsgCt) {
		this.newSysMsgCt = newSysMsgCt;
	}
	
	//reports
	public List<Reports> getReports() {
		return reports;
	}
	
	public void setReports(List<Reports> reports) {
		this.reports = reports;
	}
}
