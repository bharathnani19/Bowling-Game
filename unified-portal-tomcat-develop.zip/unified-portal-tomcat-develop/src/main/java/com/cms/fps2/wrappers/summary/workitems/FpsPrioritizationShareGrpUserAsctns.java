package com.cms.fps2.wrappers.summary.workitems;

public class FpsPrioritizationShareGrpUserAsctns {
	private String shareGrpId;
	private String shareUserId;
	private String actvInd;
	private String audtInsrtId;
	private String audtInsrtTs;
	private String audtUpdtId;
	private String audtUpdtTs;
	
	// constructor
	public FpsPrioritizationShareGrpUserAsctns() {}
	
	// shareGrpId
	public String getShareGrpId() {
		return shareGrpId;
	}
	
	public void setShareGrpId(String shareGrpId) {
		this.shareGrpId = shareGrpId;
	}
	
	// shareUserId
	public String getShareUserId() {
		return shareUserId;
	}
	
	public void setShareUserId(String shareUserId) {
		this.shareUserId = shareUserId;
	}
	
	// actvInd
	public String getActvInd() {
		return actvInd;
	}
	
	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}
	
	// audtInsrtId
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	
	// audtInsrtTs
	public String getAudtInsrtTs() {
		return audtInsrtTs;
	}
	
	public void setAudtInsrtTs(String audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	
	// audtUpdtId
	public String getAudtUpdtId() {
		return audtUpdtId;
	}
	
	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	
	// audtUpdtTs
	public String getAudtUpdtTs() {
		return audtUpdtTs;
	}
	
	public void setAudtUpdtTs(String audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
}
