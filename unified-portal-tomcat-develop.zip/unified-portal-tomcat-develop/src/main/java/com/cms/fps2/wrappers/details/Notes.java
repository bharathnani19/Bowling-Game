package com.cms.fps2.wrappers.details;

public class Notes {
	
	private String leaderInvId;
	private String note;
	private String activityActionRuling;
	private String recordedDt;
	private String userId;
	private String eventDt;
	
	//constructor
	Notes(){}
	
	//leaderInvId
	public String getLeaderInvId() {
		return leaderInvId;
	}
	
	public void setLeaderInvId(String leaderInvId) {
		this.leaderInvId = leaderInvId;
	}
	
	//note
	public String getNote() {
		return note;
	}
	
	public void setNote(String note) {
		this.note = note;
	}
	
	//activityActionRuling
	public String getActivityActionRuling() {
		return activityActionRuling;
	}
	
	public void setActivityActionRuling(String activityActionRuling) {
		this.activityActionRuling = activityActionRuling;
	}
	
	//recordedDt
	public String getRecordedDt() {
		return recordedDt;
	}
	
	public void setRecordedDt(String recordedDt) {
		this.recordedDt = recordedDt;
	}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//eventDt
	public String getEventDt() {
		return eventDt;
	}
	
	public void setEventDt(String eventDt) {
		this.eventDt = eventDt;
	}

}
