package com.cms.fps2.wrappers.details.tab.partdclaims;

import java.util.ArrayList;
import java.util.List;

public class PartdDlaimLinesRespWrapper {
	
	private List<PartDClaimLines> response = new ArrayList<PartDClaimLines>();
	
	//constructor
	public PartdDlaimLinesRespWrapper(){}
	
	//solrId
	public List<PartDClaimLines> getResponse() {
		return response;
	}
	
	public void setResponse(List<PartDClaimLines> response) {
		this.response = response;
	}
}
