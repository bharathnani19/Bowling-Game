package com.cms.fps2.wrappers.refdata;

public class Alerts {
	private String alertTypeCd;
	private String alertTypeDesc;
	
	//constructor
	public Alerts(){}
	
	//alertTypeCd
	public String getAlertTypeCd() {
		return alertTypeCd;
	}
	
	public void setAlertTypeCd(String alertTypeCd) {
		this.alertTypeCd = alertTypeCd;
	}
	
	//alertTypeDesc
	public String getAlertTypeDesc() {
		return alertTypeDesc;
	}
	
	public void setAlertTypeDesc(String alertTypeDesc) {
		this.alertTypeDesc = alertTypeDesc;
	}
	
}
