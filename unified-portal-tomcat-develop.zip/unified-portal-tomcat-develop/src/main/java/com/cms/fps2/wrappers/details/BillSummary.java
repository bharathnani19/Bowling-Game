package com.cms.fps2.wrappers.details;

public class BillSummary {
	private String asrptId;
	private String prvdrNpiNum;
	private String prvdrNm;
	private String upicJrsdctn;
	private String npiAlertTypeCd;
	private String clmBlngPrvdrNpiNum;
	private String rltdPrvdrName;
	private String clmPmtAmt;
	private String clmLineCnt;
	private String clmSbmtAmt;
	private String clmBeneCnt;
	private String modelBusnsId;
	private String clmSrcType;
	private String blngAsrptId;
	
	//constructor
	public BillSummary(){}
	
	
	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	//prvdrNpiNum
	public String getRecordedDt() {
		return prvdrNpiNum;
	}
	
	public void setprvdrNpiNum(String prvdrNpiNum) {
		this.prvdrNpiNum = prvdrNpiNum;
	}
	
	//prvdrNm
	public String getprvdrNm() {
		return prvdrNm;
	}
	
	public void setprvdrNm(String prvdrNm) {
		this.prvdrNm = prvdrNm;
	}
	
	//upicJrsdctn
	public String getupicJrsdctn() {
		return upicJrsdctn;
	}
	
	public void setupicJrsdctn(String upicJrsdctn) {
		this.upicJrsdctn = upicJrsdctn;
	}
	
	//npiAlertTypeCd
	public String getnpiAlertTypeCd() {
		return npiAlertTypeCd;
	}
	
	public void setnpiAlertTypeCd(String npiAlertTypeCd) {
		this.npiAlertTypeCd = npiAlertTypeCd;
	}
	
	//clmBlngPrvdrNpiNum
	public String getclmBlngPrvdrNpiNum() {
		return clmBlngPrvdrNpiNum;
	}
	
	public void setclmBlngPrvdrNpiNum(String clmBlngPrvdrNpiNum) {
		this.clmBlngPrvdrNpiNum = clmBlngPrvdrNpiNum;
	}	
	
	//rltdPrvdrName
	public String getrltdPrvdrName() {
		return rltdPrvdrName;
	}
	
	public void setrltdPrvdrName(String rltdPrvdrName) {
		this.rltdPrvdrName = rltdPrvdrName;
	}

	//clmPmtAmt
	public String getclmPmtAmt() {
		return clmPmtAmt;
	}
	
	public void setclmPmtAmt(String clmPmtAmt) {
		this.clmPmtAmt = clmPmtAmt;
	}
	
	//clmLineCnt
	public String getclmLineCnt() {
		return clmLineCnt;
	}
	
	public void setclmLineCnt(String clmLineCnt) {
		this.clmLineCnt = clmLineCnt;
	}

	//clmSbmtAmt
	public String getclmSbmtAmt() {
		return clmSbmtAmt;
	}
	
	public void setclmSbmtAmt(String clmSbmtAmt) {
		this.clmSbmtAmt = clmSbmtAmt;
	}

	//clmBeneCnt
	public String getclmBeneCnt() {
		return clmBeneCnt;
	}
	
	public void setclmBeneCnt(String clmBeneCnt) {
		this.clmBeneCnt = clmBeneCnt;
	}

	//modelBusnsId
	public String getmodelBusnsId() {
		return modelBusnsId;
	}
	
	public void setmodelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}

	//clmSrcType
	public String getclmSrcType() {
		return clmSrcType;
	}
	
	public void setclmSrcType(String clmSrcType) {
		this.clmSrcType = clmSrcType;
	}

	//blngAsrptId
	public String getblngAsrptId() {
		return blngAsrptId;
	}
	
	public void setblngAsrptId(String blngAsrptId) {
		this.blngAsrptId = blngAsrptId;
	}
}
