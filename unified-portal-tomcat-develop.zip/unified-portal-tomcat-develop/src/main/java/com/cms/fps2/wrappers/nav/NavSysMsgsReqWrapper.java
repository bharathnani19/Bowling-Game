package com.cms.fps2.wrappers.nav;

public class NavSysMsgsReqWrapper {
	
	private String userZone;
	private String userId;
	
	//constructor
	public NavSysMsgsReqWrapper (){}
	
	//userZone
	public String getUserZone() {
		return userZone;
	}
	
	public void setUserZone(String userZone) {
		this.userZone = userZone;
	}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
