package com.cms.fps2.wrappers.details.tab.partdclaims;

import java.util.ArrayList;
import java.util.List;

public class PartDClaimLines {
	private String solrId;
	private String claimType;
	private String beneId;
	private String beneFirstName;
	private String beneLastName;
	private String beneCity;
	private String beneAddress;
	private String beneAddress2;
	private String beneStateCd;
	private String beneZip;
	private String age;
	private String birthDt;
	private String deathDt;
	private String dualInd;
	private String claimFromDt;
	private String unitsService;
	private List<String> asrs = new ArrayList<String>();
	private List<String> asrAsctns = new ArrayList<String>();
	private String birthDtSolr;
	private String deathDtSolr;
	private String unitsServiceSolr;
	private String lineSubmittedAmtSolr;
	private String lineAllowedAmtSolr;
	private String lineProviderPaidAmtSolr;
	private String claimSubmittedAmtSolr;
	private String claimAllowedAmtSolr;
	private String claimProviderPaidAmtSolr;
	private String paymentAmtSolr;
	private String unitsAlwdSolr;
	private String clmLineBenePmtAmt;
	private String clmCtstrphcCvrgIndCd;
	private String clmCtstrphcCvrgIndDesc;
	private String clmUniqId;
	private String clmCmpndCd;
	private String clmLineCvrdPdAmt;
	private String clmLineDaysSuplyQty;
	private String clmDawProdSlctnCd;
	private String clmDawProdSlctnDesc;
	private String clmDspnsngStusCd;
	private String clmDspnsngStusDesc;
	private String clmDrugCvrgStusCd;
	private String clmDrugCvrgStusDesc;
	private String clmLineRxNum;
	private String clmLineLisAmt;
	private String clmLineNdcCd;
	private String clmLineNdcDesc;
	private String clmLineNdcQty;
	private String clmLineNdcQtyQlfyrCd;
	private String clmLineNcvrdPdAmt;
	private String clmLinePlroAmt;
	private String clmPdDt;
	private String prvdrPrsbngIdQlfyrCd;
	private String prvdrPrsbngIdQlfyrDesc;
	private String clmPrsbngPrvdrGnrcIdNum;
	private String clmCntrctOfRecCntrctNum;
	private String clmSrvcPrvdrGnrcIdNum;
	private String clmSbmtrCntrctNum;
	private String clmSbmtrCntrctPbpNum;
	private String clmLineOthrTpPdAmt;
	private String clmLineIngrdntCstAmt;
	private String clmLineSlsTaxAmt;
	private String clmLineSrvcCstAmt;
	private String prvdrSrvcIdQlfyrCd;
	private String prvdrSrvcIdQlfyrDesc;
	private String prvdrNcpdp1DspnsrTypeCd;
	private String prvdrNcpdp1DspnsrTypeDesc;
	private String prvdrNcpdp2DspnsrTypeCd;
	private String prvdrNcpdp2DspnsrTypeDesc;
	private String prvdrNcpdp3DspnsrTypeCd;
	private String prvdrNcpdp3DspnsrTypeDesc;
	private String prvdrNcpdpDspnsrClsCd;
	private String prvdrNcpdpDspnsrClsCdDesc;
	private String prvdrNcpdpId;
	private String prvdrNcpdpNpi;
	private String prvdrNcpdpDbaName;
	private String ndcBrndGnrcInd;
	private String ndcCd;
	private String ndcDeaClassDesc;
	private String ndcFdbDeaClsCd;
	private String ndcDeaClsCd;
	private String ndcDsgFormDesc;
	private String ndcFdbBrndGnrcDesc;
	private String ndcFdbPkgSizeAmt;
	private String ndcGpiNameExtnsnCd;
	private String ndcGpiNameExtnsnDesc;
	private String ndcGpiStgthCd;
	private String ndcLabelName;
	private String ndcMddbBrndGnrcCd;
	private String ndcMltTypeCd;
	private String ndcProdAbrvtnDesc;
	private String clmCntlNum;
	private String clmLineRxFillNum;
	private String clmCmpndDesc;
	private String totalPaidAmt;
	private String totalBilledAmt;
	private String lineRevUnitNum;	
	private String asrptId;
	private String claimNum;
	private String claimLineNum;
	private String lineFromDt;
	private String lineToDt;
	private String claimToDt;
	private String claimToReview;
	private String crossoverInd;
	private String modelString;
	private String asrKey;
	private String alertKey;
	private String attributeKey;
	private String lineFromDtSolr;
	private String lineToDtSolr;
	private String claimFromDtSolr;
	private String claimToDtSolr;
	private String prcdrDesc;
	
	//constructor
	public PartDClaimLines(){}
	
	//solrId
	public String getSolrId() {
		return solrId;
	}
	
	public void setSolrId(String solrId) {
		this.solrId = solrId;
	}
	
	//claimType
	public String getClaimType() {
		return claimType;
	}
	
	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}
	
	//beneId
	public String getBeneId() {
		return beneId;
	}
	
	public void setBeneId(String beneId) {
		this.beneId = beneId;
	}
	
	//beneFirstName
	public String getBeneFirstName() {
		return beneFirstName;
	}
	
	public void setBeneFirstName(String beneFirstName) {
		this.beneFirstName = beneFirstName;
	}
	
	//beneLastName
	public String getBeneLastName() {
		return beneLastName;
	}
	
	public void setBeneLastName(String beneLastName) {
		this.beneLastName = beneLastName;
	}
	
	//beneCity
	public String getBeneCity() {
		return beneCity;
	}
	
	public void setBeneCity(String beneCity) {
		this.beneCity = beneCity;
	}
	
	//beneAddress
	public String getBeneAddress() {
		return beneAddress;
	}
	
	public void setBeneAddress(String beneAddress) {
		this.beneAddress = beneAddress;
	}
	
	//beneAddress2
	public String getBeneAddress2() {
		return beneAddress2;
	}
	
	public void setBeneAddress2(String beneAddress2) {
		this.beneAddress2 = beneAddress2;
	}
	
	//beneStateCd
	public String getBeneStateCd() {
		return beneStateCd;
	}
	
	public void setBeneStateCd(String beneStateCd) {
		this.beneStateCd = beneStateCd;
	}
	
	//beneZip
	public String getBeneZip() {
		return beneZip;
	}
	
	public void setBeneZip(String beneZip) {
		this.beneZip = beneZip;
	}
	
	//age
	public String getAge() {
		return age;
	}
	
	public void setAge(String age) {
		this.age = age;
	}
	
	//birthDt
	public String getBirthDt() {
		return birthDt;
	}
	
	public void setBirthDt(String birthDt) {
		this.birthDt = birthDt;
	}
	
	//deathDt
	public String getDeathDt() {
		return deathDt;
	}
	
	public void setDeathDt(String deathDt) {
		this.deathDt = deathDt;
	}
	
	//dualInd
	public String getDualInd() {
		return dualInd;
	}
	
	public void setDualInd(String dualInd) {
		this.dualInd = dualInd;
	}
	
	//claimFromDt
	public String getClaimFromDt() {
		return claimFromDt;
	}
	
	public void setClaimFromDt(String claimFromDt) {
		this.claimFromDt = claimFromDt;
	}
	
	//unitsService
	public String getUnitsService() {
		return unitsService;
	}
	
	public void setUnitsService(String unitsService) {
		this.unitsService = unitsService;
	}
	
	//asrs
	public List<String> getAsrs() {
		return asrs;
	}
	
	public void setAsrs(List<String> asrs) {
		this.asrs = asrs;
	}
	
	//asrAsctns
	public List<String> getAsrAsctns() {
		return asrAsctns;
	}
	
	public void setAsrAsctns(List<String> asrAsctns) {
		this.asrAsctns = asrAsctns;
	}
	
	//birthDtSolr
	public String getBirthDtSolr() {
		return birthDtSolr;
	}
	
	public void setBirthDtSolr(String birthDtSolr) {
		this.birthDtSolr = birthDtSolr;
	}
	
	//deathDtSolr
	public String getDeathDtSolr() {
		return deathDtSolr;
	}
	
	public void setDeathDtSolr(String deathDtSolr) {
		this.deathDtSolr = deathDtSolr;
	}
	
	//unitsServiceSolr
	public String getUnitsServiceSolr() {
		return unitsServiceSolr;
	}
	
	public void setUnitsServiceSolr(String unitsServiceSolr) {
		this.unitsServiceSolr = unitsServiceSolr;
	}
	
	//lineSubmittedAmtSolr
	public String getLineSubmittedAmtSolr() {
		return lineSubmittedAmtSolr;
	}
	
	public void setLineSubmittedAmtSolr(String lineSubmittedAmtSolr) {
		this.lineSubmittedAmtSolr = lineSubmittedAmtSolr;
	}
	
	//lineAllowedAmtSolr
	public String getLineAllowedAmtSolr() {
		return lineAllowedAmtSolr;
	}
	
	public void setLineAllowedAmtSolr(String lineAllowedAmtSolr) {
		this.lineAllowedAmtSolr = lineAllowedAmtSolr;
	}
	
	//lineProviderPaidAmtSolr
	public String getLineProviderPaidAmtSolr() {
		return lineProviderPaidAmtSolr;
	}
	
	public void setLineProviderPaidAmtSolr(String lineProviderPaidAmtSolr) {
		this.lineProviderPaidAmtSolr = lineProviderPaidAmtSolr;
	}
	
	//claimSubmittedAmtSolr
	public String getClaimSubmittedAmtSolr() {
		return claimSubmittedAmtSolr;
	}
	
	public void setClaimSubmittedAmtSolr(String claimSubmittedAmtSolr) {
		this.claimSubmittedAmtSolr = claimSubmittedAmtSolr;
	}
	
	//claimAllowedAmtSolr
	public String getClaimAllowedAmtSolr() {
		return claimAllowedAmtSolr;
	}
	
	public void setClaimAllowedAmtSolr(String claimAllowedAmtSolr) {
		this.claimAllowedAmtSolr = claimAllowedAmtSolr;
	}
	
	//claimProviderPaidAmtSolr
	public String getClaimProviderPaidAmtSolr() {
		return claimProviderPaidAmtSolr;
	}
	
	public void setClaimProviderPaidAmtSolr(String claimProviderPaidAmtSolr) {
		this.claimProviderPaidAmtSolr = claimProviderPaidAmtSolr;
	}
	
	//paymentAmtSolr
	public String getPaymentAmtSolr() {
		return paymentAmtSolr;
	}
	
	public void setPaymentAmtSolr(String paymentAmtSolr) {
		this.paymentAmtSolr = paymentAmtSolr;
	}
	
	//unitsAlwdSolr
	public String getUnitsAlwdSolr() {
		return unitsAlwdSolr;
	}
	
	public void setUnitsAlwdSolr(String unitsAlwdSolr) {
		this.unitsAlwdSolr = unitsAlwdSolr;
	}
	
	//clmLineBenePmtAmt
	public String getClmLineBenePmtAmt() {
		return clmLineBenePmtAmt;
	}
	
	public void setClmLineBenePmtAmt(String clmLineBenePmtAmt) {
		this.clmLineBenePmtAmt = clmLineBenePmtAmt;
	}
	
	//clmCtstrphcCvrgIndCd
	public String getClmCtstrphcCvrgIndCd() {
		return clmCtstrphcCvrgIndCd;
	}
	
	public void setClmCtstrphcCvrgIndCd(String clmCtstrphcCvrgIndCd) {
		this.clmCtstrphcCvrgIndCd = clmCtstrphcCvrgIndCd;
	}
	
	//clmCtstrphcCvrgIndDesc
	public String getClmCtstrphcCvrgIndDesc() {
		return clmCtstrphcCvrgIndDesc;
	}
	
	public void setClmCtstrphcCvrgIndDesc(String clmCtstrphcCvrgIndDesc) {
		this.clmCtstrphcCvrgIndDesc = clmCtstrphcCvrgIndDesc;
	}
	
	//clmUniqId
	public String getClmUniqId() {
		return clmUniqId;
	}
	
	public void setClmUniqId(String clmUniqId) {
		this.clmUniqId = clmUniqId;
	}
	
	//clmCmpndCd
	public String getClmCmpndCd() {
		return clmCmpndCd;
	}
	
	public void setClmCmpndCd(String clmCmpndCd) {
		this.clmCmpndCd = clmCmpndCd;
	}
	
	//clmLineCvrdPdAmt
	public String getClmLineCvrdPdAmt() {
		return clmLineCvrdPdAmt;
	}
	
	public void setClmLineCvrdPdAmt(String clmLineCvrdPdAmt) {
		this.clmLineCvrdPdAmt = clmLineCvrdPdAmt;
	}
	
	//clmLineDaysSuplyQty
	public String getClmLineDaysSuplyQty() {
		return clmLineDaysSuplyQty;
	}
	
	public void setClmLineDaysSuplyQty(String clmLineDaysSuplyQty) {
		this.clmLineDaysSuplyQty = clmLineDaysSuplyQty;
	}
	
	//clmDawProdSlctnCd
	public String getClmDawProdSlctnCd() {
		return clmDawProdSlctnCd;
	}
	
	public void setClmDawProdSlctnCd(String clmDawProdSlctnCd) {
		this.clmDawProdSlctnCd = clmDawProdSlctnCd;
	}
	
	//clmDawProdSlctnDesc
	public String getClmDawProdSlctnDesc() {
		return clmDawProdSlctnDesc;
	}
	
	public void setClmDawProdSlctnDesc(String clmDawProdSlctnDesc) {
		this.clmDawProdSlctnDesc = clmDawProdSlctnDesc;
	}
	
	//clmDspnsngStusCd
	public String getClmDspnsngStusCd() {
		return clmDspnsngStusCd;
	}
	
	public void setClmDspnsngStusCd(String clmDspnsngStusCd) {
		this.clmDspnsngStusCd = clmDspnsngStusCd;
	}
	
	//clmDspnsngStusDesc
	public String getClmDspnsngStusDesc() {
		return clmDspnsngStusDesc;
	}
	
	public void setClmDspnsngStusDesc(String clmDspnsngStusDesc) {
		this.clmDspnsngStusDesc = clmDspnsngStusDesc;
	}
	
	//clmDrugCvrgStusCd
	public String getClmDrugCvrgStusCd() {
		return clmDrugCvrgStusCd;
	}
	
	public void setClmDrugCvrgStusCd(String clmDrugCvrgStusCd) {
		this.clmDrugCvrgStusCd = clmDrugCvrgStusCd;
	}
	
	//clmDrugCvrgStusDesc
	public String getClmDrugCvrgStusDesc() {
		return clmDrugCvrgStusDesc;
	}
	
	public void setClmDrugCvrgStusDesc(String clmDrugCvrgStusDesc) {
		this.clmDrugCvrgStusDesc = clmDrugCvrgStusDesc;
	}
	
	//clmLineRxNum
	public String getClmLineRxNum() {
		return clmLineRxNum;
	}
	
	public void setClmLineRxNum(String clmLineRxNum) {
		this.clmLineRxNum = clmLineRxNum;
	}
	
	//clmLineLisAmt
	public String getClmLineLisAmt() {
		return clmLineLisAmt;
	}
	
	public void setClmLineLisAmt(String clmLineLisAmt) {
		this.clmLineLisAmt = clmLineLisAmt;
	}
	
	//clmLineNdcCd
	public String getClmLineNdcCd() {
		return clmLineNdcCd;
	}
	
	public void setClmLineNdcCd(String clmLineNdcCd) {
		this.clmLineNdcCd = clmLineNdcCd;
	}
	
	//clmLineNdcDesc
	public String getClmLineNdcDesc() {
		return clmLineNdcDesc;
	}
	
	public void setClmLineNdcDesc(String clmLineNdcDesc) {
		this.clmLineNdcDesc = clmLineNdcDesc;
	}
	
	//clmLineNdcQty
	public String getClmLineNdcQty() {
		return clmLineNdcQty;
	}
	
	public void setClmLineNdcQty(String clmLineNdcQty) {
		this.clmLineNdcQty = clmLineNdcQty;
	}
	
	//clmLineNdcQtyQlfyrCd
	public String getClmLineNdcQtyQlfyrCd() {
		return clmLineNdcQtyQlfyrCd;
	}
	
	public void setClmLineNdcQtyQlfyrCd(String clmLineNdcQtyQlfyrCd) {
		this.clmLineNdcQtyQlfyrCd = clmLineNdcQtyQlfyrCd;
	}
	
	//clmLineNcvrdPdAmt
	public String getClmLineNcvrdPdAmt() {
		return clmLineNcvrdPdAmt;
	}
	
	public void setClmLineNcvrdPdAmt(String clmLineNcvrdPdAmt) {
		this.clmLineNcvrdPdAmt = clmLineNcvrdPdAmt;
	}
	
	//clmLinePlroAmt
	public String getClmLinePlroAmt() {
		return clmLinePlroAmt;
	}
	
	public void setClmLinePlroAmt(String clmLinePlroAmt) {
		this.clmLinePlroAmt = clmLinePlroAmt;
	}
	
	//clmPdDt
	public String getClmPdDt() {
		return clmPdDt;
	}
	
	public void setClmPdDt(String clmPdDt) {
		this.clmPdDt = clmPdDt;
	}
	
	//prvdrPrsbngIdQlfyrCd
	public String getPrvdrPrsbngIdQlfyrCd() {
		return prvdrPrsbngIdQlfyrCd;
	}
	
	public void setPrvdrPrsbngIdQlfyrCd(String prvdrPrsbngIdQlfyrCd) {
		this.prvdrPrsbngIdQlfyrCd = prvdrPrsbngIdQlfyrCd;
	}
	
	//prvdrPrsbngIdQlfyrDesc
	public String getPrvdrPrsbngIdQlfyrDesc() {
		return prvdrPrsbngIdQlfyrDesc;
	}
	
	public void setPrvdrPrsbngIdQlfyrDesc(String prvdrPrsbngIdQlfyrDesc) {
		this.prvdrPrsbngIdQlfyrDesc = prvdrPrsbngIdQlfyrDesc;
	}
	
	//clmPrsbngPrvdrGnrcIdNum
	public String getClmPrsbngPrvdrGnrcIdNum() {
		return clmPrsbngPrvdrGnrcIdNum;
	}
	
	public void setClmPrsbngPrvdrGnrcIdNum(String clmPrsbngPrvdrGnrcIdNum) {
		this.clmPrsbngPrvdrGnrcIdNum = clmPrsbngPrvdrGnrcIdNum;
	}
	
	//clmCntrctOfRecCntrctNum
	public String getClmCntrctOfRecCntrctNum() {
		return clmCntrctOfRecCntrctNum;
	}
	
	public void setClmCntrctOfRecCntrctNum(String clmCntrctOfRecCntrctNum) {
		this.clmCntrctOfRecCntrctNum = clmCntrctOfRecCntrctNum;
	}
	
	//clmSrvcPrvdrGnrcIdNum
	public String getClmSrvcPrvdrGnrcIdNum() {
		return clmSrvcPrvdrGnrcIdNum;
	}
	
	public void setClmSrvcPrvdrGnrcIdNum(String clmSrvcPrvdrGnrcIdNum) {
		this.clmSrvcPrvdrGnrcIdNum = clmSrvcPrvdrGnrcIdNum;
	}
	
	//clmSbmtrCntrctNum
	public String getClmSbmtrCntrctNum() {
		return clmSbmtrCntrctNum;
	}
	
	public void setClmSbmtrCntrctNum(String clmSbmtrCntrctNum) {
		this.clmSbmtrCntrctNum = clmSbmtrCntrctNum;
	}
	
	//clmSbmtrCntrctPbpNum
	public String getClmSbmtrCntrctPbpNum() {
		return clmSbmtrCntrctPbpNum;
	}
	
	public void setClmSbmtrCntrctPbpNum(String clmSbmtrCntrctPbpNum) {
		this.clmSbmtrCntrctPbpNum = clmSbmtrCntrctPbpNum;
	}
	
	//clmLineOthrTpPdAmt
	public String getClmLineOthrTpPdAmt() {
		return clmLineOthrTpPdAmt;
	}
	
	public void setClmLineOthrTpPdAmt(String clmLineOthrTpPdAmt) {
		this.clmLineOthrTpPdAmt = clmLineOthrTpPdAmt;
	}
	
	//clmLineIngrdntCstAmt
	public String getClmLineIngrdntCstAmt() {
		return clmLineIngrdntCstAmt;
	}
	
	public void setClmLineIngrdntCstAmt(String clmLineIngrdntCstAmt) {
		this.clmLineIngrdntCstAmt = clmLineIngrdntCstAmt;
	}
	
	//clmLineSlsTaxAmt
	public String getClmLineSlsTaxAmt() {
		return clmLineSlsTaxAmt;
	}
	
	public void setClmLineSlsTaxAmt(String clmLineSlsTaxAmt) {
		this.clmLineSlsTaxAmt = clmLineSlsTaxAmt;
	}
	
	//clmLineSrvcCstAmt
	public String getClmLineSrvcCstAmt() {
		return clmLineSrvcCstAmt;
	}
	
	public void setClmLineSrvcCstAmt(String clmLineSrvcCstAmt) {
		this.clmLineSrvcCstAmt = clmLineSrvcCstAmt;
	}
	
	//prvdrSrvcIdQlfyrCd
	public String getPrvdrSrvcIdQlfyrCd() {
		return prvdrSrvcIdQlfyrCd;
	}
	
	public void setPrvdrSrvcIdQlfyrCd(String prvdrSrvcIdQlfyrCd) {
		this.prvdrSrvcIdQlfyrCd = prvdrSrvcIdQlfyrCd;
	}
	
	//prvdrSrvcIdQlfyrDesc
	public String getPrvdrSrvcIdQlfyrDesc() {
		return prvdrSrvcIdQlfyrDesc;
	}
	
	public void setPrvdrSrvcIdQlfyrDesc(String prvdrSrvcIdQlfyrDesc) {
		this.prvdrSrvcIdQlfyrDesc = prvdrSrvcIdQlfyrDesc;
	}
	
	//prvdrNcpdp1DspnsrTypeCd
	public String getPrvdrNcpdp1DspnsrTypeCd() {
		return prvdrNcpdp1DspnsrTypeCd;
	}
	
	public void setPrvdrNcpdp1DspnsrTypeCd(String prvdrNcpdp1DspnsrTypeCd) {
		this.prvdrNcpdp1DspnsrTypeCd = prvdrNcpdp1DspnsrTypeCd;
	}
	
	//prvdrNcpdp1DspnsrTypeDesc
	public String getPrvdrNcpdp1DspnsrTypeDesc() {
		return prvdrNcpdp1DspnsrTypeDesc;
	}
	
	public void setPrvdrNcpdp1DspnsrTypeDesc(String prvdrNcpdp1DspnsrTypeDesc) {
		this.prvdrNcpdp1DspnsrTypeDesc = prvdrNcpdp1DspnsrTypeDesc;
	}
	
	//prvdrNcpdp2DspnsrTypeCd
	public String getPrvdrNcpdp2DspnsrTypeCd() {
		return prvdrNcpdp2DspnsrTypeCd;
	}
	
	public void setPrvdrNcpdp2DspnsrTypeCd(String prvdrNcpdp2DspnsrTypeCd) {
		this.prvdrNcpdp2DspnsrTypeCd = prvdrNcpdp2DspnsrTypeCd;
	}
	
	//prvdrNcpdp2DspnsrTypeDesc
	public String getPrvdrNcpdp2DspnsrTypeDesc() {
		return prvdrNcpdp2DspnsrTypeDesc;
	}
	
	public void setPrvdrNcpdp2DspnsrTypeDesc(String prvdrNcpdp2DspnsrTypeDesc) {
		this.prvdrNcpdp2DspnsrTypeDesc = prvdrNcpdp2DspnsrTypeDesc;
	}
	
	//prvdrNcpdp3DspnsrTypeCd
	public String getPrvdrNcpdp3DspnsrTypeCd() {
		return prvdrNcpdp3DspnsrTypeCd;
	}
	
	public void setPrvdrNcpdp3DspnsrTypeCd(String prvdrNcpdp3DspnsrTypeCd) {
		this.prvdrNcpdp3DspnsrTypeCd = prvdrNcpdp3DspnsrTypeCd;
	}
	
	//prvdrNcpdp3DspnsrTypeDesc
	public String getPrvdrNcpdp3DspnsrTypeDesc() {
		return prvdrNcpdp3DspnsrTypeDesc;
	}
	
	public void setPrvdrNcpdp3DspnsrTypeDesc(String prvdrNcpdp3DspnsrTypeDesc) {
		this.prvdrNcpdp3DspnsrTypeDesc = prvdrNcpdp3DspnsrTypeDesc;
	}
	
	//prvdrNcpdpDspnsrClsCd
	public String getPrvdrNcpdpDspnsrClsCd() {
		return prvdrNcpdpDspnsrClsCd;
	}
	
	public void setPrvdrNcpdpDspnsrClsCd(String prvdrNcpdpDspnsrClsCd) {
		this.prvdrNcpdpDspnsrClsCd = prvdrNcpdpDspnsrClsCd;
	}
	
	//prvdrNcpdpDspnsrClsCdDesc
	public String getPrvdrNcpdpDspnsrClsCdDesc() {
		return prvdrNcpdpDspnsrClsCdDesc;
	}
	
	public void setPrvdrNcpdpDspnsrClsCdDesc(String prvdrNcpdpDspnsrClsCdDesc) {
		this.prvdrNcpdpDspnsrClsCdDesc = prvdrNcpdpDspnsrClsCdDesc;
	}
	
	//prvdrNcpdpId
	public String getPrvdrNcpdpId() {
		return prvdrNcpdpId;
	}
	
	public void setPrvdrNcpdpId(String prvdrNcpdpId) {
		this.prvdrNcpdpId = prvdrNcpdpId;
	}
	
	//prvdrNcpdpNpi
	public String getPrvdrNcpdpNpi() {
		return prvdrNcpdpNpi;
	}
	
	public void setPrvdrNcpdpNpi(String prvdrNcpdpNpi) {
		this.prvdrNcpdpNpi = prvdrNcpdpNpi;
	}
	
	//prvdrNcpdpDbaName
	public String getPrvdrNcpdpDbaName() {
		return prvdrNcpdpDbaName;
	}
	
	public void setPrvdrNcpdpDbaName(String prvdrNcpdpDbaName) {
		this.prvdrNcpdpDbaName = prvdrNcpdpDbaName;
	}
	
	//ndcBrndGnrcInd
	public String getNdcBrndGnrcInd() {
		return ndcBrndGnrcInd;
	}
	
	public void setNdcBrndGnrcInd(String ndcBrndGnrcInd) {
		this.ndcBrndGnrcInd = ndcBrndGnrcInd;
	}
	
	//ndcCd
	public String getNdcCd() {
		return ndcCd;
	}
	
	public void setNdcCd(String ndcCd) {
		this.ndcCd = ndcCd;
	}
	
	//ndcDeaClassDesc
	public String getNdcDeaClassDesc() {
		return ndcDeaClassDesc;
	}
	
	public void setNdcDeaClassDesc(String ndcDeaClassDesc) {
		this.ndcDeaClassDesc = ndcDeaClassDesc;
	}
	
	//ndcFdbDeaClsCd
	public String getNdcFdbDeaClsCd() {
		return ndcFdbDeaClsCd;
	}
	
	public void setNdcFdbDeaClsCd(String ndcFdbDeaClsCd) {
		this.ndcFdbDeaClsCd = ndcFdbDeaClsCd;
	}
	
	//ndcDeaClsCd
	public String getNdcDeaClsCd() {
		return ndcDeaClsCd;
	}
	
	public void setNdcDeaClsCd(String ndcDeaClsCd) {
		this.ndcDeaClsCd = ndcDeaClsCd;
	}
	
	//ndcDsgFormDesc
	public String getNdcDsgFormDesc() {
		return ndcDsgFormDesc;
	}
	
	public void setNdcDsgFormDesc(String ndcDsgFormDesc) {
		this.ndcDsgFormDesc = ndcDsgFormDesc;
	}
	
	//ndcFdbBrndGnrcDesc
	public String getNdcFdbBrndGnrcDesc() {
		return ndcFdbBrndGnrcDesc;
	}
	
	public void setNdcFdbBrndGnrcDesc(String ndcFdbBrndGnrcDesc) {
		this.ndcFdbBrndGnrcDesc = ndcFdbBrndGnrcDesc;
	}
	
	//ndcFdbPkgSizeAmt
	public String getNdcFdbPkgSizeAmt() {
		return ndcFdbPkgSizeAmt;
	}
	
	public void setNdcFdbPkgSizeAmt(String ndcFdbPkgSizeAmt) {
		this.ndcFdbPkgSizeAmt = ndcFdbPkgSizeAmt;
	}
	
	//ndcGpiNameExtnsnCd
	public String getNdcGpiNameExtnsnCd() {
		return ndcGpiNameExtnsnCd;
	}
	
	public void setNdcGpiNameExtnsnCd(String ndcGpiNameExtnsnCd) {
		this.ndcGpiNameExtnsnCd = ndcGpiNameExtnsnCd;
	}
	
	//ndcGpiNameExtnsnDesc
	public String getNdcGpiNameExtnsnDesc() {
		return ndcGpiNameExtnsnDesc;
	}
	
	public void setNdcGpiNameExtnsnDesc(String ndcGpiNameExtnsnDesc) {
		this.ndcGpiNameExtnsnDesc = ndcGpiNameExtnsnDesc;
	}
	
	//ndcGpiStgthCd
	public String getNdcGpiStgthCd() {
		return ndcGpiStgthCd;
	}
	
	public void setNdcGpiStgthCd(String ndcGpiStgthCd) {
		this.ndcGpiStgthCd = ndcGpiStgthCd;
	}
	
	//ndcLabelName
	public String getNdcLabelName() {
		return ndcLabelName;
	}
	
	public void setNdcLabelName(String ndcLabelName) {
		this.ndcLabelName = ndcLabelName;
	}
	
	//ndcMddbBrndGnrcCd
	public String getNdcMddbBrndGnrcCd() {
		return ndcMddbBrndGnrcCd;
	}
	
	public void setNdcMddbBrndGnrcCd(String ndcMddbBrndGnrcCd) {
		this.ndcMddbBrndGnrcCd = ndcMddbBrndGnrcCd;
	}
	
	//ndcMltTypeCd
	public String getNdcMltTypeCd() {
		return ndcMltTypeCd;
	}
	
	public void setNdcMltTypeCd(String ndcMltTypeCd) {
		this.ndcMltTypeCd = ndcMltTypeCd;
	}
	
	//ndcProdAbrvtnDesc
	public String getNdcProdAbrvtnDesc() {
		return ndcProdAbrvtnDesc;
	}
	
	public void setNdcProdAbrvtnDesc(String ndcProdAbrvtnDesc) {
		this.ndcProdAbrvtnDesc = ndcProdAbrvtnDesc;
	}
	
	//clmCntlNum
	public String getClmCntlNum() {
		return clmCntlNum;
	}
	
	public void setClmCntlNum(String clmCntlNum) {
		this.clmCntlNum = clmCntlNum;
	}
	
	//clmCmpndDesc
	public String getClmCmpndDesc() {
		return clmCmpndDesc;
	}
	
	public void setClmCmpndDesc(String clmCmpndDesc) {
		this.clmCmpndDesc = clmCmpndDesc;
	}
	
	//totalPaidAmt
	public String getTotalPaidAmt() {
		return totalPaidAmt;
	}
	
	public void setTotalPaidAmt(String totalPaidAmt) {
		this.totalPaidAmt = totalPaidAmt;
	}
	
	//totalBilledAmt
	public String getTotalBilledAmt() {
		return totalBilledAmt;
	}
	
	public void setTotalBilledAmt(String totalBilledAmt) {
		this.totalBilledAmt = totalBilledAmt;
	}
	
	//lineRevUnitNum
	public String getLineRevUnitNum() {
		return lineRevUnitNum;
	}
	
	public void setLineRevUnitNum(String lineRevUnitNum) {
		this.lineRevUnitNum = lineRevUnitNum;
	}
	
	//clmLineRxFillNum
	public String getClmLineRxFillNum() {
		return clmLineRxFillNum;
	}
	
	public void setClmLineRxFillNum(String clmLineRxFillNum) {
		this.clmLineRxFillNum = clmLineRxFillNum;
	}
	
	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	//claimNum
	public String getClaimNum() {
		return claimNum;
	}
	
	public void setClaimNum(String claimNum) {
		this.claimNum = claimNum;
	}
	
	//claimLineNum
	public String getClaimLineNum() {
		return claimLineNum;
	}
	
	public void setClaimLineNum(String claimLineNum) {
		this.claimLineNum = claimLineNum;
	}
	
	//lineFromDt
	public String getLineFromDt() {
		return lineFromDt;
	}
	
	public void setLineFromDt(String lineFromDt) {
		this.lineFromDt = lineFromDt;
	}
	
	//lineToDt
	public String getLineToDt() {
		return lineToDt;
	}
	
	public void setLineToDt(String lineToDt) {
		this.lineToDt = lineToDt;
	}
	
	//claimToDt
	public String getClaimToDt() {
		return claimToDt;
	}
	
	public void setClaimToDt(String claimToDt) {
		this.claimToDt = claimToDt;
	}
	
	//claimToReview
	public String getClaimToReview() {
		return claimToReview;
	}
	
	public void setClaimToReview(String claimToReview) {
		this.claimToReview = claimToReview;
	}
	
	//crossoverInd
	public String getCrossoverInd() {
		return crossoverInd;
	}
	
	public void setCrossoverInd(String crossoverInd) {
		this.crossoverInd = crossoverInd;
	}
	
	//modelString
	public String getModelString() {
		return modelString;
	}
	
	public void setModelString(String modelString) {
		this.modelString = modelString;
	}
	
	//asrKey
	public String getAsrKey() {
		return asrKey;
	}
	
	public void setAsrKey(String asrKey) {
		this.asrKey = asrKey;
	}
	
	//alertKey
	public String getAlertKey() {
		return alertKey;
	}
	
	public void setAlertKey(String alertKey) {
		this.alertKey = alertKey;
	}
	
	//attributeKey
	public String getAttributeKey() {
		return attributeKey;
	}
	
	public void setAttributeKey(String attributeKey) {
		this.attributeKey = attributeKey;
	}
	
	//lineFromDtSolr
	public String getLineFromDtSolr() {
		return lineFromDtSolr;
	}
	
	public void setLineFromDtSolr(String lineFromDtSolr) {
		this.lineFromDtSolr = lineFromDtSolr;
	}
	
	//lineToDtSolr
	public String getLineToDtSolr() {
		return lineToDtSolr;
	}
	
	public void setLineToDtSolr(String lineToDtSolr) {
		this.lineToDtSolr = lineToDtSolr;
	}
	
	//claimFromDtSolr
	public String getClaimFromDtSolr() {
		return claimFromDtSolr;
	}
	
	public void setClaimFromDtSolr(String claimFromDtSolr) {
		this.claimFromDtSolr = claimFromDtSolr;
	}
	
	//claimToDtSolr
	public String getClaimToDtSolr() {
		return claimToDtSolr;
	}
	
	public void setClaimToDtSolr(String claimToDtSolr) {
		this.claimToDtSolr = claimToDtSolr;
	}
	
	//prcdrDesc
	public String getPrcdrDesc() {
		return prcdrDesc;
	}
	
	public void setPrcdrDesc(String prcdrDesc) {
		this.prcdrDesc = prcdrDesc;
	}
}
