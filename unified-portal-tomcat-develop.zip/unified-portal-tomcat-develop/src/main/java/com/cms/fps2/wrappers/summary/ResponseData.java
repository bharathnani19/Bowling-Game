package com.cms.fps2.wrappers.summary;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.refdata.CityStates;
import com.cms.fps2.wrappers.refdata.Models;
import com.cms.fps2.wrappers.summary.modals.MedicaidInfo;
import com.cms.fps2.wrappers.summary.modals.PriorityCriteria;

public class ResponseData {
	
	private String asrId;
	private String name;
	private String groupNpi;
	private String type;
	private List<SystemTags> systemTags = new ArrayList<SystemTags>();
	private List<ClaimTypes> claimTypes = new ArrayList<ClaimTypes>();
	private String claimLinesCnt;
	private String crossoverLinesCnt;
	private String cost;	
	private String riskScore;
	private String alertLinesCnt;
	private List<Alerts> alerts = new ArrayList<Alerts>();
	private String uniqueAlertBenesCnt;
	private String totalDualBenesCnt;
	private String dualBenePct;
	private String uniqueProcedures;
	private List<Procedures> procedures = new ArrayList<Procedures>();
	private String subjectStateCd;
	private String subjectZoneCd;
	private String subjectZoneCost;
	private String assignedZoneCd;
	private List<AssignedToUserIds> assignedToUserIds = new ArrayList<AssignedToUserIds>();
	private List<OpenLeadInvest> openLeadInvest = new ArrayList<OpenLeadInvest>();
	private List<OpenLeadInvest2> openLeadInvest2 = new ArrayList<OpenLeadInvest2>();
	private String ptanCnt;
	private String specialtyCnt;
	private List<Specialties> specialties = new ArrayList<Specialties>();
	private List<Activities> activities = new ArrayList<Activities>();
	private List<Actions> actions = new ArrayList<Actions>();
	private List<BarrierToActionCds> barrierToActionCds = new ArrayList<BarrierToActionCds>();
	private List<RulingChangeReasons> rulingChangeReasons = new ArrayList<RulingChangeReasons>();
	private String notSubjectChangeInd;
	private String notSuspectReason;
	private String lastUpdateDt;
	private String createdDt;
	private List<AssignedZoneCds> assignedZoneCds = new ArrayList<AssignedZoneCds>();
	private String notSuspectChangeInd;
	private String asrDbid;
	private String legacyScore;
	private String userCnt;
	private String activityCnt;
	private String barrierCdCnt;
	private String alertCnt;
	private String actionCnt;
	private String investCnt;
	private String procedureCnt;
	private String claimTypeCnt;
	private String legacyCost;
	private String state;
	private List<CurrentAlerts> currentAlerts = new ArrayList<CurrentAlerts>();
	private List<Priorities> priorities = new ArrayList<Priorities>();
	private String asrAlertStatus;
	private PartD partD;
	//added class to make part D sorting work correctly in the portal
	private String partDCount;
	private String mac;
	private String riskScoreModDt;
	private List<Ptans> ptans = new ArrayList<Ptans>();
	private String riskScoreDelta;
	private String riskScore90;
	private String riskScore180;
	private String riskScore365;
	private String riskScoreTrend;
	private String priorityScore;
	private List<CurrentAlerts> recentAlerts = new ArrayList<CurrentAlerts>();
	private List<CurrentAlerts> priorityAlerts = new ArrayList<CurrentAlerts>();
	private String priorityScoreModDt;
	private String priorityScoreDelta;
	private List<PriorityCriteria> priorityCriteria = new ArrayList<PriorityCriteria>();
	private String prevPriorityScore;
	private String zrType;
	private List<DrugClasses> drugClasses = new ArrayList<DrugClasses>();
	private List<CityStates> cityStates = new ArrayList<CityStates>();
	private String cityStateCnt;
	private String drugClassCnt;
	private String revocation;
	private String medicaid;
	private String ucmAsrId;
	private MedicaidInfo medicaidInfo;
	private String relLastAlertDt;
	private String lastAlertDt;
	private String revocationDate;
	private String revocationDesc;
	private List<EnrollmentId> enrollmentIds = new ArrayList<EnrollmentId>();
	private String enrollmentId;
	private List<LeadInvActions> leadInvActions = new ArrayList<LeadInvActions>();
	private List<LeadInvActivities> leadInvActivities = new ArrayList<LeadInvActivities>();
	private List<LeadInvRatings> leadInvRatings = new ArrayList<LeadInvRatings>();
	private String actionability;
	private String timeliness;
	private String aps;
	private String showMacEduReport;
	private String showUpicEduReport;
	private String showChowReport;
	private String hasPartD;
	private String wsLabel;
	private String relatedAsrCnt;
	private String nonAlertedPrvdrInd;
	private String dualBeneCntInd;
	
	private String clmTypeTxt;
	private String agedAlerts;
	private String submitAmt;
	private String totalPayment;
	private String earliestClmDt;
	private String lastClmDt;
	private String prvdrState;
	private String enrollmentStus;
	private String enrollmentStusRsn;
	private String enrollmentStusRsnDesc;
	private String prvdrPlaceNm;
	private String exclusion;
	private String mostRecentUcmClsdDt;
	private String biuCategory;
	private String zrCaseIds;
	private String biuComplaintsCnt;
	private String prioritizedOtherZone;
	private String ucmCaseIds;
	private String biuComplaints90Cnt;
	private String ucmSummary;
	private String lastEduDt;
	private String newAlerts;
	private String prioritizedMyZone;
	private String partDInd;
	private String claimLinesDCnt;
	private String beneDCnt;
	private String macCntrctrNum;
	private String lastAlertClmDt;
	private String listItemId;
	private String enrollmentStusDesc;
	private String ucmCaseStus;
	private String specialtyTxt;
	private String submitDAmt;
	private String prvdrEduProvBy;
	private String topCityStateTxt;
	private String totalPaymentD;
	private String billAfterEduInd;
	private String clmCntrctrNum;
	private String fraudTypeDesc;
	private String leadInd;
	private String cncStus;
	private String prvdrNm;
	private String revokedInd;
	private String exLabel;
	private String hasExclusionHistory;
	
	private String extractDt;
	private String asrptId;
	private String prvdrNpiNum;
	private String partAInd;
	private String partBInd;
	
	private String postEdInd;
	private String lastDateOfTpeEducation;
	private String tpeReviewRnd;
	private String tpeEduOffered;
	private String tpeReviewTopic;
	private String tpeRefRsn;
	private String riskScoreMethod;
	
	// Medicaid attributes
	private String mdcdSpecialty;
    private String mdcdSvcType;
    private String mdcdSvcSubCat;
    private String mdcdEnrollmentStatus;
    private String mdcdSubmitAmt;
    private String mdcdTotalPmt;
    private String mdcdRecipientCnt;
    private String mdcdClmCnt;
    private String mdcdBillingNpi;
    private String mdcdRiskScore;
    private String mdcdNewAlerts;
    private String mdcdAgedAlerts;
    private String mdcdStates;
    private String pathToEduInd;
    private String acoInd;


	// Phase 1 attributes
	
	private String p1NewAlerts;
    private String p1Cost;
    private String p1SubjZoneCd;
	private String p1EnableInd;
	
	
	
	//empty Constructor
	public ResponseData() {}
	
	//asrId
	public String getAsrId() {
		return asrId;
	}
	
	public void setAsrId(String asrId) {
		this.asrId = asrId;
	}
	
	//name
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	//npi
	public String getGroupNpi() {
		return groupNpi;
	}
	
	public void setGroupNpi(String groupNpi) {
		this.groupNpi = groupNpi;
	}
	
	//type
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	//system tag
	public List<SystemTags> getSystemTags() {
		return systemTags;
	}
	
	public void setSystemTags(List<SystemTags> systemTags) {
		this.systemTags = systemTags;
	}
	
	//claimTypes
	public List<ClaimTypes> getClaimTypes() {
		return claimTypes;
	}
	
	public void setClaimTypes(List<ClaimTypes> claimTypes) {
		this.claimTypes = claimTypes;
	}
	
	//lines
	public String getClaimLinesCnt() {
		return claimLinesCnt;
	}
	
	public void setClaimLinesCnt(String claimLinesCnt) {
		this.claimLinesCnt = claimLinesCnt;
	}
	
	//xOverLines
	public String getCrossoverLinesCnt() {
		return crossoverLinesCnt;
	}
	
	public void setCrossoverLinesCnt(String crossoverLinesCnt) {
		this.crossoverLinesCnt = crossoverLinesCnt;
	}
	
	//Cost
	public String getCost() {
		return cost;
	}
	
	public void setCost(String cost) {
		this.cost = cost;
	}
	
	// risk score
	public String getRiskScore() {
		return riskScore;
	}
	
	public void setRiskScore(String riskScore) {
		this.riskScore = riskScore;
	}
	
	//alertLinesNumber
	public String getAlertLinesCnt() {
		return alertLinesCnt;
	}
	
	public void setAlertLinesCnt(String alertLinesCnt) {
		this.alertLinesCnt = alertLinesCnt;
	}
	
	//alerts
	public List<Alerts> getAlerts() {
		return alerts;
	}
	
	public void setAlerts(List<Alerts> alerts) {
		this.alerts = alerts;
	}
	
	//beneProvider
	public String getUniqueAlertBenesCnt() {
		return uniqueAlertBenesCnt;
	}
	
	public void setUniqueAlertBenesCnt(String uniqueAlertBenesCnt) {
		this.uniqueAlertBenesCnt = uniqueAlertBenesCnt;
	}
	
	//dualBeneNumber
	public String getTotalDualBenesCnt() {
		return totalDualBenesCnt;
	}
	
	public void setTotalDualBenesCnt(String totalDualBenesCnt) {
		this.totalDualBenesCnt = totalDualBenesCnt;
	}
	
	//dualBenePercent
	public String getDualBenePct() {
		return dualBenePct;
	}
	
	public void setDualBenePct(String dualBenePct) {
		this.dualBenePct = dualBenePct;
	}
	
	//proceduresNumber
	public String getUniqueProcedures() {
		return uniqueProcedures;
	}
	
	public void setUniqueProcedures(String uniqueProcedures) {
		this.uniqueProcedures = uniqueProcedures;
	}
	
	//procedures
	public List<Procedures> getProcedures() {
		return procedures;
	}
	
	public void setProcedures(List<Procedures> procedures) {
		this.procedures = procedures;
	}
	
	//subjectState
	public String getSubjectStateCd() {
		return subjectStateCd;
	}
	
	public void setSubjectStateCd(String subjectStateCd) {
		this.subjectStateCd = subjectStateCd;
	}
	
	//subjectZone
	public String getSubjectZoneCd() {
		return subjectZoneCd;
	}
	
	public void setSubjectZoneCd(String subjectZoneCd) {
		this.subjectZoneCd = subjectZoneCd;
	}
	
	//subjectZoneCost
	public String getSubjectZoneCost() {
		return subjectZoneCost;
	}
	
	public void setSubjectZoneCost(String subjectZoneCost) {
		this.subjectZoneCost = subjectZoneCost;
	}
	
	//assignedZone
	public String getAssignedZoneCd() {
		return assignedZoneCd;
	}
	
	public void setAssignedZoneCd(String assignedZoneCd) {
		this.assignedZoneCd = assignedZoneCd;
	}
	
	//assignedTo
	public List<AssignedToUserIds> getAssignedToUserIds() {
		return assignedToUserIds;
	}
	
	public void setAssignedToUserIds(List<AssignedToUserIds> assignedToUserIds) {
		this.assignedToUserIds = assignedToUserIds;
	}
	
	//openLeadInvest
	public List<OpenLeadInvest> getOpenLeadInvest() {
		return openLeadInvest;
	}
	
	public void setOpenLeadInvest(List<OpenLeadInvest> openLeadInvest) {
		this.openLeadInvest = openLeadInvest;
	}
	
	//openLeadInvest2
	public List<OpenLeadInvest2> getOpenLeadInvest2() {
		return openLeadInvest2;
	}
	
	public void setOpenLeadInvest2(List<OpenLeadInvest2> openLeadInvest2) {
		this.openLeadInvest2 = openLeadInvest2;
	}
	
	//ptansNumber
	public String getPtanCnt() {
		return ptanCnt;
	}
	
	public void setPtanCnt(String ptanCnt) {
		this.ptanCnt = ptanCnt;
	}
	
	//specialtiesNumber
	public String getSpecialtyCnt() {
		return specialtyCnt;
	}
	
	public void setSpecialtyCnt(String specialtyCnt) {
		this.specialtyCnt = specialtyCnt;
	}
	
	//specialties
	public List<Specialties> getSpecialties() {
		return specialties;
	}
	
	public void setSpecialties(List<Specialties> specialties) {
		this.specialties = specialties;
	}
		
	//activities
	public List<Activities> getActivities() {
		return activities;
	}
	
	public void setActivities(List<Activities> activities) {
		this.activities = activities;
	}
		
	//actions
	public List<Actions> getActions() {
		return actions;
	}
	
	public void setActions(List<Actions> actions) {
		this.actions = actions;
	}
		
	//barrierToAction
	public List<BarrierToActionCds> getBarrierToActionCds() {
		return barrierToActionCds;
	}
	
	public void setBarrierToActionCds(List<BarrierToActionCds> barrierToActionCds) {
		this.barrierToActionCds = barrierToActionCds;
	}
		
	//rulingChangeReason
	public List<RulingChangeReasons> getRulingChangeReasons() {
		return rulingChangeReasons;
	}
	
	public void setRulingChangeReasons(List<RulingChangeReasons> rulingChangeReasons) {
		this.rulingChangeReasons = rulingChangeReasons;
	}
	
	//notSubjChangeIndicator
	public String getNotSubjectChangeInd() {
		return notSubjectChangeInd;
	}
	
	public void setNotSubjectChangeInd(String notSubjectChangeInd) {
		this.notSubjectChangeInd = notSubjectChangeInd;
	}
		
	//notSuspectReasons
	public String getNotSuspectReason() {
		return notSuspectReason;
	}
	
	public void setNotSuspectReason(String notSuspectReason) {
		this.notSuspectReason = notSuspectReason;
	}
	
	//lastUpdateDt
	public String getLastUpdateDt() {
		return lastUpdateDt;
	}
	
	public void setLastUpdateDt(String lastUpdateDt) {
		this.lastUpdateDt = lastUpdateDt;
	}
	
	//createdDt
	public String getCreatedDt() {
		return createdDt;
	}
	
	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}
	
	//assignedZoneCds
	public List<AssignedZoneCds> getAssignedZoneCds() {
		return assignedZoneCds;
	}
	
	public void setAssignedZoneCds(List<AssignedZoneCds> assignedZoneCds) {
		this.assignedZoneCds = assignedZoneCds;
	}
	
	//notSuspectChangeInd
	public String getNotSuspectChangeInd() {
		return notSuspectChangeInd;
	}
	
	public void setNotSuspectChangeInd(String notSuspectChangeInd) {
		this.notSuspectChangeInd = notSuspectChangeInd;
	}
	
	//asrDbid
	public String getAsrDbid() {
		return asrDbid;
	}
	
	public void setAsrDbid(String asrDbid) {
		this.asrDbid = asrDbid;
	}
	
	//legacyScore
	public String getLegacyScore() {
		return legacyScore;
	}
	
	public void setLegacyScore(String legacyScore) {
		this.legacyScore = legacyScore;
	}
	
	//userCnt
	public String getUserCnt() {
		return userCnt;
	}
	
	public void setUserCnt(String userCnt) {
		this.userCnt = userCnt;
	}
	
	//activityCnt
	public String getActivityCnt() {
		return activityCnt;
	}
	
	public void setActivityCnt(String activityCnt) {
		this.activityCnt = activityCnt;
	}
	
	//barrierCdCnt
	public String getBarrierCdCnt() {
		return barrierCdCnt;
	}
	
	public void setBarrierCdCnt(String barrierCdCnt) {
		this.barrierCdCnt = barrierCdCnt;
	}
	
	//alertCnt
	public String getAlertCnt() {
		return alertCnt;
	}
	
	public void setAlertCnt(String alertCnt) {
		this.alertCnt = alertCnt;
	}
	
	//actionCnt
	public String getActionCnt() {
		return actionCnt;
	}
	
	public void setActionCnt(String actionCnt) {
		this.actionCnt = actionCnt;
	}
	
	//investCnt
	public String getInvestCnt() {
		return investCnt;
	}
	
	public void setInvestCnt(String investCnt) {
		this.investCnt = investCnt;
	}
	
	//procedureCnt
	public String getProcedureCnt() {
		return procedureCnt;
	}
	
	public void setProcedureCnt(String procedureCnt) {
		this.procedureCnt = procedureCnt;
	}
	
	//claimTypeCnt
	public String getClaimTypeCnt() {
		return claimTypeCnt;
	}
	
	public void setClaimTypeCnt(String claimTypeCnt) {
		this.claimTypeCnt = claimTypeCnt;
	}
	
	//legacyCost
	public String getLegacyCost() {
		return legacyCost;
	}
	
	public void setLegacyCost(String legacyCost) {
		this.legacyCost = legacyCost;
	}
	
	//state
	public String getState() {
		return state;
	}
	
	public void setState(String state) {
		this.state = state;
	}
	
	//currentAlerts
	public List<CurrentAlerts> getCurrentAlerts() {
		return currentAlerts;
	}
	
	public void setCurrentAlerts(List<CurrentAlerts> currentAlerts) {
		this.currentAlerts = currentAlerts;
	}
	
	//priorities
	public List<Priorities> getPriorities() {
		return priorities;
	}
	
	public void setPriorities(List<Priorities> priorities) {
		this.priorities = priorities;
	}
	
	//asrAlertStatus
	public String getAsrAlertStatus() {
		return asrAlertStatus;
	}
	
	public void setAsrAlertStatus(String asrAlertStatus) {
		this.asrAlertStatus = asrAlertStatus;
	}
	
	//partD
	public PartD getPartD() {
		return partD;
	}
	
	public void setPartD(PartD partD) {
		this.partD = partD;
	}
	
	//partDCount
	public String getPartDCount() {
		if (getPartD() != null) {
			partDCount = getPartD().getCount();
		}
		
		return partDCount;
	}
	
	public void setPartDCount(String partDCount) {
		this.partDCount = partDCount;
	}
	
	//mac
	public String getMac() {
		
		return mac;
	}
	
	public void setMac(String mac) {
		this.mac = mac;
	}
	
	//riskScoreModDt
	public String getRiskScoreModDt() {
		
		return riskScoreModDt;
	}
	
	public void setRiskScoreModDt(String riskScoreModDt) {
		this.riskScoreModDt = riskScoreModDt;
	}
	
	//ptans
	public List<Ptans> getPtans() {
		
		return ptans;
	}
	
	public void setPtans(List<Ptans> ptans) {
		this.ptans = ptans;
	}
	
	//riskScoreDelta
	public String getRiskScoreDelta() {
		
		return riskScoreDelta;
	}
	
	public void setRiskScoreDelta(String riskScoreDelta) {
		this.riskScoreDelta = riskScoreDelta;
	}
	
	//riskScore90
	public String getRiskScore90() {
		
		return riskScore90;
	}
	
	public void setRiskScore90(String riskScore90) {
		this.riskScore90 = riskScore90;
	}
	
	//riskScore180
	public String getRiskScore180() {
		
		return riskScore180;
	}
	
	public void setRiskScore180(String riskScore180) {
		this.riskScore180 = riskScore180;
	}
	
	//riskScore365
	public String getRiskScore365() {
		
		return riskScore365;
	}
	
	public void setRiskScore365(String riskScore365) {
		this.riskScore365 = riskScore365;
	}
	
	//riskScoreTrend
	public String getRiskScoreTrend() {
		
		return riskScoreTrend;
	}
	
	public void setRiskScoreTrend(String riskScoreTrend) {
		this.riskScoreTrend = riskScoreTrend;
	}
	
	//priorityScore
	public String getPriorityScore() {
		
		return priorityScore;
	}
	
	public void setPriorityScore(String priorityScore) {
		this.priorityScore = priorityScore;
	}
	
	//recentAlerts
	public List<CurrentAlerts> getRecentAlerts() {
		
		return recentAlerts;
	}
	
	public void setRecentAlerts(List<CurrentAlerts> recentAlerts) {
		this.recentAlerts = recentAlerts;
	}
	
	//priorityAlerts
	public List<CurrentAlerts> getPriorityAlerts() {
		
		return priorityAlerts;
	}
	
	public void setPriorityAlerts(List<CurrentAlerts> priorityAlerts) {
		this.priorityAlerts = priorityAlerts;
	}
	
	//priorityScoreModDt
	public String getPriorityScoreModDt() {
		
		return priorityScoreModDt;
	}
	
	public void setPriorityScoreModDt(String priorityScoreModDt) {
		this.priorityScoreModDt = priorityScoreModDt;
	}
	
	//priorityScoreDelta
	public String getPriorityScoreDelta() {
		
		return priorityScoreDelta;
	}
	
	public void setPriorityScoreDelta(String priorityScoreDelta) {
		this.priorityScoreDelta = priorityScoreDelta;
	}
	
	//priorityCriteria
	public List<PriorityCriteria> getPriorityCriteria() {
		
		return priorityCriteria;
	}
	
	public void setPriorityCriteria(List<PriorityCriteria> priorityCriteria) {
		this.priorityCriteria = priorityCriteria;
	}
	
	//prevPriorityScore
	public String getPrevPriorityScore() {
		
		return prevPriorityScore;
	}
	
	public void setPrevPriorityScore(String prevPriorityScore) {
		this.prevPriorityScore = prevPriorityScore;
	}
	
	//zrType
	public String getZrType() {
		
		return zrType;
	}
	
	public void setZrType(String zrType) {
		this.zrType = zrType;
	}
	
	//drugClasses
	public List<DrugClasses> getDrugClasses() {
		return drugClasses;
	}
	
	public void setDrugClasses(List<DrugClasses> drugClasses) {
		this.drugClasses = drugClasses;
	}
	//cityStates
	public List<CityStates> getCityStates() {
		return cityStates;
	}
	
	public void setCityStates(List<CityStates> cityStates) {
		this.cityStates = cityStates;
	}
	
	//cityStateCnt
	public String getCityStateCnt() {		
		return cityStateCnt;	
	}
	
	public void setCityStateCnt(String cityStateCnt) {
		this.cityStateCnt = cityStateCnt;
	}
	
	//drugClassCnt 
	public String getDrugClassCnt() {		
		return drugClassCnt;	}
	
	public void setDrugClassCnt(String drugClassCnt) {
		this.drugClassCnt = drugClassCnt;
	}
	
	//revocation
	public String getRevocation() {
		return revocation;
	}
	
	public void setRevocation(String revocation) {
		this.revocation = revocation;
	}
	
	//medicaid
	public String getMedicaid() {
		return medicaid;
	}
	
	public void setMedicaid(String medicaid) {
		this.medicaid = medicaid;
	}
	
	//ucmAsrId
	public String getUcmAsrId() {
		return ucmAsrId;
	}
	
	public void setUcmAsrId(String ucmAsrId) {
		this.ucmAsrId = ucmAsrId;
	}
	
	//medicaidInfo
	public MedicaidInfo getMedicaidInfo() {
		return medicaidInfo;
	}
	
	public void setMedicaidInfo(MedicaidInfo medicaidInfo) {
		this.medicaidInfo = medicaidInfo;
	}
	
	//relLastAlertDt
	public String getRelLastAlertDt() {
		return relLastAlertDt;
	}
	
	public void setRelLastAlertDt(String relLastAlertDt) {
		this.relLastAlertDt = relLastAlertDt;
	}
	
	//lastAlertDt
	public String getLastAlertDt() {
		return lastAlertDt;
	}
	
	public void setLastAlertDt(String lastAlertDt) {
		this.lastAlertDt = lastAlertDt;
	}
	
	//revocationDate
	public String getRevocationDate() {
		return revocationDate;
	}
	
	public void setRevocationDate(String revocationDate) {
		this.revocationDate = revocationDate;
	}
	
	//revocationDesc
	public String getRevocationDesc() {
		return revocationDesc;
	}
	
	public void setRevocationDesc(String revocationDesc) {
		this.revocationDesc = revocationDesc;
	}
	
	//enrollmentIds
	public List<EnrollmentId> getEnrollmentIds() {
		return enrollmentIds;
	}
	
	public void setEnrollmentIds(List<EnrollmentId> enrollmentIds) {
		this.enrollmentIds = enrollmentIds;
	}
	
	//enrollmentId
	public String getEnrollmentId() {
		return enrollmentId;
	}
	
	public void setEnrollmentId(String enrollmentId) {
		this.enrollmentId = enrollmentId;
	}
	
	//leadInvActions
	public List<LeadInvActions> getLeadInvActions() {
		return leadInvActions;
	}
	
	public void setLeadInvActions(List<LeadInvActions> leadInvActions) {
		this.leadInvActions = leadInvActions;
	}
	
	//leadInvActivities
	public List<LeadInvActivities> getLeadInvActivities() {
		return leadInvActivities;
	}
	
	public void setLeadInvActivities(List<LeadInvActivities> leadInvActivities) {
		this.leadInvActivities = leadInvActivities;
	}
	
	//leadInvRatings
	public List<LeadInvRatings> getLeadInvRatings() {
		return leadInvRatings;
	}
	
	public void setLeadInvRatings(List<LeadInvRatings> leadInvRatings) {
		this.leadInvRatings = leadInvRatings;
	}
	
	//actionability
	public String getActionability() {
		return actionability;
	}
	
	public void setActionability(String actionability) {
		this.actionability = actionability;
	}
	
	//timeliness
	public String getTimeliness() {
		return timeliness;
	}
	
	public void setTimeliness(String timeliness) {
		this.timeliness = timeliness;
	}
	
	//aps
	public String getAps() {
		return aps;
	}
	
	public void setAps(String aps) {
		this.aps = aps;
	}
	
	//showMacEduReport
	public String getShowMacEduReport() {
		return showMacEduReport;
	}
	
	public void setShowMacEduReport(String showMacEduReport) {
		this.showMacEduReport = showMacEduReport;
	}
	
	//showUpicEduReport
	public String getShowUpicEduReport() {
		return showUpicEduReport;
	}
	
	public void setShowUpicEduReport(String showUpicEduReport) {
		this.showUpicEduReport = showUpicEduReport;
	}
	
	//showChowReport
	public String getShowChowReport() {
		return showChowReport;
	}
	
	public void setShowChowReport(String showChowReport) {
		this.showChowReport = showChowReport;
	}
	
	//hasPartD
	public String getHasPartD() {
		return hasPartD;
	}
	
	public void setHasPartD(String hasPartD) {
		this.hasPartD = hasPartD;
	}
	
	// clmTypeTxt
	public String getClmTypeTxt() {
		return clmTypeTxt;
	}
	
	public void setClmTypeTxt(String clmTypeTxt) {
		this.clmTypeTxt = clmTypeTxt;
	}
	
	// agedAlerts
	public String getAgedAlerts() {
		return agedAlerts;
	}
	
	public void setAgedAlerts(String agedAlerts) {
		this.agedAlerts = agedAlerts;
	}
	
	// submitAmt
	public String getSubmitAmt() {
		return submitAmt;
	}
	
	public void setSubmitAmt(String submitAmt) {
		this.submitAmt = submitAmt;
	}
	
	// totalPayment
	public String getTotalPayment() {
		return totalPayment;
	}
	
	public void setTotalPayment(String totalPayment) {
		this.totalPayment = totalPayment;
	}
	
	// earliestClmDt
	public String getEarliestClmDt() {
		return earliestClmDt;
	}
	
	public void setEarliestClmDt(String earliestClmDt) {
		this.earliestClmDt = earliestClmDt;
	}
	
	// lastClmDt
	public String getLastClmDt() {
		return lastClmDt;
	}
	
	public void setLastClmDt(String lastClmDt) {
		this.lastClmDt = lastClmDt;
	}
	
	// prvdrState
	public String getPrvdrState() {
		return prvdrState;
	}
	
	public void setPrvdrState(String prvdrState) {
		this.prvdrState = prvdrState;
	}
	
	// enrollmentStus
	public String getEnrollmentStus() {
		return enrollmentStus;
	}
	
	public void setEnrollmentStus(String enrollmentStus) {
		this.enrollmentStus = enrollmentStus;
	}
	
	// enrollmentStusRsn
	public String getEnrollmentStusRsn() {
		return enrollmentStusRsn;
	}
	
	public void setEnrollmentStusRsn(String enrollmentStusRsn) {
		this.enrollmentStusRsn = enrollmentStusRsn;
	}
	
	// enrollmentStusRsnDesc
	public String getEnrollmentStusRsnDesc() {
		return enrollmentStusRsnDesc;
	}
	
	public void setEnrollmentStusRsnDesc(String enrollmentStusRsnDesc) {
		this.enrollmentStusRsnDesc = enrollmentStusRsnDesc;
	}
	
	// prvdrPlaceNm
	public String getPrvdrPlaceNm() {
		return prvdrPlaceNm;
	}
	
	public void setPrvdrPlaceNm(String prvdrPlaceNm) {
		this.prvdrPlaceNm = prvdrPlaceNm;
	}
	
	// exclusion
	public String getExclusion() {
		return exclusion;
	}
	
	public void setExclusion(String exclusion) {
		this.exclusion = exclusion;
	}
	
	// mostRecentUcmClsdDt
	public String getMostRecentUcmClsdDt() {
		return mostRecentUcmClsdDt;
	}
	
	public void setMostRecentUcmClsdDt(String mostRecentUcmClsdDt) {
		this.mostRecentUcmClsdDt = mostRecentUcmClsdDt;
	}
	
	// biuCategory
	public String getBiuCategory() {
		return biuCategory;
	}
	
	public void setBiuCategory(String biuCategory) {
		this.biuCategory = biuCategory;
	}
	
	// zrCaseIds
	public String getZrCaseIds() {
		return zrCaseIds;
	}
	
	public void setZrCaseIds(String zrCaseIds) {
		this.zrCaseIds = zrCaseIds;
	}
	
	// biuComplaintsCnt
	public String getBiuComplaintsCnt() {
		return biuComplaintsCnt;
	}
	
	public void setBiuComplaintsCnt(String biuComplaintsCnt) {
		this.biuComplaintsCnt = biuComplaintsCnt;
	}
	
	// prioritizedOtherZone
	public String getPrioritizedOtherZone() {
		return prioritizedOtherZone;
	}
	
	public void setPrioritizedOtherZone(String prioritizedOtherZone) {
		this.prioritizedOtherZone = prioritizedOtherZone;
	}
	
	// ucmCaseIds
	public String getUcmCaseIds() {
		return ucmCaseIds;
	}
	
	public void setUcmCaseIds(String ucmCaseIds) {
		this.ucmCaseIds = ucmCaseIds;
	}
	
	// biuComplaints90Cnt
	public String getBiuComplaints90Cnt() {
		return biuComplaints90Cnt;
	}
	
	public void setBiuComplaints90Cnt(String biuComplaints90Cnt) {
		this.biuComplaints90Cnt = biuComplaints90Cnt;
	}
	
	// ucmSummary
	public String getUcmSummary() {
		return ucmSummary;
	}
	
	public void setUcmSummary(String ucmSummary) {
		this.ucmSummary = ucmSummary;
	}
	
	// lastEduDt 
	public String getLastEduDt() {
		return lastEduDt;
	}
	
	public void setLastEduDt(String lastEduDt) {
		this.lastEduDt = lastEduDt;
	}
	
	// newAlerts
	public String getNewAlerts() {
		return newAlerts;
	}
	
	public void setNewAlerts(String newAlerts) {
		this.newAlerts = newAlerts;
	}
	
	// prioritizedMyZone
	public String getPrioritizedMyZone() {
		return prioritizedMyZone;
	}
	
	public void setPrioritizedMyZone(String prioritizedMyZone) {
		this.prioritizedMyZone = prioritizedMyZone;
	}
	
	// partDInd
	public String getPartDInd() {
		return partDInd;
	}
	
	public void setPartDInd(String partDInd) {
		this.partDInd = partDInd;
	}
	
	// extractDt
	public String getExtractDt() {
		return extractDt;
	}
	
	public void setExtractDt(String extractDt) {
		this.extractDt = extractDt;
	}
	
	// asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	// prvdrNpiNum
	public String getPrvdrNpiNum() {
		return prvdrNpiNum;
	}
	
	public void setPrvdrNpiNum(String prvdrNpiNum) {
		this.prvdrNpiNum = prvdrNpiNum;
	}
	
	// partAInd
	public String getPartAInd() {
		return partAInd;
	}
	
	public void setPartAInd(String partAInd) {
		this.partAInd = partAInd;
	}
	
	// partBInd
	public String getPartBInd() {
		return partBInd;
	}
	
	public void setPartBInd(String partBInd) {
		this.partBInd = partBInd;
	}
	
	// claimLinesDCnt
	public String getClaimLinesDCnt() {
		return claimLinesDCnt;
	}
	
	public void setClaimLinesDCnt(String claimLinesDCnt) {
		this.claimLinesDCnt = claimLinesDCnt;
	}
	
	// beneDCnt
	public String getBeneDCnt() {
		return beneDCnt;
	}
	
	public void setBeneDCnt(String beneDCnt) {
		this.beneDCnt = beneDCnt;
	}
	
	// macCntrctrNum
	public String getMacCntrctrNum() {
		return macCntrctrNum;
	}
	
	public void setMacCntrctrNum(String macCntrctrNum) {
		this.macCntrctrNum = macCntrctrNum;
	}
	
	// lastAlertClmDt
	public String getLastAlertClmDt() {
		return lastAlertClmDt;
	}
	
	public void setLastAlertClmDt(String lastAlertClmDt) {
		this.lastAlertClmDt = lastAlertClmDt;
	}
	
	// listItemId
	public String getListItemId() {
		return listItemId;
	}
	
	public void setListItemId(String listItemId) {
		this.listItemId = listItemId;
	}
	
	// enrollmentStusDesc
	public String getEnrollmentStusDesc() {
		return enrollmentStusDesc;
	}
	
	public void setEnrollmentStusDesc(String enrollmentStusDesc) {
		this.enrollmentStusDesc = enrollmentStusDesc;
	}
	
	// ucmCaseStus
	public String getUcmCaseStus() {
		return ucmCaseStus;
	}
	
	public void setUcmCaseStus(String ucmCaseStus) {
		this.ucmCaseStus = ucmCaseStus;
	}
	
	// specialtyTxt
	public String getSpecialtyTxt() {
		return specialtyTxt;
	}
	
	public void setSpecialtyTxt(String specialtyTxt) {
		this.specialtyTxt = specialtyTxt;
	}
	
	// submitDAmt
	public String getSubmitDAmt() {
		return submitDAmt;
	}
	
	public void setSubmitDAmt(String submitDAmt) {
		this.submitDAmt = submitDAmt;
	}
	
	// prvdrEduProvBy
	public String getPrvdrEduProvBy() {
		return prvdrEduProvBy;
	}
	
	public void setPrvdrEduProvBy(String prvdrEduProvBy) {
		this.prvdrEduProvBy = prvdrEduProvBy;
	}
	
	// topCityStateTxt
	public String getTopCityStateTxt() {
		return topCityStateTxt;
	}
	
	public void setTopCityStateTxt(String topCityStateTxt) {
		this.topCityStateTxt = topCityStateTxt;
	}
	
	// totalPaymentD
	public String getTotalPaymentD() {
		return totalPaymentD;
	}
	
	public void setTotalPaymentD(String totalPaymentD) {
		this.totalPaymentD = totalPaymentD;
	}
	
	// billAfterEduInd
	public String getBillAfterEduInd() {
		return billAfterEduInd;
	}
	
	public void setBillAfterEduInd(String billAfterEduInd) {
		this.billAfterEduInd = billAfterEduInd;
	}
	
	// clmCntrctrNum
	public String getClmCntrctrNum() {
		return clmCntrctrNum;
	}
	
	public void setClmCntrctrNum(String clmCntrctrNum) {
		this.clmCntrctrNum = clmCntrctrNum;
	}
	
	// fraudTypeDesc
	public String getFraudTypeDesc() {
		return fraudTypeDesc;
	}
	
	public void setFraudTypeDesc(String fraudTypeDesc) {
		this.fraudTypeDesc = fraudTypeDesc;
	}
	
	// leadInd
	public String getLeadInd() {
		return leadInd;
	}
	
	public void setLeadInd(String leadInd) {
		this.leadInd = leadInd;
	}
	
	// cncStus
	public String getCncStus() {
		return cncStus;
	}
	
	public void setCncStus(String cncStus) {
		this.cncStus = cncStus;
	}
	
	// prvdrNm
	public String getPrvdrNm() {
		return prvdrNm;
	}
	
	public void setPrvdrNm(String prvdrNm) {
		this.prvdrNm = prvdrNm;
	}
	
	// revokedInd
	public String getRevokedInd() {
		return revokedInd;
	}
	
	public void setRevokedInd(String revokedInd) {
		this.revokedInd = revokedInd;
	}
	
	// postEdInd
	public String getPostEdInd() {
		return postEdInd;
	}
	
	public void setPostEdInd(String postEdInd) {
		this.postEdInd = postEdInd;
	}
	
	// lastDateOfTpeEducation
	public String getLastDateOfTpeEducation() {
		return lastDateOfTpeEducation;
	}
	
	public void setLastDateOfTpeEducation(String lastDateOfTpeEducation) {
		this.lastDateOfTpeEducation = lastDateOfTpeEducation;
	}
	
	// tpeReviewRnd
	public String getTpeReviewRnd() {
		return tpeReviewRnd;
	}
	
	public void setTpeReviewRnd(String tpeReviewRnd) {
		this.tpeReviewRnd = tpeReviewRnd;
	}
	
	// tpeEduOffered
	public String getTpeEduOffered() {
		return tpeEduOffered;
	}
	
	public void setTpeEduOffered(String tpeEduOffered) {
		this.tpeEduOffered = tpeEduOffered;
	}
	
	// tpeReviewTopic
	public String getTpeReviewTopic() {
		return tpeReviewTopic;
	}
	
	public void setTpeReviewTopic(String tpeReviewTopic) {
		this.tpeReviewTopic = tpeReviewTopic;
	}
	
	// tpeRefRsn
	public String getTpeRefRsn() {
		return tpeRefRsn;
	}
	
	public void setTpeRefRsn(String tpeRefRsn) {
		this.tpeRefRsn = tpeRefRsn;
	}
	
	// wsLabel
	public String getWsLabel() {
		return wsLabel;
	}
	
	public void setWsLabel(String wsLabel) {
		this.wsLabel = wsLabel;
	}
	
	// exLabel
	public String getExLabel() {
		return exLabel;
	}
	
	public void setExLabel(String exLabel) {
		this.exLabel = exLabel;
	}
	
	// hasExclusionHistory
	public String getHasExclusionHistory() {
		return hasExclusionHistory;
	}
	
	public void setHasExclusionHistory(String hasExclusionHistory) {
		this.hasExclusionHistory = hasExclusionHistory;
	}
	
	// relatedAsrCnt
	public String getRelatedAsrCnt() {
		return relatedAsrCnt;
	}
	
	public void setRelatedAsrCnt(String relatedAsrCnt) {
		this.relatedAsrCnt = relatedAsrCnt;
	}
	
	// nonAlertedPrvdrInd
	public String getNonAlertedPrvdrInd() {
		return nonAlertedPrvdrInd;
	}
	
	public void setNonAlertedPrvdrInd(String nonAlertedPrvdrInd) {
		this.nonAlertedPrvdrInd = nonAlertedPrvdrInd;
	}
	
	// dualBeneCntInd
	public String getDualBeneCntInd() {
		return dualBeneCntInd;
	}
	
	public void setDualBeneCntInd(String dualBeneCntInd) {
		this.dualBeneCntInd = dualBeneCntInd;
	}

	/**
	 * @return the riskScoreMethod
	 */
	public String getRiskScoreMethod() {
		return riskScoreMethod;
	}

	/**
	 * @param riskScoreMethod the riskScoreMethod to set
	 */
	public void setRiskScoreMethod(String riskScoreMethod) {
		this.riskScoreMethod = riskScoreMethod;
	}

	// mdcdSpecialty
	
	public String getMdcdSpecialty() {
		return mdcdSpecialty;
	}

	// mdcdSvcType
	
	public String getMdcdSvcType() {
		return mdcdSvcType;
	}

	// mdcdSvcSubCat
	
	public String getMdcdSvcSubCat() {
		return mdcdSvcSubCat;
	}

	// mdcdEnrollmentStatus
	
	public String getMdcdEnrollmentStatus() {
		return mdcdEnrollmentStatus;
	}

	// mdcdSubmitAmt
	
	public String getMdcdSubmitAmt() {
		return mdcdSubmitAmt;
	}

	// mdcdTotalPmt
	
	public String getMdcdTotalPmt() {
		return mdcdTotalPmt;
	}

	// mdcdRecipientCnt
	
	public String getMdcdRecipientCnt() {
		return mdcdRecipientCnt;
	}

	// mdcdClmCnt
	
	public String getMdcdClmCnt() {
		return mdcdClmCnt;
	}

	// mdcdBillingNpi
	
	public String getMdcdBillingNpi() {
		return mdcdBillingNpi;
	}

	// mdcdRiskScore
	
	public String getMdcdRiskScore() {
		return mdcdRiskScore;
	}

	// mdcdNewAlerts
	
	public String getMdcdNewAlerts() {
		return mdcdNewAlerts;
	}

	// mdcdAgedAlerts
	
	public String getMdcdAgedAlerts() {
		return mdcdAgedAlerts;
	}

	// mdcdStates
	
	public String getMdcdStates() {
		return mdcdStates;
	}

	// mdcdSpecialty
	
	public void setMdcdSpecialty(String mdcdSpecialty) {
		this.mdcdSpecialty = mdcdSpecialty;
	}

	// mdcdSvcType
	
	public void setMdcdSvcType(String mdcdSvcType) {
		this.mdcdSvcType = mdcdSvcType;
	}

	// mdcdSvcSubCat
	
	public void setMdcdSvcSubCat(String mdcdSvcSubCat) {
		this.mdcdSvcSubCat = mdcdSvcSubCat;
	}

	// mdcdEnrollmentStatus
	
	public void setMdcdEnrollmentStatus(String mdcdEnrollmentStatus) {
		this.mdcdEnrollmentStatus = mdcdEnrollmentStatus;
	}

	// mdcdSubmitAmt
	
	public void setMdcdSubmitAmt(String mdcdSubmitAmt) {
		this.mdcdSubmitAmt = mdcdSubmitAmt;
	}

	// mdcdTotalPmt
	
	public void setMdcdTotalPmt(String mdcdTotalPmt) {
		this.mdcdTotalPmt = mdcdTotalPmt;
	}

	// mdcdRecipientCnt
	
	public void setMdcdRecipientCnt(String mdcdRecipientCnt) {
		this.mdcdRecipientCnt = mdcdRecipientCnt;
	}

	// mdcdClmCnt
	
	public void setMdcdClmCnt(String mdcdClmCnt) {
		this.mdcdClmCnt = mdcdClmCnt;
	}

	// mdcdBillingNpi
	
	public void setMdcdBillingNpi(String mdcdBillingNpi) {
		this.mdcdBillingNpi = mdcdBillingNpi;
	}

	// mdcdRiskScore
	
	public void setMdcdRiskScore(String mdcdRiskScore) {
		this.mdcdRiskScore = mdcdRiskScore;
	}

	// mdcdNewAlerts
	
	public void setMdcdNewAlerts(String mdcdNewAlerts) {
		this.mdcdNewAlerts = mdcdNewAlerts;
	}

	// mdcdAgedAlerts
	
	public void setMdcdAgedAlerts(String mdcdAgedAlerts) {
		this.mdcdAgedAlerts = mdcdAgedAlerts;
	}

	// mdcdStates
	
	public void setMdcdStates(String mdcdStates) {
		this.mdcdStates = mdcdStates;
	}

	//pathToEduInd
	
	public String getPathToEduInd() {
		return pathToEduInd;
	}

	public void setPathToEduInd(String pathToEduInd) {
		this.pathToEduInd = pathToEduInd;
	}

	// acoInd
	public String getAcoInd() {
		return acoInd;
	}

	public void setAcoInd(String acoInd) {
		this.acoInd = acoInd;
	}

	
	//p1EnableInd
	public String getp1EnableInd() {
		return p1EnableInd;
	}
	
	public void setp1EnableInd(String p1EnableInd) {
		this.p1EnableInd = p1EnableInd;
	}

	//p1NewAlerts
	public String getp1NewAlerts() {
		return p1NewAlerts;
	}
	
	public void setp1NewAlerts(String p1NewAlerts) {
		this.p1NewAlerts = p1NewAlerts;
	}

//p1Cost
	public String getp1Cost() {
		return p1Cost;
	}
	
	public void setp1Cost(String p1Cost) {
		this.p1Cost = p1Cost;
	}

//p1SubjZoneCd
	public String getp1SubjZoneCd() {
		return p1SubjZoneCd;
	}
	
	public void setp1SubjZoneCd(String p1SubjZoneCd) {
		this.p1SubjZoneCd = p1SubjZoneCd;
	}


	
}
