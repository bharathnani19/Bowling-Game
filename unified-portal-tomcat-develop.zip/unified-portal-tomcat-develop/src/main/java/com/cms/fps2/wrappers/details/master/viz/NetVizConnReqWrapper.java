package com.cms.fps2.wrappers.details.master.viz;

public class NetVizConnReqWrapper {
	
	private String modelName;
	private String npi;
	private String userId;
	private String connectIndex;
	
	// constructor
	public NetVizConnReqWrapper() {}
	
	//modelName
	public String getModelName() {
		return modelName;
	}
	
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	
	//npi
	public String getNpi() {
		return npi;
	}
	
	public void setNpi(String npi) {
		this.npi = npi;
	}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//connectIndex
	public String getConnectIndex() {
		return connectIndex;
	}
	
	public void setConnectIndex(String connectIndex) {
		this.connectIndex = connectIndex;
	}
}
