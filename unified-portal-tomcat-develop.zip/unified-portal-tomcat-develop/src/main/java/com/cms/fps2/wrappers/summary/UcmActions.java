package com.cms.fps2.wrappers.summary;

public class UcmActions {
	
	private String userId;
	private String eventDt;
	private String desc;
	private String source;
	private String ucmId;
	
	// constructor
	public UcmActions() {}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//eventDt
	public String getEventDt() {
		return eventDt;
	}
	
	public void setEventDt(String eventDt) {
		this.eventDt = eventDt;
	}
	
	//desc
	public String getDesc() {
		return desc;
	}
	
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	//source
	public String getSource() {
		return source;
	}
	
	public void setSource(String source) {
		this.source = source;
	}
	
	//ucmId
	public String getUcmId() {
		return ucmId;
	}
	
	public void setUcmId(String ucmId) {
		this.ucmId = ucmId;
	}
}
