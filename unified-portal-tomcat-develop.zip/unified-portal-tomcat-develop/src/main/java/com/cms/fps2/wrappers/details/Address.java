package com.cms.fps2.wrappers.details;

public class Address {
	
	private String npi;
	private String id;
	private String lastName;	
	private String firstName;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String zip;
	private String age;
	private String phone;
	private String latitiude;
	private String longitude;
	private String beneSk;
	private String hicn;
	private String mbi;
	private String birthDt;
	private String deathDt;
	private String gender;
	private String prvdrNm;
	
	//constructor
	public Address(){}
	
	//npi 	
	public String getNpi() {
		return npi;
	}
	
	public void setNpi(String npi) {
		this.npi = npi;
	}
	
	//id 	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	//lastName 	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	//firstName 	
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	//address1 	
	public String getAddress1() {
		return address1;
	}
	
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	
	//address2 	
	public String getAddress2() {
		return address2;
	}
	
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	
	//city 	
	public String getCity() {
		return city;
	}
	
	public void setCity(String city) {
		this.city = city;
	}
	
	//state 	
	public String getState() {
		return state;
	}
	
	public void setState(String state) {
		this.state = state;
	}
	
	//zip 	
	public String getZip() {
		return zip;
	}
	
	public void setZip(String zip) {
		this.zip = zip;
	}
	
	//age 	
	public String getAge() {
		return age;
	}
	
	public void setAge(String age) {
		this.age = age;
	}
	
	//phone
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	//latitiude
	public String getLatitiude() {
		return latitiude;
	}
	
	public void setLatitiude(String latitiude) {
		this.latitiude = latitiude;
	}
	
	//longitude
	public String getLongitude() {
		return longitude;
	}
	
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	
	//beneSk
	public String getBeneSk() {
		return beneSk;
	}
	
	public void setBeneSk(String beneSk) {
		this.beneSk = beneSk;
	}
	
	//hicn
	public String getHicn() {
		return hicn;
	}
	
	public void setHicn(String hicn) {
		this.hicn = hicn;
	}
	
	//mbi
	public String getMbi() {
		return mbi;
	}
	
	public void setMbi(String mbi) {
		this.mbi = mbi;
	}
	
	//birthDt
	public String getBirthDt() {
		return birthDt;
	}
	
	public void setBirthDt(String birthDt) {
		this.birthDt = birthDt;
	}
	
	//deathDt
	public String getDeathDt() {
		return deathDt;
	}
	
	public void setDeathDt(String deathDt) {
		this.deathDt = deathDt;
	}
	
	//gender
	public String getGender() {
		return gender;
	}
	
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	// prvdrNm
	public String getPrvdrNm() {
		return prvdrNm;
	}
	
	public void setPrvdrNm(String prvdrNm) {
		this.prvdrNm = prvdrNm;
	}
}
