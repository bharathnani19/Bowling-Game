package com.cms.fps2.wrappers.details;

public class Fids {
	private String fidNumber;
	
	//constructor
	public Fids(){}
	
	//currentInd
	public String getFidNumber() {
		return fidNumber;
	}
	
	public void setFidNumber(String fidNumber) {
		this.fidNumber = fidNumber;
	}
}
