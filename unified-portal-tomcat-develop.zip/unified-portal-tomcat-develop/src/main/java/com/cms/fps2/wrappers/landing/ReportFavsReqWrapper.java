package com.cms.fps2.wrappers.landing;

public class ReportFavsReqWrapper {
	
	private String userId;
	private String userZone;
	
	//constructor
	public ReportFavsReqWrapper() {}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//userZone
	public String getUserZone() {
		return userZone;
	}
	
	public void setUserZone(String userZone) {
		this.userZone = userZone;
	}
}
