package com.cms.fps2.wrappers.ucm;

import java.util.ArrayList;
import java.util.List;

public class PrioritizeASRReqWrapper {
	
	private List<Priorities> priorities = new ArrayList<Priorities>();
	
	//empty constructor
	public PrioritizeASRReqWrapper(){}
	
	//priorities
	public List<Priorities> getPriorities() {
		return priorities;
	}
	
	public void setPriorities(List<Priorities> priorities) {
		this.priorities = priorities;
	}
}
