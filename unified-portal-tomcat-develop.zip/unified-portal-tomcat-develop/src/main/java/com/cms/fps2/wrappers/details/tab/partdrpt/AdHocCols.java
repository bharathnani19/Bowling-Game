package com.cms.fps2.wrappers.details.tab.partdrpt;

public class AdHocCols {
	private String name;
	private String value;
	
	//constructor
	public AdHocCols(){}
	
	//name
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	//value
	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}
}
