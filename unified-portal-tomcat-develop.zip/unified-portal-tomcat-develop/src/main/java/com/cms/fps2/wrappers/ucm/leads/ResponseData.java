package com.cms.fps2.wrappers.ucm.leads;

import java.util.ArrayList;
import java.util.List;

public class ResponseData {
	private List<Leads> leads = new ArrayList<Leads>(); 
	private String prioritized;
	
	//empty constructor
	public ResponseData(){}
	
	//leads
	public List<Leads> getLeads() {
		return leads;
	}
	
	public void setLeads(List<Leads> leads) {
		this.leads = leads;
	}
	
	//prioritized
	public String getPrioritized() {
		return prioritized;
	}
	
	public void setPrioritized(String prioritized) {
		this.prioritized = prioritized;
	}
	
}
