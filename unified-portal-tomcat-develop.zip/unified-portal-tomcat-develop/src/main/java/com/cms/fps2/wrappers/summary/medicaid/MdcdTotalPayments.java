package com.cms.fps2.wrappers.summary.medicaid;

public class MdcdTotalPayments {
	private String modelNm;
	private String role;
	private String billingNpi;
	private String svcCat;
	private String states;
	private String mcoSubmitAmt;
	private String mcoTotalPmt;
	private String mcoPlan;
	private String ffsSubmitAmt;
	private String ffsTotalPmt;
	private String mcoRecipCnt;
	private String ffsRecipCnt;
	// modelNm
	
	public String getModelNm() {
		return modelNm;
	}
	// role
	
	public String getRole() {
		return role;
	}
	// billingNpi
	
	public String getBillingNpi() {
		return billingNpi;
	}
	// svcCat
	
	public String getSvcCat() {
		return svcCat;
	}
	// states
	
	public String getStates() {
		return states;
	}
	// mcoSubmitAmt
	
	public String getMcoSubmitAmt() {
		return mcoSubmitAmt;
	}
	// mcoTotalPmt
	
	public String getMcoTotalPmt() {
		return mcoTotalPmt;
	}
	// mcoPlan
	
	public String getMcoPlan() {
		return mcoPlan;
	}
	// ffsSubmitAmt
	
	public String getFfsSubmitAmt() {
		return ffsSubmitAmt;
	}
	// ffsTotalPmt
	
	public String getFfsTotalPmt() {
		return ffsTotalPmt;
	}
	// mcoRecipCnt
	
	public String getMcoRecipCnt() {
		return mcoRecipCnt;
	}
	// ffsRecipCnt
	
	public String getFfsRecipCnt() {
		return ffsRecipCnt;
	}
	// modelNm
	
	public void setModelNm(String modelNm) {
		this.modelNm = modelNm;
	}
	// role
	
	public void setRole(String role) {
		this.role = role;
	}
	// billingNpi
	
	public void setBillingNpi(String billingNpi) {
		this.billingNpi = billingNpi;
	}
	// svcCat
	
	public void setSvcCat(String svcCat) {
		this.svcCat = svcCat;
	}
	// states
	
	public void setStates(String states) {
		this.states = states;
	}
	// mcoSubmitAmt
	
	public void setMcoSubmitAmt(String mcoSubmitAmt) {
		this.mcoSubmitAmt = mcoSubmitAmt;
	}
	// mcoTotalPmt
	
	public void setMcoTotalPmt(String mcoTotalPmt) {
		this.mcoTotalPmt = mcoTotalPmt;
	}
	// mcoPlan
	
	public void setMcoPlan(String mcoPlan) {
		this.mcoPlan = mcoPlan;
	}
	// ffsSubmitAmt
	
	public void setFfsSubmitAmt(String ffsSubmitAmt) {
		this.ffsSubmitAmt = ffsSubmitAmt;
	}
	// ffsTotalPmt
	
	public void setFfsTotalPmt(String ffsTotalPmt) {
		this.ffsTotalPmt = ffsTotalPmt;
	}
	// mcoRecipCnt
	
	public void setMcoRecipCnt(String mcoRecipCnt) {
		this.mcoRecipCnt = mcoRecipCnt;
	}
	// ffsRecipCnt
	
	public void setFfsRecipCnt(String ffsRecipCnt) {
		this.ffsRecipCnt = ffsRecipCnt;
	}
	
	
	

}
