package com.cms.fps2.wrappers.summary.workitems;

public class AddToExistInputValReqWrapper {
	private String userId;
	
	// constructor
	public AddToExistInputValReqWrapper() {}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
