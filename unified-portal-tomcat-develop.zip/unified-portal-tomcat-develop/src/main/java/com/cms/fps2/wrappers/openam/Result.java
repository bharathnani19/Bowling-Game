package com.cms.fps2.wrappers.openam;

import java.util.ArrayList;
import java.util.List;

public class Result {
	private String username;
	private List<String> cn = new ArrayList<String>();
	private List<String> businessCategory = new ArrayList<String>();	
	
	//constructor
	public Result(){}
	
	//username
	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	//cn
	public List<String> getCn() {
		return cn;
	}
	
	public void setCn(List<String> cn) {
		this.cn = cn;
	}
	
	//businessCategory
	public List<String> getBusinessCategory() {
		return businessCategory;
	}
	
	public void setBusinessCategory(List<String> businessCategory) {
		this.businessCategory = businessCategory;
	}
	
	
}
