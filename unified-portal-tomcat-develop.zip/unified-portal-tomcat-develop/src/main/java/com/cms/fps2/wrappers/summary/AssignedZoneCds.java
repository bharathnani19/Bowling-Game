package com.cms.fps2.wrappers.summary;

public class AssignedZoneCds {
	
	private String zoneCd;
	private String zoneDesc;
	
	//constructor
	public AssignedZoneCds(){}
	
	//zoneCd
	public String getZoneCd() {
		return zoneCd;
	}
	
	public void setZoneCd(String zoneCd) {
		this.zoneCd = zoneCd;
	}
	
	//zoneDesc
	public String getZoneDesc() {
		return zoneDesc;
	}
	
	public void setZoneDesc(String zoneDesc) {
		this.zoneDesc = zoneDesc;
	}
}
