package com.cms.fps2.wrappers.details;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.details.provider.systags.SysTags;

public class Systags {
	
	private String sysTagId;
	private String sysTagTxt;
	private List<Fids> fids = new ArrayList<Fids>();
	private List<Bius> bius = new ArrayList<Bius>();
	private List<Ucms> ucms = new ArrayList<Ucms>();
	private List<SysTags> sysTags = new ArrayList<SysTags>();
		
	//constructor
	public Systags(){}
	
	//sysTagId 	
	public String getSysTagId() {
		return sysTagId;
	}
	
	public void setSysTagId(String sysTagId) {
		this.sysTagId = sysTagId;
	}
	
	//sysTagTxt 	
	public String getSysTagTxt() {
		return sysTagTxt;
	}
	
	public void setSysTagTxt(String sysTagTxt) {
		this.sysTagTxt = sysTagTxt;
	}
	
	//fids 	
	public List<Fids> getFids() {
		return fids;
	}
	
	public void setFids(List<Fids> fids) {
		this.fids = fids;
	}
	
	//bius 	
	public List<Bius> getBius() {
		return bius;
	}
	
	public void setBius(List<Bius> bius) {
		this.bius = bius;
	}
	
	//ucms 	
	public List<Ucms> getUcms() {
		return ucms;
	}
	
	public void setUcms(List<Ucms> ucms) {
		this.ucms = ucms;
	}
	
	//sysTags 	
	public List<SysTags> getSysTags() {
		return sysTags;
	}
	
	public void setSysTags(List<SysTags> sysTags) {
		this.sysTags = sysTags;
	}
}
