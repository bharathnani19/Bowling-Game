package com.cms.fps2.wrappers.details.master;

public class Alerts {
	
	private String createDt;
	private String riskScore;
	private String cost;
	private String derivedZone;
	private String legacyScore;
	private String hasReportCard;
	private String recentInd;
	private String priorityInd;
	private String insertDt;
	private String status;
	private String currentInd;
	private String legacyInd;
	private String modelTypeCd;
	private String modDt;
	private String createDtAsDate;
	private String modelStatus;
	private String alertId;
	private String partDClaimInd;
	private String state;
	private String mdcdState;
	private String pathToEduInd;
	private String sevScore;
	private String showClaimsLinkInd;
	private String relCreatedDt;
	
	

	//constructor
	public Alerts(){}
	
	//createDt 	
	public String getCreateDt() {
		return createDt;
	}
	
	public void setCreateDt(String createDt) {
		this.createDt = createDt;
	}
	
	//riskScore 	
	public String getRiskScore() {
		return riskScore;
	}
	
	public void setRiskScore(String riskScore) {
		this.riskScore = riskScore;
	}
	
	//cost 	
	public String getCost() {
		return cost;
	}
	
	public void setCost(String cost) {
		this.cost = cost;
	}
	
	//derivedZone 	
	public String getDerivedZone() {
		return derivedZone;
	}
	
	public void setDerivedZone(String derivedZone) {
		this.derivedZone = derivedZone;
	}
	
	//legacyScore 	
	public String getLegacyScore() {
		return legacyScore;
	}
	
	public void setLegacyScore(String legacyScore) {
		this.legacyScore = legacyScore;
	}
	
	//hasReportCard
	public String getHasReportCard() {
		return hasReportCard;
	}
	
	public void setHasReportCard(String hasReportCard) {
		this.hasReportCard = hasReportCard;
	}
	
	//recentInd
	public String getRecentInd() {
		return recentInd;
	}
	
	public void setRecentInd(String recentInd) {
		this.recentInd = recentInd;
	}
	
	//priorityInd
	public String getPriorityInd() {
		return priorityInd;
	}
	
	public void setPriorityInd(String priorityInd) {
		this.priorityInd = priorityInd;
	}
	
	//insertDt
	public String getInsertDt() {
		return insertDt;
	}
	
	public void setInsertDt(String insertDt) {
		this.insertDt = insertDt;
	}
	
	//status
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	//currentInd
	public String getCurrentInd() {
		return currentInd;
	}
	
	public void setCurrentInd(String currentInd) {
		this.currentInd = currentInd;
	}
	
	//legacyInd
	public String getLegacyInd() {
		return legacyInd;
	}
	
	public void setLegacyInd(String legacyInd) {
		this.legacyInd = legacyInd;
	}
	
	//modelTypeCd
	public String getModelTypeCd() {
		return modelTypeCd;
	}
	
	public void setModelTypeCd(String modelTypeCd) {
		this.modelTypeCd = modelTypeCd;
	}
	
	//modDt
	public String getModDt() {
		return modDt;
	}
	
	public void setModDt(String modDt) {
		this.modDt = modDt;
	}
	
	//createDtAsDate
	public String getCreateDtAsDate() {
		return createDtAsDate;
	}
	
	public void setCreateDtAsDate(String createDtAsDate) {
		this.createDtAsDate = createDtAsDate;
	}
	
	//modelStatus
	public String getModelStatus() {
		return modelStatus;
	}
	
	public void setModelStatus(String modelStatus) {
		this.modelStatus = modelStatus;
	}
	
	// alertId
	public String getAlertId() {
		return alertId;
	}
	
	public void setAlertId(String alertId) {
		this.alertId = alertId;
	}
	
	// partDClaimInd
	public String getPartDClaimInd() {
		return partDClaimInd;
	}
	
	public void setPartDClaimInd(String partDClaimInd) {
		this.partDClaimInd = partDClaimInd;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getMdcdState() {
		return mdcdState;
	}

	public void setMdcdState(String mdcdState) {
		this.mdcdState = mdcdState;
	}

	public String getpathToEduInd() {
		return pathToEduInd;
	}

	public void setpathToEduInd(String pathToEduInd) {
		this.pathToEduInd = pathToEduInd;
	}

	public String getSevScore() {
		return sevScore;
	}

	public void setSevScore(String sevScore) {
		this.sevScore = sevScore;
	}

	//showClaimsLinkInd

	public String getshowClaimsLinkInd() {
		return showClaimsLinkInd;
	}

	public void setshowClaimsLinkInd(String showClaimsLinkInd) {
		this.showClaimsLinkInd = showClaimsLinkInd;
	}
	
	//relCreatedDt
	public String getRelCreatedDt() {
		return relCreatedDt;
	}
	
	public void setRelCreatedDt(String relCreatedDt) {
		this.relCreatedDt = relCreatedDt;
	}
	

}
