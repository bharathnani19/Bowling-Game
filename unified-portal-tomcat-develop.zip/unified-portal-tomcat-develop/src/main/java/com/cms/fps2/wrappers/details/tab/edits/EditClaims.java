package com.cms.fps2.wrappers.details.tab.edits;

public class EditClaims {
	
	private String fpsRcncltnClmlineId;
	private String acrtnDt;
	private String admsnDt;
	private String alowdChrgAmt;
	private String atndgNpiNum;
	private String atndgNpiPtanNum;
	private String atndgNpiPrcdrCd;
	private String atndgNpiTinNum;
	private String beneLine1Adr;
	private String beneLine2Adr;
	private String beneAgeSrvcName;
	private String beneCityName;
	private String beneBirthDt;
	private String beneDeathDt;
	private String bene1stName;
	private String beneLastName;
	private String beneHicnNum;
	private String beneLatTxt;
	private String beneLonTxt;
	private String beneReprsntedInd;
	private String beneStateCd;
	private String beneZipCd;
	private String blgNpiNum;
	private String blgNpiPtanNum;
	private String blgTypeName;
	private String clmBeneLine1Adr;
	private String clmBeneLine2Adr;
	private String clmBeneCityName;
	private String clmBeneLatTxt;
	private String clmBeneLonTxt;
	private String clmBeneStateCd;
	private String clmBeneZipCd;
	private String clmId;
	private String cllSubAmt;
	private String clmRcptDt;
	private String clmTypeCd;
	private String condCd;
	private String cntrctNum;
	private String dgns1Cd;
	private String dgns2Cd;
	private String dgns3Cd;
	private String dgns4Cd;
	private String dgns5Cd;
	private String dgns6Cd;
	private String dgns7Cd;
	private String dgns8Cd;
	private String dschrgDt;
	private String enhncmtId;
	private String enhncmtTime;
	private String filName;
	private String hippsCd;
	private String hospPrdNum;
	private String hospUsedDayNum;
	private String mdcrPymtAmt;
	private String ordrgPrvdrPecosStusTxt;
	private String ptntStusTxt;
	private String plcOdSrvcCd;
	private String posZipCd;
	private String prcdrCd;
	private String prcdr1MdfrTxt;
	private String prcdr2MdfrTxt;
	private String prcdr3MdfrTxt;
	private String prcdr4MdfrTxt;
	private String prcdr5MdfrTxt;
	private String prcdrTime;
	private String prvdrReimbrsmtAmt;
	private String prvdrSpcltyCd;
	private String prvdrCityName;
	private String prvdrLatTxt;
	private String prvdrLonTxt;
	private String prvdrName;
	private String prvdrNpiNum;
	private String prvdrPtanNum;
	private String prvdrSpclty1Cd;
	private String prvdrStateName;
	private String prvdrTxnmyName;
	private String prvdrTinNum;
	private String prvdrZipCd;
	private String prvdrRfrncZipCd;
	private String rfrgPrvdrLine1Adr;
	private String rfrgPrvdrCityName;
	private String rfrgPrvdrLatTxt;
	private String rfrgPrvdrLonTxt;
	private String rfrgPrvdrName;
	private String rfrgPrvdrNpiNum;
	private String rfrgPrvdrPtanNum;
	private String rfrgPrvdrSpcltyCd;
	private String rfrgPrvdrZipCd;
	private String reimbrsmtAmt;
	private String revCd;
	private String srvcChrgAmt;
	private String srvcFacZipCd;
	private String srvcFromDt;
	private String srvcLineNum;
	private String srvcLineQlfyrNum;
	private String srvcLineThruDt;
	private String stmtFromDt;
	private String stmtThruDt;
	private String sbmtrEntId;
	private String sbmtrId;
	private String transId;
	private String srvcTypeCd;
	private String unitName;
	private String zpicCd;
	private String modelName;
	private String prmryDgnsCd;
	private String entTypeCd;
	private String actnCd;
	private String dualStusInd;
	private String scndryPyrId;
	private String crossOvrInd;
	private String crossOvrDstntnId;
	private String crossOvrDstntnTransId;
	private String srgryCd;
	private String othrModelName;
	private String fpsVrsnInd;
	private String prvdrLine1Adr;
	private String rfrgPrvdrStateCd;
	private String rcncltnStusTxt;
	private String rcncltnDt;
	private String initlEnrlmtDt;
	
		
	// constructor
	public EditClaims() {}
	
	// fpsRcncltnClmlineId
	public String getFpsRcncltnClmlineId() {
		return fpsRcncltnClmlineId;
	}
	
	public void setFpsRcncltnClmlineId(String fpsRcncltnClmlineId) {
		this.fpsRcncltnClmlineId = fpsRcncltnClmlineId;
	}
	
	// acrtnDt
	public String getAcrtnDt() {
		return acrtnDt;
	}
	
	public void setAcrtnDt(String acrtnDt) {
		this.acrtnDt = acrtnDt;
	}
	
	//admsnDt
	public String getAdmsnDt() {
		return admsnDt;
	}
	
	public void setAdmsnDt(String admsnDt) {
		this.admsnDt = admsnDt;
	}
	
	// alowdChrgAmt
	public String getAlowdChrgAmt() {
		return alowdChrgAmt;
	}
	
	public void setAlowdChrgAmt(String alowdChrgAmt) {
		this.alowdChrgAmt = alowdChrgAmt;
	}
	
	//atndgNpiNum
	public String getAtndgNpiNum() {
		return atndgNpiNum;
	}
	
	public void setAtndgNpiNum(String atndgNpiNum) {
		this.atndgNpiNum = atndgNpiNum;
	}
	
	// atndgNpiPtanNum
	public String getAtndgNpiPtanNum() {
		return atndgNpiPtanNum;
	}
	
	public void setAtndgNpiPtanNum(String atndgNpiPtanNum) {
		this.atndgNpiPtanNum = atndgNpiPtanNum;
	}
	
	//atndgNpiPrcdrCd
	public String getAtndgNpiPrcdrCd() {
		return atndgNpiPrcdrCd;
	}
	
	public void setAtndgNpiPrcdrCd(String atndgNpiPrcdrCd) {
		this.atndgNpiPrcdrCd = atndgNpiPrcdrCd;
	}
	
	//atndgNpiTinNum
	public String getAtndgNpiTinNum() {
		return atndgNpiTinNum;
	}
	
	public void setAtndgNpiTinNum(String atndgNpiTinNum) {
		this.atndgNpiTinNum = atndgNpiTinNum;
	}
	
	//beneLine1Adr
	public String getBeneLine1Adr() {
		return beneLine1Adr;
	}
	
	public void setBeneLine1Adr(String beneLine1Adr) {
		this.beneLine1Adr = beneLine1Adr;
	}
	
	//beneLine2Adr
	public String getBeneLine2Adr() {
		return beneLine2Adr;
	}
	
	public void setBeneLine2Adr(String beneLine2Adr) {
		this.beneLine2Adr = beneLine2Adr;
	}
	
	//beneAgeSrvcName
	public String getBeneAgeSrvcName() {
		return beneAgeSrvcName;
	}
	
	public void setBeneAgeSrvcName(String beneAgeSrvcName) {
		this.beneAgeSrvcName = beneAgeSrvcName;
	}
	
	//beneCityName
	public String getBeneCityName() {
		return beneCityName;
	}
	
	public void setBeneCityName(String beneCityName) {
		this.beneCityName = beneCityName;
	}
	
	//beneBirthDt
	public String getBeneBirthDt() {
		return beneBirthDt;
	}
	
	public void setBeneBirthDt(String beneBirthDt) {
		this.beneBirthDt = beneBirthDt;
	}
	
	//beneDeathDt
	public String getBeneDeathDt() {
		return beneDeathDt;
	}
	
	public void setBeneDeathDt(String beneDeathDt) {
		this.beneDeathDt = beneDeathDt;
	}
	
	//bene1stName
	public String getBene1stName() {
		return bene1stName;
	}
	
	public void setBene1stName(String bene1stName) {
		this.bene1stName = bene1stName;
	}
	
	//beneLastName
	public String getBeneLastName() {
		return beneLastName;
	}
	
	public void setBeneLastName(String beneLastName) {
		this.beneLastName = beneLastName;
	}
	
	//beneHicnNum
	public String getBeneHicnNum() {
		return beneHicnNum;
	}
	
	public void setBeneHicnNum(String beneHicnNum) {
		this.beneHicnNum = beneHicnNum;
	}
	
	//beneLatTxt
	public String getBeneLatTxt() {
		return beneLatTxt;
	}
	
	public void setBeneLatTxt(String beneLatTxt) {
		this.beneLatTxt = beneLatTxt;
	}
	
	//beneLonTxt
	public String getBeneLonTxt() {
		return beneLonTxt;
	}
	
	public void setBeneLonTxt(String beneLonTxt) {
		this.beneLonTxt = beneLonTxt;
	}
	
	//beneReprsntedInd
	public String getBeneReprsntedInd() {
		return beneReprsntedInd;
	}
	
	public void setBeneReprsntedInd(String beneReprsntedInd) {
		this.beneReprsntedInd = beneReprsntedInd;
	}
	
	//beneStateCd
	public String getBeneStateCd() {
		return beneStateCd;
	}
	
	public void setBeneStateCd(String beneStateCd) {
		this.beneStateCd = beneStateCd;
	}
	
	//beneZipCd
	public String getBeneZipCd() {
		return beneZipCd;
	}
	
	public void setBeneZipCd(String beneZipCd) {
		this.beneZipCd = beneZipCd;
	}
	
	//blgNpiNum
	public String getBlgNpiNum() {
		return blgNpiNum;
	}
	
	public void setBlgNpiNum(String blgNpiNum) {
		this.blgNpiNum = blgNpiNum;
	}
	
	//blgNpiPtanNum
	public String getBlgNpiPtanNum() {
		return blgNpiPtanNum;
	}
	
	public void setBlgNpiPtanNum(String blgNpiPtanNum) {
		this.blgNpiPtanNum = blgNpiPtanNum;
	}
	
	//blgTypeName
	public String getBlgTypeName() {
		return blgTypeName;
	}
	
	public void setBlgTypeName(String blgTypeName) {
		this.blgTypeName = blgTypeName;
	}
	
	//clmBeneLine1Adr
	public String getClmBeneLine1Adr() {
		return clmBeneLine1Adr;
	}
	
	public void setClmBeneLine1Adr(String clmBeneLine1Adr) {
		this.clmBeneLine1Adr = clmBeneLine1Adr;
	}
	
	//clmBeneLine2Adr
	public String getClmBeneLine2Adr() {
		return clmBeneLine2Adr;
	}
	
	public void setClmBeneLine2Adr(String clmBeneLine2Adr) {
		this.clmBeneLine2Adr = clmBeneLine2Adr;
	}
	
	//clmBeneCityName
	public String getClmBeneCityName() {
		return clmBeneCityName;
	}
	
	public void setClmBeneCityName(String clmBeneCityName) {
		this.clmBeneCityName = clmBeneCityName;
	}
	
	//clmBeneLatTxt
	public String getClmBeneLatTxt() {
		return clmBeneLatTxt;
	}
	
	public void setClmBeneLatTxt(String clmBeneLatTxt) {
		this.clmBeneLatTxt = clmBeneLatTxt;
	}
	
	//clmBeneLonTxt
	public String getClmBeneLonTxt() {
		return clmBeneLonTxt;
	}
	
	public void setClmBeneLonTxt(String clmBeneLonTxt) {
		this.clmBeneLonTxt = clmBeneLonTxt;
	}
	
	//clmBeneStateCd
	public String getClmBeneStateCd() {
		return clmBeneStateCd;
	}
	
	public void setClmBeneStateCd(String clmBeneStateCd) {
		this.clmBeneStateCd = clmBeneStateCd;
	}
	
	//clmBeneZipCd
	public String getClmBeneZipCd() {
		return clmBeneZipCd;
	}
	
	public void setClmBeneZipCd(String clmBeneZipCd) {
		this.clmBeneZipCd = clmBeneZipCd;
	}
	
	//clmId
	public String getClmId() {
		return clmId;
	}
	
	public void setClmId(String clmId) {
		this.clmId = clmId;
	}
	
	//cllSubAmt
	public String getCllSubAmt() {
		return cllSubAmt;
	}
	
	public void setCllSubAmt(String cllSubAmt) {
		this.cllSubAmt = cllSubAmt;
	}
	
	//clmRcptDt
	public String getClmRcptDt() {
		return clmRcptDt;
	}
	
	public void setClmRcptDt(String clmRcptDt) {
		this.clmRcptDt = clmRcptDt;
	}
	
	//clmTypeCd
	public String getClmTypeCd() {
		return clmTypeCd;
	}
	
	public void setClmTypeCd(String clmTypeCd) {
		this.clmTypeCd = clmTypeCd;
	}
	
	//condCd
	public String getCondCd() {
		return condCd;
	}
	
	public void setCondCd(String condCd) {
		this.condCd = condCd;
	}
	
	//cntrctNum
	public String getCntrctNum() {
		return cntrctNum;
	}
	
	public void setCntrctNum(String cntrctNum) {
		this.cntrctNum = cntrctNum;
	}
	
	//dgns1Cd
	public String getDgns1Cd() {
		return dgns1Cd;
	}
	
	public void setDgns1Cd(String dgns1Cd) {
		this.dgns1Cd = dgns1Cd;
	}
	
	//dgns2Cd
	public String getDgns2Cd() {
		return dgns2Cd;
	}
	
	public void setDgns2Cd(String dgns2Cd) {
		this.dgns2Cd = dgns2Cd;
	}
	
	//dgns3Cd
	public String getDgns3Cd() {
		return dgns3Cd;
	}
	
	public void setDgns3Cd(String dgns3Cd) {
		this.dgns3Cd = dgns3Cd;
	}
	
	//dgns4Cd
	public String getDgns4Cd() {
		return dgns4Cd;
	}
	
	public void setDgns4Cd(String dgns4Cd) {
		this.dgns4Cd = dgns4Cd;
	}
	
	//dgns5Cd
	public String getDgns5Cd() {
		return dgns5Cd;
	}
	
	public void setDgns5Cd(String dgns5Cd) {
		this.dgns5Cd = dgns5Cd;
	}
	
	//dgns6Cd
	public String getDgns6Cd() {
		return dgns6Cd;
	}
	
	public void setDgns6Cd(String dgns6Cd) {
		this.dgns6Cd = dgns6Cd;
	}
	
	//dgns7Cd
	public String getDgns7Cd() {
		return dgns7Cd;
	}
	
	public void setDgns7Cd(String dgns7Cd) {
		this.dgns7Cd = dgns7Cd;
	}
	
	//dgns8Cd
	public String getDgns8Cd() {
		return dgns8Cd;
	}
	
	public void setDgns8Cd(String dgns8Cd) {
		this.dgns8Cd = dgns8Cd;
	}
	
	//dschrgDt
	public String getDschrgDt() {
		return dschrgDt;
	}
	
	public void setDschrgDt(String dschrgDt) {
		this.dschrgDt = dschrgDt;
	}
	
	//enhncmtId
	public String getEnhncmtId() {
		return enhncmtId;
	}
	
	public void setEnhncmtId(String enhncmtId) {
		this.enhncmtId = enhncmtId;
	}
	
	//enhncmtTime
	public String getEnhncmtTime() {
		return enhncmtTime;
	}
	
	public void setEnhncmtTime(String enhncmtTime) {
		this.enhncmtTime = enhncmtTime;
	}
	
	//filName
	public String getFilName() {
		return filName;
	}
	
	public void setFilName(String filName) {
		this.filName = filName;
	}
	
	//hippsCd
	public String getHippsCd() {
		return hippsCd;
	}
	
	public void setHippsCd(String hippsCd) {
		this.hippsCd = hippsCd;
	}
	
	//hospPrdNum
	public String getHospPrdNum() {
		return hospPrdNum;
	}
	
	public void setHospPrdNum(String hospPrdNum) {
		this.hospPrdNum = hospPrdNum;
	}
	
	//hospUsedDayNum
	public String getHospUsedDayNum() {
		return hospUsedDayNum;
	}
	
	public void setHospUsedDayNum(String hospUsedDayNum) {
		this.hospUsedDayNum = hospUsedDayNum;
	}
	
	//mdcrPymtAmt
	public String getMdcrPymtAmt() {
		return mdcrPymtAmt;
	}
	
	public void setMdcrPymtAmt(String mdcrPymtAmt) {
		this.mdcrPymtAmt = mdcrPymtAmt;
	}
	
	//ordrgPrvdrPecosStusTxt
	public String getOrdrgPrvdrPecosStusTxt() {
		return ordrgPrvdrPecosStusTxt;
	}
	
	public void setOrdrgPrvdrPecosStusTxt(String ordrgPrvdrPecosStusTxt) {
		this.ordrgPrvdrPecosStusTxt = ordrgPrvdrPecosStusTxt;
	}
	
	//ptntStusTxt
	public String getPtntStusTxt() {
		return ptntStusTxt;
	}
	
	public void setPtntStusTxt(String ptntStusTxt) {
		this.ptntStusTxt = ptntStusTxt;
	}
	
	//plcOdSrvcCd
	public String getPlcOdSrvcCd() {
		return plcOdSrvcCd;
	}
	
	public void setPlcOdSrvcCd(String plcOdSrvcCd) {
		this.plcOdSrvcCd = plcOdSrvcCd;
	}
	
	//posZipCd
	public String getPosZipCd() {
		return posZipCd;
	}
	
	public void setPosZipCd(String posZipCd) {
		this.posZipCd = posZipCd;
	}
	
	//prcdrCd
	public String getPrcdrCd() {
		return prcdrCd;
	}
	
	public void setPrcdrCd(String prcdrCd) {
		this.prcdrCd = prcdrCd;
	}
	
	//prcdr1MdfrTxt
	public String getPrcdr1MdfrTxt() {
		return prcdr1MdfrTxt;
	}
	
	public void setPrcdr1MdfrTxt(String prcdr1MdfrTxt) {
		this.prcdr1MdfrTxt = prcdr1MdfrTxt;
	}
	
	//prcdr2MdfrTxt
	public String getPrcdr2MdfrTxt() {
		return prcdr2MdfrTxt;
	}
	
	public void setPrcdr2MdfrTxt(String prcdr2MdfrTxt) {
		this.prcdr2MdfrTxt = prcdr2MdfrTxt;
	}
	
	//prcdr3MdfrTxt
	public String getPrcdr3MdfrTxt() {
		return prcdr3MdfrTxt;
	}
	
	public void setPrcdr3MdfrTxt(String prcdr3MdfrTxt) {
		this.prcdr3MdfrTxt = prcdr3MdfrTxt;
	}
	
	//prcdr4MdfrTxt
	public String getPrcdr4MdfrTxt() {
		return prcdr4MdfrTxt;
	}
	
	public void setPrcdr4MdfrTxt(String prcdr4MdfrTxt) {
		this.prcdr4MdfrTxt = prcdr4MdfrTxt;
	}
	
	//prcdr5MdfrTxt
	public String getPrcdr5MdfrTxt() {
		return prcdr5MdfrTxt;
	}
	
	public void setPrcdr5MdfrTxt(String prcdr5MdfrTxt) {
		this.prcdr5MdfrTxt = prcdr5MdfrTxt;
	}
	
	//prcdrTime
	public String getPrcdrTime() {
		return prcdrTime;
	}
	
	public void setPrcdrTime(String prcdrTime) {
		this.prcdrTime = prcdrTime;
	}
	
	//prvdrReimbrsmtAmt
	public String getPrvdrReimbrsmtAmt() {
		return prvdrReimbrsmtAmt;
	}
	
	public void setPrvdrReimbrsmtAmt(String prvdrReimbrsmtAmt) {
		this.prvdrReimbrsmtAmt = prvdrReimbrsmtAmt;
	}
	
	//prvdrSpcltyCd
	public String getPrvdrSpcltyCd() {
		return prvdrSpcltyCd;
	}
	
	public void setPrvdrSpcltyCd(String prvdrSpcltyCd) {
		this.prvdrSpcltyCd = prvdrSpcltyCd;
	}
	
	//prvdrCityName
	public String getPrvdrCityName() {
		return prvdrCityName;
	}
	
	public void setPrvdrCityName(String prvdrCityName) {
		this.prvdrCityName = prvdrCityName;
	}
	
	//prvdrLatTxt
	public String getPrvdrLatTxt() {
		return prvdrLatTxt;
	}
	
	public void setPrvdrLatTxt(String prvdrLatTxt) {
		this.prvdrLatTxt = prvdrLatTxt;
	}
	
	//prvdrLonTxt
	public String getPrvdrLonTxt() {
		return prvdrLonTxt;
	}
	
	public void setPrvdrLonTxt(String prvdrLonTxt) {
		this.prvdrLonTxt = prvdrLonTxt;
	}
	
	//prvdrName
	public String getPrvdrName() {
		return prvdrName;
	}
	
	public void setPrvdrName(String prvdrName) {
		this.prvdrName = prvdrName;
	}
	
	//prvdrNpiNum
	public String getPrvdrNpiNum() {
		return prvdrNpiNum;
	}
	
	public void setPrvdrNpiNum(String prvdrNpiNum) {
		this.prvdrNpiNum = prvdrNpiNum;
	}
	
	//prvdrPtanNum
	public String getPrvdrPtanNum() {
		return prvdrPtanNum;
	}
	
	public void setPrvdrPtanNum(String prvdrPtanNum) {
		this.prvdrPtanNum = prvdrPtanNum;
	}
	
	//prvdrSpclty1Cd
	public String getPrvdrSpclty1Cd() {
		return prvdrSpclty1Cd;
	}
	
	public void setPrvdrSpclty1Cd(String prvdrSpclty1Cd) {
		this.prvdrSpclty1Cd = prvdrSpclty1Cd;
	}
	
	//prvdrStateName
	public String getPrvdrStateName() {
		return prvdrStateName;
	}
	
	public void setPrvdrStateName(String prvdrStateName) {
		this.prvdrStateName = prvdrStateName;
	}
	
	//prvdrTxnmyName
	public String getPrvdrTxnmyName() {
		return prvdrTxnmyName;
	}
	
	public void setPrvdrTxnmyName(String prvdrTxnmyName) {
		this.prvdrTxnmyName = prvdrTxnmyName;
	}
	
	//prvdrTinNum
	public String getPrvdrTinNum() {
		return prvdrTinNum;
	}
	
	public void setPrvdrTinNum(String prvdrTinNum) {
		this.prvdrTinNum = prvdrTinNum;
	}
	
	//prvdrZipCd
	public String getPrvdrZipCd() {
		return prvdrZipCd;
	}
	
	public void setPrvdrZipCd(String prvdrZipCd) {
		this.prvdrZipCd = prvdrZipCd;
	}
	
	//prvdrRfrncZipCd
	public String getPrvdrRfrncZipCd() {
		return prvdrRfrncZipCd;
	}
	
	public void setPrvdrRfrncZipCd(String prvdrRfrncZipCd) {
		this.prvdrRfrncZipCd = prvdrRfrncZipCd;
	}
	
	//rfrgPrvdrLine1Adr
	public String getRfrgPrvdrLine1Adr() {
		return rfrgPrvdrLine1Adr;
	}
	
	public void setRfrgPrvdrLine1Adr(String rfrgPrvdrLine1Adr) {
		this.rfrgPrvdrLine1Adr = rfrgPrvdrLine1Adr;
	}
	
	//rfrgPrvdrCityName
	public String getRfrgPrvdrCityName() {
		return rfrgPrvdrCityName;
	}
	
	public void setRfrgPrvdrCityName(String rfrgPrvdrCityName) {
		this.rfrgPrvdrCityName = rfrgPrvdrCityName;
	}
	
	//rfrgPrvdrLatTxt
	public String getRfrgPrvdrLatTxt() {
		return rfrgPrvdrLatTxt;
	}
	
	public void setRfrgPrvdrLatTxt(String rfrgPrvdrLatTxt) {
		this.rfrgPrvdrLatTxt = rfrgPrvdrLatTxt;
	}
	
	//rfrgPrvdrLonTxt
	public String getRfrgPrvdrLonTxt() {
		return rfrgPrvdrLonTxt;
	}
	
	public void setRfrgPrvdrLonTxt(String rfrgPrvdrLonTxt) {
		this.rfrgPrvdrLonTxt = rfrgPrvdrLonTxt;
	}
	
	//rfrgPrvdrName
	public String getRfrgPrvdrName() {
		return rfrgPrvdrName;
	}
	
	public void setRfrgPrvdrName(String rfrgPrvdrName) {
		this.rfrgPrvdrName = rfrgPrvdrName;
	}
	
	//rfrgPrvdrNpiNum
	public String getRfrgPrvdrNpiNum() {
		return rfrgPrvdrNpiNum;
	}
	
	public void setRfrgPrvdrNpiNum(String rfrgPrvdrNpiNum) {
		this.rfrgPrvdrNpiNum = rfrgPrvdrNpiNum;
	}
	
	//rfrgPrvdrPtanNum
	public String getRfrgPrvdrPtanNum() {
		return rfrgPrvdrPtanNum;
	}
	
	public void setRfrgPrvdrPtanNum(String rfrgPrvdrPtanNum) {
		this.rfrgPrvdrPtanNum = rfrgPrvdrPtanNum;
	}
	
	//rfrgPrvdrSpcltyCd
	public String getRfrgPrvdrSpcltyCd() {
		return rfrgPrvdrSpcltyCd;
	}
	
	public void setRfrgPrvdrSpcltyCd(String rfrgPrvdrSpcltyCd) {
		this.rfrgPrvdrSpcltyCd = rfrgPrvdrSpcltyCd;
	}
	
	//rfrgPrvdrZipCd
	public String getRfrgPrvdrZipCd() {
		return rfrgPrvdrZipCd;
	}
	
	public void setRfrgPrvdrZipCd(String rfrgPrvdrZipCd) {
		this.rfrgPrvdrZipCd = rfrgPrvdrZipCd;
	}
	
	//reimbrsmtAmt
	public String getReimbrsmtAmt() {
		return reimbrsmtAmt;
	}
	
	public void setReimbrsmtAmt(String reimbrsmtAmt) {
		this.reimbrsmtAmt = reimbrsmtAmt;
	}
	
	//revCd
	public String getRevCd() {
		return revCd;
	}
	
	public void setRevCd(String revCd) {
		this.revCd = revCd;
	}
	
	//srvcChrgAmt
	public String getSrvcChrgAmt() {
		return srvcChrgAmt;
	}
	
	public void setSrvcChrgAmt(String srvcChrgAmt) {
		this.srvcChrgAmt = srvcChrgAmt;
	}
	
	//srvcFacZipCd
	public String getSrvcFacZipCd() {
		return srvcFacZipCd;
	}
	
	public void setSrvcFacZipCd(String srvcFacZipCd) {
		this.srvcFacZipCd = srvcFacZipCd;
	}
	
	//srvcFromDt
	public String getSrvcFromDt() {
		return srvcFromDt;
	}
	
	public void setSrvcFromDt(String srvcFromDt) {
		this.srvcFromDt = srvcFromDt;
	}
	
	//srvcLineNum
	public String getSrvcLineNum() {
		return srvcLineNum;
	}
	
	public void setSrvcLineNum(String srvcLineNum) {
		this.srvcLineNum = srvcLineNum;
	}
	
	//srvcLineQlfyrNum
	public String getSrvcLineQlfyrNum() {
		return srvcLineQlfyrNum;
	}
	
	public void setSrvcLineQlfyrNum(String srvcLineQlfyrNum) {
		this.srvcLineQlfyrNum = srvcLineQlfyrNum;
	}
	
	//srvcLineThruDt
	public String getSrvcLineThruDt() {
		return srvcLineThruDt;
	}
	
	public void setSrvcLineThruDt(String srvcLineThruDt) {
		this.srvcLineThruDt = srvcLineThruDt;
	}
	
	//stmtFromDt
	public String getStmtFromDt() {
		return stmtFromDt;
	}
	
	public void setStmtFromDt(String stmtFromDt) {
		this.stmtFromDt = stmtFromDt;
	}
	
	//stmtThruDt
	public String getStmtThruDt() {
		return stmtThruDt;
	}
	
	public void setStmtThruDt(String stmtThruDt) {
		this.stmtThruDt = stmtThruDt;
	}
	
	//sbmtrEntId
	public String getSbmtrEntId() {
		return sbmtrEntId;
	}
	
	public void setSbmtrEntId(String sbmtrEntId) {
		this.sbmtrEntId = sbmtrEntId;
	}
	
	//sbmtrId
	public String getSbmtrId() {
		return sbmtrId;
	}
	
	public void setSbmtrId(String sbmtrId) {
		this.sbmtrId = sbmtrId;
	}
	
	//transId
	public String getTransId() {
		return transId;
	}
	
	public void setTransId(String transId) {
		this.transId = transId;
	}
	
	//srvcTypeCd
	public String getSrvcTypeCd() {
		return srvcTypeCd;
	}
	
	public void setSrvcTypeCd(String srvcTypeCd) {
		this.srvcTypeCd = srvcTypeCd;
	}
	
	//unitName
	public String getUnitName() {
		return unitName;
	}
	
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}
	
	//zpicCd
	public String getZpicCd() {
		return zpicCd;
	}
	
	public void setZpicCd(String zpicCd) {
		this.zpicCd = zpicCd;
	}
	
	//modelName
	public String getModelName() {
		return modelName;
	}
	
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	
	//prmryDgnsCd
	public String getPrmryDgnsCd() {
		return prmryDgnsCd;
	}
	
	public void setPrmryDgnsCd(String prmryDgnsCd) {
		this.prmryDgnsCd = prmryDgnsCd;
	}
	
	//entTypeCd
	public String getEntTypeCd() {
		return entTypeCd;
	}
	
	public void setEntTypeCd(String entTypeCd) {
		this.entTypeCd = entTypeCd;
	}
	
	//actnCd
	public String getActnCd() {
		return actnCd;
	}
	
	public void setActnCd(String actnCd) {
		this.actnCd = actnCd;
	}
	
	//dualStusInd
	public String getDualStusInd() {
		return dualStusInd;
	}
	
	public void setDualStusInd(String dualStusInd) {
		this.dualStusInd = dualStusInd;
	}
	
	//scndryPyrId
	public String getScndryPyrId() {
		return scndryPyrId;
	}
	
	public void setScndryPyrId(String scndryPyrId) {
		this.scndryPyrId = scndryPyrId;
	}
	
	//crossOvrInd
	public String getCrossOvrInd() {
		return crossOvrInd;
	}
	
	public void setCrossOvrInd(String crossOvrInd) {
		this.crossOvrInd = crossOvrInd;
	}
	
	//crossOvrDstntnId
	public String getCrossOvrDstntnId() {
		return crossOvrDstntnId;
	}
	
	public void setCrossOvrDstntnId(String crossOvrDstntnId) {
		this.crossOvrDstntnId = crossOvrDstntnId;
	}
	
	//crossOvrDstntnTransId
	public String getCrossOvrDstntnTransId() {
		return crossOvrDstntnTransId;
	}
	
	public void setCrossOvrDstntnTransId(String crossOvrDstntnTransId) {
		this.crossOvrDstntnTransId = crossOvrDstntnTransId;
	}
	
	//srgryCd
	public String getSrgryCd() {
		return srgryCd;
	}
	
	public void setSrgryCd(String srgryCd) {
		this.srgryCd = srgryCd;
	}
	
	//othrModelName
	public String getOthrModelName() {
		return othrModelName;
	}
	
	public void setOthrModelName(String othrModelName) {
		this.othrModelName = othrModelName;
	}
	
	//fpsVrsnInd
	public String getFpsVrsnInd() {
		return fpsVrsnInd;
	}
	
	public void setFpsVrsnInd(String fpsVrsnInd) {
		this.fpsVrsnInd = fpsVrsnInd;
	}
	
	//prvdrLine1Adr
	public String getPrvdrLine1Adr() {
		return prvdrLine1Adr;
	}
	
	public void setPrvdrLine1Adr(String prvdrLine1Adr) {
		this.prvdrLine1Adr = prvdrLine1Adr;
	}
	
	//rfrgPrvdrStateCd
	public String getRfrgPrvdrStateCd() {
		return rfrgPrvdrStateCd;
	}
	
	public void setRfrgPrvdrStateCd(String rfrgPrvdrStateCd) {
		this.rfrgPrvdrStateCd = rfrgPrvdrStateCd;
	}
	
	//rcncltnStusTxt
	public String getRcncltnStusTxt() {
		return rcncltnStusTxt;
	}
	
	public void setRcncltnStusTxt(String rcncltnStusTxt) {
		this.rcncltnStusTxt = rcncltnStusTxt;
	}
	
	//rcncltnDt
	public String getRcncltnDt() {
		return rcncltnDt;
	}
	
	public void setRcncltnDt(String rcncltnDt) {
		this.rcncltnDt = rcncltnDt;
	}
	
	//initlEnrlmtDt
	public String getInitlEnrlmtDt() {
		return initlEnrlmtDt;
	}
	
	public void setInitlEnrlmtDt(String initlEnrlmtDt) {
		this.initlEnrlmtDt = initlEnrlmtDt;
	}
	
}
