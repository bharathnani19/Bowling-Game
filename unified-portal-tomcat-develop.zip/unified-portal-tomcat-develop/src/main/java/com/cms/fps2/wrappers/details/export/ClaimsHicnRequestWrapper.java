package com.cms.fps2.wrappers.details.export;

public class ClaimsHicnRequestWrapper {
	private String asrptId;
	
	//constructor
	public ClaimsHicnRequestWrapper(){}
	
	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
}
