package com.cms.fps2.wrappers.details;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.details.tab.partdclaims.PartDClaimLines;
import com.cms.fps2.wrappers.rptcard.DrillClaims;

public class DrillClaimsRespWrapper {
	private List<DrillClaims> drillClaims = new ArrayList<DrillClaims>();
	private List<PartDClaimLines> partDDrillClaims = new ArrayList<PartDClaimLines>();
	
	//constructor
	public DrillClaimsRespWrapper() {}
	
	//drillClaims
	public List<DrillClaims> getDrillClaims() {
		return drillClaims;
	}
	
	public void setDrillClaims(List<DrillClaims> drillClaims) {
		this.drillClaims = drillClaims;
	}
	
	//partDDrillClaims
	public List<PartDClaimLines> getPartDDrillClaims() {
		return partDDrillClaims;
	}
	
	public void setPartDDrillClaims(List<PartDClaimLines> partDDrillClaims) {
		this.partDDrillClaims = partDDrillClaims;
	}
}
