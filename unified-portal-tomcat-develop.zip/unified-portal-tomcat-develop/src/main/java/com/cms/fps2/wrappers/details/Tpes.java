package com.cms.fps2.wrappers.details;

public class Tpes {
	
	private String prvdrNpi;
	private String ptan;
	private String prvdrStateCd;
	private String macRvwRsnDesc;
	private String cartRvwTopicDesc;
	private String tpeRnd;
	private String intraProbeEdctnOfrd;
	private String intraProbeEdctnAcptd;
	private String intraProbeEdctn1Dt;
	private String intraProbeEdctn1Desc;
	private String intraProbeEdctn2Dt;
	private String intraProbeEdctn2Desc;
	private String intraProbeEdctn3Dt;
	private String intraProbeEdctn3Desc;
	private String intraProbeEdctn4Dt;
	private String intraProbeEdctn4Desc;
	private String intraProbeEdctn5Dt;
	private String intraProbeEdctn5Desc;
	private String postProbeEdctnOfrd;
	private String postProbeEdctnActpd;
	private String postProbeEdctnDt;
	private String postProbeEdctnDesc;
	private String edctnDnlRsn1Desc;
	private String edctnDnlRsn2Desc;
	private String edctnDnlRateIncrInd;
	private String rfrlToDesc;
	private String rfrlRsnDesc;
	private String ctrctrId;
	private String asrptId;
	private String tpeInd;
	private String lastDtEdctn;
	private String edctnSucsInd;
	private String edctnOffered;
	private String edctnDnlRsn3Desc;
	private String cmtTxt;
	
	// constructor
	public Tpes() {}
	
	public String getPrvdrNpi() {
		return prvdrNpi;
	}
	
	public void setPrvdrNpi(String prvdrNpi) {
		this.prvdrNpi = prvdrNpi;
	}
	
	//ptan
	public String getPtan() {
		return ptan;
	}
	
	public void setPtan(String ptan) {
		this.ptan = ptan;
	}
	
	// prvdrStateCd
	public String getPrvdrStateCd() {
		return prvdrStateCd;
	}
	
	public void setPrvdrStateCd(String prvdrStateCd) {
		this.prvdrStateCd = prvdrStateCd;
	}
	
	//macRvwRsnDesc
	public String getMacRvwRsnDesc() {
		return macRvwRsnDesc;
	}
	
	public void setMacRvwRsnDesc(String macRvwRsnDesc) {
		this.macRvwRsnDesc = macRvwRsnDesc;
	}
	
	//cartRvwTopicDesc
	public String getCartRvwTopicDesc() {
		return cartRvwTopicDesc;
	}
	
	public void setCartRvwTopicDesc(String cartRvwTopicDesc) {
		this.cartRvwTopicDesc = cartRvwTopicDesc;
	}
	
	//tpeRnd
	public String getTpeRnd() {
		return tpeRnd;
	}
	
	public void setTpeRnd(String tpeRnd) {
		this.tpeRnd = tpeRnd;
	}
	
	//intraProbeEdctnOfrd
	public String getIntraProbeEdctnOfrd() {
		return intraProbeEdctnOfrd;
	}
	
	public void setIntraProbeEdctnOfrd(String intraProbeEdctnOfrd) {
		this.intraProbeEdctnOfrd = intraProbeEdctnOfrd;
	}
	
	//intraProbeEdctnAcptd
	public String getIntraProbeEdctnAcptd() {
		return intraProbeEdctnAcptd;
	}
	
	public void setIntraProbeEdctnAcptd(String intraProbeEdctnAcptd) {
		this.intraProbeEdctnAcptd = intraProbeEdctnAcptd;
	}
	
	// intraProbeEdctn1Dt
	public String getIntraProbeEdctn1Dt() {
		return intraProbeEdctn1Dt;
	}
	
	public void setIntraProbeEdctn1Dt(String intraProbeEdctn1Dt) {
		this.intraProbeEdctn1Dt = intraProbeEdctn1Dt;
	}
	
	//intraProbeEdctn1Desc
	public String getIntraProbeEdctn1Desc() {
		return intraProbeEdctn1Desc;
	}
	
	public void setIntraProbeEdctn1Desc(String intraProbeEdctn1Desc) {
		this.intraProbeEdctn1Desc = intraProbeEdctn1Desc;
	}
	
	//intraProbeEdctn2Dt
	public String getIntraProbeEdctn2Dt() {
		return intraProbeEdctn2Dt;
	}
	
	public void setIntraProbeEdctn2Dt(String intraProbeEdctn2Dt) {
		this.intraProbeEdctn2Dt = intraProbeEdctn2Dt;
	}
	
	//intraProbeEdctn2Desc
	public String getIntraProbeEdctn2Desc() {
		return intraProbeEdctn2Desc;
	}
	
	public void setIntraProbeEdctn2Desc(String intraProbeEdctn2Desc) {
		this.intraProbeEdctn2Desc = intraProbeEdctn2Desc;
	}
	
	//intraProbeEdctn3Dt
	public String getIntraProbeEdctn3Dt() {
		return intraProbeEdctn3Dt;
	}
	
	public void setIntraProbeEdctn3Dt(String intraProbeEdctn3Dt) {
		this.intraProbeEdctn3Dt = intraProbeEdctn3Dt;
	}
	
	//intraProbeEdctn3Desc
	public String getIntraProbeEdctn3Desc() {
		return intraProbeEdctn3Desc;
	}
	
	public void setIntraProbeEdctn3Desc(String intraProbeEdctn3Desc) {
		this.intraProbeEdctn3Desc = intraProbeEdctn3Desc;
	}
	
	//intraProbeEdctn4Dt
	public String getIntraProbeEdctn4Dt() {
		return intraProbeEdctn4Dt;
	}
	
	public void setIntraProbeEdctn4Dt(String intraProbeEdctn4Dt) {
		this.intraProbeEdctn4Dt = intraProbeEdctn4Dt;
	}
	
	//intraProbeEdctn4Desc
	public String getIntraProbeEdctn4Desc() {
		return intraProbeEdctn4Desc;
	}
	
	public void setIntraProbeEdctn4Desc(String intraProbeEdctn4Desc) {
		this.intraProbeEdctn4Desc = intraProbeEdctn4Desc;
	}
	
	//intraProbeEdctn5Dt
	public String getIntraProbeEdctn5Dt() {
		return intraProbeEdctn5Dt;
	}
	
	public void setIntraProbeEdctn5Dt(String intraProbeEdctn5Dt) {
		this.intraProbeEdctn5Dt = intraProbeEdctn5Dt;
	}
	
	//intraProbeEdctn5Desc
	public String getIntraProbeEdctn5Desc() {
		return intraProbeEdctn5Desc;
	}
	
	public void setIntraProbeEdctn5Desc(String intraProbeEdctn5Desc) {
		this.intraProbeEdctn5Desc = intraProbeEdctn5Desc;
	}
	
	//postProbeEdctnOfrd
	public String getPostProbeEdctnOfrd() {
		return postProbeEdctnOfrd;
	}
	
	public void setPostProbeEdctnOfrd(String postProbeEdctnOfrd) {
		this.postProbeEdctnOfrd = postProbeEdctnOfrd;
	}
	
	//postProbeEdctnActpd
	public String getPostProbeEdctnActpd() {
		return postProbeEdctnActpd;
	}
	
	public void setPostProbeEdctnActpd(String postProbeEdctnActpd) {
		this.postProbeEdctnActpd = postProbeEdctnActpd;
	}
	
	//postProbeEdctnDt
	public String getPostProbeEdctnDt() {
		return postProbeEdctnDt;
	}
	
	public void setPostProbeEdctnDt(String postProbeEdctnDt) {
		this.postProbeEdctnDt = postProbeEdctnDt;
	}
	
	//postProbeEdctnDesc
	public String getPostProbeEdctnDesc() {
		return postProbeEdctnDesc;
	}
	
	public void setPostProbeEdctnDesc(String postProbeEdctnDesc) {
		this.postProbeEdctnDesc = postProbeEdctnDesc;
	}
		
	//edctnDnlRsn1Desc
	public String getEdctnDnlRsn1Desc() {
		return edctnDnlRsn1Desc;
	}
	
	public void setEdctnDnlRsn1Desc(String edctnDnlRsn1Desc) {
		this.edctnDnlRsn1Desc = edctnDnlRsn1Desc;
	}
	
	//edctnDnlRsn2Desc
	public String getEdctnDnlRsn2Desc() {
		return edctnDnlRsn2Desc;
	}
	
	public void setEdctnDnlRsn2Desc(String edctnDnlRsn2Desc) {
		this.edctnDnlRsn2Desc = edctnDnlRsn2Desc;
	}
	
	//edctnDnlRateIncrInd
	public String getEdctnDnlRateIncrInd() {
		return edctnDnlRateIncrInd;
	}
	
	public void setEdctnDnlRateIncrInd(String edctnDnlRateIncrInd) {
		this.edctnDnlRateIncrInd = edctnDnlRateIncrInd;
	}
	
	//rfrlToDesc
	public String getRfrlToDesc() {
		return rfrlToDesc;
	}
	
	public void setRfrlToDesc(String rfrlToDesc) {
		this.rfrlToDesc = rfrlToDesc;
	}
	
	//rfrlRsnDesc
	public String getRfrlRsnDesc() {
		return rfrlRsnDesc;
	}
	
	public void setRfrlRsnDesc(String rfrlRsnDesc) {
		this.rfrlRsnDesc = rfrlRsnDesc;
	}
	
	// ctrctrId
	public String getCtrctrId() {
		return ctrctrId;
	}
	
	public void setCtrctrId(String ctrctrId) {
		this.ctrctrId = ctrctrId;
	}
	
	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	//tpeInd
	public String getTpeInd() {
		return tpeInd;
	}
	
	public void setTpeInd(String tpeInd) {
		this.tpeInd = tpeInd;
	}
	
	//lastDtEdctn
	public String getLastDtEdctn() {
		return lastDtEdctn;
	}
	
	public void setLastDtEdctn(String lastDtEdctn) {
		this.lastDtEdctn = lastDtEdctn;
	}
	
	//edctnSucsInd
	public String getEdctnSucsInd() {
		return edctnSucsInd;
	}
	
	public void setEdctnSucsInd(String edctnSucsInd) {
		this.edctnSucsInd = edctnSucsInd;
	}
	
	//edctnOffered
	public String getEdctnOffered() {
		return edctnOffered;
	}
	
	public void setEdctnOffered(String edctnOffered) {
		this.edctnOffered = edctnOffered;
	}
	
	// edctnDnlRsn3Desc
	public String getEdctnDnlRsn3Desc() {
		return edctnDnlRsn3Desc;
	}
	
	public void setEdctnDnlRsn3Desc(String edctnDnlRsn3Desc) {
		this.edctnDnlRsn3Desc = edctnDnlRsn3Desc;
	}
	
	// cmtTxt
	public String getCmtTxt() {
		return cmtTxt;
	}
	
	public void setCmtTxt(String cmtTxt) {
		this.cmtTxt = cmtTxt;
	}
	
}
