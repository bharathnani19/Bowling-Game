package com.cms.fps2.wrappers.summary.workitems;

public class InfoModelListReqWrapper {
    private String infoModel;
	private String infoDate;
	private String userId;
	
	// constructor
	public InfoModelListReqWrapper() {}
	
	// workItemId
	public String getInfoModel() {
		return infoModel;
	}
	
	public void setInfoModel(String infoModel) {
		this.infoModel = infoModel;
	}
	
	// userId
	public String getInfoDate() {
		return infoDate;
	}
	
	public void setInfoDate(String infoDate) {
		this.infoDate = infoDate;
	}

	// userId

	public String getUserId() {
		return userId;
	}

	// userId

	public void setUserId(String userId) {
		this.userId = userId;
	}
}