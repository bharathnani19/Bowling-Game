package com.cms.fps2.wrappers.details;

public class Edits {
	
	private String editNum;
	private String alertName;
	private String firstDetectedDenialDt;
	private String lastDetectedDenialDt;
	private String numClaimsDenied;
	private String totalDeniedPaymentsClaimsAmt;
	private String numLineItemsDenied;
	private String totalDeniedPaymentsLinesAmt;
	private String numProcCodes;
	private String numDenialCodes;
	private String dateLastReconciled;
	private String fpsEditNum;

	//constructor
	public Edits(){}
	
	//editNum 	
	public String getEditNum() {
		return editNum;
	}
	
	public void setEditNum(String editNum) {
		this.editNum = editNum;
	}
	
	//alertName 	
	public String getAlertName() {
		return alertName;
	}
	
	public void setAlertName(String alertName) {
		this.alertName = alertName;
	}
	
	//firstDetectedDenialDt 	
	public String getFirstDetectedDenialDt() {
		return firstDetectedDenialDt;
	}
	
	public void setFirstDetectedDenialDt(String firstDetectedDenialDt) {
		this.firstDetectedDenialDt = firstDetectedDenialDt;
	}
	
	//lastDetectedDenialDt 	
	public String getLastDetectedDenialDt() {
		return lastDetectedDenialDt;
	}
	
	public void setLastDetectedDenialDt(String lastDetectedDenialDt) {
		this.lastDetectedDenialDt = lastDetectedDenialDt;
	}
	
	//numClaimsDenied 	
	public String getNumClaimsDenied() {
		return numClaimsDenied;
	}
	
	public void setNumClaimsDenied(String numClaimsDenied) {
		this.numClaimsDenied = numClaimsDenied;
	}
	
	//totalDeniedPaymentsClaimsAmt 	
	public String getTotalDeniedPaymentsClaimsAmt() {
		return totalDeniedPaymentsClaimsAmt;
	}
	
	public void setTotalDeniedPaymentsClaimsAmt(String totalDeniedPaymentsClaimsAmt) {
		this.totalDeniedPaymentsClaimsAmt = totalDeniedPaymentsClaimsAmt;
	}
	
	//numLineItemsDenied 	
	public String getNumLineItemsDenied() {
		return numLineItemsDenied;
	}
	
	public void setNumLineItemsDenied(String numLineItemsDenied) {
		this.numLineItemsDenied = numLineItemsDenied;
	}
	
	//totalDeniedPaymentsLinesAmt 	
	public String getTotalDeniedPaymentsLinesAmt() {
		return totalDeniedPaymentsLinesAmt;
	}
	
	public void setTotalDeniedPaymentsLinesAmt(String totalDeniedPaymentsLinesAmt) {
		this.totalDeniedPaymentsLinesAmt = totalDeniedPaymentsLinesAmt;
	}
	
	//numProcCodes 	
	public String getNumProcCodes() {
		return numProcCodes;
	}
	
	public void setNumProcCodes(String numProcCodes) {
		this.numProcCodes = numProcCodes;
	}
	
	//numDenialCodes 	
	public String getNumDenialCodes() {
		return numDenialCodes;
	}
	
	public void setNumDenialCodes(String numDenialCodes) {
		this.numDenialCodes = numDenialCodes;
	}
	
	//dateLastReconciled
	public String getDateLastReconciled() {
		return dateLastReconciled;
	}
	
	public void setDateLastReconciled(String dateLastReconciled) {
		this.dateLastReconciled = dateLastReconciled;
	}
	
	//fpsEditNum
	public String getFpsEditNum() {
		return fpsEditNum;
	}
	
	public void setFpsEditNum(String fpsEditNum) {
		this.fpsEditNum = fpsEditNum;
	}
	
}
