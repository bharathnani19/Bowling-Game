package com.cms.fps2.wrappers.summary;

public class Users {
	//constructor
	public Users(){}
}
