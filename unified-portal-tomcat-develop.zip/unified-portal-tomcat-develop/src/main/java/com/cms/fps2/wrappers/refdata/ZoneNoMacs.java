package com.cms.fps2.wrappers.refdata;

public class ZoneNoMacs {
	
	private String zoneCd;
    private String zoneDesc;
	
	//constructor
	public ZoneNoMacs(){}
	
	//zoneCd
	public String getZoneCd() {
		return zoneCd;
	}
	
	public void setZoneCd(String zoneCd) {
		this.zoneCd = zoneCd;
	}
	
	//zoneDesc
	public String getZoneDesc() {
		return zoneDesc;
	}
	
	public void setZoneDesc(String zoneDesc) {
		this.zoneDesc = zoneDesc;
	}

}
