package com.cms.fps2.wrappers.details.provider;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.details.provider.Bius;


public class SysTags {
	
	private List<String> fids = new ArrayList<String>();
	private List<Bius> bius = new ArrayList<Bius>();
	private List<Ucms> ucms = new ArrayList<Ucms>();
	private List<com.cms.fps2.wrappers.details.provider.systags.SysTags> sysTags = new ArrayList<com.cms.fps2.wrappers.details.provider.systags.SysTags>();
	
	//constructor
	public SysTags(){}
	
	//fids 	
	public List<String> getFids() {
		return fids;
	}
	
	public void setFids(List<String> fids) {
		this.fids = fids;
	}
	
	//bius 	
	public List<Bius> getBius() {
		return bius;
	}
	
	public void setBius(List<Bius> bius) {
		this.bius = bius;
	}
	
	//ucms 	
	public List<Ucms> getUcms() {
		return ucms;
	}
	
	public void setUcms(List<Ucms> ucms) {
		this.ucms = ucms;
	}
	
	//sysTags 	
	public List<com.cms.fps2.wrappers.details.provider.systags.SysTags> getSysTags() {
		return sysTags;
	}
	
	public void setSysTags(List<com.cms.fps2.wrappers.details.provider.systags.SysTags> sysTags) {
		this.sysTags = sysTags;
	}
}
