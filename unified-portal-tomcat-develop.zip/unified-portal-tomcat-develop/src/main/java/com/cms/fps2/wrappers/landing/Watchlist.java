package com.cms.fps2.wrappers.landing;

import java.util.ArrayList;
import java.util.List;

public class Watchlist {
	private String name;
	private List<WatchItems> items = new ArrayList<WatchItems>();
	
	// constructor
	public Watchlist() {}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	// items
	public List<WatchItems> getItems() {
		return items;
	}
	
	public void setItems(List<WatchItems> items) {
		this.items = items;
	}
}
