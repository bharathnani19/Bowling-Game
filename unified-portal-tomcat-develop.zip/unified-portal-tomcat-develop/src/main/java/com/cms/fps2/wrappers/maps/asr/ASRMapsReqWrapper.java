package com.cms.fps2.wrappers.maps.asr;

public class ASRMapsReqWrapper {
	private String asrptId;
	private String userId;
	private String resultsIndex;
	
	//constructor
	public ASRMapsReqWrapper() {}
	
	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//resultsIndex
	public String getResultsIndex() {
		return resultsIndex;
	}
	
	public void setResultsIndex(String resultsIndex) {
		this.resultsIndex = resultsIndex;
	}
}
