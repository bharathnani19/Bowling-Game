package com.cms.fps2.wrappers.summary.modals;

public class Trends {
	
	private String asrptId;
	private String riskScoreDt;
	private String riskScore;
	
	//constructor
	public Trends(){}
	
	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	//riskScoreDt
	public String getRiskScoreDt() {
		return riskScoreDt;
	}
	
	public void setRiskScoreDt(String riskScoreDt) {
		this.riskScoreDt = riskScoreDt;
	}
	
	//riskScore
	public String getRiskScore() {
		return riskScore;
	}
	
	public void setRiskScore(String riskScore) {
		this.riskScore = riskScore;
	}

}
