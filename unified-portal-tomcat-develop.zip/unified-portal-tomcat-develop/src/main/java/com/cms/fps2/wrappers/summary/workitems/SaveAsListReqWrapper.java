package com.cms.fps2.wrappers.summary.workitems;

public class SaveAsListReqWrapper {
	private FpsPrioritizationList fpsPrioritizationList;
	
	// constructor
	public SaveAsListReqWrapper() {}
	
	// fpsPrioritizationList
	public FpsPrioritizationList getFpsPrioritizationList() {
		return fpsPrioritizationList;
	}
	
	public void setFpsPrioritizationList(FpsPrioritizationList fpsPrioritizationList) {
		this.fpsPrioritizationList = fpsPrioritizationList;
	}
}
