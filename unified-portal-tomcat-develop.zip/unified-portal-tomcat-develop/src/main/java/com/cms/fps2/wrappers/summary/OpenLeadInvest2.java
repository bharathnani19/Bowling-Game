package com.cms.fps2.wrappers.summary;

import java.util.ArrayList;
import java.util.List;

public class OpenLeadInvest2 {
	
	private String id;
	private String status;
	private String createdDt;
	private String activities;
	private String assignedTo;
	private String actions;
	private String ruling;
	private String source;
	private List<UcmActions> ucmActions = new ArrayList<UcmActions>();
	private String ucmId;
	private List<UcmActivities> ucmActivities = new ArrayList<UcmActivities>();
	private List<String> ucmModelRatings = new ArrayList<String>();
	
	// constructor
	public OpenLeadInvest2() {}
	
	//id
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	//status
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	//createdDt
	public String getCreatedDt() {
		return createdDt;
	}
	
	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}
	
	//activities
	public String getActivities() {
		return activities;
	}
	
	public void setActivities(String activities) {
		this.activities = activities;
	}
	
	//assignedTo
	public String getAssignedTo() {
		return assignedTo;
	}
	
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	
	//actions
	public String getActions() {
		return actions;
	}
	
	public void setActions(String actions) {
		this.actions = actions;
	}
	
	//ruling
	public String getRuling() {
		return ruling;
	}
	
	public void setRuling(String ruling) {
		this.ruling = ruling;
	}
	
	//source
	public String getSource() {
		return source;
	}
	
	public void setSource(String source) {
		this.source = source;
	}
	
	//ucmActions
	public List<UcmActions> getUcmActions() {
		return ucmActions;
	}
	
	public void setUcmActions(List<UcmActions> ucmActions) {
		this.ucmActions = ucmActions;
	}
	
	//ucmId
	public String getUcmId() {
		return ucmId;
	}
	
	public void setUcmId(String ucmId) {
		this.ucmId = ucmId;
	}
	
	//ucmActivities
	public List<UcmActivities> getUcmActivities() {
		return ucmActivities;
	}
	
	public void setUcmActivities(List<UcmActivities> ucmActivities) {
		this.ucmActivities = ucmActivities;
	}
	
	//ucmModelRatings
	public List<String> getUcmModelRatings() {
		return ucmModelRatings;
	}
	
	public void setUcmModelRatings(List<String> ucmModelRatings) {
		this.ucmModelRatings = ucmModelRatings;
	}
}
