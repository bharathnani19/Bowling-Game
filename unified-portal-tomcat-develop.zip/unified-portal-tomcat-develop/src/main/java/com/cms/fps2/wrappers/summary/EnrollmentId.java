package com.cms.fps2.wrappers.summary;

public class EnrollmentId {
	private String code;
	private String desc;
	
	// constructor
	public EnrollmentId() {}
	
	//code
	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}
	
	//desc
	public String getDesc() {
		return desc;
	}
	
	public void setDesc(String desc) {
		this.desc = desc;
	}
}
