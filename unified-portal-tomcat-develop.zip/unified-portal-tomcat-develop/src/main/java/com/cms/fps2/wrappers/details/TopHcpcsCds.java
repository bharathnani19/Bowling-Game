package com.cms.fps2.wrappers.details;

public class TopHcpcsCds {
	
	private String key;
	private String value;
	private String desc;
	private String amt;
	
	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getAmt() {
		return amt;
	}

	public void setAmt(String amt) {
		this.amt = amt;
	}

	//constructor
	public TopHcpcsCds() {}
	
	//key
	public String getKey() {
		return key;
	}
	
	public void setKey(String key) {
		this.key = key;
	}
	
	//value
	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}

}
