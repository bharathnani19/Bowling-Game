package com.cms.fps2.wrappers.details;

public class History {
	private String userName;
	private String recordedDt;
	private String eventDt;
	private String riskScore;
	private String description;
	private String comments;
	private String legacyPriority;
	
	//constructor
	public History(){}
	
	
	//userName
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	//recordedDt
	public String getRecordedDt() {
		return recordedDt;
	}
	
	public void setRecordedDt(String recordedDt) {
		this.recordedDt = recordedDt;
	}
	
	//eventDt
	public String getEventDt() {
		return eventDt;
	}
	
	public void setEventDt(String eventDt) {
		this.eventDt = eventDt;
	}
	
	//riskScore
	public String getRiskScore() {
		return riskScore;
	}
	
	public void setRiskScore(String riskScore) {
		this.riskScore = riskScore;
	}
	
	//description
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	//comments
	public String getComments() {
		return comments;
	}
	
	public void setComments(String comments) {
		this.comments = comments;
	}	
	
	//legacyPriority
	public String getLegacyPriority() {
		return legacyPriority;
	}
	
	public void setLegacyPriority(String legacyPriority) {
		this.legacyPriority = legacyPriority;
	}
	
}
