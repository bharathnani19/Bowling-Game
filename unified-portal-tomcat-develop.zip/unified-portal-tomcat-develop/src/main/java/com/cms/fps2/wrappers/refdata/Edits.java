package com.cms.fps2.wrappers.refdata;

public class Edits {
	private String code;
	// constructor
	public Edits() {}
	
	// code
	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}
}
