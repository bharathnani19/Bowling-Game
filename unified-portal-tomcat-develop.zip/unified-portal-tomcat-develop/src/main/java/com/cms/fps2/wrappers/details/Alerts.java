package com.cms.fps2.wrappers.details;

public class Alerts {
	private String alertTypeCd;
	private String alertTypeDesc;
	private String alertId;
	private String alertDesc;
	private String alertStatusCd;
	private String modelName;
	
	//alertTypeCd 	
	public String getAlertTypeCd() {
		return alertTypeCd;
	}
	
	public void setAlertTypeCd(String alertTypeCd) {
		this.alertTypeCd = alertTypeCd;
	}
	
	//alertTypeDesc 	
	public String getAlertTypeDesc() {
		return alertTypeDesc;
	}
	
	public void setAlertTypeDesc(String alertTypeDesc) {
		this.alertTypeDesc = alertTypeDesc;
	}
	
	//alertId 	
	public String getAlertId() {
		return alertId;
	}
	
	public void setAlertId(String alertId) {
		this.alertId = alertId;
	}
	
	//alertDesc 	
	public String getAlertDesc() {
		return alertDesc;
	}
	
	public void setAlertDesc(String alertDesc) {
		this.alertDesc = alertDesc;
	}
	
	//alertStatusCd 	
	public String getAlertStatusCd() {
		return alertStatusCd;
	}
	
	public void setAlertStatusCd(String alertStatusCd) {
		this.alertStatusCd = alertStatusCd;
	}
	
	//modelName 	
	public String getModelName() {
		return modelName;
	}
	
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
}
