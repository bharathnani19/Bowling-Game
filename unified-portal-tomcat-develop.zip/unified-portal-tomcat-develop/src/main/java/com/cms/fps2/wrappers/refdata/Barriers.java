package com.cms.fps2.wrappers.refdata;

public class Barriers {
	private String barrierCd;
	private String barrierDesc;
	
	public Barriers(){}
	
	//barrierCd
	public String getBarrierCd() {
		return barrierCd;
	}
	
	public void setBarrierCd(String barrierCd) {
		this.barrierCd = barrierCd;
	}
	
	//barrierCd
	public String getBarrierDesc() {
		return barrierDesc;
	}
	
	public void setBarrierDesc(String barrierDesc) {
		this.barrierDesc = barrierDesc;
	}
}
