package com.cms.fps2.wrappers.rptcard;

import java.util.List;

import com.cms.fps2.wrappers.refdata.AsrStatesByUserResponse;

public class AsrStatesByUserWrapper {
	private List<AsrStatesByUserResponse> states;

	public List<AsrStatesByUserResponse> getStates() {
		return states;
	}

	public void setStates(List<AsrStatesByUserResponse> states) {
		this.states = states;
	}
}
