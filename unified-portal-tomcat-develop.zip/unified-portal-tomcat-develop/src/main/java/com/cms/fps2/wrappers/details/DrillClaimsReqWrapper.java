package com.cms.fps2.wrappers.details;

public class DrillClaimsReqWrapper {
	private String npi;
	private String userId;
	private String attrSqncNum;
	private String modelId;
	private String drillType;
	
	//constructor
	public DrillClaimsReqWrapper() {}
	
	//npi
	public String getNpi() {
		return npi;
	}
	
	public void setNpi(String npi) {
		this.npi = npi;
	}
	
	//userId 	
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//attrSqncNum
	public String getAttrSqncNum() {
		return attrSqncNum;
	}
	
	public void setAttrSqncNum(String attrSqncNum) {
		this.attrSqncNum = attrSqncNum;
	}
	
	//modelId
	public String getModelId() {
		return modelId;
	}
	
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	
	// drillType
	public String getDrillType() {
		return drillType;
	}
	
	public void setDrillType(String drillType) {
		this.drillType = drillType;
	}
	
}
