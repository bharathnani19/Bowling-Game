package com.cms.fps2.wrappers.summary;

public class Rulings {
	
	private String desc;
	private String code;
	
	//constructor
	public Rulings(){}
	
	//rulings
	public String getDesc() {
		return desc;
	}
		
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	//code for Adv Search
	public String getCode() {
		return code;
	}
		
	public void setCode(String code) {
		this.code = code;
	}
}
