package com.cms.fps2.wrappers.details.tab.claims;

import com.cms.fps2.wrappers.details.tab.claims.ResponseData;

public class ClaimsTabResponseWrapper {
	private ResponseData responseData;
	
	//constructor
	public ClaimsTabResponseWrapper(){}
	
	//responseData
	public ResponseData getResponseData() {
		return responseData;
	}
	
	public void setResponseData(ResponseData responseData) {
		this.responseData = responseData;
	}
}
