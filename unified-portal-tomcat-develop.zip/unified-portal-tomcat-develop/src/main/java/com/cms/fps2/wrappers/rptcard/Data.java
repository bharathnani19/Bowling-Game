package com.cms.fps2.wrappers.rptcard;

public class Data {
	private String columnData;
	private String columnIndex;
	private String rowIndex;
	private String linkToAsrInd;
	private String columnImgSrc;
	private String columnImgSrcType;
	
	//constructor
	public Data(){}
	
	//columnData
	public String getColumnData() {
		return columnData;
	}
	
	public void setColumnData(String columnData) {
		this.columnData = columnData;
	}
	
	//columnIndex
	public String getColumnIndex() {
		return columnIndex;
	}
	
	public void setColumnIndex(String columnIndex) {
		this.columnIndex = columnIndex;
	}
	
	//rowIndex
	public String getRowIndex() {
		return rowIndex;
	}
	
	public void setRowIndex(String rowIndex) {
		this.rowIndex = rowIndex;
	}
	
	// linkToAsrInd
	public String getLinkToAsrInd() {
		return linkToAsrInd;
	}
	
	public void setLinkToAsrInd(String linkToAsrInd) {
		this.linkToAsrInd = linkToAsrInd;
	}

	// columnImgSrc
	public String getcolumnImgSrc() {
		return columnImgSrc;
	}
	
	public void setcolumnImgSrc(String columnImgSrc) {
		this.columnImgSrc = columnImgSrc;
	}

	//columnImgSrcType
	public String getcolumnImgSrcType() {
		return columnImgSrcType;
	}
	
	public void setcolumnImgSrcType(String columnImgSrcType) {
		this.columnImgSrcType = columnImgSrcType;
	}
}
