package com.cms.fps2.wrappers.rptcard;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.details.tab.partdclaims.PartDClaimLines;

public class AaSingle {
	private String overThreshold;
	private String infoOrAction;
	private String drill;
	private String providerValue;
	private String nationalMed;
	private String zoneMed;
	private String zoneThreshold;
	private String providerNatRank;
	private String provderZoneRank;
	private String contribToAlertPriority;
	private String relatedPrvdrNpi;
	private String relatedPrvdrName;
	private String subjPrvdrBeneCnt;
	private String relatedPrvdrBeneCnt;
	private String sharedBeneCnt;
	private String subjectPrvdrSharedBenePct;
	private String relatedPrvdrSharedBenePct;
	private String riskRelationshipRsn;
	private String reportCardType;
	private String npi;
	private String asOfDt;
	private String subjPrvdrName;
	private String jurisdiction;
	private String attrDef;
	private String modelCompScore;
	private String modelScoreThreshold;
	private List<DrillClaims> drillClaims = new ArrayList<DrillClaims>();
	private String modelId;
	private String modelBusnsId;
	private String latestAlert;
	private List<PartDClaimLines> partDDrillClaims = new ArrayList<PartDClaimLines>();
	private String attrSqncNum;
	private String macMed;
	private String macPctl;
	private String drillD;
	
	//constructor
	public AaSingle(){}
	
	//overThreshold
	public String getOverThreshold() {
		return overThreshold;
	}
	
	public void setOverThreshold(String overThreshold) {
		this.overThreshold = overThreshold;
	}
	
	//infoOrAction
	public String getInfoOrAction() {
		return infoOrAction;
	}
	
	public void setInfoOrAction(String infoOrAction) {
		this.infoOrAction = infoOrAction;
	}
	
	//drill
	public String getDrill() {
		return drill;
	}
	
	public void setDrill(String drill) {
		this.drill = drill;
	}
	
	//providerValue
	public String getProviderValue() {
		return providerValue;
	}
	
	public void setProviderValue(String providerValue) {
		this.providerValue = providerValue;
	}
	
	//nationalMed
	public String getNationalMed() {
		return nationalMed;
	}
	
	public void setNationalMed(String nationalMed) {
		this.nationalMed = nationalMed;
	}
	
	//zoneMed
	public String getZoneMed() {
		return zoneMed;
	}
	
	public void setZoneMed(String zoneMed) {
		this.zoneMed = zoneMed;
	}
	
	//zoneThreshold
	public String getZoneThreshold() {
		return zoneThreshold;
	}
	
	public void setZoneThreshold(String zoneThreshold) {
		this.zoneThreshold = zoneThreshold;
	}
	
	//providerNatRank
	public String getProviderNatRank() {
		return providerNatRank;
	}
	
	public void setProviderNatRank(String providerNatRank) {
		this.providerNatRank = providerNatRank;
	}
	
	//provderZoneRank
	public String getProvderZoneRank() {
		return provderZoneRank;
	}
	
	public void setProvderZoneRank(String provderZoneRank) {
		this.provderZoneRank = provderZoneRank;
	}
	
	//contribToAlertPriority
	public String getContribToAlertPriority() {
		return contribToAlertPriority;
	}
	
	public void setContribToAlertPriority(String contribToAlertPriority) {
		this.contribToAlertPriority = contribToAlertPriority;
	}
	
	//relatedPrvdrNpi
	public String getRelatedPrvdrNpi() {
		return relatedPrvdrNpi;
	}
	
	public void setRelatedPrvdrNpi(String relatedPrvdrNpi) {
		this.relatedPrvdrNpi = relatedPrvdrNpi;
	}
	
	//relatedPrvdrName
	public String getRelatedPrvdrName() {
		return relatedPrvdrName;
	}
	
	public void setRelatedPrvdrName(String relatedPrvdrName) {
		this.relatedPrvdrName = relatedPrvdrName;
	}
	
	//subjPrvdrBeneCnt
	public String getSubjPrvdrBeneCnt() {
		return subjPrvdrBeneCnt;
	}
	
	public void setSubjPrvdrBeneCnt(String subjPrvdrBeneCnt) {
		this.subjPrvdrBeneCnt = subjPrvdrBeneCnt;
	}
	
	//relatedPrvdrBeneCnt
	public String getRelatedPrvdrBeneCnt() {
		return relatedPrvdrBeneCnt;
	}
	
	public void setRelatedPrvdrBeneCnt(String relatedPrvdrBeneCnt) {
		this.relatedPrvdrBeneCnt = relatedPrvdrBeneCnt;
	}
	
	//sharedBeneCnt
	public String getSharedBeneCnt() {
		return sharedBeneCnt;
	}
	
	public void setSharedBeneCnt(String sharedBeneCnt) {
		this.sharedBeneCnt = sharedBeneCnt;
	}
	
	//subjectPrvdrSharedBenePct
	public String getSubjectPrvdrSharedBenePct() {
		return subjectPrvdrSharedBenePct;
	}
	
	public void setSubjectPrvdrSharedBenePct(String subjectPrvdrSharedBenePct) {
		this.subjectPrvdrSharedBenePct = subjectPrvdrSharedBenePct;
	}
	
	//relatedPrvdrSharedBenePct
	public String getRelatedPrvdrSharedBenePct() {
		return relatedPrvdrSharedBenePct;
	}
	
	public void setRelatedPrvdrSharedBenePct(String relatedPrvdrSharedBenePct) {
		this.relatedPrvdrSharedBenePct = relatedPrvdrSharedBenePct;
	}
	
	//riskRelationshipRsn
	public String getRiskRelationshipRsn() {
		return riskRelationshipRsn;
	}
	
	public void setRiskRelationshipRsn(String riskRelationshipRsn) {
		this.riskRelationshipRsn = riskRelationshipRsn;
	}
	
	//reportCardType
	public String getReportCardType() {
		return reportCardType;
	}
	
	public void setReportCardType(String reportCardType) {
		this.reportCardType = reportCardType;
	}
	
	//npi
	public String getNpi() {
		return npi;
	}
	
	public void setNpi(String npi) {
		this.npi = npi;
	}
	
	//asOfDt
	public String getAsOfDt() {
		return asOfDt;
	}
	
	public void setAsOfDt(String asOfDt) {
		this.asOfDt = asOfDt;
	}
	
	//subjPrvdrName
	public String getSubjPrvdrName() {
		return subjPrvdrName;
	}
	
	public void setSubjPrvdrName(String subjPrvdrName) {
		this.subjPrvdrName = subjPrvdrName;
	}
	
	//jurisdiction
	public String getJurisdiction() {
		return jurisdiction;
	}
	
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}
	
	//attrDef
	public String getAttrDef() {
		return attrDef;
	}
	
	public void setAttrDef(String attrDef) {
		this.attrDef = attrDef;
	}
	
	//modelCompScore
	public String getModelCompScore() {
		return modelCompScore;
	}
	
	public void setModelCompScore(String modelCompScore) {
		this.modelCompScore = modelCompScore;
	}
	
	//modelScoreThreshold
	public String getModelScoreThreshold() {
		return modelScoreThreshold;
	}
	
	public void setModelScoreThreshold(String modelScoreThreshold) {
		this.modelScoreThreshold = modelScoreThreshold;
	}
	
	//drillClaims
	public List<DrillClaims> getDrillClaims() {
		return drillClaims;
	}
	
	public void setDrillClaims(List<DrillClaims> drillClaims) {
		this.drillClaims = drillClaims;
	}
	
	//modelId
	public String getModelId() {
		return modelId;
	}
	
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	
	//modelBusnsId
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	
	//latestAlert
	public String getLatestAlert() {
		return latestAlert;
	}
	
	public void setLatestAlert(String latestAlert) {
		this.latestAlert = latestAlert;
	}
	
	//partDDrillClaims
	public List<PartDClaimLines> getPartDDrillClaims() {
		return partDDrillClaims;
	}
	
	public void setPartDDrillClaims(List<PartDClaimLines> partDDrillClaims) {
		this.partDDrillClaims = partDDrillClaims;
	}
	
	//attrSqncNum
	public String getAttrSqncNum() {
		return attrSqncNum;
	}
	
	public void setAttrSqncNum(String attrSqncNum) {
		this.attrSqncNum = attrSqncNum;
	}
	
	//macMed
	public String getMacMed() {
		return macMed;
	}
	
	public void setMacMed(String macMed) {
		this.macMed = macMed;
	}
	
	//macPctl
	public String getMacPctl() {
		return macPctl;
	}
	
	public void setMacPctl(String macPctl) {
		this.macPctl = macPctl;
	}	
	
	// drillD
	public String getDrillD() {
		return drillD;
	}
	
	public void setDrillD(String drillD) {
		this.drillD = drillD;
	}
	
}
