package com.cms.fps2.wrappers.details.provider;

public class TotalPaymentRespWrapper {
	private ResponseData responseData = new ResponseData();
	
	// constructor
	public TotalPaymentRespWrapper() {}
	
	//responseData
	public ResponseData getResponseData() {
		return responseData;
	}
	
	public void setResponseData(ResponseData responseData) {
		this.responseData = responseData;
	}
}
