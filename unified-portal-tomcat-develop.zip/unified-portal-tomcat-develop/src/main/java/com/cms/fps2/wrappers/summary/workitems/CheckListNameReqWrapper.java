package com.cms.fps2.wrappers.summary.workitems;

public class CheckListNameReqWrapper {
	
	private String userId;
	private String listNm;
	private String listType;
	
	// constructor
	public CheckListNameReqWrapper() {}
	
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	// listNm
	public String getListNm() {
		return listNm;
	}
	
	public void setListNm(String listNm) {
		this.listNm = listNm;
	}
	
	// listType
	public String getListType() {
		return listType;
	}
	
	public void setListType(String listType) {
		this.listType = listType;
	}

}
