package com.cms.fps2.wrappers.details.provider;

import java.util.ArrayList;
import java.util.List;

public class ResponseData {
	
	private String prioritized;
	private List<TotalPymtZones> totalPymtZones = new ArrayList<TotalPymtZones>();
	
	// constructor	
	public ResponseData() {}
	
	//prioritized
	public String getPrioritized() {
		return prioritized;
	}
	
	public void setPrioritized(String prioritized) {
		this.prioritized = prioritized;
	}
	
	// totalPymtZones
	public List<TotalPymtZones>  getTotalPymtZones() {
		return totalPymtZones;
	}
	
	public void setTotalPymtZones(List<TotalPymtZones> totalPymtZones) {
		this.totalPymtZones = totalPymtZones;
	}
}
