package com.cms.fps2.wrappers.details.tab.edits;

public class InactiveEditInfos {
	
	private String fpsEditNum;
	private String fpsEditName;
	private String modelCntrctr;
	private String editOwner;
	private String audtInsrtId;
	private String echimpName;
	private String audtInsrtTs;
	private String audtUpdtId;
	private String audtUpdtTs;
	private String actvInd;
	private String macInfo;
	private String editDesc;
	private String editActnType;
	private String lineOfBusns;
	private String hstry;
	private String hstryLkbckPrd;
	private String echimpNum;
	
	//constructor
	public InactiveEditInfos() {}
		
	// fpsEditNum
	public String getFpsEditNum() {
		return fpsEditNum;
	}
	
	public void setFpsEditNum(String fpsEditNum) {
		this.fpsEditNum = fpsEditNum;
	}
	
	// fpsEditName
	public String getFpsEditName() {
		return fpsEditName;
	}
	
	public void setFpsEditName(String fpsEditName) {
		this.fpsEditName = fpsEditName;
	}
	
	// modelCntrctr
	public String getModelCntrctr() {
		return modelCntrctr;
	}
	
	public void setModelCntrctr(String modelCntrctr) {
		this.modelCntrctr = modelCntrctr;
	}
	
	// editOwner
	public String getEditOwner() {
		return editOwner;
	}
	
	public void setEditOwner(String editOwner) {
		this.editOwner = editOwner;
	}
	
	// audtInsrtId
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	
	// echimpName
	public String getEchimpName() {
		return echimpName;
	}
	
	public void setEchimpName(String echimpName) {
		this.echimpName = echimpName;
	}
	
	// audtInsrtTs
	public String getAudtInsrtTs() {
		return audtInsrtTs;
	}
	
	public void setAudtInsrtTs(String audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	
	// audtUpdtId
	public String getAudtUpdtId() {
		return audtUpdtId;
	}
	
	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	
	// audtUpdtTs
	public String getAudtUpdtTs() {
		return audtUpdtTs;
	}
	
	public void setAudtUpdtTs(String audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
	
	// actvInd
	public String getActvInd() {
		return actvInd;
	}
	
	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}
	
	// macInfo
	public String getMacInfo() {
		return macInfo;
	}
	
	public void setMacInfo(String macInfo) {
		this.macInfo = macInfo;
	}
	
	// editDesc
	public String getEditDesc() {
		return editDesc;
	}
	
	public void setEditDesc(String editDesc) {
		this.editDesc = editDesc;
	}
	
	// editActnType
	public String getEditActnType() {
		return editActnType;
	}
	
	public void setEditActnType(String editActnType) {
		this.editActnType = editActnType;
	}
	
	// lineOfBusns
	public String getLineOfBusns() {
		return lineOfBusns;
	}
	
	public void setLineOfBusns(String lineOfBusns) {
		this.lineOfBusns = lineOfBusns;
	}
	
	// hstry
	public String getHstry() {
		return hstry;
	}
	
	public void setHstry(String hstry) {
		this.hstry = hstry;
	}
	
	// hstryLkbckPrd
	public String getHstryLkbckPrd() {
		return hstryLkbckPrd;
	}
	
	public void setHstryLkbckPrd(String hstryLkbckPrd) {
		this.hstryLkbckPrd = hstryLkbckPrd;
	}
	
	// echimpNum
	public String getEchimpNum() {
		return echimpNum;
	}
	
	public void setEchimpNum(String echimpNum) {
		this.echimpNum = echimpNum;
	}


}
