package com.cms.fps2.wrappers.details;

public class TotalCostZones {
	
	private String zone;
	private String totalClaimLines;
	private String totalCost;
	private String jurisdiction;
	private String totalClaimLinesAll;
	private String totalCostAll;
	
	//constructor
	public TotalCostZones(){}
	
	//zone
	public String getZone() {
		return zone;
	}
	
	public void setZone(String zone) {
		this.zone = zone;
	}
	
	//totalClaimLines
	public String getTotalClaimLines() {
		return totalClaimLines;
	}
	
	public void setTotalClaimLines(String totalClaimLines) {
		this.totalClaimLines = totalClaimLines;
	}
	
	//totalCost
	public String getTotalCost() {
		return totalCost;
	}
	
	public void setTotalCost(String totalCost) {
		this.totalCost = totalCost;
	}
	
	//jurisdiction
	public String getJurisdiction() {
		return jurisdiction;
	}
	
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}
	
	// totalClaimLinesAll 
	public String getTotalClaimLinesAll() {
		return totalClaimLinesAll;
	}
	
	public void setTotalClaimLinesAll(String totalClaimLinesAll) {
		this.totalClaimLinesAll = totalClaimLinesAll;
	}
	
	// totalCostAll
	public String getTotalCostAll() {
		return totalCostAll;
	}
	
	public void setTotalCostAll(String totalCostAll) {
		this.totalCostAll = totalCostAll;
	}
}
