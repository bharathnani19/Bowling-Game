package com.cms.fps2.wrappers.summary.medicaid;

import java.util.ArrayList;
import java.util.List;

public class ResponseData {
	
	private boolean prioritized;
	
	private List<MdcdTotalPayments> mdcdTotalPayments = new ArrayList<MdcdTotalPayments>();

	// mdcdTotalPayments
	
	public List<MdcdTotalPayments> getMdcdTotalPayments() {
		return mdcdTotalPayments;
	}

	// mdcdTotalPayments
	
	public void setMdcdTotalPayments(List<MdcdTotalPayments> mdcdTotalPayments) {
		this.mdcdTotalPayments = mdcdTotalPayments;
	}

	// prioritized
	
	public boolean isPrioritized() {
		return prioritized;
	}

	// prioritized
	
	public void setPrioritized(boolean prioritized) {
		this.prioritized = prioritized;
	}
	
	
	
	
	
	
	

}
