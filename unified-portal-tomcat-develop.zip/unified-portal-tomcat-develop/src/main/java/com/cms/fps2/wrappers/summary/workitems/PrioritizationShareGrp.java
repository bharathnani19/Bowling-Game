package com.cms.fps2.wrappers.summary.workitems;

import java.util.ArrayList;
import java.util.List;

public class PrioritizationShareGrp {
	private String grpId;
	private String grpNm;
	private String grpType;
	private String listId;
	private String grpTxt;
	List<String> userIds = new ArrayList<String>();
	
	// constructor
	public PrioritizationShareGrp () {}
	
	// grpId
	public String getGrpId() {
		return grpId;
	}
	
	public void setGrpId(String grpId) {
		this.grpId = grpId;
	}
	
	// grpNm
	public String getGrpNm() {
		return grpNm;
	}
	
	public void setGrpNm(String grpNm) {
		this.grpNm = grpNm;
	}
	
	// grpType
	public String getGrpType() {
		return grpType;
	}
	
	public void setGrpType(String grpType) {
		this.grpType = grpType;
	}
	
	// listId
	public String getListId() {
		return listId;
	}
	
	public void setListId(String listId) {
		this.listId = listId;
	}
	
	// userIds
	public List<String> getUserIds() {
		return userIds;
	}
	
	public void setUserIds(List<String> userIds) {
		this.userIds = userIds;
	}
	
	// grpTxt
	public String getGrpTxt() {
		return grpTxt;
	}
	
	public void setGrpTxt(String grpTxt) {
		this.grpTxt = grpTxt;
	}
}
