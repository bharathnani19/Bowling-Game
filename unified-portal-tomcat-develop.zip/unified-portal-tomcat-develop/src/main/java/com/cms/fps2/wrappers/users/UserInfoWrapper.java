package com.cms.fps2.wrappers.users;

public class UserInfoWrapper {
	
	private String uid;
	private String firstName;
	private String lastName;
	private String organization;
	private String lastLogin;
	private String[] userRoles;
	private String asrPrioritization; 
	private String masterApprover;
	private String prtAdmin;
	private String prtRead;
	private String prtWrite;
	private String vmAdmin;
	private String vmCreate;
	private String vmRead;
	private String vmUpdateEdit;
	
	//empty constructor
	public UserInfoWrapper() {
		
	}
	
	//uid
	public String getUid() {
		return uid;
	}
	
	public void setUid(String uid) {
		this.uid = uid;
	}
	
	//first name
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	//last name
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	//organization
	public String getOrganization() {
		return organization;
	}
	
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	
	//last login time
	public String getLastLogin() {
		return lastLogin;
	}
	
	public void setLastLogin(String lastLogin) {
		this.lastLogin = lastLogin;
	}
	
	//user Roles
    public String[] getUserRoles() {
        return userRoles;
    }
    
    public void setUserRoles(String[] userRoles) {
        this.userRoles = userRoles;
    }
    
    //asrPrioritization
	public String getAsrPrioritization() {
		return asrPrioritization;
	}
	
	public void setAsrPrioritization(String asrPrioritization) {
		this.asrPrioritization = asrPrioritization;
	}
	
	//masterApprover
	public String getMasterApprover() {
		return masterApprover;
	}
	
	public void setMasterApprover(String masterApprover) {
		this.masterApprover = masterApprover;
	}
	
	//prtAdmin
	public String getPrtAdmin() {
		return prtAdmin;
	}
	
	public void setPrtAdmin(String prtAdmin) {
		this.prtAdmin = prtAdmin;
	}
	
	//prtRead
	public String getPrtRead() {
		return prtRead;
	}
	
	public void setPrtRead(String prtRead) {
		this.prtRead = prtRead;
	}
	
	//prtWrite
	public String getPrtWrite() {
		return prtWrite;
	}
	
	public void setPrtWrite(String prtWrite) {
		this.prtWrite = prtWrite;
	}
	
	//vmAdmin
	public String getVmAdmin() {
		return vmAdmin;
	}
	
	public void setVmAdmin(String vmAdmin) {
		this.vmAdmin = vmAdmin;
	}
	
	//vmCreate
	public String getVmCreate() {
		return vmCreate;
	}
	
	public void setVmCreate(String vmCreate) {
		this.vmCreate = vmCreate;
	}
	
	//vmRead
	public String getVmRead() {
		return vmRead;
	}
	
	public void setVmRead(String vmRead) {
		this.vmRead = vmRead;
	}
	
	//vmUpdateEdit
	public String getVmUpdateEdit() {
		return vmUpdateEdit;
	}
	
	public void setVmUpdateEdit(String vmUpdateEdit) {
		this.vmUpdateEdit = vmUpdateEdit;
	}
}
