package com.cms.fps2.wrappers.landing;

public class ShareUsersObj {
	private String userId;
	private String firstNm;
	private String lastNm;
	private String sharedInd;
	private String jurisdiction;
	
	// constructor
	public ShareUsersObj() {};

	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	// firstNm
	public String getFirstNm() {
		return firstNm;
	}
	
	public void setFirstNm(String firstNm) {
		this.firstNm = firstNm;
	}
	
	// lastNm
	public String getLastNm() {
		return lastNm;
	}
	
	public void setLastNm(String lastNm) {
		this.lastNm = lastNm;
	}
	
	// sharedInd
	public String getSharedInd() {
		return sharedInd;
	}
	
	public void setSharedInd(String sharedInd) {
		this.sharedInd = sharedInd;
	}
	
	// jurisdiction
	public String getJurisdiction() {
		return jurisdiction;
	}
	
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}
}
