package com.cms.fps2.wrappers.details.tab.systags;

public class SysTagsTabReqWrapper {
	private String asrptId; 
	private String userId;
	
	//constructor
	public SysTagsTabReqWrapper(){}
	

	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
