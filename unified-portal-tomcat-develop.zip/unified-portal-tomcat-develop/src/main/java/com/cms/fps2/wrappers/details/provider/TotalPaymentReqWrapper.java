package com.cms.fps2.wrappers.details.provider;

public class TotalPaymentReqWrapper {
	private String asrptId;
	private String userId;
	
	public TotalPaymentReqWrapper() {}
	
	// asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
