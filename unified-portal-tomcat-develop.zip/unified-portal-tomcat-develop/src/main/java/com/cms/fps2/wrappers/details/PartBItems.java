package com.cms.fps2.wrappers.details;

public class PartBItems {
	//constructor
	public PartBItems(){}
	
	private String claimType;
	private String macId;
	private String jurisdiction;
	private String submitterId;
	private String performNpi;
	private String performPtan;
	private String performSpecialty;
	private String performPrvdrCity;
	private String performPrvdrStateCd;
	private String providerZip;
	private String attendNpiName;
	private String beneId;
	private String beneFirstName;
	private String beneLastName;
	private String beneCity;
	private String age;
	private String birthDt;
	private String deathDt;
	private String dualInd;
	private String claimNum;
	private String claimLineNum;
	private String procedure;
	private String procTimeHrs;
	private String mod1;
	private String mod2;
	private String mod3;
	private String mod4;
	private String mod5;
	private String lineFromDt;
	private String lineToDt;
	private String claimFromDt;
	private String claimToDt;
	private String claimToReview;
	private String unitsService;
	private String lineProviderPaidAmt;
	private String claimSubmittedAmt;
	private String claimAllowedAmt;
	private String claimProviderPaidAmt;
	private String crossoverInd;
	private String referNpi;
	private String referPtan;
	private String referNpiName;
	private String billNpi;
	private String billPtan;
	private String billPrvdrName;
	private String lineSubmittedAmt;
	private String lineAllowedAmt;	
	private String attendNpi;
	private String attendSpecialty;
	private String beneStateCd;
	private String beneZip;
	private String alertAttributeName;
	private String referNpiSpecialty;
	private String beneAddress;
	private String attendPtan;
	private String diagnosis;	
	private String billType;
	private String revenueCode;	
	private String tinEinOnClaim;
	private String providerName;
	private String benePhone;
	private String mbi;
	private String claimId;
	private String alertClaimId;
	private String modelString;
	private String diagnosis1;
	private String diagnosis2;
	private String pos;
	private String admitDt;
	private String dischargeDt;
	private String paymentAmt;
	private String unitsAlwd;
	private String drg;
	private String lineDiagnosis;
	private String hcpcsCd;
	
	//claimType
	public String getClaimType() {
		return claimType;
	}
	
	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}
	
	//macId
	public String getMacId() {
		return macId;
	}
	
	public void setMacId(String macId) {
		this.macId = macId;
	}
	
	//jurisdiction
	public String getJurisdiction() {
		return jurisdiction;
	}
	
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	//submitterId
	public String getSubmitterId() {
		return submitterId;
	}
	
	public void setSubmitterId(String submitterId) {
		this.submitterId = submitterId;
	}
	
	//performNpi
	public String getPerformNpi() {
		return performNpi;
	}
	
	public void setPerformNpi(String performNpi) {
		this.performNpi = performNpi;
	}
	
	//performPtan
	public String getPerformPtan() {
		return performPtan;
	}
	
	public void setPerformPtan(String performPtan) {
		this.performPtan = performPtan;
	}
	
	//performSpecialty
	public String getPerformSpecialty() {
		return performSpecialty;
	}
	
	public void setPerformSpecialty(String performSpecialty) {
		this.performSpecialty = performSpecialty;
	}
	
	//performPrvdrCity
	public String getPerformPrvdrCity() {
		return performPrvdrCity;
	}
	
	public void setPerformPrvdrCity(String performPrvdrCity) {
		this.performPrvdrCity = performPrvdrCity;
	}
	
	//performPrvdrStateCd
	public String getPerformPrvdrStateCd() {
		return performPrvdrStateCd;
	}
	
	public void setPerformPrvdrStateCd(String performPrvdrStateCd) {
		this.performPrvdrStateCd = performPrvdrStateCd;
	}
	
	//providerZip
	public String getProviderZip() {
		return providerZip;
	}
	
	public void setProviderZip(String providerZip) {
		this.providerZip = providerZip;
	}
	
	//attendNpiName
	public String getAttendNpiName() {
		return attendNpiName;
	}
	
	public void setAttendNpiName(String attendNpiName) {
		this.attendNpiName = attendNpiName;
	}
	
	//beneId
	public String getBeneId() {
		return beneId;
	}
	
	public void setBeneId(String beneId) {
		this.beneId = beneId;
	}
	
	//beneFirstName
	public String getBeneFirstName() {
		return beneFirstName;
	}
	
	public void setBeneFirstName(String beneFirstName) {
		this.beneFirstName = beneFirstName;
	}
	
	//beneLastName
	public String getBeneLastName() {
		return beneLastName;
	}
	
	public void setBeneLastName(String beneLastName) {
		this.beneLastName = beneLastName;
	}
	
	//beneCity
	public String getBeneCity() {
		return beneCity;
	}
	
	public void setBeneCity(String beneCity) {
		this.beneCity = beneCity;
	}
	
	//age
	public String getAge() {
		return age;
	}
	
	public void setAge(String age) {
		this.age = age;
	}
	
	//birthDt
	public String getBirthDt() {
		return birthDt;
	}
	
	public void setBirthDt(String birthDt) {
		this.birthDt = birthDt;
	}
	
	//deathDt
	public String getDeathDt() {
		return deathDt;
	}
	
	public void setDeathDt(String deathDt) {
		this.deathDt = deathDt;
	}
	
	//dualInd
	public String getDualInd() {
		return dualInd;
	}
	
	public void setDualInd(String dualInd) {
		this.dualInd = dualInd;
	}
	
	//claimNum
	public String getClaimNum() {
		return claimNum;
	}
	
	public void setClaimNum(String claimNum) {
		this.claimNum = claimNum;
	}
	
	//claimLineNum
	public String getClaimLineNum() {
		return claimLineNum;
	}
	
	public void setClaimLineNum(String claimLineNum) {
		this.claimLineNum = claimLineNum;
	}
	
	//procedure
	public String getProcedure() {
		return procedure;
	}
	
	public void setProcedure(String procedure) {
		this.procedure = procedure;
	}
	
	//procTimeHrs
	public String getProcTimeHrs() {
		return procTimeHrs;
	}
	
	public void setProcTimeHrs(String procTimeHrs) {
		this.procTimeHrs = procTimeHrs;
	}
	
	//mod1
	public String getMod1() {
		return mod1;
	}
	
	public void setMod1(String mod1) {
		this.mod1 = mod1;
	}
	
	//mod2
	public String getMod2() {
		return mod2;
	}
	
	public void setMod2(String mod2) {
		this.mod2 = mod2;
	}
	
	//mod3
	public String getMod3() {
		return mod3;
	}
	
	public void setMod3(String mod3) {
		this.mod3 = mod3;
	}
	
	//mod4
	public String getMod4() {
		return mod4;
	}
	
	public void setMod4(String mod4) {
		this.mod4 = mod4;
	}
	
	//mod5
	public String getMod5() {
		return mod5;
	}
	
	public void setMod5(String mod5) {
		this.mod5 = mod5;
	}
	
	//lineFromDt
	public String getLineFromDt() {
		return lineFromDt;
	}
	
	public void setLineFromDt(String lineFromDt) {
		this.lineFromDt = lineFromDt;
	}
	
	//lineToDt
	public String getLineToDt() {
		return lineToDt;
	}
	
	public void setLineToDt(String lineToDt) {
		this.lineToDt = lineToDt;
	}
	
	//claimFromDt
	public String getClaimFromDt() {
		return claimFromDt;
	}
	
	public void setClaimFromDt(String claimFromDt) {
		this.claimFromDt = claimFromDt;
	}
	
	//claimToDt
	public String getClaimToDt() {
		return claimToDt;
	}
	
	public void setClaimToDt(String claimToDt) {
		this.claimToDt = claimToDt;
	}
	
	//claimToReview
	public String getClaimToReview() {
		return claimToReview;
	}
	
	public void setClaimToReview(String claimToReview) {
		this.claimToReview = claimToReview;
	}
	
	//unitsService
	public String getUnitsService() {
		return unitsService;
	}
	
	public void setUnitsService(String unitsService) {
		this.unitsService = unitsService;
	}
	
	//lineProviderPaidAmt
	public String getLineProviderPaidAmt() {
		return lineProviderPaidAmt;
	}
	
	public void setLineProviderPaidAmt(String lineProviderPaidAmt) {
		this.lineProviderPaidAmt = lineProviderPaidAmt;
	}
	
	//claimSubmittedAmt
	public String getClaimSubmittedAmt() {
		return claimSubmittedAmt;
	}
	
	public void setClaimSubmittedAmt(String claimSubmittedAmt) {
		this.claimSubmittedAmt = claimSubmittedAmt;
	}
	
	//claimAllowedAmt
	public String getClaimAllowedAmt() {
		return claimAllowedAmt;
	}
	
	public void setClaimAllowedAmt(String claimAllowedAmt) {
		this.claimAllowedAmt = claimAllowedAmt;
	}
	
	//claimProviderPaidAmt
	public String getClaimProviderPaidAmt() {
		return claimProviderPaidAmt;
	}
	
	public void setClaimProviderPaidAmt(String claimProviderPaidAmt) {
		this.claimProviderPaidAmt = claimProviderPaidAmt;
	}
	
	//crossoverInd
	public String getCrossoverInd() {
		return crossoverInd;
	}
	
	public void setCrossoverInd(String crossoverInd) {
		this.crossoverInd = crossoverInd;
	}
	
	//referNpi
	public String getReferNpi() {
		return referNpi;
	}
	
	public void setReferNpi(String referNpi) {
		this.referNpi = referNpi;
	}
	
	//referPtan
	public String getReferPtan() {
		return referPtan;
	}
	
	public void setReferPtan(String referPtan) {
		this.referPtan = referPtan;
	}
	
	//referNpiName
	public String getReferNpiName() {
		return referNpiName;
	}
	
	public void setReferNpiName(String referNpiName) {
		this.referNpiName = referNpiName;
	}
	
	//billNpi
	public String getBillNpi() {
		return billNpi;
	}
	
	public void setBillNpi(String billNpi) {
		this.billNpi = billNpi;
	}
	
	//billPtan
	public String getBillPtan() {
		return billPtan;
	}
	
	public void setBillPtan(String billPtan) {
		this.billPtan = billPtan;
	}
	
	//billPrvdrName
	public String getBillPrvdrName() {
		return billPrvdrName;
	}
	
	public void setBillPrvdrName(String billPrvdrName) {
		this.billPrvdrName = billPrvdrName;
	}
	
	//lineSubmittedAmt
	public String getLineSubmittedAmt() {
		return lineSubmittedAmt;
	}
	
	public void setLineSubmittedAmt(String lineSubmittedAmt) {
		this.lineSubmittedAmt = lineSubmittedAmt;
	}
	
	//lineAllowedAmt
	public String getLineAllowedAmt() {
		return lineAllowedAmt;
	}
	
	public void setLineAllowedAmt(String lineAllowedAmt) {
		this.lineAllowedAmt = lineAllowedAmt;
	}
	
	//attendNpi
	public String getAttendNpi() {
		return attendNpi;
	}
	
	public void setAttendNpi(String attendNpi) {
		this.attendNpi = attendNpi;
	}
	
	//attendSpecialty
	public String getAttendSpecialty() {
		return attendSpecialty;
	}
	
	public void setAttendSpecialty(String attendSpecialty) {
		this.attendSpecialty = attendSpecialty;
	}
	
	//beneStateCd
	public String getBeneStateCd() {
		return beneStateCd;
	}
	
	public void setBeneStateCd(String beneStateCd) {
		this.beneStateCd = beneStateCd;
	}
	
	//beneZip
	public String getBeneZip() {
		return beneZip;
	}
	
	public void setBeneZip(String beneZip) {
		this.beneZip = beneZip;
	}
	
	//alertAttributeName
	public String getAlertAttributeName() {
		return alertAttributeName;
	}
	
	public void setAlertAttributeName(String alertAttributeName) {
		this.alertAttributeName = alertAttributeName;
	}
	
	//referNpiSpecialty
	public String getReferNpiSpecialty() {
		return referNpiSpecialty;
	}
	
	public void setReferNpiSpecialty(String referNpiSpecialty) {
		this.referNpiSpecialty = referNpiSpecialty;
	}
	
	//beneAddress
	public String getBeneAddress() {
		return beneAddress;
	}
	
	public void setBeneAddress(String beneAddress) {
		this.beneAddress = beneAddress;
	}
	
	//attendPtan 	
	public String getAttendPtan() {
		return attendPtan;
	}
	
	public void setAttendPtan(String attendPtan) {
		this.attendPtan = attendPtan;
	}
	
	//diagnosis 	
	public String getDiagnosis() {
		return diagnosis;
	}
	
	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}
		
	//billType	
	public String getBillType() {
		return billType;
	}
	
	public void setBillType(String billType) {
		this.billType = billType;
	}
	
	//revenueCode	
	public String getRevenueCode() {
		return revenueCode;
	}
	
	public void setRevenueCode(String revenueCode) {
		this.revenueCode = revenueCode;
	}
		
	//tinEinOnClaim	
	public String getTinEinOnClaim() {
		return tinEinOnClaim;
	}
	
	public void setTinEinOnClaim(String tinEinOnClaim) {
		this.tinEinOnClaim = tinEinOnClaim;
	}
	
	//providerName	
	public String getProviderName() {
		return providerName;
	}
	
	public void setproviderName(String providerName) {
		this.providerName = providerName;
	}
	
	//benePhone
	public String getBenePhone() {
		return benePhone;
	}
	
	public void setBenePhone(String benePhone) {
		this.benePhone = benePhone;
	}
	
	//mbi
	public String getMbi() {
		return mbi;
	}
	
	public void setMbi(String mbi) {
		this.mbi = mbi;
	}
	
	//claimId
	public String getClaimId() {
		return claimId;
	}
	
	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}
	
	//alertClaimId
	public String getAlertClaimId() {
		return alertClaimId;
	}
	
	public void setAlertClaimId(String alertClaimId) {
		this.alertClaimId = alertClaimId;
	}
	
	//modelString
	public String getModelString() {
		return modelString;
	}
	
	public void setModelString(String modelString) {
		this.modelString = modelString;
	}
	
	//diagnosis1
	public String getDiagnosis1() {
		return diagnosis1;
	}
	
	public void setDiagnosis1(String diagnosis1) {
		this.diagnosis1 = diagnosis1;
	}
	
	//diagnosis2
	public String getDiagnosis2() {
		return diagnosis2;
	}
	
	public void setDiagnosis2(String diagnosis2) {
		this.diagnosis2 = diagnosis2;
	}
	
	//pos
	public String getPos() {
		return pos;
	}
	
	public void setPos(String pos) {
		this.pos = pos;
	}
	
	//admitDt
	public String getAdmitDt() {
		return admitDt;
	}
	
	public void setAdmitDt(String admitDt) {
		this.admitDt = admitDt;
	}
	
	//dischargeDt
	public String getDischargeDt() {
		return dischargeDt;
	}
	
	public void setDischargeDt(String dischargeDt) {
		this.dischargeDt = dischargeDt;
	}
	
	//paymentAmt
	public String getPaymentAmt() {
		return paymentAmt;
	}
	
	public void setPaymentAmt(String paymentAmt) {
		this.paymentAmt = paymentAmt;
	}
	
	//unitsAlwd
	public String getUnitsAlwd() {
		return unitsAlwd;
	}
	
	public void setUnitsAlwd(String unitsAlwd) {
		this.unitsAlwd = unitsAlwd;
	}
	
	//drg
	public String getDrg() {
		return drg;
	}
	
	public void setDrg(String drg) {
		this.drg = drg;
	}
	
	//lineDiagnosis
	public String getLineDiagnosis() {
		return lineDiagnosis;
	}
	
	public void setLineDiagnosis(String lineDiagnosis) {
		this.lineDiagnosis = lineDiagnosis;
	}
	
	//hcpcsCd
	public String getHcpcsCd() {
		return hcpcsCd;
	}
	
	public void setHcpcsCd(String hcpcsCd) {
		this.hcpcsCd = hcpcsCd;
	}
}
