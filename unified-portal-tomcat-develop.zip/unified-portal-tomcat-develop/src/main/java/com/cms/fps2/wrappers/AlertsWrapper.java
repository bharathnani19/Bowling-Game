package com.cms.fps2.wrappers;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.refdata.Models;
import com.cms.fps2.wrappers.refdata.PrioritizationTypes;
import com.cms.fps2.wrappers.refdata.Rulings;
import com.cms.fps2.wrappers.refdata.Specialties;
import com.cms.fps2.wrappers.refdata.States;
import com.cms.fps2.wrappers.refdata.ZoneNoMacs;
import com.cms.fps2.wrappers.refdata.Actions;
import com.cms.fps2.wrappers.refdata.Activities;
import com.cms.fps2.wrappers.refdata.Barriers;
import com.cms.fps2.wrappers.refdata.CityStates;
import com.cms.fps2.wrappers.refdata.Edits;
import com.cms.fps2.wrappers.refdata.Enrollments;
import com.cms.fps2.wrappers.refdata.Exclusions;
import com.cms.fps2.wrappers.refdata.ExclusionsMdcd;
import com.cms.fps2.wrappers.summary.Alerts;
import com.cms.fps2.wrappers.summary.ExclusionCategories;
import com.cms.fps2.wrappers.summary.Users;
import com.cms.fps2.wrappers.summary.Zones;
import com.cms.fps2.wrappers.summary.Categories;

public class AlertsWrapper {
	private List<Alerts> alerts = new ArrayList<Alerts>();
	private List<Models> models = new ArrayList<Models>();
	private List<Models> p1Models = new ArrayList<Models>();
	private List<Users> users = new ArrayList<Users>();
	private List<Zones> zones = new ArrayList<Zones>();
	private List<Actions> actions = new ArrayList<Actions>();
	private List<Activities> activities = new ArrayList<Activities>();
	private List<States> states = new ArrayList<States>();
	private List<Rulings> rulings = new ArrayList<Rulings>();
	private List<Barriers> barriers = new ArrayList<Barriers>();
	private List<CityStates> cityStates = new ArrayList<CityStates>();
	private List<ZoneNoMacs> zoneNoMacs =  new ArrayList<ZoneNoMacs>();
	private List<PrioritizationTypes> prioritizationTypes = new ArrayList<PrioritizationTypes>();
	private List<Edits> edits = new ArrayList<Edits>();
	private List<Exclusions> exclusions = new ArrayList<Exclusions>();
	private List<ExclusionsMdcd> exclusionsMdcd = new ArrayList<ExclusionsMdcd>();
	private List<Enrollments> enrollments =  new ArrayList<Enrollments>();
	private List<ExclusionCategories> exclusionCategories =  new ArrayList<ExclusionCategories>();
	private List<Specialties> specialties = new ArrayList<Specialties>();
	// Medicaid models
	private List<Models> mdcdModels = new ArrayList<Models>();
	private List<Categories> mdcdSvcCats = new ArrayList<Categories>();
	private List<Categories> mdcdSvcSubCats = new ArrayList<Categories>();
	private List<Categories> mdcdSpecialties = new ArrayList<Categories>();
	private List<Categories> mdcdRoles = new ArrayList<Categories>();
	private List<Categories> mdcdSvcTypes = new ArrayList<Categories>();

	private String p1EnabledInd;

	

	
	//constructor
	public AlertsWrapper (){}
	
	//alerts
	public List<Alerts> getAlerts() {
		return alerts;
	}
	
	public void setAlerts(List<Alerts> alerts) {
		this.alerts = alerts;
	}
	
	//models
	public List<Models> getModels() {
		return models;
	}
	
	public void setModels(List<Models> models) {
		this.models = models;
	}

	//p1models
	public List<Models> getP1Models() {
		return p1Models;
	}
	
	public void setP1Models(List<Models> p1Models) {
		this.p1Models = p1Models;
	}
	
	//users
	public List<Users> getUsers() {
		return users;
	}
	
	public void setUsers(List<Users> users) {
		this.users = users;
	}
	
	//zones
	public List<Zones> getZones() {
		return zones;
	}
	
	public void setZones(List<Zones> zones) {
		this.zones = zones;
	}
	
	//actions
	public List<Actions> getActions() {
		return actions;
	}
	
	public void setActions(List<Actions> actions) {
		this.actions = actions;
	}
	
	//activities 	
	public List<Activities> getActivities() {
		return activities;
	}
	
	public void setActivities(List<Activities> activities) {
		this.activities = activities;
	}
	
	//states
	public List<States> getStates() {
		return states;
	}
	
	public void setStates(List<States> states) {
		this.states = states;
	}
	
	//Rulings
	public List<Rulings> getRulings() {
		return rulings;
	}
	
	public void setRulings(List<Rulings> rulings) {
		this.rulings = rulings;
	}
	//Barriers
	public List<Barriers> getBarriers() {
		return barriers;
	}
	
	public void setBarriers(List<Barriers> barriers) {
		this.barriers = barriers;
	}
	//cityStates
	public List<CityStates> getCityStates() {
		return cityStates;
	}
	
	public void setCityStates(List<CityStates> cityStates) {
		this.cityStates = cityStates;
	}
	
	// zoneNoMacs
	public List<ZoneNoMacs> getZoneNoMacs() {
		return zoneNoMacs;
	}
	
	public void setZoneNoMacs(List<ZoneNoMacs> zoneNoMacs) {
		this.zoneNoMacs = zoneNoMacs;
	}
	
	// prioritizationTypes
	public List<PrioritizationTypes> getPrioritizationTypes() {
		return prioritizationTypes;
	}
	
	public void setPrioritizationTypes(List<PrioritizationTypes> prioritizationTypes) {
		this.prioritizationTypes = prioritizationTypes;
	}
	
	// edits
	public List<Edits> getEdits() {
		return edits;
	}
	
	public void setEdits(List<Edits> edits) {
		this.edits = edits;
	}
	
	// exclusions
	public List<Exclusions> getExclusions() {
		return exclusions;
	}
	
	public void setExclusions(List<Exclusions> exclusions) {
		this.exclusions = exclusions;
	}

	// exclusionsMdcd
	public List<ExclusionsMdcd> getExclusionsMdcd() {
		return exclusionsMdcd;
	}
	
	public void setExclusionsMdcd(List<ExclusionsMdcd> exclusionsMdcd) {
		this.exclusionsMdcd = exclusionsMdcd;
	}
	
	// enrollments
	public List<Enrollments> getEnrollments() {
		return enrollments;
	}
	
	public void setEnrollments(List<Enrollments> enrollments) {
		this.enrollments = enrollments;
	}
	
	// exclusionCategories
	public List<ExclusionCategories> getExclusionCategories() {
		return exclusionCategories;
	}
	
	public void setExclusionCategories(List<ExclusionCategories> exclusionCategories) {
		this.exclusionCategories = exclusionCategories;
	}
	
	// specialties
	public List<Specialties> getSpecialties() {
		return specialties;
	}
	
	public void setSpecialties(List<Specialties> specialties) {
		this.specialties = specialties;
	}

	// mdcdModels
	
	public List<Models> getMdcdModels() {
		return mdcdModels;
	}

	// mdcdSvcCats
	
	public List<Categories> getMdcdSvcCats() {
		return mdcdSvcCats;
	}

	// mdcdSvcSubCats
	
	public List<Categories> getMdcdSvcSubCats() {
		return mdcdSvcSubCats;
	}

	// mdcdSpecialties
	
	public List<Categories> getMdcdSpecialties() {
		return mdcdSpecialties;
	}

	// mdcdRoles
	
	public List<Categories> getMdcdRoles() {
		return mdcdRoles;
	}

	/**
	 * @param mdcdModels the mdcdModels to set
	 */
	public void setMdcdModels(List<Models> mdcdModels) {
		this.mdcdModels = mdcdModels;
	}

	/**
	 * @param mdcdSvcCats the mdcdSvcCats to set
	 */
	public void setMdcdSvcCats(List<Categories> mdcdSvcCats) {
		this.mdcdSvcCats = mdcdSvcCats;
	}

	/**
	 * @param mdcdSvcSubCats the mdcdSvcSubCats to set
	 */
	public void setMdcdSvcSubCats(List<Categories> mdcdSvcSubCats) {
		this.mdcdSvcSubCats = mdcdSvcSubCats;
	}

	/**
	 * @param mdcdSpecialties the mdcdSpecialties to set
	 */
	public void setMdcdSpecialties(List<Categories> mdcdSpecialties) {
		this.mdcdSpecialties = mdcdSpecialties;
	}

	/**
	 * @param mdcdRoles the mdcdRoles to set
	 */
	public void setMdcdRoles(List<Categories> mdcdRoles) {
		this.mdcdRoles = mdcdRoles;
	}

	// mdcdSvcTypes
	
	public List<Categories> getMdcdSvcTypes() {
		return mdcdSvcTypes;
	}

	// mdcdSvcTypes
	
	public void setMdcdSvcTypes(List<Categories> mdcdSvcTypes) {
		this.mdcdSvcTypes = mdcdSvcTypes;
	}
	
	public String getp1EnabledInd() {
		return p1EnabledInd;
	}
	
	public void setp1EnabledInd(String p1EnabledInd) {
		this.p1EnabledInd = p1EnabledInd;
	}
	
}
