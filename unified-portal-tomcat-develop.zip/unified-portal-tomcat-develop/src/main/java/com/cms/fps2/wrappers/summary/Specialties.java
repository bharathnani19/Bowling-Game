package com.cms.fps2.wrappers.summary;

public class Specialties {
	
	private String specialtyTypeCd;
	private String specialtyTypeDesc;
	
	//constructor
	public Specialties(){}
	
	//specialtyTypeCd	
	public String getSpecialtyTypeCd() {
		return specialtyTypeCd;
	}
	
	public void setSpecialtyTypeCd(String specialtyTypeCd) {
		this.specialtyTypeCd = specialtyTypeCd;
	}
	
	//specialtyTypeDesc	
	public String getSpecialtyTypeDesc() {
		return specialtyTypeDesc;
	}
	
	public void setSpecialtyTypeDesc(String specialtyTypeDesc) {
		this.specialtyTypeDesc = specialtyTypeDesc;
	}
}
