package com.cms.fps2.wrappers.tracking;

public class UserTrackingReqWrapper {
	private String userId;
	private String pageId;
	private String trackingVal;
	
	//constructor
	public UserTrackingReqWrapper(){}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//pageId
	public String getPageId() {
		return pageId;
	}
	
	public void setPageId(String pageId) {
		this.pageId = pageId;
	}
	
	// trackingVal
	public String getTrackingVal() {
		return trackingVal;
	}
	
	public void setTrackingVal(String trackingVal) {
		this.trackingVal = trackingVal;
	}
	
}
