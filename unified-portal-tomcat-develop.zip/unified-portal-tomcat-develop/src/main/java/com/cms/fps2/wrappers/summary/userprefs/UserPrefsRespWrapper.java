package com.cms.fps2.wrappers.summary.userprefs;

public class UserPrefsRespWrapper {
	private String userId;
	private String prefName;
	private String prefJson;
	
	
	//constructor
	public UserPrefsRespWrapper(){}
	
	//userId 	
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//prefName
	public String getPrefName() {
		return prefName;
	}
	
	public void setPrefName(String prefName) {
		this.prefName = prefName;
	}
	
	//prefJson
	public String getPrefJson() {
		return prefJson;
	}
	
	public void setPrefJson(String prefJson) {
		this.prefJson = prefJson;
	}
}
