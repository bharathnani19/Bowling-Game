package com.cms.fps2.wrappers.details.tab.prioritize;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.ucm.Priorities;

public class ResponseData {
	//use the Priorities Object from the ASR Details general details response
	private List<Priorities> priorities = new ArrayList<Priorities>();
	private String prioritized;
	private String recentAlerts;
	private String recentEdits;
	private String recentInv;
	private String hasEdits;
	private String hasInv;
	private String hasSysTags;
	private String hasNotes;
	private String hasPartD;
	
	//constructor
	public ResponseData(){}
	
	//priorities
	public List<Priorities> getPriorities() {
		return priorities;
	}
	
	public void setPriorities(List<Priorities> priorities) {
		this.priorities = priorities;
	}
	
	//prioritized - this field is not used by the prioritzed tab
	public String getPrioritized() {
		return prioritized;
	}
	
	public void setPrioritized(String prioritized) {
		this.prioritized = prioritized;
	}
	
	//recentAlerts
	public String getRecentAlerts() {
		
		return recentAlerts;
	}
	
	public void setRecentAlerts(String recentAlerts) {
		this.recentAlerts = recentAlerts;
	}
	
	//recentEdits
	public String getRecentEdits() {
		
		return recentEdits;
	}
	
	public void setRecentEdits(String recentEdits) {
		this.recentEdits = recentEdits;
	}
	
	//recentInv
	public String getRecentInv() {
		
		return recentInv;
	}
	
	public void setRecentInv(String recentInv) {
		this.recentInv = recentInv;
	}
	
	//hasEdits
	public String getHasEdits() {		
		return hasEdits;
	}
	
	public void setHasEdits(String hasEdits) {
		this.hasEdits = hasEdits;
	}
	
	//hasInv
	public String getHasInv() {		
		return hasInv;
	}
	
	public void setHasInv(String hasInv) {
		this.hasInv = hasInv;
	}
	
	//hasSysTags
	public String getHasSysTags() {		
		return hasSysTags;
	}
	
	public void setHasSysTags(String hasSysTags) {
		this.hasSysTags = hasSysTags;
	}
	
	//hasNotes
	public String getHasNotes() {		
		return hasNotes;
	}
	
	public void setHasNotes(String hasNotes) {
		this.hasNotes = hasNotes;
	}
	
	//hasPartD
	public String getHasPartD() {		
		return hasPartD;
	}
	
	public void setHasPartD(String hasPartD) {
		this.hasPartD = hasPartD;
	}
}
