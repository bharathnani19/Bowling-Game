package com.cms.fps2.wrappers.summary.workitems;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.summary.ResponseData;

public class FpsPrioritizationListItem {
	
	private String prioritizationListItemId;	
	private String prioritizationListId;
	private String asrptId;
	private String prioritizedInd;
	private String prioritizedByUserId;
	private String prioritizedTs;
	private String actvInd;
	private String actvIndUserId;
	private String actvIndTs;
	private List<ResponseData> fpsPrvdrAnlys = new ArrayList<ResponseData>();
	private String audtInsrtId;
	private String audtInsrtTs;
	private String audtUpdtId;
	private String audtUpdtTs;
	
	// constructor
	public FpsPrioritizationListItem() {}
	
	// prioritizationListItemId
	public String getPrioritizationListItemId() {
		return prioritizationListItemId;
	}
	
	public void setPrioritizationListItemId(String prioritizationListItemId) {
		this.prioritizationListItemId = prioritizationListItemId;
	}
	
	// prioritizationListId
	public String getPrioritizationListId() {
		return prioritizationListId;
	}
	
	public void setPrioritizationListId(String prioritizationListId) {
		this.prioritizationListId = prioritizationListId;
	}
	
	// asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	// prioritizedInd
	public String getPrioritizedInd() {
		return prioritizedInd;
	}
	
	public void setPrioritizedInd(String prioritizedInd) {
		this.prioritizedInd = prioritizedInd;
	}
	
	// prioritizedByUserId
	public String getPrioritizedByUserId() {
		return prioritizedByUserId;
	}
	
	public void setPrioritizedByUserId(String prioritizedByUserId) {
		this.prioritizedByUserId = prioritizedByUserId;
	}
	
	// prioritizedTs
	public String getPrioritizedTs() {
		return prioritizedTs;
	}
	
	public void setPrioritizedTs(String prioritizedTs) {
		this.prioritizedTs = prioritizedTs;
	}
	
	// actvInd
	public String getActvInd() {
		return actvInd;
	}
	
	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}
	
	// actvIndUserId
	public String getActvIndUserId() {
		return actvIndUserId;
	}
	
	public void setActvIndUserId(String actvIndUserId) {
		this.actvIndUserId = actvIndUserId;
	}
	
	// actvIndTs
	public String getActvIndTs() {
		return actvIndTs;
	}
	
	public void setActvIndTs(String actvIndTs) {
		this.actvIndTs = actvIndTs;
	}
	
	// fpsPrvdrAnlys
	public List<ResponseData> getFpsPrvdrAnlys() {
		return fpsPrvdrAnlys;
	}
	
	public void setResponseData(List<ResponseData> fpsPrvdrAnlys) {
		this.fpsPrvdrAnlys = fpsPrvdrAnlys;
	}
	
	// audtInsrtId
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	
	// audtInsrtTs
	public String getAudtInsrtTs() {
		return audtInsrtTs;
	}
	
	public void setAudtInsrtTs(String audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	
	// audtUpdtId
	public String getAudtUpdtId() {
		return audtUpdtId;
	}
	
	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	
	// audtUpdtTs
	public String getAudtUpdtTs() {
		return audtUpdtTs;
	}
	
	public void setAudtUpdtTs(String audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
	
}
