package com.cms.fps2.wrappers.details;

public class ContribScores {
	private String modelNm;
	private String modelRiskScore;
	private String contribScorePct;
	private String modelId;
	private String  modelTypeCd;
	
	public String getModelNm() {
		return modelNm;
	}
	public void setModelNm(String modelNm) {
		this.modelNm = modelNm;
	}
	public String getModelRiskScore() {
		return modelRiskScore;
	}
	public void setModelRiskScore(String modelRiskScore) {
		this.modelRiskScore = modelRiskScore;
	}
	public String getContribScorePct() {
		return contribScorePct;
	}
	public void setContribScorePct(String contribScorePct) {
		this.contribScorePct = contribScorePct;
	}
	/**
	 * @return the modelId
	 */
	public String getModelId() {
		return modelId;
	}
	/**
	 * @param modelId the modelId to set
	 */
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	/**
	 * @return the modelTypeCd
	 */
	public String getModelTypeCd() {
		return modelTypeCd;
	}
	/**
	 * @param modelTypeCd the modelTypeCd to set
	 */
	public void setModelTypeCd(String modelTypeCd) {
		this.modelTypeCd = modelTypeCd;
	}
	
	

}
