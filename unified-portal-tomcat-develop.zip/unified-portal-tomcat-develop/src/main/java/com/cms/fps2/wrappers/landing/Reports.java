package com.cms.fps2.wrappers.landing;

public class Reports {
	
	private String projectNm;
	private String workbookNm;
	private String rptUrl;
	private String workbookDesc;
	private String rptId;
	private String rptNm;
	private String checked;
	private String rptDesc;
	
	//constructor
	public Reports() {}
	
	//projectNm
	public String getProjectNm() {
		return projectNm;
	}
	
	public void setProjectNm(String projectNm) {
		this.projectNm = projectNm;
	}
	
	//workbookNm
	public String getWorkbookNm() {
		return workbookNm;
	}
	
	public void setWorkbookNm(String workbookNm) {
		this.workbookNm = workbookNm;
	}
	
	//rptUrl
	public String getRptUrl() {
		return rptUrl;
	}
	
	public void setRptUrl(String rptUrl) {
		this.rptUrl = rptUrl;
	}
	
	//workbookDesc
	public String getWorkbookDesc() {
		return workbookDesc;
	}
	
	public void setWorkbookDesc(String workbookDesc) {
		this.workbookDesc = workbookDesc;
	}
	
	//rptId
	public String getRptId() {
		return rptId;
	}
	
	public void setRptId(String rptId) {
		this.rptId = rptId;
	}
	
	//rptNm
	public String getRptNm() {
		return rptNm;
	}
	
	public void setRptNm(String rptNm) {
		this.rptNm = rptNm;
	}
	
	//checked
	public String getChecked() {
		return checked;
	}
	
	public void setChecked(String checked) {
		this.checked = checked;
	}
	
	//rptDesc
	public String getRptDesc() {
		return rptDesc;
	}
	
	public void setRptDesc(String rptDesc) {
		this.rptDesc = rptDesc;
	}
	
}