package com.cms.fps2.wrappers.summary;

public class CurrentAlerts {
	private String alertTypeCd;
	private String alertId;
	private String riskScore;
	private String alertStatusCd;
	
	//constructor
	public CurrentAlerts(){}
	
	//alertTypeCd
	public String getAlertTypeCd() {
		return alertTypeCd;
	}
	
	public void setAlertTypeCd(String alertTypeCd) {
		this.alertTypeCd = alertTypeCd;
	}
	
	//alertId
	public String getAlertId() {
		return alertId;
	}
	
	public void setAlertId(String alertId) {
		this.alertId = alertId;
	}
	
	//riskScore
	public String getRiskScore() {
		return riskScore;
	}
	
	public void setRiskScore(String riskScore) {
		this.riskScore = riskScore;
	}
	
	//alertStatusCd
	public String getAlertStatusCd() {
		return alertStatusCd;
	}
	
	public void setAlertStatusCd(String alertStatusCd) {
		this.alertStatusCd = alertStatusCd;
	}
}
