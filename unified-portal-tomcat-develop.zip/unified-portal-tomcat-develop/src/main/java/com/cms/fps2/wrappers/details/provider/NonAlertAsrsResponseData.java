package com.cms.fps2.wrappers.details.provider;

import java.util.ArrayList;
import java.util.List;

public class NonAlertAsrsResponseData {
	
	private String prioritized;
	private List<NapParents> napParents = new ArrayList<NapParents>();
	
	// constructor
	public NonAlertAsrsResponseData() {}
	
	// prioritized
	public String getPrioritized() {
		return prioritized;
	}
	
	public void setPrioritized(String prioritized) {
		this.prioritized = prioritized;
	}
	
	// napParents
	public List<NapParents> getNapParents() {
		return napParents;
	}
	
	public void setNapParents(List<NapParents> napParents) {
		this.napParents = napParents;
	}

}
