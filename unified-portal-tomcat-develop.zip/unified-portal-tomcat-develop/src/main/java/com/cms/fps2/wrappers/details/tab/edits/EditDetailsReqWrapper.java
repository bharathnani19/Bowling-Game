package com.cms.fps2.wrappers.details.tab.edits;

public class EditDetailsReqWrapper {
	
	private String editName;	
	private String userId;
	
	// constructor
	public EditDetailsReqWrapper() {}
	
	// editName
	public String getEditName() {
		return editName;
	}
	
	public void setEditName(String editName) {
		this.editName = editName;
	}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
 