package com.cms.fps2.wrappers.details.tab.edits;

public class EditInfoReqWrapper {
	
	private String userId;
	
	//constructor
	public EditInfoReqWrapper() {}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
