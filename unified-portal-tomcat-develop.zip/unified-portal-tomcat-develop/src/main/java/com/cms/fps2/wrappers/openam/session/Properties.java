package com.cms.fps2.wrappers.openam.session;

public class Properties {
	//constructor
	public Properties(){}
}
