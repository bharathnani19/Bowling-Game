package com.cms.fps2.wrappers.details;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.details.provider.DualBenes;
import com.cms.fps2.wrappers.details.provider.Ptans;
import com.cms.fps2.wrappers.details.provider.SysTags;
import com.cms.fps2.wrappers.details.provider.TopProcCodes;
import com.cms.fps2.wrappers.summary.EnrollmentId;
import com.cms.fps2.wrappers.summary.modals.MedicaidInfo;
import com.cms.fps2.wrappers.summary.modals.PriorityCriteria;

public class Provider {
	private String npi;
	private String providerName;
	private String riskScoreNum;
	private String totalCost;
	private String uniqueAlertsCnt;
	private String createdDt;
	private String updateDt;
	private String assignedTo;
	private String specialtiesCnt;
	private List<Specialties> specialties = new ArrayList<Specialties>();
	private String benesCnt;
	private List<Benes> benes = new ArrayList<Benes>();
	private String proceduresCnt; 
	private List<Procedures> procedures = new ArrayList<Procedures>();
	private String asrProviderCnt;	
	private List<AsrProviders> asrProviders  = new ArrayList<AsrProviders>();
	private String submitterIdCnt;
	private List<SubmitterIds> submitterIds = new ArrayList<SubmitterIds>();
	private String subjectStateCd;
	private String jurisdiction;
	private List<SubjectRoleCd> subjectRoleCd = new ArrayList<SubjectRoleCd>();
	private String fidNumberCnt;
	private List<FidNumbers> fidNumbers = new ArrayList<FidNumbers>();
	private List<UcmCaseData> ucmCaseData = new ArrayList<UcmCaseData>();
	private String ucmCaseDataCnt;
	private String biu4WeekCnt;
	private String biu1YearCnt;
	private String inWorkload;
	private String inWorkloadDt;
	private SysTags sysTags;
	private List<BarrierToAction> barrierToAction = new ArrayList<BarrierToAction>();
	private List<Alerts> alerts = new ArrayList<Alerts>();
	private Address address;
	private String crossoverLinesCnt;
	private String prvdrStateCd;
	private List<Ptans> ptans = new ArrayList<Ptans>();
	private String mac;
	private String priorityScoreNum;
	private List<PriorityCriteria> priorityCriteria = new ArrayList<PriorityCriteria>();
	private String prevPriorityScoreNum;
	private String priorityScoreDelta;
	private String riskScore90;
	private String riskScore180;
	private String riskScore365;
	private String zrType;
	private List<DualBenes> dualBenes = new ArrayList<DualBenes>();
	private List<TopProcCodes> topProcCds = new ArrayList<TopProcCodes>();
	private String revocation;
	private String medicaid;
	private String ucmAsrId;
	private List<TopHcpcsCds> topHcpcsCds = new ArrayList<TopHcpcsCds>();
	private String showEduReport;
	private String revocationDate;
	private String revocationDesc;
	private List<EnrollmentId> enrollmentIds = new ArrayList<EnrollmentId>();
	private String enrollmentId;
	private String showMacEduReport;
	private String showUpicEduReport;
	private String hasHhaNv;
	private String actionability;
	private String timeliness;
	private String hasAps;
	private List<ApsRecs> apsRecs = new ArrayList<ApsRecs>();
	private String showChowReport;
	private String hasPartD;
	private String hasRrb;
	private String postEdInd;
	private String tpes;
	private String totalPmt;
	private String relatedAsrCnt;
	private String hasDmeNv;
	private String nonAlertedPrvdrInd;
	private String uniqueAlertsNA;
	private String specialtiesNA;
	private String ptansNA;
	private String crossoverNA;
	private String rolesNA;
	private String riskScoreMethod;
	private List<MdcdEnrollmentIds> mdcdEnrollmentIds  = new ArrayList<MdcdEnrollmentIds>();
	private MedicaidInfo medicaidInfo;
	private String acoInd;
	private String minRiskScoreInd;
    private String minRiskScoreModelTxt;
	private String p1TotalCost;
	private String p1Jurisdiction;
	private String p1RiskScore;
    	
	
	private List<ContribScores> contribScores = new ArrayList<ContribScores>();
	
	//contribScores
	public List<ContribScores> getContribScores() {
		return contribScores;
	}
	//	contribScores
	public void setContribScores(List<ContribScores> contribScores) {
		this.contribScores = contribScores;
	}
	
	//constructor
	public Provider(){}
	
	//npi 	
	public String getNpi() {
		return npi;
	}
	
	public void setNpi(String npi) {
		this.npi = npi;
	}
	
	//providerName 	
	public String getProviderName() {
		return providerName;
	}
	
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}	

	//riskScoreNum 	
	public String getRiskScoreNum() {
		return riskScoreNum;
	}
	
	public void setRiskScoreNum(String riskScoreNum) {
		this.riskScoreNum = riskScoreNum;
	}
	
	//totalCost 	
	public String getTotalCost() {
		return totalCost;
	}
	
	public void setTotalCost(String totalCost) {
		this.totalCost = totalCost;
	}
	
	//uniqueAlertsCnt 	
	public String getUniqueAlertsCnt() {
		return uniqueAlertsCnt;
	}
	
	public void setUniqueAlertsCnt(String uniqueAlertsCnt) {
		this.uniqueAlertsCnt = uniqueAlertsCnt;
	}
	
	//createdDt 	
	public String getCreatedDt() {
		return createdDt;
	}
	
	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}
	
	//updateDt 	
	public String getUpdateDt() {
		return updateDt;
	}
	
	public void setUpdateDt(String updateDt) {
		this.updateDt = updateDt;
	}
	
	//assignedTo 	
	public String getAssignedTo() {
		return assignedTo;
	}
	
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	
	//specialtiesCnt 	
	public String getSpecialtiesCnt() {
		return specialtiesCnt;
	}
	
	public void setSpecialtiesCnt(String specialtiesCnt) {
		this.specialtiesCnt = specialtiesCnt;
	}
	
	//specialties
	public List<Specialties> getSpecialties() {
		return specialties;
	}
	
	public void setSpecialties(List<Specialties> specialties) {
		this.specialties = specialties;
	}
	
	//benesCnt 	
	public String getBenesCnt() {
		return benesCnt;
	}
	
	public void setBenesCnt(String benesCnt) {
		this.benesCnt = benesCnt;
	}
	
	//benes 	
	public List<Benes> getBenes() {
		return benes;
	}
	
	public void setBenes(List<Benes> benes) {
		this.benes = benes;
	}
	
	//proceduresCnt 	
	public String getProceduresCnt() {
		return proceduresCnt;
	}
	
	public void setProceduresCnt(String proceduresCnt) {
		this.proceduresCnt = proceduresCnt;
	}
	
	//procedures
	public List<Procedures> getProcedures() {
		return procedures;
	}
	
	public void setProcedures(List<Procedures> procedures) {
		this.procedures = procedures;
	}
	
	//asrProviderCnt
	public String getAsrProviderCnt() {
		return asrProviderCnt;
	}
	
	public void setAsrProviderCnt(String asrProviderCnt) {
		this.asrProviderCnt = asrProviderCnt;
	}
	
	//asrProviders
	public List<AsrProviders> getAsrProviders() {
		return asrProviders;
	}
	
	public void setAsrProviders(List<AsrProviders> asrProviders) {
		this.asrProviders = asrProviders;
	}
	
	//submittedIdCnt 	
	public String getSubmitterIdCnt() {
		return submitterIdCnt;
	}
	
	public void setSubmitterIdCnt(String submitterIdCnt) {
		this.submitterIdCnt = submitterIdCnt;
	}
	
	//submitterIds 	
	public List<SubmitterIds> getSubmitterIds() {
		return submitterIds;
	}
	
	public void setSubmitterIds(List<SubmitterIds> submitterIds) {
		this.submitterIds = submitterIds;
	}
	
	//subjectStateCd 	
	public String getSubjectStateCd() {
		return subjectStateCd;
	}
	
	public void setSubjectStateCd(String subjectStateCd) {
		this.subjectStateCd = subjectStateCd;
	}
	
	//jurisdiction 	
	public String getJurisdiction() {
		return jurisdiction;
	}
	
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}
	
	//roles 	
	public List<SubjectRoleCd> getSubjectRoleCd() {
		return subjectRoleCd;
	}
	
	public void setSubjectRoleCd(List<SubjectRoleCd> subjectRoleCd) {
		this.subjectRoleCd = subjectRoleCd;
	}
	
	//fidNumberCnt 	
	public String getFidNumberCnt() {
		return fidNumberCnt;
	}
	
	public void setFidNumberCnt(String fidNumberCnt) {
		this.fidNumberCnt = fidNumberCnt;
	}
	
	//fidNumbers 	
	public List<FidNumbers> getFidNumbers() {
		return fidNumbers;
	}
	
	public void setFidNumbers(List<FidNumbers> fidNumbers) {
		this.fidNumbers = fidNumbers;
	}
	
	//ucmCaseData 	
	public List<UcmCaseData> getUcmCaseData() {
		return ucmCaseData;
	}
	
	public void setUcmCaseData(List<UcmCaseData> ucmCaseData) {
		this.ucmCaseData = ucmCaseData;
	}
	
	//ucmCaseDataCnt 	
	public String getUcmCaseDataCnt() {
		return ucmCaseDataCnt;
	}
	
	public void setUcmCaseDataCnt(String ucmCaseDataCnt) {
		this.ucmCaseDataCnt = ucmCaseDataCnt;
	}
	
	//biu4WeekCnt 	
	public String getBiu4WeekCnt() {
		return biu4WeekCnt;
	}
	
	public void setBiu4WeekCnt(String biu4WeekCnt) {
		this.biu4WeekCnt = biu4WeekCnt;
	}
	
	//biu1YearCnt 	
	public String getBiu1YearCnt() {
		return biu1YearCnt;
	}
	
	public void setBiu1YearCnt(String biu1YearCnt) {
		this.biu1YearCnt = biu1YearCnt;
	}
	
	//inWorkload 	
	public String getInWorkload() {
		return inWorkload;
	}
	
	public void setInWorkload(String inWorkload) {
		this.inWorkload = inWorkload;
	}
	
	//inWorkloadDt 	
	public String getInWorkloadDt() {
		return inWorkloadDt;
	}
	
	public void setInWorkloadDt(String inWorkloadDt) {
		this.inWorkloadDt = inWorkloadDt;
	}
	
	//barrierToAction 	
	public List<BarrierToAction> getBarrierToAction() {
		return barrierToAction;
	}
	
	public void setBarrierToAction( List<BarrierToAction> barrierToAction) {
		this.barrierToAction = barrierToAction;
	}
	
	//sysTags 	
	public SysTags getSysTags() {
		return sysTags;
	}
	
	public void setSysTags(SysTags sysTags) {
		this.sysTags = sysTags;
	}
	
	//alerts 	
	public List<Alerts> getAlerts() {
		return alerts;
	}
	
	public void setAlerts(List<Alerts> alerts) {
		this.alerts = alerts;
	}
	
	//address 	
	public Address getAddress() {
		return address;
	}
	
	public void setAddress(Address address) {
		this.address = address;
	}	
	
	//crossoverLinesCnt 	
	public String getCrossoverLinesCnt() {
		return crossoverLinesCnt;
	}
	
	public void setCrossoverLinesCnt(String crossoverLinesCnt) {
		this.crossoverLinesCnt = crossoverLinesCnt;
	}	
	
	//prvdrStateCd 	
	public String getPrvdrStateCd() {
		return prvdrStateCd;
	}
	
	public void setPrvdrStateCd(String prvdrStateCd) {
		this.prvdrStateCd = prvdrStateCd;
	}	
	
	//ptans
	public List<Ptans> getPtans() {
		return ptans;
	}
	
	public void setPtans(List<Ptans> ptans) {
		this.ptans = ptans;
	}
	
	//mac
	public String getMac() {
		return mac;
	}
	
	public void setMac(String mac) {
		this.mac = mac;
	}	
	
	//priorityScoreNum
	public String getPriorityScoreNum() {
		return priorityScoreNum;
	}
	
	public void setPriorityScoreNum(String priorityScoreNum) {
		this.priorityScoreNum = priorityScoreNum;
	}
	
	//priorityCriteria
	public  List<PriorityCriteria> getPriorityCriteria() {
		return priorityCriteria;
	}
	
	public void setPriorityCriteria( List<PriorityCriteria> priorityCriteria) {
		this.priorityCriteria = priorityCriteria;
	}
	
	//prevPriorityScoreNum
	public String getPrevPriorityScoreNum() {
		return prevPriorityScoreNum;
	}
	
	public void setPrevPriorityScoreNum(String prevPriorityScoreNum) {
		this.prevPriorityScoreNum = prevPriorityScoreNum;
	}
	
	//priorityScoreDelta
	public String getPriorityScoreDelta() {
		return priorityScoreDelta;
	}
	
	public void setPriorityScoreDelta(String priorityScoreDelta) {
		this.priorityScoreDelta = priorityScoreDelta;
	}
	
	//riskScore90
	public String getRiskScore90() {
		
		return riskScore90;
	}
	
	public void setRiskScore90(String riskScore90) {
		this.riskScore90 = riskScore90;
	}
	
	//riskScore180
	public String getRiskScore180() {
		
		return riskScore180;
	}
	
	public void setRiskScore180(String riskScore180) {
		this.riskScore180 = riskScore180;
	}
	
	//riskScore365
	public String getRiskScore365() {		
		return riskScore365;
	}
	
	public void setRiskScore365(String riskScore365) {
		this.riskScore365 = riskScore365;
	}
	
	//zrType
	public String getZrType() {		
		return zrType;
	}
	
	public void setZrType(String zrType) {
		this.zrType = zrType;
	}
	
	//dualBenes
	public List<DualBenes> getDualBenes() {
		return dualBenes;
	}
	
	public void setDualBenes(List<DualBenes> dualBenes) {
		this.dualBenes = dualBenes;
	}
	
	//topProcCds
	public List<TopProcCodes> getTopProcCds() {
		return topProcCds;
	}
	
	public void setTopProcCds(List<TopProcCodes> topProcCds) {
		this.topProcCds = topProcCds;
	}
	
	//revocation
	public String getRevocation() {
		return revocation;
	}
	
	public void setRevocation(String revocation) {
		this.revocation = revocation;
	}
	
	//medicaid
	public String getMedicaid() {
		return medicaid;
	}
	
	public void setMedicaid(String medicaid) {
		this.medicaid = medicaid;
	}
	
	//ucmAsrId
	public String getUcmAsrId() {
		return ucmAsrId;
	}
	
	public void setUcmAsrId(String ucmAsrId) {
		this.ucmAsrId = ucmAsrId;
	}
	
	//topHcpcsCds
	public List<TopHcpcsCds> getTopHcpcsCds() {
		return topHcpcsCds;
	}
	
	public void setTopHcpcsCds(List<TopHcpcsCds> topHcpcsCds) {
		this.topHcpcsCds = topHcpcsCds;
	}
	
	//showEduReport
	public String getShowEduReport() {
		return showEduReport;
	}
	
	public void setShowEduReport(String showEduReport) {
		this.showEduReport = showEduReport;
	}
	
	//revocationDate
	public String getRevocationDate() {
		return revocationDate;
	}
	
	public void setRevocationDate(String revocationDate) {
		this.revocationDate = revocationDate;
	}
	
	//revocationDesc
	public String getRevocationDesc() {
		return revocationDesc;
	}
	
	public void setRevocationDesc(String revocationDesc) {
		this.revocationDesc = revocationDesc;
	}
	
	//enrollmentIds
	public List<EnrollmentId> getEnrollmentIds() {
		return enrollmentIds;
	}
	
	public void setEnrollmentIds(List<EnrollmentId> enrollmentIds) {
		this.enrollmentIds = enrollmentIds;
	}
	
	//enrollmentId
	public String getEnrollmentId() {
		return enrollmentId;
	}
	
	public void setEnrollmentId(String enrollmentId) {
		this.enrollmentId = enrollmentId;
	}
	
	//showMacEduReport
	public String getShowMacEduReport() {
		return showMacEduReport;
	}
	
	public void setShowMacEduReport(String showMacEduReport) {
		this.showMacEduReport = showMacEduReport;
	}
	
	//showUpicEduReport
	public String getShowUpicEduReport() {
		return showUpicEduReport;
	}
	
	public void setShowUpicEduReport(String showUpicEduReport) {
		this.showUpicEduReport = showUpicEduReport;
	}
	
	//hasHhaNv
	public String getHasHhaNv() {
		return hasHhaNv;
	}
	
	public void setHasHhaNv(String hasHhaNv) {
		this.hasHhaNv = hasHhaNv;
	}
	
	//actionability
	public String getActionability() {
		return actionability;
	}
	
	public void setActionability(String actionability) {
		this.actionability = actionability;
	}
	
	//timeliness
	public String getTimeliness() {
		return timeliness;
	}
	
	public void setTimeliness(String timeliness) {
		this.timeliness = timeliness;
	}
	
	//hasAps
	public String getHasAps() {
		return hasAps;
	}
	
	public void setHasAps(String hasAps) {
		this.hasAps = hasAps;
	}
	
	//apsRecs
	public List<ApsRecs> getApsRecs() {
		return apsRecs;
	}
	
	public void setApsRecs(List<ApsRecs> apsRecs) {
		this.apsRecs = apsRecs;
	}
	
	//showChowReport
	public String getShowChowReport() {
		return showChowReport;
	}
	
	public void setShowChowReport(String showChowReport) {
		this.showChowReport = showChowReport;
	}
	
	//hasPartD
	public String getHasPartD() {
		return hasPartD;
	}
	
	public void setHasPartD(String hasPartD) {
		this.hasPartD = hasPartD;
	}
	
	//hasRrb
	public String getHasRrb() {
		return hasRrb;
	}
	
	public void setHasRrb(String hasRrb) {
		this.hasRrb = hasRrb;
	}
	
	//postEdInd
	public String getPostEdInd() {
		return postEdInd;
	}
	
	public void setPostEdInd(String postEdInd) {
		this.postEdInd = postEdInd;
	}
	
	//tpes
	public String getTpes() {
		return tpes;
	}
	
	public void setTpes(String tpes) {
		this.tpes = tpes;
	}
	
	//totalPmt
	public String getTotalPmt() {
		return totalPmt;
	}
	
	public void setTotalPmt(String totalPmt) {
		this.totalPmt = totalPmt;
	}
	
	// relatedAsrCnt
	public String getRelatedAsrCnt() {
		return relatedAsrCnt;
	}
	
	public void setRelatedAsrCnt(String relatedAsrCnt) {
		this.relatedAsrCnt = relatedAsrCnt;
	}
	
	// hasDmeNv
	public String getHasDmeNv() {
		return hasDmeNv;
	}
	
	public void setHasDmeNv(String hasDmeNv) {
		this.hasDmeNv = hasDmeNv;
	}
	
	// nonAlertedPrvdrInd
	public String getNonAlertedPrvdrInd() {
		return nonAlertedPrvdrInd;
	}
	
	public void setNonAlertedPrvdrInd(String nonAlertedPrvdrInd) {
		this.nonAlertedPrvdrInd = nonAlertedPrvdrInd;
	}
	
	// uniqueAlertsNA
	public String getUniqueAlertsNA() {
		return uniqueAlertsNA;
	}
	
	public void setUniqueAlertsNA(String uniqueAlertsNA) {
		this.uniqueAlertsNA = uniqueAlertsNA;
	}
	
	// specialtiesNA
	public String getSpecialtiesNA() {
		return specialtiesNA;
	}
	
	public void setSpecialtiesNA(String specialtiesNA) {
		this.specialtiesNA = specialtiesNA;
	}
	
	// ptansNA
	public String getPtansNA() {
		return ptansNA;
	}
	
	public void setPtansNA(String ptansNA) {
		this.ptansNA = ptansNA;
	}
	
	// crossoverNA
	public String getCrossoverNA() {
		return crossoverNA;
	}
	
	public void setCrossoverNA(String crossoverNA) {
		this.crossoverNA = crossoverNA;
	}
	
	// rolesNA
	public String getRolesNA() {
		return rolesNA;
	}
	
	public void setRolesNA(String rolesNA) {
		this.rolesNA = rolesNA;
	}
	/**
	 * @return the riskScoreMethod
	 */
	public String getRiskScoreMethod() {
		return riskScoreMethod;
	}
	/**
	 * @param riskScoreMethod the riskScoreMethod to set
	 */
	public void setRiskScoreMethod(String riskScoreMethod) {
		this.riskScoreMethod = riskScoreMethod;
	}
	// mdcdEnrollmentIds
	
	public List<MdcdEnrollmentIds> getMdcdEnrollmentIds() {
		return mdcdEnrollmentIds;
	}
	// mdcdEnrollmentIds
	
	public void setMdcdEnrollmentIds(List<MdcdEnrollmentIds> mdcdEnrollmentIds) {
		this.mdcdEnrollmentIds = mdcdEnrollmentIds;
	}
	// medicaidInfo
	
	public MedicaidInfo getMedicaidInfo() {
		return medicaidInfo;
	}
	// medicaidInfo
	
	public void setMedicaidInfo(MedicaidInfo medicaidInfo) {
		this.medicaidInfo = medicaidInfo;
	}
	public String getAcoInd() {
		return acoInd;
	}
	public void setAcoInd(String acoInd) {
		this.acoInd = acoInd;
	}
	// minRiskScoreInd
	
	public String getMinRiskScoreInd() {
		return minRiskScoreInd;
	}
	// minRiskScoreModelTxt
	
	public String getMinRiskScoreModelTxt() {
		return minRiskScoreModelTxt;
	}
	// minRiskScoreInd
	
	public void setMinRiskScoreInd(String minRiskScoreInd) {
		this.minRiskScoreInd = minRiskScoreInd;
	}
	// minRiskScoreModelTxt
	
	public void setMinRiskScoreModelTxt(String minRiskScoreModelTxt) {
		this.minRiskScoreModelTxt = minRiskScoreModelTxt;
	}
	//p1TotalCost
	public String getp1TotalCost() {
		return p1TotalCost;
	}
	public void setp1TotalCost(String p1TotalCost) {
		this.p1TotalCost = p1TotalCost;
	}

	//p1Jurisdiction
	public String getp1Jurisdiction() {
		return p1Jurisdiction;
	}
	public void setp1Jurisdiction(String p1Jurisdiction) {
		this.p1Jurisdiction = p1Jurisdiction;
	}

	//p1RiskScore
	public String getp1RiskScore() {
		return p1RiskScore;
	}
	public void setp1RiskScore(String p1RiskScore) {
		this.p1RiskScore = p1RiskScore;
	}

}
