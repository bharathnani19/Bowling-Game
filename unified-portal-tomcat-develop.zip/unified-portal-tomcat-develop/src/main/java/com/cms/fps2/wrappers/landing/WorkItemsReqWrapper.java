package com.cms.fps2.wrappers.landing;

public class WorkItemsReqWrapper {
	private String userId;
	
	// constructor
	public WorkItemsReqWrapper() {}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	} 
}
