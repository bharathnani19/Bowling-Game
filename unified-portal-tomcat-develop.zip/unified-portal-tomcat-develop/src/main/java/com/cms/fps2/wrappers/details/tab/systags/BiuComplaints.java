package com.cms.fps2.wrappers.details.tab.systags;

public class BiuComplaints {
	private String biuSummary;
	private String day90Cnt;
	private String totalCnt;
	
	public BiuComplaints(){}
	
	// biuSummary
	public String getBiuSummary() {		
		return biuSummary;
	}
	
	public void setBiuSummary(String biuSummary) {
		this.biuSummary = biuSummary;
	}
	
	// day90Cnt
	public String getDay90Cnt() {		
		return day90Cnt;
	}
	
	public void setDay90Cnt(String day90Cnt) {
		this.day90Cnt = day90Cnt;
	}
	
	// totalCnt
	public String getTotalCnt() {		
		return totalCnt;
	}
	
	public void setTotalCnt(String totalCnt) {
		this.totalCnt = totalCnt;
	}
	
}
