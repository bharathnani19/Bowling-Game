package com.cms.fps2.wrappers.details.provider.systags;

public class SysTags {
	
	private String sysTagId;
	private String sysTagTxt;
	private String yesNoInd;
	
	//constructor
	public SysTags(){}
	
	//sysTagId
	public String getSysTagId() {
		return sysTagId;
	}
	
	public void setSysTagId(String sysTagId) {
		this.sysTagId = sysTagId;
	}
	
	//sysTagId
	public String getSysTagTxt() {
		return sysTagTxt;
	}
	
	public void setSysTagTxt(String sysTagTxt) {
		this.sysTagTxt = sysTagTxt;
	}
	
	//yesNoInd
	public String getYesNoInd() {
		return yesNoInd;
	}
	
	public void setYesNoInd(String yesNoInd) {
		this.yesNoInd = yesNoInd;
	}
}
