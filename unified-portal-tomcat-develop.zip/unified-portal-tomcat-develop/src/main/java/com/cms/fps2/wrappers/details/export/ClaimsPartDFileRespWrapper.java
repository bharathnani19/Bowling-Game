package com.cms.fps2.wrappers.details.export;

public class ClaimsPartDFileRespWrapper {
	private String fileContents;
	
	//constructor
	public ClaimsPartDFileRespWrapper(){}
	
	//fileContents
	public String getFileContents() {
		return fileContents;
	}
	
	public void setFileContents(String fileContents) {
		this.fileContents = fileContents;
	}
}
