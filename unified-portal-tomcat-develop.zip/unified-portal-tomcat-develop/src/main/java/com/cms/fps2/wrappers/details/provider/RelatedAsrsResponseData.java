package com.cms.fps2.wrappers.details.provider;

import java.util.ArrayList;
import java.util.List;

public class RelatedAsrsResponseData {
	private String prioritized;
	private List<RelatedAsrs> relatedAsrs = new ArrayList<RelatedAsrs>();
	
	// constructor
	public RelatedAsrsResponseData() {}
	
	//prioritized
	public String getPrioritized() {
		return prioritized;
	}
	
	public void setPrioritized(String prioritized) {
		this.prioritized = prioritized;
	}
	
	// relatedAsrs
	public List<RelatedAsrs> getRelatedAsrs() {
		return relatedAsrs;
	}
	
	public void setRelatedAsrs(List<RelatedAsrs> relatedAsrs) {
		this.relatedAsrs = relatedAsrs;
	}
}
