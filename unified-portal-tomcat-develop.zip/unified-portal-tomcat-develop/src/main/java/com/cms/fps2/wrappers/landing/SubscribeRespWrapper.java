package com.cms.fps2.wrappers.landing;

public class SubscribeRespWrapper {
	
	private String systemID;
	private String action;
	private String event;
	private String type;
	private String searchID;
		
	// constructor
	public SubscribeRespWrapper() {}
	
	// systemId
	public String getSystemID() {
		return systemID;
	}
	
	public void setSystemID(String systemID) {
		this.systemID = systemID;
	}
	
	// action
	public String getAction() {
		return action;
	}
	
	public void setAction(String action) {
		this.action = action;
	}
	
	// event
	public String getEvent() {
		return event;
	}
	
	public void setEvent(String event) {
		this.event = event;
	}
	
	// type
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	// searchID
	public String getSearchID() {
		return searchID;
	}
	
	public void setSearchID(String searchID ) {
		this.searchID  = searchID;
	}
}
