package com.cms.fps2.wrappers.summary;

public class AssignedToUserIds {
	
	private String userId;
	private String givenName;
	private String email;
	private String groupName;
	private String businessCategory;
	private String firstName;
	private String lastName;
	private String masterApprover;
	private String inqOnlyApprover;
	
	//constructor
	public AssignedToUserIds(){}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//givenName
	public String getGivenName() {
		return givenName;
	}
	
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}
	
	//email
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	//groupName
	public String getGroupName() {
		return groupName;
	}
	
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
	//businessCategory
	public String getBusinessCategory() {
		return businessCategory;
	}
	
	public void setBusinessCategory(String businessCategory) {
		this.businessCategory = businessCategory;
	}
	
	//firstName
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	//lastName
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	//masterApprover
	public String getMasterApprover() {
		return masterApprover;
	}
	
	public void setMasterApprover(String masterApprover) {
		this.masterApprover = masterApprover;
	}
	
	//inqOnlyApprover
	public String getInqOnlyApprover() {
		return inqOnlyApprover;
	}
	
	public void setInqOnlyApprover(String inqOnlyApprover) {
		this.inqOnlyApprover = inqOnlyApprover;
	}
	
}
