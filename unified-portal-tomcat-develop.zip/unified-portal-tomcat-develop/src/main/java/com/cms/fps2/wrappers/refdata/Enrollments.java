package com.cms.fps2.wrappers.refdata;

public class Enrollments {
	
	private String code;
	
	// constructor
	public Enrollments() {}
	
	// code
	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}

}
