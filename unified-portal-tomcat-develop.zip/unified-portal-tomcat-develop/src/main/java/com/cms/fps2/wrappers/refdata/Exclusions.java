package com.cms.fps2.wrappers.refdata;

public class Exclusions {
	private String key;
	private String value;
	
	// constructor
	public Exclusions() {}
	
	// key
	public String getKey() {
		return key;
	}
	
	public void setKey(String key) {
		this.key = key;
	}
	
	// value
	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}
}
