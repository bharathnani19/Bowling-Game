package com.cms.fps2.wrappers.summary;

public class Actions {
	
	private String actionTypeCd;
	private String source;
	private String actionTypeDesc;
	
	//constructor
	public Actions() {}
	
	//actionTypeCd
	public String getActionTypeCd() {
		return actionTypeCd;
	}
	
	public void setActionTypeCd(String actionTypeCd) {
		this.actionTypeCd = actionTypeCd;
	}
	
	//source
	public String getSource() {
		return source;
	}
	
	public void setSource(String source) {
		this.source = source;
	}	
	
	//actionTypeDesc
	public String getActionTypeDesc() {
		return actionTypeDesc;
	}
	
	public void setActionTypeDesc(String actionTypeDesc) {
		this.actionTypeDesc = actionTypeDesc;
	}
}
