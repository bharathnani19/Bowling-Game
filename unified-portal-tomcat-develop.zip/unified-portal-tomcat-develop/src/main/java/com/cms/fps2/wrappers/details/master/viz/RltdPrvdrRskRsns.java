package com.cms.fps2.wrappers.details.master.viz;

public class RltdPrvdrRskRsns {
	
	private String code;
	
	//constructor
	public RltdPrvdrRskRsns() {}
	
	//code
	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}

}
