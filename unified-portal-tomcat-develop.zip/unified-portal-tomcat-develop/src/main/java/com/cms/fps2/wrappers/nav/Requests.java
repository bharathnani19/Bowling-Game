package com.cms.fps2.wrappers.nav;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;

//@JsonIgnoreProperties(ignoreUnknown=true)
public class Requests {
	private String firstName;
	private String lastName;
	private String requestDt;
	private String status;
	private String userId;
		
	//constructor
	public Requests(){}		
	
	
	
	//requestDt
	public String getRequestDt() {
		return requestDt;
	}
	
	public void setRequestDt(String requestDt) {
		this.requestDt = requestDt;
	}
	
	//status
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
}
