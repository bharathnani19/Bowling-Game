package com.cms.fps2.wrappers.summary;

public class OpenLeadInvest {
	
	private String leadInvstNum;
	private String leadOpen;
	private String source;
	
	//constructor
	public OpenLeadInvest() {}
	
	//leadInvstNum
	public String getLeadInvstNum() {
		return leadInvstNum;
	}
	
	public void setLeadInvstNum(String leadInvstNum) {
		this.leadInvstNum = leadInvstNum;
	}
	
	//leadOpen
	public String getLeadOpen() {
		return leadOpen;
	}
	
	public void setLeadOpen(String leadOpen) {
		this.leadOpen = leadOpen;
	}
	
	//source
	public String getSource() {
		return source;
	}
	
	public void setSource(String source) {
		this.source = source;
	}

}
