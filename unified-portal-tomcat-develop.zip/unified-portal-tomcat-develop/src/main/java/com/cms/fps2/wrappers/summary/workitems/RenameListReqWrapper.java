package com.cms.fps2.wrappers.summary.workitems;

public class RenameListReqWrapper {
	private FpsPrioritizationList fpsPrioritizationList;
	
	// constructor
	public RenameListReqWrapper() {}
	
	// fpsPrioritizationList
	public FpsPrioritizationList getFpsPrioritizationList() {
		return fpsPrioritizationList;
	}
	
	public void setFpsPrioritizationList(FpsPrioritizationList fpsPrioritizationList) {
		this.fpsPrioritizationList = fpsPrioritizationList;
	}
}
