package com.cms.fps2.wrappers.nav;

public class EnhancementReqWrapper {
	
	private String userId;
	private String firstName;
	private String lastName;
	private String email;
	private String phone;
	private String messageTxt;
	
	// constructor 
	public EnhancementReqWrapper() {}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	// firstName
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	// lastName
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	// email
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	// phone
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	// messageTxt
	public String getMessageTxt() {
		return messageTxt;
	}
	
	public void setMessageTxt(String messageTxt) {
		this.messageTxt = messageTxt;
	}
}
