package com.cms.fps2.wrappers.details;

import java.util.ArrayList;
import java.util.List;

public class ClaimLines {
	
	List<PartAItems> partAItems = new ArrayList<PartAItems>();
	List<PartBItems> partBItems = new ArrayList<PartBItems>();
	List<PartDMEItems> partDMEItems = new ArrayList<PartDMEItems>();
	
	//constructor
	public ClaimLines(){}
	
	//partAItems
	public List<PartAItems> getPartAItems() {
		return partAItems;
	}
	
	public void setPartAItems(List<PartAItems> partAItems) {
		this.partAItems = partAItems;
	}
	
	//partBItems
	public List<PartBItems> getPartBItems() {
		return partBItems;
	}
	
	public void setPartBItems(List<PartBItems> partBItems) {
		this.partBItems = partBItems;
	}
	
	//partDMEItems
	public List<PartDMEItems> getPartDMEItems() {
		return partDMEItems;
	}
	
	public void setPartDMEItems(List<PartDMEItems> partDMEItems) {
		this.partDMEItems = partDMEItems;
	}
}
