package com.cms.fps2.wrappers.summary;

public class LeadInvRatings {
	
	private String userId;
	private String eventDt;
	private String modelNm;
	private String rating;
	private String source;
	private String ucmId;
	
	//constructor
	LeadInvRatings(){}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//eventDt
	public String getEventDt() {
		return eventDt;
	}
	
	public void setEventDt(String eventDt) {
		this.eventDt = eventDt;
	}
	
	//modelNm
	public String getModelNm() {
		return modelNm;
	}
	
	public void setModelNm(String modelNm) {
		this.modelNm = modelNm;
	}
	
	//rating
	public String getRating() {
		return rating;
	}
	
	public void setRating(String rating) {
		this.rating = rating;
	}
	
	//source
	public String getSource() {
		return source;
	}
	
	public void setSource(String source) {
		this.source = source;
	}
	
	//ucmId
	public String getUcmId() {
		return ucmId;
	}
	
	public void setUcmId(String ucmId) {
		this.ucmId = ucmId;
	}
}
