package com.cms.fps2.wrappers.details.tab.systags;

import com.cms.fps2.wrappers.details.Systags;

public class ResponseData {
	private Systags systags = new Systags();
	private String prioritized;
	private String recentAlerts;
	private String recentEdits;
	private String recentInv;
	private String hasEdits;
	private String hasInv;
	private String hasSysTags;
	private String hasNotes;
	private String hasPartD;	
	BiuComplaints biuSummary = new BiuComplaints();
	
	//constructor
	public ResponseData(){}
	
	//systags
	public Systags getSystags() {
		return systags;
	}
	
	public void setSystags(Systags systags) {
		this.systags = systags;
	}
	
	//prioritized - this field is not used by the system tags tab
	public String getPrioritized() {
		return prioritized;
	}
	
	public void setPrioritized(String prioritized) {
		this.prioritized = prioritized;
	}
	
	//recentAlerts
	public String getRecentAlerts() {
		
		return recentAlerts;
	}
	
	public void setRecentAlerts(String recentAlerts) {
		this.recentAlerts = recentAlerts;
	}
	
	//recentEdits
	public String getRecentEdits() {
		
		return recentEdits;
	}
	
	public void setRecentEdits(String recentEdits) {
		this.recentEdits = recentEdits;
	}
	
	//recentInv
	public String getRecentInv() {
		
		return recentInv;
	}
	
	public void setRecentInv(String recentInv) {
		this.recentInv = recentInv;
	}
	
	//hasEdits
	public String getHasEdits() {		
		return hasEdits;
	}
	
	public void setHasEdits(String hasEdits) {
		this.hasEdits = hasEdits;
	}
	
	//hasInv
	public String getHasInv() {		
		return hasInv;
	}
	
	public void setHasInv(String hasInv) {
		this.hasInv = hasInv;
	}
	
	//hasSysTags
	public String getHasSysTags() {		
		return hasSysTags;
	}
	
	public void setHasSysTags(String hasSysTags) {
		this.hasSysTags = hasSysTags;
	}
	
	//hasNotes
	public String getHasNotes() {		
		return hasNotes;
	}
	
	public void setHasNotes(String hasNotes) {
		this.hasNotes = hasNotes;
	}
	
	//hasPartD
	public String getHasPartD() {		
		return hasPartD;
	}
	
	public void setHasPartD(String hasPartD) {
		this.hasPartD = hasPartD;
	}
	
	// biuSummary
	public BiuComplaints getBiuSummary() {		
		return biuSummary;
	}
	
	public void setBiuSummary(BiuComplaints biuSummary) {
		this.biuSummary = biuSummary;
	}
}
