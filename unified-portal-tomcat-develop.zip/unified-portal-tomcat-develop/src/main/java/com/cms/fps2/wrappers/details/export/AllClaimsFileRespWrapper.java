package com.cms.fps2.wrappers.details.export;

public class AllClaimsFileRespWrapper {
	
	private String fileContents;
	
	//constructor
	public AllClaimsFileRespWrapper(){}
	
	//fileContents
	public String getFileContents() {
		return fileContents;
	}
	
	public void setFileContents(String fileContents) {
		this.fileContents = fileContents;
	}

}
