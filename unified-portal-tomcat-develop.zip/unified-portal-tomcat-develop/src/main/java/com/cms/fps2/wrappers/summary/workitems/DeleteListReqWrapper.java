package com.cms.fps2.wrappers.summary.workitems;

public class DeleteListReqWrapper {
	private String userId;
	private String listId;
	private String listType;
	
	// constructor
	public DeleteListReqWrapper() {}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	// listId
	public String getListId() {
		return listId;
	}
	
	public void setListId(String listId) {
		this.listId = listId;
	}
	
	// listType
	public String getListType() {
		return listType;
	}
	
	public void setListType(String listType) {
		this.listType = listType;
	}
}
