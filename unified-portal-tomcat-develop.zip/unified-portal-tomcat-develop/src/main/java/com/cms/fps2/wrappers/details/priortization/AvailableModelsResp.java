package com.cms.fps2.wrappers.details.priortization;

import java.util.ArrayList;
import java.util.List;

public class AvailableModelsResp {
	private String npi;
	private String asrptId;
	private String providerName;
	private String comments;
	
	private List<PriortizeAlerts> alerts = new ArrayList<PriortizeAlerts>();
	/**
	 * @return the npi
	 */
	public String getNpi() {
		return npi;
	}
	/**
	 * @return the asrptId
	 */
	public String getAsrptId() {
		return asrptId;
	}
	/**
	 * @return the providerName
	 */
	public String getProviderName() {
		return providerName;
	}
	/**
	 * @return the alerts
	 */
	public List<PriortizeAlerts> getAlerts() {
		return alerts;
	}
	/**
	 * @param npi the npi to set
	 */
	public void setNpi(String npi) {
		this.npi = npi;
	}
	/**
	 * @param asrptId the asrptId to set
	 */
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	/**
	 * @param providerName the providerName to set
	 */
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	/**
	 * @param alerts the alerts to set
	 */
	public void setAlerts(List<PriortizeAlerts> alerts) {
		this.alerts = alerts;
	}
	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}
	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	

}
