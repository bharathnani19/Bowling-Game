package com.cms.fps2.wrappers.summary;

public class ClaimTypes {
	
	private String claimTypeCd;
	private String claimTypeDesc;
	
	//constructor
	public ClaimTypes() {}
	
	//claimTypeCd
	public String getClaimTypeCd() {
		return claimTypeCd;
	}
	
	public void setClaimTypeCd(String claimTypeCd) {
		this.claimTypeCd = claimTypeCd;
	}
	
	//claimTypeDesc
	public String getClaimTypeDesc() {
		return claimTypeDesc;
	}
	
	public void setClaimTypeDesc(String claimTypeDesc) {
		this.claimTypeDesc = claimTypeDesc;
	}
}
