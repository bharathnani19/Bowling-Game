package com.cms.fps2.service;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.logging.LoggingFeature;

import com.cms.fps2.wrappers.AlertsWrapper;
import com.cms.fps2.wrappers.admin.AdminModelsReqWrapper;
import com.cms.fps2.wrappers.admin.AdminModelsRespWrapper;
import com.cms.fps2.wrappers.admin.AdminMsgsReqWrapper;
import com.cms.fps2.wrappers.admin.AdminMsgsRespWrapper;
import com.cms.fps2.wrappers.admin.AdminOutagesReqWrapper;
import com.cms.fps2.wrappers.admin.AdminOutagesRespWrapper;
import com.cms.fps2.wrappers.admin.AdminSysMsgsReqWrapper;
import com.cms.fps2.wrappers.admin.AdminSysMsgsRespWrapper;
import com.cms.fps2.wrappers.details.AsrDetailsWrapper;
import com.cms.fps2.wrappers.details.DrillClaimsReqWrapper;
import com.cms.fps2.wrappers.details.DrillClaimsRespWrapper;
import com.cms.fps2.wrappers.details.MedicaidTotalPaymentWrapper;
import com.cms.fps2.wrappers.details.TpeReqWrapper;
import com.cms.fps2.wrappers.details.TpeRespWrapper;
import com.cms.fps2.wrappers.details.export.FieldExportReqWrapper;
import com.cms.fps2.wrappers.details.init.ASRDetailsInitReqWrapper;
import com.cms.fps2.wrappers.details.master.modal.claims.MasterClaimsRequestWrapper;
import com.cms.fps2.wrappers.details.master.modal.claims.MasterClaimsResponseWrapper;
import com.cms.fps2.wrappers.details.master.viz.NetVizConnReqWrapper;
import com.cms.fps2.wrappers.details.master.viz.NetVizExportReqWrapper;
import com.cms.fps2.wrappers.details.master.viz.NetVizReqWrapper;
import com.cms.fps2.wrappers.details.master.viz.NetVizRespWrapper;
import com.cms.fps2.wrappers.details.priortization.AvailableModelsReq;
import com.cms.fps2.wrappers.details.priortization.AvailableModelsResp;
import com.cms.fps2.wrappers.details.provider.NonAlertAsrsReqWrapper;
import com.cms.fps2.wrappers.details.provider.NonAlertAsrsRespWrapper;
import com.cms.fps2.wrappers.details.provider.RelatedAsrsReqWrapper;
import com.cms.fps2.wrappers.details.provider.RelatedAsrsRespWrapper;
import com.cms.fps2.wrappers.details.provider.TotalPaymentReqWrapper;
import com.cms.fps2.wrappers.details.provider.TotalPaymentRespWrapper;
import com.cms.fps2.wrappers.details.tab.claims.ClaimsTabRequestWrapper;
import com.cms.fps2.wrappers.details.tab.claims.ClaimsTabResponseWrapper;
import com.cms.fps2.wrappers.details.tab.edits.EditAllClaimsReqWrapper;
import com.cms.fps2.wrappers.details.tab.edits.EditAllClaimsRespWrapper;
import com.cms.fps2.wrappers.details.tab.edits.EditDetailsReqWrapper;
import com.cms.fps2.wrappers.details.tab.edits.EditDetailsRespWrapper;
import com.cms.fps2.wrappers.details.tab.edits.EditInfoReqWrapper;
import com.cms.fps2.wrappers.details.tab.edits.EditInfoRespWrapper;
import com.cms.fps2.wrappers.details.tab.edits.EditsTabRequestWrapper;
import com.cms.fps2.wrappers.details.tab.edits.EditsTabResponseWrapper;
import com.cms.fps2.wrappers.details.tab.history.HistoryTabRequestWrapper;
import com.cms.fps2.wrappers.details.tab.history.HistoryTabResponseWrapper;
import com.cms.fps2.wrappers.details.tab.leads.LeadsTabRequestWrapper;
import com.cms.fps2.wrappers.details.tab.leads.LeadsTabResponseWrapper;
import com.cms.fps2.wrappers.details.tab.notes.NotesTabRequestWrapper;
import com.cms.fps2.wrappers.details.tab.notes.NotesTabResponseWrapper;
import com.cms.fps2.wrappers.details.tab.partdclaims.PartDClaimLines;
import com.cms.fps2.wrappers.details.tab.partdclaims.PartdDlaimLinesReqWrapper;
import com.cms.fps2.wrappers.details.tab.partdclaims.PartdDlaimLinesRespWrapper;
import com.cms.fps2.wrappers.details.tab.partdrpt.PartDReportsTabRequestWrapper;
import com.cms.fps2.wrappers.details.tab.partdrpt.PartDReportsTabResponseWrapper;
import com.cms.fps2.wrappers.details.tab.partdrpt.ResponseData;
import com.cms.fps2.wrappers.details.tab.prioritize.PrioritizeUCMTabRequestWrapper;
import com.cms.fps2.wrappers.details.tab.prioritize.PrioritizeUCMTabResponseWrapper;
import com.cms.fps2.wrappers.details.tab.systags.SysTagsTabReqWrapper;
import com.cms.fps2.wrappers.details.tab.systags.SysTagsTabRespWrapper;
import com.cms.fps2.wrappers.details.tab.totalzncost.TotalZnCostReqWrapper;
import com.cms.fps2.wrappers.details.tab.totalzncost.TotalZnCostRespWrapper;
import com.cms.fps2.wrappers.home.HomepageTileResponse;
import com.cms.fps2.wrappers.landing.ArchiveListReqWrapper;
import com.cms.fps2.wrappers.landing.ExListActionReqWrapper;
import com.cms.fps2.wrappers.landing.LandingPageRequestWrapper;
import com.cms.fps2.wrappers.landing.LandingPageWrapper;
import com.cms.fps2.wrappers.landing.ReportFavsReqWrapper;
import com.cms.fps2.wrappers.landing.ReportFavsRespWrapper;
import com.cms.fps2.wrappers.landing.SubscribeReqWrapper;
import com.cms.fps2.wrappers.landing.SubscribeRespWrapper;
import com.cms.fps2.wrappers.landing.WorkItem;
import com.cms.fps2.wrappers.landing.WorkItemsReqWrapper;
import com.cms.fps2.wrappers.landing.WorkItemsRespWrapper;
import com.cms.fps2.wrappers.maps.asr.ASRMapsReqWrapper;
import com.cms.fps2.wrappers.maps.asr.ASRMapsRespWrapper;
import com.cms.fps2.wrappers.maps.model.BeneModelReqWrapper;
import com.cms.fps2.wrappers.maps.model.BeneModelRespWrapper;
import com.cms.fps2.wrappers.nav.NavSysMsgsReqWrapper;
import com.cms.fps2.wrappers.nav.NavSysMsgsRespWrapper;
import com.cms.fps2.wrappers.nav.ReadMsgsReqWrapper;
import com.cms.fps2.wrappers.nav.ReadMsgsRespWrapper;
import com.cms.fps2.wrappers.refdata.AsrStatesByUserRequest;
import com.cms.fps2.wrappers.refdata.RefDataReqWrapper;
import com.cms.fps2.wrappers.refdata.RefDataWrapper;
import com.cms.fps2.wrappers.rptcard.AsrStatesByUserWrapper;
import com.cms.fps2.wrappers.rptcard.ReportCardRequestWrapper;
import com.cms.fps2.wrappers.rptcard.ReportCardResponseWrapper;
import com.cms.fps2.wrappers.summary.ASRSearchWrapper;
import com.cms.fps2.wrappers.summary.AlertsReqWrapper;
import com.cms.fps2.wrappers.summary.SearchCriteriaReqWrapper;
import com.cms.fps2.wrappers.summary.SearchCriteriaRespWrapper;
import com.cms.fps2.wrappers.summary.modals.SummaryModalsRequestWrapper;
import com.cms.fps2.wrappers.summary.modals.SummaryModalsResponseWrapper;
import com.cms.fps2.wrappers.summary.userprefs.UserPrefsReqWrapper;
import com.cms.fps2.wrappers.summary.userprefs.UserPrefsRespWrapper;
import com.cms.fps2.wrappers.summary.workitems.AddToExistInputValReqWrapper;
import com.cms.fps2.wrappers.summary.workitems.AddToExistListReqWrapper;
import com.cms.fps2.wrappers.summary.workitems.AddtoExclusionListReq;
import com.cms.fps2.wrappers.summary.workitems.CheckListNameReqWrapper;
import com.cms.fps2.wrappers.summary.workitems.DeleteListReqWrapper;
import com.cms.fps2.wrappers.summary.workitems.ExDetailEditRespWrapper;
import com.cms.fps2.wrappers.summary.workitems.ExDetailExclusion;
import com.cms.fps2.wrappers.summary.workitems.ExclusionDetailReqWrapper;
import com.cms.fps2.wrappers.summary.workitems.ExclusionDetailRespWrapper;
import com.cms.fps2.wrappers.summary.workitems.FpsPrioritizationList;
import com.cms.fps2.wrappers.summary.workitems.FpsPrioritizationShareGrp;
import com.cms.fps2.wrappers.summary.workitems.FpsWorkbenchList;
import com.cms.fps2.wrappers.summary.workitems.InfoModelListReqWrapper;
import com.cms.fps2.wrappers.summary.workitems.RemoveAsrsReqWrapper;
import com.cms.fps2.wrappers.summary.workitems.RemoveAsrsRespWrapper;
import com.cms.fps2.wrappers.summary.workitems.RenameListReqWrapper;
import com.cms.fps2.wrappers.summary.workitems.RenameListRespWrapper;
import com.cms.fps2.wrappers.summary.workitems.SaveAsListReqWrapper;
import com.cms.fps2.wrappers.summary.workitems.SaveSearchListReqWrapper;
import com.cms.fps2.wrappers.summary.workitems.ShareToGroupReqWrapper;
import com.cms.fps2.wrappers.summary.workitems.ShareableUsersReqWrapper;
import com.cms.fps2.wrappers.summary.workitems.ShareableUsersRespWrapper;
import com.cms.fps2.wrappers.summary.workitems.WorkItemsListReqWrapper;
import com.cms.fps2.wrappers.summary.workitems.WorkItemsListRespWrapper;
import com.cms.fps2.wrappers.tracking.SlaMeticsReqWrapper;
import com.cms.fps2.wrappers.tracking.SlaMeticsRespWrapper;
import com.cms.fps2.wrappers.tracking.UserTrackingReqWrapper;
import com.cms.fps2.wrappers.tracking.UserTrackingRespWrapper;
import com.cms.fps2.wrappers.ucm.PrioritizeASRReqWrapper;
import com.cms.fps2.wrappers.ucm.PrioritizeASRRespWrapper;
import com.cms.fps2.wrappers.ucm.leads.UCMLeadDataReqWrapper;
import com.cms.fps2.wrappers.ucm.leads.UCMLeadDataRespWrapper;
import com.cms.util.JwtUtil;
import com.cms.util.OktaLoginToken;
import com.cms.util.OktaLoginTokenFields;
import com.cms.util.PropertyFileHandler;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.Invocation;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import net.minidev.json.JSONObject;

@Path("/portal")
public class UnifiedPortalRestService {
	static final Logger logger = LogManager.getLogger(UnifiedPortalRestService.class);
	private static final java.util.logging.Logger utilLogger = java.util.logging.Logger.getLogger(UnifiedPortalRestService.class.getName());
	@Context
	private HttpServletResponse httpServletResponse;

	@Context
	private HttpHeaders httpHeaders;

	public UnifiedPortalRestService() {
//		SlaLogHandler con = new SlaLogHandler();
//        con.setLevel(Level.ALL);
//       
//        utilLogger.addHandler(con);
	}
	@POST
	@Path("/navBarData")
	@Produces({ "application/json" })
	@Consumes({ "application/json" })
	public NavSysMsgsRespWrapper getNavMessagesData(NavSysMsgsReqWrapper pMsgsRequest) {
		NavSysMsgsRespWrapper oMsgsResponse = new NavSysMsgsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceMsgs = client.target(
						String.valueOf(ucmUrlStr) + "/rest/landingpage/header/" + verifyUser(pMsgsRequest.getUserId())
								+ "/" + pMsgsRequest.getUserZone().replaceAll(" ", "%20"));

				Invocation.Builder invocationBuilder = webResourceMsgs.request();
				invocationBuilder.header("Content-Type", "application/json");
				invocationBuilder.header("Authorization", "Bearer " + getToken());

				
				invocationBuilder.accept("application/json");

				Response responseMsgs = invocationBuilder.get();
				if (responseMsgs.getStatus() != 200 && responseMsgs.getStatus() != 202) {
					responseMsgs.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseMsgs.getStatus() + ": "
							+ responseMsgs.getStatusInfo().getReasonPhrase());
				}
				oMsgsResponse = (NavSysMsgsRespWrapper) responseMsgs.readEntity(NavSysMsgsRespWrapper.class);
				logger.debug("Nav Bar REST Output from Server .... \n");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oMsgsResponse;
	}

	@POST
	@Path("/exportFieldBin")
	@Produces({ "application/octet-stream" })
	public Response getFieldExportBin(FieldExportReqWrapper pFieldExportReq) {
		Response.ResponseBuilder responseBuilder = Response.noContent();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/asrexport/"
						+ pFieldExportReq.getAsrptId() + "?userId=" + pFieldExportReq.getUserId());

				Response response = (Response) webResource.request().header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.get(Response.class);
				response.bufferEntity();
				if (response.getStatus() != 200) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				responseBuilder = Response.ok(response.getEntity(), "application/octet-stream");
				responseBuilder.header("Content-Disposition",
						((List) response.getHeaders().get("Content-Disposition")).toString());
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return responseBuilder.build();
	}

	@POST
	@Path("/exportFieldMdcdBin")
	@Produces({ "application/octet-stream" })
	public Response getFieldExportMdcdBin(FieldExportReqWrapper pFieldExportReq) {
		Response.ResponseBuilder responseBuilder = Response.noContent();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/mdcd/asrexport/"
						+ pFieldExportReq.getAsrptId() + "?userId=" + pFieldExportReq.getUserId());
				Response response = (Response) webResource.request().header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.get(Response.class);
				if (response.getStatus() != 200) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				responseBuilder = Response.ok((InputStream) response.getEntity(), "application/octet-stream");
				responseBuilder.header("Content-Disposition",
						((List) response.getHeaders().get("Content-Disposition")).toString());
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return responseBuilder.build();
	}

	@POST
	@Path("/exportNetVizBin")
	@Produces({ "application/octet-stream" })
	public Response getExportNetVizBin(NetVizExportReqWrapper pNetVizExportRequest) {
		logger.debug("Export Net Viz Export Bin Request: " + pNetVizExportRequest);
		Response.ResponseBuilder responseBuilder = Response.noContent();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			String wsUrl = "";
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				if (pNetVizExportRequest.getModelType().equalsIgnoreCase("HHA")) {
					wsUrl = String.valueOf(ucmUrlStr) + "/rest/asr/hhavizexport/" + pNetVizExportRequest.getAsrptId()
							+ "/" + "?userId=" + pNetVizExportRequest.getUserId();
				} else if (pNetVizExportRequest.getModelType().equalsIgnoreCase("DME")) {
					wsUrl = String.valueOf(ucmUrlStr) + "/rest/asr/dmevizexport/" + pNetVizExportRequest.getAsrptId()
							+ "/" + "?userId=" + pNetVizExportRequest.getUserId();
				} else {
					wsUrl = String.valueOf(ucmUrlStr) + "/rest/asr/vizexport/" + pNetVizExportRequest.getAsrptId() + "/"
							+ pNetVizExportRequest.getModelName() + "?userId=" + pNetVizExportRequest.getUserId();
				}
				WebTarget webResource = client.target(wsUrl);
				Response response = (Response) webResource.request().header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.get(Response.class);
				if (response.getStatus() != 200) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				responseBuilder = Response.ok((InputStream) response.getEntity(), "application/octet-stream");
				responseBuilder.header("Content-Disposition",
						((List) response.getHeaders().get("Content-Disposition")).toString());
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return responseBuilder.build();
	}

	@POST
	@Path("/asrMgmtSearch")
	@Produces({ "application/json" })
	public ASRSearchWrapper getAsrMgmtSearch(String pSearchRequest) {
		ASRSearchWrapper oAsrSearchWrapper = new ASRSearchWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceSearch = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/searchldg");
				Response responseSearch = webResourceSearch.request().accept("application/json")
						.header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.post(Entity.entity(pSearchRequest, MediaType.APPLICATION_JSON));
				if (responseSearch.getStatus() != 200) {
					responseSearch.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseSearch.getStatus());
				}
				oAsrSearchWrapper = (ASRSearchWrapper) responseSearch.readEntity(ASRSearchWrapper.class);
				logger.debug("ASR Mgmt Search REST Output from Server .... \n");
				responseSearch.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oAsrSearchWrapper;
	}

	@POST
	@Path("/saveSearchList")
	@Produces({ "application/json" })
	public List<FpsWorkbenchList> getSavedSearchList(SaveSearchListReqWrapper pSaveSearchListReq) {
		List<FpsWorkbenchList> oSaveSearchListResp = new ArrayList<FpsWorkbenchList>();
		this.httpHeaders.getRequestHeader("Authorization");
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/provider/lists/user/"
						+ verifyUser(pSaveSearchListReq.getUserId()) + "/search");
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oSaveSearchListResp = (List<FpsWorkbenchList>) response
						.readEntity(new GenericType<List<FpsWorkbenchList>>() {
						});
				logger.debug("Add to List Input Values REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oSaveSearchListResp;
	}

	@POST
	@Path("/editInfoIndex")
	@Produces({ "application/json" })
	public EditInfoRespWrapper getEditInfoIndex(EditInfoReqWrapper pEditInfoRequest) {
		EditInfoRespWrapper oEditInfoResp = new EditInfoRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/landing/editinfo?userId="
						+ verifyUser(pEditInfoRequest.getUserId()));
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oEditInfoResp = (EditInfoRespWrapper) response.readEntity(EditInfoRespWrapper.class);
				logger.debug("Edit Info REST Output from Server .... \n");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oEditInfoResp;
	}

	@POST
	@Path("/editInfo")
	@Produces({ "application/json" })
	public EditInfoRespWrapper getEditInfo(EditInfoReqWrapper pEditInfoRequest) {
		EditInfoRespWrapper oEditInfoResp = new EditInfoRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client
						.target(String.valueOf(ucmUrlStr) + "/rest/editinfo?userId=" + pEditInfoRequest.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oEditInfoResp = (EditInfoRespWrapper) response.readEntity(EditInfoRespWrapper.class);
				logger.debug("Edit Info REST Output from Server .... \n");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oEditInfoResp;
	}

	@POST
	@Path("/editAllClaims")
	@Produces({ "application/json" })
	public EditAllClaimsRespWrapper getEditAllClaims(EditAllClaimsReqWrapper pEditAllClaimsRequest) {
		EditAllClaimsRespWrapper oEditAllClaimsResp = new EditAllClaimsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(
						String.valueOf(ucmUrlStr) + "/rest/editinfo/claims/" + pEditAllClaimsRequest.getNpi() + "/"
								+ pEditAllClaimsRequest.getEditName() + "?userId=" + pEditAllClaimsRequest.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oEditAllClaimsResp = (EditAllClaimsRespWrapper) response.readEntity(EditAllClaimsRespWrapper.class);
				logger.debug("Edit All Claims REST Output from Server .... \n");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oEditAllClaimsResp;
	}

	@POST
	@Path("/editDetails")
	@Produces({ "application/json" })
	public EditDetailsRespWrapper getEditDetails(EditDetailsReqWrapper pEditDetailsRequest) {
		EditDetailsRespWrapper oEditDetailsResp = new EditDetailsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/editinfo/"
						+ pEditDetailsRequest.getEditName() + "?userId=" + pEditDetailsRequest.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oEditDetailsResp = (EditDetailsRespWrapper) response.readEntity(EditDetailsRespWrapper.class);
				logger.debug("Edit Details REST Output from Server .... \n");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oEditDetailsResp;
	}

	@POST
	@Path("/claimStates")
	@Produces({ "application/json" })
	public AsrStatesByUserWrapper getStatesForUser(AsrStatesByUserRequest asrStatesReq) {
		AsrStatesByUserWrapper wrapper = new AsrStatesByUserWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/mdcd/asr/states/"
						+ asrStatesReq.getAsrptId() + "?userId=" + asrStatesReq.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				wrapper = (AsrStatesByUserWrapper) response.readEntity(AsrStatesByUserWrapper.class);
				logger.debug("Claims States REST Output from Server .... \n");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return wrapper;
	}

	@POST
	@Path("/addToExclusionList")
	@Produces({ "application/json" })
	public WorkItemsListRespWrapper addToExclusionList(AddtoExclusionListReq pRequest) {
		WorkItemsListRespWrapper oResponse = new WorkItemsListRespWrapper();
		logger.debug("Calling the Rest Webservice : UnifiedPortalRestService.addToExclusionList()");
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(
						String.valueOf(ucmUrlStr) + "/rest/provider/exclusions/" + verifyUser(pRequest.getUserId()));
				Response response = webResource.request().accept(new String[] { "application/json" })
						.header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.post(Entity.entity(pRequest.getReqStr(), MediaType.APPLICATION_JSON));

				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oResponse = (WorkItemsListRespWrapper) response.readEntity(WorkItemsListRespWrapper.class);
				logger.debug("Case Mgmt Search REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oResponse;
	}

	@POST
	@Path("/verifyAsrs")
	@Produces({ "application/json" })
	public ASRSearchWrapper getAsrVerification(String pSearchRequest) {
		ASRSearchWrapper asrSearchWrapper = new ASRSearchWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceSearch = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/search/verify");
				Response responseSearch = webResourceSearch.request().accept(new String[] { "application/json" })
						.header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.post(Entity.entity(pSearchRequest, MediaType.APPLICATION_JSON));
				if (responseSearch.getStatus() != 200) {
					responseSearch.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseSearch.getStatus());
				}
				asrSearchWrapper = (ASRSearchWrapper) responseSearch.readEntity(ASRSearchWrapper.class);
				logger.debug("Case Mgmt Search REST Output from Server .... \n");
				responseSearch.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return asrSearchWrapper;
	}

	@POST
	@Path("/verifyMdcdAsrs")
	@Produces({ "application/json" })
	public ASRSearchWrapper getMdcdAsrVerification(String pSearchRequest) {
		ASRSearchWrapper asrSearchWrapper = new ASRSearchWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceSearch = client.target(String.valueOf(ucmUrlStr) + "/rest/mdcd/asr/search/verify");
				Response responseSearch = webResourceSearch.request().accept(new String[] { "application/json" })
						.header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.post(Entity.entity(pSearchRequest, MediaType.APPLICATION_JSON));
				if (responseSearch.getStatus() != 200) {
					responseSearch.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseSearch.getStatus());
				}
				asrSearchWrapper = (ASRSearchWrapper) responseSearch.readEntity(ASRSearchWrapper.class);
				logger.debug("Case Mgmt Search REST Output from Server .... \n");
				responseSearch.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return asrSearchWrapper;
	}

	@POST
	@Path("/mdcdTotalPayment")
	@Produces({ "application/json" })
	public MedicaidTotalPaymentWrapper getMedicaidTotalPayment(MedicaidTotalPaymentWrapper wrapper) {
		MedicaidTotalPaymentWrapper medicaidTotalPaymentWrapper = new MedicaidTotalPaymentWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/mdcd/asr/detail/"
						+ wrapper.getAsrDbid() + "/MDCDTOTALPYMT" + "?userId=" + wrapper.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				medicaidTotalPaymentWrapper = (MedicaidTotalPaymentWrapper) response
						.readEntity(MedicaidTotalPaymentWrapper.class);
				logger.debug("getMedicaidTotalPayment REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return medicaidTotalPaymentWrapper;
	}

	@POST
	@Path("/caseMgmtSearch")
	@Produces({ "application/json" })
	public ASRSearchWrapper getCaseMgmtSearch(String pSearchRequest) {
		ASRSearchWrapper asrSearchWrapper = new ASRSearchWrapper();
		logger.debug("Calling the Rest Webservice : UnifiedPortalRestService.getCaseMgmtSearch() - " + pSearchRequest);
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceSearch = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/search");
				Response responseSearch = webResourceSearch.request().accept(new String[] { "application/json" })
						.header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.post(Entity.entity(pSearchRequest, MediaType.APPLICATION_JSON));
				if (responseSearch.getStatus() != 200) {
					responseSearch.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseSearch.getStatus());
				}
				asrSearchWrapper = (ASRSearchWrapper) responseSearch.readEntity(ASRSearchWrapper.class);
				logger.debug("Case Mgmt Search REST Output from Server .... \n");
				responseSearch.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return asrSearchWrapper;
	}

	@POST
	@Path("/infoModelMdcr")
	@Produces({ "application/json" })
	public ASRSearchWrapper getinfoModelMdcr(InfoModelListReqWrapper infoModelDetails) {
		ASRSearchWrapper asrSearchWrapper = new ASRSearchWrapper();
		logger.debug("Calling the Rest Webservice : UnifiedPortalRestService.getinfoModelMdcr() - " + infoModelDetails);
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceSearch = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/search/latest/"
				+ infoModelDetails.getInfoModel() + "/" + infoModelDetails.getInfoDate()+ "?userId="
				+ infoModelDetails.getUserId());
				logger.debug(String.valueOf(ucmUrlStr) + "/rest/asr/search/latest/"
				+ infoModelDetails.getInfoModel() + "/" + infoModelDetails.getInfoDate()+ "?userId="
				+ infoModelDetails.getUserId());
				Response responseSearch = webResourceSearch.request().accept(new String[] { "application/json" })
						.header("Content-Type", "application/json")
						.post(Entity.entity(infoModelDetails, MediaType.APPLICATION_JSON));
				if (responseSearch.getStatus() != 200) {
					responseSearch.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseSearch.getStatus());
				}
				asrSearchWrapper = (ASRSearchWrapper) responseSearch.readEntity(ASRSearchWrapper.class);
				logger.debug("Case Mgmt Search REST Output from Server .... \n");
				responseSearch.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return asrSearchWrapper;
	}

	@POST
	@Path("/infoModelMdcd")
	@Produces({ "application/json" })
	public ASRSearchWrapper getinfoModelMdcd(InfoModelListReqWrapper infoModelDetails) {
		ASRSearchWrapper asrSearchWrapper = new ASRSearchWrapper();
		logger.debug("Calling the Rest Webservice : UnifiedPortalRestService.getinfoModelMdcr() - " + infoModelDetails);
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceSearch = client.target(String.valueOf(ucmUrlStr) + "/rest/mdcd/asr/search/latest/"
				+ infoModelDetails.getInfoModel() + "/" + infoModelDetails.getInfoDate()+ "?userId="
				+ infoModelDetails.getUserId());
				logger.debug(String.valueOf(ucmUrlStr) + "/rest/asr/search/latest/"
				+ infoModelDetails.getInfoModel() + "/" + infoModelDetails.getInfoDate()+ "?userId="
				+ infoModelDetails.getUserId());
				Response responseSearch = webResourceSearch.request().accept(new String[] { "application/json" })
						.header("Content-Type", "application/json")
						.post(Entity.entity(infoModelDetails, MediaType.APPLICATION_JSON));
				if (responseSearch.getStatus() != 200) {
					responseSearch.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseSearch.getStatus());
				}
				asrSearchWrapper = (ASRSearchWrapper) responseSearch.readEntity(ASRSearchWrapper.class);
				logger.debug("Case Mgmt Search REST Output from Server .... \n");
				responseSearch.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return asrSearchWrapper;
	}

	@POST
	@Path("/querySummaryModalData")
	@Produces({ "application/json" })
	public SummaryModalsResponseWrapper getSummaryModalData(SummaryModalsRequestWrapper pSummaryModalReq) {
		logger.debug("Calling the Rest Webservice : UnifiedPortalRestService.getSummaryModalData() - "
				+ pSummaryModalReq.getAsrptId());
		SummaryModalsResponseWrapper oSummaryModalResponse = new SummaryModalsResponseWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(
						String.valueOf(ucmUrlStr) + "/rest/asr/search/" + pSummaryModalReq.getAsrptId() + "?userId="
								+ pSummaryModalReq.getUserId() + "&link=" + pSummaryModalReq.getLinkType());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oSummaryModalResponse = (SummaryModalsResponseWrapper) response
						.readEntity(SummaryModalsResponseWrapper.class);
				logger.debug("getSummaryModalData REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oSummaryModalResponse;
	}

	@POST
	@Path("/queryMDCDSummaryModalData")
	@Produces({ "application/json" })
	public AsrDetailsWrapper getMDCDSummaryModalData(SummaryModalsRequestWrapper pSummaryModalReq) {
		logger.debug("Calling the Rest Webservice : UnifiedPortalRestService.getMDCDSummaryModalData() - "
				+ pSummaryModalReq.getAsrptId());
		AsrDetailsWrapper oSummaryModalResponse = new AsrDetailsWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client
						.target(String.valueOf(ucmUrlStr) + "/rest/mdcd/asr/detail/" + pSummaryModalReq.getAsrptId()
								+ "/" + pSummaryModalReq.getLinkType() + "?userId=" + pSummaryModalReq.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oSummaryModalResponse = (AsrDetailsWrapper) response.readEntity(AsrDetailsWrapper.class);
				logger.debug("getSummaryModalData REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oSummaryModalResponse;
	}

	@POST
	@Path("/queryMasterAlertClaims")
	@Produces({ "application/json" })
	public List<MasterClaimsResponseWrapper> getQueryMasterAlertClaims(MasterClaimsRequestWrapper pMasterClaimsReq) {
		List<MasterClaimsResponseWrapper> oMasterClaimsResponse = null;
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {

				String wsURL = String.valueOf(ucmUrlStr) + "/rest/asr/claims/" + pMasterClaimsReq.getModelId() + "/"
						+ pMasterClaimsReq.getNpi();
				if (pMasterClaimsReq.getInsertDt() != null) {
					logger.debug("insertDt is NOT null");
					wsURL = String.valueOf(wsURL) + "/" + pMasterClaimsReq.getInsertDt() + "?userId="
							+ pMasterClaimsReq.getUserId();
				} else {
					logger.debug("insertDt is null");
					wsURL = String.valueOf(wsURL) + "?userId=" + pMasterClaimsReq.getUserId();
				}
				Client client = buildClientConfig();
				WebTarget webResource = client.target(wsURL);
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200) {
					String responseStatus = response.getStatusInfo().getReasonPhrase();
					response.close();
					throw new RuntimeException("QueryMasterClaimLines Failed : HTTP error code : " + responseStatus);
				}
				oMasterClaimsResponse = (List<MasterClaimsResponseWrapper>) response
						.readEntity(new GenericType<List<MasterClaimsResponseWrapper>>() {
						});
				logger.debug("Get Master Claim Lines REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oMasterClaimsResponse;
	}

	@POST
	@Path("/prioritizeForUCMTable")
	@Produces({ "application/json" })
	public List<AvailableModelsResp> getPrioritizeForUCMTable(AvailableModelsReq availableModelsReq) {
		List<AvailableModelsResp> availableModelsResp = new ArrayList<AvailableModelsResp>();
		logger.debug("Inside getPrioritizeForUCMTable ");
		try {
			logger.debug("ASR ID " + availableModelsReq.getAsrptIds().toArray());
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				String urlString = "/rest/asr/availablemodels";
				if (availableModelsReq.getProgramType() != null) {
					if (availableModelsReq.getProgramType().equals("medicaid")) {
						urlString = "/rest/mdcd/asr/availablemodels";
						logger.debug("------------inside the get program type conditional-----------------");
					}
					logger.debug("------------here is the url being sent to the webresource " + ucmUrlStr + urlString);
				}
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + urlString);
				Response response = webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json")
						.post(Entity.entity(availableModelsReq, MediaType.APPLICATION_JSON));
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				availableModelsResp = (List<AvailableModelsResp>) response
						.readEntity(new GenericType<List<AvailableModelsResp>>() {
						});
				logger.debug("Query Available Models  REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
			e1.printStackTrace();
		}
		return availableModelsResp;
	}

	@POST
	@Path("/queryPriorUcmZones")
	@Produces({ "application/json" })
	public RefDataWrapper getQueryPrioritiyZones(String pAlertsRequest) {
		RefDataWrapper oZonesResponse = new RefDataWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceSearch = client.target(String.valueOf(ucmUrlStr) + "/rest/refdata/PRIORITIZE");
				Response responseSearch = (Response) webResourceSearch.request()
						.accept(new String[] { "application/json" }).header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.get(Response.class);
				if (responseSearch.getStatus() != 200) {
					responseSearch.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseSearch.getStatus());
				}
				oZonesResponse = (RefDataWrapper) responseSearch.readEntity(RefDataWrapper.class);
				logger.debug("Query Prioritize UCM Zones REST Output from Server .... \n");
				responseSearch.close();
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oZonesResponse;
	}

	@POST
	@Path("/queryAllAlerts")
	@Produces({ "application/json" })
	public AlertsWrapper getQueryAllAlerts(AlertsReqWrapper pAlertsRequest) {
		logger.debug("Inside UnifiedPortalRestService.getQueryAllAlerts().");
		AlertsWrapper alertsWrapper = null;
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceSearch = client.target(
						String.valueOf(ucmUrlStr) + "/rest/refdata/ASRLEVEL?userId=" + pAlertsRequest.getUserId());
				Response responseSearch = (Response) webResourceSearch.request()
						.accept(new String[] { "application/json" }).header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.get(Response.class);
				if (responseSearch.getStatus() != 200) {
					responseSearch.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseSearch.getStatus());
				}
				alertsWrapper = (AlertsWrapper) responseSearch.readEntity(AlertsWrapper.class);
				logger.debug("Case Mgmt Search REST Output from Server .... \n");
				responseSearch.close();
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return alertsWrapper;
	}

	@POST
	@Path("/adminMsgsData")
	@Produces({ "application/json" })
	public AdminMsgsRespWrapper getAdminMessages(AdminMsgsReqWrapper pAdminMsgsRequest) {
		AdminMsgsRespWrapper oAdminMsgsResponse = new AdminMsgsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/landingpage/messages");
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oAdminMsgsResponse = (AdminMsgsRespWrapper) response.readEntity(AdminMsgsRespWrapper.class);
				logger.debug("Case Mgmt Admin Sys Msgs REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oAdminMsgsResponse;
	}

	@POST
	@Path("/drillClaims")
	@Produces({ "application/json" })
	public DrillClaimsRespWrapper getDrillClaims(DrillClaimsReqWrapper pDrillClaimsReq) {
		DrillClaimsRespWrapper oDrillClaimsRep = new DrillClaimsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client
						.target(String.valueOf(ucmUrlStr) + "/rest/asr/rptcard/" + pDrillClaimsReq.getModelId() + "/"
								+ pDrillClaimsReq.getNpi() + "/claims/" + pDrillClaimsReq.getAttrSqncNum());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oDrillClaimsRep = (DrillClaimsRespWrapper) response.readEntity(DrillClaimsRespWrapper.class);
				logger.debug("Drill Claims REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oDrillClaimsRep;
	}

	@POST
	@Path("/queryAllZones")
	@Produces({ "application/json" })
	public RefDataWrapper getQueryAllZones(RefDataReqWrapper pZonesRequest) {
		logger.debug("Inside UnifiedPortalRestService.getQueryAllZones(). Rest Request= " + pZonesRequest.getUserId());
		RefDataWrapper oZonesResponse = new RefDataWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceSearch = client
						.target(String.valueOf(ucmUrlStr) + "/rest/refdata/SEARCH?userId=" + pZonesRequest.getUserId());
				Response responseSearch = (Response) webResourceSearch.request()
						.accept(new String[] { "application/json" }).header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.get(Response.class);
				if (responseSearch.getStatus() != 200) {
					responseSearch.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseSearch.getStatus());
				}
				oZonesResponse = (RefDataWrapper) responseSearch.readEntity(RefDataWrapper.class);
				logger.debug("Case Mgmt Search REST Output from Server .... \n");
				responseSearch.close();
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oZonesResponse;
	}

	@POST
	@Path("/partdClaimLinesData")
	@Produces({ "application/json" })
	public PartdDlaimLinesRespWrapper getPartdDlaimLines(PartdDlaimLinesReqWrapper pPartDDataReq) {
		PartdDlaimLinesRespWrapper oPartDDataResp = new PartdDlaimLinesRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client
						.target(String.valueOf(ucmUrlStr) + "/rest/asr/claims/partd/" + pPartDDataReq.getModelId() + "/"
								+ pPartDDataReq.getAsrptId() + "?userId=" + pPartDDataReq.getUserId());
				Response response = webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get();
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				ObjectMapper mapper = new ObjectMapper();
				List<PartDClaimLines> partDClaimLinesArray = (List<PartDClaimLines>) mapper.readValue("",
						new TypeReference<List<PartDClaimLines>>() {

						});
				oPartDDataResp.setResponse(partDClaimLinesArray);
				logger.debug("Part D Claim Lines REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException ioe) {
			logger.error(ioe.getMessage(), ioe);
		}
		return oPartDDataResp;
	}

	@POST
	@Path("/readMessages")
	@Produces({ "application/json" })
	public ReadMsgsRespWrapper getMsgsAsReadByUser(ReadMsgsReqWrapper pLandPageDataReq) {
		ReadMsgsRespWrapper oReadMsgsResponse = new ReadMsgsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/landingpage/messages/read/"
						+ verifyUser(pLandPageDataReq.getUserId()));
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oReadMsgsResponse.setValidResponse("true");
				logger.debug("Assign ASRs REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException ioe) {
			logger.error(ioe.getMessage(), ioe);
		}
		return oReadMsgsResponse;
	}

	@POST
	@Path("/queryLandPageData")
	@Produces({ "application/json" })
	public LandingPageWrapper getQueryLandPageData(LandingPageRequestWrapper pLandPageDataReq) {
		logger.debug("Inside UnifiedPortalRestService.getQueryLandPageData(). UserId= " + pLandPageDataReq.getUserId()
				+ ". UserZone = " + pLandPageDataReq.getUserZone());
		LandingPageWrapper landingPageWrapper = new LandingPageWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				if (pLandPageDataReq.getUserZone() != null) {
					if (pLandPageDataReq.getUserZone().matches(".*\\s+.*")) {
						String tempUrlStr = URLEncoder.encode(pLandPageDataReq.getUserZone(), "UTF-8").replaceAll("\\+",
								"%20");
						pLandPageDataReq.setUserZone(tempUrlStr);
					}
				} else {
					pLandPageDataReq.setUserZone("0");
				}
				Client client = buildClientConfig();
				WebTarget webResourceSearch = client.target(String.valueOf(ucmUrlStr) + "/rest/landingpage/"
						+ verifyUser(pLandPageDataReq.getUserId()) + "/" + pLandPageDataReq.getUserZone());
				Response responseSearch = webResourceSearch.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (responseSearch.getStatus() != 200 && responseSearch.getStatus() != 202) {
					responseSearch.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseSearch.getStatus());
				}
				landingPageWrapper = (LandingPageWrapper) responseSearch.readEntity(LandingPageWrapper.class);
				logger.debug("Query Landing Page Data REST Output from Server .... \n");
				responseSearch.close();
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return landingPageWrapper;
	}

	@POST
	@Path("/asrMapsInfo")
	@Produces({ "application/json" })
	public ASRMapsRespWrapper getAsrMapsData(ASRMapsReqWrapper pAsrMapsReq) {
		logger.debug("Inside UnifiedPortalRestService.getAsrMapsData(). Rest Request= " + pAsrMapsReq);
		ASRMapsRespWrapper oAsrMapsResp = new ASRMapsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client
						.target(String.valueOf(ucmUrlStr) + "/rest/asr/detail/" + pAsrMapsReq.getAsrptId() + "/MAPS/"
								+ pAsrMapsReq.getResultsIndex() + "?userId=" + pAsrMapsReq.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oAsrMapsResp = (ASRMapsRespWrapper) response.readEntity(ASRMapsRespWrapper.class);
				logger.debug("ASR Benes REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oAsrMapsResp;
	}

	@POST
	@Path("/modelBenes")
	@Produces({ "application/json" })
	public List<BeneModelRespWrapper> getModelBenesData(BeneModelReqWrapper pBeneModelReq) {
		logger.debug("Inside UnifiedPortalRestService.getModelBenesData(). Rest Request= " + pBeneModelReq);
		List<BeneModelRespWrapper> oBeneList = new ArrayList<BeneModelRespWrapper>();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/"
						+ pBeneModelReq.getAsrptId() + "/alert/" + pBeneModelReq.getModelId() + "/benes");
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oBeneList = (List<BeneModelRespWrapper>) response
						.readEntity(new GenericType<List<BeneModelRespWrapper>>() {
						});
				logger.debug("ASR Details REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oBeneList;
	}

	@POST
	@Path("/subscribe")
	@Produces({ "application/json" })
	public SubscribeRespWrapper getSubscribe(SubscribeReqWrapper pSubscribeReq) {
		SubscribeRespWrapper oSubscribeResp = new SubscribeRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {

				pSubscribeReq.setType("WATCHLIST");
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/service/subscribe");
				Response response = webResource.request().accept(new String[] { "application/json" })
						.header("Content-Type", "application/json").header("Accept-API-Version", "resource=3.0")
						.header("Authorization", "Bearer " + getToken())
						.post(Entity.entity(pSubscribeReq, MediaType.APPLICATION_JSON));

				if (response.getStatus() != 200) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oSubscribeResp = (SubscribeRespWrapper) response.readEntity(SubscribeRespWrapper.class);
				logger.debug("Subscribe REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oSubscribeResp;
	}

	@POST
	@Path("/asrMdcdDetails")
	@Produces({ "application/json" })
	public AsrDetailsWrapper getQueryASRMdcdDetailsData(@Context HttpHeaders headers,
			ASRDetailsInitReqWrapper pAsrDetailsReq) {
		logger.debug("Inside UnifiedPortalRestService.getQueryASRMdcdDetailsData().");
		AsrDetailsWrapper asrDetailsWrapper = new AsrDetailsWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				logger.debug("asrId Parameter = " + pAsrDetailsReq.getAsrId());
				logger.debug("searchType Parameter = " + pAsrDetailsReq.getSearchType());

				WebTarget webResourceDetails = client
						.target(String.valueOf(ucmUrlStr) + "/rest/mdcd/asr/detail/" + pAsrDetailsReq.getAsrId() + "/"
								+ pAsrDetailsReq.getSearchType() + "?userId=" + pAsrDetailsReq.getUserId());
				Response responseDetails = (Response) webResourceDetails.request()
						.accept(new String[] { "application/json" }).header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.get(Response.class);
				if (responseDetails.getStatus() != 200) {
					responseDetails.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseDetails.getStatus());
				}
				asrDetailsWrapper = (AsrDetailsWrapper) responseDetails.readEntity(AsrDetailsWrapper.class);
				logger.debug("getQueryASRMdcdDetailsDatas REST Output from Server .... \n");
				responseDetails.close();
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return asrDetailsWrapper;
	}

	@POST
	@Path("/asrDetails")
	@Produces({ "application/json" })
	public AsrDetailsWrapper getQueryASRDetailsData(@Context HttpHeaders headers,
			ASRDetailsInitReqWrapper pAsrDetailsReq) {
		logger.debug("Inside UnifiedPortalRestService.getQueryLandPageData().");
		AsrDetailsWrapper asrDetailsWrapper = new AsrDetailsWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {

				logger.debug("asrId Parameter = " + pAsrDetailsReq.getAsrId());
				logger.debug("searchType Parameter = " + pAsrDetailsReq.getSearchType());

				String urlPath = "/rest/asr/detail/";
				Client client = buildClientConfig();
				WebTarget webResourceDetails = client
						.target(String.valueOf(ucmUrlStr) + urlPath + pAsrDetailsReq.getAsrId() + "/"
								+ pAsrDetailsReq.getSearchType() + "?userId=" + pAsrDetailsReq.getUserId());
				Response responseDetails = (Response) webResourceDetails.request()
						.accept(new String[] { "application/json" }).header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.get(Response.class);
				if (responseDetails.getStatus() != 200) {
					responseDetails.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseDetails.getStatus());
				}
				asrDetailsWrapper = (AsrDetailsWrapper) responseDetails.readEntity(AsrDetailsWrapper.class);
				logger.debug("ASR Details REST Output from Server .... \n");
				responseDetails.close();
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return asrDetailsWrapper;
	}

	@POST
	@Path("/reportCard")
	@Produces({ "application/json" })
	public ReportCardResponseWrapper getQueryReportCards(ReportCardRequestWrapper pReportCardRequest) {
		ReportCardResponseWrapper rprtCardRespWrapper = new ReportCardResponseWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				String wsURL = String.valueOf(ucmUrlStr) + "/rest/asr/rptcard/" + pReportCardRequest.getModelId() + "/"
						+ pReportCardRequest.getNpi();
				if (pReportCardRequest.gettableId() != null) {
					wsURL = String.valueOf(wsURL) + "/viz/" + pReportCardRequest.gettableId()+ "?userId=" + pReportCardRequest.getUserId();
				} else{
					if (pReportCardRequest.getInsertDt() != null) {
						logger.debug("insertDt is NOT null");
						wsURL = String.valueOf(wsURL) + "/" + pReportCardRequest.getInsertDt() + "?userId="
								+ pReportCardRequest.getUserId();
					} else {
						logger.debug("insertDt is null");
						wsURL = String.valueOf(wsURL) + "?userId=" + pReportCardRequest.getUserId();
					}
			      }
				WebTarget webResourceReportCard = client.target(wsURL.toString());
				Response responseReportCard = (Response) webResourceReportCard.request()
						.accept(new String[] { "application/json" }).header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.get(Response.class);
				if (responseReportCard.getStatus() != 200 && responseReportCard.getStatus() != 202) {
					responseReportCard.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseReportCard.getStatus() + ": "
							+ responseReportCard.getStatusInfo().getReasonPhrase());
				}
				rprtCardRespWrapper = (ReportCardResponseWrapper) responseReportCard
						.readEntity(ReportCardResponseWrapper.class);
				logger.debug("Report Card REST Output returned from server.");
				responseReportCard.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return rprtCardRespWrapper;
	}

	@POST
	@Path("/mdcdReportCard")
	@Produces({ "application/json" })
	public ReportCardResponseWrapper getQueryMdcdReportCards(ReportCardRequestWrapper pReportCardRequest) {
		ReportCardResponseWrapper rprtCardRespWrapper = new ReportCardResponseWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("Inside getQueryMdcdReportCards ");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				String wsURL = String.valueOf(ucmUrlStr) + "/rest/mdcd/asr/rptcard/" + pReportCardRequest.getModelId()
						+ "/" + pReportCardRequest.getNpi() + "/" + pReportCardRequest.getState();
				if (pReportCardRequest.gettableId() != null) {
					wsURL = String.valueOf(wsURL) + "/viz/" + pReportCardRequest.gettableId()+ "?userId=" + pReportCardRequest.getUserId();
				}
				else{
					if (pReportCardRequest.getInsertDt() != null) {
					logger.debug("insertDt is NOT null");
					wsURL = String.valueOf(wsURL) + "/" + pReportCardRequest.getInsertDt() + "?userId="
							+ pReportCardRequest.getUserId();
					} else {
						logger.debug("insertDt is null");
						wsURL = String.valueOf(wsURL) + "?userId=" + pReportCardRequest.getUserId();
					}
				} 
				WebTarget webResourceReportCard = client.target(wsURL.toString());
				Response responseReportCard = (Response) webResourceReportCard.request()
						.accept(new String[] { "application/json" }).header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.get(Response.class);
				if (responseReportCard.getStatus() != 200 && responseReportCard.getStatus() != 202) {
					responseReportCard.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseReportCard.getStatus() + ": "
							+ responseReportCard.getStatusInfo().getReasonPhrase());
				}
				rprtCardRespWrapper = (ReportCardResponseWrapper) responseReportCard
						.readEntity(ReportCardResponseWrapper.class);
				logger.debug("Report Card REST Output returned from server.");
				responseReportCard.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return rprtCardRespWrapper;
	}

	@POST
	@Path("/nonAlertAsrs")
	@Produces({ "application/json" })
	public NonAlertAsrsRespWrapper getNonAlertedAsrs(NonAlertAsrsReqWrapper pNonAlertAsrsReq) {
		NonAlertAsrsRespWrapper oNonAlertAsrsRespWrapper = new NonAlertAsrsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/detail/"
						+ pNonAlertAsrsReq.getAsrptId() + "/NAPS?userId=" + pNonAlertAsrsReq.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oNonAlertAsrsRespWrapper = (NonAlertAsrsRespWrapper) response.readEntity(NonAlertAsrsRespWrapper.class);
				logger.debug("Non-Alerted ASR Data REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oNonAlertAsrsRespWrapper;
	}

	@POST
	@Path("/relatedAsrs")
	@Produces({ "application/json" })
	public RelatedAsrsRespWrapper getRelatedAsrs(RelatedAsrsReqWrapper pRelatedAsrsReq) {
		RelatedAsrsRespWrapper oRelatedAsrsRespWrapper = new RelatedAsrsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/detail/"
						+ pRelatedAsrsReq.getAsrptId() + "/RELATEDASRS?userId=" + pRelatedAsrsReq.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oRelatedAsrsRespWrapper = (RelatedAsrsRespWrapper) response.readEntity(RelatedAsrsRespWrapper.class);
				logger.debug("Related ASRs Data REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oRelatedAsrsRespWrapper;
	}

	@POST
	@Path("/totalPayment")
	@Produces({ "application/json" })
	public TotalPaymentRespWrapper getTotalPayment(TotalPaymentReqWrapper pTotalPaymentReq) {
		TotalPaymentRespWrapper oTotalPaymentResp = new TotalPaymentRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/detail/"
						+ pTotalPaymentReq.getAsrptId() + "/TOTALZNPYMT?userId=" + pTotalPaymentReq.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oTotalPaymentResp = (TotalPaymentRespWrapper) response.readEntity(TotalPaymentRespWrapper.class);
				logger.debug("History Tab Data REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oTotalPaymentResp;
	}

	@POST
	@Path("/tabDataHistory")
	@Produces({ "application/json" })
	public HistoryTabResponseWrapper getQueryTabDataHistory(HistoryTabRequestWrapper pHistoryTabDataRequest) {
		HistoryTabResponseWrapper oHistoryTabRespWrapper = new HistoryTabResponseWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceTabDataHistory = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/detail/"
						+ pHistoryTabDataRequest.getAsrptId() + "/history");
				Response responseTabDataHistory = (Response) webResourceTabDataHistory.request()
						.accept(new String[] { "application/json" }).header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.get(Response.class);
				if (responseTabDataHistory.getStatus() != 200 && responseTabDataHistory.getStatus() != 202) {
					responseTabDataHistory.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseTabDataHistory.getStatus() + ": "
							+ responseTabDataHistory.getStatusInfo().getReasonPhrase());
				}
				oHistoryTabRespWrapper = (HistoryTabResponseWrapper) responseTabDataHistory
						.readEntity(HistoryTabResponseWrapper.class);
				logger.debug("History Tab Data REST Output from Server .... \n");
				responseTabDataHistory.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oHistoryTabRespWrapper;
	}

	@POST
	@Path("/tabDataTotalZoneCost")
	@Produces({ "application/json" })
	public TotalZnCostRespWrapper getQueryTabDataTotalZnCost(TotalZnCostReqWrapper pTotalZnCostRequest) {
		TotalZnCostRespWrapper oTotalZnCostRespWrapper = new TotalZnCostRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/detail/"
						+ pTotalZnCostRequest.getAsrptId() + "/totalzncost?userId=" + pTotalZnCostRequest.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oTotalZnCostRespWrapper = (TotalZnCostRespWrapper) response.readEntity(TotalZnCostRespWrapper.class);
				logger.debug("Total Cost Zone Tab Data REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oTotalZnCostRespWrapper;
	}

	@POST
	@Path("/tabDatap1TotalZoneCost")
	@Produces({ "application/json" })
	public TotalZnCostRespWrapper getQueryTabDatap1TotalZnCost(TotalZnCostReqWrapper pTotalZnCostRequest) {
		TotalZnCostRespWrapper oTotalZnCostRespWrapper = new TotalZnCostRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/detail/"
						+ pTotalZnCostRequest.getAsrptId() + "/P1TOTALZNCOST?userId=" + pTotalZnCostRequest.getUserId());
						logger.debug("webResource" + webResource);
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oTotalZnCostRespWrapper = (TotalZnCostRespWrapper) response.readEntity(TotalZnCostRespWrapper.class);
				logger.debug("Total Cost Zone Tab Data REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oTotalZnCostRespWrapper;
	}

	@POST
	@Path("/reportFavorites")
	@Produces({ "application/json" })
	public ReportFavsRespWrapper getReportFavs(ReportFavsReqWrapper pReportFavsReq) {
		ReportFavsRespWrapper oReportFavsResp = new ReportFavsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/landingpage/reports/"
						+ verifyUser(pReportFavsReq.getUserId()) + "/"
						+ pReportFavsReq.getUserZone().replaceAll(" ", "%20"));
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oReportFavsResp = (ReportFavsRespWrapper) response.readEntity(ReportFavsRespWrapper.class);
				logger.debug("SysTags Tab Data REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oReportFavsResp;
	}

	@POST
	@Path("/tabDataSysTags")
	@Produces({ "application/json" })
	public SysTagsTabRespWrapper getQueryTabDataSysTags(SysTagsTabReqWrapper pSysTagsTabDataRequest) {
		SysTagsTabRespWrapper oSysTagsTabRespWrapper = new SysTagsTabRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceTabDataSysTags = client
						.target(String.valueOf(ucmUrlStr) + "/rest/asr/detail/" + pSysTagsTabDataRequest.getAsrptId()
								+ "/systags?userId=" + pSysTagsTabDataRequest.getUserId());
				Response responseTabDataSysTags = (Response) webResourceTabDataSysTags.request()
						.accept(new String[] { "application/json" }).header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.get(Response.class);
				if (responseTabDataSysTags.getStatus() != 200 && responseTabDataSysTags.getStatus() != 202) {
					responseTabDataSysTags.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseTabDataSysTags.getStatus() + ": "
							+ responseTabDataSysTags.getStatusInfo().getReasonPhrase());
				}
				oSysTagsTabRespWrapper = (SysTagsTabRespWrapper) responseTabDataSysTags
						.readEntity(SysTagsTabRespWrapper.class);
				logger.debug("SysTags Tab Data REST Output from Server .... \n");
				responseTabDataSysTags.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oSysTagsTabRespWrapper;
	}

	@POST
	@Path("/tabDataClaims")
	@Produces({ "application/json" })
	public ClaimsTabResponseWrapper getQueryTabDataClaims(ClaimsTabRequestWrapper pClaimsTabDataRequest) {
		ClaimsTabResponseWrapper oClaimsTabRespWrapper = new ClaimsTabResponseWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceTabDataClaims = client
						.target(String.valueOf(ucmUrlStr) + "/rest/asr/detail/" + pClaimsTabDataRequest.getAsrptId()
								+ "/claimlines?userId=" + pClaimsTabDataRequest.getUserId());
				Response responseTabDataClaims = (Response) webResourceTabDataClaims.request()
						.accept(new String[] { "application/json" }).header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.get(Response.class);
				if (responseTabDataClaims.getStatus() != 200 && responseTabDataClaims.getStatus() != 202) {
					responseTabDataClaims.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseTabDataClaims.getStatus() + ": "
							+ responseTabDataClaims.getStatusInfo().getReasonPhrase());
				}
				oClaimsTabRespWrapper = (ClaimsTabResponseWrapper) responseTabDataClaims
						.readEntity(ClaimsTabResponseWrapper.class);
				logger.debug("Claims Tab Data REST Output from Server .... \n");
				responseTabDataClaims.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oClaimsTabRespWrapper;
	}

	@POST
	@Path("/tabDataNotes")
	@Produces({ "application/json" })
	public NotesTabResponseWrapper getQueryTabDataNotes(NotesTabRequestWrapper pNotesTabDataRequest) {
		NotesTabResponseWrapper oNotesTabRespWrapper = new NotesTabResponseWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceTabDataNotes = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/detail/"
						+ pNotesTabDataRequest.getAsrptId() + "/notes?userId=" + pNotesTabDataRequest.getUserId());
				Response responseTabDataNotes = (Response) webResourceTabDataNotes.request()
						.accept(new String[] { "application/json" }).header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.get(Response.class);
				if (responseTabDataNotes.getStatus() != 200 && responseTabDataNotes.getStatus() != 202) {
					responseTabDataNotes.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseTabDataNotes.getStatus() + ": "
							+ responseTabDataNotes.getStatusInfo().getReasonPhrase());
				}
				oNotesTabRespWrapper = (NotesTabResponseWrapper) responseTabDataNotes
						.readEntity(NotesTabResponseWrapper.class);
				logger.debug("Notes Tab Data REST Output from Server .... \n");
				responseTabDataNotes.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oNotesTabRespWrapper;
	}

	@POST
	@Path("/tabDataPartDReports")
	@Produces({ "application/json" })
	public PartDReportsTabResponseWrapper getQueryTabDataPartDReports(
			PartDReportsTabRequestWrapper pPartDRprtTabDataReq) {
		PartDReportsTabResponseWrapper oPartDRprtTabDataResp = new PartDReportsTabResponseWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/detail/"
						+ pPartDRprtTabDataReq.getAsrptId() + "/partd?userId=" + pPartDRprtTabDataReq.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				AsrDetailsWrapper asrDetailsWrapper = new AsrDetailsWrapper();
				asrDetailsWrapper = (AsrDetailsWrapper) response.readEntity(AsrDetailsWrapper.class);
				ResponseData partdResponseData = new ResponseData();
				partdResponseData.setPartD(asrDetailsWrapper.getResponseData().getPartD());
				oPartDRprtTabDataResp.setResponseData(partdResponseData);
				logger.debug("Prioritize for UCM Tab Data REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oPartDRprtTabDataResp;
	}

	@POST
	@Path("/tabDataPrioritizeUCM")
	@Produces({ "application/json" })
	public PrioritizeUCMTabResponseWrapper getQueryTabDataPrioritizeUCM(
			PrioritizeUCMTabRequestWrapper pPrioritizeUCMTabDataRequest) {
		PrioritizeUCMTabResponseWrapper oPrioritizeUCMTabRespWrapper = new PrioritizeUCMTabResponseWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				String urlFrag = "/rest/asr/detail/";
				if ("medicaid".equals(pPrioritizeUCMTabDataRequest.getProgramType()))
					urlFrag = "/rest/mdcd/asr/detail/";
				WebTarget webResource = client
						.target(String.valueOf(ucmUrlStr) + urlFrag + pPrioritizeUCMTabDataRequest.getAsrptId()
								+ "/priority?userId=" + pPrioritizeUCMTabDataRequest.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oPrioritizeUCMTabRespWrapper = (PrioritizeUCMTabResponseWrapper) response
						.readEntity(PrioritizeUCMTabResponseWrapper.class);
				logger.debug("Prioritize for UCM Tab Data REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oPrioritizeUCMTabRespWrapper;
	}

	@POST
	@Path("/tabDataLeads")
	@Produces({ "application/json" })
	public LeadsTabResponseWrapper getQueryTabDataLeads(LeadsTabRequestWrapper pLeadsTabDataRequest) {
		LeadsTabResponseWrapper oLeadsTabRespWrapper = new LeadsTabResponseWrapper();
		try {
			String urlFrag = "/rest/asr/detail/";
			if ("medicaid".equals(pLeadsTabDataRequest.getProgramType()))
				urlFrag = "/rest/mdcd/asr/detail/";
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceTabDataLead = client.target(String.valueOf(ucmUrlStr) + urlFrag
						+ pLeadsTabDataRequest.getAsrptId() + "/leads?userId=" + pLeadsTabDataRequest.getUserId());
				Response responseTabDataLead = (Response) webResourceTabDataLead.request()
						.accept(new String[] { "application/json" }).header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.get(Response.class);
				if (responseTabDataLead.getStatus() != 200 && responseTabDataLead.getStatus() != 202) {
					responseTabDataLead.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseTabDataLead.getStatus() + ": "
							+ responseTabDataLead.getStatusInfo().getReasonPhrase());
				}
				oLeadsTabRespWrapper = (LeadsTabResponseWrapper) responseTabDataLead
						.readEntity(LeadsTabResponseWrapper.class);
				logger.debug("Lead Tab Data REST Output from Server .... \n");
				responseTabDataLead.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oLeadsTabRespWrapper;
	}

	@POST
	@Path("/tabDataEdits")
	@Produces({ "application/json" })
	public EditsTabResponseWrapper getQueryTabDataEdits(EditsTabRequestWrapper pEditsTabDataRequest) {
		EditsTabResponseWrapper oEditsTabRespWrapper = new EditsTabResponseWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceTabDataEdits = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/detail/"
						+ pEditsTabDataRequest.getAsrptId() + "/edits?userId=" + pEditsTabDataRequest.getUserId());
				Response responseTabDataEdits = (Response) webResourceTabDataEdits.request()
						.accept(new String[] { "application/json" }).header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.get(Response.class);
				if (responseTabDataEdits.getStatus() != 200 && responseTabDataEdits.getStatus() != 202) {
					responseTabDataEdits.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseTabDataEdits.getStatus() + ": "
							+ responseTabDataEdits.getStatusInfo().getReasonPhrase());
				}
				oEditsTabRespWrapper = (EditsTabResponseWrapper) responseTabDataEdits
						.readEntity(EditsTabResponseWrapper.class);
				logger.debug("Edits Tab Data REST Output from Server .... \n");
				responseTabDataEdits.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oEditsTabRespWrapper;
	}

	@POST
	@Path("/updateExSetVals")
	@Produces({ "application/json" })
	public ExDetailEditRespWrapper updateExclusionVals(ExDetailExclusion pUpdateCommentsReq) {
		ExDetailEditRespWrapper oUpdateCommentsResp = new ExDetailEditRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(
						String.valueOf(ucmUrlStr) + "/rest/provider/exclusions/" + pUpdateCommentsReq.getUserNm());
				Response response = webResource.request().accept(new String[] { "application/json" })
						.header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.post(Entity.entity(pUpdateCommentsReq, MediaType.APPLICATION_JSON));

				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oUpdateCommentsResp = (ExDetailEditRespWrapper) response.readEntity(ExDetailEditRespWrapper.class);
				logger.debug("Update Exclusion Set Details REST Output from Server .... \n");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oUpdateCommentsResp;
	}

	@POST
	@Path("/saveAdminSysMsgsData")
	@Produces({ "application/json" })
	public AdminSysMsgsRespWrapper getAdminSystemMessagesData(AdminSysMsgsReqWrapper pAdminSysMsgsRequest) {
		AdminSysMsgsRespWrapper oSysMsgsResponse = new AdminSysMsgsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webSystemMessage = client.target(String.valueOf(ucmUrlStr) + "/rest/landingpage/message/");
				Response responseSysMessage = webSystemMessage.request().accept(new String[] { "application/json" })
						.header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.post(Entity.entity(pAdminSysMsgsRequest, MediaType.APPLICATION_JSON));
				if (responseSysMessage.getStatus() != 200 && responseSysMessage.getStatus() != 202) {
					responseSysMessage.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseSysMessage.getStatus() + ": "
							+ responseSysMessage.getStatusInfo().getReasonPhrase());
				}
				oSysMsgsResponse = (AdminSysMsgsRespWrapper) responseSysMessage
						.readEntity(AdminSysMsgsRespWrapper.class);
				logger.debug("Add System Messages to DB REST Output from Server .... \n");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oSysMsgsResponse;
	}

	@POST
	@Path("/saveAdminModelsData")
	@Produces({ "application/json" })
	public AdminModelsRespWrapper getSaveAdminModelsData(AdminModelsReqWrapper pModelsReq) {
		AdminModelsRespWrapper oResponseModels = new AdminModelsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/landingpage/model/");
				Response Response = webResource.request().accept(new String[] { "application/json" })
						.header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.post(Entity.entity(pModelsReq, MediaType.APPLICATION_JSON));
				if (Response.getStatus() != 200 && Response.getStatus() != 202) {
					Response.close();
					throw new RuntimeException("Failed : HTTP error code : " + Response.getStatus() + ": "
							+ Response.getStatusInfo().getReasonPhrase());
				}
				oResponseModels = (AdminModelsRespWrapper) Response.readEntity(AdminModelsRespWrapper.class);
				logger.debug("Add Models to DB REST Output from Server .... \n");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oResponseModels;
	}

	@POST
	@Path("/retrieveUserPrefs")
	@Produces({ "application/json" })
	public UserPrefsRespWrapper getRetrieveUserPreferences(UserPrefsReqWrapper pUserPrefsReq) {
		UserPrefsRespWrapper oUserPrefsResponse = new UserPrefsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/preferences/"
						+ verifyUser(pUserPrefsReq.getUserId()) + "/" + pUserPrefsReq.getPrefName());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oUserPrefsResponse = (UserPrefsRespWrapper) response.readEntity(UserPrefsRespWrapper.class);
				logger.debug("Get user preferences REST Output from Server .... \n");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oUserPrefsResponse;
	}

	@POST
	@Path("/archiveList")
	@Produces({ "application/json" })
	public WorkItemsRespWrapper getArchiveList(ArchiveListReqWrapper pArchiveListReq) {
		WorkItemsRespWrapper oArchiveListResponse = new WorkItemsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/provider/lists/"
						+ pArchiveListReq.getGroupId() + "/archive/" + pArchiveListReq.getUserId());
				Response response = webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json")
						.post(Entity.entity(pArchiveListReq, MediaType.APPLICATION_JSON));
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oArchiveListResponse = (WorkItemsRespWrapper) response.readEntity(WorkItemsRespWrapper.class);
				logger.debug("Archive List Input Values REST Output from Server .... \n");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oArchiveListResponse;
	}

	@POST
	@Path("/deleteList")
	@Produces({ "application/json" })
	public WorkItemsRespWrapper getDeleteList(DeleteListReqWrapper pDeleteListReq) {
		WorkItemsRespWrapper oDeleteListResponse = new WorkItemsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				String webResourceURL = "";
				if ("asr".equals(pDeleteListReq.getListType())) {
					webResourceURL = "/rest/provider/lists/" + pDeleteListReq.getListId() + "?userId="
							+ pDeleteListReq.getUserId();
				} else {
					webResourceURL = "/rest/provider/searches/" + pDeleteListReq.getListId() + "?userId="
							+ pDeleteListReq.getUserId();
				}
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + webResourceURL);
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").delete(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oDeleteListResponse = (WorkItemsRespWrapper) response.readEntity(WorkItemsRespWrapper.class);
				logger.debug("Delete List Input Values REST Output from Server .... \n");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oDeleteListResponse;
	}

	@POST
	@Path("/deleteUserPrefs")
	@Produces({ "application/json" })
	public UserPrefsRespWrapper getDeleteUserPreferences(UserPrefsReqWrapper pUserPrefsReq) {
		UserPrefsRespWrapper oUserPrefsResponse = new UserPrefsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/preferences/"
						+ verifyUser(pUserPrefsReq.getUserId()) + "/" + pUserPrefsReq.getPrefName());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").delete(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oUserPrefsResponse.setUserId(pUserPrefsReq.getUserId());
				oUserPrefsResponse.setPrefName(pUserPrefsReq.getPrefName());
				oUserPrefsResponse.setPrefJson("[]");
				logger.debug("Delete user preferences REST Output from Server .... \n");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oUserPrefsResponse;
	}

	@POST
	@Path("/editSearchCriteria")
	@Produces({ "application/json" })
	public SearchCriteriaRespWrapper getEditSearchCriteria(SearchCriteriaReqWrapper pSearchCriteriaReq) {
		SearchCriteriaRespWrapper oSearchCriteriaResp = new SearchCriteriaRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/savedsearch/"
						+ pSearchCriteriaReq.getSearchId() + "?userId=" + pSearchCriteriaReq.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oSearchCriteriaResp = (SearchCriteriaRespWrapper) response.readEntity(SearchCriteriaRespWrapper.class);
				logger.debug("Get Search Criteria REST Output from Server .... \n");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oSearchCriteriaResp;
	}

	@POST
	@Path("/saveUserPrefs")
	@Produces({ "application/json" })
	public UserPrefsRespWrapper getSaveUserPreferences(UserPrefsReqWrapper pUserPrefsReq) {
		UserPrefsRespWrapper oUserPrefsResponse = new UserPrefsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/preferences");
				Response response = webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json")
						.post(Entity.entity(pUserPrefsReq, MediaType.APPLICATION_JSON));
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oUserPrefsResponse = (UserPrefsRespWrapper) response.readEntity(UserPrefsRespWrapper.class);
				logger.debug("Set user preferences REST Output from Server .... \n");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oUserPrefsResponse;
	}

	@POST
	@Path("/saveAdminPlnSysOutages")
	@Produces({ "application/json" })
	public AdminOutagesRespWrapper getSaveAdminPlannedSystemOutagesData(AdminOutagesReqWrapper pOutagesReq) {
		AdminOutagesRespWrapper oResponseOutages = new AdminOutagesRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webPlnSystemOutage = client.target(String.valueOf(ucmUrlStr) + "/rest/landingpage/outage/");
				Response responsePlnSysOutage = webPlnSystemOutage.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json")
						.post(Entity.entity(pOutagesReq, MediaType.APPLICATION_JSON));
				if (responsePlnSysOutage.getStatus() != 200 && responsePlnSysOutage.getStatus() != 202) {
					responsePlnSysOutage.close();
					throw new RuntimeException("Failed : HTTP error code : " + responsePlnSysOutage.getStatus() + ": "
							+ responsePlnSysOutage.getStatusInfo().getReasonPhrase());
				}
				oResponseOutages = (AdminOutagesRespWrapper) responsePlnSysOutage
						.readEntity(AdminOutagesRespWrapper.class);
				logger.debug("Add Planned System Outages to DB REST Output from Server .... \n");
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oResponseOutages;
	}

	@POST
	@Path("/deleteAdminModels")
	@Produces({ "application/json" })
	public AdminModelsRespWrapper deleteAdminModels(AdminModelsReqWrapper pModelsReq) {
		logger.debug("Inside UnifiedPortalRestService.deleteAdminModels(). Rest Request= " + pModelsReq.getModelId());
		AdminModelsRespWrapper oResponseModels = new AdminModelsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client
						.target(String.valueOf(ucmUrlStr) + "/rest/landingpage/model/" + pModelsReq.getModelId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").delete(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				String oResponseModelsStr = (String) response.readEntity(String.class);
				oResponseModels.setDeleteStatusMsg(oResponseModelsStr);
				logger.debug("deleteAdminModels REST Output from Server .... \n");
				logger.debug(oResponseModels.getDeleteStatusMsg());
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oResponseModels;
	}

	@POST
	@Path("/deleteAdminPlnSysOutages")
	@Produces({ "application/json" })
	public AdminOutagesRespWrapper deletePlanSystemMsgID(AdminOutagesReqWrapper pOutagesReq) {
		logger.debug("Inside UnifiedPortalRestService.deletePlanSystemMsgID(). Rest Request= " + pOutagesReq.getId());
		AdminOutagesRespWrapper oResponseOutages = new AdminOutagesRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client
						.target(String.valueOf(ucmUrlStr) + "/rest/landingpage/outage/" + pOutagesReq.getId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").delete(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				String oResponseOutagesStr = (String) response.readEntity(String.class);
				oResponseOutages.setDeleteStatusMsg(oResponseOutagesStr);
				logger.debug("DeletePlanSystemMsgID REST Output from Server .... \n");
				logger.debug(oResponseOutages.getDeleteStatusMsg());
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oResponseOutages;
	}

	@POST
	@Path("/addNetVizHhaConnections")
	@Produces({ "application/json" })
	public NetVizRespWrapper addNetVizHhaConnections(NetVizConnReqWrapper pNetVizConnReq) {
		NetVizRespWrapper oNetVizResponse = new NetVizRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client
						.target(String.valueOf(ucmUrlStr) + "/rest/asr/hhaviz/" + pNetVizConnReq.getNpi() + "/"
								+ pNetVizConnReq.getConnectIndex() + "?userId=" + pNetVizConnReq.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oNetVizResponse = (NetVizRespWrapper) response.readEntity(NetVizRespWrapper.class);
				logger.debug("addNetVizHhaConnections REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oNetVizResponse;
	}

	@POST
	@Path("/networkVizDmeData")
	@Produces({ "application/json" })
	public NetVizRespWrapper networkVizDmeData(NetVizReqWrapper pNetVizReq) {
		NetVizRespWrapper oNetVizResponse = new NetVizRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/dmeviz/"
						+ pNetVizReq.getAsrptId() + "/" + "?userId=" + pNetVizReq.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oNetVizResponse = (NetVizRespWrapper) response.readEntity(NetVizRespWrapper.class);
				logger.debug("networkVizDmeData REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oNetVizResponse;
	}

	@POST
	@Path("/networkVizHhaData")
	@Produces({ "application/json" })
	public NetVizRespWrapper networkVizHhaData(NetVizReqWrapper pNetVizReq) {
		NetVizRespWrapper oNetVizResponse = new NetVizRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/hhaviz/"
						+ pNetVizReq.getAsrptId() + "/" + "?userId=" + pNetVizReq.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oNetVizResponse = (NetVizRespWrapper) response.readEntity(NetVizRespWrapper.class);
				logger.debug("networkVizHhaData REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oNetVizResponse;
	}

	@POST
	@Path("/networkVizData")
	@Produces({ "application/json" })
	public NetVizRespWrapper networkVizData(NetVizReqWrapper pNetVizReq) {
		NetVizRespWrapper oNetVizResponse = new NetVizRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client
						.target(String.valueOf(ucmUrlStr) + "/rest/asr/viz/" + pNetVizReq.getAsrptId() + "/"
								+ pNetVizReq.getModelId() + "?userId=" + pNetVizReq.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oNetVizResponse = (NetVizRespWrapper) response.readEntity(NetVizRespWrapper.class);
				logger.debug("networkVizData REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oNetVizResponse;
	}

	@POST
	@Path("/prioritizeASRsForUCM")
	@Produces({ "application/json" })
	public PrioritizeASRRespWrapper prioritizeASRsForUCM(PrioritizeASRReqWrapper pUCMMsgsReq) {
		logger.debug("Inside UnifiedPortalRestService.prioritizeASRsForUCM(). Rest Request size = "
				+ pUCMMsgsReq.getPriorities().size());
		PrioritizeASRRespWrapper oResponsePriorities = new PrioritizeASRRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/priority");
				Response response = webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json")
						.post(Entity.entity(pUCMMsgsReq, MediaType.APPLICATION_JSON));
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oResponsePriorities.setMessage("success");
				logger.debug("prioritizeASRsForUCM REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oResponsePriorities;
	}

	@POST
	@Path("/deleteAdminSysMsgs")
	@Produces({ "application/json" })
	public AdminSysMsgsRespWrapper deleteSystemMessageID(AdminSysMsgsReqWrapper pSysMsgsReq) {
		logger.debug("Inside UnifiedPortalRestService.deleteSystemMessageID(). Rest Request= " + pSysMsgsReq.getId());
		AdminSysMsgsRespWrapper oResponseSysMsgs = new AdminSysMsgsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client
						.target(String.valueOf(ucmUrlStr) + "/rest/landingpage/message/" + pSysMsgsReq.getId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").delete(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				String oResponseSysMsgsStr = (String) response.readEntity(String.class);
				oResponseSysMsgs.setDeleteStatusMsg(oResponseSysMsgsStr);
				logger.debug("DeletePlanSystemMsgID REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oResponseSysMsgs;
	}

	@POST
	@Path("/userTracking")
	@Produces({ "application/json" })
	public UserTrackingRespWrapper getUserTrackingData(UserTrackingReqWrapper pUserTrackingRequest) {
		UserTrackingRespWrapper oUserTrackingResponse = new UserTrackingRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {

				String serviceUrl = "";
				if (pUserTrackingRequest.getTrackingVal() != null && !pUserTrackingRequest.getTrackingVal().isEmpty()) {
					serviceUrl = "/rest/tracking/" + pUserTrackingRequest.getPageId() + "/"
							+ pUserTrackingRequest.getUserId() + "/" + pUserTrackingRequest.getTrackingVal();
				} else {
					serviceUrl = "/rest/tracking/" + pUserTrackingRequest.getPageId() + "/"
							+ pUserTrackingRequest.getUserId();
				}
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + serviceUrl);
				Response response = webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json")
						.post(Entity.entity(pUserTrackingRequest, MediaType.APPLICATION_JSON));
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oUserTrackingResponse.setResponseMsg("Success");
				logger.debug("User Tracking REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oUserTrackingResponse;
	}

	@POST
	@Path("/slaMetrics")
	@Produces({ "application/json" })
	public SlaMeticsRespWrapper getSlaMetrics(SlaMeticsReqWrapper pSlaMetricsRequest) {
		SlaMeticsRespWrapper oSlaMetricsResp = new SlaMeticsRespWrapper();
		// override browser-generated date with system-generated date
		SimpleDateFormat shortFormatDash = new SimpleDateFormat("MMMM dd, YYYY hh:mm:ss a");
		String slaDate = shortFormatDash.format(new Date());
		pSlaMetricsRequest.setDateTime(slaDate);
		utilLogger.info("SLA Metrics Entry. Type = " + pSlaMetricsRequest.getEventType() + ", Time = "
				+ pSlaMetricsRequest.getDateTime() + ", User = " + pSlaMetricsRequest.getUserId() + ", Zone = "
				+ pSlaMetricsRequest.getZone());
		if (pSlaMetricsRequest.getEventType() != null && pSlaMetricsRequest.getDateTime() != null
				&& pSlaMetricsRequest.getUserId() != null) {
			oSlaMetricsResp.setStatus("success");
		} else {
			oSlaMetricsResp.setStatus("failure");
		}
		return oSlaMetricsResp;
	}

	@POST
	@Path("/addToExistList")
	@Produces({ "application/json" })
	public WorkItemsListRespWrapper getAddToExistList(AddToExistListReqWrapper pAddToExistListRequest) {
		WorkItemsListRespWrapper oAddToExistListResponse = new WorkItemsListRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(
						String.valueOf(ucmUrlStr) + "/rest/provider/lists/" + pAddToExistListRequest.getWorkItemId()
								+ "/items?userId=" + pAddToExistListRequest.getUserId());
				JSONObject jsonObject = new JSONObject();
				
				jsonObject.put("asrptIds", pAddToExistListRequest.getAsrptIds());
				Response response = webResource.request().accept(new String[] { "application/json" })
						.header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + getToken())
						.post(Entity.entity(jsonObject.toString(), MediaType.APPLICATION_JSON));
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oAddToExistListResponse = (WorkItemsListRespWrapper) response
						.readEntity(WorkItemsListRespWrapper.class);
				logger.debug("Add ASRs to Existing List REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oAddToExistListResponse;
	}

	@POST
	@Path("/exclusionDetail")
	@Produces({ "application/json" })
	public ExclusionDetailRespWrapper getExclusionDetail(ExclusionDetailReqWrapper pExclusionDetailReq) {
		ExclusionDetailRespWrapper oExclusionDetailResp = new ExclusionDetailRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/provider/lists/exclusions/"
						+ verifyUser(pExclusionDetailReq.getUserId()) + "/" + pExclusionDetailReq.getAsrId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oExclusionDetailResp = (ExclusionDetailRespWrapper) response
						.readEntity(ExclusionDetailRespWrapper.class);
				logger.debug("Exclusion Detail REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oExclusionDetailResp;
	}

	@POST
	@Path("/removeFromExList")
	@Produces({ "application/json" })
	public RemoveAsrsRespWrapper getRemoveAsrsFromExList(RemoveAsrsReqWrapper pRemoveAsrsRequest) {
		RemoveAsrsRespWrapper oRemoveAsrsResponse = new RemoveAsrsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/provider/exclusions/"
						+ verifyUser(pRemoveAsrsRequest.getUserId()) + "/items?userId="
						+ pRemoveAsrsRequest.getUserId());
				JSONObject jsonObject = new JSONObject();
//				JSONArray jsonArray = new JSONArray();
//				jsonArray.add(pRemoveAsrsRequest.getAsrptIds());
				jsonObject.put("asrptIds", pRemoveAsrsRequest.getAsrptIds());
				Response response = webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json")
						.put(Entity.entity(jsonObject.toString(), MediaType.APPLICATION_JSON));
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oRemoveAsrsResponse = (RemoveAsrsRespWrapper) response.readEntity(RemoveAsrsRespWrapper.class);
				logger.debug("Remove ASRs from List REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oRemoveAsrsResponse;
	}

	@POST
	@Path("/removeFromList")
	@Produces({ "application/json" })
	public RemoveAsrsRespWrapper getRemoveAsrsFromList(RemoveAsrsReqWrapper pRemoveAsrsRequest) {
		RemoveAsrsRespWrapper oRemoveAsrsResponse = new RemoveAsrsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/provider/lists/"
						+ pRemoveAsrsRequest.getWorkItemId() + "/items?userId=" + pRemoveAsrsRequest.getUserId());
				ObjectMapper mapper = new ObjectMapper();
				JSONObject jsonObject = new JSONObject();
//				JSONArray jsonArray = new JSONArray();
//				jsonArray.add(pRemoveAsrsRequest.getAsrptIds());
				jsonObject.put("asrptIds", pRemoveAsrsRequest.getAsrptIds());
				Response response = webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json")
						.put(Entity.entity(jsonObject.toString(), MediaType.APPLICATION_JSON));
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oRemoveAsrsResponse = (RemoveAsrsRespWrapper) response.readEntity(RemoveAsrsRespWrapper.class);
				logger.debug("Remove ASRs from List REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oRemoveAsrsResponse;
	}

	@POST
	@Path("/renameList")
	@Produces({ "application/json" })
	public RenameListRespWrapper getRenameListData(RenameListReqWrapper pRenameListRequest) {
		RenameListRespWrapper oRenameListResponse = new RenameListRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {

				String webResourceURL = "";
				if ("asr".equals(pRenameListRequest.getFpsPrioritizationList().getListType())) {
					webResourceURL = "/rest/provider/lists/"
							+ pRenameListRequest.getFpsPrioritizationList().getPrioritizationListId();
				} else {
					webResourceURL = "/rest/provider/searches/"
							+ pRenameListRequest.getFpsPrioritizationList().getPrioritizationListId();
				}
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + webResourceURL);
				Response response = webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json")
						.post(Entity.entity(pRenameListRequest.getFpsPrioritizationList(), MediaType.APPLICATION_JSON));
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oRenameListResponse = (RenameListRespWrapper) response.readEntity(RenameListRespWrapper.class);
				logger.debug("Rename List REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oRenameListResponse;
	}

	@POST
	@Path("/saveAsList")
	@Produces({ "application/json" })
	public FpsPrioritizationList getSaveAsListData(SaveAsListReqWrapper pSaveAsListRequest) {
		FpsPrioritizationList oSaveAsListResponse = new FpsPrioritizationList();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/provider/lists");
				Response response = webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json")
						.post(Entity.entity(pSaveAsListRequest.getFpsPrioritizationList(), MediaType.APPLICATION_JSON));
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oSaveAsListResponse = (FpsPrioritizationList) response.readEntity(FpsPrioritizationList.class);
				logger.debug("Save as List REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oSaveAsListResponse;
	}

	@POST
	@Path("/addToExistInputVals")
	@Produces({ "application/json" })
	public List<FpsWorkbenchList> getAddToExistInputVals(AddToExistInputValReqWrapper pInputValRequest) {
		List<FpsWorkbenchList> oInputValResponse = new ArrayList<FpsWorkbenchList>();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/provider/lists/user/"
						+ verifyUser(pInputValRequest.getUserId()) + "/asr");
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oInputValResponse = (List<FpsWorkbenchList>) response
						.readEntity(new GenericType<List<FpsWorkbenchList>>() {
						});
				logger.debug("Add to List Input Values REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oInputValResponse;
	}

	@POST
	@Path("/addToExistInputValsMdcd")
	@Produces({ "application/json" })
	public List<FpsWorkbenchList> getAddToExistInputValsMdcd(AddToExistInputValReqWrapper pInputValRequest) {
		List<FpsWorkbenchList> oInputValResponse = new ArrayList<FpsWorkbenchList>();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/provider/mdcd/lists/user/"
						+ verifyUser(pInputValRequest.getUserId()) + "/asr");
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oInputValResponse = (List<FpsWorkbenchList>) response
						.readEntity(new GenericType<List<FpsWorkbenchList>>() {
						});
				logger.debug("Add to List Input Values REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oInputValResponse;
	}

	@POST
	@Path("/checkListName")
	@Produces({ "application/json" })
	public List<WorkItem> getCheckListName(CheckListNameReqWrapper pCheckListNameRequest) {
		List<WorkItem> oCheckListNameResponse = new ArrayList<WorkItem>();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {

				String urlStr = "";
				if ("search".equals(pCheckListNameRequest.getListType())) {
					urlStr = "/rest/provider/lists/user/" + pCheckListNameRequest.getUserId() + "/search";
				} else {
					urlStr = "/rest/provider/lists/user/" + pCheckListNameRequest.getUserId() + "/asr";
				}
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + urlStr);
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oCheckListNameResponse = (List<WorkItem>) response.readEntity(new GenericType<List<WorkItem>>() {
				});
				logger.debug("Check List Name REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oCheckListNameResponse;
	}

	@POST
	@Path("/checkListNameMdcd")
	@Produces({ "application/json" })
	public List<WorkItem> getCheckListNameMDCD(CheckListNameReqWrapper pCheckListNameRequest) {
		List<WorkItem> oCheckListNameResponse = new ArrayList<WorkItem>();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {

				String urlStr = "";
				if ("search".equals(pCheckListNameRequest.getListType())) {
					urlStr = "/rest/provider/mdcd/lists/user/" + pCheckListNameRequest.getUserId() + "/search";
				} else {
					urlStr = "/rest/provider/mdcd/lists/user/" + pCheckListNameRequest.getUserId() + "/asr";
				}
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + urlStr);
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oCheckListNameResponse = (List<WorkItem>) response.readEntity(new GenericType<List<WorkItem>>() {
				});
				logger.debug("Check List Name REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oCheckListNameResponse;
	}

	@POST
	@Path("/shareToGroup")
	@Produces({ "application/json" })
	public FpsPrioritizationShareGrp getShareToGroupData(ShareToGroupReqWrapper pShareToGroupRequest) {
		FpsPrioritizationShareGrp oShareToGroupResponse = new FpsPrioritizationShareGrp();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(
						String.valueOf(ucmUrlStr) + "/rest/provider/groups?userId=" + pShareToGroupRequest.getUserId());
				Response response = webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").post(Entity
								.entity(pShareToGroupRequest.getPrioritizationShareGrp(), MediaType.APPLICATION_JSON));
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oShareToGroupResponse = (FpsPrioritizationShareGrp) response
						.readEntity(FpsPrioritizationShareGrp.class);
				logger.debug("Share to Group REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oShareToGroupResponse;
	}

	@POST
	@Path("/shareableUsers")
	@Produces({ "application/json" })
	public ShareableUsersRespWrapper getShareableUsersData(ShareableUsersReqWrapper pShareableUsersRequest) {
		ShareableUsersRespWrapper oShareableUserResponse = new ShareableUsersRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/provider/groups/"
						+ pShareableUsersRequest.getGroupId() + "?userId=" + pShareableUsersRequest.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oShareableUserResponse = (ShareableUsersRespWrapper) response
						.readEntity(ShareableUsersRespWrapper.class);
				logger.debug("Save as List REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oShareableUserResponse;
	}

	@POST
	@Path("/shareableMDCDUsers")
	@Produces({ "application/json" })
	public ShareableUsersRespWrapper getShareableMDCDUsersData(ShareableUsersReqWrapper pShareableUsersRequest) {
		ShareableUsersRespWrapper oShareableUserResponse = new ShareableUsersRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/provider/mdcd/groups/"
						+ pShareableUsersRequest.getGroupId() + "?userId=" + pShareableUsersRequest.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);

				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oShareableUserResponse = (ShareableUsersRespWrapper) response
						.readEntity(ShareableUsersRespWrapper.class);
				logger.debug("Save as List REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oShareableUserResponse;
	}

	@POST
	@Path("/workItemQueryList")
	@Produces({ "application/json" })
	public WorkItemsListRespWrapper getWorkItemsQueryListData(WorkItemsListReqWrapper pWorkItemsQueryRequest) {
		WorkItemsListRespWrapper oWorkItemsQueryResponse = new WorkItemsListRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/provider/lists/search/"
						+ pWorkItemsQueryRequest.getWorkItemId() + "?userId=" + pWorkItemsQueryRequest.getUserId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oWorkItemsQueryResponse = (WorkItemsListRespWrapper) response
						.readEntity(WorkItemsListRespWrapper.class);
				logger.debug("Work Items Query List REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oWorkItemsQueryResponse;
	}

	@POST
	@Path("/updateExListAction")
	@Produces({ "application/json" })
	public WorkItemsRespWrapper getUpdateExclusionListAction(ExListActionReqWrapper pExListActnRequest) {
		WorkItemsRespWrapper oExListActionResp = new WorkItemsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/provider/exclusions/"
						+ verifyUser(pExListActnRequest.getUserId()) + "/visible/"
						+ pExListActnRequest.getActionBool());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oExListActionResp = (WorkItemsRespWrapper) response.readEntity(WorkItemsRespWrapper.class);
				logger.debug("Update Exclusion List Action REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oExListActionResp;
	}

	@POST
	@Path("/picExclusionList")
	@Produces({ "application/json" })
	public WorkItemsListRespWrapper getPicExclusionListData(WorkItemsListReqWrapper pWorkItemsRequest) {
		WorkItemsListRespWrapper oPicExclusionResponse = new WorkItemsListRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/provider/lists/pic/"
						+ verifyUser(pWorkItemsRequest.getUserId()));
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oPicExclusionResponse = (WorkItemsListRespWrapper) response.readEntity(WorkItemsListRespWrapper.class);
				logger.debug("PIC Exclusion List REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oPicExclusionResponse;
	}

	@POST
	@Path("/exclusionList")
	@Produces({ "application/json" })
	public WorkItemsListRespWrapper getExclusionListData(WorkItemsListReqWrapper pWorkItemsRequest) {
		WorkItemsListRespWrapper oWorkItemsResponse = new WorkItemsListRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/provider/lists/exclusions/"
						+ verifyUser(pWorkItemsRequest.getUserId()));
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oWorkItemsResponse = (WorkItemsListRespWrapper) response.readEntity(WorkItemsListRespWrapper.class);
				logger.debug("Exclusion List REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oWorkItemsResponse;
	}

	@POST
	@Path("/workItemList")
	@Produces({ "application/json" })
	public WorkItemsListRespWrapper getWorkItemsListData(WorkItemsListReqWrapper pWorkItemsRequest) {
		WorkItemsListRespWrapper oWorkItemsResponse = new WorkItemsListRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(
						String.valueOf(ucmUrlStr) + "/rest/provider/lists/" + pWorkItemsRequest.getWorkItemId()+"?userId="+ verifyUser(pWorkItemsRequest.getUserId()));;
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oWorkItemsResponse = (WorkItemsListRespWrapper) response.readEntity(WorkItemsListRespWrapper.class);
				logger.debug("Work Items List REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oWorkItemsResponse;
	}

	@POST
	@Path("/workItemListMdcd")
	@Produces({ "application/json" })
	public WorkItemsListRespWrapper getWorkItemsListDataMdcd(WorkItemsListReqWrapper pWorkItemsRequest) {
		WorkItemsListRespWrapper oWorkItemsResponse = new WorkItemsListRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(
						String.valueOf(ucmUrlStr) + "/rest/provider/mdcd/lists/" + pWorkItemsRequest.getWorkItemId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oWorkItemsResponse = (WorkItemsListRespWrapper) response.readEntity(WorkItemsListRespWrapper.class);
				logger.debug("Work Items List REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oWorkItemsResponse;
	}

	@POST
	@Path("/workItems")
	@Produces({ "application/json" })
	public WorkItemsRespWrapper getWorkItemsData(WorkItemsReqWrapper pWorkItemsRequest) {
		WorkItemsRespWrapper oWorkItemsResponse = new WorkItemsRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/provider/lists/user/"
						+ verifyUser(pWorkItemsRequest.getUserId()));
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oWorkItemsResponse = (WorkItemsRespWrapper) response.readEntity(WorkItemsRespWrapper.class);
				logger.debug("Work Items REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oWorkItemsResponse;
	}

	@POST
	@Path("/tpeData")
	@Produces({ "application/json" })
	public TpeRespWrapper getTpeData(TpeReqWrapper pTpeRequest) {
		TpeRespWrapper oTpeResponse = new TpeRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(String.valueOf(ucmUrlStr) + "/rest/asr/detail/"
						+ pTpeRequest.getAsrptId() + "/tpe?userId=" + verifyUser(pTpeRequest.getUserId()));
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus() + ": "
							+ response.getStatusInfo().getReasonPhrase());
				}
				oTpeResponse = (TpeRespWrapper) response.readEntity(TpeRespWrapper.class);
				logger.debug("History Tab Data REST Output from Server .... \n");
				response.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return oTpeResponse;
	}

	@POST
	@Path("/ucmLeadData")
	@Produces({ "application/json" })
	public UCMLeadDataRespWrapper getUcmLeadData(UCMLeadDataReqWrapper pUcmLeadDataRequest) {
		UCMLeadDataRespWrapper oUcmLeadDataResponse = new UCMLeadDataRespWrapper();
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResource = client.target(
						String.valueOf(ucmUrlStr) + "/rest/asr/investigation/" + pUcmLeadDataRequest.getLeadId());
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Authorization", "Bearer " + getToken())
						.header("Content-Type", "application/json").get(Response.class);
				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
				oUcmLeadDataResponse = (UCMLeadDataRespWrapper) response.readEntity(UCMLeadDataRespWrapper.class);
				logger.debug("UcmLeadData REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
		return oUcmLeadDataResponse;
	}

	@POST
	@Path("/record")
	@Consumes({ "application/json" })
	public void recordLogin(OktaLoginTokenFields pOktaTokenFields) {
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String splunkURL = pfh.getPortalProperty("splunkURL");
			String splunkToken = pfh.getPortalProperty("splunkToken");
			String env = pfh.getPortalProperty("env");
			if (!splunkURL.isEmpty()) {
				OktaLoginToken oktaToken = new OktaLoginToken();
				pOktaTokenFields.setTimestamp(new Date());
				pOktaTokenFields.setEnv(env);
				oktaToken.setEvent(pOktaTokenFields);
				logger.warn(oktaToken);
				Client client = buildClientConfig();
				WebTarget webResource = client.target(splunkURL);
				Response response = (Response) webResource.request().accept(new String[] { "application/json" })
						.header("Content-Type", "application/json")
						.header("Authorization", "Splunk " + splunkToken)
						.post(Entity.entity(oktaToken, MediaType.APPLICATION_JSON)) ;

				if (response.getStatus() != 200 && response.getStatus() != 202) {
					response.close();
					throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
				}
//	        oUcmLeadDataResponse = (UCMLeadDataRespWrapper)response.getEntity(UCMLeadDataRespWrapper.class);
				logger.debug("recordLogin REST Output from Server .... \n");
			}
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1);
		}
	}

	public static void main(String[] args) {
		System.out.println("TEST");
	}
	private String getToken() {
		String accessToken = this.httpHeaders.getRequestHeader("authorization").get(0);
		
		return accessToken;
	}
	private String verifyUser(String userId) {
		String accessToken = this.httpHeaders.getRequestHeader("authorization").get(0);
//		logger.debug("Token = " + accessToken);
		boolean valid = JwtUtil.getInstance().verifyUser(accessToken, userId);
		String validUserId = userId;
		if (!valid)
			validUserId = "none";
		return validUserId;
	}

	private Client buildClientConfig() {
		ClientConfig clientConfig = new ClientConfig();
		clientConfig.property(LoggingFeature.LOGGING_FEATURE_VERBOSITY_CLIENT, LoggingFeature.Verbosity.PAYLOAD_ANY);
		clientConfig.property(ClientProperties.CONNECT_TIMEOUT, 360000);
		clientConfig.property(ClientProperties.READ_TIMEOUT, 360000);
	
		SSLContext sslcontext;
		try {
			sslcontext = SSLContext.getInstance("TLSv1.2");

			sslcontext.init(null, new TrustManager[]  { new X509TrustManager() {
				@Override
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				@Override
				public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}

				@Override
				public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}
			
			} }, new java.security.SecureRandom());

			Client client = ClientBuilder.newBuilder().withConfig(clientConfig)
					.sslContext(sslcontext)
					.hostnameVerifier((s1, s2) -> true)
					 .connectTimeout(6, TimeUnit.MINUTES)
				        .readTimeout(6, TimeUnit.MINUTES)
					.build();
			return client;
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;

	}
	@POST
	@Path("/homepageTiles")
	@Produces({ "application/json" })
	public HomepageTileResponse getHomepageTiles() {
		HomepageTileResponse tilesWrapper = new HomepageTileResponse();
		logger.debug("Calling the Rest Webservice : UnifiedPortalRestService.getHomepageTiles() - " );
		try {
			PropertyFileHandler pfh = new PropertyFileHandler();
			String ucmUrlStr = pfh.getPortalProperty("ucmURL");
			logger.debug("ucmURL property = " + ucmUrlStr);
			if (!ucmUrlStr.isEmpty()) {
				Client client = buildClientConfig();
				WebTarget webResourceMsgs = client.target(
						String.valueOf(ucmUrlStr) + "/rest/home");

				Invocation.Builder invocationBuilder = webResourceMsgs.request();
				invocationBuilder.header("Content-Type", "application/json");
				invocationBuilder.header("Authorization", getToken());

				
				invocationBuilder.accept("application/json");

				Response responseTiles = invocationBuilder.get();
				if (responseTiles.getStatus() != 200) {
					responseTiles.close();
					throw new RuntimeException("Failed : HTTP error code : " + responseTiles.getStatus());
				}
				tilesWrapper = (HomepageTileResponse) responseTiles.readEntity(HomepageTileResponse.class);
				responseTiles.close();
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		return tilesWrapper;
	}
	

}

