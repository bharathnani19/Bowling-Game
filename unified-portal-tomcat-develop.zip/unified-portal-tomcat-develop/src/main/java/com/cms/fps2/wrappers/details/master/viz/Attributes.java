package com.cms.fps2.wrappers.details.master.viz;

import java.util.ArrayList;
import java.util.List;

public class Attributes {
	private String name;
	private List<Npis> npis = new ArrayList<Npis>();
	
	//constructor
	public Attributes() {}
	
	//code
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	//npis
	public List<Npis> getNpis() {
		return npis;
	}
	
	public void setNpis(List<Npis> npis) {
		this.npis = npis;
	}
}
