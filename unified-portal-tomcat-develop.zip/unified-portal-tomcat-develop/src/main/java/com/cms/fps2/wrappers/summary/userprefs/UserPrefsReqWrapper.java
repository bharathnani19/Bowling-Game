package com.cms.fps2.wrappers.summary.userprefs;

public class UserPrefsReqWrapper {
	private String userId;
	private String prefName;
	private String prefJson;
	private String prefLbl;
	
	//constructor
	public UserPrefsReqWrapper(){}
	
	//userId 	
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//prefName
	public String getPrefName() {
		return prefName;
	}
	
	public void setPrefName(String prefName) {
		this.prefName = prefName;
	}
	
	//prefJson
	public String getPrefJson() {
		return prefJson;
	}
	
	public void setPrefJson(String prefJson) {
		this.prefJson = prefJson;
	}
	
	// prefLbl
	public String getPrefLbl() {
		return prefLbl;
	}
	
	public void setPrefLbl(String prefLbl) {
		this.prefLbl = prefLbl;
	}
}
