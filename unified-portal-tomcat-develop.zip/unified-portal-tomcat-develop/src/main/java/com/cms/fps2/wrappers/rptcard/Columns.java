package com.cms.fps2.wrappers.rptcard;

public class Columns {
	private String columnName;
	private String columnIndex;
	
	//constructor
	public Columns() {}
	
	//columnName
	public String getColumnName() {
		return columnName;
	}
	
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	
	//columnIndex
	public String getColumnIndex() {
		return columnIndex;
	}
	
	public void setColumnIndex(String columnIndex) {
		this.columnIndex = columnIndex;
	}
}
