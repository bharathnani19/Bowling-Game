package com.cms.fps2.wrappers.rptcard;

public class ReportCardRequestWrapper {
	private String npi;
	private String modelId;
	private String userId;
	private String insertDt;
	private String state;
	private String tableId;
	
	
	//constructor
	public ReportCardRequestWrapper(){}
	
	//npi
	public String getNpi() {
		return npi;
	}
	
	public void setNpi(String npi) {
		this.npi = npi;
	}
	
	//modelId
	public String getModelId() {
		return modelId;
	}
	
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//insertDt
	public String getInsertDt() {
		return insertDt;
	}
	
	public void setInsertDt(String insertDt) {
		this.insertDt = insertDt;
	}

	// state
	
	public String getState() {
		return state;
	}

	// state
	
	public void setState(String state) {
		this.state = state;
	}

	// tableId
	public String gettableId() {
		return tableId;
	}

	public void settableId(String tableId) {
		this.tableId = tableId;
	}
}
