package com.cms.fps2.wrappers.details;

public class Leads {
	private String id;
	private String category;
	private String status;
	private String assignedTo;
	private String legacyInd;
	private String ruling;
	private String bpmTaskId;
	private String bpmProcNum;
	private String createdDt;
	private String activities;
	private String actions;
	private String subRuling;
	private String ucmId;
	private String modDt;
	private String state;
	
	//constructor
	public Leads(){}
	
	//id 	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	//category 	
	public String getCategory() {
		return category;
	}
	
	public void setCategory(String category) {
		this.category = category;
	}
	
	//status 	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	//assignedTo 	
	public String getAssignedTo() {
		return assignedTo;
	}
	
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	
	//legacyInd 	
	public String getLegacyInd() {
		return legacyInd;
	}
	
	public void setLegacyInd(String legacyInd) {
		this.legacyInd = legacyInd;
	}
	
	//ruling 	
	public String getRuling() {
		return ruling;
	}
	
	public void setRuling(String ruling) {
		this.ruling = ruling;
	}
	
	//bpmTaskId 	
	public String getBpmTaskId() {
		return bpmTaskId;
	}
	
	public void setBpmTaskId(String bpmTaskId) {
		this.bpmTaskId = bpmTaskId;
	}
	
	//bpmProcNum 	
	public String getBpmProcNum() {
		return bpmProcNum;
	}
	
	public void setBpmProcNum(String bpmProcNum) {
		this.bpmProcNum = bpmProcNum;
	}
	
	//createdDt 	
	public String getCreatedDt() {
		return createdDt;
	}
	
	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}
	
	//activities 	
	public String getActivities() {
		return activities;
	}
	
	public void setActivities(String activities) {
		this.activities = activities;
	}
	
	//actions 	
	public String getActions() {
		return actions;
	}
	
	public void setActions(String actions) {
		this.actions = actions;
	}
	
	//subRuling
	public String getSubRuling() {
		return subRuling;
	}
	
	public void setSubRuling(String subRuling) {
		this.subRuling = subRuling;
	}
	
	//ucmId
	public String getUcmId() {
		return ucmId;
	}
	
	public void setUcmId(String ucmId) {
		this.ucmId = ucmId;
	}
	
	//modDt
	public String getModDt() {
		return modDt;
	}
	
	public void setModDt(String modDt) {
		this.modDt = modDt;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
}
