package com.cms.fps2.wrappers.details;

public class TpeRespWrapper {
	
	private TpeResponseData responseData;
	
	// constructor
	public TpeRespWrapper() {}
	
	//responseData
	public TpeResponseData getResponseData() {
		return responseData;
	}
	
	public void setResponseData(TpeResponseData responseData) {
		this.responseData = responseData;
	}
}
