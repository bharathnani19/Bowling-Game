package com.cms.fps2.wrappers.details.provider;

public class TotalPymtZones {
	
	private String totalClaimLines;
	private String totalCost;
	private String zone;
		
	// constructor
	public TotalPymtZones() {}
	
	// totalClaimLines
	public String getTotalClaimLines() {
		return totalClaimLines;
	}
	
	public void setTotalClaimLines(String totalClaimLines) {
		this.totalClaimLines = totalClaimLines;
	}
	
	// totalCost
	public String getTotalCost() {
		return totalCost;
	}
	
	public void setTotalCost(String totalCost) {
		this.totalCost = totalCost;
	}
	
	// zone
	public String getZone() {
		return zone;
	}
	
	public void setZone(String zone) {
		this.zone = zone;
	}

}
