package com.cms.fps2.wrappers.details.master.viz;

public class Color {
	private String border;
	private String background;
	
	// constructor
	public Color () {}
	
	// border
	public String getBorder() {
		return border;
	}
	
	public void setBorder(String border) {
		this.border = border;
	}
	
	// background
	public String getBackground() {
		return background;
	}
	
	public void setBackground(String background) {
		this.background = background;
	}
	
}
