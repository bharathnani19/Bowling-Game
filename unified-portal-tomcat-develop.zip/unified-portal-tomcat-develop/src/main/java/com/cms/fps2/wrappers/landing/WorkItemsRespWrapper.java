package com.cms.fps2.wrappers.landing;

import java.util.ArrayList;
import java.util.List;

public class WorkItemsRespWrapper {
	private List<WorkItem> workbenchLists = new ArrayList<WorkItem>();
	private List<WorkItem> workbenchMdcdLists = new ArrayList<WorkItem>();
	
	// constructor
	public WorkItemsRespWrapper() {}
	
	// workItem
	public List<WorkItem> getWorkbenchLists() {
		return workbenchLists;
	}
	
	public void setWorkbenchLists(List<WorkItem> workbenchLists) {
		this.workbenchLists = workbenchLists;
	}

	public List<WorkItem> getworkbenchMdcdLists() {
		return workbenchMdcdLists;
	}
	
	public void setworkbenchMdcdLists(List<WorkItem> workbenchMdcdLists) {
		this.workbenchMdcdLists = workbenchMdcdLists;
	}
}
