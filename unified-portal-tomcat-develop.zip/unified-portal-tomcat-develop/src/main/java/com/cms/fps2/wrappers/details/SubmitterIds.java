package com.cms.fps2.wrappers.details;

public class SubmitterIds {
	
	private String submitterId;
	
	//constructor
	public SubmitterIds(){}
	
	//submitterId 	
	public String getSubmitterId() {
		return submitterId;
	}
	
	public void setSubmitterId(String submitterId) {
		this.submitterId = submitterId;
	}

}
