package com.cms.fps2.wrappers.details.tab.edits;

import java.util.ArrayList;
import java.util.List;

public class EditInfoRespWrapper {
	
	private List<ActiveEditInfos> activeEditInfos = new ArrayList<ActiveEditInfos>();
	private List<InactiveEditInfos> inactiveEditInfos = new ArrayList<InactiveEditInfos>();
	
	// constructor
	public EditInfoRespWrapper() {}
	
	// activeEditInfos
	public List<ActiveEditInfos> getActiveEditInfos() {
		return activeEditInfos;
	}
	
	public void setActiveEditInfos(List<ActiveEditInfos> activeEditInfos) {
		this.activeEditInfos = activeEditInfos;
	}
	
	// inactiveEditInfos
	public List<InactiveEditInfos> getInactiveEditInfos() {
		return inactiveEditInfos;
	}
	
	public void setInactiveEditInfos(List<InactiveEditInfos> inactiveEditInfos) {
		this.inactiveEditInfos = inactiveEditInfos;
	}
}
