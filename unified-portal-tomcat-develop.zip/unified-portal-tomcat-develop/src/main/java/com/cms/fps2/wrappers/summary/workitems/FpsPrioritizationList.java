package com.cms.fps2.wrappers.summary.workitems;

import java.util.ArrayList;
import java.util.List;

public class FpsPrioritizationList {
	private String prioritizationListId;
	private String listNm;
	private String cmtTxt;
	private String actvInd;
	private String shareGrpId;
	private List<FpsPrioritizationListItem> fpsPrioritizationListItems = new ArrayList<FpsPrioritizationListItem>();
	private String audtInsrtId;
	private String audtInsrtTs;
	private String audtUpdtId;
	private String audtUpdtTs;
	private List<FpsPrioritizationShareGrp> fpsPrioritizationShareGrps = new ArrayList<FpsPrioritizationShareGrp>();
	private String listCnt;
	private String listPrrtyCnt;
	private String listType;
	private List<FpsPrioritizationExclsnItems> fpsPrioritizationExclsnItems = new ArrayList<FpsPrioritizationExclsnItems>();
	private String usrJrsdctn;
	private String exclsnPublicInd;
	private String exclusionListCnt;
	private String removedInd;
	private String usrName;
	
	// constructor 
	public FpsPrioritizationList () {}
	
	// prioritizationListId
	public String getPrioritizationListId() {
		return prioritizationListId;
	}
	
	public void setPrioritizationListId(String prioritizationListId) {
		this.prioritizationListId = prioritizationListId;
	}
	
	// listNm
	public String getListNm() {
		return listNm;
	}
	
	public void setListNm(String listNm) {
		this.listNm = listNm;
	}
	
	// cmtTxt
	public String getCmtTxt() {
		return cmtTxt;
	}
	
	public void setCmtTxt(String cmtTxt) {
		this.cmtTxt = cmtTxt;
	}
	
	// actvInd
	public String getActvInd() {
		return actvInd;
	}
	
	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}
	
	// shareGrpId
	public String getShareGrpId() {
		return shareGrpId;
	}
	
	public void setShareGrpId(String shareGrpId) {
		this.shareGrpId = shareGrpId;
	}
	
	// fpsPrioritizationListItems
	public List<FpsPrioritizationListItem> getFpsPrioritizationListItems() {
		return fpsPrioritizationListItems;
	}
	
	public void setFpsPrioritizationListItems(List<FpsPrioritizationListItem> fpsPrioritizationListItems) {
		this.fpsPrioritizationListItems = fpsPrioritizationListItems;
	}
	
	// audtInsrtId
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	
	// audtInsrtTs
	public String getAudtInsrtTs() {
		return audtInsrtTs;
	}
	
	public void setAudtInsrtTs(String audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	
	// audtUpdtId
	public String getAudtUpdtId() {
		return audtUpdtId;
	}
	
	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	
	// audtUpdtTs
	public String getAudtUpdtTs() {
		return audtUpdtTs;
	}
	
	public void setAudtUpdtTs(String audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
	
	// fpsPrioritizationShareGrps
	public List<FpsPrioritizationShareGrp> getFpsPrioritizationShareGrps() {
		return fpsPrioritizationShareGrps;
	}
	
	public void setFpsPrioritizationShareGrps(List<FpsPrioritizationShareGrp> fpsPrioritizationShareGrps) {
		this.fpsPrioritizationShareGrps = fpsPrioritizationShareGrps;
	}
	
	// listCnt
	public String getListCnt() {
		return listCnt;
	}
	
	public void setListCnt(String listCnt) {
		this.listCnt = listCnt;
	}
	
	// listPrrtyCnt
	public String getListPrrtyCnt() {
		return listPrrtyCnt;
	}
	
	public void setListPrrtyCnt(String listPrrtyCnt) {
		this.listPrrtyCnt = listPrrtyCnt;
	}
	
	// listType
	public String getListType() {
		return listType;
	}
	
	public void setListType(String listType) {
		this.listType = listType;
	}
	
	// fpsPrioritizationExclsnItems
	public List<FpsPrioritizationExclsnItems> getFpsPrioritizationExclsnItems() {
		return fpsPrioritizationExclsnItems;
	}
	
	public void FpsPrioritizationExclsnItems(List<FpsPrioritizationExclsnItems> fpsPrioritizationExclsnItems) {
		this.fpsPrioritizationExclsnItems = fpsPrioritizationExclsnItems;
	}
	
	// usrJrsdctn
	public String getUsrJrsdctn() {
		return usrJrsdctn;
	}
	
	public void setUsrJrsdctn(String usrJrsdctn) {
		this.usrJrsdctn = usrJrsdctn;
	}
	
	// exclsnPublicInd
	public String getExclsnPublicInd() {
		return exclsnPublicInd;
	}
	
	public void setExclsnPublicInd(String exclsnPublicInd) {
		this.exclsnPublicInd = exclsnPublicInd;
	}
	
	// exclusionListCnt
	public String getExclusionListCnt() {
		return exclusionListCnt;
	}
	
	public void setExclusionListCnt(String exclusionListCnt) {
		this.exclusionListCnt = exclusionListCnt;
	}
	
	// removedInd
	public String getRemovedInd() {
		return removedInd;
	}
	
	public void setRemovedInd(String removedInd) {
		this.removedInd = removedInd;
	}
	
	// usrName
	public String getUsrName() {
		return usrName;
	}
	
	public void setUsrName(String usrName) {
		this.usrName = usrName;
	}
}
