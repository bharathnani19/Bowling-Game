package com.cms.fps2.wrappers.summary;

public class Activities {
	private String type;
	private String comments;
	private String count;
	private String date;
	private String userActivityId;
	private String activityTypeDesc;
	private String source;
	
	//empty constructor
	public Activities(){};
	
	//getters and setters
	
	//type
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	//comments
	public String getComments() {
		return comments;
	}
	
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	//count
	public String getCount() {
		return count;
	}
	
	public void setCount(String count) {
		this.count = count;
	}
	
	//date
	public String getDate() {
		return date;
	}
	
	public void setDate(String date) {
		this.date = date;
	}
	
	//userActivityId
	public String getUserActivityId() {
		return userActivityId;
	}
	
	public void setUserActivityId(String userActivityId) {
		this.userActivityId = userActivityId;
	}
	
	//activityTypeDesc
	public String getActivityTypeDesc() {
		return activityTypeDesc;
	}
	
	public void setActivityTypeDesc(String activityTypeDesc) {
		this.activityTypeDesc = activityTypeDesc;
	}
	
	//source
	public String getSource() {
		return source;
	}
	
	public void setSource(String source) {
		this.source = source;
	}
	
}
