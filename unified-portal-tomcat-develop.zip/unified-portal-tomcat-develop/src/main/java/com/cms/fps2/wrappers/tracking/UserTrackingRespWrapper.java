package com.cms.fps2.wrappers.tracking;

public class UserTrackingRespWrapper {
	private String responseMsg;
	
	//constructor
	public UserTrackingRespWrapper(){}
	
	//responseMsg
	public String getResponseMsg() {
		return responseMsg;
	}
	
	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}
}
