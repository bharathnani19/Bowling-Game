package com.cms.fps2.wrappers.details;

import java.util.ArrayList;
import java.util.List;

public class TpeResponseData {
	
	private String prioritized;
	List<Tpes> tpes = new ArrayList<Tpes>();
	
	// constructor
	public TpeResponseData() {}

	//prioritized
	public String getPrioritized() {
		return prioritized;
	}
	
	public void setPrioritized(String prioritized) {
		this.prioritized = prioritized;
	}
	
	//tpes
	public List<Tpes> getTpes() {
		return tpes;
	}
	
	public void setTpes(List<Tpes> tpes) {
		this.tpes = tpes;
	}
}
