package com.cms.fps2.wrappers.details.tab.prioritize;

public class PrioritizeUCMTabRequestWrapper {
	private String asrptId;
	private String userId;
	private String programType;
	
	//empty constructor
	public PrioritizeUCMTabRequestWrapper(){}
	
	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	//programType
	public String getProgramType() {
		return programType;
	}

	public void setProgramType(String programType) {
		this.programType = programType;
	}
}
