package com.cms.fps2.wrappers.summary.workitems;

public class ShareableUsersReqWrapper {
	private String groupId;
	private String userId;
	
	// constructor
	public ShareableUsersReqWrapper() {}
	
	// groupId
	public String getGroupId() {
		return groupId;
	}
	
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
