package com.cms.fps2.wrappers.ucm.leads;

public class UcmActions {
	private String userId;
	private String receivedDt;
	private String count;
	private String comments;
	private String desc;
	private String modelNm;
	private String rating;
	private String ucmId;
	private String eventDt;
	private String source;
	
	//empty constructor
	public UcmActions(){}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//receivedDt
	public String getReceivedDt() {
		return receivedDt;
	}
	
	public void setReceivedDt(String receivedDt) {
		this.receivedDt = receivedDt;
	}
	
	//count
	public String getCount() {
		return count;
	}
	
	public void setCount(String count) {
		this.count = count;
	}
	
	//comments
	public String getComments() {
		return comments;
	}
	
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	//desc
	public String getDesc() {
		return desc;
	}
	
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	//modelNm
	public String getModelNm() {
		return modelNm;
	}
	
	public void setModelNm(String modelNm) {
		this.modelNm = modelNm;
	}
	
	//rating
	public String getRating() {
		return rating;
	}
	
	public void setRating(String rating) {
		this.rating = rating;
	}
	
	//ucmId
	public String getUcmId() {
		return ucmId;
	}
	
	public void setUcmId(String ucmId) {
		this.ucmId = ucmId;
	}
	
	//eventDt
	public String getEventDt() {
		return eventDt;
	}
	
	public void setEventDt(String eventDt) {
		this.eventDt = eventDt;
	}
	
	//source
	public String getSource() {
		return source;
	}
	
	public void setSource(String source) {
		this.source = source;
	}
}
