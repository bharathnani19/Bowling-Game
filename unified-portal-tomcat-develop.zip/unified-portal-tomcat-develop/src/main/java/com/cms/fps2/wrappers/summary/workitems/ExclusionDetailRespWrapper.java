package com.cms.fps2.wrappers.summary.workitems;

import java.util.ArrayList;
import java.util.List;

public class ExclusionDetailRespWrapper {
	
	private String userId;
	private List<ExDetailExclusion> exclusions = new ArrayList<ExDetailExclusion>();
	
	// constructor
	public ExclusionDetailRespWrapper() {}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	// exclusions
	public List<ExDetailExclusion> getExclusions() {
		return exclusions;
	}
	
	public void setExclusions(List<ExDetailExclusion> exclusions) {
		this.exclusions = exclusions;
	}
}
