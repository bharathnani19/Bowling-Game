package com.cms.fps2.wrappers.details;

public class ApsRecs {
	
	private String identityId;
	private String npi;
	private String businessName;
	private String firstName;
	private String lastName;
	private String chargeDate;
	private String chargeType;
	private String county;
	private String courtName;
	private String crimSource;
	private String disposition;
	private String dispositionDate;
	private String incarcerationDate;
	private String sentence;
	private String sentenceDate;
	private String state;
	private String charge;
	private String courtJurisdiction;
	private String offenseId;
	private String updateDt;
	private String newInd;
	
	//constructor
	public ApsRecs() {}
	
	//identityId
	public String getIdentityId() {
		return identityId;
	}
	
	public void setIdentityId(String identityId) {
		this.identityId = identityId;
	}
	
	//npi
	public String getNpi() {
		return npi;
	}
	
	public void setNpi(String npi) {
		this.npi = npi;
	}
	
	//businessName
	public String getBusinessName() {
		return businessName;
	}
	
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	
	//firstName
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	//lastName
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	//chargeDate
	public String getChargeDate() {
		return chargeDate;
	}
	
	public void setChargeDate(String chargeDate) {
		this.chargeDate = chargeDate;
	}
	
	//chargeType
	public String getChargeType() {
		return chargeType;
	}
	
	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}
	
	//county
	public String getCounty() {
		return county;
	}
	
	public void setCounty(String county) {
		this.county = county;
	}
	
	//courtName
	public String getCourtName() {
		return courtName;
	}
	
	public void setCourtName(String courtName) {
		this.courtName = courtName;
	}
	
	//crimSource
	public String getCrimSource() {
		return crimSource;
	}
	
	public void setCrimSource(String crimSource) {
		this.crimSource = crimSource;
	}
	
	//disposition
	public String getDisposition() {
		return disposition;
	}
	
	public void setDisposition(String disposition) {
		this.disposition = disposition;
	}
	
	//dispositionDate
	public String getDispositionDate() {
		return dispositionDate;
	}
	
	public void setDispositionDate(String dispositionDate) {
		this.dispositionDate = dispositionDate;
	}
	
	//incarcerationDate
	public String getIncarcerationDate() {
		return incarcerationDate;
	}
	
	public void setIncarcerationDate(String incarcerationDate) {
		this.incarcerationDate = incarcerationDate;
	}
	
	//sentence
	public String getSentence() {
		return sentence;
	}
	
	public void setSentence(String sentence) {
		this.sentence = sentence;
	}
	
	//sentenceDate
	public String getSentenceDate() {
		return sentenceDate;
	}
	
	public void setSentenceDate(String sentenceDate) {
		this.sentenceDate = sentenceDate;
	}
	
	//state
	public String getState() {
		return state;
	}
	
	public void setState(String state) {
		this.state = state;
	}
	
	//charge
	public String getCharge() {
		return charge;
	}
	
	public void setCharge(String charge) {
		this.charge = charge;
	}
	
	//courtJurisdiction
	public String getCourtJurisdiction() {
		return courtJurisdiction;
	}
	
	public void setCourtJurisdiction(String courtJurisdiction) {
		this.courtJurisdiction = courtJurisdiction;
	}
	
	// offenseId
	public String getOffenseId() {
		return offenseId;
	}
	
	public void setOffenseId(String offenseId) {
		this.offenseId = offenseId;
	}
	
	// updateDt
	public String getUpdateDt() {
		return updateDt;
	}
	
	public void setUpdateDt(String updateDt) {
		this.updateDt = updateDt;
	}
	
	// newInd
	public String getNewInd() {
		return newInd;
	}
	
	public void setNewInd(String newInd) {
		this.newInd = newInd;
	}
}
