package com.cms.fps2.wrappers.summary.workitems;

public class FpsPrioritizationExclsnItems {
	// constructor
	public FpsPrioritizationExclsnItems() {}
}
