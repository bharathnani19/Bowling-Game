package com.cms.fps2.wrappers.summary.workitems;

import java.util.ArrayList;
import java.util.List;

public class ExDetailExclusion {
	
	private String asrptId;
	private String userNm;
	private String comments;
	private String addedDt;
	private String zone;
	private List<ExDetailExclusionCode> exclusions = new ArrayList<ExDetailExclusionCode>();
	private String removedDt;
	private String itemId;
	private String ownerId;
	
	// constructor
	public ExDetailExclusion() {}
	
	// asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	// userNm
	public String getUserNm() {
		return userNm;
	}
	
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	
	// comments
	public String getComments() {
		return comments;
	}
	
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	// addedDt
	public String getAddedDt() {
		return addedDt;
	}
	
	public void setAddedDt(String addedDt) {
		this.addedDt = addedDt;
	}
	
	// zone
	public String getZone() {
		return zone;
	}
	
	public void setZone(String zone) {
		this.zone = zone;
	}
	
	// exclusions
	public List<ExDetailExclusionCode> getExclusions() {
		return exclusions;
	}
	
	public void setExclusions(List<ExDetailExclusionCode> exclusions) {
		this.exclusions = exclusions;
	}
	
	// removedDt
	public String getRemovedDt() {
		return removedDt;
	}
	
	public void setRemovedDt(String removedDt) {
		this.removedDt = removedDt;
	}
	
	// itemId
	public String getItemId() {
		return itemId;
	}
	
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	
	// ownerId
	public String getOwnerId() {
		return ownerId;
	}
	
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

}
