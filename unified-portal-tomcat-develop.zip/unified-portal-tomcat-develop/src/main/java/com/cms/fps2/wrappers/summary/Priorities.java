package com.cms.fps2.wrappers.summary;

public class Priorities {
	
	private String asrDbId;
	private String userId;
	private String zone;
	private String addedDt;
	private String comments;
	private String asrId;
	private String cmsPriorityAsrInd;
	
	//empty constructor
	public Priorities(){}
	
	//asrDbId
	public String getAsrDbId() {
		return asrDbId;
	}
	
	public void setAsrDbId(String asrDbId) {
		this.asrDbId = asrDbId;
	}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}

	//zone
	public String getZone() {
		return zone;
	}
	
	public void setZone(String zone) {
		this.zone = zone;
	}
	
	//addedDt
	public String getAddedDt() {
		return addedDt;
	}
	
	public void setAddedDt(String addedDt) {
		this.addedDt = addedDt;
	}

	//comments
	public String getComments() {
		return comments;
	}
	
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	//asrId
	public String getAsrId() {
		return asrId;
	}
	
	public void setAsrId(String asrId) {
		this.asrId = asrId;
	}
	
	//cmsPriorityAsrInd
	public String getCmsPriorityAsrInd() {
		return cmsPriorityAsrInd;
	}
	
	public void setCmsPriorityAsrInd(String cmsPriorityAsrInd) {
		this.cmsPriorityAsrInd = cmsPriorityAsrInd;
	}
	
}
