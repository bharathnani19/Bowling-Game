package com.cms.fps2.wrappers.summary.modals;

public class PriorityCriteria {
		
		private String asrptId;
		private String criteriaDesc;
		private String criteriaScore;
		private String criteriaVal;
		private String criteriaWeight;
		private String rangeDesc;
		private String criteriaNm;
		
		//constructor
		public PriorityCriteria(){}
		
		//asrptId
		public String getAsrptId() {
			
			return asrptId;
		}
		
		public void setAsrptId(String asrptId) {
			this.asrptId = asrptId;
		}
		
		//criteriaDesc
		public String getCriteriaDesc() {
			
			return criteriaDesc;
		}
		
		public void setCriteriaDesc(String criteriaDesc) {
			this.criteriaDesc = criteriaDesc;
		}
		
		//criteriaScore
		public String getCriteriaScore() {
			
			return criteriaScore;
		}
		
		public void setCriteriaScore(String criteriaScore) {
			this.criteriaScore = criteriaScore;
		}
		
		//criteriaVal
		public String getCriteriaVal() {
			
			return criteriaVal;
		}
		
		public void setCriteriaVal(String criteriaVal) {
			this.criteriaVal = criteriaVal;
		}
		
		//criteriaWeight
		public String getCriteriaWeight() {
			
			return criteriaWeight;
		}
		
		public void setCriteriaWeight(String criteriaWeight) {
			this.criteriaWeight = criteriaWeight;
		}
		
		//rangeDesc
		public String getRangeDesc() {
			
			return rangeDesc;
		}
		
		public void setRangeDesc(String rangeDesc) {
			this.rangeDesc = rangeDesc;
		}
		
		//criteriaNm
		public String getCriteriaNm() {
			
			return criteriaNm;
		}
		
		public void setCriteriaNm(String criteriaNm) {
			this.criteriaNm = criteriaNm;
		}
}
