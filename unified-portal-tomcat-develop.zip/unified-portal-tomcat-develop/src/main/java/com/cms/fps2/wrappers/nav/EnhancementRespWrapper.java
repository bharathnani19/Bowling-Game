package com.cms.fps2.wrappers.nav;

public class EnhancementRespWrapper {
	private String status;
	
	// constructor
	public EnhancementRespWrapper() {}
	
	// status
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
}
