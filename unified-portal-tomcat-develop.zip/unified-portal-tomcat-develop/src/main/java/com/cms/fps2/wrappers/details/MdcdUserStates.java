package com.cms.fps2.wrappers.details;

public class MdcdUserStates {

	private String state;
	private String lclState;

	// state

	public String getState() {
		return state;
	}
	// lclState

	public String getLclState() {
		return lclState;
	}
	// state

	public void setState(String state) {
		this.state = state;
	}
	// lclState

	public void setLclState(String lclState) {
		this.lclState = lclState;
	}

}
