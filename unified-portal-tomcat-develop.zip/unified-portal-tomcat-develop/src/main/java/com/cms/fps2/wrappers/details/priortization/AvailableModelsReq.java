package com.cms.fps2.wrappers.details.priortization;

import java.util.ArrayList;
import java.util.List;

public class AvailableModelsReq {
	private List<Integer> asrptIds = new ArrayList<Integer>();
	private String programType;
	private String loggedInUserId;
	
	public String getLoggedInUserId() {
		return loggedInUserId;
	}
	
    /**
     * @return the programType
     */
	public String getProgramType(){
		return programType;
	}

	/**
	 * @return the asrptIds
	 */
	public List<Integer> getAsrptIds() {
		return asrptIds;
	}

	/**
	 * @param asrptIds the asrptIds to set
	 */
	public void setAsrptIds(List<Integer> asrptIds) {
		this.asrptIds = asrptIds;
	}
	/**
	 * @param programType  the programType to set
	 */
	public void setProgramType(String programType) {
		this.programType = programType;
	}
	
	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}

}
