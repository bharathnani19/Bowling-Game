package com.cms.fps2.wrappers.summary.workitems;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.landing.ShareUsersObj;

public class ShareableUsersRespWrapper {
	private List<ShareUsersObj> availableUsers = new ArrayList<ShareUsersObj>();
	private List<ShareUsersObj> sharedUsers = new ArrayList<ShareUsersObj>();
		
	// constructor
	public ShareableUsersRespWrapper() {}
	
	// availableUsers
	public List<ShareUsersObj> getAvailableUsers() {
		return availableUsers;
	}
	
	public void setAvailableUsers(List<ShareUsersObj> availableUsers) {
		this.availableUsers = availableUsers;
	}
	
	// sharedUsers
	public List<ShareUsersObj> getSharedUsers() {
		return sharedUsers;
	}
	
	public void setSharedUsers(List<ShareUsersObj> sharedUsers) {
		this.sharedUsers = sharedUsers;
	}

}
