package com.cms.fps2.wrappers.details;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.details.master.Alerts;
import com.cms.fps2.wrappers.details.master.ClaimLines;

public class MasterAlert {
	
	private Models models;
	private String currentInd;
	private String legacyInd;
	private List<String> reportCards = new ArrayList<String>();
	private List<ClaimLines> claimLines = new ArrayList<ClaimLines>();
	private String createdDt;
	private String modDt;
	private String riskScore;
	private String derivedZone;
	private String cost;
	private String alertCnt;
	private List<Alerts> alerts = new ArrayList<Alerts>();
	private String createdDtAsDate;
	private String legacyScore;
	private String modelId;
	private String asrptId;
	private String npi;
	private String modelTypeCd;
	private String hasReportCard;
	private String modelBusnsId;
	private String recentInd;
	private String priorityInd;
	private String status;
	private String lookback;
	private String showViz;
	private String relCreatedDt;
	private String vizType;
	private String modelStatus;
	private String alertId;
	private String partDClaimInd;
	private String state;
	private String mdcdState;
	private String pathToEduInd;
	private String sevScore;
	
	//constructor
	public MasterAlert(){}
	
	//models
	public Models getModels() {
		return models;
	}
	
	public void setModels(Models models) {
		this.models = models;
	}
	
	//currentInd
	public String getCurrentInd() {
		return currentInd;
	}
	
	public void setCurrentInd(String currentInd) {
		this.currentInd = currentInd;
	}
	
	//legacyInd
	public String getLegacyInd() {
		return legacyInd;
	}
	
	public void setLegacyInd(String legacyInd) {
		this.legacyInd = legacyInd;
	}	
	
	//reportCard
	public List<String> getReportCards() {
		return reportCards;
	}
	
	public void setReportCards(List<String> reportCards) {
		this.reportCards = reportCards;
	}	
	
	//claimLines
	public List<ClaimLines> getClaimLines() {
		return claimLines;
	}
	
	public void setClaimLines(List<ClaimLines> claimLines) {
		this.claimLines = claimLines;
	}
	
	//createdDt
	public String getCreatedDt() {
		return createdDt;
	}
	
	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}
	
	//modDt
	public String getModDt() {
		return modDt;
	}
	
	public void setModDt(String modDt) {
		this.modDt = modDt;
	}
	
	//riskScore
	public String getRiskScore() {
		return riskScore;
	}
	
	public void setRiskScore(String riskScore) {
		this.riskScore = riskScore;
	}
	
	//derivedZone
	public String getDerivedZone() {
		return derivedZone;
	}
	
	public void setDerivedZone(String derivedZone) {
		this.derivedZone = derivedZone;
	}
	
	//cost
	public String getCost() {
		return cost;
	}
	
	public void setCost(String cost) {
		this.cost = cost;
	}
	
	//alertCnt
	public String getAlertCnt() {
		return alertCnt;
	}
	
	public void setAlertCnt(String alertCnt) {
		this.alertCnt = alertCnt;
	}
	
	//alerts
	public List<Alerts> getAlerts() {
		return alerts;
	}
	
	public void setAlerts(List<Alerts> alerts) {
		this.alerts = alerts;
	}
	
	//createdDtAsDate
	public String getCreatedDtAsDate() {
		return createdDtAsDate;
	}
	
	public void setCreatedDtAsDate(String createdDtAsDate) {
		this.createdDtAsDate = createdDtAsDate;
	}
	
	//legacyScore
	public String getLegacyScore() {
		return legacyScore;
	}
	
	public void setLegacyScore(String legacyScore) {
		this.legacyScore = legacyScore;
	}
	
	// state
	
	public String getState() {
		return state;
	}

	// state
	
	public void setState(String state) {
		this.state = state;
	}

	//modelId
	public String getModelId() {
		return modelId;
	}
	
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	
	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	//npi
	public String getNpi() {
		return npi;
	}
	
	public void setNpi(String npi) {
		this.npi = npi;
	}
	
	//modelTypeCd
	public String getModelTypeCd() {		
		return modelTypeCd;
	}
	
	public void setModelTypeCd(String modelTypeCd) {
		this.modelTypeCd = modelTypeCd;
	}
	
	//hasReportCard
	public String getHasReportCard() {
		return hasReportCard;
	}
	
	public void setHasReportCard(String hasReportCard) {
		this.hasReportCard = hasReportCard;
	}
	
	//modelBusnsId
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	
	//recentInd
	public String getRecentInd() {
		return recentInd;
	}
	
	public void setRecentInd(String recentInd) {
		this.recentInd = recentInd;
	}
	
	//priorityInd
	public String getPriorityInd() {
		return priorityInd;
	}
	
	public void setPriorityInd(String priorityInd) {
		this.priorityInd = priorityInd;
	}
	
	//status
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	//lookback
	public String getLookback() {
		return lookback;
	}
	
	public void setLookback(String lookback) {
		this.lookback = lookback;
	}
	
	//showViz
	public String getShowViz() {
		return showViz;
	}
	
	public void setShowViz(String showViz) {
		this.showViz = showViz;
	}
	
	//relCreatedDt
	public String getRelCreatedDt() {
		return relCreatedDt;
	}
	
	public void setRelCreatedDt(String relCreatedDt) {
		this.relCreatedDt = relCreatedDt;
	}
	
	//vizType
	public String getVizType() {
		return vizType;
	}
	
	public void setVizType(String vizType) {
		this.vizType = vizType;
	}
	
	//modelStatus
	public String getModelStatus() {
		return modelStatus;
	}
	
	public void setModelStatus(String modelStatus) {
		this.modelStatus = modelStatus;
	}
	
	// alertId
	public String getAlertId() {
		return alertId;
	}
	
	public void setAlertId(String alertId) {
		this.alertId = alertId;
	}
	
	// partDClaimInd
	public String getPartDClaimInd() {
		return partDClaimInd;
	}
	
	public void setPartDClaimInd(String partDClaimInd) {
		this.partDClaimInd = partDClaimInd;
	}

	// mdcdState
	public String getMdcdState() {
		return mdcdState;
	}


	public void setMdcdState(String mdcdState) {
		this.mdcdState = mdcdState;
	}
	
	// pathToEduInd
	public String getpathToEduInd() {
		return pathToEduInd;
	}

	public void setpathToEduInd(String pathToEduInd) {
		this.pathToEduInd = pathToEduInd;
	}
	// sevScore
	public String getsevScore() {
		return sevScore;
	}

	public void setsevScore(String sevScore) {
		this.sevScore = sevScore;
	}
}
