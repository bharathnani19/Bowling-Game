package com.cms.fps2.wrappers.details.tab.totalzncost;

public class TotalZnCostRespWrapper {
	
	private ResponseData responseData;
	private String transactionID;
	private String status;
	private String responseType;
	
	//constructor
	public TotalZnCostRespWrapper(){}
	
	//responseData
	public ResponseData getResponseData() {
		return responseData;
	}
	
	public void setResponseData(ResponseData responseData) {
		this.responseData = responseData;
	}
	
	//transactionID
	public String getTransactionID() {
		return transactionID;
	}
	
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	
	//status
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	//responseType
	public String getResponseType() {
		return responseType;
	}
	
	public void setResponseType(String responseType) {
		this.responseType = responseType;
	}
}
