package com.cms.fps2.wrappers.landing;

public class ExListActionReqWrapper {
	private String userId;
	private String actionBool;
	
	// constructor
	public ExListActionReqWrapper() {}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	// actionBool
	public String getActionBool() {
		return actionBool;
	}
	
	public void setActionBool(String actionBool) {
		this.actionBool = actionBool;
	}
}
