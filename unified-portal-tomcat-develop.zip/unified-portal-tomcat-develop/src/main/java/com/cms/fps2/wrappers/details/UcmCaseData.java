package com.cms.fps2.wrappers.details;

public class UcmCaseData {
	
	private String caseID;
	private String subjectID;
	private String externalCaseID;
	
	//constructor
	public UcmCaseData(){}
	
	//caseID 	
	public String getCaseID() {
		return caseID;
	}
	
	public void setCaseID(String caseID) {
		this.caseID = caseID;
	}
	
	//subjectID 	
	public String getSubjectID() {
		return subjectID;
	}
	
	public void setSubjectID(String subjectID) {
		this.subjectID = subjectID;
	}
	
	//externalCaseID 	
	public String getExternalCaseID() {
		return externalCaseID;
	}
	
	public void setExternalCaseID(String externalCaseID) {
		this.externalCaseID = externalCaseID;
	}

}
