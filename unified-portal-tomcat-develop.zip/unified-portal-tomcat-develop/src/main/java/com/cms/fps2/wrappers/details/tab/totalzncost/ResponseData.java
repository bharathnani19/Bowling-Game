package com.cms.fps2.wrappers.details.tab.totalzncost;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.details.TotalCostZones;

public class ResponseData {
	private List<TotalCostZones> totalCostZones = new ArrayList<TotalCostZones>();
	private List<TotalCostZones> p1TotalCostZones = new ArrayList<TotalCostZones>();
	private String prioritized;
	
	//constructor
	public ResponseData(){}
	
	//totalCostZones
	public List<TotalCostZones> getTotalCostZones() {
		return totalCostZones;
	}
	
	public void setTotalCostZones(List<TotalCostZones> totalCostZones) {
		this.totalCostZones = totalCostZones;
	}

	//p1TotalCostZones
	public List<TotalCostZones> getP1TotalCostZones() {
		return p1TotalCostZones;
	}
	
	public void setP1TotalCostZones(List<TotalCostZones> p1TotalCostZones) {
		this.p1TotalCostZones = p1TotalCostZones;
	}
	
	
	//prioritized - this field is not used by the total cost tab
	public String getPrioritized() {
		return prioritized;
	}
	
	public void setPrioritized(String prioritized) {
		this.prioritized = prioritized;
	}
}
