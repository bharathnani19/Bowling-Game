package com.cms.fps2.wrappers.details;

public class AvailableClaims {
	private String atRiskInd;
	private String atRiskDInd;
	private String latestInd;
	private String latestDInd;
	private String allClaimsInd;
	private String allClaimsDInd;
	private String rrbInd;
	private String atRiskP1Ind;
	private String asrCostP1Ind;
	
	// constructor 
	public AvailableClaims() {}
	
	// atRiskInd
	public String getAtRiskInd() {		
		return atRiskInd;
	}
	
	public void setAtRiskInd(String atRiskInd) {
		this.atRiskInd = atRiskInd;
	}
	
	// atRiskDInd
	public String getAtRiskDInd() {		
		return atRiskDInd;
	}
	
	public void setAtRiskDInd(String atRiskDInd) {
		this.atRiskDInd = atRiskDInd;
	}
	
	// latestInd
	public String getLatestInd() {		
		return latestInd;
	}
	
	public void setLatestInd(String latestInd) {
		this.latestInd = latestInd;
	}
	
	// latestDInd
	public String getLatestDInd() {		
		return latestDInd;
	}
	
	public void setLatestDInd(String latestDInd) {
		this.latestDInd = latestDInd;
	}
	
	// allClaimsInd
	public String getAllClaimsInd() {		
		return allClaimsInd;
	}
	
	public void setAllClaimsInd(String allClaimsInd) {
		this.allClaimsInd = allClaimsInd;
	}
	
	// allClaimsDInd
	public String getAllClaimsDInd() {		
		return allClaimsDInd;
	}
	
	public void setAllClaimsDInd(String allClaimsDInd) {
		this.allClaimsDInd = allClaimsDInd;
	}
	
	// rrbInd
	public String getRrbInd() {		
		return rrbInd;
	}
	
	public void setRrbInd(String rrbInd) {
		this.rrbInd = rrbInd;
	}

	//atRiskP1Ind
	public String getAtRiskP1Ind() {		
		return atRiskP1Ind;
	}
	
	public void setAtRiskP1Ind(String atRiskP1Ind) {
		this.atRiskP1Ind = atRiskP1Ind;
	}

	//asrCostP1Ind
	public String getAsrCostP1Ind() {		
		return asrCostP1Ind;
	}
	
	public void setAsrCostP1Ind(String asrCostP1Ind) {
		this.asrCostP1Ind = asrCostP1Ind;
	}
}
