package com.cms.fps2.wrappers.details;

public class SubjectRoleCd {
	
	private String roleCd;
	
	//constructor
	public SubjectRoleCd(){}
	
	//roleCd 	
	public String getRoleCd() {
		return roleCd;
	}
	
	public void setRoleCd(String roleCd) {
		this.roleCd = roleCd;
	}
}
