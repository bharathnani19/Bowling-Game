package com.cms.fps2.wrappers.admin;

public class AdminMsgsReqWrapper {
	
	private String userId;
	private String userZone;
	
	//constructor
	public AdminMsgsReqWrapper(){}
	
	//userId
	public String getUserId() {		
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//userZone
	public String getUserZone() {		
		return userZone;
	}
	
	public void setUserZone(String userZone) {
		this.userZone = userZone;
	}
}
