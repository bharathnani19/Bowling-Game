package com.cms.fps2.wrappers.rptcard;

import java.util.ArrayList;
import java.util.List;

public class ReportCardResponseWrapper {

	private List<AaMulti> aaMulti = new ArrayList<AaMulti>();
	private List<AaSingle> aaSingle = new ArrayList<AaSingle>();
	private List<SocNet> socNet = new ArrayList<SocNet>();
	private List<Predict> predict = new ArrayList<Predict>();
	private List<RuleBased> ruleBased = new ArrayList<RuleBased>();
	private List<Unknown> unknown = new ArrayList<Unknown>();
	private List<CustomTables> customTables = new ArrayList<CustomTables>();
	private String fpsVersionInd;
	private List<String> reportCardDates = new ArrayList<String>();
	private String lookback;
	private String modelBusnsId;
	private String modelId;
	private String docUrl;
	private String hasMac;
	private String partDClaimInd;
	private String tableId;
	private List<RiskScoreRC> riskScoreRC = new ArrayList<RiskScoreRC>();
	private List<CustomVizTables> customVizTables = new ArrayList<CustomVizTables>();

	// constructor
	public ReportCardResponseWrapper() {
	}

	// aaMulti
	public List<AaMulti> getAaMulti() {
		return aaMulti;
	}

	public void setAaMulti(List<AaMulti> aaMulti) {
		this.aaMulti = aaMulti;
	}

	// aaSingle
	public List<AaSingle> getAaSingle() {
		return aaSingle;
	}

	public void setAaSingle(List<AaSingle> aaSingle) {
		this.aaSingle = aaSingle;
	}

	// socNet
	public List<SocNet> getSocNet() {
		return socNet;
	}

	public void setSocNet(List<SocNet> socNet) {
		this.socNet = socNet;
	}

	// predict
	public List<Predict> getPredict() {
		return predict;
	}

	public void setPredict(List<Predict> predict) {
		this.predict = predict;
	}

	// ruleBased
	public List<RuleBased> getRuleBased() {
		return ruleBased;
	}

	public void setRuleBased(List<RuleBased> ruleBased) {
		this.ruleBased = ruleBased;
	}

	// unknown
	public List<Unknown> getUnknown() {
		return unknown;
	}

	public void setUnknown(List<Unknown> unknown) {
		this.unknown = unknown;
	}

	// customTables
	public List<CustomTables> getCustomTables() {
		return customTables;
	}

	public void setCustomTables(List<CustomTables> customTables) {
		this.customTables = customTables;
	}

	// fpsVersionInd
	public String getFpsVersionInd() {
		return fpsVersionInd;
	}

	public void setFpsVersionInd(String fpsVersionInd) {
		this.fpsVersionInd = fpsVersionInd;
	}

	// reportCardDates
	public List<String> getReportCardDates() {
		return reportCardDates;
	}

	public void setReportCardDates(List<String> reportCardDates) {
		this.reportCardDates = reportCardDates;
	}

	// lookback
	public String getLookback() {
		return lookback;
	}

	public void setLookback(String lookback) {
		this.lookback = lookback;
	}

	// modelBusnsId
	public String getModelBusnsId() {
		return modelBusnsId;
	}

	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}

	// modelId
	public String getModelId() {
		return modelId;
	}

	public void setModelId(String modelId) {
		this.modelId = modelId;
	}

	// docUrl
	public String getDocUrl() {
		return docUrl;
	}

	public void setDocUrl(String docUrl) {
		this.docUrl = docUrl;
	}

	// hasMac
	public String getHasMac() {
		return hasMac;
	}

	public void setHasMac(String hasMac) {
		this.hasMac = hasMac;
	}

	// partDClaimInd
	public String getPartDClaimInd() {
		return partDClaimInd;
	}

	public void setPartDClaimInd(String partDClaimInd) {
		this.partDClaimInd = partDClaimInd;
	}

	// tableId
	public String gettableId() {
		return tableId;
	}

	public void settableId(String tableId) {
		this.tableId = tableId;
	}

	/**
	 * @return the riskScoreRC
	 */
	public List<RiskScoreRC> getRiskScoreRC() {
		return riskScoreRC;
	}

	/**
	 * @param riskScoreRC the riskScoreRC to set
	 */
	public void setRiskScoreRC(List<RiskScoreRC> riskScoreRC) {
		this.riskScoreRC = riskScoreRC;
	}

	 /**
	 * @return the customVizTables
	 * */
	public List<CustomVizTables> getcustomVizTables() {
		return customVizTables;
	}

	/**
	 * @param customVizTables 
	 */

	public void setcustomVizTables(List<CustomVizTables> customVizTables) {
		this.customVizTables = customVizTables;
	}

}
