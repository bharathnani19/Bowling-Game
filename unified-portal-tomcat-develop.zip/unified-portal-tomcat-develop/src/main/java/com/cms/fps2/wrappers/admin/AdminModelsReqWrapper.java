package com.cms.fps2.wrappers.admin;

public class AdminModelsReqWrapper {
	private String modelId;
	private String modelDesc;
	private String activeStatus;
	private String ownerName;
	private String ownerEmail;
	private String ownerPhone;
	private String lastUpdateUser;
	private String loggedInUserId;
	private String priorityInd;
	
	//constructor
	public AdminModelsReqWrapper(){} 
	
	//modelId
	public String getModelId() {
		return modelId;
	}
	
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	
	//modelDesc
	public String getModelDesc() {
		return modelDesc;
	}
	
	public void setModelDesc(String modelDesc) {
		this.modelDesc = modelDesc;
	}
	
	//activeStatus
	public String getActiveStatus() {
		return activeStatus;
	}
	
	public void setActiveStatus(String activeStatus) {
		this.activeStatus = activeStatus;
	}
	
	//ownerName
	public String getOwnerName() {
		return ownerName;
	}
	
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	
	//ownerEmail
	public String getOwnerEmail() {
		return ownerEmail;
	}
	
	public void setOwnerEmail(String ownerEmail) {
		this.ownerEmail = ownerEmail;
	}
	
	//ownerPhone
	public String getOwnerPhone() {
		return ownerPhone;
	}
	
	public void setOwnerPhone(String ownerPhone) {
		this.ownerPhone = ownerPhone;
	}
	
	//lastUpdateUser
	public String getLastUpdateUser() {
		return lastUpdateUser;
	}
	
	public void setLastUpdateUser(String lastUpdateUser) {
		this.lastUpdateUser = lastUpdateUser;
	}
	
	//loggedInUserId
	public String getLoggedInUserId() {
		return loggedInUserId;
	}
	
	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}
	
	//priorityInd
	public String getPriorityInd() {
		return priorityInd;
	}
	
	public void setPriorityInd(String priorityInd) {
		this.priorityInd = priorityInd;
	}
	
}
