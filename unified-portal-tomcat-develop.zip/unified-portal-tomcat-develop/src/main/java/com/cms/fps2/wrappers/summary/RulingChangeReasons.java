package com.cms.fps2.wrappers.summary;

public class RulingChangeReasons {
	
	private String rulingChangeReasonDesc;
	private String rulingChangeReasonCd;
	
	//constructor
	public RulingChangeReasons() {}
	
	//rulingChangeReasonDesc
	public String getRulingChangeReasonDesc() {
		return rulingChangeReasonDesc;
	}
	
	public void setRulingChangeReasonDesc(String rulingChangeReasonDesc) {
		this.rulingChangeReasonDesc = rulingChangeReasonDesc;
	}
	
	//rulingChangeReasonCd
	public String getRulingChangeReasonCd() {
		return rulingChangeReasonCd;
	}
	
	public void setRulingChangeReasonCd(String rulingChangeReasonCd) {
		this.rulingChangeReasonCd = rulingChangeReasonCd;
	}
}
