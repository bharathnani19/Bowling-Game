package com.cms.fps2.wrappers.details.tab.history;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.details.History;

public class ResponseData {
	//use the History Object from the ASR Details general details response
	private List<History> history = new ArrayList<History>();
	
	//constructor
	public ResponseData(){}
	
	//leads
	public List<History> getHistory() {
		return history;
	}
	
	public void setHistory(List<History> history) {
		this.history = history;
	}
}
