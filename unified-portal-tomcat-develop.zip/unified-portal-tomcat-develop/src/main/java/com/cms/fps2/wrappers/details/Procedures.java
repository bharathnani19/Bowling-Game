package com.cms.fps2.wrappers.details;

public class Procedures {
	
	private String procedureTypeCd;
	private String procedureTypeDesc;
	
	//constructor
	public Procedures() {}
	
	//procedureTypeCd
	public String getProcedureTypeCd() {
		return procedureTypeCd;
	}
	
	public void setProcedureTypeCd(String procedureTypeCd) {
		this.procedureTypeCd = procedureTypeCd;
	}
	
	//procedureTypeDesc
	public String getProcedureTypeDesc() {
		return procedureTypeDesc;
	}
	
	public void setProcedureTypeDesc(String procedureTypeDesc) {
		this.procedureTypeDesc = procedureTypeDesc;
	}
}
