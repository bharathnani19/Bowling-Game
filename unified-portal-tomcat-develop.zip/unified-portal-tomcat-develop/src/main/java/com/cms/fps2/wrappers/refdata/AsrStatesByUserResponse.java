package com.cms.fps2.wrappers.refdata;

public class AsrStatesByUserResponse {

	private String state;
	private String lclState;

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getLclState() {
		return lclState;
	}

	public void setLclState(String lclState) {
		this.lclState = lclState;
	}
}
