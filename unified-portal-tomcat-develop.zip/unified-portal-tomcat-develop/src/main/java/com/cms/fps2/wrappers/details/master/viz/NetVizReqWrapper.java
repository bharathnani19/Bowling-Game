package com.cms.fps2.wrappers.details.master.viz;

public class NetVizReqWrapper {
	
	private String modelId;
	private String asrptId;
	private String userId;
	
	//constructor
	public NetVizReqWrapper(){}
	
	//modelId
	public String getModelId() {
		return modelId;
	}
	
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	
	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
