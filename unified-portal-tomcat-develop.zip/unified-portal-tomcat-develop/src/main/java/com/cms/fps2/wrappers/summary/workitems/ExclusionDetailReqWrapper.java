package com.cms.fps2.wrappers.summary.workitems;

public class ExclusionDetailReqWrapper {
	
	private String userId;
	private String asrId;
	
	// constructor
	public ExclusionDetailReqWrapper() {}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	// asrId
	public String getAsrId() {
		return asrId;
	}
	
	public void setAsrId(String asrId) {
		this.asrId = asrId;
	}

}
