package com.cms.fps2.wrappers.details.tab.partdrpt;

import java.util.ArrayList;
import java.util.List;

public class Reports {
	
	private String type;
	private String audtInsrtId;
	private String audtInsrtTs;
	private String audtUpdtId;
	private String audtUpdtTs;
	private String enrlmtSpcltyDesc1;
	private String enrlmtSpcltyDesc2;
	private String enrlmtSpcltyDesc3;
	private String enrlmtSpcltyDesc4;
	private String enrlmtSpcltyDesc5;
	private String fidActv;
	private String fidInactv;
	private String fidLastPmtSuspnsnBgnDt;
	private String fidLastPmtSuspnsnEndDt;
	private String opAvgMmeBene;
	private String opAvgMmeBenePct;
	private String opAvgMmeShpngBene;
	private String opBene;
	private String opBenePct;
	private String opDailyMmeBene;
	private String opDailyMmeShpngBene;
	private String opLines;
	private String opLinesPct;
	private String opLinesPerBene;
	private String opLinesPerBenePerDay;
	private String opPhrmcyShpngBene;
	private String opPmt;
	private String opPmtPct;
	private String opPmtPerBene;
	private String opPrscrbrShpngBene;
	private String pecosEnrlmtAprvd;
	private String pecosEnrlmtDactvtd;
	private String pecosEnrlmtMisg;
	private String pecosEnrlmtOptout;
	private String pecosEnrlmtOthr;
	private String pecosEnrlmtRvked;
	private String pecosEnrlmtTot;
	private String prscrbrName;
	private String stateCd1;
	private String stateCd2;
	private String stateCd3;
	private String stateCd4;
	private String stateCd5;
	private String stateCd6;
	private String stateCd7;
	private String stateCd8;
	private String stateCd9;
	private String stateCd10;
	private String stdyPrdEnd;
	private String stdyPrdStrt;
	private String totBene;
	private String totLines;
	private String totPmt;
	private String bzoBene;
	private String bzoBenePct;
	private String bzoLines;
	private String bzoLinesPct;
	private String bzoLinesPerBene;
	private String bzoPmt;
	private String bzoPmtPct;
	private String bzoPmtPerBene;
	private String opBzoCncrnt7Bene;
	private String opBzoCncrnt7BeneMmePct;
	private String opBzoCncrnt7BenePct;
	private String opBzoCncrnt7MmeBene;
	private String opBzoCncrntBene;
	private String opBzoCncrntBenePct;
	private String opBeneErOd1Day;
	private String opBeneErOd30Days;
	private String opBeneErOd30Mme;
	private String opBeneErOd7Days;
	private String opBeneErOd90Days;
	private String opAvgMmeShpngBenePct;
	private String opDailyMmeBenePct;
	private String opDailyMmeShpngBenePct;
	private String opNdcPerBene;
	private String opPhrmcyShpngBenePct;
	private String opPrscrbrShpngBenePct;
	private String opRxTop1Pct;
	private String opRxTop10Pct;
	private String opRxTop25Pct;
	private String opRxTop5Pct;
	private String opBeneTop1Pct;
	private String opBeneTop10Pct;
	private String opBeneTop25Pct;
	private String opBeneTop5Pct;
	private String opBeneErOd30AvgMme;
	private String fidLastPmtSuspnsnBgnDtStr;
	private String fidLastPmtSuspnsnEndDtStr;
	private String stdyPrdEndStr;
	private String stdyPrdStrtStr;
	private String prscrbrNpi;
	private String adHocReport;
	private String name;
	private List<AdHocCols> adHocCols = new ArrayList<AdHocCols>();
	
	//constructor
	public Reports(){}
	
	//type
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	//audtInsrtId
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	
	//audtInsrtTs
	public String getAudtInsrtTs() {
		return audtInsrtTs;
	}
	
	public void setAudtInsrtTs(String audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	
	//audtUpdtId
	public String getAudtUpdtId() {
		return audtUpdtId;
	}
	
	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	
	//audtUpdtTs
	public String getAudtUpdtTs() {
		return audtUpdtTs;
	}
	
	public void setAudtUpdtTs(String audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}

	//enrlmtSpcltyDesc1
	public String getEnrlmtSpcltyDesc1() {
		return enrlmtSpcltyDesc1;
	}
	
	public void setEnrlmtSpcltyDesc1(String enrlmtSpcltyDesc1) {
		this.enrlmtSpcltyDesc1 = enrlmtSpcltyDesc1;
	}
	
	//enrlmtSpcltyDesc2
	public String getEnrlmtSpcltyDesc2() {
		return enrlmtSpcltyDesc2;
	}
	
	public void setEnrlmtSpcltyDesc2(String enrlmtSpcltyDesc2) {
		this.enrlmtSpcltyDesc2 = enrlmtSpcltyDesc2;
	}
	
	//enrlmtSpcltyDesc3
	public String getEnrlmtSpcltyDesc3() {
		return enrlmtSpcltyDesc3;
	}
	
	public void setEnrlmtSpcltyDesc3(String enrlmtSpcltyDesc3) {
		this.enrlmtSpcltyDesc3 = enrlmtSpcltyDesc3;
	}
	
	//enrlmtSpcltyDesc4
	public String getEnrlmtSpcltyDesc4() {
		return enrlmtSpcltyDesc4;
	}
	
	public void setEnrlmtSpcltyDesc4(String enrlmtSpcltyDesc4) {
		this.enrlmtSpcltyDesc4 = enrlmtSpcltyDesc4;
	}
	
	//enrlmtSpcltyDesc5
	public String getEnrlmtSpcltyDesc5() {
		return enrlmtSpcltyDesc5;
	}
	
	public void setEnrlmtSpcltyDesc5(String enrlmtSpcltyDesc5) {
		this.enrlmtSpcltyDesc5 = enrlmtSpcltyDesc5;
	}
	
	//fidActv
	public String getFidActv() {
		return fidActv;
	}
	
	public void setFidActv(String fidActv) {
		this.fidActv = fidActv;
	}
	
	//fidInactv
	public String getFidInactv() {
		return fidInactv;
	}
	
	public void setFidInactv(String fidInactv) {
		this.fidInactv = fidInactv;
	}
	
	//fidLastPmtSuspnsnBgnDt
	public String getFidLastPmtSuspnsnBgnDt() {
		return fidLastPmtSuspnsnBgnDt;
	}
	
	public void setFidLastPmtSuspnsnBgnDt(String fidLastPmtSuspnsnBgnDt) {
		this.fidLastPmtSuspnsnBgnDt = fidLastPmtSuspnsnBgnDt;
	}
	
	//fidLastPmtSuspnsnEndDt
	public String getFidLastPmtSuspnsnEndDt() {
		return fidLastPmtSuspnsnEndDt;
	}
	
	public void setFidLastPmtSuspnsnEndDt(String fidLastPmtSuspnsnEndDt) {
		this.fidLastPmtSuspnsnEndDt = fidLastPmtSuspnsnEndDt;
	}
	
	//opAvgMmeBene
	public String getOpAvgMmeBene() {
		return opAvgMmeBene;
	}
	
	public void setOpAvgMmeBene(String opAvgMmeBene) {
		this.opAvgMmeBene = opAvgMmeBene;
	}
	
	//opAvgMmeBenePct
	public String getOpAvgMmeBenePct() {
		return opAvgMmeBenePct;
	}
	
	public void setOpAvgMmeBenePct(String opAvgMmeBenePct) {
		this.opAvgMmeBenePct = opAvgMmeBenePct;
	}
	
	//opAvgMmeShpngBene
	public String getOpAvgMmeShpngBene() {
		return opAvgMmeShpngBene;
	}
	
	public void setOpAvgMmeShpngBene(String opAvgMmeShpngBene) {
		this.opAvgMmeShpngBene = opAvgMmeShpngBene;
	}
	
	//opBene
	public String getOpBene() {
		return opBene;
	}
	
	public void setOpBene(String opBene) {
		this.opBene = opBene;
	}
	
	//opBenePct
	public String getOpBenePct() {
		return opBenePct;
	}
	
	public void setOpBenePct(String opBenePct) {
		this.opBenePct = opBenePct;
	}
	
	//opDailyMmeBene
	public String getOpDailyMmeBene() {
		return opDailyMmeBene;
	}
	
	public void setOpDailyMmeBene(String opDailyMmeBene) {
		this.opDailyMmeBene = opDailyMmeBene;
	}
	
	//opDailyMmeShpngBene
	public String getOpDailyMmeShpngBene() {
		return opDailyMmeShpngBene;
	}
	
	public void setOpDailyMmeShpngBene(String opDailyMmeShpngBene) {
		this.opDailyMmeShpngBene = opDailyMmeShpngBene;
	}
	
	//opLines
	public String getOpLines() {
		return opLines;
	}
	
	public void setOpLines(String opLines) {
		this.opLines = opLines;
	}
	
	//opLinesPct
	public String getOpLinesPct() {
		return opLinesPct;
	}
	
	public void setOpLinesPct(String opLinesPct) {
		this.opLinesPct = opLinesPct;
	}
	
	//opLinesPerBene
	public String getOpLinesPerBene() {
		return opLinesPerBene;
	}
	
	public void setOpLinesPerBene(String opLinesPerBene) {
		this.opLinesPerBene = opLinesPerBene;
	}
	
	//opLinesPerBenePerDay
	public String getOpLinesPerBenePerDay() {
		return opLinesPerBenePerDay;
	}
	
	public void setOpLinesPerBenePerDay(String opLinesPerBenePerDay) {
		this.opLinesPerBenePerDay = opLinesPerBenePerDay;
	}
	
	//opPhrmcyShpngBene
	public String getOpPhrmcyShpngBene() {
		return opPhrmcyShpngBene;
	}
	
	public void setOpPhrmcyShpngBene(String opPhrmcyShpngBene) {
		this.opPhrmcyShpngBene = opPhrmcyShpngBene;
	}
	
	//opPmt
	public String getOpPmt() {
		return opPmt;
	}
	
	public void setOpPmt(String opPmt) {
		this.opPmt = opPmt;
	}
	
	//opPmtPct
	public String getOpPmtPct() {
		return opPmtPct;
	}
	
	public void setOpPmtPct(String opPmtPct) {
		this.opPmtPct = opPmtPct;
	}
	
	//opPmtPerBene
	public String getOpPmtPerBene() {
		return opPmtPerBene;
	}
	
	public void setOpPmtPerBene(String opPmtPerBene) {
		this.opPmtPerBene = opPmtPerBene;
	}
	
	//opPrscrbrShpngBene
	public String getOpPrscrbrShpngBene() {
		return opPrscrbrShpngBene;
	}
	
	public void setOpPrscrbrShpngBene(String opPrscrbrShpngBene) {
		this.opPrscrbrShpngBene = opPrscrbrShpngBene;
	}
	
	//pecosEnrlmtAprvd
	public String getPecosEnrlmtAprvd() {
		return pecosEnrlmtAprvd;
	}
	
	public void setPecosEnrlmtAprvd(String pecosEnrlmtAprvd) {
		this.pecosEnrlmtAprvd = pecosEnrlmtAprvd;
	}
	
	//pecosEnrlmtDactvtd
	public String getPecosEnrlmtDactvtd() {
		return pecosEnrlmtDactvtd;
	}
	
	public void setPecosEnrlmtDactvtd(String pecosEnrlmtDactvtd) {
		this.pecosEnrlmtDactvtd = pecosEnrlmtDactvtd;
	}
	
	//pecosEnrlmtMisg
	public String getPecosEnrlmtMisg() {
		return pecosEnrlmtMisg;
	}
	
	public void setPecosEnrlmtMisg(String pecosEnrlmtMisg) {
		this.pecosEnrlmtMisg = pecosEnrlmtMisg;
	}
	
	//pecosEnrlmtOptout
	public String getPecosEnrlmtOptout() {
		return pecosEnrlmtOptout;
	}
	
	public void setPecosEnrlmtOptout(String pecosEnrlmtOptout) {
		this.pecosEnrlmtOptout = pecosEnrlmtOptout;
	}
	
	//pecosEnrlmtOthr
	public String getPecosEnrlmtOthr() {
		return pecosEnrlmtOthr;
	}
	
	public void setPecosEnrlmtOthr(String pecosEnrlmtOthr) {
		this.pecosEnrlmtOthr = pecosEnrlmtOthr;
	}
	
	//pecosEnrlmtRvked
	public String getPecosEnrlmtRvked() {
		return pecosEnrlmtRvked;
	}
	
	public void setPecosEnrlmtRvked(String pecosEnrlmtRvked) {
		this.pecosEnrlmtRvked = pecosEnrlmtRvked;
	}
	
	//pecosEnrlmtTot
	public String getPecosEnrlmtTot() {
		return pecosEnrlmtTot;
	}
	
	public void setPecosEnrlmtTot(String pecosEnrlmtTot) {
		this.pecosEnrlmtTot = pecosEnrlmtTot;
	}
	
	//prscrbrName
	public String getPrscrbrName() {
		return prscrbrName;
	}
	
	public void setPrscrbrName(String prscrbrName) {
		this.prscrbrName = prscrbrName;
	}
	
	//stateCd1
	public String getStateCd1() {
		return stateCd1;
	}
	
	public void setStateCd1(String stateCd1) {
		this.stateCd1 = stateCd1;
	}
	
	//stateCd2
	public String getStateCd2() {
		return stateCd2;
	}
	
	public void setStateCd2(String stateCd2) {
		this.stateCd2 = stateCd2;
	}
	
	//stateCd3
	public String getStateCd3() {
		return stateCd3;
	}
	
	public void setStateCd3(String stateCd3) {
		this.stateCd3 = stateCd3;
	}
	
	//stateCd4
	public String getStateCd4() {
		return stateCd4;
	}
	
	public void setStateCd4(String stateCd4) {
		this.stateCd4 = stateCd4;
	}
	
	//stateCd5
	public String getStateCd5() {
		return stateCd5;
	}
	
	public void setStateCd5(String stateCd5) {
		this.stateCd5 = stateCd5;
	}
	
	//stateCd6
	public String getStateCd6() {
		return stateCd6;
	}
	
	public void setStateCd6(String stateCd6) {
		this.stateCd6 = stateCd6;
	}
	
	//stateCd7
	public String getStateCd7() {
		return stateCd7;
	}
	
	public void setStateCd7(String stateCd7) {
		this.stateCd7 = stateCd7;
	}
	
	//stateCd8
	public String getStateCd8() {
		return stateCd8;
	}
	
	public void setStateCd8(String stateCd8) {
		this.stateCd8 = stateCd8;
	}
	
	//stateCd9
	public String getStateCd9() {
		return stateCd9;
	}
	
	public void setStateCd9(String stateCd9) {
		this.stateCd9 = stateCd9;
	}
	
	//stateCd10
	public String getStateCd10() {
		return stateCd10;
	}
	
	public void setStateCd10(String stateCd10) {
		this.stateCd10 = stateCd10;
	}
	
	//stdyPrdEnd
	public String getStdyPrdEnd() {
		return stdyPrdEnd;
	}
	
	public void setStdyPrdEnd(String stdyPrdEnd) {
		this.stdyPrdEnd = stdyPrdEnd;
	}
	
	//stdyPrdStart
	public String getStdyPrdStrt() {
		return stdyPrdStrt;
	}
	
	public void setStdyPrdStrt(String stdyPrdStrt) {
		this.stdyPrdStrt = stdyPrdStrt;
	}
	
	//totBene
	public String getTotBene() {
		return totBene;
	}
	
	public void setTotBene(String totBene) {
		this.totBene = totBene;
	}
	
	//totLines
	public String getTotLines() {
		return totLines;
	}
	
	public void setTotLines(String totLines) {
		this.totLines = totLines;
	}
	
	//totPmt
	public String getTotPmt() {
		return totPmt;
	}
	
	public void setTotPmt(String totPmt) {
		this.totPmt = totPmt;
	}
	
	//bzoBene
	public String getBzoBene() {
		return bzoBene;
	}
	
	public void setBzoBene(String bzoBene) {
		this.bzoBene = bzoBene;
	}
	
	//bzoBenePct
	public String getBzoBenePct() {
		return bzoBenePct;
	}
	
	public void setBzoBenePct(String bzoBenePct) {
		this.bzoBenePct = bzoBenePct;
	}
	
	//bzoLines
	public String getBzoLines() {
		return bzoLines;
	}
	
	public void setBzoLines(String bzoLines) {
		this.bzoLines = bzoLines;
	}
	
	//bzoLinesPct
	public String getBzoLinesPct() {
		return bzoLinesPct;
	}
	
	public void setBzoLinesPct(String bzoLinesPct) {
		this.bzoLinesPct = bzoLinesPct;
	}
	
	//bzoLinesPerBene
	public String getBzoLinesPerBene() {
		return bzoLinesPerBene;
	}
	
	public void setBzoLinesPerBene(String bzoLinesPerBene) {
		this.bzoLinesPerBene = bzoLinesPerBene;
	}
	
	//bzoPmt
	public String getBzoPmt() {
		return bzoPmt;
	}
	
	public void setBzoPmt(String bzoPmt) {
		this.bzoPmt = bzoPmt;
	}
	
	//bzoPmtPct
	public String getBzoPmtPct() {
		return bzoPmtPct;
	}
	
	public void setBzoPmtPct(String bzoPmtPct) {
		this.bzoPmtPct = bzoPmtPct;
	}
	
	//bzoPmtPerBene
	public String getBzoPmtPerBene() {
		return bzoPmtPerBene;
	}
	
	public void setBzoPmtPerBene(String bzoPmtPerBene) {
		this.bzoPmtPerBene = bzoPmtPerBene;
	}
	
	//opBzoCncrnt7Bene
	public String getOpBzoCncrnt7Bene() {
		return opBzoCncrnt7Bene;
	}
	
	public void setOpBzoCncrnt7Bene(String opBzoCncrnt7Bene) {
		this.opBzoCncrnt7Bene = opBzoCncrnt7Bene;
	}
	
	//opBzoCncrnt7BeneMmePct
	public String getOpBzoCncrnt7BeneMmePct() {
		return opBzoCncrnt7BeneMmePct;
	}
	
	public void setOpBzoCncrnt7BeneMmePct(String opBzoCncrnt7BeneMmePct) {
		this.opBzoCncrnt7BeneMmePct = opBzoCncrnt7BeneMmePct;
	}
	
	//opBzoCncrnt7BenePct
	public String getOpBzoCncrnt7BenePct() {
		return opBzoCncrnt7BenePct;
	}
	
	public void setOpBzoCncrnt7BenePct(String opBzoCncrnt7BenePct) {
		this.opBzoCncrnt7BenePct = opBzoCncrnt7BenePct;
	}
	
	//opBzoCncrnt7MmeBene
	public String getOpBzoCncrnt7MmeBene() {
		return opBzoCncrnt7MmeBene;
	}
	
	public void setOpBzoCncrnt7MmeBene(String opBzoCncrnt7MmeBene) {
		this.opBzoCncrnt7MmeBene = opBzoCncrnt7MmeBene;
	}
	
	//opBzoCncrntBene
	public String getOpBzoCncrntBene() {
		return opBzoCncrntBene;
	}
	
	public void setOpBzoCncrntBene(String opBzoCncrntBene) {
		this.opBzoCncrntBene = opBzoCncrntBene;
	}
	
	//opBzoCncrntBenePct
	public String getOpBzoCncrntBenePct() {
		return opBzoCncrntBenePct;
	}
	
	public void setOpBzoCncrntBenePct(String opBzoCncrntBenePct) {
		this.opBzoCncrntBenePct = opBzoCncrntBenePct;
	}
	
	//opBeneErOd1Day
	public String getOpBeneErOd1Day() {
		return opBeneErOd1Day;
	}
	
	public void setOpBeneErOd1Day(String opBeneErOd1Day) {
		this.opBeneErOd1Day = opBeneErOd1Day;
	}
	
	//opBeneErOd30Days
	public String getOpBeneErOd30Days() {
		return opBeneErOd30Days;
	}
	
	public void setOpBeneErOd30Days(String opBeneErOd30Days) {
		this.opBeneErOd30Days = opBeneErOd30Days;
	}
	
	//opBeneErOd30Mme
	public String getOpBeneErOd30Mme() {
		return opBeneErOd30Mme;
	}
	
	public void setOpBeneErOd30Mme(String opBeneErOd30Mme) {
		this.opBeneErOd30Mme = opBeneErOd30Mme;
	}
	
	//opBeneErOd7Days
	public String getOpBeneErOd7Days() {
		return opBeneErOd7Days;
	}
	
	public void setOpBeneErOd7Days(String opBeneErOd7Days) {
		this.opBeneErOd7Days = opBeneErOd7Days;
	}
	
	//opBeneErOd90Days
	public String getOpBeneErOd90Days() {
		return opBeneErOd90Days;
	}
	
	public void setOpBeneErOd90Days(String opBeneErOd90Days) {
		this.opBeneErOd90Days = opBeneErOd90Days;
	}
	
	//opAvgMmeShpngBenePct
	public String getOpAvgMmeShpngBenePct() {
		return opAvgMmeShpngBenePct;
	}
	
	public void setOpAvgMmeShpngBenePct(String opAvgMmeShpngBenePct) {
		this.opAvgMmeShpngBenePct = opAvgMmeShpngBenePct;
	}
	
	//opDailyMmeBenePct
	public String getOpDailyMmeBenePct() {
		return opDailyMmeBenePct;
	}
	
	public void setOpDailyMmeBenePct(String opDailyMmeBenePct) {
		this.opDailyMmeBenePct = opDailyMmeBenePct;
	}
	
	//opDailyMmeShpngBenePct
	public String getOpDailyMmeShpngBenePct() {
		return opDailyMmeShpngBenePct;
	}
	
	public void setOpDailyMmeShpngBenePct(String opDailyMmeShpngBenePct) {
		this.opDailyMmeShpngBenePct = opDailyMmeShpngBenePct;
	}
	
	//opNdcPerBene
	public String getOpNdcPerBene() {
		return opNdcPerBene;
	}
	
	public void setOpNdcPerBene(String opNdcPerBene) {
		this.opNdcPerBene = opNdcPerBene;
	}
	
	//opPhrmcyShpngBenePct
	public String getOpPhrmcyShpngBenePct() {
		return opPhrmcyShpngBenePct;
	}
	
	public void setOpPhrmcyShpngBenePct(String opPhrmcyShpngBenePct) {
		this.opPhrmcyShpngBenePct = opPhrmcyShpngBenePct;
	}
	
	//opPrscrbrShpngBenePct
	public String getOpPrscrbrShpngBenePct() {
		return opPrscrbrShpngBenePct;
	}
	
	public void setOpPrscrbrShpngBenePct(String opPrscrbrShpngBenePct) {
		this.opPrscrbrShpngBenePct = opPrscrbrShpngBenePct;
	}
	
	//opRxTop1Pct
	public String getOpRxTop1Pct() {
		return opRxTop1Pct;
	}
	
	public void setOpRxTop1Pct(String opRxTop1Pct) {
		this.opRxTop1Pct = opRxTop1Pct;
	}
	
	//opRxTop10Pct
	public String getOpRxTop10Pct() {
		return opRxTop10Pct;
	}
	
	public void setOpRxTop10Pct(String opRxTop10Pct) {
		this.opRxTop10Pct = opRxTop10Pct;
	}
	
	//opRxTop25Pct
	public String getOpRxTop25Pct() {
		return opRxTop25Pct;
	}
	
	public void setOpRxTop25Pct(String opRxTop25Pct) {
		this.opRxTop25Pct = opRxTop25Pct;
	}
	
	//opRxTop5Pct
	public String getOpRxTop5Pct() {
		return opRxTop5Pct;
	}
	
	public void setOpRxTop5Pct(String opRxTop5Pct) {
		this.opRxTop5Pct = opRxTop5Pct;
	}
	
	//opBeneTop1Pct
	public String getOpBeneTop1Pct() {
		return opBeneTop1Pct;
	}
	
	public void setOpBeneTop1Pct(String opBeneTop1Pct) {
		this.opBeneTop1Pct = opBeneTop1Pct;
	}
	
	//opBeneTop10Pct
	public String getOpBeneTop10Pct() {
		return opBeneTop10Pct;
	}
	
	public void setOpBeneTop10Pct(String opBeneTop10Pct) {
		this.opBeneTop10Pct = opBeneTop10Pct;
	}
	
	//opBeneTop25Pct
	public String getOpBeneTop25Pct() {
		return opBeneTop25Pct;
	}
	
	public void setOpBeneTop25Pct(String opBeneTop25Pct) {
		this.opBeneTop25Pct = opBeneTop25Pct;
	}
	
	//opBeneTop5Pct
	public String getOpBeneTop5Pct() {
		return opBeneTop5Pct;
	}
	
	public void setOpBeneTop5Pct(String opBeneTop5Pct) {
		this.opBeneTop5Pct = opBeneTop5Pct;
	}
	
	//opBeneErOd30AvgMme
	public String getOpBeneErOd30AvgMme() {
		return opBeneErOd30AvgMme;
	}
	
	public void setOpBeneErOd30AvgMme(String opBeneErOd30AvgMme) {
		this.opBeneErOd30AvgMme = opBeneErOd30AvgMme;
	}
	
	//fidLastPmtSuspnsnBgnDtStr
	public String getFidLastPmtSuspnsnBgnDtStr() {
		return fidLastPmtSuspnsnBgnDtStr;
	}
	
	public void setFidLastPmtSuspnsnBgnDtStr(String fidLastPmtSuspnsnBgnDtStr) {
		this.fidLastPmtSuspnsnBgnDtStr = fidLastPmtSuspnsnBgnDtStr;
	}
	
	//fidLastPmtSuspnsnEndDtStr
	public String getFidLastPmtSuspnsnEndDtStr() {
		return fidLastPmtSuspnsnEndDtStr;
	}
	
	public void setFidLastPmtSuspnsnEndDtStr(String fidLastPmtSuspnsnEndDtStr) {
		this.fidLastPmtSuspnsnEndDtStr = fidLastPmtSuspnsnEndDtStr;
	}
	
	//stdyPrdEndStr
	public String getStdyPrdEndStr() {
		return stdyPrdEndStr;
	}
	
	public void setStdyPrdEndStr(String stdyPrdEndStr) {
		this.stdyPrdEndStr = stdyPrdEndStr;
	}
	
	//stdyPrdStrtStr
	public String getStdyPrdStrtStr() {
		return stdyPrdStrtStr;
	}
	
	public void setStdyPrdStrtStr(String stdyPrdStrtStr) {
		this.stdyPrdStrtStr = stdyPrdStrtStr;
	}
	
	//prscrbrNpi
	public String getPrscrbrNpi() {
		return prscrbrNpi;
	}
	
	public void setPrscrbrNpi(String prscrbrNpi) {
		this.prscrbrNpi = prscrbrNpi;
	}
	
	//adHocReport
	public String getAdHocReport() {
		return adHocReport;
	}
	
	public void setAdHocReport(String adHocReport) {
		this.adHocReport = adHocReport;
	}
	
	//name
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	//adHocCols
	public List<AdHocCols> getAdHocCols() {
		return adHocCols;
	}
	
	public void setAdHocCols(List<AdHocCols> adHocCols) {
		this.adHocCols = adHocCols;
	}
	
	
}
