package com.cms.fps2.wrappers.landing;

public class ArchiveListReqWrapper {
	private String userId;
	private String listId;
	private String groupId;
	
	// constructor
	public ArchiveListReqWrapper() {}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	// listId
	public String getListId() {
		return listId;
	}
	
	public void setListId(String listId) {
		this.listId = listId;
	}
	
	// groupId
	public String getGroupId() {
		return groupId;
	}
	
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
}
