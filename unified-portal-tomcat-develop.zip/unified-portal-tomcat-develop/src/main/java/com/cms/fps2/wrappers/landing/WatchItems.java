package com.cms.fps2.wrappers.landing;

public class WatchItems {
	
	private String createDt;
	private String userId;
	private String eventType;
	private String eventName;
	private String subjId;
	private String name;
	private String agedAlerts;
	private String lastAlertCreateDt;
	private String prioritizeMine;
	private String prioritizeOther;
	private String asrId;
	private String newAlerts;
		
	// constructor
	public WatchItems() {}
	
	// createDt
	public String getCreateDt() {
		return createDt;
	}
	
	public void setCreateDt(String createDt) {
		this.createDt = createDt;
	}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	// eventType
	public String getEventType() {
		return eventType;
	}
	
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	
	// eventName
	public String getEventName() {
		return eventName;
	}
	
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	
	// subjId
	public String getSubjId() {
		return subjId;
	}
	
	public void setSubjId(String subjId) {
		this.subjId = subjId;
	}
	
	// name
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	// agedAlerts
	public String getAgedAlerts() {
		return agedAlerts;
	}
	
	public void setAgedAlerts(String agedAlerts) {
		this.agedAlerts = agedAlerts;
	}
	
	// lastAlertCreateDt
	public String getLastAlertCreateDt() {
		return lastAlertCreateDt;
	}
	
	public void setLastAlertCreateDt(String lastAlertCreateDt) {
		this.lastAlertCreateDt = lastAlertCreateDt;
	}
	
	// prioritizeMine
	public String getPrioritizeMine() {
		return prioritizeMine;
	}
	
	public void setPrioritizeMine(String prioritizeMine) {
		this.prioritizeMine = prioritizeMine;
	}
	
	// prioritizeOther
	public String getPrioritizeOther() {
		return prioritizeOther;
	}
	
	public void setPrioritizeOther(String prioritizeOther) {
		this.prioritizeOther = prioritizeOther;
	}
	
	// asrId
	public String getAsrId() {
		return asrId;
	}
	
	public void setAsrId(String asrId) {
		this.asrId = asrId;
	}
	
	// newAlerts
	public String getNewAlerts() {
		return newAlerts;
	}
	
	public void setNewAlerts(String newAlerts) {
		this.newAlerts = newAlerts;
	}
}
