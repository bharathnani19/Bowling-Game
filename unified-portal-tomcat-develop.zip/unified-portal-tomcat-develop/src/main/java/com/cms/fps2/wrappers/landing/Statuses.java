package com.cms.fps2.wrappers.landing;

public class Statuses {
	
	private String modelName;
	private String lastProcessedTime;
	private String cpiInd;
	private String lookback;
	
	
	//constructor
	public Statuses(){}
	
	//modelName
	public String getModelName() {
		return modelName;
	}
	
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	
	//lastProcessedTime
	public String getLastProcessedTime() {
		return lastProcessedTime;
	}
	
	public void setLastProcessedTime(String lastProcessedTime) {
		this.lastProcessedTime = lastProcessedTime;
	}
	
	//cpiInd
	public String getCpiInd() {
		return cpiInd;
	}
	
	public void setCpiInd(String cpiInd) {
		this.cpiInd = cpiInd;
	}
	
	//lookback
	public String getLookback() {
		return lookback;
	}
	
	public void setLookback(String lookback) {
		this.lookback = lookback;
	}
	

}
