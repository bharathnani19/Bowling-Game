package com.cms.fps2.wrappers.summary.workitems;

import java.util.ArrayList;
import java.util.List;
import com.cms.fps2.wrappers.summary.ResponseData;

public class ExDetailEditRespWrapper {
	private String transactionID;
	private String status;
	List<ResponseData> responseData =  new ArrayList<ResponseData>();
	private String owner;
	private String listId;
	private String listNm;
	private String listType;
	
	public ExDetailEditRespWrapper() {}
	
	//transactionID	
	public String getTransactionID() {
		return transactionID;
	}
	
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	
	//status
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	// responseData
	public List<ResponseData> getResponseData() {
		return responseData;
	}
	
	public void setResponseData(List<ResponseData> responseData) {
		this.responseData = responseData;
	}
	
	// owner
	public String getOwner() {
		return owner;
	}
	
	public void setOwner(String owner) {
		this.owner = owner;
	}
	
	// listId
	public String getListId() {
		return listId;
	}
	
	public void setListId(String listId) {
		this.listId = listId;
	}
	
	// listNm
	public String getListNm() {
		return listNm;
	}
	
	public void setListNm(String listNm) {
		this.listNm = listNm;
	}
	
	// listType
	public String getListType() {
		return listType;
	}
	
	public void setListType(String listType) {
		this.listType = listType;
	}
}
