package com.cms.fps2.wrappers.nav;

public class ReadMsgsRespWrapper {
	private String validResponse;
	
	//constructor
	public ReadMsgsRespWrapper(){}
	
	//validResponse
	public String getValidResponse() {
		return validResponse;
	}
	
	public void setValidResponse(String validResponse) {
		this.validResponse = validResponse;
	}
}
