package com.cms.fps2.wrappers.details.master.modal.claims;

import java.util.ArrayList;
import java.util.List;

public class MasterClaimsResponseWrapper {
	
	private String claimType;
	private String macId;
	private String jurisdiction;
	private String performNpi;
	private String performPtan;
	private String performSpecialty;
	private String performPrvdrCity;
	private String performPrvdrStateCd;
	private String providerZip;
	private String attendNpiName;
	private String beneId;
	private String beneFirstName;
	private String beneLastName;
	private String beneCity;
	private String age;
	private String birthDt;
	private String deathDt;
	private String dualInd;
	private String claimNum;
	private String claimLineNum;
	private String procedure;
	private String procTimeHrs;
	private String lineFromDt;
	private String lineToDt;
	private String claimFromDt;
	private String claimToDt;
	private String unitsService;
	private String lineSubmittedAmt;
	private String lineAllowedAmt;
	private String lineProviderPaidAmt;
	private String claimSubmittedAmt;
	private String claimAllowedAmt;
	private String claimProviderPaidAmt;
	private String crossoverInd;
	private String referNpi;
	private String referPtan;
	private String referNpiName;
	private String billNpi;
	private String billPtan;
	private String billPrvdrName;
	private String submitterId;
	private String attendNpi;
	private String attendSpecialty;
	private String mod1;
	private String mod2;
	private String mod3;
	private String mod4;
	private String mod5;
	private String referNpiSpecialty;
	private String beneStateCd;
	private String beneZip;
	private String beneAddress;
	private String alertAttributeName;
	private String attendPtan;
	private String diagnosis;
	private String claimToReview;
	private String providerName;
	private String tinEinOnClaim;
	private String billType;
	private String revenueCode;
	private String benePhone;
	private String mbi;
	private String claimId;
	private String alertClaimId;
	private String modelString;
	private String diagnosis1;
	private String diagnosis2;
	private String pos;
	private String admitDt;
	private String dischargeDt;
	private String paymentAmt;
	private String unitsAlwd;
	private String drg;
	private String lineDiagnosis;
	private String hcpcsCd;
	private String solrId;
	private String birthDtSolr;
	private String deathDtSolr;
	private String unitsServiceSolr;
	private String lineSubmittedAmtSolr;
	private String lineAllowedAmtSolr;
	private String lineProviderPaidAmtSolr;
	private String claimSubmittedAmtSolr;
	private String claimAllowedAmtSolr;
	private String claimProviderPaidAmtSolr;
	private String paymentAmtSolr;
	private String unitsAlwdSolr;
	private String beneAddress2;
	private String asrKey;
	private String alertKey;
	private String attributeKey;
	private String hcpcsDesc;
	private String diag1Desc;
	private String diagDesc;
	List<String> asrs = new ArrayList<String>();
	List<String> asrAsctns = new ArrayList<String>();
	private String diag2Desc;
	private String asrptId;
	private String lineFromDtSolr;
	private String lineToDtSolr;
	private String claimFromDtSolr;
	private String claimToDtSolr;
	private String admitDtSolr;
	private String dischargeDtSolr;
	private String lineRevUnitNum;
	private String clmCntlNum;
	private String prcdrDesc;
	private String beneRrbNum;
	
	//constructor
	public MasterClaimsResponseWrapper(){};
	
	//claimType
		public String getClaimType() {
			return claimType;
		}
		
		public void setClaimType(String claimType) {
			this.claimType = claimType;
		}
		
		//macId
		public String getMacId() {
			return macId;
		}
		
		public void setMacId(String macId) {
			this.macId = macId;
		}
		
		//jurisdiction
		public String getJurisdiction() {
			return jurisdiction;
		}
		
		public void setJurisdiction(String jurisdiction) {
			this.jurisdiction = jurisdiction;
		}
		
		//performNpi
		public String getPerformNpi() {
			return performNpi;
		}
		
		public void setPerformNpi(String performNpi) {
			this.performNpi = performNpi;
		}
		
		//performPtan
		public String getPerformPtan() {
			return performPtan;
		}
		
		public void setPerformPtan(String performPtan) {
			this.performPtan = performPtan;
		}
		
		//performSpecialty
		public String getPerformSpecialty() {
			return performSpecialty;
		}
		
		public void setPerformSpecialty(String performSpecialty) {
			this.performSpecialty = performSpecialty;
		}
		
		//performPrvdrCity
		public String getPerformPrvdrCity() {
			return performPrvdrCity;
		}
		
		public void setPerformPrvdrCity(String performPrvdrCity) {
			this.performPrvdrCity = performPrvdrCity;
		}
		
		//performPrvdrStateCd
		public String getPerformPrvdrStateCd() {
			return performPrvdrStateCd;
		}
		
		public void setPerformPrvdrStateCd(String performPrvdrStateCd) {
			this.performPrvdrStateCd = performPrvdrStateCd;
		}
		
		//providerZip
		public String getProviderZip() {
			return providerZip;
		}
		
		public void setProviderZip(String providerZip) {
			this.providerZip = providerZip;
		}
		
		//attendNpiName
		public String getAttendNpiName() {
			return attendNpiName;
		}
		
		public void setAttendNpiName(String attendNpiName) {
			this.attendNpiName = attendNpiName;
		}
		
		//beneId
		public String getBeneId() {
			return beneId;
		}
		
		public void setBeneId(String beneId) {
			this.beneId = beneId;
		}
		
		//beneFirstName
		public String getBeneFirstName() {
			return beneFirstName;
		}
		
		public void setBeneFirstName(String beneFirstName) {
			this.beneFirstName = beneFirstName;
		}
		
		//beneLastName
		public String getBeneLastName() {
			return beneLastName;
		}
		
		public void setBeneLastName(String beneLastName) {
			this.beneLastName = beneLastName;
		}
		
		//beneCity
		public String getBeneCity() {
			return beneCity;
		}
		
		public void setBeneCity(String beneCity) {
			this.beneCity = beneCity;
		}
		
		//age
		public String getAge() {
			return age;
		}
		
		public void setAge(String age) {
			this.age = age;
		}
		
		//birthDt
		public String getBirthDt() {
			return birthDt;
		}
		
		public void setBirthDt(String birthDt) {
			this.birthDt = birthDt;
		}
		
		//deathDt
		public String getDeathDt() {
			return deathDt;
		}
		
		public void setDeathDt(String deathDt) {
			this.deathDt = deathDt;
		}
		
		//dualInd
		public String getDualInd() {
			return dualInd;
		}
		
		public void setDualInd(String dualInd) {
			this.dualInd = dualInd;
		}
		
		//claimNum
		public String getClaimNum() {
			return claimNum;
		}
		
		public void setClaimNum(String claimNum) {
			this.claimNum = claimNum;
		}
		
		//claimLineNum
		public String getClaimLineNum() {
			return claimLineNum;
		}
		
		public void setClaimLineNum(String claimLineNum) {
			this.claimLineNum = claimLineNum;
		}
		
		//procedure
		public String getProcedure() {
			return procedure;
		}
		
		public void setProcedure(String procedure) {
			this.procedure = procedure;
		}
		
		//procTimeHrs
		public String getProcTimeHrs() {
			return procTimeHrs;
		}
		
		public void setProcTimeHrs(String procTimeHrs) {
			this.procTimeHrs = procTimeHrs;
		}
		
		//lineFromDt
		public String getLineFromDt() {
			return lineFromDt;
		}
		
		public void setLineFromDt(String lineFromDt) {
			this.lineFromDt = lineFromDt;
		}
		
		//lineToDt
		public String getLineToDt() {
			return lineToDt;
		}
		
		public void setLineToDt(String lineToDt) {
			this.lineToDt = lineToDt;
		}
		
		//claimFromDt
		public String getClaimFromDt() {
			return claimFromDt;
		}
		
		public void setClaimFromDt(String claimFromDt) {
			this.claimFromDt = claimFromDt;
		}
		
		//claimToDt
		public String getClaimToDt() {
			return claimToDt;
		}
		
		public void setClaimToDt(String claimToDt) {
			this.claimToDt = claimToDt;
		}
		
		//unitsService
		public String getUnitsService() {
			return unitsService;
		}
		
		public void setUnitsService(String unitsService) {
			this.unitsService = unitsService;
		}
		
		//lineSubmittedAmt
		public String getLineSubmittedAmt() {
			return lineSubmittedAmt;
		}
		
		public void setLineSubmittedAmt(String lineSubmittedAmt) {
			this.lineSubmittedAmt = lineSubmittedAmt;
		}
		
		//lineAllowedAmt
		public String getLineAllowedAmt() {
			return lineAllowedAmt;
		}
		
		public void setLineAllowedAmt(String lineAllowedAmt) {
			this.lineAllowedAmt = lineAllowedAmt;
		}
		
		//lineProviderPaidAmt
		public String getLineProviderPaidAmt() {
			return lineProviderPaidAmt;
		}
		
		public void setLineProviderPaidAmt(String lineProviderPaidAmt) {
			this.lineProviderPaidAmt = lineProviderPaidAmt;
		}
		
		//claimSubmittedAmt
		public String getClaimSubmittedAmt() {
			return claimSubmittedAmt;
		}
		
		public void setClaimSubmittedAmt(String claimSubmittedAmt) {
			this.claimSubmittedAmt = claimSubmittedAmt;
		}
		
		//claimAllowedAmt
		public String getClaimAllowedAmt() {
			return claimAllowedAmt;
		}
		
		public void setClaimAllowedAmt(String claimAllowedAmt) {
			this.claimAllowedAmt = claimAllowedAmt;
		}
		
		//claimProviderPaidAmt
		public String getClaimProviderPaidAmt() {
			return claimProviderPaidAmt;
		}
		
		public void setClaimProviderPaidAmt(String claimProviderPaidAmt) {
			this.claimProviderPaidAmt = claimProviderPaidAmt;
		}
		
		//crossoverInd
		public String getCrossoverInd() {
			return crossoverInd;
		}
		
		public void setCrossoverInd(String crossoverInd) {
			this.crossoverInd = crossoverInd;
		}
		
		//referNpi
		public String getReferNpi() {
			return referNpi;
		}
		
		public void setReferNpi(String referNpi) {
			this.referNpi = referNpi;
		}
		
		//referPtan
		public String getReferPtan() {
			return referPtan;
		}
		
		public void setReferPtan(String referPtan) {
			this.referPtan = referPtan;
		}
		
		//referNpiName
		public String getReferNpiName() {
			return referNpiName;
		}
		
		public void setReferNpiName(String referNpiName) {
			this.referNpiName = referNpiName;
		}
		
		//billNpi
		public String getBillNpi() {
			return billNpi;
		}
		
		public void setBillNpi(String billNpi) {
			this.billNpi = billNpi;
		}
		
		//billPtan
		public String getBillPtan() {
			return billPtan;
		}
		
		public void setBillPtan(String billPtan) {
			this.billPtan = billPtan;
		}
		
		//billPrvdrName
		public String getBillPrvdrName() {
			return billPrvdrName;
		}
		
		public void setBillPrvdrName(String billPrvdrName) {
			this.billPrvdrName = billPrvdrName;
		}
		
		//submitterId
		public String getSubmitterId() {
			return submitterId;
		}
		
		public void setSubmitterId(String submitterId) {
			this.submitterId = submitterId;
		}
		
		//attendNpi
		public String getAttendNpi() {
			return attendNpi;
		}
		
		public void setAttendNpi(String attendNpi) {
			this.attendNpi = attendNpi;
		}
		
		//attendSpecialty
		public String getAttendSpecialty() {
			return attendSpecialty;
		}
		
		public void setAttendSpecialty(String attendSpecialty) {
			this.attendSpecialty = attendSpecialty;
		}
		
		//mod1
		public String getMod1() {
			return mod1;
		}
		
		public void setMod1(String mod1) {
			this.mod1 = mod1;
		}
		
		//mod2
		public String getMod2() {
			return mod2;
		}
		
		public void setMod2(String mod2) {
			this.mod2 = mod2;
		}
		
		//mod3
		public String getMod3() {
			return mod3;
		}
		
		public void setMod3(String mod3) {
			this.mod3 = mod3;
		}
		
		//mod4
		public String getMod4() {
			return mod4;
		}
		
		public void setMod4(String mod4) {
			this.mod4 = mod4;
		}
		
		//mod5
		public String getMod5() {
			return mod5;
		}
		
		public void setMod5(String mod5) {
			this.mod5 = mod5;
		}
		
		//referNpiSpecialty
		public String getReferNpiSpecialty() {
			return referNpiSpecialty;
		}
		
		public void setReferNpiSpecialty(String referNpiSpecialty) {
			this.referNpiSpecialty = referNpiSpecialty;
		}
		
		//beneStateCd
		public String getBeneStateCd() {
			return beneStateCd;
		}
		
		public void setBeneStateCd(String beneStateCd) {
			this.beneStateCd = beneStateCd;
		}
		
		//beneZip
		public String getBeneZip() {
			return beneZip;
		}
		
		public void setBeneZip(String beneZip) {
			this.beneZip = beneZip;
		}
		
		//beneAddress
		public String getBeneAddress() {
			return beneAddress;
		}
		
		public void setBeneAddress(String beneAddress) {
			this.beneAddress = beneAddress;
		}
		
		//beneAddress2
		public String getBeneAddress2() {
			return beneAddress2;
		}
		
		public void setBeneAddress2(String beneAddress2) {
			this.beneAddress2 = beneAddress2;
		}
		
		//alertAttributeName
		public String getAlertAttributeName() {
			return alertAttributeName;
		}
		
		public void setAlertAttributeName(String alertAttributeName) {
			this.alertAttributeName = alertAttributeName;
		}
		
		//attendPtan
		public String getAttendPtan() {
			return attendPtan;
		}
		
		public void setAttendPtan(String attendPtan) {
			this.attendPtan = attendPtan;
		}
		
		//diagnosis
		public String getDiagnosis() {
			return diagnosis;
		}
		
		public void setDiagnosis(String diagnosis) {
			this.diagnosis = diagnosis;
		}
		
		//claimToReview
		public String getClaimToReview() {
			return claimToReview;
		}
		
		public void setClaimToReview(String claimToReview) {
			this.claimToReview = claimToReview;
		}
		
		//providerName
		public String getProviderName() {
			return providerName;
		}
		
		public void setProviderName(String providerName) {
			this.providerName = providerName;
		}
		
		//tinEinOnClaim
		public String getTinEinOnClaim() {
			return tinEinOnClaim;
		}
		
		public void setTinEinOnClaim(String tinEinOnClaim) {
			this.tinEinOnClaim = tinEinOnClaim;
		}
		
		//billType
		public String getBillType() {
			return billType;
		}
		
		public void setBillType(String billType) {
			this.billType = billType;
		}
		
		//revenueCode
		public String getRevenueCode() {
			return revenueCode;
		}
		
		public void setRevenueCode(String revenueCode) {
			this.revenueCode = revenueCode;
		}
		
		//benePhone
		public String getBenePhone() {
			return benePhone;
		}
		
		public void setBenePhone(String benePhone) {
			this.benePhone = benePhone;
		}
		
		//mbi
		public String getMbi() {
			return mbi;
		}
		
		public void setMbi(String mbi) {
			this.mbi = mbi;
		}
		//claimId
		public String getClaimId() {
			return claimId;
		}
		
		public void setClaimId(String claimId) {
			this.claimId = claimId;
		}
		
		//alertClaimId
		public String getAlertClaimId() {
			return alertClaimId;
		}
		
		public void setAlertClaimId(String alertClaimId) {
			this.alertClaimId = alertClaimId;
		}
		
		//modelString
		public String getModelString() {
			return modelString;
		}
		
		public void setModelString(String modelString) {
			this.modelString = modelString;
		}
		
		//diagnosis1
		public String getDiagnosis1() {
			return diagnosis1;
		}
		
		public void setDiagnosis1(String diagnosis1) {
			this.diagnosis1 = diagnosis1;
		}
		
		//diagnosis2
		public String getDiagnosis2() {
			return diagnosis2;
		}
		
		public void setDiagnosis2(String diagnosis2) {
			this.diagnosis2 = diagnosis2;
		}
		
		//pos
		public String getPos() {
			return pos;
		}
		
		public void setPos(String pos) {
			this.pos = pos;
		}
		
		//admitDt
		public String getAdmitDt() {
			return admitDt;
		}
		
		public void setAdmitDt(String admitDt) {
			this.admitDt = admitDt;
		}
		
		//dischargeDt
		public String getDischargeDt() {
			return dischargeDt;
		}
		
		public void setDischargeDt(String dischargeDt) {
			this.dischargeDt = dischargeDt;
		}
		
		//paymentAmt
		public String getPaymentAmt() {
			return paymentAmt;
		}
		
		public void setPaymentAmt(String paymentAmt) {
			this.paymentAmt = paymentAmt;
		}
		
		//unitsAlwd
		public String getUnitsAlwd() {
			return unitsAlwd;
		}
		
		public void setUnitsAlwd(String unitsAlwd) {
			this.unitsAlwd = unitsAlwd;
		}
		
		//drg
		public String getDrg() {
			return drg;
		}
		
		public void setDrg(String drg) {
			this.drg = drg;
		}
		
		//lineDiagnosis
		public String getLineDiagnosis() {
			return lineDiagnosis;
		}
		
		public void setLineDiagnosis(String lineDiagnosis) {
			this.lineDiagnosis = lineDiagnosis;
		}
		
		//hcpcsCd
		public String getHcpcsCd() {
			return hcpcsCd;
		}
		
		public void setHcpcsCd(String hcpcsCd) {
			this.hcpcsCd = hcpcsCd;
		}
		
		//solrId
		public String getSolrId() {
			return solrId;
		}
		
		public void setSolrId(String solrId) {
			this.solrId = solrId;
		}
		
		//birthDtSolr
		public String getBirthDtSolr() {
			return birthDtSolr;
		}
		
		public void setBirthDtSolr(String birthDtSolr) {
			this.birthDtSolr = birthDtSolr;
		}
		
		//deathDtSolr
		public String getDeathDtSolr() {
			return deathDtSolr;
		}
		
		public void setDeathDtSolr(String deathDtSolr) {
			this.deathDtSolr = deathDtSolr;
		}
		
		//unitsServiceSolr
		public String getUnitsServiceSolr() {
			return unitsServiceSolr;
		}
		
		public void setUnitsServiceSolr(String unitsServiceSolr) {
			this.unitsServiceSolr = unitsServiceSolr;
		}
		
		//lineSubmittedAmtSolr
		public String getLineSubmittedAmtSolr() {
			return lineSubmittedAmtSolr;
		}
		
		public void setLineSubmittedAmtSolr(String lineSubmittedAmtSolr) {
			this.lineSubmittedAmtSolr = lineSubmittedAmtSolr;
		}
		
		//lineAllowedAmtSolr
		public String getLineAllowedAmtSolr() {
			return lineAllowedAmtSolr;
		}
		
		public void setLineAllowedAmtSolr(String lineAllowedAmtSolr) {
			this.lineAllowedAmtSolr = lineAllowedAmtSolr;
		}
		
		//lineProviderPaidAmtSolr
		public String getLineProviderPaidAmtSolr() {
			return lineProviderPaidAmtSolr;
		}
		
		public void setLineProviderPaidAmtSolr(String lineProviderPaidAmtSolr) {
			this.lineProviderPaidAmtSolr = lineProviderPaidAmtSolr;
		}
		
		//claimSubmittedAmtSolr
		public String getClaimSubmittedAmtSolr() {
			return claimSubmittedAmtSolr;
		}
		
		public void setClaimSubmittedAmtSolr(String claimSubmittedAmtSolr) {
			this.claimSubmittedAmtSolr = claimSubmittedAmtSolr;
		}
		
		//claimAllowedAmtSolr
		public String getClaimAllowedAmtSolr() {
			return claimAllowedAmtSolr;
		}
		
		public void setClaimAllowedAmtSolr(String claimAllowedAmtSolr) {
			this.claimAllowedAmtSolr = claimAllowedAmtSolr;
		}
		
		//claimProviderPaidAmtSolr
		public String getClaimProviderPaidAmtSolr() {
			return claimProviderPaidAmtSolr;
		}
		
		public void setClaimProviderPaidAmtSolr(String claimProviderPaidAmtSolr) {
			this.claimProviderPaidAmtSolr = claimProviderPaidAmtSolr;
		}
		
		//paymentAmtSolr
		public String getPaymentAmtSolr() {
			return paymentAmtSolr;
		}
		
		public void setPaymentAmtSolr(String paymentAmtSolr) {
			this.paymentAmtSolr = paymentAmtSolr;
		}
		
		//unitsAlwdSolr
		public String getUnitsAlwdSolr() {
			return unitsAlwdSolr;
		}
		
		public void setUnitsAlwdSolr(String unitsAlwdSolr) {
			this.unitsAlwdSolr = unitsAlwdSolr;
		}
		
		//asrKey
		public String getAsrKey() {
			return asrKey;
		}
		
		public void setAsrKey(String asrKey) {
			this.asrKey = asrKey;
		}
		
		//alertKey
		public String getAlertKey() {
			return alertKey;
		}
		
		public void setAlertKey(String alertKey) {
			this.alertKey = alertKey;
		}
		
		//attributeKey
		public String getAttributeKey() {
			return attributeKey;
		}
		
		public void setAttributeKey(String attributeKey) {
			this.attributeKey = attributeKey;
		}
		
		//hcpcsDesc		
		public String getHcpcsDesc() {
			return hcpcsDesc;
		}
		
		public void setHcpcsDesc(String hcpcsDesc) {
			this.hcpcsDesc = hcpcsDesc;
		}
		
		//diag1Desc
		public String getDiag1Desc() {
			return diag1Desc;
		}
		
		public void setDiag1Desc(String diag1Desc) {
			this.diag1Desc = diag1Desc;
		}
		
		//diagDesc
		public String getDiagDesc() {
			return diagDesc;
		}
		
		public void setDiagDesc(String diagDesc) {
			this.diagDesc = diagDesc;
		}
		
		//asrs
		public List<String> getAsrs() {
			return asrs;
		}
		
		public void setAsrs(List<String> asrs) {
			this.asrs = asrs;
		}
		
		//asrAsctns
		public List<String> getAsrAsctns() {
			return asrAsctns;
		}
		
		public void setAsrAsctns(List<String> asrAsctns) {
			this.asrAsctns = asrAsctns;
		}
		
		//diag2Desc
		public String getDiag2Desc() {
			return diag2Desc;
		}
		
		public void setDiag2Desc(String diag2Desc) {
			this.diag2Desc = diag2Desc;
		}
		
		//asrptId
		public String getAsrptId() {
			return asrptId;
		}
		
		public void setAsrptId(String asrptId) {
			this.asrptId = asrptId;
		}
		
		//lineFromDtSolr
		public String getLineFromDtSolr() {
			return lineFromDtSolr;
		}
		
		public void setLineFromDtSolr(String lineFromDtSolr) {
			this.lineFromDtSolr = lineFromDtSolr;
		}
		
		//lineToDtSolr
		public String getLineToDtSolr() {
			return lineToDtSolr;
		}
		
		public void setLineToDtSolr(String lineToDtSolr) {
			this.lineToDtSolr = lineToDtSolr;
		}
		
		//claimFromDtSolr
		public String getClaimFromDtSolr() {
			return claimFromDtSolr;
		}
		
		public void setClaimFromDtSolr(String claimFromDtSolr) {
			this.claimFromDtSolr = claimFromDtSolr;
		}
		
		//claimToDtSolr
		public String getClaimToDtSolr() {
			return claimToDtSolr;
		}
		
		public void setClaimToDtSolr(String claimToDtSolr) {
			this.claimToDtSolr = claimToDtSolr;
		}
		
		//admitDtSolr
		public String getAdmitDtSolr() {
			return admitDtSolr;
		}
		
		public void setAdmitDtSolr(String admitDtSolr) {
			this.admitDtSolr = admitDtSolr;
		}
		
		//dischargeDtSolr
		public String getDischargeDtSolr() {
			return dischargeDtSolr;
		}
		
		public void setDischargeDtSolr(String dischargeDtSolr) {
			this.dischargeDtSolr = dischargeDtSolr;
		}
		
		//lineRevUnitNum
		public String getLineRevUnitNum() {
			return lineRevUnitNum;
		}

		public void setLineRevUnitNum(String lineRevUnitNum) {
			this.lineRevUnitNum = lineRevUnitNum;
		}
		
		//clmCntlNum
		public String getClmCntlNum() {
			return clmCntlNum;
		}

		public void setClmCntlNum(String clmCntlNum) {
			this.clmCntlNum = clmCntlNum;
		}
		
		//prcdrDesc
		public String getPrcdrDesc() {
			return prcdrDesc;
		}

		public void setPrcdrDesc(String prcdrDesc) {
			this.prcdrDesc = prcdrDesc;
		}
		
		//beneRrbNum
		public String getBeneRrbNum() {
			return beneRrbNum;
		}

		public void setBeneRrbNum(String beneRrbNum) {
			this.beneRrbNum = beneRrbNum;
		}
		
}
