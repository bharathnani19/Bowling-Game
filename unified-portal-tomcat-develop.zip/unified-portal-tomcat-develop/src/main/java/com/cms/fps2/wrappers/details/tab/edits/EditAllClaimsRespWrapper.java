package com.cms.fps2.wrappers.details.tab.edits;

import java.util.ArrayList;
import java.util.List;

public class EditAllClaimsRespWrapper {
	
	private List<EditClaims> editClaims = new ArrayList<EditClaims>();
	
	// constructor
	public EditAllClaimsRespWrapper() {}
	
	//editClaims
	public List<EditClaims> getEditClaims() {
		return editClaims;
	}
	
	public void setEditClaims(List<EditClaims> editClaims) {
		this.editClaims = editClaims;
	}
}
