package com.cms.fps2.wrappers.summary;

public class Items {
	private String name;
	private String date;
	private String desc;
	
	//constructor
	public Items(){}
	
	//name
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	//date
	public String getDate() {
		return date;
	}
	
	public void setDate(String date) {
		this.date = date;
	}
	
	//desc
	public String getDesc() {
		return desc;
	}
	
	public void setDesc(String desc) {
		this.desc = desc;
	}
}
