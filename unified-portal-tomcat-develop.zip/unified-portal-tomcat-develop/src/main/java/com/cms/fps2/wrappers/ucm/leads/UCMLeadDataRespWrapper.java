package com.cms.fps2.wrappers.ucm.leads;

public class UCMLeadDataRespWrapper {
	private ResponseData responseData;
	private String transactionID;
	private String status;
	private String responseType;
	
	//empty constructor
	public UCMLeadDataRespWrapper(){}
	
	//responseData
	public ResponseData getResponseData() {
		return responseData;
	}
	
	public void setResponseData(ResponseData responseData) {
		this.responseData = responseData;
	}
	
	//transactionID
	public String getTransactionID() {
		return transactionID;
	}
	
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	
	//status
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	//responseType
	public String getResponseType() {
		return responseType;
	}
	
	public void setResponseType(String responseType) {
		this.responseType = responseType;
	}
}
