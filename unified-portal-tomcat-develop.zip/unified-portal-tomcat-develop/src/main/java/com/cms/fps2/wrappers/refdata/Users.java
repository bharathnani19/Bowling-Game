package com.cms.fps2.wrappers.refdata;

public class Users {
	//constructor
	public Users() {}

}
