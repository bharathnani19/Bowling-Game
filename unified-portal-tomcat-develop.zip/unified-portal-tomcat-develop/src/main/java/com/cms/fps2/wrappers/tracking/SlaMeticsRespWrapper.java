package com.cms.fps2.wrappers.tracking;

public class SlaMeticsRespWrapper {
	private String status;
	
	// constructor
	public SlaMeticsRespWrapper() {}
	
	// status
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
}
