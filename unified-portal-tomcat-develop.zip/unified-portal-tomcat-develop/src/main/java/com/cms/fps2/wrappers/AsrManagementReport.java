package com.cms.fps2.wrappers;

public class AsrManagementReport {
	
	//constructor
	public AsrManagementReport (){}

}
