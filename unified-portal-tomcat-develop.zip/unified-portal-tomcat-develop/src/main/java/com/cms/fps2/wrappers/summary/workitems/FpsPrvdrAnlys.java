package com.cms.fps2.wrappers.summary.workitems;

public class FpsPrvdrAnlys {
	
	// constructor
	public FpsPrvdrAnlys() {}

}
