package com.cms.fps2.wrappers.ucm.leads;

public class UCMLeadDataReqWrapper {
	private String asrptId;
	private String leadId;
			
	//empty constructor
	public UCMLeadDataReqWrapper(){}
	
	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}	
	
	//leadId
	public String getLeadId() {
		return leadId;
	}
	
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
}
