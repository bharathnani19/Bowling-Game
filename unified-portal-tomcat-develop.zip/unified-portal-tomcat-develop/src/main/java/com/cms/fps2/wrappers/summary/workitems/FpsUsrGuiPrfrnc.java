package com.cms.fps2.wrappers.summary.workitems;

public class FpsUsrGuiPrfrnc {
	private String usrGuiPrfrncId;
	private String usrId;
	private String prfrncGrp;
	private String prfrncNm;
	private String prfrncOptions;
	private String audtInsrtId;
	private String audtInsrtTs;
	private String audtUpdtId;
	private String audtUpdtTs;
	private String fpsPrioritizationShareGrps;
	private String shareGrpId;
	
	// constructor
	public FpsUsrGuiPrfrnc() {}
	
	// usrGuiPrfrncId
	public String getUsrGuiPrfrncId() {
		return usrGuiPrfrncId;
	}
	
	public void setUsrGuiPrfrncId(String usrGuiPrfrncId) {
		this.usrGuiPrfrncId = usrGuiPrfrncId;
	}
	
	// usrId
	public String getUsrId() {
		return usrId;
	}
	
	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}
	
	// prfrncGrp
	public String getPrfrncGrp() {
		return prfrncGrp;
	}
	
	public void setPrfrncGrp(String prfrncGrp) {
		this.prfrncGrp = prfrncGrp;
	}
	
	// prfrncNm
	public String getPrfrncNm() {
		return prfrncNm;
	}
	
	public void setPrfrncNm(String prfrncNm) {
		this.prfrncNm = prfrncNm;
	}
	
	// prfrncOptions
	public String getPrfrncOptions() {
		return prfrncOptions;
	}
	
	public void setPrfrncOptions(String prfrncOptions) {
		this.prfrncOptions = prfrncOptions;
	}
	
	// audtInsrtId
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	
	// audtInsrtTs
	public String getAudtInsrtTs() {
		return audtInsrtTs;
	}
	
	public void setAudtInsrtTs(String audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	
	// audtUpdtId
	public String getAudtUpdtId() {
		return audtUpdtId;
	}
	
	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	
	// audtUpdtTs
	public String getAudtUpdtTs() {
		return audtUpdtTs;
	}
	
	public void setAudtUpdtTs(String audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
	
	// fpsPrioritizationShareGrps
	public String getFpsPrioritizationShareGrps() {
		return fpsPrioritizationShareGrps;
	}
	
	public void setFpsPrioritizationShareGrps(String fpsPrioritizationShareGrps) {
		this.fpsPrioritizationShareGrps = fpsPrioritizationShareGrps;
	}
	
	// shareGrpId
	public String getShareGrpId() {
		return shareGrpId;
	}
	
	public void setShareGrpId(String shareGrpId) {
		this.shareGrpId = shareGrpId;
	}
}
