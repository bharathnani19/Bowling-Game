package com.cms.fps2.wrappers.landing;

public class Faqs {
	
	private String usrSprtQstnId;
	private String usrSprtQstnCtgryCd;
	private String usrSprtQstnSbctgryCd;
	private String usrSprtQstnTxt;
	private String usrSprtQstnAswrTxt;
	private String dfltInd;
	private String actvInd;
	private UsrSprtQstnCtgryRfrnc fpsUsrSprtQstnCtgryRfrnc; 
	private UsrSprtQstnSbctgryRfrnc fpsUsrSprtQstnSbctgryRfrnc;
	
	//constructor
	public Faqs() {}

	//usrSprtQstnId
	public String getUsrSprtQstnId() {
		return usrSprtQstnId;
	}
	
	public void setUsrSprtQstnId(String usrSprtQstnId) {
		this.usrSprtQstnId = usrSprtQstnId;
	}
	
	//usrSprtQstnCtgryCd
	public String getUsrSprtQstnCtgryCd() {
		return usrSprtQstnCtgryCd;
	}
	
	public void setUsrSprtQstnCtgryCd(String usrSprtQstnCtgryCd) {
		this.usrSprtQstnCtgryCd = usrSprtQstnCtgryCd;
	}
	
	//usrSprtQstnSbctgryCd
	public String getUsrSprtQstnSbctgryCd() {
		return usrSprtQstnSbctgryCd;
	}
	
	public void setUsrSprtQstnSbctgryCd(String usrSprtQstnSbctgryCd) {
		this.usrSprtQstnSbctgryCd = usrSprtQstnSbctgryCd;
	}
	
	//usrSprtQstnTxt
	public String getUsrSprtQstnTxt() {
		return usrSprtQstnTxt;
	}
	
	public void setUsrSprtQstnTxt(String usrSprtQstnTxt) {
		this.usrSprtQstnTxt = usrSprtQstnTxt;
	}
	
	//usrSprtQstnAswrTxt
	public String getUsrSprtQstnAswrTxt() {
		return usrSprtQstnAswrTxt;
	}
	
	public void setUsrSprtQstnAswrTxt(String usrSprtQstnAswrTxt) {
		this.usrSprtQstnAswrTxt = usrSprtQstnAswrTxt;
	}
	
	//dfltInd
	public String getDfltInd() {
		return dfltInd;
	}
	
	public void setDfltInd(String dfltInd) {
		this.dfltInd = dfltInd;
	}
	
	//actvInd
	public String getActvInd() {
		return actvInd;
	}
	
	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}
	
	//fpsUsrSprtQstnCtgryRfrnc
	public UsrSprtQstnCtgryRfrnc getFpsUsrSprtQstnCtgryRfrnc() {
		return fpsUsrSprtQstnCtgryRfrnc;
	}
	
	public void setFpsUsrSprtQstnCtgryRfrnc(UsrSprtQstnCtgryRfrnc fpsUsrSprtQstnCtgryRfrnc) {
		this.fpsUsrSprtQstnCtgryRfrnc = fpsUsrSprtQstnCtgryRfrnc;
	}
	
	//fpsUsrSprtQstnSbctgryRfrnc
	public UsrSprtQstnSbctgryRfrnc getFpsUsrSprtQstnSbctgryRfrnc() {
		return fpsUsrSprtQstnSbctgryRfrnc;
	}
	
	public void setFpsUsrSprtQstnSbctgryRfrnc(UsrSprtQstnSbctgryRfrnc fpsUsrSprtQstnSbctgryRfrnc) {
		this.fpsUsrSprtQstnSbctgryRfrnc = fpsUsrSprtQstnSbctgryRfrnc;
	}
}
