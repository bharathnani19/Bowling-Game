package com.cms.fps2.wrappers.summary;

public class DrugClasses {
	private String code;
	
	//constructor
	public DrugClasses(){}
	
	//code
	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}
}
