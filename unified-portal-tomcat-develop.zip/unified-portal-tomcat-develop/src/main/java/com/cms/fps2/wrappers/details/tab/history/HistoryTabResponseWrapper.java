package com.cms.fps2.wrappers.details.tab.history;

public class HistoryTabResponseWrapper {
	
	
	//constructor
	public HistoryTabResponseWrapper(){}
}
