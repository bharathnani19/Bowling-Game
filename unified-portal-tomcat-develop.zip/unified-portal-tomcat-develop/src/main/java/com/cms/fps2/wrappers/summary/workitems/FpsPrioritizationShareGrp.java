package com.cms.fps2.wrappers.summary.workitems;

import java.util.ArrayList;
import java.util.List;

public class FpsPrioritizationShareGrp {
	private String shareGrpId;
	private String actvInd;
	private FpsPrioritizationList fpsPrioritizationList;
	private List<FpsPrioritizationShareGrpUserAsctns> fpsPrioritizationShareGrpUserAsctns = new ArrayList<FpsPrioritizationShareGrpUserAsctns>();
	private String shareTxt;
	private String shareNm;
	private FpsUsrGuiPrfrnc fpsUsrGuiPrfrnc;
	
	// constructor
	public FpsPrioritizationShareGrp() {}
	
	// shareGrpId
	public String getShareGrpId() {
		return shareGrpId;
	}
	
	public void setShareGrpId(String shareGrpId) {
		this.shareGrpId = shareGrpId;
	}
	
	// actvInd
	public String getActvInd() {
		return actvInd;
	}
	
	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}
	
	// fpsPrioritizationList
	public FpsPrioritizationList getFpsPrioritizationList() {
		return fpsPrioritizationList;
	}
	
	public void setFpsPrioritizationList(FpsPrioritizationList fpsPrioritizationList) {
		this.fpsPrioritizationList = fpsPrioritizationList;
	}
	
	// fpsPrioritizationShareGrpUserAsctns
	public List<FpsPrioritizationShareGrpUserAsctns> getFpsPrioritizationShareGrpUserAsctns() {
		return fpsPrioritizationShareGrpUserAsctns;
	}
	
	public void setFFpsPrioritizationShareGrpUserAsctns(List<FpsPrioritizationShareGrpUserAsctns> fpsPrioritizationShareGrpUserAsctns) {
		this.fpsPrioritizationShareGrpUserAsctns = fpsPrioritizationShareGrpUserAsctns;
	}
	
	// shareTxt
	public String getShareTxt() {
		return shareTxt;
	}
	
	public void setShareTxt(String shareTxt) {
		this.shareTxt = shareTxt;
	}
	
	// shareNm
	public String getShareNm() {
		return shareNm;
	}
	
	public void setShareNm(String shareNm) {
		this.shareNm = shareNm;
	}
	
	// fpsUsrGuiPrfrnc
	public FpsUsrGuiPrfrnc getFpsUsrGuiPrfrnc() {
		return fpsUsrGuiPrfrnc;
	}
	
	public void setFpsUsrGuiPrfrnc(FpsUsrGuiPrfrnc fpsUsrGuiPrfrnc) {
		this.fpsUsrGuiPrfrnc = fpsUsrGuiPrfrnc;
	}
	
}
