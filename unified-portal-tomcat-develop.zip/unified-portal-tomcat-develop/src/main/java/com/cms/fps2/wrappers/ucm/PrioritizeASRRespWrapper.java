package com.cms.fps2.wrappers.ucm;

public class PrioritizeASRRespWrapper {
	private String message;
	
	//empty constructor
	public PrioritizeASRRespWrapper(){}
	
	//message
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
}
