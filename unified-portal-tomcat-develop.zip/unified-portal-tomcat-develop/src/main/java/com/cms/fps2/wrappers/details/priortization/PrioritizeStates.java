package com.cms.fps2.wrappers.details.priortization;

public class PrioritizeStates {
	private String state;
	private String modelLabel;
	
	public PrioritizeStates(String state, String modelLabel) {
		this.state = state;
		this.modelLabel = modelLabel;
	}
	public PrioritizeStates() {
		
	}
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getModelLabel() {
		return modelLabel;
	}
	public void setModelLabel(String modelLabel) {
		this.modelLabel = modelLabel;
	}
	
}