package com.cms.fps2.wrappers.summary.modals;

import java.util.ArrayList;
import java.util.List;

public class ResponseData {
	private String prioritized;
	private List<Trends> trends = new ArrayList<Trends>();
	
	//constructor
	public ResponseData(){}
	
	//asrptId
	public String getPrioritized() {
		return prioritized;
	}
	
	public void setPrioritized(String prioritized) {
		this.prioritized = prioritized;
	}
	
	//trends
	public List<Trends> getTrends() {
		return trends;
	}
	
	public void setTrends(List<Trends> trends) {
		this.trends = trends;
	}
}
