package com.cms.fps2.wrappers.details.tab.partdrpt;

import java.util.ArrayList;
import java.util.List;

public class PartD {
	private List<Reports> reports = new ArrayList<Reports>();
	
	//constructor
	public PartD(){}
	
	//reports
	public List<Reports> getReports() {
		return reports;
	}
	
	public void setReports(List<Reports> reports) {
		this.reports = reports;
	}

}
