package com.cms.fps2.wrappers.details.priortization;

import java.util.List;





public class PriortizeAlerts {
	private String createDt;
	private String status;
	private String modelBusnsId;
	private String prioritizedInd;
	private List<PrioritizeStates> states;
	private String disabled;
	
	public void setStates(List<PrioritizeStates> states) {
		this.states = states;
	}
	
	public List<PrioritizeStates> getStates() {
		return states;
	}
	
	/**
	 * @return the createDt
	 */
	public String getCreateDt() {
		return createDt;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @return the modelBusnsId
	 */
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	/**
	 * @return the prioritizedInd
	 */
	public String getPrioritizedInd() {
		return prioritizedInd;
	}
	/**
	 * @param createDt the createDt to set
	 */
	public void setCreateDt(String createDt) {
		this.createDt = createDt;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @param modelBusnsId the modelBusnsId to set
	 */
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	/**
	 * @param prioritizedInd the prioritizedInd to set
	 */
	public void setPrioritizedInd(String prioritizedInd) {
		this.prioritizedInd = prioritizedInd;
	}

	// disabled
	
	public String getDisabled() {
		return disabled;
	}

	// disabled
	
	public void setDisabled(String disabled) {
		this.disabled = disabled;
	}
	

}
