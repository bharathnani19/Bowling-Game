package com.cms.fps2.wrappers.summary.workitems;

import java.util.ArrayList;
import java.util.List;

public class ExDetailEditReqWrapper {
	
	private String userId;
	private List<ExDetailExclusion> exclusions = new ArrayList<ExDetailExclusion>();
	
	public ExDetailEditReqWrapper() {}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	// exclusions
	public List<ExDetailExclusion> getExclusions() {
		return exclusions;
	}
	
	public void setExclusions(List<ExDetailExclusion> exclusions) {
		this.exclusions = exclusions;
	}
}
