package com.cms.fps2.wrappers.landing;

import java.util.ArrayList;
import java.util.List;

public class AsrManagementReport {
	
	private List<Items> items = new ArrayList<Items>();
	
	//constructor
	public AsrManagementReport (){}
	
	//items
	public List<Items> getItems() {
		return items;
	}
	
	public void setItems(List<Items> items) {
		this.items = items;
	}
}
