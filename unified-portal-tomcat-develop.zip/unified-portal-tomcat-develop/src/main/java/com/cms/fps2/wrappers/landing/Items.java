package com.cms.fps2.wrappers.landing;

public class Items {
	
	private String label;
	private String count;
	private String preSetFlag;
	
	//constructor
	public Items(){}
	
	//label
	public String getLabel() {
		return label;
	}
	
	public void setLabel(String label) {
		this.label = label;
	}
	
	//count
	public String getCount() {
		return count;
	}
	
	public void setCount(String count) {
		this.count = count;
	}
	
	//preSetFlag
	public String getPreSetFlag() {
		return preSetFlag;
	}
	
	public void setPreSetFlag(String preSetFlag) {
		this.preSetFlag = preSetFlag;
	}

}
