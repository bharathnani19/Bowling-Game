package com.cms.fps2.wrappers.refdata;

public class Rulings {
	private String code;
	private String desc;
	
	//constructor
	public Rulings(){}
	
	//code
	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}
	
	//desc
	public String getDesc() {
		return desc;
	}
	
	public void setDesc(String desc) {
		this.desc = desc;
	}
}
