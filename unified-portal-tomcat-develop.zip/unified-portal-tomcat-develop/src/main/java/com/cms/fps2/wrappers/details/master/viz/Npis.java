package com.cms.fps2.wrappers.details.master.viz;

public class Npis {
	
	private String code;
	
	//constructor
	public Npis() {}
	
	//code
	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}

}
