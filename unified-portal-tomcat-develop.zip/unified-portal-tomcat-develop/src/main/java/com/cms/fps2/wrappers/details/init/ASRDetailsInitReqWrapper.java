package com.cms.fps2.wrappers.details.init;

public class ASRDetailsInitReqWrapper {
	private String asrId;
	private String userId;
	private String searchType;
	
	//constructor
	public ASRDetailsInitReqWrapper(){}
	
	//asrId 	
	public String getAsrId() {
		return asrId;
	}
	
	public void setAsrId(String asrId) {
		this.asrId = asrId;
	}
	
	//userId 	
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	//searchType 	
	public String getSearchType() {
		return searchType;
	}
	
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
}
