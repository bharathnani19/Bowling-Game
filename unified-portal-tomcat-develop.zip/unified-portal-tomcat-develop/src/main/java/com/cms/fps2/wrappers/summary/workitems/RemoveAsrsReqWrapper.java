package com.cms.fps2.wrappers.summary.workitems;

import java.util.ArrayList;
import java.util.List;

public class RemoveAsrsReqWrapper {
	private String workItemId;
	private String userId;
	private List<Integer> asrptIds = new ArrayList<Integer>();
		
	// constructor
	public RemoveAsrsReqWrapper() {}
	
	// workItemId
	public String getWorkItemId() {
		return workItemId;
	}
	
	public void setWorkItemId(String workItemId) {
		this.workItemId = workItemId;
	}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	// asrptIds
	public List<Integer> getAsrptIds() {
		return asrptIds;
	}
	
	public void setAsrptIds(List<Integer> asrptIds) {
		this.asrptIds = asrptIds;
	}
}
