package com.cms.fps2.wrappers.admin;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.landing.Messages;

public class AdminMsgsRespWrapper {
	private List<Messages> messages = new ArrayList<Messages>();
	private String newSysMsgCt;
	
	//constructor
	public AdminMsgsRespWrapper(){}
	
	//messages
	public List<Messages> getMessages() {		
		return messages;
	}
	
	public void setMessages(List<Messages> messages) {
		this.messages = messages;
	}
	
	//newSysMsgCt
	public String getNewSysMsgCt() {		
		return newSysMsgCt;
	}
	
	public void setNewSysMsgCt(String newSysMsgCt) {
		this.newSysMsgCt = newSysMsgCt;
	}
}
