package com.cms.fps2.wrappers.summary.modals;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.summary.ResponseData;

public class SummaryModalsResponseWrapper {
	private String transactionID;
	private String status;
	private List<ResponseData> responseData = new ArrayList<ResponseData>();
	private String statusDescription;
	
	//constructor
	public SummaryModalsResponseWrapper(){}
	
	//transactionID
	public String getTransactionID() {
		return transactionID;
	}
	
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	
	//status
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	//responseData
	public List<ResponseData> getResponseData() {
		return responseData;
	}
	
	public void setResponseData(List<ResponseData> responseData) {
		this.responseData = responseData;
	}
	
	//statusDescription
	public String getStatusDescription() {
		return statusDescription;
	}
	
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
}
