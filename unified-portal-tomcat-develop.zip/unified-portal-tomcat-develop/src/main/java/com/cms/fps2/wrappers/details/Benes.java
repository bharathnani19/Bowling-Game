package com.cms.fps2.wrappers.details;

public class Benes {
	
	private String hicn;
	private Address address;
	private String mbi;
	
	//constructor
	public Benes(){}
	
	//hcin 	
	public String getHicn() {
		return hicn;
	}
	
	public void setHicn(String hicn) {
		this.hicn = hicn;
	}
	
	//address	
	public Address getAddress() {
		return address;
	}
	
	public void setAddress(Address address) {
		this.address = address;
	}
	
	//mbi
	public String getMbi() {
		return mbi;
	}
	
	public void setMbi(String mbi) {
		this.mbi = mbi;
	}
	
}
