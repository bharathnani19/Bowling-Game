package com.cms.fps2.wrappers;

public class Notes {
	
	private String leaderInvId;
	private String note;
	
	//constructor
	Notes(){}
	
	//leaderInvId
	public String getLeaderInvId() {
		return leaderInvId;
	}
	
	public void setLeaderInvId(String leaderInvId) {
		this.leaderInvId = leaderInvId;
	}
	
	//note
	public String getNote() {
		return note;
	}
	
	public void setNote(String note) {
		this.note = note;
	}

}
