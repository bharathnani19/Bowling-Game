package com.cms.fps2.wrappers.rptcard;

import java.util.ArrayList;
import java.util.List;

public class CustomVizTables {
	
	private String modelBusnsId;
	private String tabName;
	private String tabSummary;
	private List<Columns> columns = new ArrayList<Columns>();
	private List<DataRows> dataRows = new ArrayList<DataRows>();
	private String tableId;
	
	//constructor
	public CustomVizTables(){}
	
	//modelBusnsId
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	
	//tabName
	public String getTabName() {
		return tabName;
	}
	
	public void setTabName(String tabName) {
		this.tabName = tabName;
	}
	
	//tabSummary
	public String getTabSummary() {
		return tabSummary;
	}
	
	public void setTabSummary(String tabSummary) {
		this.tabSummary = tabSummary;
	}
	
	//columns
	public List<Columns> getColumns() {
		return columns;
	}
	
	public void setColumns(List<Columns> columns) {
		this.columns = columns;
	}
	
	//dataRows
	public List<DataRows> getDataRows() {
		return dataRows;
	}
	
	public void setDataRows(List<DataRows> dataRows) {
		this.dataRows = dataRows;
	}
	
	//tableId
	public String getTableId() {
		return tableId;
	}
	
	public void setTableId(String tableId) {
		this.tableId = tableId;
	}
}

