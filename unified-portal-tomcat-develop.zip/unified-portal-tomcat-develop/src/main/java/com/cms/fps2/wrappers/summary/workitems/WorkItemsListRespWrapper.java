package com.cms.fps2.wrappers.summary.workitems;

import java.util.ArrayList;
import java.util.List;

import com.cms.fps2.wrappers.summary.ResponseData;



public class WorkItemsListRespWrapper {
	private String transactionID;
	private String status;
	private String owner;
	private String sharedInd;
	private String listId;
	private String listNm;
	private String listType;
	private List<ResponseData> responseData = new ArrayList<ResponseData>();
	private List<ResponseData> responseDataMdcd = new ArrayList<ResponseData>();
	private String shareGrpId;
	private String mdcdPrrtyEnabledInd;
	
	
	
	// constructor
	public WorkItemsListRespWrapper() {}
	
	// transactionID
	public String getTransactionID() {
		return transactionID;
	}
	
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	
	// status
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	// owner
	public String getOwner() {
		return owner;
	}
	
	public void setOwner(String owner) {
		this.owner = owner;
	}
	
	// sharedInd
	public String getSharedInd() {
		return sharedInd;
	}
	
	public void setSharedInd(String sharedInd) {
		this.sharedInd = sharedInd;
	}
	
	// listId
	public String getListId() {
		return listId;
	}
	
	public void setListId(String listId) {
		this.listId = listId;
	}
	
	// listNm
	public String getListNm() {
		return listNm;
	}
	
	public void setListNm(String listNm) {
		this.listNm = listNm;
	}
	
	// listType
	public String getListType() {
		return listType;
	}
	
	public void setListType(String listType) {
		this.listType = listType;
	}
	
	// responseData
	public List<ResponseData> getResponseData() {
		return responseData;
	}
	
	public void setResponseData(List<ResponseData> responseData) {
		this.responseData = responseData;
	}
	
	// shareGrpId
	public String getShareGrpId() {
		return shareGrpId;
	}
	
	public void setShareGrpId(String shareGrpId) {
		this.shareGrpId = shareGrpId;
	}

	// responseDataMdcd
	
	public List<ResponseData> getResponseDataMdcd() {
		return responseDataMdcd;
	}

	// responseDataMdcd
	
	public void setResponseDataMdcd(List<ResponseData> responseDataMdcd) {
		this.responseDataMdcd = responseDataMdcd;
	}

	// mdcdPrrtyEnabledInd
	
	public String getMdcdPrrtyEnabledInd() {
		return mdcdPrrtyEnabledInd;
	}

	// mdcdPrrtyEnabledInd
	 
	public void setMdcdPrrtyEnabledInd(String mdcdPrrtyEnabledInd) {
		this.mdcdPrrtyEnabledInd = mdcdPrrtyEnabledInd;
	}
	
}
