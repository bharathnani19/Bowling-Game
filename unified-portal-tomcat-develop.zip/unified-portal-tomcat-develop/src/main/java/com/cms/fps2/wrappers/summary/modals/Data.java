package com.cms.fps2.wrappers.summary.modals;

public class Data {
	
	private String attrDef;
	private String threshold;
	private String prvdrVal;
	private String attrThresh;
	private String stateMedian;
	private String statePct;
	
	
	//constructor
	public Data() {}
	
	//attrDef
	public String getAttrDef() {
		return attrDef;
	}
	
	public void setAttrDef(String attrDef) {
		this.attrDef = attrDef;
	}
	
	//threshold
	public String getThreshold() {
		return threshold;
	}
	
	public void setThreshold(String threshold) {
		this.threshold = threshold;
	}
	
	//prvdrVal
	public String getPrvdrVal() {
		return prvdrVal;
	}
	
	public void setPrvdrVal(String prvdrVal) {
		this.prvdrVal = prvdrVal;
	}
	
	//attrThresh
	public String getAttrThresh() {
		return attrThresh;
	}
	
	public void setAttrThresh(String attrThresh) {
		this.attrThresh = attrThresh;
	}
	
	//stateMedian
	public String getStateMedian() {
		return stateMedian;
	}
	
	public void setStateMedian(String stateMedian) {
		this.stateMedian = stateMedian;
	}
	
	//statePct
	public String getStatePct() {
		return statePct;
	}
	
	public void setStatePct(String statePct) {
		this.statePct = statePct;
	}
	

}
