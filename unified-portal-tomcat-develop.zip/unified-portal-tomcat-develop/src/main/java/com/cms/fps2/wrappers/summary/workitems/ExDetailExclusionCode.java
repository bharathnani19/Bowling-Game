package com.cms.fps2.wrappers.summary.workitems;

public class ExDetailExclusionCode {
	
	private String code;
	
	// constructor
	public ExDetailExclusionCode() {}
	
	// code
	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}

}
