package com.cms.fps2.wrappers.home;

import java.io.Serializable;
import java.util.List;


public class HomepageTileResponse implements Serializable {

	private List<HomepageTile> homepageTiles;
	
	public HomepageTileResponse() {
		
	}
	public HomepageTileResponse(List<HomepageTile> homepageTiles) {
		this.homepageTiles = homepageTiles;
	}

	public List<HomepageTile> getHomepageTiles() {
		return homepageTiles;
	}

	public void setHomepageTiles(List<HomepageTile> homepageTiles) {
		this.homepageTiles = homepageTiles;
	}
}
