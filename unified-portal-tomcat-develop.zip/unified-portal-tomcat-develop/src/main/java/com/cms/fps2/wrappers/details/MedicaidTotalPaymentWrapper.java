package com.cms.fps2.wrappers.details;

import com.cms.fps2.wrappers.summary.medicaid.ResponseData;

public class MedicaidTotalPaymentWrapper {
	private String asrDbid;
	private String userId;
	private ResponseData responseData;

	// userId

	public String getUserId() {
		return userId;
	}

	// userId

	public void setUserId(String userId) {
		this.userId = userId;
	}
	// asrDbid

	public String getAsrDbid() {
		return asrDbid;
	}

	// asrDbid

	public void setAsrDbid(String asrDbid) {
		this.asrDbid = asrDbid;
	}

	// responseData

	public ResponseData getResponseData() {
		return responseData;
	}

	// responseData

	public void setResponseData(ResponseData responseData) {
		this.responseData = responseData;
	}

}
