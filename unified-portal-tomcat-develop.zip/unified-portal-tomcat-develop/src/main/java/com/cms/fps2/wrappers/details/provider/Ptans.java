package com.cms.fps2.wrappers.details.provider;

public class Ptans {	
	
	private String ptan;
	private String type;
	
	public Ptans(){}
	
	//ptan
	public String getPtan() {
		return ptan;
	}
	
	public void setPtan(String ptan) {
		this.ptan = ptan;
	}
	
	//type
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
}
