package com.cms.fps2.wrappers.maps.model;

public class BeneModelReqWrapper {
	
	private String asrptId;
	private String modelId;
	
	//constructor
	public BeneModelReqWrapper() {}
	
	//asrptId
	public String getAsrptId() {
		return asrptId;
	}
	
	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}
	
	//modelId
	public String getModelId() {
		return modelId;
	}
	
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
}
