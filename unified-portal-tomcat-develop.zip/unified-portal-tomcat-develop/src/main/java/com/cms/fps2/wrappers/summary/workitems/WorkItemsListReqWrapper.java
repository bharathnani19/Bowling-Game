package com.cms.fps2.wrappers.summary.workitems;

public class WorkItemsListReqWrapper {
	private String workItemId;
	private String userId;
	
	// constructor
	public WorkItemsListReqWrapper() {}
	
	// workItemId
	public String getWorkItemId() {
		return workItemId;
	}
	
	public void setWorkItemId(String workItemId) {
		this.workItemId = workItemId;
	}
	
	// userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
