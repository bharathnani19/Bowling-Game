package com.cms.fps2.wrappers.details;

public class Ucms {
	private String caseID;
	private String externalCaseID;
	private String subjectID;
	
	//constructor
	public Ucms(){}
	
	//caseID 	
	public String getCaseID() {
		return caseID;
	}
	
	public void setCaseID(String caseID) {
		this.caseID = caseID;
	}
	
	//externalCaseID 	
	public String getExternalCaseID() {
		return externalCaseID;
	}
	
	public void setExternalCaseID(String externalCaseID) {
		this.externalCaseID = externalCaseID;
	}
	
	//subjectID 	
	public String getSubjectID() {
		return subjectID;
	}
	
	public void setSubjectID(String subjectID) {
		this.subjectID = subjectID;
	}
}
