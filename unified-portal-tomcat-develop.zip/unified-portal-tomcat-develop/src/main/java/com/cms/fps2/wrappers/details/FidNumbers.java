package com.cms.fps2.wrappers.details;

public class FidNumbers {
	
	private String fidNumber;
	
	//constructor
	public FidNumbers(){}
	
	//sysTagTxt 	
	public String getFidNumber() {
		return fidNumber;
	}
	
	public void setFidNumber(String fidNumber) {
		this.fidNumber = fidNumber;
	}

}
