package com.cms.fps2.wrappers.refdata;

public class RefDataReqWrapper {
	
	private String userId;
	
	public RefDataReqWrapper() {}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
