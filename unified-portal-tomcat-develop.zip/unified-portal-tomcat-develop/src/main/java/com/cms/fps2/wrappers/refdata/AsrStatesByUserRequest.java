package com.cms.fps2.wrappers.refdata;

public class AsrStatesByUserRequest {
	

	String userId;
	Integer asrptId;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
}
