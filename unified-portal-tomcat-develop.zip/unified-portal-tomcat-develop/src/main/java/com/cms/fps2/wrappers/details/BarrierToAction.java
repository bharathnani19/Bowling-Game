package com.cms.fps2.wrappers.details;

public class BarrierToAction {
	
	private String barrierCd;
	private String leadInvestigationId;
	private String source;
	
	//constructor
	BarrierToAction(){}
	
	//barrierCd 	
	public String getBarrierCd() {
		return barrierCd;
	}
	
	public void setBarrierCd(String barrierCd) {
		this.barrierCd = barrierCd;
	}
	
	//leadInvestigationId 	
	public String getLeadInvestigationId() {
		return leadInvestigationId;
	}
	
	public void setLeadInvestigationId(String leadInvestigationId) {
		this.leadInvestigationId = leadInvestigationId;
	}
	
	//source 	
	public String getSource() {
		return source;
	}
	
	public void setSource(String source) {
		this.source = source;
	}
}
