package com.cms.fps2.wrappers.summary;

public class AlertsReqWrapper {
	private String userId;
	
	// constructor
	public AlertsReqWrapper() {}
	
	//userId
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
}
