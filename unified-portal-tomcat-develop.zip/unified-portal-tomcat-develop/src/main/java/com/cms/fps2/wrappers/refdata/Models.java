package com.cms.fps2.wrappers.refdata;

public class Models {
	
	private String modelName;
	private String modelId;
	private String lookback;
	
	//constructor
	public Models(){}
	
	//modelName
	public String getModelName() {
		return modelName;
	}
	
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	
	//modelId
	public String getModelId() {
		return modelId;
	}
	
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	
	//lookback
	public String getLookback() {
		return lookback;
	}
	
	public void setLookback(String lookback) {
		this.lookback = lookback;
	}

}
