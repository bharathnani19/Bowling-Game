package com.cms.fps2.wrappers.summary;

import java.util.ArrayList;
import java.util.List;

public class ASRSearchWrapper {
	
	private String transactionID; 
	private String status; 
	private List<ResponseData> responseData = new ArrayList<ResponseData>();
	private String statusDescription;
	private List<ResponseData> responseDataMdcd = new ArrayList<ResponseData>();
	private String mdcdPrrtyEnabledInd;
	
	
	// responseDataMdcd
	
	public String getMdcdPrrtyEnabledInd() {
		return mdcdPrrtyEnabledInd;
	}

	public void setMdcdPrrtyEnabledInd(String mdcdPrrtyEnabledInd) {
		this.mdcdPrrtyEnabledInd = mdcdPrrtyEnabledInd;
	}

	public List<ResponseData> getResponseDataMdcd() {
		return responseDataMdcd;
	}

	// responseDataMdcd
	
	public void setResponseDataMdcd(List<ResponseData> responseDataMdcd) {
		this.responseDataMdcd = responseDataMdcd;
	}

	//constructor
	public ASRSearchWrapper() {}
	
	//transactionID
	public String getTransactionID() {
		return transactionID;
	}
	
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	
	//status
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	//responseData
	public List<ResponseData> getResponseData() {
		return responseData;
	}
	
	public void setResponseData(List<ResponseData> responseData) {
		this.responseData = responseData;
	}
	
	//statusDescription
	public String getStatusDescription() {
		return statusDescription;
	}
	
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
}
