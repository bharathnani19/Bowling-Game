package com.cms.fps2.wrappers.home;

import java.io.Serializable;

public class HomepageTile implements Serializable {

	private String homepageCd;
	private String homepageIconUrlNm;
	private String homepageUrlTxt;
	private String homepageUrlNm;
	private Integer homepageSqncNum;
	private String homepageUrlDesc;
	private String homepageEnvCd;
	private String newTabInd;
	private String actvInd;
	
	public String getHomepageCd() {
		return homepageCd;
	}
	public void setHomepageCd(String homepageCd) {
		this.homepageCd = homepageCd;
	}
	public String getHomepageIconUrlNm() {
		return homepageIconUrlNm;
	}
	public void setHomepageIconUrlNm(String homepageIconUrlNm) {
		this.homepageIconUrlNm = homepageIconUrlNm;
	}
	public String getHomepageUrlTxt() {
		return homepageUrlTxt;
	}
	public void setHomepageUrlTxt(String homepageUrlTxt) {
		this.homepageUrlTxt = homepageUrlTxt;
	}
	public String getHomepageUrlNm() {
		return homepageUrlNm;
	}
	public void setHomepageUrlNm(String homepageUrlNm) {
		this.homepageUrlNm = homepageUrlNm;
	}
	public Integer getHomepageSqncNum() {
		return homepageSqncNum;
	}
	public void setHomepageSqncNum(Integer homepageSqncNum) {
		this.homepageSqncNum = homepageSqncNum;
	}
	public String getHomepageUrlDesc() {
		return homepageUrlDesc;
	}
	public void setHomepageUrlDesc(String homepageUrlDesc) {
		this.homepageUrlDesc = homepageUrlDesc;
	}
	public String getHomepageEnvCd() {
		return homepageEnvCd;
	}
	public void setHomepageEnvCd(String homepageEnvCd) {
		this.homepageEnvCd = homepageEnvCd;
	}
	public String getNewTabInd() {
		return newTabInd;
	}
	public void setNewTabInd(String newTabInd) {
		this.newTabInd = newTabInd;
	}
	public String getActvInd() {
		return actvInd;
	}
	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}
}

