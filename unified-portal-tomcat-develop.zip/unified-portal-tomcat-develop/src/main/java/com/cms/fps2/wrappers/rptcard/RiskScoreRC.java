package com.cms.fps2.wrappers.rptcard;

public class RiskScoreRC {
	
	
	private String modelId;
	private String npi;
	private String modelBusnsId;
	private String attrIndex;
	private String attrRank;
	private String contribDef;
	private String contribType;
	private String prvdrErsVal;
	private String contribVal;
	private String alertedPrvdrPct;
	private String contribImpact;
	/**
	 * @return the modelId
	 */
	public String getModelId() {
		return modelId;
	}
	/**
	 * @param modelId the modelId to set
	 */
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	/**
	 * @return the npi
	 */
	public String getNpi() {
		return npi;
	}
	/**
	 * @param npi the npi to set
	 */
	public void setNpi(String npi) {
		this.npi = npi;
	}
	/**
	 * @return the modelBusnsId
	 */
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	/**
	 * @param modelBusnsId the modelBusnsId to set
	 */
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	/**
	 * @return the attrIndex
	 */
	public String getAttrIndex() {
		return attrIndex;
	}
	/**
	 * @param attrIndex the attrIndex to set
	 */
	public void setAttrIndex(String attrIndex) {
		this.attrIndex = attrIndex;
	}
	/**
	 * @return the attrRank
	 */
	public String getAttrRank() {
		return attrRank;
	}
	/**
	 * @param attrRank the attrRank to set
	 */
	public void setAttrRank(String attrRank) {
		this.attrRank = attrRank;
	}
	/**
	 * @return the contribDef
	 */
	public String getContribDef() {
		return contribDef;
	}
	/**
	 * @param contribDef the contribDef to set
	 */
	public void setContribDef(String contribDef) {
		this.contribDef = contribDef;
	}
	/**
	 * @return the contribType
	 */
	public String getContribType() {
		return contribType;
	}
	/**
	 * @param contribType the contribType to set
	 */
	public void setContribType(String contribType) {
		this.contribType = contribType;
	}
	/**
	 * @return the prvdrErsVal
	 */
	public String getPrvdrErsVal() {
		return prvdrErsVal;
	}
	/**
	 * @param prvdrErsVal the prvdrErsVal to set
	 */
	public void setPrvdrErsVal(String prvdrErsVal) {
		this.prvdrErsVal = prvdrErsVal;
	}
	/**
	 * @return the contribVal
	 */
	public String getContribVal() {
		return contribVal;
	}
	/**
	 * @param contribVal the contribVal to set
	 */
	public void setContribVal(String contribVal) {
		this.contribVal = contribVal;
	}
	/**
	 * @return the alertedPrvdrPct
	 */
	public String getAlertedPrvdrPct() {
		return alertedPrvdrPct;
	}
	/**
	 * @param alertedPrvdrPct the alertedPrvdrPct to set
	 */
	public void setAlertedPrvdrPct(String alertedPrvdrPct) {
		this.alertedPrvdrPct = alertedPrvdrPct;
	}
	/**
	 * @return the contribImpact
	 */
	public String getContribImpact() {
		return contribImpact;
	}
	/**
	 * @param contribImpact the contribImpact to set
	 */
	public void setContribImpact(String contribImpact) {
		this.contribImpact = contribImpact;
	}
	
	

}
