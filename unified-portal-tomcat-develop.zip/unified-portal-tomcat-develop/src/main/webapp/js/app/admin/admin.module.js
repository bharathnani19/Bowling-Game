var appAdmin = angular.module('admin.module', ['ngRoute', 'ngCookies', 'ngSanitize']);

appAdmin.controller("adminController", ['$scope', '$location', '$cookies', '$window', '$filter', '$sanitize', 'adminFactory', 'utilService', 'utilFactory', 
                                        function ($scope, $location, $cookies, $window, $filter, $sanitize, adminFactory, utilService, utilFactory) {
	console.log('Inside the adminController.');

	// get the Okta authClient object from the util service
	var authClient = utilService.getOktaAuth();

	// check for a valid okta token
	authClient.tokenManager.getTokens()
	.then(({ accessToken, idToken }) => {
		// handle accessToken and idToken
		if (accessToken) {
			// user has valid access token, so show page contents
			console.log("administration controller - valid access token");

			showAdminPageContents(idToken);
		} else {
			// no token and not logged-in, so redirect to login screen               
			authClient.token.getWithRedirect({
				responseType: ['token', 'id_token']
			});
		}
	});

	 // this function shows the page to users that have been authenticated via Okta
	 showAdminPageContents = function(pIdToken) {
		console.log(`showAdminPageContents pIdToken = ${pIdToken} `);

		if (pIdToken) {
			//initialize the System Messages, Model and Edit data tables
			$("#adminSysMsgsTable").bootstrapTable({});
			$("#adminModelTable").bootstrapTable({});
			$("#adminEditTable").bootstrapTable({});
			
			//show the full page overlay spinner
			//$.LoadingOverlay("show");
			$("#adminSysMsgsTable").LoadingOverlay("show"); 
			$("#adminModelTable").LoadingOverlay("show"); 

			//call the factory method to get the property from the property file
			utilFactory.getURLPropertyFromFile().then(function(response) {
				//declare a scope level variable for the URL used to make REST web service calls
				$scope.restURL = response.data;

				// get username from id token 
				$scope.uid = pIdToken.claims.preferred_username;

				// parse role and jurisdiction from id token
				$scope.rolesArray = [];						
				$scope.zonesArray = [];
				var groupsArray = pIdToken.claims.groups;					

				for (i = 0; i < groupsArray.length; i++) {
					console.log('group - ' + groupsArray[i]);
					var groupObj = groupsArray[i];

					// populate role array
					if (groupObj.search('FPSUI Role') != -1) {
						$scope.rolesArray.push(groupObj.replace("FPSUI Role", "").trim());
					}

					// populate the zone Array
					if (groupObj.search('FPSUI Zone') != -1) {
						$scope.zonesArray.push(groupObj.replace("FPSUI Zone", "").trim());
					}
				}

				// set the jurisdiction to the first entry in the zones arary
				$scope.organization = $scope.zonesArray[0];	

				//show the Admin page contents if the user is a Admin				
				if ($scope.rolesArray.indexOf("Admin") == -1) {				
					console.log('User is not an Admin, so do NOT show Administration page contents.');
					//show the unauthorized modal window					
					$('#authModal').modal("show");
				} else {
					console.log('User is an Admin, so show Administration page contents');
					$('#containerDiv').removeAttr('hidden');
					$('#adminOutagesModal').removeAttr('hidden');
					$('#adminSysMsgsModal').removeAttr('hidden');
					$('#modelsModal').removeAttr('hidden');

					//load the admin page data				
					loadAdminPageData();
					//load the admin system messages data
					loadAdminPageMsgsData();
				}
			}).catch(function(err) {
				console.log('getURLPropertyFromFile REST Error:' + err.data);	
				//hide the overlay spinner
				$.LoadingOverlay("hide");
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load system data due to ' + err.data, 'danger');		
			});	
		} else {
			// You're not logged in, you need a sessionToken
			authClient.token.getWithRedirect({
				responseType: ['token', 'id_token']
			});
		} 	
	}
	
	//the user clicked the Add or Edit button for the System Messages Table
	$scope.modelsBtnClick = function(pBtnType) {
		console.log('Inside modelsBtnClick.  pBtnType = ' + pBtnType);
		
		//reset the form, and then set the status to pristine
		$scope.modelsForm.$setPristine();
		
		$scope.adminModelDescription = '';
		$scope.adminModelStatus =  '';
		$scope.adminModelPriority =  '';
		$scope.adminModelsOwner =  '';
		$scope.adminModelsOwnerPhone =  '';
		$scope.adminModelsOwnerEmail =  '';
		$scope.modelId =  '';
		
		//check the button type to see if the user is adding or editing
		if (pBtnType == 'add') {
			//set the modal window title to Add Models
			$scope.modelsModalTitle = 'Add Models';
			//set the modal window button 
			$scope.adminModelsBtnLabel = 'Save Models';
			
			//show the Models Modal window
			$("#modelsModal").modal("show");
			
			//apply the scope ng-binding changes to the display
			$scope.$apply();	
			
		} else if (pBtnType == 'edit') {
			//user wants to edit a model
			console.log('User wants to EDIT a Model.');			
			//assign models table selections to scope level variable
			$scope.adminModelsSelections = $('#adminModelTable').bootstrapTable('getSelections');
			
			//check to see if user selected at least one model from the models table
			if($scope.adminModelsSelections.length > 0) {
				//user selected a model to edit
				console.log('Selected Models = ' + JSON.stringify($scope.adminModelsSelections));
				
				//set the modal window title to Edit Models
				$scope.modelsModalTitle = 'Edit Models';
				//set the modal window button 
				$scope.adminModelsBtnLabel = 'Save Models';
								
				//show the System Messages Modal window
				$("#modelsModal").modal("show");
				
				//populate the form fields with the values from the table row selected
				$scope.modelId = $scope.adminModelsSelections[0].modelId;
				$scope.adminModelDescription = $scope.adminModelsSelections[0].modelDesc;
				$scope.adminModelStatus = $scope.adminModelsSelections[0].activeStatus;
				$scope.adminModelPriority = $scope.adminModelsSelections[0].priorityInd;
				$scope.adminModelsOwner = $scope.adminModelsSelections[0].ownerName;
				$scope.adminModelsOwnerPhone =  $scope.adminModelsSelections[0].ownerPhone;
				$scope.adminModelsOwnerEmail =  $scope.adminModelsSelections[0].ownerEmail;
				
				//apply the scope ng-binding changes to the display
				$scope.$apply();
			} else {		   			
			    //no system messages were chosen from the table
				//console.log('Canceling ' + pBtnType + ' because no System Messages were selected.');			
			    showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Please select a Model from the System Messages table.', 'danger');
			}
		} else if (pBtnType == 'delete') {
			//user wants to delete a Model
			console.log('User wants to DELETE a Model.');
			
			//assign Model table selections to scope level variable
			$scope.adminModelsSelections = $('#adminModelTable').bootstrapTable('getSelections');
			
			//check to see if user selected at least one model from the models table
			if($scope.adminModelsSelections.length > 0) {
				
				console.log('Selected Models = ' + JSON.stringify($scope.adminModelsSelections)); 
				
				//call the factory method to delete an outages message from the database				
				adminFactory.deleteAdminModelsData($scope.restURL, $scope.adminModelsSelections[0].id).then(function(response) {
					showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i> Model successfully deleted.', 'success');
					
					//show the table overlay
					$("#adminModelTable").LoadingOverlay("show");
															
					//refresh the admin page data
					loadAdminPageData();
				}).catch(function(err) {
					console.log('deleteAdminModelsData REST Error:' + err.data);	
					//show the full page overlay
					$.LoadingOverlay("hide"); 
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to delete Model due to ' + err.data, 'danger');		
				});
			} else {		   			
			    //no models were chosen from the table
				console.log('Canceling ' + pBtnType + ' because no Models were selected.');			
			    showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Please select a Model from the System Messages table.', 'danger');
			}
		}
	}

	//user clicked the submit button on the Add/Edit System Messages Modal Window
	$scope.modelsModalBtnClick = function() {

		//set the form to Dirty to show errors after submittal
		$scope.modelsForm.$setDirty();
		
		//user wants to add/edit a model
		console.log('User wants to ADD/EDIT a Model. Form validity = ' + $scope.modelsForm.$valid);
		
		if ($scope.modelsForm.$valid) {
			console.log('Inside modelsModalBtnClick. id = ' + $scope.modelId + ', description = ' + $scope.adminModelDescription 
					+ ', status = ' + $scope.adminModelStatus + ', priority = ' + $scope.adminModelPriority
					+ ', owner = ' + $scope.adminModelsOwner + ', owner phone number = ' + $scope.adminModelsOwnerPhone + ', owner email = ' + $scope.adminModelsOwnerEmail);
			
			//show the modal overlay
			$("#modelsModalBody").LoadingOverlay("show"); 
			
			//change models id to null value if undefined
			if ($scope.modelId === void(0) || $scope.modelId === '') {
				$scope.modelId = null;
			}
			
			//call the add/update web service to persist models to DB			
			adminFactory.updateModelsData($scope.restURL, $scope.modelId, $sanitize($scope.adminModelDescription), $scope.adminModelStatus,  $sanitize($scope.adminModelsOwner), $scope.adminModelsOwnerPhone, 
					$scope.adminModelsOwnerEmail, $scope.uid, $scope.adminModelPriority).then(function(response) {
						
					//hide modal overlay
		    		$("#modelsModalBody").LoadingOverlay("hide"); 	
		    		
		    		//show message back to the user				
					showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i> Model successfully saved.', 'success');
					
					//hide the models Modal window
					$("#modelsModal").modal("hide");
					
					//clear the form fields
					$scope.adminModelDescription = '';
					$scope.adminModelStatus = '';
					$scope.adminModelPriority = '';
					$scope.adminModelsOwner = '';
					$scope.adminModelsOwnerPhone = '';
					$scope.adminModelsOwnerEmail = '';
					
					//show the overlay for the models table
					$("#adminModelTable").LoadingOverlay("show"); 
					
					//refresh the admin page data
					loadAdminPageData();
						
			}).catch(function(err) {
				console.log('updateModelsData REST Error:' + err);    				
				//hide modal overlay
	    		$("#modelsModalBody").LoadingOverlay("hide");    				
				//show message to user that assign to user failed
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> ' + err.data, 'danger');
			});
			
		} else {
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Please complete all required form fields.', 'danger');
		}
	}

	//the user clicked the Add or Edit button for the System Messages Table
	$scope.sysMsgsBtnClick = function(pBtnType) {
		console.log('Inside sysMsgsBtnClick.  pBtnType = ' + pBtnType);
		//reset the form, and then set the status to pristine
		$scope.adminSysMsgsForm.$setPristine();
		//angular.copy({}, $scope.adminOutagesForm);
		$scope.adminSysMsgsMessage = '';
		$scope.sysMsgsId =  '';
		$scope.adminSysMsgsStartDate =  '';
		$scope.adminSysMsgsEndDate =  '';
		$scope.adminSysMsgsStartHours =  '';
		$scope.adminSysMsgsStartMins =  '';
		$scope.adminSysMsgsStartAmPm =  ''; 
		$scope.adminSysMsgsEndHours =  '';
		$scope.adminSysMsgsEndMins =  '';
		$scope.adminSysMsgsEndAmPm =  '';
		
		//create an array used to populate the outageStartHours and outageEndHours dropdown boxes
		$scope.sysMsgsStartHoursArray = [];			
		for (i=1; i<13; i++) {
			var sysMsgsStartHoursObj = {};
			if (i <10) {
				sysMsgsStartHoursObj.hour = '0' + i.toString();
			} else {
				sysMsgsStartHoursObj.hour = i.toString();
			}
			
			$scope.sysMsgsStartHoursArray.push(sysMsgsStartHoursObj);
		}
		
		$scope.sysMsgsEndHoursArray = [];			
		for (i=1; i<13; i++) {
			var sysMsgsEndHoursObj = {};
			if (i <10) {
				sysMsgsEndHoursObj.hour = '0' + i.toString();
			} else {
				sysMsgsEndHoursObj.hour = i.toString();
			}
			
			$scope.sysMsgsEndHoursArray.push(sysMsgsEndHoursObj);
		}
		
		//create an array used to populste the outageStartMins and outageEndMins dropdown boxes
		$scope.sysMsgsStartMinsArray = [];			
		for (i=0; i<60; i++) {
			var sysMsgsStartMinsObj = {};
			if (i <10) {
				sysMsgsStartMinsObj.minute = '0' + i.toString();
			} else {
				sysMsgsStartMinsObj.minute = i.toString();
			}
			
			$scope.sysMsgsStartMinsArray.push(sysMsgsStartMinsObj);
		}
		
		$scope.sysMsgsEndMinsArray = [];			
		for (i=0; i<60; i++) {
			var sysMsgsEndMinsObj = {};
			if (i <10) {
				sysMsgsEndMinsObj.minute = '0' + i.toString();
			} else {
				sysMsgsEndMinsObj.minute = i.toString();
			}
			
			$scope.sysMsgsEndMinsArray.push(sysMsgsEndMinsObj);
		}
		
		//check the button type to see if the user is adding or editing
		if (pBtnType == 'add') {
			//set the modal window title to Add System Messages
			$scope.adminSysMsgsModalTitle = 'Add System Messages';
			//set the modal window button 
			$scope.adminSysMsgsBtnLabel = 'Save System Messages';
			
			//show the System Messages Modal window
			$("#adminSysMsgsModal").modal("show");
			
			//apply the scope ng-binding changes to the display
			$scope.$apply();
			
		} else if (pBtnType == 'edit') {
			//user wants to edit a system message
			console.log('User wants to EDIT a System Message.');			
			//assign system messages table selections to scope level variable
			$scope.adminSysMsgsTableSelections = $('#adminSysMsgsTable').bootstrapTable('getSelections');
			
			//check to see if user selected at least one ASR from summary table
			if($scope.adminSysMsgsTableSelections.length > 0) {
				//user selected a system message to edit
				console.log('Selected System Messages = ' + JSON.stringify($scope.adminSysMsgsTableSelections));
				
				//set the modal window title to Edit Outages
				$scope.adminSysMsgsModalTitle = 'Edit System Messages';
				//set the modal window button 
				$scope.adminSysMsgsBtnLabel = 'Save System Messages Edits';
								
				//show the System Messages Modal window
				$("#adminSysMsgsModal").modal("show");
												
				//populate the form fields with the values from the table row selected
				$scope.adminSysMsgsMessage = $scope.adminSysMsgsTableSelections[0].message;
				$scope.sysMsgsId = $scope.adminSysMsgsTableSelections[0].id;
				//$scope.sysMsgsStartDate =$scope.adminSysMsgsTableSelections[0].dateAdded;
				
				//remove the timezone from the start date and end date
				$scope.startDtNoTz = $scope.adminSysMsgsTableSelections[0].startDt.substring(0, $scope.adminSysMsgsTableSelections[0].startDt.length - 2).trim();
				$scope.endDtNoTz = $scope.adminSysMsgsTableSelections[0].endDt.substring(0, $scope.adminSysMsgsTableSelections[0].endDt.length - 2).trim();
				
				console.log("$scope.startDtNoTz = " + $scope.startDtNoTz);
				console.log("$scope.endDtNoTz = " + $scope.endDtNoTz);
				
				$scope.adminSysMsgsStartDate = $filter('date')(new Date($scope.startDtNoTz), 'yyyy-MM-dd');
				$scope.adminSysMsgsEndDate = $filter('date')(new Date($scope.endDtNoTz), 'yyyy-MM-dd');
				$scope.adminSysMsgsStartHours = $filter('date')(new Date($scope.startDtNoTz), 'hh');
				$scope.adminSysMsgsStartMins = $filter('date')(new Date($scope.startDtNoTz), 'mm');
				$scope.adminSysMsgsStartAmPm = $filter('date')(new Date($scope.startDtNoTz), 'a'); 
				$scope.adminSysMsgsEndHours = $filter('date')(new Date($scope.endDtNoTz ), 'hh');
				$scope.adminSysMsgsEndMins = $filter('date')(new Date($scope.endDtNoTz ), 'mm');
				$scope.adminSysMsgsEndAmPm = $filter('date')(new Date($scope.endDtNoTz ), 'a'); 
				
				//apply the scope ng-binding changes to the display
				$scope.$apply();
			} else {		   			
			    //no system messages were chosen from the table
				//console.log('Canceling ' + pBtnType + ' because no System Messages were selected.');			
			    showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Please select a System Message from the System Messages table.', 'danger');
			}
			
		} else if (pBtnType == 'delete') {
			//user wants to delete a System Message
			console.log('User wants to DELETE a System Message.');
			
			//assign system messages table selections to scope level variable
			$scope.adminSysMsgsTableSelections = $('#adminSysMsgsTable').bootstrapTable('getSelections');
			
			//check to see if user selected at least one ASR from summary table
			if($scope.adminSysMsgsTableSelections.length > 0) {
				console.log('Selected Outages = ' + JSON.stringify($scope.adminOutagesTableSelections)); 
				
				//call the factory method to delete an outages message from the database				
				adminFactory.deleteAdminSysMsgsData($scope.restURL, $scope.adminSysMsgsTableSelections[0].id).then(function(response) {
					showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i> System Message successfully deleted.', 'success');
					
					//show the table overlay
					$("#adminSysMsgsTable").LoadingOverlay("show");
					
					//refresh the admin page data
					//loadAdminPageData();
					loadAdminPageMsgsData();
				}).catch(function(err) {
					console.log('deleteAdminSysMsgsData REST Error:' + err.data);	
					//show the full page overlay
					$.LoadingOverlay("hide"); 
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to delete System Message due to ' + err.data, 'danger');		
				});
			} else {		   			
			    //no system messages were chosen from the table
				console.log('Canceling ' + pBtnType + ' because no System Messages were selected.');			
			    showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Please select a System Message from the System Messages table.', 'danger');
			}
		}
	}

	//user clicked the submit button on the Add/Edit System Messages Modal Window
	$scope.sysMsgsModalBtnClick = function() {
		//set the form to Dirty to show errors after submittal
		$scope.adminSysMsgsForm.$setDirty();
		
		//user wants to add/edit a system message
		console.log('User wants to ADD/EDIT a System Message. Form validity = ' + $scope.adminSysMsgsForm.$valid);
		
		if ($scope.adminSysMsgsForm.$valid) {
			console.log('Inside sysMsgsModalBtnClick. id = ' + $scope.sysMsgsId + ', message = ' + $scope.adminSysMsgsMessage 
					+ ', adminSysMsgsStartDate = ' + $scope.adminSysMsgsStartDate 
					+ ', adminSysMsgsStartHours = ' + $scope.adminSysMsgsStartHours + ', adminSysMsgsStartMins = ' + $scope.adminSysMsgsStartMins + ', adminSysMsgsStartAmPm = ' + $scope.adminSysMsgsStartAmPm + ', adminSysMsgsEndDate = '
					+ $scope.adminSysMsgsEndDate + ', adminSysMsgsEndHours= ' + $scope.adminSysMsgsEndHours + ', adminSysMsgsEndMins= ' + $scope.adminSysMsgsEndMins + ', adminSysMsgsEndAmPm = ' + $scope.adminSysMsgsEndAmPm);
			
			//show the modal overlay
			$("#adminSysMsgsModalBody").LoadingOverlay("show");  
			
			//change sysMsgsId to null value if undefined
			if ($scope.sysMsgsId === void(0) || $scope.sysMsgsId === '') {
				$scope.sysMsgsId = null;
			}
			
			$scope.sysMsgsStartDateTime = $scope.adminSysMsgsStartDate + ' ' + convertToMilitaryHour($scope.adminSysMsgsStartHours, $scope.adminSysMsgsStartAmPm) + ':' + $scope.adminSysMsgsStartMins + ':00.000000';
			$scope.sysMsgsEndDateTime = $scope.adminSysMsgsEndDate + ' ' + convertToMilitaryHour($scope.adminSysMsgsEndHours, $scope.adminSysMsgsEndAmPm) + ':' + $scope.adminSysMsgsEndMins + ':00.000000';
			
			//call the add/update web service to persist outages to DB			
			adminFactory.updateAdminSysMsgsData($scope.restURL, $scope.sysMsgsId, $sanitize($scope.adminSysMsgsMessage), null, $scope.uid, $scope.sysMsgsStartDateTime, 
					$scope.sysMsgsEndDateTime).then(function(response) {
				//hide modal overlay
	    		$("#adminSysMsgsModalBody").LoadingOverlay("hide");    				
				//show message back to the user				
				showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i> System Message successfully saved.', 'success');
	  //  		showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i>  ' + response.data.response + '.', 'success');	
				
				//hide the system messages Modal window
				$("#adminSysMsgsModal").modal("hide");
				
				//clear the form fields
				$scope.adminSysMsgsMessage = '';
				$scope.sysMsgsId = '';
				$scope.adminSysMsgsStartDate = '';
				
				//show the table overlay
				$("#adminSysMsgsTable").LoadingOverlay("show"); 
				
				//refresh the admin page data
				//loadAdminPageData();
				loadAdminPageMsgsData();
				
			}).catch(function(err) {
				console.log('updateAdminSysMsgsData REST Error:' + err);    				
				//hide modal overlay
	    		$("#adminSysMsgsModalBody").LoadingOverlay("hide");    				
				//show message to user that assign to user failed
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> ' + err.data, 'danger');
			});
			
		} else {
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Please complete all required form fields.', 'danger');
		}
	}

	//this function loads/refreshes the system messags data
	function loadAdminPageMsgsData() {
		//load the system messages from the header service
		adminFactory.getAdminPageMsgsData($scope.restURL,$scope.uid, $scope.organization).then(function(response) {
			$("#adminSysMsgsTable").bootstrapTable('load', response.data.messages);
			
			$("#adminSysMsgsTable").LoadingOverlay("hide"); 
		}).catch(function(err) {
			console.log('getAdminPageMsgsData  RESTError:' +  err.data);    				
			//hide the overlay spinner
//			$("#adminPlanSysMsgTable").LoadingOverlay("hide");    
			$("#adminSysMsgsTable").LoadingOverlay("hide");  
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> No System Messages data available due to ' +  err.data + ' error.', 'danger');
		});
	}

	//this function loads/refreshes landing page data
	function loadAdminPageData() {
		//load the models data from the landing page web service
		adminFactory.getAdminPageData($scope.restURL,$scope.uid, $scope.organization).then(function(response) {
			//set a scope level variable to the info returned from the services
			$scope.adminData = response.data;
			
			//merge the models and nonActiveModels arrays together, and then display the result
			$scope.allModelsArray = $.merge(response.data.models, response.data.nonActiveModels);
			console.log("allModelsArray size = " + $scope.allModelsArray.length);
			
			//sort the allModelsArray
			$scope.allModelsArray.sort(function(a, b){
				return (a['modelName'] > b['modelName']) ? 1 : ((a['modelName'] > b['modelName']) ? -1 : 0);
			});
			
			//populate the Model Table
			$("#adminModelTable").bootstrapTable('load', $scope.allModelsArray);
			//populate the Edit Table
			//$("#adminEditTable").bootstrapTable('load', response.data.edits);
			
			$("#adminModelTable").LoadingOverlay("hide"); 
			$.LoadingOverlay("hide"); 
		}).catch(function(err) {
			console.log('getLandingPageData  RESTError:' +  err.data);    				
			//hide the overlay spinner
			$.LoadingOverlay("hide"); 
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> No Admin Page data available due to ' +  err.data + ' error.', 'danger');
		});
	}

	function convertToMilitaryHour(pHour, pAmPm) {
		var hours = parseInt(pHour.substr(0, 2)); 
		var oHour;
		
		//check to see if user chose AM
		if (pAmPm == 'AM' && hours == 12) {
			//convert 12am to 00
			oHour = pTime.replace('12', '00');
		} else if (pAmPm == 'PM' && hours < 12) {
			oHour = hours + 12;
		} else if (pAmPm == 'AM' && hours < 12) {
			oHour = pHour;
		} else if (pAmPm == 'PM' && hours == 12) {
			oHour = pHour;
		}
		
		console.log("converted hour value = " + oHour);
		
		return oHour;
	}

	//this function validates date ranges for the System Messages form
	$scope.checkDtRangeSysMsgs = function() {
		var startDateTime = '';
		var endDateTime = '';
		
		//check to see if end date is before current date
		if ($scope.adminSysMsgsEndDate != '' && $scope.adminSysMsgsEndHours != '' && $scope.adminSysMsgsEndMins != '' && $scope.adminSysMsgsEndAmPm) {	
			
			endDateTime = $scope.adminSysMsgsEndDate + ' ' + convertToMilitaryHour($scope.adminSysMsgsEndHours, $scope.adminSysMsgsEndAmPm) + ':' + $scope.adminSysMsgsEndMins + ':00.000000';
			
			var currentDate = moment(new Date()).format("MMMM DD, YYYY hh:mm:ss a");
			endDateTime = moment(endDateTime).format("MMMM DD, YYYY hh:mm:ss a");
			//console.log("formatted date = " + currentDate);
			//console.log("endDateTime = " + endDateTime);
			
			if(moment(currentDate).isAfter(endDateTime)){
				console.log('End date cannot be in the past');
				$scope.adminSysMsgsForm.adminSysMsgsEndDate.$setValidity('msgspastenddterror', false);
		        $scope.adminSysMsgsForm.adminSysMsgsEndHours.$setValidity('msgspastenddterror', false);
		        $scope.adminSysMsgsForm.adminSysMsgsEndMins.$setValidity('msgspastenddterror', false);
		        $scope.adminSysMsgsForm.adminSysMsgsEndAmPm.$setValidity('msgspastenddterror', false);
			} else {
				$scope.adminSysMsgsForm.adminSysMsgsEndDate.$setValidity('msgspastenddterror', true);
		        $scope.adminSysMsgsForm.adminSysMsgsEndHours.$setValidity('msgspastenddterror', true);
		        $scope.adminSysMsgsForm.adminSysMsgsEndMins.$setValidity('msgspastenddterror', true);
		        $scope.adminSysMsgsForm.adminSysMsgsEndAmPm.$setValidity('msgspastenddterror', true);
			}
		}
		
		//make sure we have all the date and time values to do a comparison
		if ($scope.adminSysMsgsStartDate != '' && $scope.adminSysMsgsStartHours != '' && $scope.adminSysMsgsStartMins != '' && $scope.adminSysMsgsStartAmPm
				&& $scope.adminSysMsgsEndDate != '' && $scope.adminSysMsgsEndHours != '' && $scope.adminSysMsgsEndMins != '' && $scope.adminSysMsgsEndAmPm) {
			
			//properly format the start and end dates/times to convert to a date object
			startDateTime = $scope.adminSysMsgsStartDate + ' ' + convertToMilitaryHour($scope.adminSysMsgsStartHours, $scope.adminSysMsgsStartAmPm) + ':' + $scope.adminSysMsgsStartMins + ':00.000000';
			endDateTime = $scope.adminSysMsgsEndDate + ' ' + convertToMilitaryHour($scope.adminSysMsgsEndHours, $scope.adminSysMsgsEndAmPm) + ':' + $scope.adminSysMsgsEndMins + ':00.000000';
		
			startDateTime = moment(startDateTime).format("MMMM DD, YYYY hh:mm:ss a");
			endDateTime = moment(endDateTime).format("MMMM DD, YYYY hh:mm:ss a");			
			
			//check to make sure start date comes before end date			
			if(moment(startDateTime).isAfter(endDateTime)){
		          console.log('End Date should be greater than start date');
		          //invalidate the form until the issue is resolved
		          $scope.adminSysMsgsForm.adminSysMsgsStartDate.$setValidity('msgsdterror', false);
		          $scope.adminSysMsgsForm.adminSysMsgsStartHours.$setValidity('msgsdterror', false);
		          $scope.adminSysMsgsForm.adminSysMsgsStartMins.$setValidity('msgsdterror', false);
		          $scope.adminSysMsgsForm.adminSysMsgsStartAmPm.$setValidity('msgsdterror', false);
		    }  else {
		    	//validate the form fields
		    	 $scope.adminSysMsgsForm.adminSysMsgsStartDate.$setValidity('msgsdterror', true);
		    	 $scope.adminSysMsgsForm.adminSysMsgsStartHours.$setValidity('msgsdterror', true);
		         $scope.adminSysMsgsForm.adminSysMsgsStartMins.$setValidity('msgsdterror', true);
		         $scope.adminSysMsgsForm.adminSysMsgsStartAmPm.$setValidity('msgsdterror', true);
		    }
		}
	}
}]);

//define a factory to perform REST functionality
appAdmin.factory('adminFactory', ['$http', '$rootScope', function($http, $rootScope) {	
	return {
		getAdminPageData: function(pURL, pUserId, pUserZone) {
			console.log("Inside appAdmin factory getLandingPageData");
    		
    		//create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			userZone: pUserZone
    		};
  
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getLandingPageData REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/queryLandPageData', jsonData);
		},
		getAdminPageMsgsData: function(pURL, pUserId, pUserZone) {
			console.log("Inside appAdmin factory getAdminPageMsgsData");
    		
    		//create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			userZone: pUserZone
    		};
  
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getAdminPageMsgsData REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/adminMsgsData', jsonData);
		},
    	getAllZones: function(pURL, pUserId) {
    		console.log("Inside adminFactory.getAllZones. pURL = " + pURL);
    		
    		//create the json request object
    		var entryCriteria = {
//    				noRequiredField: 'noRequiredValue'	
    				userId: pUserId
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getAllZones REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/queryAllZones', jsonData);
    	},
		updateAdminOutagesData: function(pURL, pId, pMessage, pStartDate, pEndDate, pJurisdiction, pUid) {
			
			var entryCriteria = {
					message: pMessage,
					id: pId,
					loggedInUserId: pUid,
					jurisdiction: pJurisdiction,
					endDate: pEndDate,
	    			startDate: pStartDate,
	    			zonesAffected: pJurisdiction,
	    			title: pMessage
			};
						
			//create the JSON object to be used in the REST Request
			jsonData = JSON.stringify(entryCriteria);
			console.log('updateAdminPlnSysOutagesData  REST request = ' + jsonData);
			
			return $http.post(pURL + '/rest/portal/saveAdminPlnSysOutages', jsonData);
		},
		deletePlanSystemOutage: function(pURL, pMessageId) {
			
			var entryCriteria = {
	    			id: pMessageId
			};
			
			//create the JSON object to be used in the REST Request
			jsonData = JSON.stringify(entryCriteria);
			console.log('landingpage/outage/id webservice call : = ' + jsonData);
			
			return $http.post(pURL + '/rest/portal/deleteAdminPlnSysOutages', jsonData);
		},
		updateModelsData: function(pURL, pModelId, pModelDescription, pModelStatus, pModelOwner, pModelOwnerPhone, pModelOwnerEmail, pUserId, pPriority) {
			//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
			
			var entryCriteria = {
				modelId: pModelId,
    			modelDesc: pModelDescription,
    			activeStatus: pModelStatus,
    			ownerName: pModelOwner,
    			ownerPhone: pModelOwnerPhone,
    			ownerEmail: pModelOwnerEmail,
    			loggedInUserId : pUserId,
    			priorityInd: pPriority
			};
			
			//create the JSON object to be used in the REST Request
			jsonData = JSON.stringify(entryCriteria);
			console.log('updateModelsData Request = ' + jsonData);
			
			return $http.post(pURL + '/rest/portal/saveAdminModelsData', jsonData);
		},
		updateAdminSysMsgsData: function(pURL, pMessageId, pMessage, pDateAdded, pUid, pStartDate, pEndDate) {
			
			//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
			
			var entryCriteria = {
	    			id: pMessageId,
	    			message: pMessage,
	    			loggedInUserId: pUid,
					dateAdded: pDateAdded,
					endDt: pEndDate,
	    			startDt: pStartDate,
				};

			//create the JSON object to be used in the REST Request
			jsonData = JSON.stringify(entryCriteria);
			console.log('landingpage/message webservice call : = ' + jsonData);
	
			return $http.post(pURL + '/rest/portal/saveAdminSysMsgsData', jsonData);
				
		},
		deleteAdminSysMsgsData: function(pURL, pMessageId) {
			
			//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
			
			var entryCriteria = {
	    		id: pMessageId
			};
						
			//create the JSON object to be used in the REST Request
			jsonData = JSON.stringify(entryCriteria);
	
			return $http.post(pURL + '/rest/portal/deleteAdminSysMsgs', jsonData);
				
		},
		deleteAdminModelsData: function(pURL, pModelId) {
			var entryCriteria = {
				modelId: pModelId
			};
			
			//create the JSON object to be used in the REST Request
			jsonData = JSON.stringify(entryCriteria);
	
			return $http.post(pURL + '/rest/portal/deleteAdminModels', jsonData);
		}
	}
}]);	
