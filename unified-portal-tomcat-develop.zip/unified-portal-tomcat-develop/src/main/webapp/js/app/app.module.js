/**
 *   This is the main module (controller) declaration for the entire Unified Portal application
 */
 
 var env = {};
  
// Import variables if present (from env.js)
if(window){
  Object.assign(env, window.__env);
}

var app = angular.module('app.module', ['nav.module', 'index.module', 'casemgmt.module', 
                          'details.module',  'util.module', 'iphome.module']);

app.config([ '$httpProvider', function($httpProvider) {
	$httpProvider.interceptors.push('APIInterceptor');	
} ]);

app.constant('__env', env);
app.service('APIInterceptor', function() {
var service = this;
service.request = function(config) {

	config.headers = config.headers || {};

	if (localStorage.getItem("okta-token-storage") != null
			&& localStorage.getItem("okta-token-storage") != undefined) {

		var oktatoken = JSON.parse(localStorage
				.getItem("okta-token-storage"));
		var idToken = oktatoken["accessToken"]["accessToken"];

		if (idToken) {
			config.headers.Authorization = 'Bearer' + idToken;
		}

	}
	return config;

};
});