var appCaseMgmt = angular.module('casemgmt.module', ['ngRoute', 'ngCookies', 'ngSanitize']);

appCaseMgmt.controller("caseMgmtController", ['$location', '$route', '$scope','$rootScope','$cookies', '$window', '$sanitize', '$sce','caseMgmtFactory', 'utilService', 'utilFactory','cache', 'detailsFactory', 'decodedListNmFilter','$q',
                                              function ($location, $route, $scope, $rootScope, $cookies, $window, $sanitize, $sce, caseMgmtFactory, utilService, utilFactory, cache, detailsFactory, decodedListNmFilter, $q) {
	console.log('Inside the caseMgmtController.');

	// get the Okta authClient object from the util service
	var authClient = utilService.getOktaAuth();
	function updatePageTitle(newTitle) {
		document.title = newTitle;

		// Announce the new title for screen readers
		const srAnnouncer = document.createElement("div");
		srAnnouncer.setAttribute("role", "alert");
		srAnnouncer.setAttribute("aria-live", "assertive");
		srAnnouncer.style.position = "absolute";
		srAnnouncer.style.width = "1px";
		srAnnouncer.style.height = "1px";
		srAnnouncer.style.margin = "-1px";
		srAnnouncer.style.clip = "rect(0, 0, 0, 0)";
		srAnnouncer.style.overflow = "hidden";
		srAnnouncer.textContent = newTitle;
		document.body.appendChild(srAnnouncer);

		// Remove the announcer after a short delay
		setTimeout(() => {
		  document.body.removeChild(srAnnouncer);
		}, 1000);
	  }

	  // Set the page title for "ASR Summary"
	  $rootScope.pageTitle = "ASR Summary";
	  updatePageTitle($rootScope.pageTitle);

	authClient.tokenManager.getTokens()
		.then(({ accessToken, idToken }) => {
			// handle accessToken and idToken
			if (accessToken) {
				// user has valid access token, so show page contents
				showSummaryPageContents(idToken);
			} else {
				// no token and not logged-in, so redirect to login screen               
				authClient.token.getWithRedirect({
					responseType: ['token', 'id_token']
				});
			}
		});

	// this function shows the page to users that have been authenticated via Okta
	showSummaryPageContents = function(pIdToken) {

		if (pIdToken) {
			// user has valid token... so proceed with page load activities
			// show the index page Dom objects
			$('#caseMgmtContainer').removeAttr('hidden');

			// create a scope level unique identifier
			$scope.loadPageUniqueId = Math.floor(Math.random() * 1000) + Date.now();
			
			//broadcast this event to the broadcastSlaMetrics listener
			$rootScope.$broadcast('broadcastSlaMetrics', {message:"Case Mgmt Load - Start: " + $scope.loadPageUniqueId, userId: ""});
			
			//Advanced Search Tab functionality
			$scope.active = 1;
			$scope.selectTab = function(value) {
				$scope.active = value;
			}
			
			$scope.isActive = function(value) {
				if($scope.active==value){
					return true;
				}
				else{
					return false;
				}
			}

			// default the panel heading to Asr Summary
			$scope.summaryHeaderTitle = 'ASR Summary';
				
			//set the undefined parameter as javascript defines it
			var undefined = void(0);
			// get url param object
			var urlParamObj = $location.search();	
			
			$scope.workItemQueryParam = urlParamObj.workitem;
			$scope.workItemTypeQueryParam = urlParamObj.type;	
			$scope.userQueryParam = urlParamObj.user;
			$scope.listNameParam = urlParamObj.listNm;
			$scope.infoModel = urlParamObj.model;
			$scope.infoRunDt = urlParamObj.runDt;
			$scope.infoASRType = urlParamObj.asrType;

			console.log("Inside the caseMgmtController. ID =  " +$scope.workItemQueryParam 
				+ ", type= " + $scope.workItemTypeQueryParam);

			//initialize the ASR Management Table data table
			$("#asrMgmtTable").bootstrapTable({});
			
			// implement a fix to align the table headers to the body 
			$("#asrMgmtTable").find("thead").find(".bs-checkbox").removeAttr('style').addClass("sumTableHeaderAlign");
			$("#asrMgmtTable").find("thead").find(".bs-checkbox").find(".fht-cell").removeAttr('style').addClass("sumTableHeaderAlign");
			
			
			//initialize the ASR Management Table data table
			$("#asrMDCDTable").bootstrapTable({});
			
			// implement a fix to align the table headers to the body 
			$("#asrMDCDTable").find("thead").find(".bs-checkbox").removeAttr('style').addClass("sumTableHeaderAlign");
			$("#asrMDCDTable").find("thead").find(".bs-checkbox").find(".fht-cell").removeAttr('style').addClass("sumTableHeaderAlign");
			
			// add an id attribute to the checkbox in the table
			//$("[name='btSelectAll']").attr('id', 'btSelectAll');
			// $("#asrMgmtTable").find("thead").find(".bs-checkbox").find(".fht-cell").append("<input type='checkbox' class='form-check-input' id='checkAll1' />");
			
			//console.log("jquery results are: " + $("#asrMgmtTable").find("thead").find(".bs-checkbox").attr("class"));

			// default the Leads/Investigations search jurisdiction check box to checked
			$scope.searcMyZoneOnlyInd = true;
			
			// set the type scope variable to search
			$scope.disableWorkSetBtn = 'hide';
			$scope.disableAddtoExistingWS = 'hide';
			$scope.disableAddtoExistingWSMDCR = 'hide';
			
			//set the scope variable used to hide the add to exclusion list button
			$scope.hideAddToExcludeSetBtn = 'hide';
			$scope.hideSecondAddToExcludeSetBtn = 'hide';
			$scope.hideRemoveFromExcludeSetBtn = 'hide';
			
			
			$scope.hideWorkingSetButtons = 'hide';
			$scope.hideMDCDWorkingSetButtons = 'hide';
			

			//this function listens for the skip Nav link scope broadcast
			$scope.$on('skipNavEvent', function() {
				console.log('skipNavEvent detected!');
				
				//set the focus on the search portlet panel heading
				$("#asrSummaryTableHdng").focus();
			});

			//call the factory method to get the property from the property file
			utilFactory.getURLPropertyFromFile().then(function(response) {
				$scope.restURL = response.data;

				$scope.userId =  pIdToken.claims.preferred_username;

				// parse the group claim array from the token
				// loop through the array to parse all of the values from the array
				$scope.rolesArray = [];
				$scope.userAttrArray = [];
				$scope.zonesArray = [];
				var groupsArray = pIdToken.claims.groups;			

				for (i = 0; i < groupsArray.length; i++) {
					console.log('group - ' + groupsArray[i]);
					var groupObj = groupsArray[i];

					// populate role array
					if (groupObj.search('FPSUI Role') != -1) {
						$scope.rolesArray.push(groupObj.replace("FPSUI Role", "").trim());
					}

					// populate the zone Array
					if (groupObj.search('FPSUI Zone') != -1) {
						$scope.zonesArray.push(groupObj.replace("FPSUI Zone", "").trim());
					}

					// populate the attributes Array
					if (groupObj.search('FPSUI Attrib') != -1) {
						$scope.userAttrArray.push(groupObj.replace("FPSUI Attrib", "").trim());
					}
				}
				
				if($scope.rolesArray.indexOf("MAC") != -1){					
					// use this variable to hide Provider Education Report button
					$scope.hideFromMacs = true;
				} else {
					// show the Provider Education Report button to non-MAC users
					$scope.hideFromMacs = false;
				}
				
				if ($scope.zonesArray.indexOf("MEDIC") != -1) {
					$scope.medicUser = true;
				}
				
				// Hide medicaid tab from MACs and Medics
				if ($scope.medicUser || $scope.hideFromMacs) {
					$scope.hideMedicaidTab = true;
					console.log("Hide medicaid tab from MACs and Medics!");
					
					//disable the medicaid AsrInfo Details tab
					$('#medicaidAsrInfoSummaryItem').addClass('disabled');
					$('#medicaidAsrInfoSummaryItem').attr('aria-disabled', 'true');
					$('#medicaidAsrInfoSummaryTabLink').css('cursor', 'not-allowed');
					$('#medicaidAsrInfoSummaryTabLink').css('pointer-events', 'none');
					$('#medicaidAsrInfoSummaryTabLink').removeAttr('data-toggle');
					
					$('#medicaidAsrInfoSearchItem').addClass('disabled');
					$('#medicaidAsrInfoSearchItem').attr('aria-disabled', 'true');
					$('#medicaidAsrInfoSearchTabLink').css('cursor', 'not-allowed');
					$('#medicaidAsrInfoSearchTabLink').css('pointer-events', 'none');
					$('#medicaidAsrInfoSearchTabLink').removeAttr('data-toggle');
					console.log("Disable Medicaid tab");
				}
				else{
					$scope.hideMedicaidTab = false;
				}

				// set the user's zone as the first entry in the zonesarray
				$scope.userZone = $scope.zonesArray[0];
				
				$scope.tempDefaultAsrView = null;
				
				// Get the User details to check if he is belongs to medicare or medicaid.
				caseMgmtFactory.buildAsrSummaryPrefs($scope.restURL,$scope.userId, $scope.userZone).then(function(response) {
						//set a scope level variable to the info returned from the services
						$scope.indexData = response.asrView.data;
						
						$scope.workItemQueryParam === undefined;
						$scope.customSearchDefaultView = response.asrView.prefJson;
						
						if ($scope.hideMedicaidTab != true && ($scope.workItemQueryParam === undefined && response.asrView.prefJson != null && response.asrView.prefJson != undefined && response.asrView.prefJson != "") ){
							$scope.defaultAsrView = response.asrView.prefJson;
						}else {
							$scope.defaultAsrView = "medicare";
						}
						$scope.currentASRview = $scope.defaultAsrView;

					var workbenchActiveTab = localStorage.getItem("workbenchActiveTab")
					if (workbenchActiveTab == 'MDCD') {
						$scope.tempDefaultAsrView = 'medicaid';
					}
					else if(workbenchActiveTab == 'MDCR') {
						$scope.tempDefaultAsrView = 'medicare';
					}
					else{
						$scope.tempDefaultAsrView = $scope.defaultAsrView;
					}
					localStorage.removeItem("workbenchActiveTab");
						
						console.log("Default ASR View from service: ", $scope.tempDefaultAsrView);
						$("#asrMDCDTable").bootstrapTable({});
						$("#asrMgmtTable").bootstrapTable({});

						if($scope.infoASRType == "MDCD"){
							$scope.tempDefaultAsrView = 'medicaid'
							$scope.currentASRview == "medicaid"
						}
						if($scope.infoASRType == "MDCR"){
							$scope.tempDefaultAsrView = 'medicare'
							$scope.currentASRview == "medicare"
						}
						
						if ($scope.tempDefaultAsrView == "medicaid"){
							$scope.showMedicaidAsrInfoSummaryTab();
							
						}else {
							$scope.showMedicareAsrInfoSummaryTab();
						}
						if($scope.currentASRview == "medicaid"){
							$scope.showMedicaidAsrInfoSearchTab();
						}
						else{
							$scope.showMedicareAsrInfoSearchTab();
						}
						
													
				// mdcdr search prefs	
				if (response.mdcrPrefs.prefJson != null && response.mdcrPrefs.prefJson != void(0)) {
					//convert the returned json array to an object, and then loop through it
					var prefJsonArray = JSON.parse(response.mdcrPrefs.prefJson);
					console.log("prefJsonArray size = " + prefJsonArray.length);
										
					for (i=0; i < prefJsonArray.length; i ++) {
						//hide the columns returned by the web service
						$('#asrMgmtTable').bootstrapTable('hideColumn', prefJsonArray[i])
						
						
					}
				} else {
					console.log("User has no preferences set.");
				}
			// mdcd search prefs				
					if (response.mdcdPrefs.prefJson != null && response.mdcdPrefs.prefJson != void(0)) {
						//convert the returned json array to an object, and then loop through it
						var prefJsonArray = JSON.parse(response.mdcdPrefs.prefJson);
						console.log("prefJsonArray size = " + prefJsonArray.length);
											
						for (i=0; i < prefJsonArray.length; i ++) {
							//hide the columns returned by the web service
							
							
						
								$('#asrMDCDTable').bootstrapTable('hideColumn', prefJsonArray[i])
							
						}
					} else {
						console.log("User has no preferences set.");
					}
				}).	catch(function(err){    			
					console.log("ASR Management REST Error: " + err.status);
										
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Loading user preferences failed for MDCD due to ' + err.status, 'danger');
				});
				

				//if the user is a MAC user, then hide certain columns
				if($scope.rolesArray.indexOf("MAC") != -1){
					//call the function used to hide MAC table columns
					$scope.hideMACTableCols();
				
					//use ng-show to hide the Barrier to Action, Assigned To, First Name, Last Name, Activities
					//Ruling Reasons, and Actions components from the user
					$scope.showForMacUser = false;
				} else {
					//use ng-show to display the Barrier to Action, Assigned To, First Name, Last Name, Activities
					//Ruling Reasons, and Actions components to the user
					$scope.showForMacUser = true;
				}

				//only show the Prioritize for UCM button to users belonging to certain roles
				if ($scope.rolesArray.indexOf("Admin") != -1  
					|| $scope.rolesArray.indexOf("Prioritize Sup") != -1
					|| ($scope.rolesArray.indexOf("MAC") != -1 && $scope.userAttrArray.indexOf('ASR Prioritization') != -1)) {
			
					console.log('User is authorized to Prioritize ASRs.');
					
					$('#prioritizeUCMBtnGroup').removeClass('hidden');					
				}

				//check for a query param denoting the user clicked on a work item on landing page
				if ($scope.workItemQueryParam === undefined && $scope.infoModel === undefined) {
					console.log("The index parameter does NOT exist.");	
					// show the overlay spinner for the results panel						
					$.LoadingOverlay("show");
					
					// show the search modal window
					$("#searchModal").modal("show");
			
					// load the ref data for the search components
					$scope.getSearchComponentVals();
					
					//broadcast this event to the broadcastSlaMetrics listener
					$rootScope.$broadcast('broadcastSlaMetrics', {message:"Case Mgmt Load - End: " + $scope.loadPageUniqueId, userId: ""});
					
					// show the overlay spinner for the results panel						
					$.LoadingOverlay("hide");
				} else {
					console.log("The index parameter DOES exist: " + $scope.workItemQueryParam);
					
					// Grey out medicaid tab
					//disable the medicaid AsrInfo SummaryTab tab
					if ($scope.infoASRType == "MDCR") {
						$scope.currentASRview = "medicare"
						$scope.showMedicareAsrInfoSummaryTab();
					}
					else {
						$scope.currentASRview = "medicaid"
						$scope.showMedicaidAsrInfoSummaryTab();
					}
					
					
					console.log("grey out medicaid tab");

					// conduct search based on list type
					if ($scope.workItemTypeQueryParam == 'search') {	
						// show the overlay spinner for the results panel						
						$("#asrPanelBody").LoadingOverlay("show");
						
						// disable the remove from working set because type is search
						$scope.disableWorkSetBtn = 'hide';
						
						// show the add to exclusion set button, and hide other exclusion buttons
						$scope.hideAddToExcludeSetBtn = 'show';	
						$scope.hideSecondAddToExcludeSetBtn = 'hide';
						$scope.hideRemoveFromExcludeSetBtn = 'hide';
						
						// get the asr query results
						caseMgmtFactory.getAsrQueryList($scope.restURL,  $scope.userId, $scope.workItemQueryParam).then(function(response) {
							// change the panel heading to search results
							$scope.summaryHeaderTitle = 'Search Results';

							var searchUrl = window.location.href;
							var urlParts = searchUrl.split('?');

							var queryParams = urlParts[1];
							var paramsArray = queryParams.split('&');
							var asrType = searchUrl.slice(-4);
							paramsArray.forEach(function (param) {
								var keyvalue = param.split('=');
								if (keyvalue[0] === "asrType") {
									asrType = keyvalue[1];
								}
							});
							if (asrType == "MDCR") {
								$scope.currentASRview = "medicare"
								$scope.showMedicareAsrInfoSummaryTab();
								$('#medicaidAsrInfoSummaryItem').addClass('disabled');
								$('#medicaidAsrInfoSummaryItem').attr('aria-disabled', 'true');
								$('#medicaidAsrInfoSummaryTabLink').css('cursor', 'not-allowed');
								$('#medicaidAsrInfoSummaryTabLink').css('pointer-events', 'none');
								$('#medicaidAsrInfoSummaryTabLink').removeAttr('data-toggle');
							}
							else {
								$scope.currentASRview = "medicaid"
								$scope.showMedicaidAsrInfoSummaryTab();
								$('#medicareAsrInfoSummaryItem').addClass('disabled');
								$('#medicareAsrInfoSummaryItem').attr('aria-disabled', 'true');
								$('#medicareAsrInfoSummaryTabLink').css('cursor', 'not-allowed');
								$('#medicareAsrInfoSummaryTabLink').css('pointer-events', 'none');
								$('#medicareAsrInfoSummaryTabLink').removeAttr('data-toggle');
							}
							if (response.data.responseData.length > 0) {
								$("#asrMgmtTable").bootstrapTable('load', response.data.responseData);
								$('#medicareAsrInfoSummaryItem').removeClass('disabled');
								$('#medicareAsrInfoSummaryItem').attr('aria-disabled', 'false');
								$('#medicareAsrInfoSummaryTabLink').css('cursor', 'pointer');
								$('#medicareAsrInfoSummaryTabLink').css('pointer-events', 'auto');
								$('#medicareAsrInfoSummaryTabLink').attr('data-toggle', 'tab');
							}

							if (response.data.responseDataMdcd.length > 0) {
								$("#asrMDCDTable").bootstrapTable('load', response.data.responseDataMdcd);
								$('#medicaidAsrInfoSummaryItem').removeClass('disabled');
								$('#medicaidAsrInfoSummaryItem').attr('aria-disabled', 'false');
								$('#medicaidAsrInfoSummaryTabLink').css('cursor', 'pointer');
								$('#medicaidAsrInfoSummaryTabLink').css('pointer-events', 'auto');
								$('#medicaidAsrInfoSummaryTabLink').attr('data-toggle', 'tab');
							}

								
								//broadcast this event to the broadcastSlaMetrics listener
								$rootScope.$broadcast('broadcastSlaMetrics', {message:"Case Mgmt Load - End: " + $scope.loadPageUniqueId, userId: ""});
								
								// hide the overlay spinner for the results panel						
								$("#asrPanelBody").LoadingOverlay("hide");
							}).
							catch(function(err){    			
							console.log("Get Work Item Query REST Error: " + err.status);
								// Hide full page LoadingOverlay
							$("#asrPanelBody").LoadingOverlay("hide");
								
							showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Query load failed due to ' + err.status, 'danger');
						});
					} else if ($scope.workItemTypeQueryParam == 'exclusion') {
						// show panel overlay						
						$("#asrPanelBody").LoadingOverlay("show");
						
						// work item type is not an working set, so disable remove from button
						$scope.disableWorkSetBtn = 'hide';
						
						// get the exclusion list
						caseMgmtFactory.getExclusionList($scope.restURL, $scope.workItemQueryParam, $scope.userQueryParam).then(function(response) {
							// change the panel heading to work item
							$scope.summaryHeaderTitle = decodedListNmFilter(response.data.listNm);
							
							// hide panel overlay
							$("#asrPanelBody").LoadingOverlay("hide");
							
							// load the asr search table
							$("#asrMgmtTable").bootstrapTable('load',response.data.responseData);
							
							$("#asrMDCDTable").bootstrapTable('load',response.data.responseDataMdcd);
							
							// Show active tab
							if ($scope.currentASRview == "medicare"){
								$scope.showMedicareAsrInfoSummaryTab();
							} else if ($scope.currentASRview == "medicaid"){
								$scope.showMedicaidAsrInfoSummaryTab();
							}
						
							// check the ownership of the exclusion list
							if (response.data.owner != $scope.userId) {
								// user is not viewing their exclusion set, so show all buttons
								$scope.hideAddToExcludeSetBtn = 'show';
								$scope.hideSecondAddToExcludeSetBtn = 'show';
								$scope.hideRemoveFromExcludeSetBtn = 'show';
							} else {
								// user is viewing their exclusion set, so show the add to existing and remove from buttons
								$scope.hideSecondAddToExcludeSetBtn = 'show';
								$scope.hideRemoveFromExcludeSetBtn = 'show';
							}
						}).
						catch(function(err){    			
							console.log("Get Exclusion List REST Error: " + err.status);
													
							// Hide full page LoadingOverlay
							$("#asrPanelBody").LoadingOverlay("hide");
						
							showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Exclusion List failed to load due to ' + err.status, 'danger');
						});
					} else if ($scope.workItemTypeQueryParam == 'picexclusion') {
						// show panel overlay						
						$("#asrPanelBody").LoadingOverlay("show");
						
						// work item type is not an working set, so disable remove from button
						$scope.disableWorkSetBtn = 'hide';
						
						// get the pic exclusion list
						caseMgmtFactory.getPicExclusionList($scope.restURL, $scope.workItemQueryParam, $scope.userId).then(function(response) {
							// change the panel heading to work item
							$scope.summaryHeaderTitle = decodedListNmFilter(response.data.listNm);
							
							// hide panel overlay
							$("#asrPanelBody").LoadingOverlay("hide");
							
							$("#asrMgmtTable").bootstrapTable('load',response.data.responseData);
							
							$("#asrMDCDTable").bootstrapTable('load',response.data.responseDataMdcd);
							
							// Show active tab
							if ($scope.currentASRview == "medicare"){
								$scope.showMedicareAsrInfoSummaryTab();
							} else if ($scope.currentASRview == "medicaid"){
								$scope.showMedicaidAsrInfoSummaryTab();
							}
						}).
						catch(function(err){    			
							console.log("Get PIC Exclusion List REST Error: " + err.status);
														
							// hide panel overlay
							$("#asrPanelBody").LoadingOverlay("hide");
							
							showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i>PIC Exclusion List failed to load due to ' + err.status, 'danger');
						});
					} else if ($scope.workItemTypeQueryParam == 'searchEdit') {
						// show the user their edited search
						console.log("Show saved search criteria...");
						
						// open the search modal window and load ref data
						$scope.conductSearchBtnClick('editSearch');		
					}
					else if($scope.infoModel){
						$("#asrPanelBody").LoadingOverlay("show");
						
						// disable the remove from working set because type is search
						$scope.disableWorkSetBtn = 'hide';
						
						// show the add to exclusion set button, and hide other exclusion buttons
						$scope.hideAddToExcludeSetBtn = 'show';	
						$scope.hideSecondAddToExcludeSetBtn = 'hide';
						$scope.hideRemoveFromExcludeSetBtn = 'hide';
						
						caseMgmtFactory.getModelInfo($scope.restURL, $scope.infoModel, $scope.infoRunDt, $scope.infoASRType, $scope.userId).then(function(response) {
							// change the panel heading to search results
							
							if ($scope.infoASRType == "medicare") {
								$scope.currentASRview = "medicare"
								$scope.showMedicareAsrInfoSummaryTab();
								$('#medicaidAsrInfoSummaryItem').addClass('disabled');
								$('#medicaidAsrInfoSummaryItem').attr('aria-disabled', 'true');
								$('#medicaidAsrInfoSummaryTabLink').css('cursor', 'not-allowed');
								$('#medicaidAsrInfoSummaryTabLink').css('pointer-events', 'none');
								$('#medicaidAsrInfoSummaryTabLink').removeAttr('data-toggle');
							}
							else {
								$scope.currentASRview = "medicaid"
								$scope.showMedicaidAsrInfoSummaryTab();
								$('#medicareAsrInfoSummaryItem').addClass('disabled');
								$('#medicareAsrInfoSummaryItem').attr('aria-disabled', 'true');
								$('#medicareAsrInfoSummaryTabLink').css('cursor', 'not-allowed');
								$('#medicareAsrInfoSummaryTabLink').css('pointer-events', 'none');
								$('#medicareAsrInfoSummaryTabLink').removeAttr('data-toggle');
							}
							if (response.data.responseData.length > 0) {
								$("#asrMgmtTable").bootstrapTable('load', response.data.responseData);
								$('#medicareAsrInfoSummaryItem').removeClass('disabled');
								$('#medicareAsrInfoSummaryItem').attr('aria-disabled', 'false');
								$('#medicareAsrInfoSummaryTabLink').css('cursor', 'pointer');
								$('#medicareAsrInfoSummaryTabLink').css('pointer-events', 'auto');
								$('#medicareAsrInfoSummaryTabLink').attr('data-toggle', 'tab');
							}

							if (response.data.responseDataMdcd.length > 0) {
								$("#asrMDCDTable").bootstrapTable('load', response.data.responseDataMdcd);
								$('#medicaidAsrInfoSummaryItem').removeClass('disabled');
								$('#medicaidAsrInfoSummaryItem').attr('aria-disabled', 'false');
								$('#medicaidAsrInfoSummaryTabLink').css('cursor', 'pointer');
								$('#medicaidAsrInfoSummaryTabLink').css('pointer-events', 'auto');
								$('#medicaidAsrInfoSummaryTabLink').attr('data-toggle', 'tab');
							}

								
								//broadcast this event to the broadcastSlaMetrics listener
								$rootScope.$broadcast('broadcastSlaMetrics', {message:"Case Mgmt Load - End: " + $scope.loadPageUniqueId, userId: ""});
								
								// hide the overlay spinner for the results panel						
								$("#asrPanelBody").LoadingOverlay("hide");
							}).
							catch(function(err){    			
							console.log("Get Work Item Query REST Error: " + err.status);
								// Hide full page LoadingOverlay
							$("#asrPanelBody").LoadingOverlay("hide");
								
							showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Query load failed due to ' + err.status, 'danger');
						});

					} else {
						// show the overlay spinner for the results panel						
						$("#asrPanelBody").LoadingOverlay("show");
						
						// work item type is NOT a search, so show remove from button
						$scope.disableWorkSetBtn = 'show';
						
						// show the add to exclusion set button
						$scope.hideAddToExcludeSetBtn = 'show';
						$scope.hideSecondAddToExcludeSetBtn = 'hide';
						$scope.hideRemoveFromExcludeSetBtn = 'hide';
						
						// get the asr item results
						caseMgmtFactory.getWorkItemsList($scope.restURL, $scope.workItemQueryParam, $scope.infoASRType, $scope.userId).then(function(response) {	
							
							console.log(response);
							
							// change the panel heading to work item
							$scope.summaryHeaderTitle = decodedListNmFilter(response.data.listNm);
						
							// Hide full page LoadingOverlay
							$("#asrPanelBody").LoadingOverlay("hide");
							if(response.data.responseData.length > 0)
							$("#asrMgmtTable").bootstrapTable('load',response.data.responseData);
							if(response.data.responseDataMdcd.length > 0)
							$("#asrMDCDTable").bootstrapTable('load', response.data.responseDataMdcd);
							
							// Show active tab
							if ($scope.infoASRType == "MDCR") {
								$scope.currentASRview = "medicare"
								$scope.showMedicareAsrInfoSummaryTab();
								$('#medicaidAsrInfoSummaryItem').addClass('disabled');
								$('#medicaidAsrInfoSummaryItem').attr('aria-disabled', 'true');
								$('#medicaidAsrInfoSummaryTabLink').css('cursor', 'not-allowed');
								$('#medicaidAsrInfoSummaryTabLink').css('pointer-events', 'none');
								$('#medicaidAsrInfoSummaryTabLink').removeAttr('data-toggle');
								$('#removeFromWorkSetBtnMDCD').css('display', 'none');
							}
							else {
								$scope.currentASRview = "medicaid"
								$scope.showMedicaidAsrInfoSummaryTab();
								$('#medicareAsrInfoSummaryItem').addClass('disabled');
								$('#medicareAsrInfoSummaryItem').attr('aria-disabled', 'true');
								$('#medicareAsrInfoSummaryTabLink').css('cursor', 'not-allowed');
								$('#medicareAsrInfoSummaryTabLink').css('pointer-events', 'none');
								$('#medicareAsrInfoSummaryTabLink').removeAttr('data-toggle');
								$('#removeFromWorkSetBtn').css('display', 'none');
							}
							if (response.data.responseData.length > 0) {
								$("#asrMgmtTable").bootstrapTable('load', response.data.responseData);
								$('#medicareAsrInfoSummaryItem').removeClass('disabled');
								$('#medicareAsrInfoSummaryItem').attr('aria-disabled', 'false');
								$('#medicareAsrInfoSummaryTabLink').css('cursor', 'pointer');
								$('#medicareAsrInfoSummaryTabLink').css('pointer-events', 'auto');
								$('#medicareAsrInfoSummaryTabLink').attr('data-toggle', 'tab');
							}

							if (response.data.responseDataMdcd.length > 0 && !$scope.hideMedicaidTab) {
								$("#asrMDCDTable").bootstrapTable('load', response.data.responseDataMdcd);
								$('#medicaidAsrInfoSummaryItem').removeClass('disabled');
								$('#medicaidAsrInfoSummaryItem').attr('aria-disabled', 'false');
								$('#medicaidAsrInfoSummaryTabLink').css('cursor', 'pointer');
								$('#medicaidAsrInfoSummaryTabLink').css('pointer-events', 'auto');
								$('#medicaidAsrInfoSummaryTabLink').attr('data-toggle', 'tab');
							}

							
							
							$scope.workItemGroupId = response.data.shareGrpId;		
							
							//broadcast this event to the broadcastSlaMetrics listener
							$rootScope.$broadcast('broadcastSlaMetrics', {message:"Case Mgmt Load - End: " + $scope.loadPageUniqueId, userId: ""});		
						}).
						catch(function(err){    			
							console.log("Get Work Items List REST Error: " + err.status);
							//$("#asrMgmtTable").bootstrapTable('hideLoading');
							
							// Hide full page LoadingOverlay
							$("#asrPanelBody").LoadingOverlay("hide");
							
							showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> List load failed due to ' + err.status, 'danger');
						});
					}
				}
	
			}).catch(function(err) {
				//hide the overlay spinner
				$.LoadingOverlay("hide");
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load web services URL due to ' + err.data + ' error.', 'danger');		
			});	

		} else {
			// You're not logged in, you need a sessionToken
			authClient.token.getWithRedirect({
				responseType: ['token', 'id_token']
			});
		} 	
	}
	

	//Show search tabs
	$scope.showMedicaidAsrInfoSearchTab = function() {
		
		console.log('show medicaid search tab');
		//$scope.resetASRSearch(false);
		$('#medicaidAsrInfoSearchTabLink').tab('show');
		$scope.currentASRview = "medicaid";
		
		$scope.tableCols = "sumTableColsMDCD";
	}

	$scope.showMedicareAsrInfoSearchTab = function() {
		
		
		console.log('show medicare search tab');
		//$scope.resetASRSearch(false);
		$('#medicareAsrInfoSearchTabLink').tab('show');
		$scope.currentASRview = "medicare";
		
		$scope.tableCols = "sumTableCols";
		
	}
	// Show summary tabs
	
	$scope.showMedicaidAsrInfoSummaryTab = function() {
		$scope.activeASRTab = 'medicaid';
		
		$("#medicaidAsrInfoSummaryTabLink").LoadingOverlay("show");
		console.log('show medicaid summary tab');
		$('#medicaidAsrInfoSummaryTabLink').tab('show');
		$scope.hideWorkingSetButtons = 'hide';
		$scope.hideMDCDWorkingSetButtons = 'show;'
		$("#medicaidAsrInfoSummaryTabLink").LoadingOverlay("hide");
		$scope.currentASRview = 'medicaid';
		console.log($scope.currentASRview);
		if($rootScope.mdcdPrrtyEnabledInd == 'N'){
			$('#prioritizeUCMBtn').attr('disabled', true);	
		}
		else{
			$('#prioritizeUCMBtn').removeAttr('disabled');
		}
		
		$scope.tableCols = "sumTableColsMDCD";
			
		caseMgmtFactory.getAddToExistInputValsMdcd($scope.restURL, $scope.userId).then(function(response) {
			if(response.data.length > 0){
				$scope.disableAddtoExistingWS = 'show';
			}
		}).
		catch(function(err){    			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load list values due to ' + err.status, 'danger');
		});


		
		
	}

	$scope.showMedicareAsrInfoSummaryTab = function() {
		
		$scope.activeASRTab = 'medicare';
		$("#medicareAsrInfoSummaryTabLink").LoadingOverlay("show");		
		console.log('show medicare summary tab');
		$('#medicareAsrInfoSummaryTabLink').tab('show');
		$scope.hideWorkingSetButtons = 'show';
		$scope.hideMDCDWorkingSetButtons = 'hide';
		$("#medicareAsrInfoSummaryTabLink").LoadingOverlay("hide");
		$scope.currentASRview = 'medicare';
		console.log($scope.currentASRview)
		$('#prioritizeUCMBtn').removeAttr('disabled');
		
		$scope.tableCols = "sumTableCols";

		caseMgmtFactory.getAddToExistInputVals($scope.restURL, $scope.userId).then(function(response) {
			if(response.data.length > 0){
				$scope.disableAddtoExistingWSMDCR = 'show';
			}
		}).
		catch(function(err){    			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load list values due to ' + err.status, 'danger');
		});
		
	}

	$scope.showMedicaidAlertedTotalPayment = function(pRow, pVal, pEditType) {
		console.log("Show TotalPayment popup");
		console.log("pRow - ",pRow);
		console.log("asrDbid - ",pRow.asrDbid);
		
		$("#totalPaymentMDCDTable").bootstrapTable();
		// show the Medicaid Total payment popup
		$("#totalPaymentMDCDModal").modal("show");
		
		
		// show body overlay
		$("#totalPaymentMDCDModal").LoadingOverlay("show");
		
		caseMgmtFactory.mdcdTotalPayment($scope.restURL, pRow.asrDbid , $scope.userId).then(function(response) {
			var totalPayment = response.data.responseData.mdcdTotalPayments;
			console.log("Inside mdcdTotalPayment", totalPayment);
			
			$("#totalPaymentMDCDTable").bootstrapTable('load', totalPayment);
			// show body overlay
			$("#totalPaymentMDCDModal").LoadingOverlay("hide");
			
			
		}).catch(function(err){ 
			// hide body overlay
			$("#totalPaymentMDCDModal").LoadingOverlay("hide");
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Medicaid Alerted Total Payment component data could not be loaded due to ' + err.status, 'danger');
		});
		
		
		
		
	}

	$scope.showviewEnrollmentLink = function(pRow, pVal, pEditType){
			//display the modal window
			$("#medicaidEnrollmentIdModal").modal("show");
			$("#medicaidEnrollmentIdModal").LoadingOverlay("show");
			detailsFactory.getASRDetailsData($scope.restURL, pRow.asrId, "init", $scope.userId, "medicaid")
			.success(function(data) {
			$scope.responseData = data.responseData;
			//populate theProviderPane 
			$scope.providerPaneObj = $scope.responseData.provider;
			//initiate the modal table
			$("#medicaidEnrollmentIdModal").LoadingOverlay("hide");
			$("#medicaidEnrollmentIdModalTable").bootstrapTable({});
			$("#medicaidEnrollmentIdModalTable").bootstrapTable('load', $scope.providerPaneObj.mdcdEnrollmentIds);
			});
			
	}

	$scope.showviewBillingNPILink = function(pRow, pVal, pEditType){
		//display the modal window
		$("#medicareViewBillingNPIModal").modal("show");
		$("#medicareViewBillingNPIModal").LoadingOverlay("show");
		detailsFactory.getASRDetailsData($scope.restURL, pRow.asrId, "BILLSUMM", $scope.userId, "medicare")
		.success(function(data) {
		var billingNPIList = data.responseData.billSummary;
		//populate theProviderPane 
		// $scope.providerPaneObj = $scope.responseData.provider;
		//initiate the modal table
		$("#medicareViewBillingNPIModal").LoadingOverlay("hide");
		$("#medicareViewBillingNPIModalTable").bootstrapTable({});
		$("#medicareViewBillingNPIModalTable").bootstrapTable('load', billingNPIList);
		});
	}

		$scope.p1AsrCostPopup = function(pRow, pVal, pEditType){
			//display the modal window
			$("#p1AsrCostPopup").modal("show");
			$("#p1AsrCostPopup").LoadingOverlay("show");
			detailsFactory.getTabp1TotalZnCostData($scope.restURL, pRow.asrId, $scope.userId, "medicare")
			.success(function(data) {
			$("#p1AsrCostPopup").LoadingOverlay("hide");
			$("#p1AsrCostPopuplTable").bootstrapTable({});
			$("#p1AsrCostPopuplTable").bootstrapTable('load',  data.responseData.p1TotalCostZones);
			});
		
	}

	// user wants to edit exclusion category or comments
	$scope.showExDetailsEdit = function(pRow, pVal, pEditType) {
		console.log('Inside showExDetailsEdit. Edit Type = ' + pEditType);
		
		// show body overlay
		$("#exclusionDetailModalBody").LoadingOverlay("show");
		
		// capture the info from the row that was submitted
		$scope.exListId = pRow.itemId;
		$scope.exComments = pRow.comments;
		$scope.exCategoriesSelect = [];
		$scope.exCategoriesReq = [];
						
		// call the refdata service to get all of the category codes
		caseMgmtFactory.getAllAlerts($scope.restURL, $scope.userId).then(function(response) {
			var respExCatArray = response.data.exclusionCategories;			
			
			// build the category arrays needed for the select component and edit request
			for (i = 0; i < respExCatArray.length; i++) {				
				for (t = 0; t < pRow.exclusions.length; t++) {
					if (respExCatArray[i].value == pRow.exclusions[t].code) {
						// populate array for populating select component
						$scope.exCategoriesSelect.push(respExCatArray[i].key);
						
						// populute array for request
						var asrExclusionObj = {};
						asrExclusionObj.code = respExCatArray[i].key;
						$scope.exCategoriesReq.push(asrExclusionObj);
					}
				}
			}
			
			console.log("exCategoriesSelect = " + JSON.stringify($scope.exCategoriesSelect));
			console.log("exCategoriesReq = " + JSON.stringify($scope.exCategoriesReq));
			
			if (pEditType == 'comments') {
				// user is editing comments
				
				// hide body overlay
				$("#exclusionDetailModalBody").LoadingOverlay("hide");
				
				// show the edit popup window
				$("#editExCommentsModal").modal("show");
				
				// populate the text area with the text
				$scope.editExComments = $scope.exComments;				
				
				//apply the scope ng-binding changes to the display
				//$scope.$apply();	
				
			} else if (pEditType == 'category') {
				// user is editing categories
				// hide body overlay
				$("#exclusionDetailModalBody").LoadingOverlay("hide");
				
				// show the edit popup window
				$("#editExCategoryModal").modal("show");
				
				// select the existing values in the component
				$("#editExCategorySelect").val($scope.exCategoriesSelect);
				
				//apply the scope ng-binding changes to the display
				//$scope.$apply(); 
			}
		}).catch(function(err){ 
			// hide body overlay
			$("#exclusionDetailModalBody").LoadingOverlay("hide");
						
		//	showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Alerts search component data could not be loaded due to ' + err.status, 'danger');
		});
	}

	// user is submitting a exclusion list edit
	$scope.editExclusionSubBtn =  function(pSubType) {
		console.log("Inside editExclusionSubBtn. pSubType = " + pSubType);
		
		var allowUpdate = true;
		
		if (pSubType == 'category') {
			// show button overlay
			$("#editCategorySubBtn").LoadingOverlay("show");
			
			// process the updated values
			var exclusions2ArrObj = [];
			for (i = 0; i < $scope.editExCategorySelect.length; i++) {
				
				console.log('exclusion code = ' + $scope.editExCategorySelect[i]);
				
				var asrExclusionObj = {};
				asrExclusionObj.code = $scope.editExCategorySelect[i];
				exclusions2ArrObj.push(asrExclusionObj);
			}
			
			// update the request array for categories
			$scope.exCategoriesReq = exclusions2ArrObj;
			
			// validate comments for ROI and Other categories
			if (($scope.editExCategorySelect.includes('LOW ROI') || $scope.editExCategorySelect.includes('OTHER')) && ($scope.exComments.trim() == '' || $scope.exComments.trim() == 'N/A')) {
				allowUpdate = false;
			} else {
				allowUpdate = true;
			}
			
		} else if (pSubType == 'comments') {
			// show the button overlay
			$("#editCommentsSubBtn").LoadingOverlay("show");
			
			// update the comments scope variable
			$scope.exComments = $scope.editExComments;	
			
			// validate comments for ROI and Other categories
			if (($scope.exCategoriesSelect.includes('LOW ROI') || $scope.exCategoriesSelect.includes('OTHER')) && ($scope.exComments.trim() == '' || $scope.exComments.trim() == 'N/A')) {
				allowUpdate = false;
			} else {
				allowUpdate = true;
			}	 
		}
		
		// if comments validation = true and comments are empty, stop update
		console.log('select values = ' + $scope.editExCategorySelect);
		
		// if user clicks comments first, then validate from alert response
		console.log('select alert values = ' + $scope.exCategoriesSelect);
 		
		if (!allowUpdate) {
			console.log('Low ROI and/or Other category + no comments');
			
			// show message indicating that comments are required
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Comments are required for the "The Low Billing and Low Probability for Cost Avoidance" and "Other" categories.' 
					+ ' Please add comments before updating.', 'danger');
			
			// hide the button overlay
			$("#editCategorySubBtn").LoadingOverlay("hide");
			$("#editCommentsSubBtn").LoadingOverlay("hide");
			
			
		} else {
			console.log('Low ROI and/or Other category + comments');
			
			// call the web service to update the categories
			caseMgmtFactory.updateExclusionVals($scope.restURL, $scope.userId, $scope.exListId, $scope.exComments , $scope.exCategoriesReq).success(function(data) {
				
				// hide the button overlay
				$("#editCategorySubBtn").LoadingOverlay("hide");
				$("#editCommentsSubBtn").LoadingOverlay("hide");
				
				// close the edit popup window
				$("#editExCategoryModal").modal("hide");
				$("#editExCommentsModal").modal("hide");
				
				// close the exclusion detail window
				$("#exclusionDetailModal").modal("hide");			
				
				// show successful growl message
				showGrowl('<i class=\'fa fa-info-circle\' aria-hidden=\'true\'></i> Exclusion values successfully updated.', 'info');
			}).catch(function(err) {
				console.log('updateExclusionCategories REST Error:' + err.data);
				
				// hide the button overlay
				$("#editCategorySubBtn").LoadingOverlay("hide");
				$("#editCommentsSubBtn").LoadingOverlay("hide");

				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to update values due to ' + err.data + ' error.', 'danger');		
			}); 
		}
		
		
	}

	// show the exclusion list details popup window
	$scope.showExclusionDetails = function(pAsrId) {
		console.log('Inside showExclusionDetails function. pAsrId = ' + pAsrId);
		
		// display the modal window
		$("#exclusionDetailModal").modal("show");
		
		// show the panel overlay
		$("#exclusionDetailModalBody").LoadingOverlay("show");
		
		// initialize exclusion table
		$("#exclusionDetailTable").bootstrapTable('destroy');
		$("#exclusionDetailTable").bootstrapTable({});
		
		// call the web serivce to load the exclusion details
		caseMgmtFactory.getExclusionDetailData($scope.restURL, $scope.userId, pAsrId).success(function(data) {
			// populate the exclusion detail table with data
			$("#exclusionDetailTable").bootstrapTable('load', data.exclusions);
			
			// hide the panel overlay
			$("#exclusionDetailModalBody").LoadingOverlay("hide");
		}).catch(function(err) {
			console.log('getExclusionDetailData REST Error:' + err.data);
			
			// hide the panel overlay
			$("#exclusionDetailModalBody").LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load exclusion details due to ' + err.data + ' error.', 'danger');		
		});
	}

	// user is submitting the form from the share with users modal
	$scope.shareModalSubmit = function() {
		console.log("Inside the shareModalSubmit function.");
		
		if ($scope.shareWorkSetForm.$invalid) {
			// process response
			console.log('Invalid - Don\'t process.');
		} else {
			// show modal body overlay
			$("#shareWorkItemModalBody").LoadingOverlay("show");
			
			// process response
			console.log('Valid - Process. ' + JSON.stringify($scope.shareUsersSelect));
			
			// create an array of the share group user ids
			var shareGroupArr = [];
			
			for (i=0; i < $scope.shareUsersSelect.length; i++) {
				shareGroupArr.push($scope.shareUsersSelect[i].userId);
			}
			
			// call the web service to share the work item
			caseMgmtFactory.shareToGroup($scope.restURL, $scope.userId, $scope.workItemGroupId, shareGroupArr, $scope.workItemQueryParam, $scope.shareUsersNotes).success(function(data) {
				
				// hide modal body overlay
				$("#shareWorkItemModalBody").LoadingOverlay("hide");
				
				// hide the share modal		
				$("#shareWorkItemModal").modal("hide");	
				
				//show growl success message
				showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i>  List successfully shared.', 'success');
				
			}).catch(function(err) {
				console.log('shareToGroup REST Error:' + err.data);
				// hide modal body overlay
				$("#shareWorkItemModalBody").LoadingOverlay("hide");
				
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load shareable users due to ' + err.data + ' error.', 'danger');		
			});
		}
	}

	$scope.getSearchComponentVals = function(pSearchType) {
		
		// show the overlay for the custom search modal body
		$("#searchModalBody").LoadingOverlay("show", {
			"zIndex": 1200
		}); 
		
		caseMgmtFactory.getAllAlerts($scope.restURL, $scope.userId).then(function(response) {
			// use the list to populate the Rulings dropdown
			$scope.refData = response.data;
			$scope.refData.p1Models.unshift({
				modelId: 'all',
				modelName: 'All',
				lookback: 'all'
			  });
			$scope.p1Models = $scope.refData.p1Models;
			
			console.log("RefData",$scope.refData);

			$scope.phase1jusrsdiction = [ {zoneCd: 'UPIC 3', zoneDesc: 'UPIC W'},
				{zoneCd: 'UPIC 4', zoneDesc: 'UPIC SW'}, 
				{zoneCd: 'UPIC 5', zoneDesc: 'UPIC SE'}, 
				{zoneCd: 'UPIC 2', zoneDesc: 'UPIC NE'},
				{zoneCd: 'UPIC 1', zoneDesc: 'UPIC MW'}
				]
			
			var mdcdZoneNoMacs = $scope.refData.zoneNoMacs;
			$scope.mdcdZoneNoMacs = [];
			
			//onsole.log("mdcdZoneNoMacs lenght", mdcdZoneNoMacs.length);
			for (i=0; i < mdcdZoneNoMacs.length; i++) {
				//console.log("indexOf ->", mdcdZoneNoMacs[i]);
				
				if (mdcdZoneNoMacs[i].zoneCd.indexOf('UPIC') != -1){
					var zoneObj = {};
					zoneObj.zoneCd = mdcdZoneNoMacs[i].zoneCd;
					zoneObj.zoneDesc = mdcdZoneNoMacs[i].zoneDesc;
					$scope.mdcdZoneNoMacs.push(zoneObj);
				}
				
			}
			console.log("mdcdZoneNoMacs length", $scope.mdcdZoneNoMacs);
			
			
			if (pSearchType == 'editSearch') {
				
				// call the web service to get the saved search criteria
				console.log('Calling web service to get saved search criteria...');
				
				caseMgmtFactory.getEditSearchCriteria($scope.restURL, $scope.workItemQueryParam, $scope.userId).then(function(response) {
					// parse the prefJson in the response into a JSON object
					const preJsonObj = JSON.parse(response.data.prefJson);
					
					console.log('loggedInUserId from prefJson = ' + preJsonObj.loggedInUserId);
					
					// populate the ASR ID field					
					if (preJsonObj.asrptIds != null) {
						console.log('asrptId array length = ' + preJsonObj.asrptIds.length);
						$scope.searchAsrId = preJsonObj.asrptIds.join('\n');
					} else {
						$scope.searchAsrId = null;
					}
					
					// populate the ASR ID field					
					if (preJsonObj.billingNpis != null) {
						console.log('Billing NPI array length = ' + preJsonObj.billingNpis.length);
						$scope.searchBillingNPIs = preJsonObj.billingNpis.join('\n');
					} else {
						$scope.searchBillingNPIs = null;
					}	
					
					
					// populate the ASR Part D Reports drop down
					if (preJsonObj.partDInd != null) {
						$scope.searchAsrPartD = preJsonObj.partDInd;
					}
										
					// populate provider name
					if (preJsonObj.prvdrName != null) {
						$scope.searchPrvdrName = preJsonObj.prvdrName;
					}
										
					// populate enrollment id
					if (preJsonObj.enrollmentId != null) {
						$scope.searchEnrollId = preJsonObj.enrollmentId;
					}
					
					// populate enrollment status
					if (preJsonObj.enrollStatus != null) {
						$scope.searchEnrollStatus = preJsonObj.enrollStatus;
					}
										
					// populate provider practice state
					if (preJsonObj.states != null) {
						$scope.searchPrvdrPractState = preJsonObj.states;
					}					
					
					// populate ASR specialties
					// convert "key" objects to "code" objects
					if (preJsonObj.specialtyCds != null) {
						var specialtyArr = [];
						
						for (i=0; i < preJsonObj.specialtyCds.length; i++) {
							var specialtyObj = {};
							specialtyObj.key = preJsonObj.specialtyCds[i].code;
							specialtyArr.push(specialtyObj);
						}
						$scope.searchPrvdrAsrSpecial = specialtyArr;
					}					
					
					// populate last date of education - start and stop
					if (preJsonObj.lastEduDtLow != null) {
						$scope.searchLastEduDtMin = preJsonObj.lastEduDtLow;
					}
					
					if (preJsonObj.lastEduDtHigh != null) {
						$scope.searchLastEduDtMax = preJsonObj.lastEduDtHigh;
					}
					
					// populate risk score - min and max
					if (preJsonObj.riskScoreLow != null) {
						$scope.searchRiskScoreMin = preJsonObj.riskScoreLow;
					}
					
					if (preJsonObj.riskScoreHigh != null) {
						$scope.searchRiskScoreMax = preJsonObj.riskScoreHigh;
					}
					
					// populate the priority score - min and max
					if (preJsonObj.priorityScoreLow != null) {
						$scope.searchPriorityScoreMin = preJsonObj.priorityScoreLow;
					}
					
					if (preJsonObj.priorityScoreHigh != null) {
						$scope.searchPriorityScoreMax = preJsonObj.priorityScoreHigh;
					}
					
					// populate timeliness - min and max
					if (preJsonObj.timelinessLow != null) {
						$scope.searchTimelinessDtMin = preJsonObj.timelinessLow;
					}
					
					if (preJsonObj.timelinessHigh != null) {
						$scope.searchTimelinessDtMax = preJsonObj.timelinessHigh;
					}
					
					// populate actionability
					if (preJsonObj.actionability != null) {
						// convert json array to regular array
						var actnabilityArr = [];
						
						for (i=0; i < preJsonObj.actionability.length; i++) {
							actnabilityArr.push(preJsonObj.actionability[i].code);
						}
						
						$scope.searchActionability = actnabilityArr;
					}					
					
					// populate criminal 
					if (preJsonObj.apsInd != null) {
						$scope.searchCriminal = preJsonObj.apsInd;
					}					
					
					// populate the Dual Eligible Bene
					if (preJsonObj.dualBeneInd != null) {
						$scope.searchDualBeneInd = preJsonObj.dualBeneInd;
					}
					
					// populate jurisdiction
					if (preJsonObj.jurisdictions != null) {
						// convert code to zonecd 
						var zoneCdArr = [];
						
						for (i=0; i < preJsonObj.jurisdictions.length; i++) {
							
							var zoneObj = {};
							zoneObj.zoneCd = preJsonObj.jurisdictions[i].code;
							zoneCdArr.push(zoneObj);
							
						}
						
						$scope.searchJurisdiction = zoneCdArr;
					}
					
					// populate phase 1 jurisdiction
					if (preJsonObj.p1Jurisdictions != null) {
						// convert code to zonecd 
						var zoneCdArr = [];
						
						for (i=0; i < preJsonObj.p1Jurisdictions.length; i++) {
							
							var zoneObj = {};
							zoneObj.zoneCd = preJsonObj.p1Jurisdictions[i].code;
							zoneCdArr.push(zoneObj);
							
						}
						
						$scope.searchphase1Jurisdiction = zoneCdArr;
					}
					

					// populate asr create date - min and max
					if (preJsonObj.createdMinDt != null) {
						$scope.searchAsrCreateDtMin = preJsonObj.createdMinDt;
					}
					
					if (preJsonObj.createdMaxDt != null) {
						$scope.searchAsrCreateDtMax = preJsonObj.createdMaxDt;
					}

					// populate asr create date - min and max
					if (preJsonObj.createdMinDt != null) {
						$scope.searchMdcrAsrCreateDtMin = preJsonObj.createdMinDt;
					}
					
					if (preJsonObj.createdMaxDt != null) {
						$scope.searchMdcrAsrCreateDtMax = preJsonObj.createdMaxDt;
					}

					
					
					// populate last date of tpe education - min and max
					if (preJsonObj.lastTpeEduDtLow != null) {
						$scope.searchTpeLastEduDtMin = preJsonObj.lastTpeEduDtLow;
					}
					
					if (preJsonObj.lastTpeEduDtHigh != null) {
						$scope.searchTpeLastEduDtMax = preJsonObj.lastTpeEduDtHigh;
					}
					
					// populate total BIU complaints
					if (preJsonObj.biuCnt != null) {
						$scope.searchBiuComplaints = preJsonObj.biuCnt;
					}
					
					if (preJsonObj.biuDays != null) {
						$scope.searchBiuComplaintDays = preJsonObj.biuDays;
					}
					
					// populate alert models
					if (preJsonObj.alerts != null) {
						// convert alertId to modelId
						var modelArr = [];
						
						for (i=0; i < preJsonObj.alerts.length; i++) {
							var modelObj = {};
							
							modelObj.modelId = preJsonObj.alerts[i].alertId;
							modelArr.push(modelObj);
						}
						
						$scope.searchAlrtModName = modelArr;
					}

					// populate phase 1 alert models
					if (preJsonObj.p1Alerts != null) {
						// convert alertId to modelId
						var modelArr = [];
						
						for (i=0; i < preJsonObj.p1Alerts.length; i++) {
							var modelObj = {};
							
							modelObj.modelId = preJsonObj.p1Alerts[i].alertId;
							modelArr.push(modelObj);
						}
						
						$scope.searchphase1AlrtModName = modelArr;
					}
					
					// populate alert status
					if (preJsonObj.alertStatus != null) {
						// convert code to flat array
						var alertStatArr = [];
						
						for (i=0; i < preJsonObj.alertStatus.length; i++) {
							alertStatArr.push(preJsonObj.alertStatus[i].code);
						}
						
						$scope.searchAlertStatus = alertStatArr;
					}

					// populate phase 1 alert status
					if (preJsonObj.p1AlertStatus != null) {
						// convert code to flat array
						var alertStatArr = [];
						
						for (i=0; i < preJsonObj.p1AlertStatus.length; i++) {
							alertStatArr.push(preJsonObj.p1AlertStatus[i].code);
						}
						
						$scope.searchphase1AlertStatus = alertStatArr;
					}
					
					// populate ruling
					if (preJsonObj.rulings != null) {
						$scope.searchRuling = preJsonObj.rulings;
					}					
					
					// populate asr cost - min and max
					if (preJsonObj.asrCostLow != null) {
						$scope.searchAsrCostMin = preJsonObj.asrCostLow;
					}
					
					if (preJsonObj.asrCostHigh != null) {
						$scope.searchAsrCostMax = preJsonObj.asrCostHigh;
					}


					// populate phase 1 asr cost - min and max
					if (preJsonObj.p1AsrCostLow != null) {
						$scope.searchphase1AsrCostMin = preJsonObj.p1AsrCostLow;
					}
					
					if (preJsonObj.p1AsrCostHigh != null) {
						$scope.searchphase1AsrCostMax = preJsonObj.p1AsrCostHigh;
					}
					
					// populate claim date of service - min and max
					if (preJsonObj.lastAlertSvcDtLow != null) {
						$scope.searchLastAlertClmDtMin = preJsonObj.lastAlertSvcDtLow;
					}
					// populate path to education
					if (preJsonObj.pathToEduInd != null) {
						$scope.searchPathToEduInd = preJsonObj.pathToEduInd;
					}
					
					// populate aco ind
					if (preJsonObj.acoInd != null) {
						$scope.searchAcoInd = preJsonObj.acoInd;
					}
					if (preJsonObj.lastAlertSvcDtHigh != null) {
						$scope.searchLastAlertClmDtMax = preJsonObj.lastAlertSvcDtHigh;
					}

					// populate Phase 1 claim date of service - min and max
					if (preJsonObj.p1LastAlertSvcDtLow != null) {
						$scope.searchLastphase1AlertClmDtMin = preJsonObj.p1LastAlertSvcDtLow;
					}

					if (preJsonObj.p1LastAlertSvcDtHigh != null) {
						$scope.searchLastphase1AlertClmDtMax = preJsonObj.p1LastAlertSvcDtHigh;
					}
					
					// populated last claim submitted date - min and max
					if (preJsonObj.lastClmDtLow != null) {
						$scope.searchClmSbtDtMin = preJsonObj.lastClmDtLow;
					}
					
					if (preJsonObj.lastClmDtHigh != null) {
						$scope.searchClmSbtDtMax = preJsonObj.lastClmDtHigh ;
					}
					
					// populate submitted amount - min and max
					if (preJsonObj.sbmtAmtLow != null) {
						$scope.searchSubmittedAmtMin = preJsonObj.sbmtAmtLow;
					}
					
					if (preJsonObj.sbmtAmtHigh != null) {
						$scope.searchSubmittedAmtMax = preJsonObj.sbmtAmtHigh;
					}
					
					// populate total amount - max and min
					if (preJsonObj.totalPymtLow != null) {
						$scope.searchTotalPayMin = preJsonObj.totalPymtLow;
					}
					
					if (preJsonObj.totalPymtHigh != null) {
						$scope.searchTotalPayMax = preJsonObj.totalPymtHigh;
					}
					
					// populate submitted amount part d - min and max
					if (preJsonObj.sbmtAmtDLow != null) {
						$scope.searchSubmittedAmtDMin = preJsonObj.sbmtAmtDLow;
					}
					
					if (preJsonObj.sbmtAmtDHigh != null) {
						$scope.searchSubmittedAmtDMax = preJsonObj.sbmtAmtDHigh;
					}
					
					// populate Total Payment Part D - min and max
					if (preJsonObj.totalPymtDLow != null) {
						$scope.searchTtlPayPartDMin = preJsonObj.totalPymtDLow;
					}
					
					if (preJsonObj.totalPymtDHigh != null) {
						$scope.searchTtlPayPartDMax = preJsonObj.totalPymtDHigh;
					}
					
					
					// populate asr claim type
					// convert claimTypeCd to flat array
					if (preJsonObj.claimTypes != null) {
						// convert code to flat array
						var claimTypesArr = [];
						
						for (i=0; i < preJsonObj.claimTypes.length; i++) {
							claimTypesArr.push(preJsonObj.claimTypes[i].claimTypeCd);
						}
						
						$scope.searchClaimType = claimTypesArr;
					}
										
					// populate leads/investigations
					// convert the code object to a flat array
					if (preJsonObj.leadInvestigationInd != null) {
						// convert code to flat array
						var leadsArr = [];
						
						for (i=0; i < preJsonObj.leadInvestigationInd.length; i++) {
							leadsArr.push(preJsonObj.leadInvestigationInd[i].code);
						}
						
						$scope.searchLeadInvStatus = leadsArr;
					}
					
					
					// populate results in my jurisdiction only
					//convert yes/no to true false
					if (preJsonObj.myZoneOnlyInd != null) {
						if (preJsonObj.myZoneOnlyInd == "Yes") {
							$scope.searcMyZoneOnlyInd = true;
						} else {
							$scope.searcMyZoneOnlyInd = false;
						}
					}
					
					// populate Prioritize for UCM 
					// convert code to key object in array
					if (preJsonObj.prioritizeTypes != null) {
						var priorArr = [];
						
						for (i=0; i < preJsonObj.prioritizeTypes.length; i++) {
							priorObj = {};
							priorObj.key = preJsonObj.prioritizeTypes[i].code;
							
							priorArr.push(priorObj);
						}
						
						$scope.searchPriorUcm =priorArr;
					}
					
					// populate lead indicator
					if (preJsonObj.leadInd != null) {
						$scope.searchLeadInd = preJsonObj.leadInd;
					}
					
					// populate zone restriction
					if (preJsonObj.zrTypes != null) {
						// convert the code object in the array to a flat array
						var zrArr = [];
						
						for (i=0; i < preJsonObj.zrTypes.length; i++) {
							zrArr.push(preJsonObj.zrTypes[i].code);
						}
						
						$scope.searchZoneRestriction = zrArr;
					}
					
					// populate UCM ASR ID
					if (preJsonObj.ucmAsrId != null) {
						$scope.searchUcmAsrId = preJsonObj.ucmAsrId;
					}
					
					// populate UCM Case ID
					if (preJsonObj.ucmCaseId != null) {
						$scope.searchUcmCaseId = preJsonObj.ucmCaseId;
					}
					
					// populate Edit Name
					if (preJsonObj.edits != null) {
						$scope.searchEditName =preJsonObj.edits;
					}
					
					// populate edit id
					if (preJsonObj.editId != null) {
						$scope.searchEditId = preJsonObj.editId;
					}
					
					// populate ASRs in a Working Set
					if (preJsonObj.asrWorkingSetInd != null) {
						// convert code object to flat object
						var asrWorkSetArr = [];
						
						for (i=0; i < preJsonObj.asrWorkingSetInd.length; i++) {
							asrWorkSetArr.push(preJsonObj.asrWorkingSetInd[i].code);
						}
						
						$scope.searchAsrInWorkSet = asrWorkSetArr;
					}
					
					// populate ASRs in an Exclusion Set
					if (preJsonObj.asrExclSetInd != null) {
						// convert code object to flat object
						var asrExSetArr = [];
						
						for (i=0; i < preJsonObj.asrExclSetInd.length; i++) {
							asrExSetArr.push(preJsonObj.asrExclSetInd[i].code);
						}
						
						$scope.searchAsrInExSet = asrExSetArr;
					}
					
					// populate exclusions
					if (preJsonObj.exclusions != null) {
						// convert code to key
						var exclusionSetArr = [];
						

						for (i=0; i < preJsonObj.exclusions.length; i++) {
							
							// create object
							var exclusionObj = {};
							exclusionObj.key = preJsonObj.exclusions[i].code;
							
							exclusionSetArr.push(exclusionObj);
						}
						
						$scope.searchExclusions = exclusionSetArr;
						
					}
					
					// populate exclusion indicator
					if (preJsonObj.exclusionOrInd != null) {
						$scope.searchExclusionsInd = preJsonObj.exclusionOrInd;
					}
					
										
					// hide the overlay for the custom search modal body
					$("#searchModalBody").LoadingOverlay("hide"); 
				}).
	    		catch(function(err){    			
	    			console.log("Get Saved Search Criteria REST Error: " + err.status);
	    						    			
	    			// hide the overlay for the custom search modal body
	    			$("#searchModalBody").LoadingOverlay("hide");
	    			
	    			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i>Saved Search criteria failed to load due to ' + err.status, 'danger');
	    		});
			} else {
				// hide the overlay for the custom search modal body
				$("#searchModalBody").LoadingOverlay("hide"); 
			}
		}).catch(function(err){ 
			// hide the overlay for the custom search modal body
			$("#searchModalBody").LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Alerts search component data could not be loaded due to ' + err.status, 'danger');
		});
	}

	// function fro removing from exclusion set
	$scope.removeFromExSetBtnClick = function() {
		console.log('Inside removeFromExSetBtnClick');
		
		// get the items selected 		
		$scope.removeItemsSelected = $('#asrMgmtTable').bootstrapTable('getSelections');
		$scope.numItemsRemoved = $('#asrMgmtTable').bootstrapTable('getSelections').length;
		
		if ($scope.numItemsRemoved > 0){
			// show the warning modal 
			$("#deleteExSetModal").modal("show");
		} else {
			// show growl window with error message
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i>Please select ASR(s) to remove from the existing list.', 'danger');
		}
	}


	// function for removing from working set in Medicare
	$scope.removeFromWorkSetBtnClick = function() {
		console.log('Inside removeFromWorkSetBtnClick');
		
		// get the items selected 
		//$scope.removeSelections = $scope.searchResultTable.api().rows({selected: true});
		$scope.removeItemsSelected = $('#asrMgmtTable').bootstrapTable('getSelections');
		$scope.numItemsRemoved = $('#asrMgmtTable').bootstrapTable('getSelections').length;
		
		if ($scope.numItemsRemoved > 0){
			// show the warning modal 
			$("#deleteWorkSetModal").modal("show");
		} else {
			// show growl window with error message
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i>Please select ASR(s) to remove from the existing list.', 'danger');
		}
	}

	// function for removing from working set Medicaid
	$scope.removeFromWorkSetMdcdBtnClick = function() {
		console.log('Inside removeFromWorkSetMdcdBtnClick');
		
		// get the items selected 
		//$scope.removeSelections = $scope.searchResultTable.api().rows({selected: true});
		$scope.removeItemsSelected = $('#asrMDCDTable').bootstrapTable('getSelections');
		$scope.numItemsRemoved = $('#asrMDCDTable').bootstrapTable('getSelections').length;
		
		if ($scope.numItemsRemoved > 0){
			// show the warning modal 
			$("#deleteWorkSetModal").modal("show");
		} else {
			// show growl window with error message
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i>Please select ASR(s) to remove from the existing list.', 'danger');
		}
	}

	// user wants to delete from exclusion set modal
	$scope.deleteFromExSetModal = function() {
		console.log('Inside deleteFromWsModal. Chosen items = ' + $scope.numItemsRemoved.length);
		
		// show button overlay
		$("#delFromExSetBtn").LoadingOverlay("show");
		
		if ($scope.removeItemsSelected.length > 0) {
			var deleteAsrArr = [];
			
			// loop through results, and then build array
			for (i = 0; i < $scope.removeItemsSelected.length; i++) {
				deleteAsrArr.push($scope.removeItemsSelected[i].asrDbid);
			}
			
			// call the delete from list service
			caseMgmtFactory.removeFromExList($scope.restURL, $scope.userId, $scope.workItemQueryParam, deleteAsrArr).then(function(response) {
				// hide button overlay
				$("#delFromExSetBtn").LoadingOverlay("hide");
				
				// hide the popup window
				$("#deleteExSetModal").modal("hide");
				
				// show the asr table overlay
				$("#asrMgmtTable").LoadingOverlay("show");
					
				// clear the data table and then reload with returned data
				$("#asrMgmtTable").bootstrapTable('load',response.data.responseData);	
				
				// hide the asr table overlay
				$("#asrMgmtTable").LoadingOverlay("hide");
				
				//show growl success message
				showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i>  ASRs successfully removed from list.', 'success');
			
			}).
			catch(function(err){    			
				console.log("Remove from Exclusion List REST Error: " + err.status);
				
				// hide button overlay
				$("#delFromExSetBtn").LoadingOverlay("hide");
				
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Remove ASRs failed due to ' + err.status, 'danger');
			});
		}
	}

	// user wants to delete from working set modal
	$scope.deleteFromWsModal = function() {
		console.log('Inside deleteFromWsModal. Chosen items = ' + $scope.removeItemsSelected.length);
		
		if ($scope.removeItemsSelected.length > 0) {
			var deleteAsrArr = [];
			
			// loop through results, and then build array
			for (i = 0; i < $scope.removeItemsSelected.length; i++) {
								
				// create object to add to array
				//var deleteAsrObj = {};
				//deleteAsrObj.asrId = $scope.searchResultTable.api().rows({selected: true }).data()[i].asrDbid;
				
				// add the object to the array
				//deleteAsrArr.push(deleteAsrObj);   
				deleteAsrArr.push($scope.removeItemsSelected[i].asrDbid);
			}
			
			console.log('deleteAsrArr =  ' + JSON.stringify(deleteAsrArr));
			
			// call the delete from list service
			caseMgmtFactory.removeFromList($scope.restURL, $scope.userId, $scope.workItemQueryParam, deleteAsrArr).then(function (response) {
				// show the asr table overlay
				$("#asrMgmtTable").LoadingOverlay("show");

				//show growl success message
				showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i>  ASRs successfully removed from list.', 'success');

				// clear the data table and then reload with returned data
				caseMgmtFactory.getWorkItemsList($scope.restURL, $scope.workItemQueryParam, $scope.infoASRType, $scope.userId).then(function (response) {

					console.log(response);

					// change the panel heading to work item
					$scope.summaryHeaderTitle = decodedListNmFilter(response.data.listNm);

					// Hide full page LoadingOverlay
					$("#asrPanelBody").LoadingOverlay("hide");
					if (response.data.responseData.length > 0)
						$("#asrMgmtTable").bootstrapTable('load', response.data.responseData);
					if (response.data.responseDataMdcd.length > 0)
						$("#asrMDCDTable").bootstrapTable('load', response.data.responseDataMdcd);

					// Show active tab
					if ($scope.infoASRType == "MDCR") {
						$scope.currentASRview = "medicare"
						$scope.showMedicareAsrInfoSummaryTab();
						$('#medicaidAsrInfoSummaryItem').addClass('disabled');
						$('#medicaidAsrInfoSummaryItem').attr('aria-disabled', 'true');
						$('#medicaidAsrInfoSummaryTabLink').css('cursor', 'not-allowed');
						$('#medicaidAsrInfoSummaryTabLink').css('pointer-events', 'none');
						$('#medicaidAsrInfoSummaryTabLink').removeAttr('data-toggle');
					}
					else {
						$scope.currentASRview = "medicaid"
						$scope.showMedicaidAsrInfoSummaryTab();
						$('#medicareAsrInfoSummaryItem').addClass('disabled');
						$('#medicareAsrInfoSummaryItem').attr('aria-disabled', 'true');
						$('#medicareAsrInfoSummaryTabLink').css('cursor', 'not-allowed');
						$('#medicareAsrInfoSummaryTabLink').css('pointer-events', 'none');
						$('#medicareAsrInfoSummaryTabLink').removeAttr('data-toggle');
					}
					if (response.data.responseData.length > 0) {
						$("#asrMgmtTable").bootstrapTable('load', response.data.responseData);
						$('#medicareAsrInfoSummaryItem').removeClass('disabled');
						$('#medicareAsrInfoSummaryItem').attr('aria-disabled', 'false');
						$('#medicareAsrInfoSummaryTabLink').css('cursor', 'pointer');
						$('#medicareAsrInfoSummaryTabLink').css('pointer-events', 'auto');
						$('#medicareAsrInfoSummaryTabLink').attr('data-toggle', 'tab');
					}

					if (response.data.responseDataMdcd.length > 0) {
						$("#asrMDCDTable").bootstrapTable('load', response.data.responseDataMdcd);
						$('#medicaidAsrInfoSummaryItem').removeClass('disabled');
						$('#medicaidAsrInfoSummaryItem').attr('aria-disabled', 'false');
						$('#medicaidAsrInfoSummaryTabLink').css('cursor', 'pointer');
						$('#medicaidAsrInfoSummaryTabLink').css('pointer-events', 'auto');
						$('#medicaidAsrInfoSummaryTabLink').attr('data-toggle', 'tab');
					}


					$scope.workItemGroupId = response.data.shareGrpId;

					//broadcast this event to the broadcastSlaMetrics listener
					$rootScope.$broadcast('broadcastSlaMetrics', { message: "Case Mgmt Load - End: " + $scope.loadPageUniqueId, userId: "" });
				});

				// show the asr table overlay
				$("#asrMgmtTable").LoadingOverlay("hide");
			}).
				catch(function (err) {
					console.log("Remove from List REST Error: " + err.status);

					// Hide modal LoadingOverlay
					//$("#prioritizeUCMModalBody").LoadingOverlay("hide");

					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Remove ASRs failed due to ' + err.status, 'danger');
				});

			// hide the warning modal 
			$("#deleteWorkSetModal").modal("hide");
		} else {
			// show growl window with error message
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i>Please select ASR(s) to remove from the existing list.', 'danger');
		}
	}

	// function for add to working set button click
	$scope.addToWorkSetBtnClick = function() {
		
		// set form to pristine
		$scope.addWsInput = null;
		$scope.addWsInputDesc = null;
		$scope.addToWorkSetForm.$setPristine();
				
		// check to see if user selected items from the table
		$scope.numItemsForNewList = $('#asrMgmtTable').bootstrapTable('getSelections');
		
		if ($scope.numItemsForNewList.length > 0) {
			// show the add to working set modal
			$("#addToWorkSetModal").modal("show");
		} else {
			// display growl message stating now items selected
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Please select ASR(s) to add to the new list.', 'danger');
		}
	}
	// function for add to working set button click for medicaid
	$scope.addToWorkSetBtnClickMdcd = function() {
		
		// set form to pristine
		$scope.addWsInput = null;
		$scope.addWsInputDesc = null;
		$scope.addToWorkSetForm.$setPristine();
				
		// check to see if user selected items from the table
		$scope.numItemsForNewList = $('#asrMDCDTable').bootstrapTable('getSelections');
		
		if ($scope.numItemsForNewList.length > 0) {
			// show the add to working set modal
			$("#addToWorkSetModal").modal("show");
		} else {
			// display growl message stating now items selected
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Please select ASR(s) to add to the new list.', 'danger');
		}
	}

	// function for add to exclusion set button click
	$scope.addToExcludeSetBtnClick = function(pBtnClickType) {
		console.log('Inside addToExcludeSetBtnClick function. pBtnClickType = ' + pBtnClickType);
		
		// set a scope level btn click type variable to be used by the modalSaveExAsrBtnClick method
		$scope.exclusionBtnType = pBtnClickType;
		
		// set the form to pristine
		$scope.excludeWorkSetForm.$setPristine();
		
		// check to see if the user selected items from the table
		$scope.selectedTblItems = $('#asrMgmtTable').bootstrapTable('getSelections');
		
		// confirm the user selected items before clicking the button
		if ($scope.selectedTblItems.length > 0) {
			// show the Exclude ASR modal
			$('#excludeWorkSetModal').modal("show");
			
		} else {
			// display growl message stating now items selected
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Please select ASR(s) to add to the new list.', 'danger');
		}
	}

	$scope.initExAsrTable = function() {
		
		console.log('Initialize the ASR exclusion table.');
		
		// dynamically create an array based on the chosen ASRs
	    var asrExclusionData = [];
	    
	    //loop through the chosen ASRs and create the table
	    for (i = 0; i < $scope.selectedTblItems.length; i++) {
	    	var tempArrObj = {};
	    	
	    	tempArrObj.asrId = $scope.selectedTblItems[i].asrId;
	    	tempArrObj.name = $scope.selectedTblItems[i].name;
	    	tempArrObj.asrDbid = $scope.selectedTblItems[i].asrDbid;
	    	tempArrObj.exCat = '';
	    	tempArrObj.comments = '';
	    	tempArrObj.lastDayExclusion = '';
	    	
	    	asrExclusionData.push(tempArrObj);
	    }
	   
		$("#excludeAsrTable").bootstrapTable('load',asrExclusionData);
		
		// asr exclusion table date picker
		$(".exclusionDatePicker").datepicker({ dateFormat: 'yy-mm-dd', minDate: 0 });

	}

	// process the Exclude ASR table data
	$scope.modalSaveExAsrBtnClick = function() {
		console.log('Inside the modalSaveExAsrBtnClick function.');
		
		// show body overlay
		$("#excludeWorkSetModalBody").LoadingOverlay("show");
		
		$scope.excludeWorkSetForm.$invalid = false;
			
			// create array for search request
			var asrExReqObj = {};
//			var paramsObj = {};	 
			var exclusions1ArrObj = [];
		    
		    // add the Params object to the request
//		    asrExReqObj.Params = paramsObj;
		    
			// if scondary review button was clicked, set add itemId to the request
			if ($scope.exclusionBtnType == 'review') {

				// add the list item id to the request
				asrExReqObj.itemId = $scope.workItemQueryParam;	
			}       
		    
			// get the table data
			var tableData = $("#excludeAsrTable").bootstrapTable('getData');
			console.log('tableData length = ' + tableData.length);
			console.log('tableData data =  ' + JSON.stringify(tableData));
			
			for (i=0; i < tableData.length; i++) {			
				// establish exclusions arrays
				var exclusionsObj = {};			
				var exclusions2ArrObj = [];	    
				
				var rowAsrId = tableData[i].asrId;			
				console.log('asrId = ' + rowAsrId);	
				
				var rowAsrDbid = tableData[i].asrDbid;
				console.log('asrDbid = ' + rowAsrDbid);	
				
				// get the value of the exclusion category field
				var exCatVal = $('#exCatSelect_' + rowAsrId).val();
				console.log('exclusion category value = ' + exCatVal);
				
				if (exCatVal == '') {
					$scope.excludeWorkSetForm.$invalid = true;
					$('#exCatSelect_' + rowAsrId).css('border-color', 'red');
				} else {
					
					$('#exCatSelect_' + rowAsrId).css('border-color', '');
				}
				
				// get the value of the comments field
				var commentsVal = $('#commentsInput_' + rowAsrId).val();
				console.log('comments value = ' + commentsVal);
				
				// get the value of teh last day of exclusion
				var lastDayExVal = $('#lastDayInput_' + rowAsrId).val();
				console.log('last day of exclusion value = ' + lastDayExVal);
				
				// add the required values to the exclusions obj
			    exclusionsObj.asrptId = rowAsrDbid;
			    exclusionsObj.comments = commentsVal;
			    exclusionsObj.rollOffDt = lastDayExVal;
			   
			    if (exCatVal.length > 0) {
			    	
			    	$scope.otherFound=false;
			    	
			    	$.each(exCatVal, function(index, value){
			    		console.log('multi select value # ' + index + ' = ' + value);
			    		
			    		// if value = OTHER or the value = LOW ROI, then invalidate the form and highlight the comments field as required
			    		if (value == "OTHER" || value == "LOW ROI") {
			    			$scope.otherFound=true;
			    		} 
			    		
			    		var codeObj = {};
				    	codeObj.code = value;
				    	exclusions2ArrObj.push(codeObj);
			    	});
			    	
			    	// highlight comments box if other was selected
			    	if ($scope.otherFound && $('#commentsInput_' + rowAsrId).val() == '') {
			    		$scope.excludeWorkSetForm.$invalid = true;
		    			$('#commentsInput_' + rowAsrId).css('border-color', 'red');
			    	} else {
			    		$('#commentsInput_' + rowAsrId).css('border-color', '');
			    	}
			    }		   
			    
			    // create inner exclusions object 
			    exclusionsObj.exclusions = exclusions2ArrObj;
			    
			    //populate outer exclusions object
			    exclusions1ArrObj.push(exclusionsObj);		    
			   
			}
			
			// populate params exclusion object
			asrExReqObj.exclusions = exclusions1ArrObj;
		    
			//console.log(JSON.stringify(asrExReqObj));
		    
			if ($scope.excludeWorkSetForm.$invalid) {
				// process response
				console.log('Invalid form - Don\'t process.');
				
				// hide body overlay
				$("#excludeWorkSetModalBody").LoadingOverlay("hide");
				
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Please enter a valid value for the items highlighted in red.', 'danger');
			} else {
				// process response
				console.log('Valid form - process.');
				
			    // call the web service to add the asrs to the exclusion list
			    caseMgmtFactory.addToExclusionList($scope.restURL, $scope.userId, asrExReqObj).then(function(response) {
			    	// hide body overlay
					$("#excludeWorkSetModalBody").LoadingOverlay("hide");
										
					// only update the table if the user is viewing exclusion list
					if ($scope.exclusionBtnType != 'add') {
			
						$("#asrMgmtTable").bootstrapTable('load',response.data.responseData);
					}					
					
					// close the modal 
					$("#excludeWorkSetModal").modal("hide");
					
					showGrowl('<i class=\'fa fa-info-circle\' aria-hidden=\'true\'></i> Add to Exclusion Set succeeded.', 'info');
			    }).
				catch(function(err){    			
					console.log("Add to Exclusion List REST Error: " + err.status);
					
					// hide body overlay
					$("#excludeWorkSetModalBody").LoadingOverlay("hide");
					
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Add to Exclusion Set failed due to ' + err.status, 'danger');
				});
			}

	}

	// function to add to a new working set from modal
	$scope.modalAddToNewBtnClick = function() {
		
		// dirty the form since it's been submitted
		$scope.addToWorkSetForm.$setDirty();
				
		// check the form validity
		if ($scope.addToWorkSetForm.$invalid) {
			// do not process response
			console.log('Invalid - Don\'t process.');
		} else {
			// process response
			console.log('Valid - Process. ASRs to add to list ' + $scope.numItemsForNewList.length);
									
			// show the overlay 
			$("#saveWorkSetModalBody").LoadingOverlay("show");
			
			// call the service to see if name already exists
			caseMgmtFactory.checkExistListName($scope.restURL, $scope.userId, $scope.addWsInput, "asr").then(function(response) {
				console.log("Check name response list length = " + response.data.length);
				
				// assign the response array to scope variable
				$scope.checkNmArray = response.data;
				
				var processReq = true;
				
				if ($scope.checkNmArray != null && $scope.checkNmArray.length > 0) {
					// loop through the array looking for match
					for (i=0; i < $scope.checkNmArray.length; i ++) {
						if ($scope.checkNmArray[i].listNm.trim() == $scope.addWsInput.trim()) {
							console.log("List already exists.")
							
							// hide the overlay
							$("#saveWorkSetModalBody").LoadingOverlay("hide");
							
							processReq = false;
							
							break;
						} 
					}
				}	
				
				// determine whether to continue processing the request
				if (processReq == true) {
					var newAsrArr = [];
					
					// loop through results, and then build array
					for (i = 0; i < $scope.numItemsForNewList.length; i++) {
						
						// create object to add to array
						var addAsrObj = {};
						addAsrObj.asrptId = $scope.numItemsForNewList[i].asrDbid;
						
						// add the object to the array
						newAsrArr.push(addAsrObj);  
					}
					
					console.log('newAsrArr =  ' + JSON.stringify(newAsrArr));
					
					// call the web service to create the new work item			
					caseMgmtFactory.createNewList($scope.restURL, $scope.userId, $scope.addWsInput, $scope.addWsInputDesc, newAsrArr).then(function(response) {
						// hide the overlay
						$("#saveWorkSetModalBody").LoadingOverlay("hide");
						
						// close the modal window
						$("#addToWorkSetModal").modal("hide");
						
						//show growl success message
						showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i>  ASRs successfully added to list.', 'success');							
						
					}).
					catch(function(err){    			
						console.log("Create List REST Error: " + err.status);

						// hide the overlay
						$("#saveWorkSetModalBody").LoadingOverlay("hide");
						
						showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Create new list failed due to ' + err.status, 'danger');
					});
				} else {
					$("#saveWorkSetModalBody").LoadingOverlay("hide");					

					// show the warning message
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> An item with that name already exists. Please choose another name.', 'danger');
				}
			}).catch(function(err){ 
				//hide full page overlay
				$("#saveWorkSetModalBody").LoadingOverlay("hide");
				
				// show growl message
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to validate list name due to ' + err.status, 'danger');
			});
		}
	}

	// function to add to a new working set from modal for Mediciad
	$scope.mdcdmodalAddToNewBtnClick = function(){

		// dirty the form since it's been submitted
		$scope.addToWorkSetForm.$setDirty();
				
		// check the form validity

		if ($scope.addToWorkSetForm.$invalid) {
			// do not process response
			console.log('Invalid - Don\'t process.');
		} else {
			// process response
			console.log('Valid - Process. ASRs to add to list ' + $scope.numItemsForNewList.length);
									
			// show the overlay 
			$("#saveWorkSetModalBody").LoadingOverlay("show");

			caseMgmtFactory.checkExistListNameMdcd($scope.restURL, $scope.userId, $scope.addWsInput, "asr").then(function(response) {
				console.log("Check name response list length = " + response.data.length);
				
				// assign the response array to scope variable
				$scope.checkNmArray = response.data;
				
				var processReq = true;
				
				if ($scope.checkNmArray != null && $scope.checkNmArray.length > 0) {
					// loop through the array looking for match
					for (i=0; i < $scope.checkNmArray.length; i ++) {
						if ($scope.checkNmArray[i].listNm.trim() == $scope.addWsInput.trim()) {
							console.log("List already exists.")
							
							// hide the overlay
							$("#saveWorkSetModalBody").LoadingOverlay("hide");
							
							processReq = false;
							
							break;
						} 
					}
				}	
				
				// determine whether to continue processing the request
				if (processReq == true) {
					var newAsrArr = [];
					
					// loop through results, and then build array
					for (i = 0; i < $scope.numItemsForNewList.length; i++) {
						
						// create object to add to array
						var addAsrObj = {};
						addAsrObj.asrptId = $scope.numItemsForNewList[i].asrDbid;
						
						// add the object to the array
						newAsrArr.push(addAsrObj);  
					}
					
					console.log('newAsrArr =  ' + JSON.stringify(newAsrArr));
					
					// call the web service to create the new work item			
					caseMgmtFactory.createNewListMdcd($scope.restURL, $scope.userId, $scope.addWsInput, $scope.addWsInputDesc, newAsrArr).then(function(response) {
						// hide the overlay
						$("#saveWorkSetModalBody").LoadingOverlay("hide");
						
						// close the modal window
						$("#addToWorkSetModal").modal("hide");
						
						//show growl success message
						showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i>  ASRs successfully added to list.', 'success');	
						
						// will enable add to exisiting work set button
						$scope.showMedicaidAsrInfoSummaryTab();
						
					}).
					catch(function(err){    			
						console.log("Create List REST Error: " + err.status);

						// hide the overlay
						$("#saveWorkSetModalBody").LoadingOverlay("hide");
						
						showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Create new list failed due to ' + err.status, 'danger');
					});
				} else {
					$("#saveWorkSetModalBody").LoadingOverlay("hide");					

					// show the warning message
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> An item with that name already exists. Please choose another name.', 'danger');
				}
			}).catch(function(err){ 
				//hide full page overlay
				$("#saveWorkSetModalBody").LoadingOverlay("hide");
				
				// show growl message
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to validate list name due to ' + err.status, 'danger');
			});
		}
	}

	// user wants to add ASRs to existing working set
	$scope.addExistWorkSetBtnClick = function() {
		console.log('Inside addExistWorkSetBtnClick');
		
		// show overlay while dropdown values load
		$("#existWorkSetSelect").LoadingOverlay("show");
		
		// set the form to pristine
		$scope.existWorkSetSelect = null;
		$scope.addToExistWorkSetForm.$setPristine();
				
		$scope.addToExistSelections =  $('#asrMgmtTable').bootstrapTable('getSelections');
		console.log('selected count = ' + $scope.addToExistSelections.length);
		
		if ($scope.addToExistSelections.length > 0) {
			// show the addToExistWorkSetModal modal
			$("#addToExistWorkSetModal").modal("show");
			
			// call the web service to get the list of working sets
			caseMgmtFactory.getAddToExistInputVals($scope.restURL, $scope.userId).then(function(response) {
				$scope.addToExistItemsOptions = response.data;
				
				console.log('response = ' + JSON.stringify($scope.addToExistItemsOptions));
				
				// hide overlay after dropdown values load
				$("#existWorkSetSelect").LoadingOverlay("hide");				
				
			}).
			catch(function(err){    			
				console.log("Get Add to Existing List Input Vals REST Error: " + err.status);

				// hide overlay after dropdown values load
				$("#existWorkSetSelect").LoadingOverlay("hide");
				
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load list values due to ' + err.status, 'danger');
			});
		} else {
				// hide overlay after dropdown values load
				$("#existWorkSetSelect").LoadingOverlay("hide");
			
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Please select ASR(s) to add to an existing list.', 'danger');
		}
	}

	// user wants to add ASRs to existing working set
	$scope.addExistWorkSetBtnClickMdcd = function() {
		console.log('Inside addExistWorkSetBtnClick');
		
		// show overlay while dropdown values load
		$("#existWorkSetSelect").LoadingOverlay("show");
		
		// set the form to pristine
		$scope.existWorkSetSelect = null;
		$scope.addToExistWorkSetForm.$setPristine();
				
		$scope.addToExistSelections =  $('#asrMDCDTable').bootstrapTable('getSelections');
		console.log('selected count = ' + $scope.addToExistSelections.length);
		
		if ($scope.addToExistSelections.length > 0) {
			// show the addToExistWorkSetModal modal
			$("#addToExistWorkSetModal").modal("show");
			
			// call the web service to get the list of working sets
			caseMgmtFactory.getAddToExistInputValsMdcd($scope.restURL, $scope.userId).then(function(response) {
				$scope.addToExistItemsOptions = response.data;
				
				console.log('response = ' + JSON.stringify($scope.addToExistItemsOptions));
				
				// hide overlay after dropdown values load
				$("#existWorkSetSelect").LoadingOverlay("hide");				
				
			}).
			catch(function(err){    			
				console.log("Get Add to Existing List Input Vals REST Error: " + err.status);

				// hide overlay after dropdown values load
				$("#existWorkSetSelect").LoadingOverlay("hide");
				
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load list values due to ' + err.status, 'danger');
			});
		} else {
				// hide overlay after dropdown values load
				$("#existWorkSetSelect").LoadingOverlay("hide");
			
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Please select ASR(s) to add to an existing list.', 'danger');
		}
	}

	// user is submitting add to existing list from modal
	$scope.addToExistWsBtnClick = function() {
		console.log('Inside addToExistWsBtnClick'); 
		
		// disable the add to existing working set button
		$scope.disableExistWorkSetBtn = 'hide';
		
		// dirty the form since it's been submitted
		$scope.addToExistWorkSetForm.$setDirty();
		
		// check the form validity
		if ($scope.addToExistWorkSetForm.$invalid) {
			// do not process response
			console.log('Invalid - Don\'t process.');
			
			// enable the add to existing working set button
			$scope.disableExistWorkSetBtn = 'show';
		} else {
			// process response
			console.log('Valid - Process');
			
			// get the value of the dropdown box
			var chosenListFromInput = $scope.existWorkSetSelect;
			console.log('Choosen List = ' + JSON.stringify(chosenListFromInput));
			
			// create asr array
			
			var addAsrExistListArr = [];
			
			// loop through results, and then build array
			for (i = 0; i < $scope.addToExistSelections.length; i++) {
				//console.log($scope.searchResultTable.api().rows({ selected: true }).data()[i].asrptId);
				
				// create object to add to array
				//var deleteAsrObj = {};
				//deleteAsrObj.asrId = $scope.searchResultTable.api().rows({selected: true }).data()[i].asrDbid;
				
				// add the object to the array
				//deleteAsrArr.push(deleteAsrObj);   
				addAsrExistListArr.push($scope.addToExistSelections[i].asrDbid);
			}
			
			// call the web service to add to existing list
			caseMgmtFactory.addToExistList($scope.restURL, $scope.userId, chosenListFromInput.listId, addAsrExistListArr).then(function(response) {
				// enable the add to existing working set button
				$scope.disableExistWorkSetBtn = 'show';
				
				//show growl success message
				showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i>  ASRs successfully added to list.', 'success');
				
				// hide the modal window
				$("#addToExistWorkSetModal").modal("hide");
				
			}).
			catch(function(err){    			
				console.log("Get Add to Existing List REST Error: " + err.status);
				
				// enable the add to existing working set button
				$scope.disableExistWorkSetBtn = 'show';

				// Hide modal LoadingOverlay
				//$("#prioritizeUCMModalBody").LoadingOverlay("hide");
				
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to add ASRs to list due to ' + err.status, 'danger');
			});
		}
		
	}

	//this method conducts search and is initiated by clicking the search button
	$scope.conductASRSearch = function() {
		if($("#medicareAsrInfoSearchItem").hasClass('active')){
			$scope.currentASRview = "medicare"
		}
		else{
			$scope.currentASRview = "medicaid"
		}
		// create a scope level unique identifier
		$scope.searchUniqueId = Math.floor(Math.random() * 1000) + Date.now();
		
		//broadcast this event to the broadcastSlaMetrics listener
		$rootScope.$broadcast('broadcastSlaMetrics', {message:"ASR Search - Start: " + $scope.searchUniqueId, userId: ""});
		
		// if user is MAC, then hide the barrierCdCnt and activityCnt columns
		
		console.log('Search Form Valid = ' + $scope.searchForm.$valid);
		
		// get the ASR IDs
		var asrLines = $('#searchAsrId').val().split('\n');
		console.log('# of ASRs = ' + asrLines.length);
		
		var searchAsrArray = [];
		$scope.searchForm.searchAsrId.$setValidity('asrformaterror', true);
		$scope.searchForm.searchAsrId.$setValidity('asriderror', true);
		
		// check to see if the user entered more than 200 ASRs
		if (asrLines.length > 200) {
			console.log('Please limit the number of ASRs to 200 or less.');
			
			// set form field as invalid
			$scope.searchForm.searchAsrId.$setValidity('asriderror', false);
		} else {
			// there are less than 200 entries... so process ASRs
			// set form field as valid
			var asrIdformatInvalidBool = true;
			
			var checkEmptyList = [];
			console.log("If Empty asr list->",!Boolean(checkEmptyList.concat(asrLines)))
			
			// loop through the ASRs and create the request array
			if (Boolean(checkEmptyList.concat(asrLines)))
			for (i = 0; i < asrLines.length ; i++) {
				
				var regExNpi = new RegExp("^([0-9]{10})$");
				if (asrLines[i].trim() != '') {
					if(!regExNpi.test(asrLines[i].trim())) {
						$scope.searchForm.searchAsrId.$setValidity('asrformaterror', false);
						asrIdformatInvalidBool = false;
						console.log("validate failed asrid - ", asrLines[i])
						break;
					}else {
						searchAsrArray.push(asrLines[i].trim());
						$scope.searchForm.searchAsrId.$setValidity('asrformaterror', true);
						console.log('asrLines #' + i + ' = ' + asrLines[i].trim());
					}
				}
			}
		}		
		
		
		// get the BIlling NPIs
		var billingNPIsLines = $('#searchBillingNPIs').val().split('\n');
		console.log('# of Billing NPIs = ' + billingNPIsLines.length);
		
		var searchBillingNPIsArray = [];
		var billingNPIformatInvalidBool = true;
		$scope.searchForm.searchBillingNPIs.$setValidity('billingNPIsFormaterror', true);
		$scope.searchForm.searchBillingNPIs.$setValidity('billingNPIserror', true);
		
		// check to see if the user entered more than 200 ASRs
		if (billingNPIsLines.length > 200) {
			console.log('Please limit the number of ASRs to 200 or less.');
			
			// set form field as invalid
			$scope.searchForm.searchBillingNPIs.$setValidity('billingNPIserror', false);
		} else {
			// there are less than 200 entries... so process ASRs
			// set form field as valid
			
			var checkEmptyList = [];
			console.log("If Empty asr list->",!Boolean(checkEmptyList.concat(billingNPIsLines)))
			
			// check if the arrry is not empty 			
			// loop through the ASRs and create the request array
			if (Boolean(checkEmptyList.concat(billingNPIsLines)))
			for (i = 0; i < billingNPIsLines.length ; i++) {
				
				var regExNpi = new RegExp("^([0-9]{10})$");
				if (billingNPIsLines[i].trim() != '') {
					if(!regExNpi.test(billingNPIsLines[i].trim())) {
						$scope.searchForm.searchBillingNPIs.$setValidity('billingNPIsFormaterror', false);
						billingNPIformatInvalidBool = false;
						break;
					}else {
						// set form field as valid
						$scope.searchForm.searchBillingNPIs.$setValidity('billingNPIsFormaterror', true);	
						searchBillingNPIsArray.push(billingNPIsLines[i].trim());
						console.log('Billing NPIs lines #' + i + ' = ' + billingNPIsLines[i].trim());
					}
					
				}else {
					console.log(" no asr ==> ", billingNPIsLines[i].trim() != '')
				}
			}
		}		
		
				
		//check to see if the main search form is dirty
		if ($scope.searchForm.$valid) {	   		
    		// Show full page LoadingOverlay
			$("#searchModalBody").LoadingOverlay("show", {
				"zIndex": 1200
			});  
			
			// create new search object		
			var initSearchObj = utilService.getSearchReqObj();	
			
			// added to differentiate between medicare and medicaid
			initSearchObj.programType = $scope.currentASRview;
			
			// add the logged-in user to the search object
			initSearchObj.loggedInUserId =  $scope.userId
						
			// ASR ID
			if ($scope.searchAsrId) {
				initSearchObj.asrptIds = searchAsrArray;
			}
			
			// Billing NPIS
			if ($scope.searchBillingNPIs) {
				initSearchObj.billingNpis = searchBillingNPIsArray;
			}
			
			
			if ( $scope.currentASRview == "medicaid"){
				
				
				// searchMdcdSvcTypes
				var svcTypeObjArray = [];
				if ($scope.searchMdcdSvcTypes != void(0) && $scope.searchMdcdSvcTypes != null && $scope.searchMdcdSvcTypes != '' && $scope.searchMdcdSvcTypes.length > 0) {
				
					
					for (i = 0; i < $scope.searchMdcdSvcTypes.length; i++) {
						var svcTypeObj = {};
						svcTypeObj.code = $scope.searchMdcdSvcTypes[i].code;
						svcTypeObjArray.push(svcTypeObj);
					}
					
					initSearchObj.mdcdSvcCats = svcTypeObjArray;
				}
				
				// searchMdcdSvcCats 
				var mdcdSvcCatsArray = [];
				if ($scope.searchMdcdSvcCats != void(0) && $scope.searchMdcdSvcCats != null && $scope.searchMdcdSvcCats != '' && $scope.searchMdcdSvcCats.length > 0) {
					
					
					for (i = 0; i < $scope.searchMdcdSvcCats.length; i++) {
						var mdcdSvcCatsObj = {};
						mdcdSvcCatsObj.code = $scope.searchMdcdSvcCats[i].code;
						mdcdSvcCatsArray.push(mdcdSvcCatsObj);
					}
					
					initSearchObj.mdcdSvcCats = mdcdSvcCatsArray;
				}
				
				// mdcdSvcSubCats
				var svcSubCatsObjArray = [];
				if ($scope.searchMdcdSvcSubCats != void(0) && $scope.searchMdcdSvcSubCats != null && $scope.searchMdcdSvcSubCats != '' && $scope.searchMdcdSvcSubCats.length > 0) {
					
					
					for (i = 0; i < $scope.searchMdcdSvcSubCats.length; i++) {
						var svcSubCatsObj = {};
						svcSubCatsObj.code = $scope.searchMdcdSvcSubCats[i].code;
						svcSubCatsObjArray.push(svcSubCatsObj);
					}
					initSearchObj.mdcdSvcSubCats = svcSubCatsObjArray;
				}
				
				
				
				// searchMdcdRoles 
				var mdcdRolesArray = [];
				if ($scope.searchMdcdRoles != void(0) && $scope.searchMdcdRoles != null && $scope.searchMdcdRoles != '' && $scope.searchMdcdRoles.length > 0) {
				
					
					for (i = 0; i < $scope.searchMdcdRoles.length; i++) {
						var mdcdSvcCatsObj = {};
						mdcdSvcCatsObj.code = $scope.searchMdcdRoles[i].code;
						mdcdRolesArray.push(mdcdSvcCatsObj);
					}
					
					initSearchObj.mdcdRoles = mdcdRolesArray;
				}
			}
			
			
			// Provider Name
			if ($scope.searchPrvdrName) {
				initSearchObj.prvdrName = $scope.searchPrvdrName;
			}
			
			// Claim Type
			if ($scope.searchClaimType != void(0) && $scope.searchClaimType != null && $scope.searchClaimType != '' && $scope.searchClaimType.length > 0) {
				var claimTypesArray = [];
				
				for (i = 0; i < $scope.searchClaimType.length; i++) {
					var claimTypesObj = {};
				    claimTypesObj.claimTypeCd = $scope.searchClaimType[i];
				    claimTypesArray.push(claimTypesObj);
				}
				
				initSearchObj.claimTypes = claimTypesArray;
			}
			
			// ASRs in a Working Set
			if ($scope.searchAsrInWorkSet != void(0) && $scope.searchAsrInWorkSet != null && $scope.searchAsrInWorkSet != '' && $scope.searchAsrInWorkSet.length > 0) {
				var asrInWorkSetArray = [];
				
				for (i = 0; i < $scope.searchAsrInWorkSet.length; i++) {
					var asrInWorkSetObj = {};
					asrInWorkSetObj.code = $scope.searchAsrInWorkSet[i];
					asrInWorkSetArray.push(asrInWorkSetObj);
				}
				
				initSearchObj.asrWorkingSetInd = asrInWorkSetArray;
			}
			
			// ASRs in a Exclusion Set
			if ($scope.searchAsrInExSet != void(0) && $scope.searchAsrInExSet != null && $scope.searchAsrInExSet != '' && $scope.searchAsrInExSet.length > 0) {
				var asrInExSetArray = [];
				
				for (i = 0; i < $scope.searchAsrInExSet.length; i++) {
					var asrInExSetObj = {};
					asrInExSetObj.code = $scope.searchAsrInExSet[i];
					asrInExSetArray.push(asrInExSetObj);
				}
				
				initSearchObj.asrExclSetInd = asrInExSetArray;
			}
			
			// biu complaint days
			if ($scope.searchBiuComplaintDays != void(0) && $scope.searchBiuComplaintDays != null && $scope.searchBiuComplaintDays != '' && $scope.searchBiuComplaintDays.length > 0) {
				initSearchObj.biuDays = $scope.searchBiuComplaintDays;
			}
			
			// biu count
			if ($scope.searchBiuComplaints) {
				initSearchObj.biuCnt = $scope.searchBiuComplaints;
			}
			
			// Enrollment ID
			if ($scope.searchEnrollId) {
				initSearchObj.enrollmentId = $scope.searchEnrollId;
			}
			
			// Enrollment Status
			if ($scope.searchEnrollStatus != void(0) && $scope.searchEnrollStatus != null && $scope.searchEnrollStatus != '' && $scope.searchEnrollStatus.length > 0) {
				var enrollStatusArray = [];
				
				for (i = 0; i < $scope.searchEnrollStatus.length; i++) {
					var enrollStatusObj = {};
					enrollStatusObj.code = $scope.searchEnrollStatus[i].code;
				    enrollStatusArray.push(enrollStatusObj);
				}
				
				initSearchObj.enrollStatus = enrollStatusArray;
			}
			
			// Last Claim Submitted Date
			if ($scope.searchClmSbtDtMin){
				initSearchObj.lastClmDtLow = $scope.searchClmSbtDtMin;
			} 
			
			if ($scope.searchClmSbtDtMax){
				initSearchObj.lastClmDtHigh = $scope.searchClmSbtDtMax;
			} 
			
			// Last Alerted Claim Date of Service
			if ($scope.searchLastAlertClmDtMin){
				initSearchObj.lastAlertSvcDtLow = $scope.searchLastAlertClmDtMin;
			} 
			
			// Path To Education
			if ($scope.searchPathToEduInd){
				initSearchObj.pathToEduInd = $scope.searchPathToEduInd;
			} 
			
			// ACO Ind
			if ($scope.searchAcoInd){
				initSearchObj.acoInd = $scope.searchAcoInd;
			} 
			
			if ($scope.searchLastAlertClmDtMax){
				initSearchObj.lastAlertSvcDtHigh = $scope.searchLastAlertClmDtMax;
			}

			// Last Alerted Phase 1 Claim Date of Service
			if ($scope.searchLastphase1AlertClmDtMin){
				initSearchObj.p1LastAlertSvcDtLow = $scope.searchLastphase1AlertClmDtMin;
			} 

			if ($scope.searchLastphase1AlertClmDtMax){
				initSearchObj.p1LastAlertSvcDtHigh = $scope.searchLastphase1AlertClmDtMax;
			}
			
			// Last Date of Education
			if ($scope.searchLastEduDtMin){
				initSearchObj.lastEduDtLow = $scope.searchLastEduDtMin;
			} 
			
			if ($scope.searchLastEduDtMax){
				initSearchObj.lastEduDtHigh = $scope.searchLastEduDtMax;
			}
			
			// Last Date of TPE Education
			if ($scope.searchTpeLastEduDtMin){
				initSearchObj.lastTpeEduDtLow = $scope.searchTpeLastEduDtMin;
			} 
			
			if ($scope.searchTpeLastEduDtMax){
				initSearchObj.lastTpeEduDtHigh = $scope.searchTpeLastEduDtMax;
			}
			
			// ASR Create Date
			if ($scope.searchAsrCreateDtMin) {
				initSearchObj.createdMinDt = $scope.searchAsrCreateDtMin;
			}
			
			if ($scope.searchAsrCreateDtMax) {
				initSearchObj.createdMaxDt = $scope.searchAsrCreateDtMax;
			}

			if ( $scope.searchMdcrAsrCreateDtMin){
				initSearchObj.createdMinDt = $scope.searchMdcrAsrCreateDtMin;
			}

			if ($scope.searchMdcrAsrCreateDtMax) {
				initSearchObj.createdMaxDt = $scope.searchMdcrAsrCreateDtMax;
			}
			
			
			// Timeliness
			if ($scope.searchTimelinessDtMin){
				initSearchObj.timelinessLow = $scope.searchTimelinessDtMin;
			} 
			
			if ($scope.searchTimelinessDtMax){
				initSearchObj.timelinessHigh = $scope.searchTimelinessDtMax;
			}	
			
			// Risk Score
			if ($scope.searchRiskScoreMin){
				initSearchObj.riskScoreLow = $scope.searchRiskScoreMin;
			} 
			
			if ($scope.searchRiskScoreMax){
				initSearchObj.riskScoreHigh = $scope.searchRiskScoreMax;
			}
			
			// Priority Score
			if ($scope.searchPriorityScoreMin){
				initSearchObj.priorityScoreLow = $scope.searchPriorityScoreMin;
			} 
			
			if ($scope.searchPriorityScoreMax){
				initSearchObj.priorityScoreHigh = $scope.searchPriorityScoreMax;
			}
			
			// Submitted Amount
			if ($scope.searchSubmittedAmtMin){
				initSearchObj.sbmtAmtLow = $scope.searchSubmittedAmtMin;
			} 
			
			if ($scope.searchSubmittedAmtMax){
				initSearchObj.sbmtAmtHigh = $scope.searchSubmittedAmtMax;
			}
			
			// Submitted Amount Part D
			if ($scope.searchSubmittedAmtDMin){
				initSearchObj.sbmtAmtDLow = $scope.searchSubmittedAmtDMin;
			} 
			
			if ($scope.searchSubmittedAmtDMax){
				initSearchObj.sbmtAmtDHigh = $scope.searchSubmittedAmtDMax;
			}
			
			// Total Payment
			if ($scope.searchTotalPayMin){
				initSearchObj.totalPymtLow = $scope.searchTotalPayMin;
			} 
			
			if ($scope.searchTotalPayMax){
				initSearchObj.totalPymtHigh = $scope.searchTotalPayMax;
			}
			
			// Total Payment Part D
			if ($scope.searchTtlPayPartDMin){
				initSearchObj.totalPymtDLow = $scope.searchTtlPayPartDMin;
			} 
			
			if ($scope.searchTtlPayPartDMax){
				initSearchObj.totalPymtDHigh = $scope.searchTtlPayPartDMax;
			}
			
			// ASR Cost
			if ($scope.searchAsrCostMin){
				initSearchObj.asrCostLow = $scope.searchAsrCostMin;
			} 
			
			if ($scope.searchAsrCostMax){
				initSearchObj.asrCostHigh = $scope.searchAsrCostMax;
			}

			// Phase 1 ASR Cost
			if ($scope.searchphase1AsrCostMin){
				initSearchObj.p1AsrCostLow = $scope.searchphase1AsrCostMin;
			} 
			
			if ($scope.searchphase1AsrCostMax){
				initSearchObj.p1AsrCostHigh = $scope.searchphase1AsrCostMax;
			}
			
			// UCM ASR ID
			if ($scope.searchUcmAsrId) {
				initSearchObj.ucmAsrId = $scope.searchUcmAsrId;
			}
			
			// UCM Case ID
			if ($scope.searchUcmCaseId) {
				initSearchObj.ucmCaseId = $scope.searchUcmCaseId;
			}
			
			// Ruling
			if ($scope.searchRuling != void(0) && $scope.searchRuling != null && $scope.searchRuling != '' && $scope.searchRuling.length > 0) {
				var rulingArray = [];
				
				for (i = 0; i < $scope.searchRuling.length; i++) {
					var rulingObj = {};
					rulingObj.code = $scope.searchRuling[i].code;
					rulingArray.push(rulingObj);
				}
				
				initSearchObj.rulings = rulingArray;
			}
			
			// Alert (Model Name)
			if ($scope.searchAlrtModName != void(0) && $scope.searchAlrtModName != null && $scope.searchAlrtModName != '' && $scope.searchAlrtModName.length > 0) {
				var alertArray = [];
				
				for (i = 0; i < $scope.searchAlrtModName.length; i++) {
					var alertObj = {};
					alertObj.alertId = $scope.searchAlrtModName[i].modelId;
					alertArray.push(alertObj);
				}
				
				initSearchObj.alerts = alertArray;
			}

			// phase 1 Alert (Model Name)
			if ($scope.searchphase1AlrtModName != void(0) && $scope.searchphase1AlrtModName != null && $scope.searchphase1AlrtModName != '' && $scope.searchphase1AlrtModName.length > 0) {
				var alertArray = [];
				const p1SelectedAll = $scope.searchphase1AlrtModName.some(item =>
					item.modelId === 'all' );
				if (p1SelectedAll) {
					for (i = 0; i < $scope.p1Models.length; i++) {
						if ($scope.p1Models[i].modelId != 'all') {
							var alertObj = {};
							alertObj.alertId = $scope.p1Models[i].modelId;
							alertArray.push(alertObj);
						}

					}
				}
				else {
					for (i = 0; i < $scope.searchphase1AlrtModName.length; i++) {
						var alertObj = {};
						if ($scope.searchphase1AlrtModName[i].modelId != 'all') {
							alertObj.alertId = $scope.searchphase1AlrtModName[i].modelId;
							alertArray.push(alertObj);
						}

					}
				}
				
				
				
				initSearchObj.p1Alerts = alertArray;
			}
			
			// Edit Name
			if ($scope.searchEditName != void(0) && $scope.searchEditName != null && $scope.searchEditName != '' && $scope.searchEditName.length > 0) {
				var editsArray = [];
				
				for (i = 0; i < $scope.searchEditName.length; i++) {
					var editsObj = {};
					editsObj.code = $scope.searchEditName[i].code;
					editsArray.push(editsObj);
				}
				
				initSearchObj.edits = editsArray;
			}
			
			// Edit ID
			if ($scope.searchEditId) {
				initSearchObj.editId = $scope.searchEditId;
			}
			
			// ASR Specialty
			if ($scope.searchPrvdrAsrSpecial != void(0) && $scope.searchPrvdrAsrSpecial != null && $scope.searchPrvdrAsrSpecial != '' && $scope.searchPrvdrAsrSpecial.length > 0) {
				var asrSpecialArray = [];
				
				for (i = 0; i < $scope.searchPrvdrAsrSpecial.length; i++) {
					var asrSpecialObj = {};
					asrSpecialObj.code = $scope.searchPrvdrAsrSpecial[i].key;
					asrSpecialArray.push(asrSpecialObj);
				}
				
				initSearchObj.specialtyCds = asrSpecialArray;
			}
			
			// States
			if ($scope.searchPrvdrPractState != void(0) && $scope.searchPrvdrPractState != null && $scope.searchPrvdrPractState != '' && $scope.searchPrvdrPractState.length > 0) {
				var statesArray = [];
				
				for (i = 0; i < $scope.searchPrvdrPractState.length; i++) {
					var statesObj = {};
					statesObj.code = $scope.searchPrvdrPractState[i].code;
					statesArray.push(statesObj);
				}
				
				initSearchObj.states = statesArray;
			}
			
			// Alert Status
			if ($scope.searchAlertStatus != void(0) && $scope.searchAlertStatus != null && $scope.searchAlertStatus != '' && $scope.searchAlertStatus.length > 0) {
				var alertStatusArray = [];
				
				for (i = 0; i < $scope.searchAlertStatus.length; i++) {
					var alertStatusObj = {};
					alertStatusObj.code = $scope.searchAlertStatus[i];
					alertStatusArray.push(alertStatusObj);
				}
				
				initSearchObj.alertStatus = alertStatusArray;
			}

			// Alert Status
			if ($scope.searchphase1AlertStatus != void(0) && $scope.searchphase1AlertStatus != null && $scope.searchphase1AlertStatus != '' && $scope.searchphase1AlertStatus.length > 0) {
				var alertStatusArray = [];
				
				for (i = 0; i < $scope.searchphase1AlertStatus.length; i++) {
					var alertStatusObj = {};
					alertStatusObj.code = $scope.searchphase1AlertStatus[i];
					alertStatusArray.push(alertStatusObj);
				}
				
				initSearchObj.p1AlertStatus = alertStatusArray;
			}
			
			// Zone Restriction
			if ($scope.searchZoneRestriction != void(0) && $scope.searchZoneRestriction != null && $scope.searchZoneRestriction != '' && $scope.searchZoneRestriction.length > 0) {
				var zoneRestrictionArray = [];
				
				for (i = 0; i < $scope.searchZoneRestriction.length; i++) {
					var zoneRestrictionsObj = {};
					zoneRestrictionsObj.code = $scope.searchZoneRestriction[i];
					zoneRestrictionArray.push(zoneRestrictionsObj);
				}
				
				initSearchObj.zrTypes = zoneRestrictionArray;
			}
			
			//ZR Case ID
			if ($scope.zrCaseId) {
				initSearchObj.zrId = $scope.zrCaseId;
			}
			
			//Jurisdiction
			if ($scope.searchJurisdiction != void(0) && $scope.searchJurisdiction != null && $scope.searchJurisdiction != '' && $scope.searchJurisdiction.length > 0) {
				var zoneArray = [];
				
				for (i = 0; i < $scope.searchJurisdiction.length; i++) {
					var zoneObj = {};
					zoneObj.code = $scope.searchJurisdiction[i].zoneCd;
					zoneArray.push(zoneObj);
				}
				
				initSearchObj.jurisdictions = zoneArray;
			}

			//Phase 1 Jurisdiction
			if ($scope.searchphase1Jurisdiction != void(0) && $scope.searchphase1Jurisdiction != null && $scope.searchphase1Jurisdiction != '' && $scope.searchphase1Jurisdiction.length > 0) {
				var zoneArray = [];
				
				for (i = 0; i < $scope.searchphase1Jurisdiction.length; i++) {
					var zoneObj = {};
					zoneObj.code = $scope.searchphase1Jurisdiction[i].zoneCd;
					zoneArray.push(zoneObj);
				}
				
				initSearchObj.p1Jurisdictions = zoneArray;
			}
			
			// Leads/Investigation Status			
			if ($scope.searchLeadInvStatus != void(0) && $scope.searchLeadInvStatus != null && $scope.searchLeadInvStatus != '' && $scope.searchLeadInvStatus.length > 0) {
				var leadsInvArray = [];
				
				for (i = 0; i < $scope.searchLeadInvStatus.length; i++) {
					var leadsInvObj = {};
					leadsInvObj.code = $scope.searchLeadInvStatus[i];
					leadsInvArray.push(leadsInvObj);
				}
				
				initSearchObj.leadInvestigationInd = leadsInvArray;
			}
			
			//  Leads/Inv my zones check box
			if ($scope.searcMyZoneOnlyInd  === true) {
				initSearchObj.myZoneOnlyInd = 'Yes';
			} else {
				initSearchObj.myZoneOnlyInd = 'No';
			}
			
			// ASR Part D Reports
			if ($scope.searchAsrPartD){
				initSearchObj.partDInd = $scope.searchAsrPartD;
			}
			
			// Criminal
			if ($scope.searchCriminal) {
				initSearchObj.apsInd = $scope.searchCriminal;
			}
			
			// Actionability		
			if ($scope.searchActionability != void(0) && $scope.searchActionability != null && $scope.searchActionability != '' && $scope.searchActionability.length > 0) {
				var actionArray = [];
				
				for (i = 0; i < $scope.searchActionability.length; i++) {
					var actionObj = {};
					actionObj.code = $scope.searchActionability[i];
					actionArray.push(actionObj);
				}
				
				initSearchObj.actionability = actionArray;
			}
			
			// Prioritize for UCM
			if ($scope.searchPriorUcm != void(0) && $scope.searchPriorUcm != null && $scope.searchPriorUcm != '' && $scope.searchPriorUcm.length > 0) {
				var priorUcmArray = [];
				
				for (i = 0; i < $scope.searchPriorUcm.length; i++) {
					var priorUcmObj = {};
					priorUcmObj.code = $scope.searchPriorUcm[i].key;
					priorUcmArray.push(priorUcmObj);
				}
				
				initSearchObj.prioritizeTypes  = priorUcmArray;
			}			
		
			// Exclusions
			if ($scope.searchExclusions != void(0) && $scope.searchExclusions != null && $scope.searchExclusions != '' && $scope.searchExclusions.length > 0) {
				var excludeArray = [];
				
				for (i = 0; i < $scope.searchExclusions.length; i++) {
					var excludeObj = {};
					excludeObj.code = $scope.searchExclusions[i].key;
					excludeArray.push(excludeObj);
				}
				
				initSearchObj.exclusions  = excludeArray;
			}
			
			// Exclusions Indicator
			if ($scope.searchExclusionsInd) {
				initSearchObj.exclusionOrInd = $scope.searchExclusionsInd;
			}
			
			// Lead Indicator
			if ($scope.searchLeadInd){
				initSearchObj.leadInd = $scope.searchLeadInd;
			} 
			// Dual Eligible Bene Indicator
			if ($scope.searchDualBeneInd){
				initSearchObj.dualBeneInd = $scope.searchDualBeneInd;
			} 
			
			
			// Remove if tabs are disabled.
			
			$('#medicaidAsrInfoSummaryItem').removeClass('disabled');
			$('#medicaidAsrInfoSummaryItem').attr('aria-disabled', 'false');
			$('#medicaidAsrInfoSummaryTabLink').css('cursor', 'pointer');
			$('#medicaidAsrInfoSummaryTabLink').css('pointer-events', 'auto');
			$('#medicaidAsrInfoSummaryTabLink').attr('data-toggle','tab');
			
			$('#medicareAsrInfoSummaryItem').removeClass('disabled');
			$('#medicareAsrInfoSummaryItem').attr('aria-disabled', 'false');
			$('#medicareAsrInfoSummaryTabLink').css('cursor', 'pointer');
			$('#medicareAsrInfoSummaryTabLink').css('pointer-events', 'auto');
			$('#medicareAsrInfoSummaryTabLink').attr('data-toggle','tab');
			
			console.log("Tabs enabled.");
			
			// see which tab is active
			if ( $('#customLvlSearchTabLi').hasClass('active') == true || $('#presetSearchTabLi').hasClass('active') == true) {
				console.log('Tab - Custom Level Search selected');
				
				// conduct regular search or preset search
				
				if ($('#customLvlSearchTabLi').hasClass('active') == true) {
					// set the search object to a scope variable (for use by the save search button)
					$scope.savedSearchObjStr = JSON.stringify(initSearchObj);
				} else if ($('#presetSearchTabLi').hasClass('active') == true) {
					
					// create new search object		
					var initSearchObj = utilService.getSearchReqObj();	
					
					// add the logged-in user to the search object
					initSearchObj.loggedInUserId =  $scope.userId
					
					// Predetermined Query
					if ($scope.searchPredetermined) {
						initSearchObj.presetSearchFlag = $scope.searchPredetermined;
					}
				}
				
				// conduct search
				caseMgmtFactory.getCaseMgmtData($scope.restURL, initSearchObj).then(function(response) {
					// change the panel heading to search results
					$scope.summaryHeaderTitle = 'Search Results';
					
					// disable the remove from working set button
					$scope.disableWorkSetBtn = 'hide';
					
					// show the add to exclusion set button
					$scope.hideAddToExcludeSetBtn = 'show';					
					$scope.hideSecondAddToExcludeSetBtn = 'hide';
					$scope.hideRemoveFromExcludeSetBtn = 'hide';
					
					// clear the data table and then reload with returned data
					$("#asrMgmtTable").bootstrapTable('load',response.data.responseData);
					
					console.log("Length ->",response.data.responseData.length);
					console.log("Length ->",response.data.responseDataMdcd.length);
					console.log(response.data.responseData);
					console.log(response.data.responseDataMdcd);
					
					$("#asrMDCDTable").bootstrapTable('load', response.data.responseDataMdcd);
					// hide search modal
					$("#searchModal").modal("hide");	
					
					setTimeout(function(){
						$("#breadcrumb-item").focus();
					},0);
					
					// Disabled Priortize UCM button based on mdcdPrrtyEnabledInd
					if(response.data.mdcdPrrtyEnabledInd == "N"){
						$('#prioritizeUCMBtn').attr('disabled', true);
						$rootScope.mdcdPrrtyEnabledInd = 'N';
					}
					else{
						$('#prioritizeUCMBtn').removeAttr('disabled');
					}
					
					// Show active tab
					if ($scope.currentASRview == "medicare" && response.data.responseData.length > 0){
						$scope.showMedicareAsrInfoSummaryTab();
					}else if ($scope.currentASRview == "medicaid" && response.data.responseDataMdcd.length > 0){
						$scope.showMedicaidAsrInfoSummaryTab();
					} 
					if (response.data.responseDataMdcd.length > 0 && response.data.responseData.length > 0  ){
						
						console.log("No summary grey out tabs");
						
					} else if (response.data.responseDataMdcd.length == 0 && response.data.responseData.length == 0  ){
							console.log("Both length zero");
							if ($scope.currentASRview == "medicare"){
								$scope.showMedicareAsrInfoSummaryTab();
								// Grey out medicaid tab
								//disable the medicaid AsrInfo SummaryTab tab
								$('#medicaidAsrInfoSummaryItem').addClass('disabled');
								$('#medicaidAsrInfoSummaryItem').attr('aria-disabled', 'true');
								$('#medicaidAsrInfoSummaryTabLink').css('cursor', 'not-allowed');
								$('#medicaidAsrInfoSummaryTabLink').css('pointer-events', 'none');
								$('#medicaidAsrInfoSummaryTabLink').removeAttr('data-toggle');
								
								console.log("grey out medicaid tab");
								
							
								
							} else if ($scope.currentASRview == "medicaid"){
								$scope.showMedicaidAsrInfoSummaryTab();
								// Grey out medicare tab
								//disable the medicare AsrInfo SummaryTab tab
								$('#medicareAsrInfoSummaryItem').addClass('disabled');
								$('#medicareAsrInfoSummaryItem').attr('aria-disabled', 'true');
								$('#medicareAsrInfoSummaryTabLink').css('cursor', 'not-allowed');
								$('#medicareAsrInfoSummaryTabLink').css('pointer-events', 'none');
								$('#medicareAsrInfoSummaryTabLink').removeAttr('data-toggle');
								
								console.log("grey out medicare tab");
							}
					} else if (response.data.responseDataMdcd.length == 0){
							$scope.showMedicareAsrInfoSummaryTab();
							// Grey out medicaid tab
							//disable the medicaid AsrInfo SummaryTab tab
							$('#medicaidAsrInfoSummaryItem').addClass('disabled');
							$('#medicaidAsrInfoSummaryItem').attr('aria-disabled', 'true');
							$('#medicaidAsrInfoSummaryTabLink').css('cursor', 'not-allowed');
							$('#medicaidAsrInfoSummaryTabLink').css('pointer-events', 'none');
							$('#medicaidAsrInfoSummaryTabLink').removeAttr('data-toggle');
							
							console.log("Medicaid length - 0, grey out medicaid tab tab");
							
					} else if (response.data.responseData.length == 0){
							$scope.showMedicaidAsrInfoSummaryTab();
							// Grey out medicare tab
							//disable the medicare AsrInfo SummaryTab tab
							$('#medicareAsrInfoSummaryItem').addClass('disabled');
							$('#medicareAsrInfoSummaryItem').attr('aria-disabled', 'true');
							$('#medicareAsrInfoSummaryTabLink').css('cursor', 'not-allowed');
							$('#medicareAsrInfoSummaryTabLink').css('pointer-events', 'none');
							$('#medicareAsrInfoSummaryTabLink').removeAttr('data-toggle');
							
							console.log("medicare length - 0, grey out medicare tab tab");
					}
						
				
					
					
					//broadcast this event to the broadcastSlaMetrics listener
					$rootScope.$broadcast('broadcastSlaMetrics', {message:"ASR Search - End: " + $scope.searchUniqueId, userId: ""});
					
					// check the URL parameter to see if the user just updated a edited search
					if ($scope.workItemTypeQueryParam == "searchEdit") {
						console.log("User is conducting an edited search. Search Name = " + window.atob($scope.listNameParam));
						
						// call the save search web service
						caseMgmtFactory.saveUserPreferences($scope.restURL, $scope.userId, "asrSearch", JSON.stringify(initSearchObj), window.atob($scope.listNameParam)).then(function(response) {
							
							//hide full page overlay
							//$("#saveSearchModalBody").LoadingOverlay("hide");
							
							//present message to user stating that preferences have been saved
							showGrowl('<i class=\'fa fa-info-circle\' aria-hidden=\'true\'></i> Edited search successfully saved.', 'info');
							
							// hide the modal window
							//$("#saveSearchModal").modal("hide");
							
						}).catch(function(err){ 
							//hide full page overlay
							//$("#saveSearchModalBody").LoadingOverlay("hide");
							
							// show growl message
							showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Edited search not saved due to ' + err.status, 'danger');
						});
						
						// clear the $scope.workItemTypeQueryParam since user
						$scope.workItemTypeQueryParam = '';
						$scope.listNameParam = '';
					} else {
						console.log("User is NOT conducting an edited search... do NOT save criteria");
					}
					
					// Hide full page LoadingOverlay
					$("#searchModalBody").LoadingOverlay("hide");
				}).
				catch(function(err){    			
					console.log("ASR Management REST Error: " + err.status);
					//$("#asrMgmtTable").bootstrapTable('hideLoading');
					// Hide full page LoadingOverlay
					$("#searchModalBody").LoadingOverlay("hide");
					
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Search failed due to ' + err.status, 'danger');
				});
			} else if ( $('#savedSearchTabLi').hasClass('active') == true) {
				console.log('Tab - Saved Searches selected');
				
				// retrieve saved search
				if ($scope.savedSearchInput){
					// get the asr query results
					caseMgmtFactory.getAsrQueryList($scope.restURL,  $scope.userId, $scope.savedSearchInput.listId).then(function(response) {
						// change the panel heading to search results
						$scope.summaryHeaderTitle = 'Search Results';
						
						// set the type scope variable to search
						$scope.disableWorkSetBtn = 'hide';
						
						// show the add to exclusion set button
						$scope.hideAddToExcludeSetBtn = 'show';
						$scope.hideSecondAddToExcludeSetBtn = 'hide';
						$scope.hideRemoveFromExcludeSetBtn = 'hide';

						if ($scope.savedSearchInput.asrType == "MDCR") {
							$scope.currentASRview = "medicare"
							$scope.showMedicareAsrInfoSummaryTab();
							$('#medicaidAsrInfoSummaryItem').addClass('disabled');
							$('#medicaidAsrInfoSummaryItem').attr('aria-disabled', 'true');
							$('#medicaidAsrInfoSummaryTabLink').css('cursor', 'not-allowed');
							$('#medicaidAsrInfoSummaryTabLink').css('pointer-events', 'none');
							$('#medicaidAsrInfoSummaryTabLink').removeAttr('data-toggle');
						}
						else {
							$scope.currentASRview = "medicaid"
							$scope.showMedicaidAsrInfoSummaryTab();
							$('#medicareAsrInfoSummaryItem').addClass('disabled');
							$('#medicareAsrInfoSummaryItem').attr('aria-disabled', 'true');
							$('#medicareAsrInfoSummaryTabLink').css('cursor', 'not-allowed');
							$('#medicareAsrInfoSummaryTabLink').css('pointer-events', 'none');
							$('#medicareAsrInfoSummaryTabLink').removeAttr('data-toggle');
						}
						if (response.data.responseData.length > 0) {
							$("#asrMgmtTable").bootstrapTable('load', response.data.responseData);
							$('#medicareAsrInfoSummaryItem').removeClass('disabled');
							$('#medicareAsrInfoSummaryItem').attr('aria-disabled', 'false');
							$('#medicareAsrInfoSummaryTabLink').css('cursor', 'pointer');
							$('#medicareAsrInfoSummaryTabLink').css('pointer-events', 'auto');
							$('#medicareAsrInfoSummaryTabLink').attr('data-toggle', 'tab');
						}

						if (response.data.responseDataMdcd.length > 0) {
							$("#asrMDCDTable").bootstrapTable('load', response.data.responseDataMdcd);
							$('#medicaidAsrInfoSummaryItem').removeClass('disabled');
							$('#medicaidAsrInfoSummaryItem').attr('aria-disabled', 'false');
							$('#medicaidAsrInfoSummaryTabLink').css('cursor', 'pointer');
							$('#medicaidAsrInfoSummaryTabLink').css('pointer-events', 'auto');
							$('#medicaidAsrInfoSummaryTabLink').attr('data-toggle', 'tab');
						}
						
						// clear the data table and then reload with returned data
						// $("#asrMgmtTable").bootstrapTable('load',response.data.responseData);
						
						// $("#asrMDCDTable").bootstrapTable('load',response.data.responseDataMdcd);
						
						console.log("Length ->",response.data.responseData.length);
						console.log("Length ->",response.data.responseDataMdcd.length);
						
						// Show active tab
						if ($scope.currentASRview == "medicare"){
							$scope.showMedicareAsrInfoSummaryTab();
						} else if ($scope.currentASRview == "medicaid"){
							$scope.showMedicaidAsrInfoSummaryTab();
						}
						// hide search modal
						$("#searchModal").modal("hide");
						
						// Hide full page LoadingOverlay
						$("#searchModalBody").LoadingOverlay("hide");
						
		    			//broadcast this event to the broadcastSlaMetrics listener
						$rootScope.$broadcast('broadcastSlaMetrics', {message:"ASR Search - End: " + $scope.searchUniqueId, userId: ""});
						
						
							
						
					}).
		    		catch(function(err){    			
		    			console.log("Get Work Item Query REST Error: " + err.status);
		    			//$("#asrMgmtTable").bootstrapTable('hideLoading');
		    			// Hide full page LoadingOverlay
		    			$("#searchModalBody").LoadingOverlay("hide");
		    			
		    			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Query load failed due to ' + err.status, 'danger');
		    		});
				} else {
					// Hide full page LoadingOverlay
					$("#searchModalBody").LoadingOverlay("hide");
					
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Please choose a saved search.', 'danger');
				}
			}
		} else {
			// Hide full page LoadingOverlay
		//	$.LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Please correct the search form field errors.', 'danger');
		}

		setTimeout(function(){
			$("#breadcrumb-item").focus();
		},0);

	}

	// reset form field values
	$scope.resetASRSearch = function(show) {
		console.log('Reset initiated', show);
		// manually reset ng-model values since Angular doesn't automatically
		
		$scope.searchAsrId = null;
		$scope.searchPrvdrName = null;
		$scope.searchClaimType = null;
		$scope.searchEnrollId = null;
		$scope.searchEnrollStatus = null;
		$scope.searchClmSbtDtMin = null;
		$scope.searchClmSbtDtMax = null;
		$scope.searchLastAlertClmDtMin = null;
		$scope.searchLastAlertClmDtMax = null;
		$scope.searchLastphase1AlertClmDtMin = null;
		$scope.searchLastphase1AlertClmDtMax = null;
		$scope.searchLastEduDtMin = null;
		$scope.searchLastEduDtMax = null;
		$scope.searchTpeLastEduDtMin = null;
		$scope.searchTpeLastEduDtMax = null;
		$scope.searchTimelinessDtMin = null;
		$scope.searchTimelinessDtMax = null;
		$scope.searchRiskScoreMin = null;
		$scope.searchRiskScoreMax = null;
		$scope.searchPriorityScoreMin = null;
		$scope.searchPriorityScoreMax = null;
		$scope.searchSubmittedAmtMin = null;
		$scope.searchSubmittedAmtMax = null;
		$scope.searchSubmittedAmtDMin = null;
		$scope.searchSubmittedAmtDMax = null;
		$scope.searchTotalPayMin = null;
		$scope.searchTotalPayMax = null;
		$scope.searchTtlPayPartDMin = null;
		$scope.searchTtlPayPartDMax = null;
		$scope.searchAsrCostMin = null;
		$scope.searchAsrCostMax = null;
		$scope.searchphase1AsrCostMin = null;
		$scope.searchphase1AsrCostMax = null;
		$scope.searchUcmAsrId = null;
		$scope.searchUcmCaseId = null;
		$scope.searchRuling = null;
		$scope.searchAlrtModName = null;
		$scope.searchphase1AlrtModName = null;
		$scope.searchEditName = null;
		$scope.searchEditId = null;
		$scope.searchPrvdrPractState = null;
		$scope.searchPrvdrAsrSpecial = null;
		$scope.searchAlertStatus = null;
		$scope.searchZoneRestriction = null;
		$scope.zrCaseId = null;
		$scope.searchJurisdiction = null;
		$scope.searchphase1Jurisdiction = null;
		$scope.searchLeadInvStatus = null;
		$scope.searcMyZoneOnlyInd = null;
		$scope.searchAsrPartD = null;
		$scope.searchCriminal = null;
		$scope.searchActionability = null;
		$scope.searchPriorUcm = null;
		$scope.searchExclusions = null;
		$scope.searchExclusionsInd = null;
		$scope.searchLeadInd = null;
		$scope.searchAsrCreateDtMin = null;
		$scope.searchMdcrAsrCreateDtMin = null;
		$scope.searchAsrCreateDtMax = null;
		$scope.searchMdcrAsrCreateDtMax = null;
		$scope.searchAsrInWorkSet=null;
		$scope.searchAsrInExSet=null;
		$scope.searchBiuComplaints=null;
		$scope.searchBiuComplaintDays=null;		
		$('#searchBiuComplaintDays').val('');
		$scope.searchDualBeneInd = null;
		$scope.searchPathToEduInd = null;
		$scope.searchAcoInd = null;
		
		// Medicaid changes
		$scope.searchBillingNPIs = null;
		$scope.searchMdcdSvcTypes = null;
		$scope.searchMdcdSvcCats = null;
		$scope.searchMdcdSvcSubCats = null;
		$scope.searchMdcdRoles = null;
		
		
		// set pre-selected search radio buttons to the first one
		$scope.searchPredetermined = "MEDIC";
		
		// set the validity of the biu complaint fields
		$scope.searchForm.searchBiuComplaintDays.$setValidity('checkbiudayserror', true);
		$scope.searchForm.searchBiuComplaints.$setValidity('checkbiuerror', true);
		
		// set the validity of the ASR ID field to true
		$scope.searchForm.searchAsrId.$setValidity('asriderror', true);
		$scope.searchForm.searchAsrId.$setValidity('asrformaterror', true);
		// set the validity of the Billing NPI field to true
		$scope.searchForm.searchBillingNPIs.$setValidity('billingNPIsFormaterror', true);
		$scope.searchForm.searchBillingNPIs.$setValidity('billingNPIserror', true);
		
		// set the date fields as valid
		// education date
		$scope.searchForm.searchLastEduDtMin.$setValidity('checkdateerror', true);
		$scope.searchForm.searchLastEduDtMax.$setValidity('checkdateerror', true);
		// asr create date
		$scope.searchForm.searchAsrCreateDtMin.$setValidity('checkdateerror', true);
		$scope.searchForm.searchAsrCreateDtMax.$setValidity('checkdateerror', true);

		$scope.searchForm.searchMdcrAsrCreateDtMin.$setValidity('checkdateerror', true);
		$scope.searchForm.searchMdcrAsrCreateDtMax.$setValidity('checkdateerror', true);

		
		// tpe education
		$scope.searchForm.searchTpeLastEduDtMin.$setValidity('checkdateerror', true);
		$scope.searchForm.searchTpeLastEduDtMax.$setValidity('checkdateerror', true);
		// alerted claim date
		$scope.searchForm.searchLastAlertClmDtMin.$setValidity('checkdateerror', true);
		$scope.searchForm.searchLastAlertClmDtMax.$setValidity('checkdateerror', true);
		// alerted phase 1 claim date
		$scope.searchForm.searchLastphase1AlertClmDtMin.$setValidity('checkdateerror', true);
		$scope.searchForm.searchLastphase1AlertClmDtMax.$setValidity('checkdateerror', true);
		// last claim submitted date
		$scope.searchForm.searchClmSbtDtMin.$setValidity('checkdateerror', true);
		$scope.searchForm.searchClmSbtDtMax.$setValidity('checkdateerror', true);
		
		// set the number fields as valid
		// risk score
		$scope.searchForm.searchRiskScoreMin.$setValidity('checkscoreerror', true);
		$scope.searchForm.searchRiskScoreMax.$setValidity('checkscoreerror', true);
		// priority score
		$scope.searchForm.searchPriorityScoreMin.$setValidity('checkscoreerror', true);
		$scope.searchForm.searchPriorityScoreMax.$setValidity('checkscoreerror', true);
		// timeliness
		$scope.searchForm.searchTimelinessDtMin.$setValidity('checkscoreerror', true);
		$scope.searchForm.searchTimelinessDtMax.$setValidity('checkscoreerror', true);
		// asr cost
		$scope.searchForm.searchAsrCostMin.$setValidity('checkscoreerror', true);
		$scope.searchForm.searchAsrCostMax.$setValidity('checkscoreerror', true);
		// phase 1 asr cost
		$scope.searchForm.searchphase1AsrCostMin.$setValidity('checkscoreerror', true);
		$scope.searchForm.searchphase1AsrCostMax.$setValidity('checkscoreerror', true);
		// submitted amount
		$scope.searchForm.searchSubmittedAmtMin.$setValidity('checkscoreerror', true);
		$scope.searchForm.searchSubmittedAmtMax.$setValidity('checkscoreerror', true);
		// total payment
		$scope.searchForm.searchTotalPayMin.$setValidity('checkscoreerror', true);
		$scope.searchForm.searchTotalPayMax.$setValidity('checkscoreerror', true);
		// submitted amt part d
		$scope.searchForm.searchSubmittedAmtDMin.$setValidity('checkscoreerror', true);
		$scope.searchForm.searchSubmittedAmtDMax.$setValidity('checkscoreerror', true);
		//total payment part d
		$scope.searchForm.searchTtlPayPartDMin.$setValidity('checkscoreerror', true);
		$scope.searchForm.searchTtlPayPartDMax.$setValidity('checkscoreerror', true);
		
		// show growl message saying the values have been restored
		if (show){
			showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i>  The search defaults have been restored. ', 'success');
		}
		
		
	}

	// user clicked on the preset search tab
	$scope.preSetSrchTabClick = function() {
		// set the first radio button as selected
		$scope.searchPredetermined = "MEDIC";
	}

	$scope.savedSearchTabClick = function() {
		console.log('Inside savedSearchTabClick');
		
		// show the overlay for the custom search modal body
		$("searchModalBody").LoadingOverlay("show");
		
		// call the web service to get the list of saved searches
		caseMgmtFactory.getSavedSearchList($scope.restURL, $scope.userId).then(function(response) {
			$scope.savedSearchList = response.data;
			
			// hide the overlay for the custom search modal body
			$("searchModalBody").LoadingOverlay("hide");
		}).
		catch(function(err){    			
			console.log("Get Saved Search List REST Error: " + err.status);
			// hide the overlay for the custom search modal body
			$("searchModalBody").LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Saved Search data failed to load due to ' + err.status, 'danger');
		});
	}

	$scope.saveSearchBtnClick = function() {
		console.log('Inside saveSearchBtnClick'); 
		
		// check to see if the user has a current search request
		if ($scope.savedSearchObjStr != null && $scope.savedSearchObjStr != void(0) && $scope.savedSearchObjStr != "") {
			$("#saveSearchModal").modal("show");
						
			// reset the text box
			$scope.saveSearchNameInput = null;
			// reset the form, and then set the status to pristine
			$scope.saveSearchModalForm.$setPristine();
			
		} else {
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> There is no search to save. Please conduct a search before saving. ', 'danger');
		}
	}

	$scope.saveSearchModalBtnClick = function() {
		console.log('Inside saveSearchModalBtnClick');
		
		// dirty the form since it's been submitted
		$scope.saveSearchModalForm.$setDirty();
		
		// check the form validity		
		if ($scope.saveSearchModalForm.$invalid) {
			// process response
			console.log('Invalid - Don\'t process.');
		} else {
			// process response
			console.log('Valid - Process');
			
			//show full page overlay
			$("#saveSearchModalBody").LoadingOverlay("show");
						
			// call the service to see if name already exists
			caseMgmtFactory.checkExistListName($scope.restURL, $scope.userId, $scope.saveSearchNameInput, "search").then(function(response) {
				console.log("Check name response list length = " + response.data.length);
				
				// assign the response array to scope variable
				$scope.checkNmArray = response.data;
				
				var processReq = true;
				var existingAsrType = null;
				if($scope.currentASRview == 'medicare'){
					existingAsrType = 'MDCR'
				}
				else{
					existingAsrType = 'MDCD'
				}
				
				if ($scope.checkNmArray != null && $scope.checkNmArray.length > 0) {
					// loop through the array looking for match
					for (i=0; i < $scope.checkNmArray.length; i ++) {
						if ($scope.checkNmArray[i].listNm.trim()+$scope.checkNmArray[i].asrType.trim() == $scope.saveSearchNameInput.trim()+existingAsrType) {
							console.log("Search already exists.")
							
							// hide the overlay
							$("#saveSearchModalBody").LoadingOverlay("hide");
							
							processReq = false;
							
							break;
						} 
					}
				}	
				
				if (processReq == true) {
					if($scope.currentASRview == "medicare"){
						var asrSearchType = "asrSearch"
					}
					else{
						asrSearchType = "asrSearchMdcd";
					}
					// call the save search web service
					caseMgmtFactory.saveUserPreferences($scope.restURL, $scope.userId, asrSearchType, $scope.savedSearchObjStr, $scope.saveSearchNameInput).then(function(response) {
						
						//hide full page overlay
						$("#saveSearchModalBody").LoadingOverlay("hide");
						
						//present message to user stating that preferences have been saved
						showGrowl('<i class=\'fa fa-info-circle\' aria-hidden=\'true\'></i> Search successfully saved.', 'info');
						
						// hide the modal window
						$("#saveSearchModal").modal("hide");
						
					}).catch(function(err){ 
						//hide full page overlay
						$("#saveSearchModalBody").LoadingOverlay("hide");
						
						// show growl message
						showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Search not saved due to ' + err.status, 'danger');
					});
				} else {
					// show the warning message
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> A search with that name already exists. Please choose another name.', 'danger');
				}
				
			}).catch(function(err){ 
				//hide full page overlay
				$("#saveSearchModalBody").LoadingOverlay("hide");
				
				// show growl message
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to validate search name due to ' + err.status, 'danger');
			});
		}
	}

	$scope.conductSearchBtnClick = function(pSearchType) {
		console.log('Inside conductSearchBtnClick'); 
		
		// show the search modal
		$("#searchModal").modal("show");
		if ($scope.customSearchDefaultView == "medicaid") {
			$scope.showMedicaidAsrInfoSearchTab();
		}
		else {
			$scope.showMedicareAsrInfoSearchTab();
		}
		
		// load the ref data for the search components
		$scope.getSearchComponentVals(pSearchType);
	}

	//this function hides table columns from MAC users
	$scope.hideMACTableCols = function() {
		
		// hide the ucm summary column for all MACs
		$("#asrMgmtTable").bootstrapTable('hideColumn', 'ucmSummary');
		$("#asrMgmtTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="ucmSummary"]').parent().hide();
		
		// hide the last education date column for all MACs
		//$("#asrMgmtTable").bootstrapTable('hideColumn', 'lastEduDt');
		//$("#asrMgmtTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="lastEduDt"]').parent().hide();
	}
	
	// this function opens the asr details screen in a separate window
	$scope.asrDetailWindowOpen = function(pAsrId) { 
		$window.open("#/ASRDetails?asrDetailsParam=" + pAsrId+"&viewParam="+$scope.currentASRview );
	}

	//delete the user's ASR Summary table user preferences
	$scope.deleteUserPreferences = function() {
		console.log('Inside deleteUserPreferences function.');
		
		//show full page overlay
		$.LoadingOverlay("show");
		
		//create an empty array to represent the user doesn't want any columns hidden
		var hiddenFieldNames = [];
		var hiddenColsArray = [];
//		hiddenColsArray = $('#asrMgmtTable').bootstrapTable('getHiddenColumns');
		console.log("Hidden column size = " + hiddenColsArray.length);
		
		//save the field names array by calling the /rest/preferences web service
		caseMgmtFactory.deleteUserPreferences($scope.restURL, $scope.userId, $scope.tableCols, JSON.stringify(hiddenFieldNames), null).then(function(response) {
			//show all columns... unless the user is a MAC user			
			for (i=0; i < hiddenColsArray.length; i++) {
				 console.log("Showing column - " + hiddenColsArray[i].field);
				 $('#asrMgmtTable').bootstrapTable('showColumn', hiddenColsArray[i].field);
			}
			
			//hide certain columns for MAC users
			if($scope.rolesArray.indexOf("MAC") != -1){
				//call the function used to hide MAC table columns
				$scope.hideMACTableCols();
			}
			
			//hide full page overlay
			$.LoadingOverlay("hide");
			
			//present message to user stating that preferences have been deleted
			showGrowl('<i class=\'fa fa-info-circle\' aria-hidden=\'true\'></i> ASR Summary preferences have been cleared.', 'info');
		}).catch(function(err){ 
			//hide full page overlay
			$.LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> User preferences not deleted due to ' + err.status, 'danger');
		});
	}

	//save the user's ASR Summary table user preferences
	$scope.saveUserPreferences = function() {
		console.log('Inside saveUserPreferences function.');
		
		//show full page overlay
		$.LoadingOverlay("show");
				
		//get the hidden columns from the ASR summary table		
		console.log("Hidden Table Columns = " + $('#asrMgmtTable').bootstrapTable('getHiddenColumns').length);
		
		//create array to hold hidden field names
		var hiddenFieldNames = [];
		
		//loop through the hidden fields array to get the field names
		for (i=0; i < $('#asrMgmtTable').bootstrapTable('getHiddenColumns').length; i++) {
			hiddenFieldNames.push($('#asrMgmtTable').bootstrapTable('getHiddenColumns')[i].field);
		}
		
		if ($scope.currentASRview == "medicare"){
			//loop through the hidden fields array to get the field names
			for (i=0; i < $('#asrMgmtTable').bootstrapTable('getHiddenColumns').length; i++) {
				hiddenFieldNames.push($('#asrMgmtTable').bootstrapTable('getHiddenColumns')[i].field);
			}
			
			console.log("medicare hidden fields");
		} else if ($scope.currentASRview == "medicaid"){
			//loop through the hidden fields array to get the field names
			for (i=0; i < $('#asrMDCDTable').bootstrapTable('getHiddenColumns').length; i++) {
				hiddenFieldNames.push($('#asrMDCDTable').bootstrapTable('getHiddenColumns')[i].field);
			}
			
			console.log("medicaid hidden field");
		}
		
		console.log("hiddenFieldNames Array = " + JSON.stringify(hiddenFieldNames));
		
		//save the field names array by calling the /rest/preferences web service
		caseMgmtFactory.saveUserPreferences($scope.restURL, $scope.userId, $scope.tableCols, JSON.stringify(hiddenFieldNames), null).then(function(response) {
			//hide full page overlay
			$.LoadingOverlay("hide");
			
			//present message to user stating that preferences have been saved
			showGrowl('<i class=\'fa fa-info-circle\' aria-hidden=\'true\'></i> ASR Summary preferences have been saved.', 'info');
		}).catch(function(err){ 
			//hide full page overlay
			$.LoadingOverlay("hide");			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> User preferences not saved due to ' + err.status, 'danger');
		});
	}

	//get the ASR Summary Data for the Modal Windows
	$scope.viewModalSummaryData  = function(pAsrId, pModalType, pPriortyScore) {
		
		//show full page overlay
		$.LoadingOverlay("show");
		
		//call the summary Modal service
		//call the factory method to get the property from the property file
		caseMgmtFactory.getSummaryModalData($scope.restURL, pAsrId, $scope.userId, pModalType).success(function(data) {
			
			console.log('Response Data from SummaryModalData = ' + JSON.stringify(data.responseData));
			
			//hide modal overlay
    		$.LoadingOverlay("hide");
			
		}).error(function(data, status) {
			console.log('getASRDetailsData REST Error:' + status);
			
			//hide modal overlay
    		$.LoadingOverlay("hide");
			
			//show message to user that assign to user failed
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> ' + status, 'danger');
		});
	}

	//this function calls the user tracking service
	$scope.trackUserActivity = function(pPageId, pTrackVal) {
		
		//call the user tracking web service to denote the fact that the user has requested a Google Map
		utilFactory.getTrackUserActivity($scope.restURL, $scope.scopeUserId, pPageId, pTrackVal).then(function(response) {
			console.log('getTrackUserActivity web service call successful.');
		}).catch(function(err) {
			console.log('getTrackUserActivity REST Error:' + err.data);			
		});		
	}

	// the user clicked the Prioritize for UCM button on the Case Mgmt screen
	$scope.prioritizeUCMBtnClick = function() {
		
		//		console.log('Inside prioritizeUCMBtnClick. User Zone = ' + $scope.userZone);
				
		// set default to do not show tiger team zones	
		$scope.showPriorUcmZones = false;
		
		//allow prioritization for Admin users, PrioritizeSup users, MAC (asrPrioritization=1)
		if ($scope.rolesArray.indexOf("Admin") != -1  
				|| $scope.rolesArray.indexOf("Prioritize Sup") != -1
				|| ($scope.rolesArray.indexOf("MAC") != -1 && $scope.userAttrArray.indexOf('ASR Prioritization') != -1)) {
			
			// variable to allow/disallow prioritization
			var allowPrioritization = true;	
			var errorMsg = '';
							
			//user is authorized to prioritize ASR
			//assign ASR Summary table selections to scope level variable
			if($scope.currentASRview == 'medicare'){
				$scope.asrSumTableSelections = $('#asrMgmtTable').bootstrapTable('getSelections');
			}
			else{
				$scope.asrSumTableSelections = $('#asrMDCDTable').bootstrapTable('getSelections');
			} 
				
			//check to see if user selected at least one ASR from summary table
			if($scope.asrSumTableSelections.length > 0) {
				console.log('# of selected ASRs from Summary table = ' + $scope.asrSumTableSelections.length);
				
				
				
				
				// check for PrioritizeSup role
				if ($scope.rolesArray.indexOf("Prioritize Sup") != -1)
				{
					console.log('User zone = ' + $scope.userZone + ', allowPrioritization = ' + allowPrioritization);
					
					// user has MEDIC jurisdiction - can only prioritize Part D ASRs
					if ($scope.userZone == 'MEDIC') {
						//loop through the selections, and check the claim type for each ASR
						for (i = 0; i < $scope.asrSumTableSelections.length; i++) {
							console.log('hasPartD Claims = ' + $scope.asrSumTableSelections[i].hasPartD);
							
							if ($scope.asrSumTableSelections[i].hasPartD == "N") {
								allowPrioritization = false;
								errorMsg = 'The prioritization of this ASR is not permitted because the ASR is not associated with Part D claims.';
								
								break;
							}
						}
					} //else if ($scope.userZone != 'UPIC 1' && $scope.userZone != 'UPIC 2' && $scope.userZone != 'UPIC 3' 
						//	&& $scope.userZone != 'UPIC 4' && $scope.userZone != 'UPIC 5') {
						
					//	allowPrioritization = false;
					//	errorMsg = 'You do not have the proper permissions to perform this action.';
					//}
					
					
					/*// check to see if user has the tiger team attribute 
					if ($scope.userAttrArray.indexOf("CPI Assigned") != -1) {
						console.log('User is a Tiger Team member.');
						
						// show modal overlay
//						$("#priorZonesSelect").LoadingOverlay("show");
						
						// set the variable used to hide/show the jurisdiction dropdown
						$scope.showPriorUcmZones = true;
						
						// call the refdata service to get the jurisdiction dropdown
						caseMgmtFactory.getPrioritizationZones($scope.restURL).then(function(response) {
							$scope.priorZonesOptions = response.data.zones;
							
							// hide the modal body overlay
							$("#priorZonesSelect").LoadingOverlay("hide");
						}).catch(function(err){ 
							// hide the modal body overlay
							$("#priorZonesSelect").LoadingOverlay("hide");
							
							showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Jurisdiction data could not be loaded due to ' + err.status, 'danger');
						});
					}*/
				}
				
				if (allowPrioritization == true) {
					
					console.log('2890 ------------------------->');
					//show modal window asking the user to confirm submission and enter comments
					$("#prioritizeUCMModalBody").LoadingOverlay("show");
					
					// 	Load Prioritize for UCM table FPS
					
					console.log("prioritizeForUCMTable -> ",$scope.asrSumTableSelections );
					var asrptids =  [];//[632505, 633951,634663  ];
					
					for(i=0; i< $scope.asrSumTableSelections.length; i++){
						asrptids.push($scope.asrSumTableSelections[i].asrDbid);
					}

					$("#prioritizeForUCMTable").bootstrapTable({});
					$("#prioritizeForUCMTableMdcd").bootstrapTable({});
					// call the refdata service to get the jurisdiction dropdown
					caseMgmtFactory.getPrioritizationZones($scope.restURL).then(function(response) {
						$scope.priorZonesOptions = response.data.zones;
						console.log('2907 ----------------------->');
						console.log('here is the zones that came in')
						console.log($scope.priorZonesOptions);
						
						caseMgmtFactory.getPrioritizeForUCMTable($scope.restURL, asrptids, $scope.currentASRview, $scope.userId).then(function(response) {
								console.log("prioritizeForUCMTable ->", response);
								console.log('<<<<--------here is the response------->>')	
								console.log(response)
								$scope.prioritizeForUCMTableData = response.data;
								console.log('2912 ----------------------->');
								console.log('here is the response data');
								console.log($scope.prioritizeForUCMTableData);
								$('.priortizeAlerts').css('color', '');
								$('.priortizeJurisdiction').css('color', '');
								$('.priortizeState').css('color', '');
								$('.priortizeComments').css('color', '');
								
								
								$("#prioritizeUCMModal").modal("show");
								 
								
								$("#prioritizeForUCMTable").bootstrapTable({});
								$("#prioritizeForUCMTable").bootstrapTable('load',$scope.prioritizeForUCMTableData );
								
								$("#prioritizeForUCMTableMdcd").bootstrapTable({});
								$("#prioritizeForUCMTableMdcd").bootstrapTable('load',$scope.prioritizeForUCMTableData );
								console.log('<-------- here is the data we are loading the prioritizeForUCMTableData -------> ');
								console.log($scope.prioritizeForUCMTableData);								
								// check to see if user has the tiger team attribute
								// IT GOES HERE CHRIS *******************************
//								if($scope.currentASRview == 'medicare'){
//									$('#prioritizeForUCMTable').bootstrapTable('hideColumn', 'states');
//								}
								if ($scope.userAttrArray.indexOf("CPI Assigned") != -1) {
									console.log('User is a Tiger Team member.');
									console.log('Show Jurisdiction Column');
									
								}else {
									// hide the zurisdiction column if the user is not belongs to CPI
									console.log('the zurisdiction column shows in the else');
									$('#prioritizeForUCMTable').bootstrapTable('hideColumn', 'zone');
									$("#prioritizeForUCMTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="zone"]').parent().hide();
								}
								
								$("#prioritizeUCMModalBody").LoadingOverlay("hide");
								
							}).catch(function(err){ 	
								$("#prioritizeUCMModalBody").LoadingOverlay("hide");
								showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Proritize for UCM table could not be loaded due to ' + err.status, 'danger');
								
							});
						
						
						// hide the modal body overlay
//						$("#priorZonesSelect").LoadingOverlay("hide");
						console.log("$scope.priorZonesOptions ->", $scope.priorZonesOptions);
					}).catch(function(err){ 
						// hide the modal body overlay
//						$("#priorZonesSelect").LoadingOverlay("hide");
						$("#prioritizeUCMModalBody").LoadingOverlay("hide");
						
						showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Jurisdiction data could not be loaded due to ' + err.status, 'danger');
					});
					
					
				} else {
					// user not authorized to prioritize ASRs
					
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> ' + errorMsg, 'danger');
				}
				
			}  else {		   			
				//no ASRs were chosen from the table
				console.log('Canceling Prioritize for UCM because no ASRs were selected.');			
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i>Please select ASR(s) to prioritize.', 'danger');
			}
		} else {
			//user is NOT authorized to prioritize ASR 
			//console.log('Logged-in user is not permitted to Prioritize for UCM');
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> You do not have the proper permissions to perform this action.', 'danger');
		}
		$("#modalPrioritizeUCMBtn").removeClass("disabled");
		$("#modalPrioritizeUCMBtn").prop("disabled", false);
	}

	//user clicked the Submit Prioritize for UCM button from the Prioritize for UCM modal window
	$scope.modalPrioritizeUCMBtnClick = function() {

		$("#modalPrioritizeUCMBtn").addClass("disabled");
		$("#modalPrioritizeUCMBtn").prop("disabled", true);	
		
		//show modal overlay
		console.log('Inside modalPrioritizeUCMBtnClick.');
		var dataList = $scope.prioritizeForUCMTableData;
		
		var prioritiesArray = [];
		var exitFlag = false;
		var showErrorMsg = false;
		var alertError = false;
		var jurisdictionError = false;
		var stateError = false;
		var commentError = false;

		//check if states are in jursidiction
		var checkEmptyStates = false;
		if($scope.currentASRview == "medicaid" && dataList.length == 1){
			for ( var checkAlerts = 0; checkAlerts < dataList.length; checkAlerts++){
				if(dataList[checkAlerts].alerts){
					for(var emptyStates = 0; emptyStates < dataList[checkAlerts].alerts.length; emptyStates++){
						if(dataList[checkAlerts].alerts[emptyStates].states.length > 0){
							 checkEmptyStates = true;
						}
					}
				}
			}
			if(!checkEmptyStates){
				showGrowl('<i aria-hidden=\'true\'></i> Prioritization to UCM can only be done for models that have alerted in a state(s) within your jurisdiction', 'danger');
				$("#modalPrioritizeUCMBtn").removeClass("disabled");
				$("#modalPrioritizeUCMBtn").prop("disabled", false);			
							return
			}
		}

		for (i = 0; i < dataList.length; i++) {
			var selectedStatesValue = [];
			var selectedDropdownValues = [];
			var selectedStates = null;
			console.log("---", dataList[i].asrptId);
			selectedStatesValue = $('#stateselectId' + dataList[i].asrptId).val();
			selectedDropdownValues = $('#selectId' + dataList[i].asrptId).val()

			if (selectedStatesValue != undefined && selectedStatesValue.length > 0) {
				var selectedStates = selectedStatesValue[0].split(' ')[0];
				var selectedStatecheck = selectedStatesValue.flatMap(item => {
					const statesMatch = item.match(/\((.*?)\)/g);
					return statesMatch ? statesMatch.map(match => match.slice(1, -1)) : [];
				});
			}
			if (selectedDropdownValues.length > 0) {
				var selectedAlerts = selectedDropdownValues.flatMap(item => {
					const statesMatch = item.match(/\((.*?)\)/g);
					return statesMatch ? statesMatch.map(match => match.slice(1, -1)) : [];
				});
			}
			console.log("selectval->", $('#selectId' + dataList[i].asrptId).val());
			console.log("CommentText->", $('#commentsTextArea' + dataList[i].asrptId).val());
			console.log("stateselectId->", selectedStates);


			// Default to current userzone .
			var userZone = $scope.userZone;
			var states = null;
			console.log("userZone ->", userZone);
			if ($scope.userAttrArray.indexOf('CPI Assigned') != -1) {
				console.log('User is a Tiger Team member.');
				if ($('#selectIdZone' + dataList[i].asrptId).val() == "") {
					// showGrowl('<i aria-hidden=\'true\'></i> Please select a Jurisdiction before continuing.', 'danger');
					$('#selectIdZone' + dataList[i].asrptId).css('border-color', 'red');
					showErrorMsg = true;
					jurisdictionError = true;
					exitFlag = true;

				} else {
					$('#selectIdZone' + dataList[i].asrptId).css('border-color', '');
					userZone = $('#selectIdZone' + dataList[i].asrptId).val();
				}
			} else {

				// Force user to select a alert if user is not a tiger team member
				console.log('User is a NOT Tiger Team member.');
				if (dataList[i].alerts.length > 0 && $('#selectId' + dataList[i].asrptId).val() == "" && $scope.currentASRview == "medicare") {
					// showGrowl('<i aria-hidden=\'true\'></i> Please correct the error(s) before continuing.', 'danger');
					$('#selectId' + dataList[i].asrptId).css('border-color', 'red');
					showErrorMsg = true;
					alertError = true;
					exitFlag = true;

				}
				else if (dataList[i].alerts.length > 0 && $('#selectId' + dataList[i].asrptId).val() == "" && $scope.currentASRview == "medicaid"
					&& !document.getElementById($('#selectId' + dataList[i].asrptId)[0].id).disabled) {
					// showGrowl('<i aria-hidden=\'true\'></i> Please correct the error(s) before continuing.', 'danger');
					$('#selectId' + dataList[i].asrptId).css('border-color', 'red');
					showErrorMsg = true;
					alertError = true;
					exitFlag = true;

				}
				else {
					$('#selectId' + dataList[i].asrptId).css('border-color', '');
				}
				const isalertDisabled = document.getElementById($('#selectId' + dataList[i].asrptId)[0].id).disabled
				if ($scope.currentASRview == "medicaid" && (selectedStates == "" || selectedStates == null) &&
					!isalertDisabled) {
					{
						$('#stateselectId' + dataList[i].asrptId).css('border-color', 'red');
						showErrorMsg = true;
						stateError = true;
						exitFlag = true;
					}
				}
				else if ($scope.currentASRview == "medicaid" && selectedStates != null) {

					if (!selectedAlerts.every(value => selectedStatecheck.includes(value))) {
						$('#stateselectId' + dataList[i].asrptId).css('border-color', 'red');
						showErrorMsg = true;
						stateError = true;
						exitFlag = true;

					}

					else {
						$('#stateselectId' + dataList[i].asrptId).css('border-color', '');
					}

				}
				else {
					$('#stateselectId' + dataList[i].asrptId).css('border-color', '');
				}

				//Force user to enter comment if there are no alerts for the given asr.
				if (dataList[i].alerts.length == 0 && $('#commentsTextArea' + dataList[i].asrptId).val() == "") {
					// showGrowl('<i aria-hidden=\'true\'></i> Please add a comment before continuing.', 'danger');
					$('#commentsTextArea' + dataList[i].asrptId).css('border-color', 'red');
					showErrorMsg = true;
					commentError = true;
					exitFlag = true;
				}
				else {
					$('#commentsTextArea' + dataList[i].asrptId).css('border-color', '');
				}
			}



			var priorityObj = {};
			// Set the values for saving when priortize.			
			priorityObj.asrDbId = dataList[i].asrptId;
			priorityObj.userId = $scope.userId;
			// set the zone to the current user's zone
			priorityObj.zone = userZone;
			priorityObj.states = states;
			priorityObj.programType = $scope.currentASRview;
			priorityObj.comments = $sanitize($('#commentsTextArea' + dataList[i].asrptId).val());
			var asrPrioritizationModelItems = dataList[i].alerts;
			var selectedDropdownValues = $('#selectId' + dataList[i].asrptId).val()
			for (k = 0; k < selectedDropdownValues.length; k++) {
				for (j = 0; j < asrPrioritizationModelItems.length; j++) {
					var modelBusnsId = asrPrioritizationModelItems[j].modelBusnsId;
					var modelBusnsIdStatus = asrPrioritizationModelItems[j].modelBusnsId + '(' + asrPrioritizationModelItems[j].status + ')';
					if (selectedDropdownValues[k] == modelBusnsIdStatus) {
						asrPrioritizationModelItems[j].prioritizedInd = "Y";
						console.log("Flag set for alert-", modelBusnsId);
					}

					if ($scope.currentASRview == "medicaid") {
						var existingStatesList = asrPrioritizationModelItems[j].states;
						var tempStates = [];
						// for (m = 0; selectedStates && m < selectedStates.length; m++) {
						//							console.log( selectedStates[m]);
						var found = existingStatesList.find(t => t.state == selectedStates);
						if (found) {
							console.log("push the state:", selectedStates);
							tempStates.push(found);
						}
						// }

						console.log("tempstates - ", tempStates);
						if (!exitFlag)
							asrPrioritizationModelItems[j].states = tempStates;
					}
				}
			}

			if (!exitFlag) {
				priorityObj.asrPrioritizationModelItems = asrPrioritizationModelItems;
				priorityObj.programType = $scope.currentASRview;
				prioritiesArray.push(priorityObj);
				console.log("priorityObj -", priorityObj);
			}

		}
		$('.priortizeAlerts').css('color', alertError ? 'red' : '');
		$('.priortizeJurisdiction').css('color', jurisdictionError ? 'red' : '');
		$('.priortizeState').css('color', stateError ? 'red' : '');
		$('.priortizeComments').css('color', commentError ? 'red' : '');
		
		if (showErrorMsg) {
			showGrowl('<i aria-hidden=\'true\'></i> Please correct the error(s) before continuing.', 'danger');
		}
		
		// Terminate the loop when there are any required fields to be entered by the user
		if (exitFlag) {
			$("#modalPrioritizeUCMBtn").removeClass("disabled");
			$("#modalPrioritizeUCMBtn").prop("disabled", false);
			return;
		}
			

		// Proceed prioritize all required fields entered by the user.
		$("#prioritizeUCMModalBody").LoadingOverlay("show");
//		console.log("prioritiesArray ->", prioritiesArray);		
		
		
		caseMgmtFactory.prioritizeASRForUCM($scope.restURL, $scope.userId, prioritiesArray).then(function (response) {
			// Hide modal LoadingOverlay
			$("#prioritizeUCMModalBody").LoadingOverlay("hide");
			$("#modalPrioritizeUCMBtn").removeClass("disabled");
			
			//show growl success message
			showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i>  ASRs successfully Prioritized for UCM.', 'success');
			$("#prioritizeUCMModal").modal("hide");
			$('.priortizeAlerts').css('color', '');
			$('.priortizeJurisdiction').css('color', '');
			$('.priortizeState').css('color', '');
			$('.priortizeComments').css('color', '');
			
		}).
			catch(function (err) {
			console.log("prioritizeASRForUCM REST Error: " + err.status);
			//$("#asrMgmtTable").bootstrapTable('hideLoading');
			// Hide modal LoadingOverlay
			$("#prioritizeUCMModalBody").LoadingOverlay("hide");
			$("#prioritizeUCMModal").modal("hide");
			$('.priortizeAlerts').css('color', '');
			$('.priortizeJurisdiction').css('color', '');
			$('.priortizeState').css('color', '');
			$('.priortizeComments').css('color', '');
			$("#modalPrioritizeUCMBtn").removeClass("disabled");
			$("#modalPrioritizeUCMBtn").prop("disabled", false);	
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Prioritize ASRs for UCM failed due to ' + err.status, 'danger');
		});
	}
	// verify ASRs button has been clicked
	$scope.verifyAsrBtn = function(asrtype) {
		console.log('Inside verifyAsrBtn', asrtype);
		
		// show the button overlay
		$("#verifyButton").LoadingOverlay("show");
		
		if ($scope.searchAsrId === void(0) || $scope.searchAsrId === null || $scope.searchAsrId === '') {
			// hide the button overlay
			$("#verifyButton").LoadingOverlay("hide");
			
			// show growl message saying there are no ASRs to verify
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Please enter ASR(s) to verify. ' + status, 'danger');
		} else {
			// get the number of lines in the text area
			var lines = $('#searchAsrId').val().trim().split('\n');
			console.log('# of ASRs = ' + lines.length);
			
			// check to see if the user entered more than 200 ASRs
			if (lines.length > 200) {
				console.log('Please limit the number of ASRs to 200 or less.');
				
				// hide the verify button overlay
				$("#verifyButton").LoadingOverlay("hide");
				
				// set form field as invalid
				$scope.searchForm.searchAsrId.$setValidity('asriderror', false);
			} else {
				// there are less than 200 entries... so process ASRs
				// set form field as valid
				$scope.searchForm.searchAsrId.$setValidity('asriderror', true);
				
				var verifyAsrArray = [];
				
				// create a variable to denote invalid ASR format
				var asrFormatBool = true;
				var regExNpi = new RegExp("^([0-9]{10})$");
				
				
				// loop through the ASRs and create the request array
				for (i = 0; i < lines.length; i++) {
					// check to make sure NPI is 10 digits
					if(!regExNpi.test(lines[i])) {
						// not a valid NPI format
						// reset the verifyAsrArray
						var verifyAsrArray = [];
						
						// set boolean to false
						asrFormatBool = false;
						
						// set form field as invalid
						$scope.searchForm.searchAsrId.$setValidity('asrformaterror', false);
						
						// hide the button overlay
						$("#verifyButton").LoadingOverlay("hide");
						
						// show message to the user
						showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> The following NPI has an incorrect format: ' + $sanitize($scope.escapeHTML(lines[i])), 'danger');
						
						break;
						
					} else {
						// set form field as valid
						$scope.searchForm.searchAsrId.$setValidity('asrformaterror', true);	
						
						verifyAsrArray.push(lines[i]);
					}
					
				}
				
				if (asrFormatBool) {
					// call the web service to verify the ASRs				
					var asrVerifySearchObj = utilService.getSearchReqObj();
					asrVerifySearchObj.asrptIds = verifyAsrArray;
					
					// add the user id to the search request
					asrVerifySearchObj.loggedInUserId = $scope.userId;
					
					if (asrtype == "medicare") {
						caseMgmtFactory.verifyASRs($scope.restURL, asrVerifySearchObj).then(function(response) {
							var respDataArray = response.data.responseData;
							
							if (respDataArray.length == 0 ){
								// all ASR in the list are valid, so return message to the user
								showGrowl('<i class=\'fa fa-info-circle\' aria-hidden=\'true\'></i> An ASR exists for all NPIs entered.', 'success');
							} else {
								var asrMsg = '';
								
								// not all ASRs are valid so collect invalid ASRs and present them to the user
								for (t = 0; t < respDataArray.length; t++) { 
									if (t == respDataArray.length-1) {
										asrMsg += respDataArray[t].asrId
									} else {
										asrMsg += respDataArray[t].asrId + ", ";
									}
								}
								
								// show message to the user
								showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> The following NPI(s) do not have an existing ASR: ' + $sanitize(asrMsg), 'danger');
							}
							
							// hide the button overlay
							$("#verifyButton").LoadingOverlay("hide");
						}).
						catch(function(err){    			
							console.log("Verify ASR REST Error: " + err.status);
							
							// hide the button overlay
							$("#verifyButton").LoadingOverlay("hide");
							
							showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> ASR verification failed due to ' + err.status, 'danger');
						});
					} else if (asrtype == "medicaid") {
						
						caseMgmtFactory.verifyMdcdAsrs($scope.restURL, asrVerifySearchObj).then(function(response) {
							var respDataArray = response.data.responseData;
							
							if (respDataArray.length == 0 ){
								// all ASR in the list are valid, so return message to the user
								showGrowl('<i class=\'fa fa-info-circle\' aria-hidden=\'true\'></i> An ASR exists for all NPIs entered.', 'success');
							} else {
								var asrMsg = '';
								
								// not all ASRs are valid so collect invalid ASRs and present them to the user
								for (t = 0; t < respDataArray.length; t++) { 
									if (t == respDataArray.length-1) {
										asrMsg += respDataArray[t].asrId
									} else {
										asrMsg += respDataArray[t].asrId + ", ";
									}
								}
								
								// show message to the user
								showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> The following NPI(s) do not have an existing ASR: ' + asrMsg, 'danger');
							}
							
							// hide the button overlay
							$("#verifyButton").LoadingOverlay("hide");
						}).
						catch(function(err){    			
							console.log("Verify ASR REST Error: " + err.status);
							
							// hide the button overlay
							$("#verifyButton").LoadingOverlay("hide");
							
							showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> ASR verification failed due to ' + err.status, 'danger');
						});
						
						
					}
				
					
					
				}
				
			}
		}
	}

	// validate the biu search field
	$scope.checkBIUField = function() {
		console.log('Validating BIU Search Field...');
		
		// see if the there is a value in the searchBiuComplaintDays field
//		console.log('Value of complaints number field = ' + $scope.searchBiuComplaints);
//		console.log('Value of complaints day field = ' + $scope.searchBiuComplaintDays);
		
		if (($scope.searchBiuComplaints != void(0) && $scope.searchBiuComplaints != null && $scope.searchBiuComplaints != '')) {
			// validate the counts field for numbers only
			var regExNumber = new RegExp("^(\\d+)$");
			console.log("regExNumber = " + regExNumber.test($scope.searchBiuComplaints));
			
		    if (regExNumber.test($scope.searchBiuComplaints)) {
		    	$scope.searchForm.searchBiuComplaints.$setValidity('checkbiunumerror', true);
		    } else {
		    	$scope.searchForm.searchBiuComplaints.$setValidity('checkbiunumerror', false);
		    }
		}
		
		// validate the days field
		if (($scope.searchBiuComplaints != void(0) && $scope.searchBiuComplaints != null && $scope.searchBiuComplaints != '') 
			&& ($scope.searchBiuComplaintDays == void(0) || $scope.searchBiuComplaintDays == null || $scope.searchBiuComplaintDays == '')) {
			
			console.log('count field has a value, but day field does not - validate field');
			
			$scope.searchForm.searchBiuComplaintDays.$setValidity('checkbiudayserror', false);
		} else {
			$scope.searchForm.searchBiuComplaintDays.$setValidity('checkbiudayserror', true);
		}
		
		// validate the counts field
		if (($scope.searchBiuComplaintDays != void(0) && $scope.searchBiuComplaintDays != null && $scope.searchBiuComplaintDays != '') 
				&& ($scope.searchBiuComplaints == void(0) || $scope.searchBiuComplaints == null || $scope.searchBiuComplaints == '')) {
			console.log('days field has a value, but count field does not - validate field');
			
			$scope.searchForm.searchBiuComplaints.$setValidity('checkbiuerror', false);
		} else {
			$scope.searchForm.searchBiuComplaints.$setValidity('checkbiuerror', true);
		}
	}

	// validate the number range fields
	$scope.checkScore = function(pInputName, pMinVal, pMaxVal) {
		console.log('checkScore - Form validity = ' + $scope.searchForm.$valid);
		console.log('Input name = ' + pInputName + ', min val = ' + pMinVal + ', max val = ' + pMinVal);
		
		if (pMinVal != void(0) && pMinVal != null && pMaxVal != void(0) && pMaxVal != null && (pMinVal > pMaxVal)) {
			if (pInputName == 'searchRiskScoreMin' || pInputName == 'searchRiskScoreMax') {				
				$scope.searchForm.searchRiskScoreMin.$setValidity('checkscoreerror', false);
				$scope.searchForm.searchRiskScoreMax.$setValidity('checkscoreerror', false);
			} else if (pInputName == 'searchPriorityScoreMin' || pInputName == 'searchPriorityScoreMax') {				
				$scope.searchForm.searchPriorityScoreMin.$setValidity('checkscoreerror', false);
				$scope.searchForm.searchPriorityScoreMax.$setValidity('checkscoreerror', false);
			} else if (pInputName == 'searchSubmittedAmtMin' || pInputName == 'searchSubmittedAmtMax') {				
				$scope.searchForm.searchSubmittedAmtMin.$setValidity('checkscoreerror', false);
				$scope.searchForm.searchSubmittedAmtMax.$setValidity('checkscoreerror', false);
			} else if (pInputName == 'searchTotalPayMin' || pInputName == 'searchTotalPayMax') {				
				$scope.searchForm.searchTotalPayMin.$setValidity('checkscoreerror', false);
				$scope.searchForm.searchTotalPayMax.$setValidity('checkscoreerror', false);
			} else if (pInputName == 'searchTtlPayPartDMin' || pInputName == 'searchTtlPayPartDMax') {				
				$scope.searchForm.searchTtlPayPartDMin.$setValidity('checkscoreerror', false);
				$scope.searchForm.searchTtlPayPartDMax.$setValidity('checkscoreerror', false);
			} else if (pInputName == 'searchAsrCostMin' || pInputName == 'searchAsrCostMax') {				
				$scope.searchForm.searchAsrCostMin.$setValidity('checkscoreerror', false);
				$scope.searchForm.searchAsrCostMax.$setValidity('checkscoreerror', false);
			} else if (pInputName == 'searchphase1AsrCostMin' || pInputName == 'searchphase1AsrCostMax') {				
				$scope.searchForm.searchphase1AsrCostMin.$setValidity('checkscoreerror', false);
				$scope.searchForm.searchphase1AsrCostMax.$setValidity('checkscoreerror', false);
			} else if (pInputName == 'searchSubmittedAmtDMin' || pInputName == 'searchSubmittedAmtDMax') {				
				$scope.searchForm.searchSubmittedAmtDMin.$setValidity('checkscoreerror', false);
				$scope.searchForm.searchSubmittedAmtDMax.$setValidity('checkscoreerror', false);
			} else if (pInputName == 'searchTimelinessDtMin' || pInputName == 'searchTimelinessDtMax') {				
				$scope.searchForm.searchTimelinessDtMin.$setValidity('checkscoreerror', false);
				$scope.searchForm.searchTimelinessDtMax.$setValidity('checkscoreerror', false);
			}
		} else {
			if (pInputName == 'searchRiskScoreMin' || pInputName == 'searchRiskScoreMax') {				
				$scope.searchForm.searchRiskScoreMin.$setValidity('checkscoreerror', true);
				$scope.searchForm.searchRiskScoreMax.$setValidity('checkscoreerror', true);
			} else if (pInputName == 'searchPriorityScoreMin' || pInputName == 'searchPriorityScoreMax') {				
				$scope.searchForm.searchPriorityScoreMin.$setValidity('checkscoreerror', true);
				$scope.searchForm.searchPriorityScoreMax.$setValidity('checkscoreerror', true);
			} else if (pInputName == 'searchSubmittedAmtMin' || pInputName == 'searchSubmittedAmtMax') {				
				$scope.searchForm.searchSubmittedAmtMin.$setValidity('checkscoreerror', true);
				$scope.searchForm.searchSubmittedAmtMax.$setValidity('checkscoreerror', true);
			} else if (pInputName == 'searchTotalPayMin' || pInputName == 'searchTotalPayMax') {				
				$scope.searchForm.searchTotalPayMin.$setValidity('checkscoreerror', true);
				$scope.searchForm.searchTotalPayMax.$setValidity('checkscoreerror', true);
			} else if (pInputName == 'searchTtlPayPartDMin' || pInputName == 'searchTtlPayPartDMax') {				
				$scope.searchForm.searchTtlPayPartDMin.$setValidity('checkscoreerror', true);
				$scope.searchForm.searchTtlPayPartDMax.$setValidity('checkscoreerror', true);
			} else if (pInputName == 'searchAsrCostMin' || pInputName == 'searchAsrCostMax') {				
				$scope.searchForm.searchAsrCostMin.$setValidity('checkscoreerror', true);
				$scope.searchForm.searchAsrCostMax.$setValidity('checkscoreerror', true);
			} else if (pInputName == 'searchphase1AsrCostMin' || pInputName == 'searchphase1AsrCostMax') {				
				$scope.searchForm.searchphase1AsrCostMin.$setValidity('checkscoreerror', true);
				$scope.searchForm.searchphase1AsrCostMax.$setValidity('checkscoreerror', true);
			} else if (pInputName == 'searchSubmittedAmtDMin' || pInputName == 'searchSubmittedAmtDMax') {				
				$scope.searchForm.searchSubmittedAmtDMin.$setValidity('checkscoreerror', true);
				$scope.searchForm.searchSubmittedAmtDMax.$setValidity('checkscoreerror', true);
			} else if (pInputName == 'searchTimelinessDtMin' || pInputName == 'searchTimelinessDtMax') {				
				$scope.searchForm.searchTimelinessDtMin.$setValidity('checkscoreerror', true);
				$scope.searchForm.searchTimelinessDtMax.$setValidity('checkscoreerror', true);
			}
		}
	}

	//validate the date fields 
	$scope.checkDate = function(pInputName, pStartDate, pEndDate) {
		console.log('checkDate - Form validity = ' + $scope.searchForm.$valid);
		console.log('Input name = ' + pInputName + ', start date = ' + pStartDate + ', end date = ' + pEndDate);
		
		if (pStartDate != void(0) && pStartDate != null && pEndDate != void(0) && pEndDate != null && (new Date(pStartDate) > new Date(pEndDate))) {
			console.log('Invalid - start date is larger than end date');
			
			if (pInputName == 'searchClmSbtDtMin' || pInputName == 'searchClmSbtDtMax') {				
				$scope.searchForm.searchClmSbtDtMin.$setValidity('checkdateerror', false);
				$scope.searchForm.searchClmSbtDtMax.$setValidity('checkdateerror', false);
			} else if (pInputName == 'searchLastAlertClmDtMin' || pInputName == 'searchLastAlertClmDtMax') {				
				$scope.searchForm.searchLastAlertClmDtMin.$setValidity('checkdateerror', false);
				$scope.searchForm.searchLastAlertClmDtMax.$setValidity('checkdateerror', false);
			} else if (pInputName == 'searchLastphase1AlertClmDtMin' || pInputName == 'searchLastphase1AlertClmDtMax') {				
				$scope.searchForm.searchLastphase1AlertClmDtMin.$setValidity('checkdateerror', false);
				$scope.searchForm.searchLastphase1AlertClmDtMax.$setValidity('checkdateerror', false);
			} else if (pInputName == 'searchLastEduDtMin' || pInputName == 'searchLastEduDtMax') {				
				$scope.searchForm.searchLastEduDtMin.$setValidity('checkdateerror', false);
				$scope.searchForm.searchLastEduDtMax.$setValidity('checkdateerror', false);
			} else if (pInputName == 'searchTpeLastEduDtMin' || pInputName == 'searchTpeLastEduDtMax') {				
				$scope.searchForm.searchTpeLastEduDtMin.$setValidity('checkdateerror', false);
				$scope.searchForm.searchTpeLastEduDtMax.$setValidity('checkdateerror', false);
			} else if (pInputName == 'searchAsrCreateDtMin' || pInputName == 'searchAsrCreateDtMax') {				
				$scope.searchForm.searchAsrCreateDtMin.$setValidity('checkdateerror', false);
				$scope.searchForm.searchAsrCreateDtMax.$setValidity('checkdateerror', false);
			} else if (pInputName == 'searchMdcrAsrCreateDtMin' || pInputName == 'searchMdcrAsrCreateDtMax') {				
				$scope.searchForm.searchMdcrAsrCreateDtMin.$setValidity('checkdateerror', false);
				$scope.searchForm.searchMdcrAsrCreateDtMax.$setValidity('checkdateerror', false);

				
			} 
			
		} else {
			if (pInputName == 'searchClmSbtDtMin' || pInputName == 'searchClmSbtDtMax') {				
				$scope.searchForm.searchClmSbtDtMin.$setValidity('checkdateerror', true);
				$scope.searchForm.searchClmSbtDtMax.$setValidity('checkdateerror', true);
			} else if (pInputName == 'searchLastAlertClmDtMin' || pInputName == 'searchLastAlertClmDtMax') {				
				$scope.searchForm.searchLastAlertClmDtMin.$setValidity('checkdateerror', true);
				$scope.searchForm.searchLastAlertClmDtMax.$setValidity('checkdateerror', true);
			} else if (pInputName == 'searchLastphase1AlertClmDtMin' || pInputName == 'searchLastphase1AlertClmDtMax') {				
				$scope.searchForm.searchLastphase1AlertClmDtMin.$setValidity('checkdateerror', true);
				$scope.searchForm.searchLastphase1AlertClmDtMax.$setValidity('checkdateerror', true);
			}else if (pInputName == 'searchLastEduDtMin' || pInputName == 'searchLastEduDtMax') {				
				$scope.searchForm.searchLastEduDtMin.$setValidity('checkdateerror', true);
				$scope.searchForm.searchLastEduDtMax.$setValidity('checkdateerror', true);
			} else if (pInputName == 'searchTpeLastEduDtMin' || pInputName == 'searchTpeLastEduDtMax') {				
				$scope.searchForm.searchTpeLastEduDtMin.$setValidity('checkdateerror', true);
				$scope.searchForm.searchTpeLastEduDtMax.$setValidity('checkdateerror', true);
			} else if (pInputName == 'searchAsrCreateDtMin' || pInputName == 'searchAsrCreateDtMax') {				
				$scope.searchForm.searchAsrCreateDtMin.$setValidity('checkdateerror', true);
				$scope.searchForm.searchAsrCreateDtMax.$setValidity('checkdateerror', true);
			} else if (pInputName == 'searchMdcrAsrCreateDtMin' || pInputName == 'searchMdcrAsrCreateDtMax') {				
				$scope.searchForm.searchMdcrAsrCreateDtMin.$setValidity('checkdateerror', true);
				$scope.searchForm.searchMdcrAsrCreateDtMax.$setValidity('checkdateerror', true);
			} 
		} 
	}

	//validate the Priority Score on the main search panel
	$scope.checkPriorityScoreMain = function() {	
		console.log('checkPriorityScoreMain - Min = ' + $scope.minPriorityScoreNumber + ', Max = ' + $scope.maxPriorityScoreNumber);
		
		if ($scope.minPriorityScoreNumber != void(0) && $scope.minPriorityScoreNumber != null && $scope.maxPriorityScoreNumber != void(0) && $scope.maxPriorityScoreNumber != null) {
			if($scope.minPriorityScoreNumber > $scope.maxPriorityScoreNumber) {
				console.log('Min Priority Score ' + $scope.minPriorityScoreNumber + ' is greater than Max Priority Score ' + $scope.maxPriorityScoreNumber);
				$scope.searchForm.minPriorityScoreNumber.$setValidity('rangepriorityerror', false);
				$scope.searchForm.maxPriorityScoreNumber.$setValidity('rangepriorityerror', false);
			} else {
				$scope.searchForm.minPriorityScoreNumber.$setValidity('rangepriorityerror', true);
				$scope.searchForm.maxPriorityScoreNumber.$setValidity('rangepriorityerror', true);
			}
		} else if($scope.minPriorityScoreNumber == null && $scope.maxPriorityScoreNumber == null) {
			//if both the min and max priority scores are null, then set the form fields as valid
			$scope.searchForm.minPriorityScoreNumber.$setValidity('rangepriorityerror', true);
			$scope.searchForm.maxPriorityScoreNumber.$setValidity('rangepriorityerror', true);
		}
	}

	//validate the Risk Score on the main search panel
	$scope.checkRiskScoreMain = function() {		
		console.log('checkRiskScoreMain - Min = ' + $scope.minRiskScoreNumber + ', Max = ' + $scope.maxRiskScoreNumber);
		//check to make sure the min risk number is smaller than the max risk number
		if ($scope.minRiskScoreNumber != void(0) && $scope.minRiskScoreNumber != null && $scope.maxRiskScoreNumber != void(0) && $scope.maxRiskScoreNumber != null) {

			if($scope.minRiskScoreNumber > $scope.maxRiskScoreNumber) {
				console.log('Min Risk Score ' + $scope.minRiskScoreNumber + ' is greater than Max Risk Score ' + $scope.maxRiskScoreNumber);
				$scope.searchForm.minRiskScoreNumber.$setValidity('rangeriskerror', false);
				$scope.searchForm.maxRiskScoreNumber.$setValidity('rangeriskerror', false);
			} else {
				$scope.searchForm.minRiskScoreNumber.$setValidity('rangeriskerror', true);
				$scope.searchForm.maxRiskScoreNumber.$setValidity('rangeriskerror', true);
			}
		} else if($scope.minRiskScoreNumber == null && $scope.maxRiskScoreNumber == null) {
			//if both the min and max risk scores are null, then set the form fields as valid
			$scope.searchForm.minRiskScoreNumber.$setValidity('rangeriskerror', true);
			$scope.searchForm.maxRiskScoreNumber.$setValidity('rangeriskerror', true);
		}
	}

	//validate the Risk Score on the advanced search panel
	$scope.checkRiskScoreAdv = function() {		
		//console.log('checkRiskScoreAdv - Min = ' + $scope.minRiskScoreNumberAdv + ', Max = ' + $scope.maxRiskScoreNumberAdv);
		//check to make sure the min risk number is smaller than the max risk number
		if ($scope.minRiskScoreNumberAdv != void(0) && $scope.minRiskScoreNumberAdv != null && $scope.maxRiskScoreNumberAdv != void(0) && $scope.maxRiskScoreNumberAdv != null) {

			if($scope.minRiskScoreNumberAdv > $scope.maxRiskScoreNumberAdv) {
				console.log('Risk Score range not valid. Min: ' + $scope.minRiskScoreNumberAdv + ' is greater than Max: ' + $scope.maxRiskScoreNumberAdv);
				$scope.advancedSearchForm.minRiskScoreNumberAdv.$setValidity('advrangeriskerror', false);
				$scope.advancedSearchForm.maxRiskScoreNumberAdv.$setValidity('advrangeriskerror', false);
			} else {
				$scope.advancedSearchForm.minRiskScoreNumberAdv.$setValidity('advrangeriskerror', true);
				$scope.advancedSearchForm.maxRiskScoreNumberAdv.$setValidity('advrangeriskerror', true);
			}
		} else if($scope.minRiskScoreNumberAdv == null && $scope.maxRiskScoreNumberAdv == null) {
			//if both the min and max risk scores are null, then set the form fields as valid
			$scope.advancedSearchForm.minRiskScoreNumberAdv.$setValidity('advrangeriskerror', true);
			$scope.advancedSearchForm.maxRiskScoreNumberAdv.$setValidity('advrangeriskerror', true);
		}
	}

	//validate Created Date on the advanced search panel
	$scope.checkCreatedDateAdv = function() {	
		console.log('checkCreatedDateAdv - Min = ' + $scope.customCreatedMinSearch + ', Max = ' + $scope.customCreatedMaxSearch);
		
		//check to make sure the min date is smaller than the max date
		if ($scope.customCreatedMinSearch != void(0) && $scope.customCreatedMinSearch != null && $scope.customCreatedMaxSearch != void(0) && $scope.customCreatedMaxSearch != null) {
			
			if (new Date($scope.customCreatedMinSearch) > new Date($scope.customCreatedMaxSearch)) {
				console.log('Min date ' + $scope.customCreatedMinSearch + ' is greater than Max date ' + $scope.customCreatedMaxSearch);
				$scope.advancedSearchForm.customCreatedMinSearch.$setValidity('advcreateddterror', false);
				$scope.advancedSearchForm.customCreatedMaxSearch.$setValidity('advcreateddterror', false);
			} else {
				$scope.advancedSearchForm.customCreatedMinSearch.$setValidity('advcreateddterror', true);
				$scope.advancedSearchForm.customCreatedMaxSearch.$setValidity('advcreateddterror', true);
			}
		}
	}
	$scope.escapeHTML = function(str) {
	  return str.replace(/[&<>"']/g, function(m) {
	    return {
	      '&': '&amp;',
	      '<': '&lt;',
	      '>': '&gt;',
	      '"': '&quot;',
	      "'": '&#39;'
	    }[m];
	  });
	} 
}]);

//define a factory to perform REST functionality
appCaseMgmt.factory('caseMgmtFactory', ['$http', '$rootScope', '$q',function($http, $rootScope, $q) {
	return {
		getCaseMgmtData: function(pURL, pSearchCriteriaObj) {
    		console.log("Inside caseMgmtFactory.getCaseMgmtData: ");
    		
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		//var entryCriteria = {
    		//	name: 'test'	
    		//};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(pSearchCriteriaObj);
    		console.log('getCaseMgmtData REST request = ' + jsonData);
    		
    		//make the rest web service call to get the data
    		return $http.post(pURL + '/rest/portal/caseMgmtSearch', jsonData);
    	},
		
		getModelInfo: function(pURL, infoModel, inforunDt, PInfoType, userId){
			$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			infoModel: infoModel,
    			infoDate: inforunDt,
				userId: userId
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		if(PInfoType == 'medicare'){
				return $http.post(pURL + '/rest/portal/infoModelMdcr', jsonData);
			}
			if(PInfoType == 'medicaid')
    		return $http.post(pURL + '/rest/portal/infoModelMdcd', jsonData); 

		},
    	verifyASRs: function(pURL, pSearchCriteriaObj) {
    		console.log("Inside caseMgmtFactory.verifyASRs.");
    		
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(pSearchCriteriaObj);
    		console.log('getCaseMgmtData REST request = ' + jsonData);
    		
    		//make the rest web service call to get the data
    		return $http.post(pURL + '/rest/portal/verifyAsrs', jsonData);
    	}, 
    	verifyMdcdAsrs: function(pURL, pSearchCriteriaObj) {
    		console.log("Inside caseMgmtFactory.verifyMdcdAsrs.");
    		
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(pSearchCriteriaObj);
    		console.log('getCaseMgmtData REST request = ' + jsonData);
    		
    		//make the rest web service call to get the data
    		return $http.post(pURL + '/rest/portal/verifyMdcdAsrs', jsonData);
    	}, 
    	mdcdTotalPayment: function(pURL,reqAsrDbid,reqUserId) {
    		console.log("Inside caseMgmtFactory.mdcdTotalPayment.");
    		
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			asrDbid: reqAsrDbid,
    			userId: reqUserId
    		};
    		
    		
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('mdcdTotalPayment REST request = ' + jsonData);
    		
    		//make the rest web service call to get the data
    		return $http.post(pURL + '/rest/portal/mdcdTotalPayment', jsonData);
    	}, 
    	addToExclusionList: function (pURL, pUserId, pAsrExReqObj){
    		console.log("Inside caseMgmtFactory.addToExclusionList factory method.");
    		
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			reqStr: JSON.stringify(pAsrExReqObj)
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		//make the rest web service call to get the data
    		return $http.post(pURL + '/rest/portal/addToExclusionList', jsonData);
    	},
    	getAllAlerts: function(pURL, pUserId) {
    		console.log("Inside caseMgmtFactory.getAllAlerts");
    		
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			userId: pUserId	
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getAllAlerts REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/queryAllAlerts', jsonData);    		
    		
    	},
    	getEditSearchCriteria: function(pURL, pSearchId, pUserId) {
    		console.log("Inside caseMgmtFactory.getEditSearchCriteria. pUserId = " + pUserId
    				+ "pSearchId = " + pSearchId);
    		
    		//create the json request object
    		var entryCriteria = {
    				searchId: pSearchId,	
    				userId: pUserId
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getEditSearchCriteria REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/editSearchCriteria', jsonData);
    		
    	},
    	getAllZones: function(pURL, pUserId) {
    		console.log("Inside caseMgmtFactory.getAllZones. pUserId = " + pUserId);
    		//console.log("pURL = " + pURL);
    		
    		//create the json request object
    		var entryCriteria = {
//    				noRequiredField: 'noRequiredValue'	
    				userId: pUserId
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getAllZones REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/queryAllZones', jsonData);    		
    		
    	},
     	getSummaryModalData: function(pURL, pAsrId, pUserId, pLinkType) {
    		console.log("Inside caseMgmtFactory.getSummaryModalData.  pUrl = " + pURL + ", pAsrId = " + pAsrId);
    		
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId: pUserId,
    			linkType: pLinkType
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getSummaryModalData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/querySummaryModalData', jsonData);
    	}, 
    	deleteUserPreferences: function(pURL, pUserId, pPrefName, pPrefJson, pPrefLabel) {
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			prefName: pPrefName,
    			prefJson: pPrefJson,
    			prefLbl: pPrefLabel
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('deleteUserPreferences REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/deleteUserPrefs', jsonData);
    	},
    	saveUserPreferences: function(pURL, pUserId, pPrefName, pPrefJson, pPrefLabel) {
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			prefName: pPrefName,
    			prefJson: pPrefJson,
    			prefLbl: pPrefLabel
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('saveUserPreferences REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/saveUserPrefs', jsonData);
    	},
    	getUserPreferences: function(pURL, pPrefName, pUserId, pPrefJson, pPrefLabel) {
			//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");

    		//create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			prefName: pPrefName,
    			prefJson: pPrefJson,
    			prefLbl: pPrefLabel 
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getUserPreferences REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/retrieveUserPrefs', jsonData);
    	},
    	prioritizeASRForUCM: function(pURL, pUserId, prioritiesArray) {
    		console.log("Inside prioritizeASRForUCM.  pUserId = " + pUserId );
    		
    		//broadcast this event to the reset session listener
//        	$rootScope.$broadcast("factoryMethodCalled"); 
    		
    		//create response similar to "priorities":[{"asrId", "userId", "zone", "comments"}]
    		var prioritiesObj = {};
    		prioritiesObj.priorities = [];
    		prioritiesObj.priorities = prioritiesArray;
    		
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(prioritiesObj);
    		console.log('prioritizeASRForUCM REST request = ' + jsonData);
    		console.log("URL ", pURL + '/rest/portal/prioritizeASRsForUCM');
    		
    		return $http.post(pURL + '/rest/portal/prioritizeASRsForUCM', jsonData);
    		
    	}, 
    	
    	
    	getPrioritizationZones: function(pURL) {
    		console.log("Inside caseMgmtFactory.getPrioritizationZones.");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    //			noRequiredField: 'noRequiredValue'	
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
  //  		console.log('getPrioritizationZones REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/queryPriorUcmZones', jsonData);  
    	},
    	getWorkItemsList: function(pURL, pWorkItemId, pinfoASRType, pUserId) {
    		console.log("Inside caseMgmtFactory.getWorkItemsList");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			workItemId: pWorkItemId	,
    			userId: pUserId
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
			if (pinfoASRType == 'MDCD')
				return $http.post(pURL + '/rest/portal/workItemListMdcd', jsonData);
			else
				return $http.post(pURL + '/rest/portal/workItemList', jsonData);
		},
    	getExclusionList: function (pURL, pWorkItemId, pUserId) {
    		console.log("Inside caseMgmtFactory.getExclusionList");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			workItemId: pWorkItemId,
    			userId: pUserId
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/exclusionList', jsonData); 
    		
    	},
    	getPicExclusionList: function (pURL, pWorkItemId, pUserId) {
    		console.log("Inside caseMgmtFactory.getPicExclusionList");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			workItemId: pWorkItemId,
    			userId: pUserId
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/picExclusionList', jsonData); 
    	},
    	getAsrQueryList: function(pURL, pUserId, pWorkItemId) {
    		console.log("Inside caseMgmtFactory.getAsrQueryList");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			workItemId: pWorkItemId,
    			userId: pUserId
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/workItemQueryList', jsonData); 
    	},
    	removeFromExList: function(pURL, pUserId, pWorkItemId, pAsrArray) {
    		console.log("Inside caseMgmtFactory.removeFromExList");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId, 	
    			workItemId: pWorkItemId,
    			asrptIds: pAsrArray
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/removeFromExList', jsonData);
    	},
    	removeFromList: function(pURL, pUserId, pWorkItemId, pAsrArray) {
    		console.log("Inside caseMgmtFactory.removeFromList");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId, 	
    			workItemId: pWorkItemId,
    			asrptIds: pAsrArray
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/removeFromList', jsonData);
    	},
    	createNewList: function(pURL, pUserId, pName, pDesc, pAsrArray) {
    		console.log("Inside caseMgmtFactory.createNewList");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// build the fpsPrioritizationList list object
    		var fpsPrioritizationListObj = {
				audtInsrtId: pUserId, 	
    			listNm: pName,
    			cmtTxt: pDesc,
    			fpsPrioritizationListItems: pAsrArray	
    		}
    		
    		// create the json request object
    		var entryCriteria = {
    			fpsPrioritizationList: fpsPrioritizationListObj
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/saveAsList', jsonData);
    	},

		createNewListMdcd: function(pURL, pUserId, pName, pDesc, pAsrArray) {
    		console.log("Inside caseMgmtFactory.createNewListMDCD");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// build the fpsPrioritizationList list object
    		var fpsPrioritizationListObj = {
				audtInsrtId: pUserId, 	
    			listNm: pName,
    			cmtTxt: pDesc,
    			fpsPrioritizationListItems: pAsrArray,
				listType : "WORKINGMDCD"	
    		}
    		
    		// create the json request object
    		var entryCriteria = {
    			fpsPrioritizationList: fpsPrioritizationListObj
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/saveAsList', jsonData);
    	},

    	getAddToExistInputVals: function(pURL, pUserId) {
    		console.log("Inside caseMgmtFactory.getAddToExistInputVals");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/addToExistInputVals', jsonData);
    	},
		getAddToExistInputValsMdcd: function(pURL, pUserId) {
    		console.log("Inside caseMgmtFactory.getAddToExistInputVals");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/addToExistInputValsMdcd', jsonData);
    	},
    	addToExistList: function(pURL, pUserId, pListId, pAsrArray) {
    		console.log("Inside caseMgmtFactory.addToExistList");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			workItemId: pListId,
    			asrptIds: pAsrArray
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/addToExistList', jsonData);
    	},
    	getSavedSearchList: function(pURL, pUserId) {
    		console.log("Inside caseMgmtFactory.getSavedSearchList");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/saveSearchList', jsonData);
    	},
    	getExclusionDetailData: function(pURL, pUserId, pAsrId) {
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			asrId: pAsrId
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/exclusionDetail', jsonData);
    	},
    	shareToGroup: function (pURL, pUserId, pGroupId, pGroupArr, pListId, pGroupComments) {
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		var prioritizationShareGrp = {
				grpId: pGroupId,
    			userIds: pGroupArr,
    			grpType: "asr",
    			listId: pListId,
    			grpTxt: pGroupComments
    		}
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			prioritizationShareGrp: prioritizationShareGrp
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/shareToGroup', jsonData);
    	},
    	checkExistListName: function(pURL, pUserId, pListName, pListType) { 
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			listNm: pListName,
    			listType: pListType
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/checkListName', jsonData);
    		
    	},

		checkExistListNameMdcd: function(pURL, pUserId, pListName, pListType) { 
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			listNm: pListName,
    			listType: pListType
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/checkListNameMdcd', jsonData);
    		
    	},
    	updateExclusionVals: function(pURL, pUserId, pListId, pComments, pExCategory){
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
			// build request for exclusion category update
			entryCriteria = {
        			userNm: pUserId,
        			comments: pComments,
        			itemId: pListId,
        			exclusions: pExCategory
        	};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/updateExSetVals', jsonData);
    	},
    	getPrioritizeForUCMTable: function(pURL, ids, currentASRview, loggedInUserId) {
    		console.log("Inside casemanagement.getPrioritizationTable.");
    		console.log('here is the asr view');
    		console.log(currentASRview)
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    				asrptIds: ids,
    				programType: currentASRview,
    				loggedInUserId: loggedInUserId
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getPrioritizationTable REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/prioritizeForUCMTable', jsonData);  
    	},
    	getLandingPageData: function(pURL, pUserId, pUserZone) {
    		 //   		console.log("Inside indexFactory.getLandingPageData");
    		 
    		    		//create the json request object
    		    		var entryCriteria = {
    		    				userId: pUserId,
    		    				userZone: pUserZone
    		    		};
    		    		
    		    		//create the JSON object to be used in the REST Request
    		    		jsonData = JSON.stringify(entryCriteria);
    		    		    		
    		    		return $http.post(pURL + '/rest/portal/queryLandPageData', jsonData);
    	},
    	buildAsrSummaryPrefs: function(pURL, pUserId, pUserZone) {
			
			var mdcrPrefs = {};
			var mdcdPrefs = {};
			var asrView = {};
			var deferred = $q.defer();
			let asrSummaryChain = {
				dataMdcrPrefs: this.getUserPreferences(pURL, "sumTableCols",pUserId, null, null),
				dataMdcdPrefs: this.getUserPreferences(pURL, "sumTableColsMDCD",pUserId, null, null),
				dataAsrView: this.getUserPreferences(pURL, "defaultAsrView",pUserId, null, null),
			}
			$q.all(asrSummaryChain).then((values) => {
				mdcrPrefs = values.dataMdcrPrefs;
				mdcdPrefs = values.dataMdcdPrefs;
				asrView = values.dataAsrView;
				var resp = {mdcrPrefs: mdcrPrefs.data, mdcdPrefs: mdcdPrefs.data,asrView: asrView.data };
				deferred.resolve(resp);
			});
			return deferred.promise;
		}
    		
    		    
	}
}]);

appCaseMgmt.filter('decodedListNm', function(){
	return function(listName){
		if(!listName) return listName;
		return listName.replace(/&amp;/g , '&');
	};
});

	