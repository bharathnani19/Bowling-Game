//create a module(app) for the utilities that will serve all screens
var appUtil = angular.module('util.module', ['ngRoute', 'ngCookies']);

//no controller since this only serving as a service 

//create a singleton service to handle various global tasks for the application
appUtil.service('utilService', function($cookies) {
	
	var navAsrIdVal;
	var navAsrDbIdVal;
	var authClient;
	
	this.getNavAsrIdVal = function(pAsrId) {
		//console.log("Inside Util Service getNavAsrIdVal. ASR ID Value = " + pAsrId);
		
		//if pAsrId contains a value, then assign it to the local variable
		if (pAsrId != null && !pAsrId == "" && pAsrId != void(0)) {
			//set the local variable
			navAsrIdVal = pAsrId;			
		} 
		
		return navAsrIdVal;
	}
	
	this.setNavAsrDbIdVal = function(pAsrId) {
		//if pAsrId contains a value, then assign it to the local variable
		if (pAsrId != null && !pAsrId == "" && pAsrId != void(0)) {
			//set the local variable
			navAsrDbIdVal = pAsrId;			
		} 
	}
	
	this.getNavAsrDbIdVal = function(pAsrId) {
		
		return navAsrDbIdVal;
	}
	
	// set the okta authClient object for use in all modules
	this.setOktaAuth = function() {
		// required okta config. SPA applications should use PKCE (default) flow, which doesn't use a client secret
		var config = __env.oktaConfig;
		
						
		// invoke the okta auth client
		authClient = new OktaAuth(config);
		
		// check if the browser supports PKCE
		var pkceSupport = authClient.features.isPKCESupported();
		console.log('PKCE Support = ' + pkceSupport);
		
		return authClient;
	}
	
	// get the okta token for use in other modules
	this.getOktaAuth = function() {
		return authClient; 
	}
		
	/**
	 * This method creates a search request object that is used by the nav and case mgmt controllers
	 */
	this.getSearchReqObj = function() {
		var oSearchObj = {};
		
		oSearchObj.loggedInUserId = null; 
		oSearchObj.asrptIds = null;
		oSearchObj.prvdrName = null;
		oSearchObj.claimTypes = null;
		oSearchObj.enrollmentId = null;
		oSearchObj.enrollStatus = null;
		oSearchObj.lastClmDtLow = null;
		oSearchObj.lastClmDtHigh = null;
		oSearchObj.lastAlertSvcDtLow = null;
		oSearchObj.lastAlertSvcDtHigh = null;
		oSearchObj.p1LastAlertSvcDtLow = null;
		oSearchObj.p1LastAlertSvcDtHigh = null;
		oSearchObj.lastEduDtLow = null;
		oSearchObj.lastEduDtHigh = null;
		oSearchObj.timelinessLow = null;
		oSearchObj.timelinessHigh = null;
		oSearchObj.riskScoreLow = null;
		oSearchObj.riskScoreHigh = null;
		oSearchObj.priorityScoreLow = null;
		oSearchObj.priorityScoreHigh = null;
		oSearchObj.sbmtAmtLow = null;
		oSearchObj.sbmtAmtHigh = null;
		oSearchObj.totalPymtLow = null;
		oSearchObj.totalPymtHigh = null;
		oSearchObj.totalPymtDLow = null
		oSearchObj.totalPymtDHigh = null;
		oSearchObj.asrCostLow = null;
		oSearchObj.asrCostHigh = null;
		oSearchObj.p1AsrCostLow = null;
		oSearchObj.p1AsrCostHigh = null;
		oSearchObj.ucmAsrId = null;
		oSearchObj.ucmCaseId = null;
		oSearchObj.rulings = null;
		oSearchObj.alerts = null;
		oSearchObj.p1Alerts = null;
		oSearchObj.editId = null;
		oSearchObj.edits = null;
		oSearchObj.states = null;
		oSearchObj.alertStatus = null;
		oSearchObj.p1AlertStatus = null;
		oSearchObj.zrTypes = null;
		oSearchObj.zrId = null;
		oSearchObj.jurisdictions = null;
		oSearchObj.p1Jurisdictions = null;
		oSearchObj.myZoneOnlyInd = null;
		oSearchObj.leadInvestigationInd = null;
		oSearchObj.partDInd = null;
		oSearchObj.apsInd = null;
		oSearchObj.actionability = null;
		oSearchObj.prioritizeTypes  = null;
		oSearchObj.presetSearchFlag = null;
		oSearchObj.exclusions = null;
		oSearchObj.exclusionOrInd = null;
		oSearchObj.leadInd = null;
		oSearchObj.searchType = null;
		oSearchObj.lastTpeEduDtLow = null;
		oSearchObj.lastTpeEduDtHigh = null;
		oSearchObj.createdMinDt = null;
		oSearchObj.createdMaxDt = null;
		oSearchObj.asrWorkingSetInd = null;
		oSearchObj.asrExclSetInd = null;
		oSearchObj.specialtyCds = null;
		
		oSearchObj.subjectJurisdiction = null;
		oSearchObj.assignedZone = null;
		oSearchObj.assignedToUserId = null;
		
		oSearchObj.barriers = null;
		oSearchObj.barrierToActionInd = null;
		oSearchObj.costSortDir = null;
		
		oSearchObj.createdMinDt = null;
		oSearchObj.createdMaxDt = null;
		
		oSearchObj.customClaimLineLevel = null;
		oSearchObj.customClaimLineLevelParam = null;
		
		oSearchObj.assignedToLName = null;
		oSearchObj.assignedToFName = null;
		oSearchObj.actions = null;
		oSearchObj.activities = null;
		oSearchObj.sysTags = null;
		
		oSearchObj.legacyScoreLow = null;
		oSearchObj.legacyScoreHigh = null;
		oSearchObj.biuDays = null;
		oSearchObj.biuCnt = null;
		
		
		oSearchObj.modelPriority = null;
		
		
	
		oSearchObj.cityStates = null;
		
		return oSearchObj;
	}
	
	this.getTableauVizURL = function(pUserRole) {
	// *** PI_22_4: This report is now a shared report. We do not need to check for a role.
		
			return __env.tableauVizURL;
		
	}
	
	this.getModelAttributeReportURL = function(pNPI, pUserZone, pUserRole) {
	//	console.log("Inside getModelAttributeReportURL service function. pNPI = " + pNPI 
	//			+ ", pUserZone = " + pUserZone + ", pUserRole = " + pUserRole);
		// *** PI_22_4: This report is now a shared report. We do not need to check for a role.
	
			return __env.tableauModelAttr + pNPI;
		
	}
	
	this.getEditTrendReportURL = function(pNPI, pUserZone, pUserRole) {
			return __env.tableauEditTrend+ pNPI;
		
	}
	
	this.getProviderProfileURL = function(pAsrId, pNpi, pUserZone, pUserRole) {
		//console.log("Inside getProviderProfileURL service function. pAsrId = " + pAsrId 
		//		+ ", pUserZone = " + pUserZone + ", pUserRole = " + pUserRole);
		
		// *** PI_22_4: This report is now a shared report. We do not need to check for a role.
		
		return __env.tableauProviderProfile+  + pAsrId;			
		
	}
	
	this.getChowReportURL = function(pNpi, pUserZone, pUserRole) {
		// *** PI_22_4: This report is now a shared report. We do not need to check for a role.
		
			return __env.tableauChow+  + pNpi;	
		
		
	}
	
	this.getPrvdrEduReportURL = function(pNpi, pUserZone, pUserRole) {
		//allow UPIC end-users and Tableau Admin Users access Investigative Reports
		//console.log("Retrieve Investigative Provider Education Reports...");
		return __env.tableauProviderEdu+  + pNpi;
	}
	
	this.getPrvdrEduAttrReportURL = function(pNpi, pUserZone, pUserRole) {
	// *** PI_22_4: This report is now a shared report. We do not need to check for a role.
		
			return __env.tableauProviderEduAttr+  + pNpi;
				
	}
	
	this.getReportsUrl = function() {
		// console.log('Inside getReportsUrl service function.');
		return __env.tableauRoot;
		
	}
	
	this.getTrainingUrl = function() {
		
		return __env.lmsUrl;
	}
	
	this.getEditsandModelsLifecycleUrl = function() {
		
		return __env.editsandModelsLifecycleUrl;
	}
	this.getEnvironment = function() {
		
		return __env.env;
	}
	
});

appUtil.factory('cache', function($cacheFactory) {
	  var cache = $cacheFactory('myCache');
	  return cache;
	});

//create a factory to perform REST functionality
appUtil.factory('utilFactory', ['$http', function($http) {
	return {
		//create a function that returns the url property from the system properties file
		getURLPropertyFromFile: function() {
			console.log("Inside the utilFactory.getURLPropertyFromFile");
			
			//get the serviceURL property from the property file
			var config = {headers:  {
		        'Content-Type': 'text/plain',
		        'Accept': 'text/plain'
		   	 }
			};
			var serviceURL = $http.get('LoadPropertiesFileServlet', config).success(function(data, status, headers, config) {
				console.log('serviceURL = ' + data);
			});
			
			return serviceURL;
		},
		logSlaMetrics: function(pUrl, pUserId, pDateTime, pEventType, pZone) {
			console.log("Inside appUtil.logSlaMetrics. pUrl = " + pUrl + ", pUserId = " 
					+ pUserId + ", pDateTime = " + pDateTime + ", pEventType = " + pEventType);
			
			//create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			dateTime: pDateTime,
    			eventType: pEventType,
    			zone:pZone
    		};
    		
    		//create the JSON object to be used in the REST Request
    		var jsonData = JSON.stringify(entryCriteria);
    		console.log('logSlaMetrics REST request = ' + jsonData);
    		
    		return $http.post(pUrl + '/rest/portal/slaMetrics', jsonData);
		},
		getInvalidateSession: function(pUrl, pToken) {
			console.log("Inside appUtil.getInvalidateSession. pUrl = " + pUrl + ", pToken = " + pToken);
			
			//create the json request object
    		var entryCriteria = {
    			tokenId: pToken
    		};
    		
    		//create the JSON object to be used in the REST Request
    		var jsonData = JSON.stringify(entryCriteria);
    		console.log('getInvalidateSession REST request = ' + jsonData);
    		
    		return $http.post(pUrl + '/rest/portal/invalidateSession', jsonData);
		},
		getTrackUserActivity: function(pURL, pUserId, pPageId, pTrackVal) {
    		//thins method makes a call to the /rest/tracking/{page}/{userId} service to denote that
    		//a user has clicked on a specific area of the portal
    		console.log("Inside utilFactory.getTrackUserActivity");
    		
    		//create the json request object
    		var entryCriteria = {
    				userId: pUserId,
    				pageId: pPageId,
    				trackingVal: pTrackVal 
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getTrackUserActivity REST request = ' + jsonData);
    		
    		//make the rest web service call to get the data
    		return $http.post(pURL + '/rest/portal/userTracking', jsonData);
		}   	
	}
}]);	