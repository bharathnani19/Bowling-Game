var appDetails = angular.module('details.module', ['ngRoute', 'ngCookies', 'ngSanitize']);

appDetails.controller("detailsController", ['$scope','$rootScope', '$location', '$sanitize', '$interval', '$cookies', '$window', '$sce', 'detailsFactory', 'utilService', 'utilFactory','$timeout', '$http',
                                            function ($scope, $rootScope, $location, $sanitize, $interval, $cookies, $window, $sce, detailsFactory, utilService, utilFactory, $timeout, $http) {
	console.log('Inside the detailsController.');

	// get the Okta authClient object from the util service
	var authClient = utilService.getOktaAuth();
	function updatePageTitle(newTitle) {
		document.title = newTitle;

		// Announce the new title for screen readers
		const srAnnouncer = document.createElement("div");
		srAnnouncer.setAttribute("role", "alert");
		srAnnouncer.setAttribute("aria-live", "assertive");
		srAnnouncer.style.position = "absolute";
		srAnnouncer.style.width = "1px";
		srAnnouncer.style.height = "1px";
		srAnnouncer.style.margin = "-1px";
		srAnnouncer.style.clip = "rect(0, 0, 0, 0)";
		srAnnouncer.style.overflow = "hidden";
		srAnnouncer.textContent = newTitle;
		document.body.appendChild(srAnnouncer);

		// Remove the announcer after a short delay
		setTimeout(() => {
		  document.body.removeChild(srAnnouncer);
		}, 1000);
	  }

	  // Set the page title for "ASR Summary"
	  $rootScope.pageTitle = "ASR Details";
	  updatePageTitle($rootScope.pageTitle);

	// check for valid okta token
	authClient.tokenManager.getTokens()
	.then(({ accessToken, idToken }) => {
		// handle accessToken and idToken
		if (accessToken) {
			// user has valid access token, so show page contents
			showDetailsPageContents(idToken);
		} else {
			// no token and not logged-in, so redirect to login screen               
		authClient.token.getWithRedirect({
				responseType: ['token', 'id_token']
			});
		}
	});

	 // this function shows the page to users that have been authenticated via Okta
	 showDetailsPageContents = function(pIdToken) {
		if (pIdToken) {
			// show the index page Dom objects
			$('#detailsContainer').removeAttr('hidden');

			// Show full page LoadingOverlay
			$.LoadingOverlay("show");
			$scope.uid = pIdToken.claims.preferred_username;
			loadPageUniqueId = crypto.randomUUID();;

			//broadcast this event to the broadcastSlaMetrics listener
			$rootScope.$broadcast('broadcastSlaMetrics', {message:"ASR Detail Load - Start: " + loadPageUniqueId, userId: ""});

			// destroy and rebuild the alert table
			$("#alertsTable").bootstrapTable('destroy');
			$('#alertsTable').bootstrapTable({});
			
			$("#alertsTableMdcd").bootstrapTable('destroy');
			$('#alertsTableMdcd').bootstrapTable({});
			
			$("#phase1AlertsTable").bootstrapTable('destroy');
			$('#phase1AlertsTable').bootstrapTable({});
			
			$('#asrHistoryTable').bootstrapTable({});
			$('#asrHistoryTableMdcd').bootstrapTable({});
			$('#leadsTable').bootstrapTable({});
			$('#editTagProcedureCodes').bootstrapTable({});
			$('#editTagDenialCodes').bootstrapTable({});

			// destroy and rebuild the priority score table
			//$('#priorScoreTable').bootstrapTable('destroy');
			$('#priorScoreTable').bootstrapTable({});

				// show priority score tab when page loads	
//			$('#pScoreTabLink').tab('show');
			
			// show ASRRiskScoreExplainabilityTab when page loads
			$('#aSRRiskScoreExplainabilityTable').bootstrapTable({});
			
			
			// No show Enhanced Risk Score Contributions tab by default
			$scope.setRcERC = false;
			
			
			//initiate the tpe tab table
			$("#tpeTable").bootstrapTable({});

			//set the map results index = 0 (to be used by the add more button)
			$scope.asrMapResultsIndex = 0;

			//check the existence of the 'index' query parameter by seeing if it's undefined
			var undefinedVal = void(0);

			//define scope level variable for ASR parameter
			$scope.asrDetailsParam = $location.search().asrDetailsParam;
//			console.log("asrDetailsParam URL parameter =  " + $scope.asrDetailsParam);
			console.log($location.search());
			
			$scope.viewParam = $location.search().viewParam;
			
			console.log("viewParam - ",$scope.viewParam , " asrDetailsParam -", $scope.asrDetailsParam );
			
			if ($scope.viewParam == "medicaid"){
				$scope.mdcdAsrDbId = $scope.asrDetailsParam;	
			}else {
				$scope.asrDbId = $scope.asrDetailsParam;
			}
			

			// get the Report Card NPI ID from custom report card
			$scope.customRptCardNpi = $location.search().asrRptCardIdParam;
			console.log("customRptCardNpi URL parameter =  " + $location.search().asrRptCardIdParam);

			//if the navAsrSearch parameter is true, then retrieve the search value from the util service
			if ($location.search().navAsrSearch != null && $location.search().navAsrSearch != undefinedVal && $location.search().navAsrSearch == 'true') {
				//retrieve the search value from the util service
				console.log("Navbar search value = " + utilService.getNavAsrIdVal()); 
				
				//set the asrDetailsParam equal to the nav search value
				$scope.asrDetailsParam = utilService.getNavAsrIdVal();
				$scope.asrDetailsDbIdParam = utilService.getNavAsrDbIdVal();
				
				//for internal metrics only to keep track of search type performed
				$scope.asrDetailsSearchType = 'quick';
				//$("#asrInfoPanelTitle").focus();
				setTimeout(function(){
					$("#breadcrumb-item").focus();
				},0);
			} else if ($scope.customRptCardNpi != undefinedVal && $scope.customRptCardNpi != null) {
				//for internal metrics only to keep track of search type performed
				$scope.asrDetailsSearchType = 'init';
				
				
				
				$scope.asrDetailsParam = $scope.customRptCardNpi;
			} else {
				//for internal metrics only to keep track of search type performed
				$scope.asrDetailsSearchType = 'init';
				
				
				//set the details db param equal to the URL parameter
				$scope.asrDetailsDbIdParam = $scope.asrDetailsParam;
			}

			//this function listens for the skip Nav link scope broadcast
			$scope.$on('skipNavEvent', function() {
				console.log('skipNavEvent detected!');
				
				//set the focus on the System Outages panel
				$("#asrInfoPanelTitle").focus();
			});

			//call the factory method from the util.module to get the property from the property file
			utilFactory.getURLPropertyFromFile().then(function(response) {
				//declare a scope level variable for the restURL 
				$scope.restURL = response.data;

				$scope.scopeUserId = pIdToken.claims.preferred_username;

				// parse the group claim array from the token
				// loop through the array to parse all of the values from the array
				$scope.rolesArray = [];
				$scope.userAttrArray = [];
				$scope.zonesArray = [];
				var groupsArray = pIdToken.claims.groups;			

				for (i = 0; i < groupsArray.length; i++) {
					console.log('group - ' + groupsArray[i]);
					var groupObj = groupsArray[i];

					// populate role array
					if (groupObj.search('FPSUI Role') != -1) {
						$scope.rolesArray.push(groupObj.replace("FPSUI Role", "").trim());
					}

					// populate the zone Array
					if (groupObj.search('FPSUI Zone') != -1) {
						$scope.zonesArray.push(groupObj.replace("FPSUI Zone", "").trim());
					}

					// populate the attributes Array
					if (groupObj.search('FPSUI Attrib') != -1) {
						$scope.userAttrArray.push(groupObj.replace("FPSUI Attrib", "").trim());
					}
				}

				$scope.scopeUserZone =  $scope.zonesArray[0];
					
				// if MAC user, then hide barrier to action components on provider pane
				// also hide the provider education button 
				if($scope.rolesArray.indexOf("MAC") != -1){
					// hide barrier to action components
					$('#prvdrPaneBarToActnDiv').addClass('hidden');	
					$('#prvdrPaneAssignToDiv').addClass('hidden');
					
					// use this variable to hide Provider Education Report button
					$scope.hideFromMacs = true;
				} else {
					// show the Provider Education Report button to non-MAC users
					$scope.hideFromMacs = false;
				}
				
				if ($scope.zonesArray.indexOf("MEDIC") != -1) {
					$scope.medicUser = true;
				}

				// only show the Prioritize for UCM button to users belonging to certain roles
				if($scope.rolesArray.indexOf("Admin") != -1 || $scope.rolesArray.indexOf("Prioritize Sup") != -1
				|| ($scope.rolesArray.indexOf("MAC") != -1 && $scope.userAttrArray.indexOf('ASR Prioritization') != -1)) {
			
					console.log('User is authorized to Prioritize ASRs.');
					$('#prioritizeUCMBtnGroup').removeClass('hidden');
					$('#prioritizeUCMBtnGroupMDCD').removeClass('hidden');
					
					
					
				}
				console.log($scope.responseData)
				// if($scope.responseData?.mdcdPrrtyEnabledInd == "N"){
				// 	$('#prioritizeUCMBtnMDCD').addClass('disabled');
				// }
				// else{
				// 	$('#prioritizeUCMBtnMDCD').removeClass('disabled');
				// }
				
				//hide the Notes Tab if the user is a MAC
				if($scope.rolesArray.indexOf("MAC") != -1) {
					console.log('User is MAC, so hide Notes tab.');
					
					$('#notesTabLink').addClass('hidden');
					$('#notesTab').addClass('hidden');
				}
				
				// look for if Medicaid/Medicare asr available.
				$scope.medicareAsrNotAvailable = false;
				$scope.medicaidAsrNotAvailable = false;
				
				if ($scope.medicUser || $scope.hideFromMacs) {
					$scope.hideMedicaidTab = true;
				}

			
				//retrieve the user's preferences for the ASR Summary table
				detailsFactory.getUserPreferences($scope.restURL, "defaultAsrView", $scope.scopeUserId, null, null).then(function(response) {
					$.LoadingOverlay("hide");
					console.log("User preferences - ", response.data);
					if (response.data.prefJson != null && response.data.prefJson != void(0)) {
						//convert the returned json array to an object, and then loop through it
						//var prefJsonArray = JSON.parse(response.data.prefJson);
//						console.log("prefJson = " + response.data.prefJson);
						$scope.defaultAsrView = response.data.prefJson;
						
					} else {
						console.log("User has no preferences set.");
						$scope.defaultAsrView = "medicare";
					}
					
					$scope.currentASRview = $scope.defaultAsrView;
					/*if ( $scope.hideMedicaidTab == true) {
						// Disable medicaid tab
						$scope.defaultAsrView = "medicare";
						console.log("MAC user, show only medicare tab");
						$scope.disableMedicaidTab();
						$scope.callMedicareDetailsFlow();
						
					}else if ($scope.defaultAsrView == "medicaid"  ){
						// No MAC and Medicaid flow
						$scope.callMedicaidDetailsFlow();
						
					}else {
						// No MAC and medicare asr
						$scope.callMedicareDetailsFlow();
					}*/
					
					if ($scope.viewParam ==undefined || $scope.viewParam == null){
						$scope.viewParam = $scope.defaultAsrView;
					}
					console.log("asrDetailsParam -", $scope.asrDetailsParam);
					console.log("asrDetailsSearchType -", $scope.asrDetailsSearchType);
					console.log("viewParam -", $scope.viewParam);
					console.log("defaultAsrView -", $scope.defaultAsrView);
					$.LoadingOverlay("show");

					var watchlistItem = localStorage.getItem("watchList");
					if(watchlistItem){
						$scope.viewParam = 'medicare';
					}

					detailsFactory.getASRDetailsData($scope.restURL, $scope.asrDetailsParam, $scope.asrDetailsSearchType, $scope.scopeUserId,$scope.viewParam )
					.success(function(data) {
						
						$.LoadingOverlay("hide");
						console.log("Resonse data - ", data.responseData);
						$scope.asrDbId = data.responseData.asrDbId
						$scope.mdcdAsrDbId = data.responseData.mdcdAsrDbId
												
						console.log(" asrDbId = ", $scope.asrDbId) ;
						console.log(" mdcdAsrDbId = ", $scope.mdcdAsrDbId) ;

						 var watchlistItem = localStorage.getItem("watchList");
						
						// Disable tabs if ASR not available

						if(watchlistItem){
							$scope.defaultAsrView == "medicare"
						}
						 localStorage.removeItem("watchList");
						
						if ($scope.asrDbId == undefined || $scope.asrDbId == null) {
							$scope.disableMedicareTab();
							$scope.callMedicaidDetailsFlow();
							
						}else if ($scope.mdcdAsrDbId == undefined || $scope.mdcdAsrDbId == null) {
							$scope.disableMedicaidTab();
							$scope.callMedicareDetailsFlow();
						} else {
							console.log("Medicare and Medicare both tabs enabled!");
							if ($scope.viewParam == "medicaid"  ){
								// No MAC and Medicaid flow
								$scope.callMedicaidDetailsFlow();
								
							}else {
								// No MAC and medicare asr
								$scope.callMedicareDetailsFlow();
							}
							
						}
						
						if ( $scope.hideMedicaidTab == true) {
						// Disable medicaid tab
						$scope.defaultAsrView = "medicare";
						console.log("MAC user, show only medicare tab");
						$scope.disableMedicaidTab();
						$scope.callMedicareDetailsFlow();
						
						}
						
						
						
					}).error(function(data, status) {
						$.LoadingOverlay("hide");
					 console.log('getASRDetailsData REST Error:' + status); 
					 showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> No ASR Details available to ' + status, 'danger'); 
					});
					
					
					
				}).	catch(function(err){   
					$.LoadingOverlay("hide");
					console.log("ASR Detail service REST Error: " + err.status);
										
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Loading user preferences failed due to ' + err.status, 'danger');
				});
				

			}).catch(function(err) {
				console.log('getURLPropertyFromFile REST Error:' + err.data);	
				//hide the overlay spinner
				$.LoadingOverlay("hide");
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load system data due to ' + err.data, 'danger');		
			});	

		} else {
			// You're not logged in, you need a sessionToken
			authClient.token.getWithRedirect({
				responseType: ['token', 'id_token']
			});
		} 	
	}	
	 
	 
	 
	$scope.callMedicareDetailsFlow = function(){
		$scope.activeASRTab = "medicare";
		
		console.log('Medicare ASR flow');
		$('#medicareAsrDetailTabLink').tab('show');
		$('#medicareAsrDetailTabLink').focus();
		$scope.asrDetailsParam = $scope.asrDbId;
		
		$scope.callASRDetailsService('medicare', $scope.asrDbId);
	}
	
	$scope.callMedicaidDetailsFlow = function(){
		$scope.activeASRTab = "medicaid";
	
		$('#medicaidAsrDetailTabLink').tab('show');
		$('#medicareAsrDetailTabLink').focus();
		$scope.asrDetailsParam = $scope.mdcdAsrDbId;
		
		console.log('Medicaid ASR flow');
		$scope.callASRDetailsService('medicaid', $scope.mdcdAsrDbId);
	}
	
	$scope.callASRDetailsService = function(medicareOrMdcd, asrId){
		
		
		
		$.LoadingOverlay("show");
		$("#totalPaymentMDCDTable").bootstrapTable();
		$('#alertsTableMdcd').bootstrapTable();
	
		
		console.log("asrDetailsSearchType - ", $scope.asrDetailsSearchType);
		console.log("asrDetailsParam - ", $scope.asrDetailsParam);
		console.log("medicareOrMdcd - ", medicareOrMdcd);
		console.log("asrId - ", $scope.asrId);
		//call the getASRDetailsData in the details factory
		
	detailsFactory.getASRDetailsData($scope.restURL, asrId, $scope.asrDetailsSearchType, $scope.scopeUserId, medicareOrMdcd)
		.success(function(data) {
			console.log('ASR Details flow - ',medicareOrMdcd, "-- ",asrId );
			console.log(data)
			
			

			// Hide full page LoadingOverlay
			$.LoadingOverlay("hide");

			//create a scope object from the response
			$scope.responseData = data.responseData;
			//populate theProviderPane 
			$scope.providerPaneObj = $scope.responseData.provider;
			$scope.mdcdUserStates = $scope.responseData.mdcdUserStates;
			
			//populate the title rows of the modal window for medicaid details
			$scope.medicaidNpi = "";
			$scope.medicaidAsOfDt = "";
			$scope.medicaidPrvdrName = "";
			$scope.medicaidClaimsRiskCnt ="";
			$scope.medicaidState = "";
			$scope.medicaidDollsAtRisk = "";
			$scope.medicaidPrvdrNumber = "";
			$scope.medicaidAlertReason = "";
			
			
			
	
			
			if($scope.activeASRTab == "medicaid") {
				
				$scope.asrDetailsDbIdParam = $scope.responseData.mdcdAsrDbId;	
				console.log("asrDbid - ",$scope.asrDetailsDbIdParam );
				

				//populate the ASR History Tab
				$scope.asrHistoryObj = $scope.responseData.history;
				$('#asrHistoryTableMdcd').bootstrapTable('load', $scope.asrHistoryObj);
				// show the Medicaid Total payment popup
				$("#totalPaymentMDCDModal").modal("show");

				// Load Total payment table
				$("#totalPaymentMDCDTable").bootstrapTable('load', $scope.responseData.mdcdTotalPayments);
				
				// Load Alerts table
				$('#alertsTableMdcd').bootstrapTable('load', $scope.responseData.masterAlert);
				$("#alertsTableMdcd").bootstrapTable('resetView');
				$("#alertsTableMdcd").parent().attr('style', 'margin-left:1px !important;');

				//leads/investigations
				if (data.responseData.hasInv != 'Y') {
					//disable the leads/investigations tab
					$('#invTabListItemMdcd').addClass('disabled');
					$('#invTabListItemMdcd').attr('aria-disabled', 'true');
					$('#invTabLinkMdcd').css('cursor', 'not-allowed');
					$('#invTabLinkMdcd').css('pointer-events', 'none');
					$('#invTabLinkMdcd').removeAttr('data-toggle');
				} else {
					//enable the edits tab
					$('#invTabListItemMdcd').removeClass('disabled');
					$('#invTabListItemMdcd').attr('aria-disabled', 'false');
					$('#invTabLinkMdcd').css('cursor', 'pointer');
					$('#invTabLinkMdcd').css('pointer-events', 'auto');
					$('#invTabLinkMdcd').attr('data-toggle','tab');
				}
				
				//set the proper provider info prioritized value, true=Y, false=N
				if($scope.responseData.prioritized == "true") {
					$scope.prvdrPrioritized = "Y";
				} else if($scope.responseData.prioritized == "false") {
					$scope.prvdrPrioritized = "N";
				} 
				// Disabled Priortize UCM button based on mdcdPrrtyEnabledInd
				if($scope.responseData.mdcdPrrtyEnabledInd == "N"){
//					$('#prioritizeUCMBtnMDCD').addClass('disabled');
					$('#prioritizeUCMBtnMDCD').attr('disabled', true);	
				}
				else{
//					$('#prioritizeUCMBtnMDCD').removeClass('disabled');
					$('#prioritizeUCMBtnMDCD').removeAttr('disabled');
				}
				


				// Set Riskscore #
			
				//calculate the risk score and then add the changed risk score to the providerPaneObj
				console.log('Provider Risk Score = ' + $scope.providerPaneObj.riskScoreNum);
				//if value is over .99 then alert the user
				if ($scope.providerPaneObj.riskScoreNum != null && $scope.providerPaneObj.riskScoreNum != 'N/A') {
					if($scope.providerPaneObj.riskScoreNum > .99) {
						$scope.providerPaneObj.riskScoreNumDisplay = '> 0.99';
					} else if($scope.providerPaneObj.riskScoreNum < 0.01) {
						$scope.providerPaneObj.riskScoreNumDisplay = '< 0.01';
					} else {
						$scope.providerPaneObj.riskScoreNumDisplay = parseFloat($scope.providerPaneObj.riskScoreNum).toFixed(2);
					}
				} else if ($scope.providerPaneObj.riskScoreNum == 'N/A') {
					$scope.providerPaneObj.riskScoreNumDisplay = $scope.providerPaneObj.riskScoreNum;
				} else {
					$scope.providerPaneObj.riskScoreNumDisplay = '';
				}
	
				console.log("==>", $scope.providerPaneObj.riskScoreNumDisplay);
				
				
				// Load Prioritize for UCM table FPS
				
				console.log("prioritizeForUCMTable -> ",$scope.asrDetailsDbIdParam );
				var asrptids =  [$scope.asrDetailsDbIdParam];//[632505, 633951,634663  ];
				
				if($scope.asrDetailsDbIdParam != null)
					detailsFactory.getPrioritizeForUCMTable($scope.restURL, asrptids, 	$scope.scopeUserId, $scope.activeASRTab).then(function(response) {
						console.log("prioritizeForUCMTable ->", response);	
						$scope.prioritizeForUCMTableData = response.data;
						
					}).catch(function(err){ 	
						showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Proritize for UCM table could not be loaded due to ' + err.status, 'danger');
					});
				
				// call the refdata service to get the jurisdiction dropdown
				detailsFactory.getPrioritizationZones($scope.restURL).then(function(response) {
					$scope.priorZonesOptions = response.data.zones;
					
					// hide the modal body overlay
	//				$("#priorZonesSelect").LoadingOverlay("hide");
					console.log("$scope.priorZonesOptions ->", $scope.priorZonesOptions);
				}).catch(function(err){ 
					// hide the modal body overlay
	//				$("#priorZonesSelect").LoadingOverlay("hide");
					
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Jurisdiction data could not be loaded due to ' + err.status, 'danger');
				});
					
				setTimeout(function(){
					$("#breadcrumb-item").focus();
				},0);
				
			}else {
				
				// Medicare workflow
				$scope.asrDetailsDbIdParam = $scope.responseData.asrDbId;
			
					//set the proper provider info prioritized value, true=Y, false=N
					if($scope.responseData.prioritized == "true") {
						$scope.prvdrPrioritized = "Y";
					} else if($scope.responseData.prioritized == "false") {
						$scope.prvdrPrioritized = "N";
					} 
		
					//disable tabs that contain no data
					//edits							
					if (data.responseData.hasEdits == "N") {
						//disable the edits tab
						$('#editsTabListItem').addClass('disabled');
						$('#editsTabListItem').attr('aria-disabled', 'true');
						$('#editsTabLink').css('cursor', 'not-allowed');
						$('#editsTabLink').css('pointer-events', 'none');
						$('#editsTabLink').removeAttr('data-toggle');								
					} else {
						//enable the edits tab
						$('#editsTabListItem').removeClass('disabled');
						$('#editsTabListItem').attr('aria-disabled', 'false');
						$('#editsTabLink').css('cursor', 'pointer');
						$('#editsTabLink').css('pointer-events', 'auto');
						$('#editsTabLink').attr('data-toggle','tab');
					}
					//leads/investigations
					if (data.responseData.hasInv == "N") {
						//disable the leads/investigations tab
						$('#invTabListItem').addClass('disabled');
						$('#invTabListItem').attr('aria-disabled', 'true');
						$('#invTabLink').css('cursor', 'not-allowed');
						$('#invTabLink').css('pointer-events', 'none');
						$('#invTabLink').removeAttr('data-toggle');
					} else {
						//enable the edits tab
						$('#invTabListItem').removeClass('disabled');
						$('#invTabListItem').attr('aria-disabled', 'false');
						$('#invTabLink').css('cursor', 'pointer');
						$('#invTabLink').css('pointer-events', 'auto');
						$('#invTabLink').attr('data-toggle','tab');
					}
					//systags
					//notes
					if (data.responseData.hasNotes == "N") {
						//disable the system tags tab
						$('#notesTabListItem').addClass('disabled');
						$('#notesTabListItem').attr('aria-disabled', 'true');
						$('#notesTabLink').css('cursor', 'not-allowed');
						$('#notesTabLink').css('pointer-events', 'none');
						$('#notesTabLink').removeAttr('data-toggle');
					} else {
						//enable the system tags tab
						$('#notesTabListItem').removeClass('disabled');
						$('#notesTabListItem').attr('aria-disabled', 'false');
						$('#notesTabLink').css('cursor', 'pointer');
						$('#notesTabLink').css('pointer-events', 'auto');
						$('#notesTabLink').attr('data-toggle','tab');
					}
					//part d reports tab
					if (data.responseData.hasPartD == "N") {
						//disable the system tags tab
						$('#partDTabListItem').addClass('disabled');
						$('#partDTabListItem').attr('aria-disabled', 'true');
						$('#partDTabLink').css('cursor', 'not-allowed');
						$('#partDTabLink').css('pointer-events', 'none');
						$('#partDTabLink').removeAttr('data-toggle');	
					} else {
						//enable the system tags tab
						$('#partDTabListItem').removeClass('disabled');
						$('#partDTabListItem').attr('aria-disabled', 'false');
						$('#partDTabLink').css('cursor', 'pointer');
						$('#partDTabLink').css('pointer-events', 'auto');
						$('#partDTabLink').attr('data-toggle','tab');
					}
		
					//phase 1 alerts
					if (data.responseData.hasP1Alerts == "Y") {
						//enable the system tags tab
						$('#phase1AlertsListItem').removeClass('disabled');
						$('#phase1AlertsListItem').attr('aria-disabled', 'false');
						$('#phase1Alerts').css('cursor', 'pointer');
						$('#phase1Alerts').css('pointer-events', 'auto');
						$('#phase1Alerts').attr('data-toggle','tab');
							
					} else {
						//disable the system tags tab
						$('#phase1AlertsListItem').addClass('disabled');
						$('#phase1AlertsListItem').attr('aria-disabled', 'true');
						$('#phase1Alerts').css('cursor', 'not-allowed');
						$('#phase1Alerts').css('pointer-events', 'none');
						$('#phase1Alerts').removeAttr('data-toggle');
					}

					if($scope.responseData.masterAlert.length == 0 && $scope.responseData.currentP1Alert.length > 0){
						$('#phase1AlertsListItem').removeClass('disabled');
						$('#phase1AlertsListItem').attr('aria-disabled', 'false');
						$('#phase1Alerts').css('cursor', 'pointer');
						$('#phase1Alerts').css('pointer-events', 'auto');
						$('#phase1Alerts').attr('data-toggle','tab');
						$('#phase1AlertsListItem').addClass('active');
						$('#phase1alertsTab').addClass('active');
						$('#alertsListItem').removeClass('active');
						$('#alertsTab').removeClass('active');
						
					}

					if($scope.responseData.masterAlert.length == 0 && $scope.responseData.currentP1Alert.length == 0 && data.responseData.hasInv == "Y"){
						$('#phase1AlertsListItem').removeClass('active');
						$('#phase1AlertsListItem').attr('aria-disabled', 'false');
						$('#phase1alertsTab').removeClass('active');
						$('#alertsListItem').removeClass('active');
						$('#alertsTab').removeClass('active');
						$('#invTabListItem').removeClass('disabled');
						$('#invTabListItem').addClass('active');
						$('#invTabListItem').attr('aria-disabled', 'false');
						$('#invTabLink').css('cursor', 'pointer');
						$('#invTabLink').css('pointer-events', 'auto');
						$('#invTabLink').attr('data-toggle','tab');
						$('#leadsTab').addClass('active')
						$('#leadsTab').addClass('in')
						$('#leadsTab').removeClass('fade')
						$scope.fpsLeadsTabClick();
					}

					
					// hide/show HHA Net Viz button based on hasHhaNv field value
					console.log("hasHhaNv = " + $scope.providerPaneObj.hasHhaNv);
					if ($scope.providerPaneObj.hasHhaNv == 'Y') {
						$scope.hideHhaNetVizBtn = false;
					} else {
						$scope.hideHhaNetVizBtn = true;
					}	
		
					// hide/show the DME Net Viz button 
					console.log("hasDmeNv = " + $scope.providerPaneObj.hasDmeNv);
					if ($scope.providerPaneObj.hasDmeNv == 'Y') {
						$scope.hideDmeNetVizBtn = false;
					} else {
						$scope.hideDmeNetVizBtn = true;
					}	
		
					// set the proper provider info revocation value 
					if ($scope.providerPaneObj.revocation == "N") {
						$scope.prvdrRevocation = "N";
					} else {
						$scope.prvdrRevocation = "Y";
					}
		
					// set the criminal value
					if ($scope.providerPaneObj.hasAps == "N") {
						$scope.providerCriminal = "N";
					} else {
						$scope.providerCriminal = "Y";
					}
					// To-DO
					console.log("contribScores -->", $scope.providerPaneObj.contribScores.length);
					if ($scope.providerPaneObj.contribScores.length>0 ) {
						
						//set npi value for all objects
						$scope.providerPaneObj.contribScores.forEach(function(el){							
							// Assign NPI, modeltypecode to list object to populate Report card tab.							
							el.npi = $scope.providerPaneObj.npi;
							}); 
						
						// populate ASRRiskScoreExplainabilityTable 
						$('#ASRRiskScoreExplainabilityTabLink').tab('show');
						$('#aSRRiskScoreExplainabilityTable').bootstrapTable('load', $scope.providerPaneObj.contribScores);
						
						var tempRskScoreNo = $scope.providerPaneObj.riskScoreNum;
		//				tempRskScoreNo = tempRskScoreNo.length>3?tempRskScoreNo.substring(0, 4):tempRskScoreNo;		
						
						$scope.minRiskScoreInd = $scope.providerPaneObj.minRiskScoreInd;
						$scope.minRiskScoreModelTxt = $scope.providerPaneObj.minRiskScoreModelTxt;
						
						if (tempRskScoreNo != null && tempRskScoreNo != 'N/A') {
							if(tempRskScoreNo > .99) {
								tempRskScoreNo = '> 0.99';
							} else if(tempRskScoreNo < 0.01) {
								tempRskScoreNo = '< 0.01';
							} else {
								tempRskScoreNo = parseFloat(tempRskScoreNo).toFixed(2);
							}
						} else if (tempRskScoreNo == 'N/A') {
							;
						} else {
							tempRskScoreNo = '';
						}
						
						$("#aSRRiskScoreExplainabilityFooterTd").html("Overall ASR Risk Score = " + tempRskScoreNo);		
						
					}else {
						// Show active tab as Priority Score	
						$('#pScoreTabLink').tab('show');
						$scope.showPriorScore();	
						
						//disable the aSRRiskScoreExplainabilityTab tab
						$('#aSRRiskScoreExplainabilityTabListItem').addClass('disabled');
						$('#aSRRiskScoreExplainabilityTabListItem').attr('aria-disabled', 'true');
						$('#aSRRiskScoreExplainabilityTabLink').css('cursor', 'not-allowed');
						$('#aSRRiskScoreExplainabilityTabLink').css('pointer-events', 'none');
						$('#aSRRiskScoreExplainabilityTabLink').removeAttr('data-toggle');
					}
					
					
					// define variables for risk score trending report
					$scope.providerNPI = $scope.providerPaneObj.npi;
					//set the scope variable for the tableau server
					$scope.vizServer = utilService.getTableauVizURL($scope.rolesArray);
		
					//populate the Dual Eligible Bene table
					//initialize the table
					$("#debTable").bootstrapTable('destroy');
					$('#debTable').bootstrapTable({});		
		
					//if data exist, then load the table
					if ($scope.providerPaneObj.dualBenes != null) {
						$("#debTable").bootstrapTable('load',$scope.providerPaneObj.dualBenes);
					}
		
					//populate the Top 5 ICD Procedure Codes table
					//initialize the table
					$("#icdProcCodesTable").bootstrapTable('destroy');
					$('#icdProcCodesTable').bootstrapTable({});	
		
					//if data exist, then load the table
					if ($scope.providerPaneObj.topProcCds != void(0) && $scope.providerPaneObj.topProcCds != null 
							&& $scope.providerPaneObj.topProcCds.length > 0) {
						//show the table div and adjust the bootstrap grid
						$scope.hideProcCodesTable = false;
						$("#debDiv").toggleClass("col-md-6", false);
						$("#procCodeDiv").toggleClass("col-md-6", false);
						$("#debDiv").toggleClass("col-md-4", true);
						$("#procCodeDiv").toggleClass("col-md-4", true);
						
						$("#icdProcCodesTable").bootstrapTable('load',$scope.providerPaneObj.topProcCds);
					} else {
						//hide the table and adjust the bootstrap grid 
						$scope.hideProcCodesTable = true;
						$("#debDiv").toggleClass("col-md-4", false);
						$("#procCodeDiv").toggleClass("col-md-4", false);
						$("#debDiv").toggleClass("col-md-6", true);
						$("#procCodeDiv").toggleClass("col-md-6", true);								
					}
		
					//populate the Top 5 Procedure Codes Table
					//initialize the table
					$("#procCodeTable").bootstrapTable('destroy');
					$('#procCodeTable').bootstrapTable({});	
					
					//if data exist, then load the table
					if ($scope.providerPaneObj.topProcCds != null) {
						$("#procCodeTable").bootstrapTable('load',$scope.providerPaneObj.topHcpcsCds);
					}
					
					//disable or enable claim types export buttons
					$scope.disableAtRiskBtn = false;
					$scope.disableAtRiskMdcdBtn = false;
					$scope.disableLatestClmBtn = false;
					$scope.disableClmSrchBtn = false;
					$scope.disablePartDSrchBtn = false;
					$scope.disableRrbSrchBtn = false;
					$scope.disablePartDLatestBtn = false;
					$scope.disableClmSrchMdcdBtn = false;

					if($scope.responseData.availableClaims.atRiskP1Ind == "N"){
							$scope.disablephase1ClmSrchBtn = true;
					}
					if($scope.responseData.availableClaims.asrCostP1Ind == "N"){
						$scope.disablephase1CostSrchBtn = true;
				}
					
		
					if($scope.responseData.claimTypes.indexOf("DME") == -1 && $scope.responseData.claimTypes.indexOf("A") == -1 
							&& $scope.responseData.claimTypes.indexOf("B") == -1 && $scope.responseData.claimTypes.indexOf("D") == -1) {
						//the ASR Provider does not have Part A, Part B, Part D, and DME claims
						//disable the "Claims at Risk" export button
						$scope.disableAtRiskBtn = true;
						//disable the "Latest Claims" button 
						$scope.disableLatestClmBtn = true;
						//disable the "Claims Search" button
						$scope.disableClmSrchBtn = true;								
					} else if($scope.responseData.claimTypes.indexOf("DME") == -1 && $scope.responseData.claimTypes.indexOf("A") == -1 
							&& $scope.responseData.claimTypes.indexOf("B") == -1 && $scope.responseData.claimTypes.indexOf("D") != -1) {
						// if the ASR only has Part D, then disable the claims at risk button
						$scope.disableAtRiskBtn = true;
					}
		
					// ASR Provider doesn't have any part D alerts
					if ($scope.responseData.claimTypes.indexOf("D") == -1) {
						$scope.disablePartDSrchBtn = true;
						$scope.disablePartDLatestBtn = true;
					}
					
					// show RRB claims button if RRB value exists
					if ($scope.providerPaneObj.hasRrb == "N") {
						$scope.disableRrbSrchBtn = true;
					}
		
					//calculate the risk score and then add the changed risk score to the providerPaneObj
					console.log('Provider Risk Score = ' + $scope.providerPaneObj.riskScoreNum);
					//if value is over .99 then alert the user
					if ($scope.providerPaneObj.riskScoreNum != null && $scope.providerPaneObj.riskScoreNum != 'N/A') {
						if($scope.providerPaneObj.riskScoreNum > .99) {
							$scope.providerPaneObj.riskScoreNumDisplay = '> 0.99';
						} else if($scope.providerPaneObj.riskScoreNum < 0.01) {
							$scope.providerPaneObj.riskScoreNumDisplay = '< 0.01';
						} else {
							$scope.providerPaneObj.riskScoreNumDisplay = parseFloat($scope.providerPaneObj.riskScoreNum).toFixed(2);
						}
					} else if ($scope.providerPaneObj.riskScoreNum == 'N/A') {
						$scope.providerPaneObj.riskScoreNumDisplay = $scope.providerPaneObj.riskScoreNum;
					} else {
						$scope.providerPaneObj.riskScoreNumDisplay = '';
					}
		
					console.log("==>", $scope.providerPaneObj.riskScoreNumDisplay);
		
					
					var riskScore90Val;
					var riskScore180Val;
					var riskScore365Val;
					
					//format the risk score time interval
					if ($scope.providerPaneObj.riskScore90 != "-") {
						riskScore90Val = parseFloat($scope.providerPaneObj.riskScore90).toFixed(2);
					} else {
						riskScore90Val = $scope.providerPaneObj.riskScore90;
					}
					
					if ($scope.providerPaneObj.riskScore180 != "-") {
						riskScore180Val = parseFloat($scope.providerPaneObj.riskScore180).toFixed(2);
					} else {
						riskScore180Val = $scope.providerPaneObj.riskScore180;
					}
					
					if ($scope.providerPaneObj.riskScore365 != "-") {
						riskScore365Val = parseFloat($scope.providerPaneObj.riskScore365).toFixed(2);
					} else {
						riskScore365Val = $scope.providerPaneObj.riskScore365;
					}
					
					$scope.riskScoreTime = riskScore90Val + "/" + riskScore180Val + "/" + riskScore365Val;
					
					console.log("Provider PTANs count = " + $scope.providerPaneObj.ptans.length);
					
					//get the number of PTANS for the provider
					$scope.ptanCnt = $scope.providerPaneObj.ptans.length;
					
					//populate the ASR History Tab
					$scope.asrHistoryObj = $scope.responseData.history;
					$('#asrHistoryTable').bootstrapTable('load', $scope.asrHistoryObj);
					
					//populate the Master Alerts Tab
					$scope.masterAlertsObj = $scope.responseData.masterAlert;
					$scope.currentP1Alert =  $scope.responseData.currentP1Alert;
					
					console.log("$scope.masterAlertsObj =>", $scope.masterAlertsObj);
					$('#alertsTable').bootstrapTable('load', $scope.masterAlertsObj);
					$("#alertsTable").bootstrapTable('resetView');
					$("#alertsTable").parent().attr('style', 'margin-left:1px !important;');

					$('#phase1AlertsTable').bootstrapTable('load', $scope.currentP1Alert);
					$("#phase1AlertsTable").bootstrapTable('resetView');
					$("#phase1AlertsTable").parent().attr('style', 'margin-left:1px !important;');
					
					
					
					
					
					// Load Prioritize for UCM table FPS
					
					console.log("prioritizeForUCMTable -> ",$scope.asrDetailsDbIdParam );
					var asrptids =  [$scope.asrDetailsDbIdParam];//[632505, 633951,634663  ];
					
					if($scope.asrDetailsDbIdParam != null)
						detailsFactory.getPrioritizeForUCMTable($scope.restURL, asrptids, 	$scope.scopeUserId, $scope.activeASRTab).then(function(response) {
							console.log("prioritizeForUCMTable ->", response);	
							$scope.prioritizeForUCMTableData = response.data;
							
						}).catch(function(err){ 	
							showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Proritize for UCM table could not be loaded due to ' + err.status, 'danger');
						});
					
					// call the refdata service to get the jurisdiction dropdown
					detailsFactory.getPrioritizationZones($scope.restURL).then(function(response) {
						$scope.priorZonesOptions = response.data.zones;
						
						// hide the modal body overlay
		//				$("#priorZonesSelect").LoadingOverlay("hide");
						console.log("$scope.priorZonesOptions ->", $scope.priorZonesOptions);
					}).catch(function(err){ 
						// hide the modal body overlay
		//				$("#priorZonesSelect").LoadingOverlay("hide");
						
						showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Jurisdiction data could not be loaded due to ' + err.status, 'danger');
					});
					
					//broadcast this event to the broadcastSlaMetrics listener
					$rootScope.$broadcast('broadcastSlaMetrics', {message:"ASR Detail Load - End: " + loadPageUniqueId, userId: ""});							
			
					// set defualt focus
					//$("#asrInfoPanelTitle").focus();
					setTimeout(function(){
						$("#breadcrumb-item").focus();
					},0);
			}
		}).error(function(data, status) {
			console.log('getASRDetailsData REST Error:' + status);
			
//		 showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> No ASR Details available to ' + status, 'danger');
		
		});
	
	
	}
	
	$scope.disableMedicareTab = function(){
		
		//disable the medicaid AsrInfo Details tab
		$('#medicareAsrDetailItem').addClass('disabled');
		$('#medicareAsrDetailItem').attr('aria-disabled', 'true');
		$('#medicareAsrDetailTabLink').css('cursor', 'not-allowed');
		$('#medicareAsrDetailTabLink').css('pointer-events', 'none');
		$('#medicareAsrDetailTabLink').removeAttr('data-toggle');
		console.log("Disable Medicare tab");
		
	}
	
	$scope.disableMedicaidTab = function(){
		
		//disable the medicaid AsrInfo Details tab
		$('#medicaidAsrDetailItem').addClass('disabled');
		$('#medicaidAsrDetailItem').attr('aria-disabled', 'true');
		$('#medicaidAsrDetailTabLink').css('cursor', 'not-allowed');
		$('#medicaidAsrDetailTabLink').css('pointer-events', 'none');
		$('#medicaidAsrDetailTabLink').removeAttr('data-toggle');
		console.log("Disable Medicaid tab");
	}
	
	

	// show the CHOW tableau report
	$scope.viewChowReport = function() {
		// call the util service to get the correct Tableau URL
		var chowReportUrl = utilService.getChowReportURL($scope.providerPaneObj.npi, null, $scope.rolesArray);
		
		// open a new window with the url
		window.open(chowReportUrl);
		
		// log user activity
		$scope.trackUserActivity('RPTCHOW', null);
	}

	// disaplay the specialties modal and contents
	$scope.showPrvdrAsrSpecialty = function() {
		console.log("Inside showPrvdrAsrSpecialty. AsrId = " + $scope.asrDetailsDbIdParam);
		
		// show full page overlay
		$.LoadingOverlay("show");
		
		//display the modal window
		$("#specialtiesModal").modal("show");
		
		//initiate the modal table
		$("#specialtiesTable").bootstrapTable({});
		
		$("#specialtiesTable").bootstrapTable('load', $scope.providerPaneObj.specialties);
		
		// hide full page overlay
		$.LoadingOverlay("hide");
	}
	

	//display the medicaid modal window and contents
	$scope.viewMedicaidModal = function() {
		console.log("Inside viewMedicaidData. AsrId = " + $scope.asrDetailsDbIdParam);
		
		//show full page overlay
		$.LoadingOverlay("show");
		
		//call the summary Modal service		
		detailsFactory.getSummaryModalData($scope.restURL, $scope.asrDetailsDbIdParam, $scope.scopeUserId , "MEDICAID").success(function(data) {
			
				console.log(data);
			
				//display the modal window
				$("#medicaidModal").modal("show");
				
				//initiate the modal table
				$("#medicaidModalTable").bootstrapTable('destroy');
				$("#medicaidModalTable").bootstrapTable({});
				
				
				if (data.responseData.length>0)
				if (data.responseData[0].medicaidInfo != void(0)) {
					
					//populate the title rows of the modal window
					$scope.medicaidNpi = data.responseData[0].medicaidInfo.npi;
					$scope.medicaidAsOfDt = data.responseData[0].medicaidInfo.asOfDate;
					$scope.medicaidPrvdrName = data.responseData[0].medicaidInfo.prvdrName;
					$scope.medicaidClaimsRiskCnt = data.responseData[0].medicaidInfo.claimCnt;
					$scope.medicaidState = data.responseData[0].medicaidInfo.state;
					$scope.medicaidDollsAtRisk = data.responseData[0].medicaidInfo.dollars;
					$scope.medicaidPrvdrNumber = data.responseData[0].medicaidInfo.number;
					//$scope.medicaidAlertReason = data.responseData[0].medicaidInfo.reason;
					
					var riskyBehavDesc = data.responseData[0].medicaidInfo.reason;
					
					
					//build the hide/show more functionality for the medicaid risky behavior description
					if (riskyBehavDesc.length > 150) {
						$scope.medicaidAlertReason = $sce.trustAsHtml(riskyBehavDesc.substring(0, 150) + "<span style='display:none;' id='riskBehavDesc'>" + riskyBehavDesc.substring(150, riskyBehavDesc.length-1) 
						+ "</span><span id='riskBehavDescDots'>...</span>&nbsp;<a tabindex='0' style='cursor:pointer;' onclick='riskBehavDescShowHide(this);'>Show more</a>");
					} else {
						//risky behavior description is under 150 chars, so display it
						$scope.medicaidAlertReason = riskyBehavDesc;
					}
															
					$("#medicaidModalTable").bootstrapTable('load', data.responseData[0].medicaidInfo.data);
				}
			
			//hide modal overlay
    		$.LoadingOverlay("hide");
			
		}).error(function(data, status) {
			console.log('getSummaryModalData REST Error:' + status);
			
			//hide modal overlay
    		$.LoadingOverlay("hide");
			
			//show message to user that the summary modal service failed
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load modal data due to ' + status, 'danger');
		});
	}
	
	
	//display the medicaid modal window and contents
	$scope.viewMDCDMedicaidModal = function() {
		console.log("Inside Medicaid viewMedicaidData. AsrId = " + $scope.asrDetailsDbIdParam);
		
		//show full page overlay
		$.LoadingOverlay("show");
		
		//call the summary Modal service		
		detailsFactory.getMDCDMedicaidModalData($scope.restURL, $scope.asrDetailsDbIdParam, $scope.scopeUserId , "MEDICAID").success(function(data) {
			
				console.log("MDCD flow", data);
			
				//display the modal window
				$("#medicaidModalMDCD").modal("show");
				
				//initiate the modal table
				$("#medicaidModalMDCDTable").bootstrapTable('destroy');
				$("#medicaidModalMDCDTable").bootstrapTable({});
				
				var medicaidInfo = data.responseData.provider.medicaidInfo;
				console.log("medicaidInfo =>", medicaidInfo);
				
				
				if (medicaidInfo != null ){	
					//populate the title rows of the modal window
					$scope.medicaidNpi = medicaidInfo.npi;
					$scope.medicaidAsOfDt = medicaidInfo.asOfDate;
					$scope.medicaidPrvdrName = medicaidInfo.prvdrName;
					$scope.medicaidClaimsRiskCnt = medicaidInfo.claimCnt;
					$scope.medicaidState = medicaidInfo.state;
					$scope.medicaidDollsAtRisk = medicaidInfo.dollars;
					$scope.medicaidPrvdrNumber = medicaidInfo.number;
					//$scope.medicaidAlertReason = medicaidInfo.reason;
					
					var riskyBehavDesc = medicaidInfo.reason;
					
					
					//build the hide/show more functionality for the medicaid risky behavior description
					if (riskyBehavDesc.length > 150) {
						$scope.medicaidAlertReason = $sce.trustAsHtml(riskyBehavDesc.substring(0, 150) + "<span style='display:none;' id='riskBehavDesc'>" + riskyBehavDesc.substring(150, riskyBehavDesc.length-1) 
						+ "</span><span id='riskBehavDescDots'>...</span>&nbsp;<a tabindex='0' style='cursor:pointer;' onclick='riskBehavDescShowHide(this);'>Show more</a>");
					} else {
						//risky behavior description is under 150 chars, so display it
						$scope.medicaidAlertReason = riskyBehavDesc;
					}
					
					if (medicaidInfo.data.length >0){
						$("#medicaidModalMDCDTable").bootstrapTable('load', medicaidInfo.data);	
					}										
					
				}
			
			//hide modal overlay
    		$.LoadingOverlay("hide");
			
		}).error(function(data, status) {
			console.log('getSummaryModalData REST Error:' + status);
			
			//hide modal overlay
    		$.LoadingOverlay("hide");
			
			//show message to user that the summary modal service failed
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load modal data due to ' + status, 'danger');
		});
	}

	//this function creates the NetViz export file
	$scope.exportNetVizBtnClick  = function() {
		console.log("Inside exportNetVizBtnClick function.");
		
		//show overlay on net viz window
		$("#networkVizModalBody").LoadingOverlay("show");
		
		//call the web service to initiate the export for NetViz data
		detailsFactory.getNetVizExportData($scope.restURL, $scope.providerPaneObj.npi, $scope.vizModelName, $scope.scopeUserId, $scope.vizModelType).then(function(response) {
			//hide the modal window overlay
			$("#networkVizModalBody").LoadingOverlay("hide");
			
			//build xlsx filename from header value
			var headerVal = response.headers('Content-Disposition');
			var blobFileName = headerVal.substring(headerVal.lastIndexOf('=')+1, headerVal.length-1);
			
			var blob = response.data;
//			var blob = new Blob([response.data.fileContents], {type:'application/octet-stream'})
			if (navigator.msSaveBlob){
				//IE Browsers
				navigator.msSaveBlob(blob, blobFileName);
			} else {
				console.log("Not IE Browser");
				var url = URL.createObjectURL(blob);
				
				var link = document.createElement("a");
				link.setAttribute("download", blobFileName);
				link.setAttribute("href", url);
				document.body.appendChild(link);  //required by FF
				link.click();
				document.body.removeChild(link);  //required by FF
			}
			
		}).catch(function(err) {
			console.log('getNetVizExportData REST Error:' + JSON.stringify(err));	
			//hide the modal window overlay		
			$("#networkVizModalBody").LoadingOverlay("hide");
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Visualization export failed due to ' + err.status, 'danger');
	 });
	}

	$scope.viewPrvdrPrioritizedModal = function() {
		console.log("Inside viewPrvdrPrioritizedModal function.");
		
		//open the modal
		$("#prvdrPrioritizedModal").modal("show");
		//show the overlay
		$("#prvdrPrioritizedModalBody").LoadingOverlay("show");
		
		//initiate the modal table
		$("#prvdrPrioritizedTable").bootstrapTable('destroy');
		$("#prvdrPrioritizedTable").bootstrapTable({});
		
		 //make a call to the getTabPriorityForUCMData factory method to get the Prioritize for UCM data
		 detailsFactory.getTabPriorityForUCMData($scope.restURL, $scope.asrDetailsParam, $scope.scopeUserId,  $scope.activeASRTab).then(function(response) {
			 //refresh the prioritize for UCM table
			 $('#prvdrPrioritizedTable').bootstrapTable('load', response.data.responseData.priorities);
			 //hide the overlay
			 $("#prvdrPrioritizedModalBody").LoadingOverlay("hide");
		 }).catch(function(err) {
				console.log('getTabPriorityForUCMData REST Error:' + JSON.stringify(err));	
				//hide a tab overlay to the Prioritize for UCM  tab 		
				$("#prvdrPrioritizedModalBody").LoadingOverlay("hide");
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Prioritize for UCM table data not available due to ' + err.status, 'danger');
		 });
	}

	$scope.viewPrvdrPrioritizedModalMDCD = function() {		
		
		console.log("Inside viewPrvdrPrioritizedModal function.");
		
		//open the modal
		$("#prvdrPrioritizedModal").modal("show");
		//show the overlay
		$("#prvdrPrioritizedModalBody").LoadingOverlay("show");
		
		//initiate the modal table
		$("#prvdrPrioritizedTableMDCD").bootstrapTable('destroy');
		$("#prvdrPrioritizedTableMDCD").bootstrapTable({});
		
		 //make a call to the getTabPriorityForUCMData factory method to get the Prioritize for UCM data
		 detailsFactory.getTabPriorityForUCMData($scope.restURL, $scope.asrDetailsParam, $scope.scopeUserId, $scope.activeASRTab).then(function(response) {
			 //refresh the prioritize for UCM table
			 $('#prvdrPrioritizedTableMDCD').bootstrapTable('load', response.data.responseData.priorities);
			 //hide the overlay
			 $("#prvdrPrioritizedModalBody").LoadingOverlay("hide");
		 }).catch(function(err) {
				console.log('getTabPriorityForUCMData REST Error:' + JSON.stringify(err));	
				//hide a tab overlay to the Prioritize for UCM  tab 		
				$("#prvdrPrioritizedModalBody").LoadingOverlay("hide");
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Prioritize for UCM table data not available due to ' + err.status, 'danger');
		 });
	}


	//this function calls the user tracking service
	$scope.trackUserActivity = function(pPageId, pTrackVal) {
		
		// add asr as the track value if risk score trending is the pageId
		if (pPageId == 'RSTRENDING') {
			// set the tracking value to the ASR ID			
			pTrackVal = $scope.asrDetailsDbIdParam;
		}
		
		//call the user tracking web service to denote the fact that the user has requested a Google Map
		utilFactory.getTrackUserActivity($scope.restURL, $scope.scopeUserId, pPageId, pTrackVal).then(function(response) {
			console.log('getTrackUserActivity web service call successful.');
		}).catch(function(err) {
			console.log('getTrackUserActivity REST Error:' + err.data);			
		});		
	}

	//reset the map display to only display the original 10 benes
	$scope.resetAsrMapBenes = function() {
		console.log("Inside the resetAsrMapBenes function.");
		
		//disable the add 10 button for 5 seconds
		$("#delBeneBtn").attr("disabled", true);
		$interval(function(){$("#delBeneBtn").removeAttr("disabled");}, 5000);
				
		//reset the map results index
		$scope.asrMapResultsIndex = 0;
		console.log("$scope.asrMapResultsIndex = " + $scope.asrMapResultsIndex);
		
		//initialize the ASR Map
		initAsrMap();
		
		//retrieve the initial 10 bene results from the web service
		detailsFactory.getAsrMapsInfo($scope.restURL, $scope.asrDetailsDbIdParam, $scope.scopeUserId, $scope.asrMapResultsIndex).then(function(response) {
			
			//$scope.providerAddrObj = response.data.responseData.provider.address;
			$scope.providerAddrObj = response.data.responseData.provider.address;
			$scope.beneArrayObj = response.data.responseData.provider.benes;
			
			//console.log("Provider Address = " + JSON.stringify($scope.providerAddrObj));
						
			//call the createGoogleMap() java script method
			displayAsrMap($scope.providerAddrObj, $scope.beneArrayObj, $scope.asrMapResultsIndex);
			
		}).catch(function(err) {
			console.log('addAsrMapBenes REST Error:' + err.data);
			//$("#googleMapsPanel").LoadingOverlay("hide");
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to retrieve maps data due to ' + err.data, 'danger');
		});
	}

	//add 10 benes to the ASR maps
	$scope.addAsrMapBenes = function() {
		console.log('Inside the addAsrMapBenes function.');
		
		//disable the add 10 button for 5 seconds
		$("#addBeneBtn").attr("disabled", true);
		$interval(function(){$("#addBeneBtn").removeAttr("disabled");}, 5000);
		
		//increase the map results index
		$scope.asrMapResultsIndex = $scope.asrMapResultsIndex + 1;
		console.log("$scope.asrMapResultsIndex = " + $scope.asrMapResultsIndex);
		
		//load the google map
		detailsFactory.getAsrMapsInfo($scope.restURL, $scope.asrDetailsDbIdParam, $scope.scopeUserId, $scope.asrMapResultsIndex).then(function(response) {
			
			//$scope.providerAddrObj = response.data.responseData.provider.address;
			$scope.providerAddrObj = response.data.responseData.provider.address;
			$scope.beneArrayObj = response.data.responseData.provider.benes;
			
			//console.log("Provider Address = " + JSON.stringify($scope.providerAddrObj));
			
			//check to see if there are any benes left
			if ($scope.beneArrayObj.length > 0) {
				//add benes to the map
				displayAsrBeneMap($scope.providerAddrObj, $scope.beneArrayObj, $scope.asrMapResultsIndex);
			} else {
				//tell user there are no more results
				showGrowl('<i class=\'fa fa-info-circle\' aria-hidden=\'true\'></i> There are no more results to display on the map.', 'info');
			}
			
		}).catch(function(err) {
			console.log('addAsrMapBenes REST Error:' + err.data);
			//$("#googleMapsPanel").LoadingOverlay("hide");
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to retrieve maps data due to ' + err.data, 'danger');
		});
	}

	//view the report cards from the Alerts pop-up initiated from Master Alerts
	$scope.viewAlertReportCard = function(pInsertDt, pModelTypeCd) {
		console.log('Inside viewAlertReportCard function. pModelId = ' 
				+ $scope.alertModelId + ', pNpi = ' + $scope.alertNpi + ', pInsertDt = ' + pInsertDt + ', pModelTypeCd = ' + pModelTypeCd);
		
		//call the showReportCard function to display report card info
		$scope.showReportCard($scope.alertModelId, $scope.alertNpi, pModelTypeCd, pInsertDt);
		
	}
	//view the report cards from the Alerts pop-up initiated from Master Alerts
	$scope.viewAlertReportCardMDCD = function(pInsertDt, pModelTypeCd, state) {
		console.log('Inside viewAlertReportCardMDCD function. pModelId = ' 
				+ $scope.alertModelId + ', pNpi = ' + $scope.alertNpi + ', pInsertDt = ' + pInsertDt + ', pModelTypeCd = ' + pModelTypeCd);
		
		//call the showReportCard function to display report card info
		$scope.showReportCard($scope.alertModelId, $scope.alertNpi, pModelTypeCd, pInsertDt, state);
		
	}
	// view the ASR Details for an NPI from the custom report card
	$scope.viewNpiRprtCardDetails = function(pNpi) {
		console.log('Inside viewNpiRprtCardDetails. pNpi = ' + pNpi);
		
		//redirect the user to the ASR Detail Page
		$window.open("#ASRDetails?asrRptCardIdParam=" + pNpi);
	}

	// view current or historical alerts
	$scope.viewAlerts = function(pModelId, pNpi, pModelName, pAlertsObj) {
		console.log('viewAlerts function. pModelId = ' + pModelId + ', pNpi = ' 
				+ pNpi + ', pModelName = ' + pModelName); 
		
		// set the scope based NPI and modelId variables for use in the report card service
		$scope.alertModelId = pModelId;
		$scope.alertNpi = pNpi;
		$('#alertModelNmSpan').text(pModelName);
		
		// display the modal window
		$("#alertsModal").modal("show");
		
		// initiate the modal table
		$("#alertsModalTable").bootstrapTable({});
		
		// load the data in the modal table
		$("#alertsModalTable").bootstrapTable('load', pAlertsObj);
	}
	// view current or historical phase 1 alerts
	$scope.phase1ViewAlerts = function(pModelId, pNpi, pModelName, pAlertsObj) {
		console.log('phase1ViewAlerts function. pModelId = ' + pModelId + ', pNpi = ' 
				+ pNpi + ', pModelName = ' + pModelName); 
		
		// set the scope based NPI and modelId variables for use in the report card service
		$scope.alertModelId = pModelId;
		$scope.alertNpi = pNpi;
		$('#phase1AlertModelNmSpan').text(pModelName);
		
		// display the modal window
		$("#phase1AlertsModal").modal("show");
		
		// initiate the modal table
		$("#phase1AlertsModalTable").bootstrapTable({});
		
		// load the data in the modal table
		$("#phase1AlertsModalTable").bootstrapTable('load', pAlertsObj);
	}
	// view current or historical alerts
	$scope.viewAlertsMDCD = function(pModelId, pNpi, pModelName, pAlertsObj) {
		console.log('viewAlertsMDCD function. pModelId = ' + pModelId + ', pNpi = ' 
				+ pNpi + ', pModelName = ' + pModelName); 
		console.log("pAlertsObj=>", pAlertsObj);
		
		// set the scope based NPI and modelId variables for use in the report card service
		$scope.alertModelId = pModelId;
		$scope.alertNpi = pNpi;
		$('#alertModelNmSpanMDCD').text(pModelName);
		
		// display the modal window
		$("#alertsModalMDCD").modal("show");
		
		// initiate the modal table
		$("#alertsModalTableMDCD").bootstrapTable({});
		
		// load the data in the modal table
		$("#alertsModalTableMDCD").bootstrapTable('load', pAlertsObj);
	}

	//view the Complaints listed in the provider info panel
	$scope.viewComplaintsModal = function() {
		console.log('Inside the viewComplaintsModal function.');
		
		//show full page overlay
		$("#complaintsModalBody").LoadingOverlay("show");
		
		//show the complaints modal							
		$("#complaintsModal").modal("show");
		
		//call the factory systags service to retrieve the complaints
		detailsFactory.getSysTagsData($scope.restURL, $scope.asrDetailsParam, $scope.scopeUserId).success(function(data) {
			
			// get the biu summary
			$scope.biuDay90Cnt = data.responseData.biuSummary.day90Cnt;
			$scope.biuTotalCnt = data.responseData.biuSummary.totalCnt;
			$scope.biuSummary = data.responseData.biuSummary.biuSummary;
			
			//loop through the bius array and locate the value for each table cell
/*			$scope.biuComplaintsObj = data.responseData.systags.bius;
			$scope.complaintsBiu4wkPartA = '';
			$scope.complaintsBiu4wkPartB = '';
			$scope.complaintsBiu4wkDME = '';
			$scope.complaintsBiu1yrPartA ='';
			$scope.complaintsBiu1yrPartB = '';
			$scope.complaintsBiu1yrDME = '';
			
			console.log('bius length = ' + $scope.biuComplaintsObj.length);
			for (i = 0; i < $scope.biuComplaintsObj.length; i++) {
				if ($scope.biuComplaintsObj[i].timeType === "4 Weeks") {
					console.log("4wk BIU found, checking type...");
					if ($scope.biuComplaintsObj[i].claimType === "Part A") {
						console.log("4wk Part A found.");
						$scope.complaintsBiu4wkPartA = $scope.biuComplaintsObj[i].count;
					} else if ($scope.biuComplaintsObj[i].claimType === "Part B") {
						console.log("4wk Part B found.");
						$scope.complaintsBiu4wkPartB = $scope.biuComplaintsObj[i].count;
					} else if ($scope.biuComplaintsObj[i].claimType === "DME") {
						console.log("4wk DME found.");
						$scope.complaintsBiu4wkDME = $scope.biuComplaintsObj[i].count;
					}
				} else if ($scope.biuComplaintsObj[i].timeType === "1 Year") {
					console.log("1yr BIU found, checking type...");
					
					if ($scope.biuComplaintsObj[i].claimType === "Part A") {
						console.log("1yr Part A found.");
						$scope.complaintsBiu1yrPartA = $scope.biuComplaintsObj[i].count;
					} else if ($scope.biuComplaintsObj[i].claimType === "Part B") {
						console.log("1yr Part B found.");
						$scope.complaintsBiu1yrPartB = $scope.biuComplaintsObj[i].count;
					} else if ($scope.biuComplaintsObj[i].claimType === "DME") {
						console.log("1yr DME found.");
						$scope.complaintsBiu1yrDME = $scope.biuComplaintsObj[i].count;
					}
				}
			}
			
			//initiate the complaints table
			$("#complaintsTable").bootstrapTable({});
			
			//update the table values
			$('#complaintsTable').bootstrapTable('updateRow', {
			    index: 0,
			    row: {
			    	rowPartA: $scope.complaintsBiu4wkPartA,
			    	rowPartB: $scope.complaintsBiu4wkPartB,
			    	rowDME: $scope.complaintsBiu4wkDME
			    }
			  });
			
			$('#complaintsTable').bootstrapTable('updateRow', {
			    index: 1,
			    row: {
			    	rowPartA: $scope.complaintsBiu1yrPartA,
			    	rowPartB: $scope.complaintsBiu1yrPartB,
			    	rowDME: $scope.complaintsBiu1yrDME
			    }
			  });
*/				
			//hide full page overlay
			$("#complaintsModalBody").LoadingOverlay("hide");
			
		}).error(function(data, status) {
			console.log('getSysTagsData REST Error:' + status);
			//hide the panel overlay
			$("#complaintsModalBody").LoadingOverlay("hide");
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> System Tags table data not loaded due to ' + status, 'danger');
		});
		
		
	}

	//view the Network Visualization diagram for the model chosen in the Alerts table
	$scope.viewNetworkViz = function(pModelId, pModelName, pModelType) {
		console.log("Inside viewNetworkViz function. pModelId = " + pModelId 
				+  ", pModelName = " + pModelName + ", ModelType = " + pModelType);
		
		// set a scope variable for the model type
		$scope.vizModelType = pModelType;
		
		// by default, hide the add connections button since it's only for HHA models
		$scope.hideAddCnctnBtn = true;
				
		// set the visualization results index = 0 (to be used by the add connections button)
		$scope.vizConnectionsIndex = 0;
		
		$scope.vizModelName = pModelName;
		
		//show net viz modal body overlay
		$("#networkVizModalBody").LoadingOverlay("show");
		
		//show the net viz modal							
		$("#networkVizModal").modal("show");
		
		// clear the nodes and edges lists
		$("#nodesList").empty();
		$("#edgesList").empty();
		
		// if HHA model, then call the HHA web services
		if(pModelType == 'HHA') {
			// show the add connection button for HHA only
			$scope.hideAddCnctnBtn = true;
			
			// call the HHA NetViz web service to get nodes and edges
			detailsFactory.getNetVizHhaData($scope.restURL, $scope.providerPaneObj.npi, pModelName, $scope.scopeUserId).success(function(data) {
				// set the scope variables used for the client
				$scope.vizNodes = data.nodes;
				$scope.vizEdges = data.edges;
				$scope.vizAttributes = data.attributes;	
				
				//call the build viz method if viz data exists
				if ($scope.vizNodes.length != 0 && $scope.vizEdges.length) {
					buildNetViz($scope.vizNodes, $scope.vizEdges, 'hha');
				}
				
				//hide the overlay spinner
				$("#networkVizModalBody").LoadingOverlay("hide");
			}).error(function(data, status) {
				console.log('getNetVizHhaData REST Error:' + status);
				//hide the panel overlay
				$("#networkVizModalBody").LoadingOverlay("hide");
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Provider Network HHA data not loaded due to ' + status, 'danger');
			});
		} if (pModelType == 'DME') {
			// show the add connection button for DME only
			$scope.hideAddCnctnBtn = true;
			
			// call the DME NetViz web service to get the nodes and edges
			detailsFactory.getNetVizDmeData($scope.restURL, $scope.providerPaneObj.npi, pModelName, $scope.scopeUserId).success(function(data) {
				// set the scope variables used for the client
				$scope.vizNodes = data.nodes;
				$scope.vizEdges = data.edges;
				$scope.vizAttributes = data.attributes;	
				
				//call the build viz method if viz data exists
				if ($scope.vizNodes.length != 0 && $scope.vizEdges.length) {
					buildNetViz($scope.vizNodes, $scope.vizEdges, 'dme');
				}
				
				//hide the overlay spinner
				$("#networkVizModalBody").LoadingOverlay("hide");
			}).error(function(data, status) {
				console.log('getNetVizDMEData REST Error:' + status);
				//hide the panel overlay
				$("#networkVizModalBody").LoadingOverlay("hide");
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Provider Network DME data not loaded due to ' + status, 'danger');
			});
		} else {
			// hide the add connections button since it's only for HHA models
			$scope.hideAddCnctnBtn = true;
									
			//call the NetViz service to get the plot points
			detailsFactory.getNetVizData($scope.restURL, $scope.providerPaneObj.npi, pModelName, $scope.scopeUserId).success(function(data) {
							
				//convert response to JSON object
				//$scope.netVizData = JSON.parse(data.responseData);
				$scope.vizNodes = data.nodes;
				$scope.vizEdges = data.edges;
				$scope.vizAttributes = data.attributes;
				
				//console.log("# of Nodes = " + $scope.vizNodes.length);
				//console.log("# of Edges = " + $scope.vizEdges.length);
				//console.log("# of Attributes = " + $scope.vizAttributes.length);
							
				//call the build viz method if viz data exists
				if ($scope.vizNodes.length != 0 && $scope.vizEdges.length) {
					buildNetViz($scope.vizNodes, $scope.vizEdges, 'sna');
				}
				
				//hide the overlay spinner
				$("#networkVizModalBody").LoadingOverlay("hide");
							
			}).error(function(data, status) {
				console.log('getNetVizData REST Error:' + status);
				//hide the panel overlay
				$("#networkVizModalBody").LoadingOverlay("hide");
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Provider Network data not loaded due to ' + status, 'danger');
			});
		}
		

	}

	//process the Attribute Comparison reports button click
	$scope.showAttrComparisonRpt = function() {
		console.log('Inside showAttrComparisonRpt function.');
		
		//call the util service to get the correct Tableau URL
		var attrModelUrl = utilService.getModelAttributeReportURL($scope.providerPaneObj.npi, $scope.scopeUserZone, $scope.rolesArray);
		
		//open a new window with the url
		window.open(attrModelUrl);
	}
	
	// handle the click event for the NNH Net Viz button
	$scope.hhaNetVizBtnClick = function() {
		console.log('Inside hhaNetVizBtnClick function.');
		
		// call the viewNetworkViz method to retrieve the data
		$scope.viewNetworkViz("", "HHA", "HHA");
	}
	
	// handle the click event for the DME Net Viz button
	$scope.dmeNetVizBtnClick = function() {
		console.log('Inside dmeNetVizBtnClick function.');
		
		// call the viewNetworkViz method to retrieve the data
		$scope.viewNetworkViz("", "DME", "DME");
	}

	// handle the click event for the field export button
	$scope.fieldExportBtnClick = function() {
		console.log('Inside fieldExportBtnClick function.');
		
		// show full overlay
		$.LoadingOverlay("show");
		
		// call the web service required to return export data
		detailsFactory.getFieldExport($scope.restURL, $scope.providerPaneObj.npi, $scope.scopeUserId).then(function(response) {
			
			//hide full overlay
			$.LoadingOverlay("hide");
			
			//build xlsx filename from header value
			var headerVal = response.headers('Content-Disposition');
			var blobFileName = headerVal.substring(headerVal.lastIndexOf('=')+1, headerVal.length-1);
											
			var blob = response.data;
//			var blob = new Blob([response.data.fileContents], {type:'application/octet-stream'})
			if (navigator.msSaveBlob){
				//IE Browsers
				navigator.msSaveBlob(blob, blobFileName);
			} else {
				console.log("Not IE Browser");
				var url = URL.createObjectURL(blob);
				
				var link = document.createElement("a");
				link.setAttribute("download", blobFileName);
				link.setAttribute("href", url);
				document.body.appendChild(link);  //required by FF
				link.click();
				document.body.removeChild(link);  //required by FF
			}

		}).catch(function(err){ 
			// hide full overlay
			$.LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Fields could not be exported due to ' + err.status, 'danger');
		});
	}
	// handle the click event for the field export button
	$scope.fieldExportMdcdBtnClick = function() {
		console.log('Inside fieldExportBtnClick function.');
		
		// show full overlay
		$.LoadingOverlay("show");
		
		// call the web service required to return export data
		detailsFactory.getFieldExportMdcd($scope.restURL, $scope.providerPaneObj.npi, $scope.scopeUserId).then(function(response) {
			
			//hide full overlay
			$.LoadingOverlay("hide");
			
			//build xlsx filename from header value
			var headerVal = response.headers('Content-Disposition');
			var blobFileName = headerVal.substring(headerVal.lastIndexOf('=')+1, headerVal.length-1);
											
			var blob = response.data;
//			var blob = new Blob([response.data.fileContents], {type:'application/octet-stream'})
			if (navigator.msSaveBlob){
				//IE Browsers
				navigator.msSaveBlob(blob, blobFileName);
			} else {
				console.log("Not IE Browser");
				var url = URL.createObjectURL(blob);
				
				var link = document.createElement("a");
				link.setAttribute("download", blobFileName);
				link.setAttribute("href", url);
				document.body.appendChild(link);  //required by FF
				link.click();
				document.body.removeChild(link);  //required by FF
			}

		}).catch(function(err){ 
			// hide full overlay
			$.LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Fields could not be exported due to ' + err.status, 'danger');
		});
	}

	//process the Provider Profile report button click
	$scope.showProviderProfile = function() {
//		console.log('Inside showProviderProfile function. ' + $scope.asrDetailsDbIdParam);
		
		//call the util service to get the correct Tableau URL
		var proProfileUrl = utilService.getProviderProfileURL($scope.asrDetailsDbIdParam, $scope.providerPaneObj.npi, $scope.scopeUserZone, $scope.rolesArray);
		//open a new window with the url
		window.open(proProfileUrl);
		
		//log user activity
		$scope.trackUserActivity('RPTPP', null);
	}
	
	// process the Edit Trend Report
	$scope.showEditTrendReport = function() {
		console.log('Inside showEditTrendReport function.');
		
		//call the util service to get the correct Tableau URL
		var editTrendUrl = utilService.getEditTrendReportURL($scope.providerPaneObj.npi, $scope.scopeUserZone, $scope.rolesArray);
		
		//open a new window with the url
		window.open(editTrendUrl);
		
		//log user activity
		$scope.trackUserActivity('RPTET', null);
	}

	// process the Provider Education report button click
	$scope.showPrvdrEduReport = function() {
		console.log('Inside showPrvdrEduReport function.');
		
		//call the util service to get the correct Tableau URL
		var proEducationUrl = utilService.getPrvdrEduReportURL($scope.providerPaneObj.npi, $scope.scopeUserZone, $scope.rolesArray);
		//open a new window with the url
		window.open(proEducationUrl);
		
		//log user activity
		$scope.trackUserActivity('RPTPE', null);
	}
	
	// process the Provider Education Attribute report button click
	$scope.showPrvdrEduAttrReport = function() {
		console.log('Inside showPrvdrEduAttrReport function.');
		
		//call the util service to get the correct Tableau URL
		var proEducationAttrUrl = utilService.getPrvdrEduAttrReportURL($scope.providerPaneObj.npi, $scope.scopeUserZone, $scope.rolesArray);
		//open a new window with the url
		window.open(proEducationAttrUrl);
		
		//log user activity
		$scope.trackUserActivity('RPTPEA', null);
	}

	// process the Net Viz add connections button click
	$scope.addNetVizConnectClick = function() {
		console.log('Inside addNetVizConnectClick function.');
		
		$("#networkVizModalBody").LoadingOverlay("show");
		
		// increase the viz results index
		$scope.vizConnectionsIndex = $scope.vizConnectionsIndex + 1;
		console.log('vizConnectionsIndex = ' + $scope.vizConnectionsIndex);
		
		// disable the button after 2 clicks
		if ($scope.vizConnectionsIndex == 2) {
			//disable button
		
		}
				
		// call the web services to get more HHA connections
		detailsFactory.addNetVizHhaConnections($scope.restURL, $scope.providerPaneObj.npi, $scope.vizModelName, $scope.scopeUserId, $scope.vizConnectionsIndex).success(function(data) {
			// hide the panel overlay
			$("#networkVizModalBody").LoadingOverlay("hide");
			
			// call the method to update the nodes
			addNetVizNodes(data.nodes);
			
		}).error(function(data, status) {
			console.log('addNetVizHhaConnections REST Error:' + status);
			
			// hide the panel overlay
			$("#networkVizModalBody").LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Provider Network HHA connections not loaded due to ' + status, 'danger');
		});
				
	}

	// populate the Leads/Investigations History tab
	$scope.leadsHistTabClick = function() {
		// attach the overlay to the leads/investigations history tab body
		$("#leadsHistoryTab").LoadingOverlay("show");
		
		// destroy, and then initialize the leads/investigations history table
		$("#leadsHistoryTable").bootstrapTable('destroy');		
		$("#leadsHistoryTable").bootstrapTable({});
		
		// call the getASRDetailsData factory method to get the tab data
		detailsFactory.getASRDetailsData($scope.restURL, $scope.asrDetailsParam, 'HLEADS', $scope.scopeUserId, $scope.activeASRTab )
		.success(function(data) {
			 
			// load the leads/investigations history table with the response data 
			$("#leadsHistoryTable").bootstrapTable('load', data.responseData.leads);
			
			// Hide full page LoadingOverlay			
			$("#leadsHistoryTab").LoadingOverlay("hide");
			 
		 }).error(function(data, status) {
			console.log('getASRDetailsData REST Error:' + status);
			
			// Hide full page LoadingOverlay			
			$("#leadsHistoryTab").LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Leads/Investigations data not available due to ' + status, 'danger');
		});
	}
	$scope.alertHistTabMdcdClick = function(){
	
		console.log('Inside alertHistTabMdcdClick function.');
		
		 // attach a tab overlay to the alerts history tab body
		 $("#alertsHistoryTabMdcd").LoadingOverlay("show");
		 
		 // destroy, and then initialize the alerts history table
		 $("#alertsHistoryTableMdcd").bootstrapTable('destroy');
		 $("#alertsHistoryTableMdcd").bootstrapTable({});
		 
		 // call the getASRDetailsData factory method to get the tab data
		 detailsFactory.getASRDetailsData($scope.restURL, $scope.asrDetailsParam, 'HALERTS', $scope.scopeUserId, $scope.activeASRTab )
		 .success(function(data) {
			 
			 // load the alerts table with the response data 
			 $("#alertsHistoryTableMdcd").bootstrapTable('load', data.responseData.oldAlert);
			 
			// Hide full page LoadingOverlay			
			$("#alertsHistoryTabMdcd").LoadingOverlay("hide");
			 
		 }).error(function(data, status) {
			console.log('getASRDetailsData REST Error:' + status);
			
			// Hide full page LoadingOverlay			
			$("#alertsHistoryTabMdcd").LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Alerts data not available due to ' + status, 'danger');
		});
	
		
	}
	// populate the Alerts History Tab 
	$scope.alertHistTabClick = function() {
		console.log('Inside alertHistTabClick function.');
		
		 // attach a tab overlay to the alerts history tab body
		 $("#alertsHistoryTab").LoadingOverlay("show");
		 
		 // destroy, and then initialize the alerts history table
		 $("#alertsHistoryTable").bootstrapTable('destroy');
		 $("#alertsHistoryTable").bootstrapTable({});
		 
		 // call the getASRDetailsData factory method to get the tab data
		 detailsFactory.getASRDetailsData($scope.restURL, $scope.asrDetailsParam, 'HALERTS', $scope.scopeUserId, $scope.activeASRTab )
		 .success(function(data) {
			 
			 // load the alerts table with the response data 
			 $("#alertsHistoryTable").bootstrapTable('load', data.responseData.oldAlert);
			 
			// Hide full page LoadingOverlay			
			$("#alertsHistoryTab").LoadingOverlay("hide");
			 
		 }).error(function(data, status) {
			console.log('getASRDetailsData REST Error:' + status);
			
			// Hide full page LoadingOverlay			
			$("#alertsHistoryTab").LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Alerts data not available due to ' + status, 'danger');
		});
	}
	// populate the phase 1 Alerts History Tab 
	$scope.phase1AlertHistTabClick = function() {
		console.log('Inside phase1alertHistTabClick function.');
		
		 // attach a tab overlay to the alerts history tab body
		 $("#phase1AlertsHistoryTab").LoadingOverlay("show");
		 
		 // destroy, and then initialize the alerts history table
		 $("#phase1AlertsHistoryTable").bootstrapTable('destroy');
		 $("#phase1AlertsHistoryTable").bootstrapTable({});
		 
		 // call the getASRDetailsData factory method to get the tab data
		 detailsFactory.getASRDetailsData($scope.restURL, $scope.asrDetailsParam, 'P1HALERTS', $scope.scopeUserId, $scope.activeASRTab )
		 .success(function(data) {
			 
			 // load the alerts table with the response data 
			 $("#phase1AlertsHistoryTable").bootstrapTable('load', data.responseData.historyP1Alert);
			 
			// Hide full page LoadingOverlay			
			$("#phase1AlertsHistoryTab").LoadingOverlay("hide");
			 
		 }).error(function(data, status) {
			console.log('getASRDetailsData REST Error:' + status);
			
			// Hide full page LoadingOverlay			
			$("#phase1AlertsHistoryTab").LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i>Phase 1 Alerts data not available due to ' + status, 'danger');
		});
	}

	//populate the Part D Reports tab when clicked by the user
	$scope.partDReportsTabClick = function() {
		console.log('Inside partDReportsTabClick function.');
		
		//attach a tab overlay to the Part D Reports Tab
		$("#partDReportsTab").LoadingOverlay("show");
		
		//destroy, and then initialize the Opioid Adverse Effects table
		$("#opAdverseEffTable").bootstrapTable('destroy');
		$("#opAdverseEffTable").bootstrapTable({});
		
	   //destroy, and then initialize the Opioid Benzodiazepines table
	   $("#opBenzTable").bootstrapTable('destroy');
	   $("#opBenzTable").bootstrapTable({});
	   
	   //destroy, and then initialize the Opioid Adverse Effects table
	   $("#opPrescribTable").bootstrapTable('destroy');
	   $("#opPrescribTable").bootstrapTable({});
	   
		//destroy, and then initialize the OIG Adverse Effects table
		$("#oigTable").bootstrapTable('destroy');
		$("#oigTable").bootstrapTable({});
		
		//destroy, and then initialize the Ad Hoc reports table
		$("#adhocTable").bootstrapTable('destroy');
		$("#adhocTable").bootstrapTable({});
		
		//make a call to the getTabPartDReportsData factory method to get the Part D data
		detailsFactory.getTabPartDReportsData($scope.restURL, $scope.asrDetailsParam, $scope.scopeUserId).then(function(response) {
			
			//create a boolean to move the active tab to only tabs that are displayed
//			 var activeBool = false;  //use with style="display:none" on each tab
			
			//loop through the reports array and build each table
			$scope.reportsArray = response.data.responseData.partD.reports;

			for (i = 0; i < $scope.reportsArray.length; i++) {
				if ($scope.reportsArray[i].type == 'OAE') {
//					 console.log("Creating OAE report tab. Active = " + activeBool);
					
				   //create the columns array for the OAE table
					var oaeColumns = [];
					//create an object and an array to hold the data
					var oaeDataObj = {};
					var oaeData = [];
					
					//get the adHocCols array from the response
					var adHocColsArray = $scope.reportsArray[i].adHocCols;
//					 console.log("OAE adHocColsArray size = " + adHocColsArray.length);
					
					//loop through the adHocCols array of the OAE report, and then build the columns with the values
					for (j=0; j < adHocColsArray.length; j++) {
						//get the name of the adhoc column, and then strip out parenthesis and quotes
						var nameValStrInit = adHocColsArray[j].name.replace(/['"()]+/g, '');
//						 console.log("nameValStrInit = " + nameValStrInit);
						//replace and equal signs (=) with the word 'equals'
						var nameValStr = nameValStrInit.replace(/[=]+/g, 'equals');
						
					   //push the new column and value into the columns array
						oaeColumns.push({
							field: nameValStr,                   
							title: nameValStr,
							sortable: true
						});
						
						//make an entry in the data array
						oaeDataObj[nameValStr] = adHocColsArray[j].value;
					}
					
					//add the adhoc JSON object to the data array
					oaeData.push(oaeDataObj);
					//console.log('oaeData = ' + JSON.stringify(oaeData));
					
					//load the data for the OAE table
				   $('#opAdverseEffTable').bootstrapTable('refreshOptions',{
						columns:oaeColumns,
						data:oaeData
				   });
				   
				   //show the tab
//					$('#oaeNavTab').show();
				   
				   //if activeBool is false, set this tab to active
//					if (activeBool == false) {
//						$('#oaeNavTab').tab('show');
//						activeBool = true;
//					}
					
				} else if($scope.reportsArray[i].type == 'OB') {
//					 console.log("Creating OB report tab. Active = " + activeBool);
					
					//create the columns array for the OB table
					var obColumns = [];
					//create an object and an array to hold the data
					var obDataObj = {};
					var obData = [];
					
					//get the adHocCols array from the response
					var adHocColsArray = $scope.reportsArray[i].adHocCols;
//					 console.log("OB adHocColsArray size = " + adHocColsArray.length);
					
					//loop through the adHocCols array of the OB report, and then build the columns with the values
					for (j=0; j < adHocColsArray.length; j++) {
						//get the name of the adhoc column, and then strip out parenthesis and quotes
						var nameValStrInit = adHocColsArray[j].name.replace(/['"()]+/g, '');
//						 console.log("nameValStrInit = " + nameValStrInit);
						//replace and equal signs (=) with the word 'equals'
						var nameValStr = nameValStrInit.replace(/[=]+/g, 'equals');
						
					   //push the new column and value into the columns array
						obColumns.push({
							field: nameValStr,                   
							title: nameValStr,
							sortable: true
						});
						
						//make an entry in the data array
						obDataObj[nameValStr] = adHocColsArray[j].value;
					}
					
					//add the adhoc JSON object to the data array
					obData.push(obDataObj);
					//console.log('obData = ' + JSON.stringify(obData));
					
					//load the data for the OB table
				   $('#opBenzTable').bootstrapTable('refreshOptions',{
						columns:obColumns,
						data:obData
				   });
				   
				   //show the tab
//					$('#obNavTab').show();
				   
				   //if activeBool is false, set this tab to active
//					if (activeBool == false) {
//						$('#obNavTab').tab('show');
//						activeBool = true;
//					}
				   
				} else if ($scope.reportsArray[i].type == 'OP') {
//					 console.log("Creating OP report tab. Active = " + activeBool);
					
					//create the columns array for the OP table
					var opColumns = [];
					//create the data object and array to hold the values
					var opDataObj = {};
					var opData = [];
					
					//get the adHocCols array from the response
					var adHocColsArray = $scope.reportsArray[i].adHocCols;
//					 console.log("OP adHocColsArray size = " + adHocColsArray.length);
					
				   //loop through the adHocCols array of the OP report, and then build the columns with the values
					for (j=0; j < adHocColsArray.length; j++) {
						//get the name of the adhoc column, and then strip out parenthesis and quotes
						var nameValStrInit = adHocColsArray[j].name.replace(/['"()]+/g, '');
//						 console.log("nameValStrInit = " + nameValStrInit);
						//replace and equal signs (=) with the word 'equals'
						var nameValStr = nameValStrInit.replace(/[=]+/g, 'equals');
						
						//push the new column and value into the columns array
						opColumns.push({
							field: nameValStr,                   
							title: nameValStr,
							sortable: true
						});
												
						//make an entry in the data array
						opDataObj[nameValStr] = adHocColsArray[j].value;
					}
					
					//add the adhoc JSON object to the data array
					opData.push(opDataObj);
					//console.log('opData = ' + JSON.stringify(opData));
					
					//refresh the table with the new columns and data
					$("#opPrescribTable").bootstrapTable('refreshOptions',{
						columns:opColumns,
						data:opData
					});
			   
					//show the tab
//					 $('#opNavTab').show();
			   
					//if activeBool is false, set this tab to active
//					 if (activeBool == false) {
//						$('#opNavTab').tab('show');
//						activeBool = true;
//					 }
				} else if ($scope.reportsArray[i].type == 'OIG' || $scope.reportsArray[i].type == 'OIG2') {
//					 console.log("Creating OIG report tab. Active = " + activeBool);
					
					//create the columns array for the OIG table
					var oigColumns = [];
					//create the data object and array to hold the values
					var oigDataObj = {};
					var oigData = [];
					
					//get the adHocCols array from the response
					var adHocColsArray = $scope.reportsArray[i].adHocCols;
//					 console.log("OIG adHocColsArray size = " + $scope.reportsArray[i].adHocCols.length);
					
					//loop through the adHocCols array of the OIG report, and then build the columns with the values
					for (j=0; j < adHocColsArray.length; j++) {
						//get the name of the adhoc column, and then strip out parenthesis and quotes
						var nameValStrInit = adHocColsArray[j].name.replace(/['"()]+/g, '');
//						 console.log("nameValStrInit = " + nameValStrInit);
						//replace and equal signs (=) with the word 'equals'
						var nameValStr = nameValStrInit.replace(/[=]+/g, 'equals');
						
						//push the new column and value into the columns array
						oigColumns.push({
							field: nameValStr,                   
							title: nameValStr,
							sortable: true
						});
												
						//make an entry in the data array
						oigDataObj[nameValStr] = adHocColsArray[j].value;
					}
					
					//add the adhoc JSON object to the data array
					oigData.push(oigDataObj);
					//console.log('oigData = ' + JSON.stringify(oigData));
					
					//refresh the table with the new columns and data
					$("#oigTable").bootstrapTable('refreshOptions',{
						columns:oigColumns,
						data:oigData
					});
				   
					//show the tab
//					 $('#oigNavTab').show();
				   
					//if activeBool is false, set this tab to active
//					 if (activeBool == false) {
//						$('#oigNavTab').tab('show');
//						activeBool = true;
//					 }

				} else if ($scope.reportsArray[i].type == 'AH') {
//					 console.log("Creating AH report tab. Active = " + activeBool);
					
				   //create the columns array for the AH table
					var ahColumns = [];
					//create the data object and array to hold the values
					var ahDataObj = {};
					var ahData = [];
					
					//get the adHocCols array from the response
					var adHocColsArray = $scope.reportsArray[i].adHocCols;
//					 console.log("AH adHocColsArray size = " + $scope.reportsArray[i].adHocCols.length);
					
					//loop through the adHocCols array of the AH report, and then build the columns with the values
					for (j=0; j < adHocColsArray.length; j++) {
						//get the name of the adhoc column, and then strip out parenthesis and quotes
						var nameValStrInit = adHocColsArray[j].name.replace(/['"()]+/g, '');
//						 console.log("nameValStrInit = " + nameValStrInit);
						//replace and equal signs (=) with the word 'equals'
						var nameValStr = nameValStrInit.replace(/[=]+/g, 'equals');
						
						//push the new column and value into the columns array
						ahColumns.push({
							field: nameValStr,                   
							title: nameValStr,
							sortable: true
						});
												
						//make an entry in the data array
						ahDataObj[nameValStr] = adHocColsArray[j].value;
					}
					
					ahData.push(ahDataObj);
					//console.log('ahData = ' + JSON.stringify(aData));
					
					//refresh the table with the new columns and data
					$("#adhocTable").bootstrapTable('refreshOptions',{
						columns:ahColumns,
						data:ahData
					});
				   
				   //show the tab
//					$('#adhocNavTab').show();
				   
				   //if activeBool is false, set this tab to active
//					if (activeBool == false) {
//						$('#adhocNavTab').tab('show');
//						activeBool = true;
//					}
				}
			}
			
			$("#partDReportsTab").LoadingOverlay("hide");
			
		}).catch(function(err) {
			   console.log('getTabPartDReportsData REST Error:' + JSON.stringify(err));	
			   //hide a tab overlay to the Prioritize for UCM  tab 		
			   $("#partDReportsTab").LoadingOverlay("hide");
			   showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Part D Reports data not available due to ' + err.status, 'danger');
		});
	}

	//show the criminal (aps) modal
	$scope.viewCriminalModal = function() {
		console.log('Inside viewCriminalModal function.');		
				
		//display the modal window
		$("#criminalModal").modal("show");
		
		//initiate the modal table
		$("#criminalTable").bootstrapTable({});
		
		$("#criminalTable").bootstrapTable('load', $scope.providerPaneObj.apsRecs);
		
		// call the tracking service
		$scope.trackUserActivity("APSDETAIL", null);
	}

	// show the revocation modal
	$scope.viewRevocationModal = function() {
		console.log('Inside viewRevocationModal function.');
		
		//create an array to hold the revocation date and desc
		var revocationArray = [];
		revoObj = {};
		revoObj.revocationDate = $scope.providerPaneObj.revocationDate;
		revoObj.revocationDesc = $scope.providerPaneObj.revocationDesc;
		revocationArray.push(revoObj);
		
//		console.log('revocationArray = ' + JSON.stringify(revocationArray));
		
		//display the modal window
		$("#revocationsModal").modal("show");
		
		//initiate the modal table
		$("#revocationsTable").bootstrapTable({});
		
		$("#revocationsTable").bootstrapTable('load',revocationArray);
	}

	//process the Provider & Bene addresses needed to display Google Map for an Alert (Model)
	$scope.showModelGoogleMap = function(pModelId, pNpi) {
		console.log('Inside showModelGoogleMap function.');
		
		//call the /rest/asr/{asrptId}/alert/{modelId}/benes service to get Benes
		detailsFactory.getModelBenes($scope.restURL, pModelId, pNpi).then(function(response) {
			console.log('Number of Model Benes = ' + response.data.length);
			
			//call the createGoogleMap function using the provider object from page load, and the bene obj in the response
			createGoogleMap($scope.responseData.provider.address, response.data);
			
		}).catch(function(err) {
			console.log('getModelBenes REST Error:' + err.data);
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to retrieve Beneficiaries for this model due to ' + err.data, 'danger');
		});
		
		//log user activity
		$scope.trackUserActivity('MAPS', null);
	}

	//get the part d claims CSV file and ready it for export
	$scope.exportAllPartDClaimsBtnClick  = function() {
		
		// create a scope level unique identifier
		var allClaimsUniqueId = crypto.randomUUID();
		
		//broadcast this event to the broadcastSlaMetrics listener
		$rootScope.$broadcast('broadcastSlaMetrics', {message:"All Claims File - " +"Part D Claims At Risk File - Start: " + allClaimsUniqueId, userId: ""});
		
		console.log('Inside exportAllPartDClaimsBtnClick function.');
		
		// show growl message to user
//		showGrowl('<i class=\'fa fa-info-circle\' aria-hidden=\'true\'></i> Export Started. Please be patient, this may take a moment.', 'info');
		
		//show claims tab overlay
		$("#claimLinesTab").LoadingOverlay("show");
		
		//construct the filename for the exported file
		var partDatRiskFilename = $scope.providerPaneObj.providerName + "_" + moment(new Date()).format("YYYY-MM-DD") + "_claimsExport.csv";
		
		//encode the filename
		var encodeFilename = window.btoa(partDatRiskFilename);
		$scope.openClaimsExport('LoadClaimsDocumentServlet?asrId=' + $scope.asrDetailsDbIdParam + '&userId=' + $scope.scopeUserId + '&searchType=partd'
			+ '&fileName=' + encodeFilename,
			"All Claims File - " +"Part D Claims At Risk File - End: " + allClaimsUniqueId,);
		//show claims tab overlay
		$("#claimLinesTab").LoadingOverlay("hide");
		
		//broadcast this event to the broadcastSlaMetrics listener
		//$rootScope.$broadcast('broadcastSlaMetrics', {message:"All Claims File - End: " + $scope.allClaimsUniqueId, userId: ""});
	}

	//get the all claims CSV file and ready it for export
	$scope.exportMdcdCARBtnClick  = function() {
		console.log('Inside exportMdcdCARBtnClick function.');
		
		// show growl message to user
//		showGrowl('<i class=\'fa fa-info-circle\' aria-hidden=\'true\'></i> Export Started. Please be patient, this may take a moment.', 'info');
		
		// create a scope level unique identifier
		var allClaimsUniqueId = crypto.randomUUID();
		
		//broadcast this event to the broadcastSlaMetrics listener
		$rootScope.$broadcast('broadcastSlaMetrics', {message:"All Claims File - " +"MDCD Claims At Risk - Start: " + allClaimsUniqueId, userId: ""});
		
		//construct the filename for the exported file
		var claimsAtRiskFilename = $scope.providerPaneObj.providerName + "_" + moment(new Date()).format("YYYY-MM-DD") + "_claimsExport.csv";
		
		//encode the filename
		var encodeFilename = window.btoa(claimsAtRiskFilename);
				
		//show claims tab overlay
		$("#claimLinesTab").LoadingOverlay("show");
			$scope.openClaimsExport('LoadClaimsDocumentServlet?asrId=' + $scope.asrDetailsDbIdParam + '&userId=' + $scope.scopeUserId + '&searchType=claimsAtRisk&programType=medicaid' 
			+ '&fileName=' + encodeFilename,
			"All Claims File - " +"MDCD Claims At Risk  - End: " + allClaimsUniqueId);
		//show claims tab overlay
		$("#claimLinesTab").LoadingOverlay("hide");
		
		//broadcast this event to the broadcastSlaMetrics listener
		
	}
//get the all claims CSV file and ready it for export
	$scope.exportAllClaimsBtnClick  = function() {
		console.log('Inside exportAllClaimsBtnClick function.');
		
		// show growl message to user
//		showGrowl('<i class=\'fa fa-info-circle\' aria-hidden=\'true\'></i> Export Started. Please be patient, this may take a moment.', 'info');
		
		// create a scope level unique identifier
		var allClaimsUniqueId = crypto.randomUUID();;
		
		//broadcast this event to the broadcastSlaMetrics listener
		$rootScope.$broadcast('broadcastSlaMetrics', {message:"All Claims File - " +"Claims At Risk - Start: " + allClaimsUniqueId, userId: ""});
		
		//construct the filename for the exported file
		var claimsAtRiskFilename = $scope.providerPaneObj.providerName + "_" + moment(new Date()).format("YYYY-MM-DD") + "_claimsExport.csv";
		
		//encode the filename
		var encodeFilename = window.btoa(claimsAtRiskFilename);
				
		//show claims tab overlay
		$("#claimLinesTab").LoadingOverlay("show");
		$scope.openClaimsExport('LoadClaimsDocumentServlet?asrId=' + $scope.asrDetailsDbIdParam + '&userId=' + $scope.scopeUserId + '&searchType=claimsAtRisk' 
			+ '&fileName=' + encodeFilename,
			"All Claims File - " +"Claims At Risk - End: " + allClaimsUniqueId);
		
		//show claims tab overlay
		$("#claimLinesTab").LoadingOverlay("hide");
		
		//broadcast this event to the broadcastSlaMetrics listener
		//$rootScope.$broadcast('broadcastSlaMetrics', {message:"Claims At Risk  - End: " + $scope.allClaimsUniqueId, userId: ""});
	}

	//get the all p1 ASR cost CSV file and ready it for export
	$scope.exportp1ASRCost  = function() {
		console.log('Inside exportp1ASRCost function.');
		var slaLabel = "p1cost"
		// create a scope level unique identifier
		var claimsId = crypto.randomUUID();
		
		//broadcast this event to the broadcastSlaMetrics listener
		$rootScope.$broadcast('broadcastSlaMetrics', {message:"Phase 1 ASR Cost - " + slaLabel+"Claims Search - Start: " + claimsId, userId: ""});
		
		//construct the filename for the exported file
		var phase1ASRCostFilename = $scope.providerPaneObj.providerName + "_" + moment(new Date()).format("YYYY-MM-DD") + "_claimsExport.csv";
		
		//encode the filename
		var encodeFilename = window.btoa(phase1ASRCostFilename);
				
		//show claims tab overlay
		$("#claimLinesTab").LoadingOverlay("show");
		$scope.openClaimsExport('LoadClaimsDocumentServlet?asrId=' + $scope.asrDetailsDbIdParam + '&userId=' + $scope.scopeUserId + '&searchType=p1cost'
			+ '&fileName=' + encodeFilename ,
			 "Phase 1 ASR Cost - " + "Claims At Risk - End: " + claimsId);
		//show claims tab overlay
		$("#claimLinesTab").LoadingOverlay("hide");
		
		//broadcast this event to the broadcastSlaMetrics listener
		//$rootScope.$broadcast('broadcastSlaMetrics', {message:"Claims At Risk  - End: " + $scope.allClaimsUniqueId, userId: ""});
	}

	$scope.exportp1Claims  = function() {
		console.log('Inside exportp1ASRCost function.');
		
		// create a scope level unique identifier
		var slaLabel = "p1"
		var claimsId = crypto.randomUUID();
		
		//broadcast this event to the broadcastSlaMetrics listener
		$rootScope.$broadcast('broadcastSlaMetrics', {message:"Phase 1 Claims - " + slaLabel+"Claims Search - Start: " + claimsId, userId: ""});
		
		//construct the filename for the exported file
		var phase1ClaimsFileName = $scope.providerPaneObj.providerName + "_" + moment(new Date()).format("YYYY-MM-DD") + "_claimsExport.csv";
		
		//encode the filename
		var encodeFilename = window.btoa(phase1ClaimsFileName);
				
		//show claims tab overlay
		$("#claimLinesTab").LoadingOverlay("show");

		$scope.openClaimsExport('LoadClaimsDocumentServlet?asrId=' + $scope.asrDetailsDbIdParam + '&userId=' + $scope.scopeUserId + '&searchType=latestP1'
			+ '&fileName=' + encodeFilename,
			 "Phase 1 Claims - " + "Claims At Risk - End: " + claimsId);
		//show claims tab overlay
		$("#claimLinesTab").LoadingOverlay("hide");
		
		//broadcast this event to the broadcastSlaMetrics listener
		//$rootScope.$broadcast('broadcastSlaMetrics', {message:"Claims At Risk  - End: " + $scope.allClaimsUniqueId, userId: ""});
	}

	// show Provider Pane Non-Alerted ASRs
	$scope.showNonAlertedASR = function() {
		console.log('Inside showNonAlertedASR function.');
		
		//show full page overlay
		$.LoadingOverlay("show");
		
		//call the summary Modal service		
		detailsFactory.getNonAlertedData($scope.restURL, $scope.asrDetailsDbIdParam, $scope.scopeUserId).success(function(data) {
			//show modal window
			$("#prvdrNonAlertModal").modal("show");	
			
			//initiate the modal table
			$("#prvdrNonAlertTable").bootstrapTable({});
			
			//get the napParents Object from the Response				
			$('#prvdrNonAlertTable').bootstrapTable('load', data.responseData.napParents);
			
			//hide modal overlay
    		$.LoadingOverlay("hide");
    		
		}).error(function(data, status) {
			console.log('showNonAlertedASR REST Error:' + status);
			
			//hide modal overlay
    		$.LoadingOverlay("hide");
			
			//show message to user that the summary modal service failed
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load  Non-Alerted ASRs data due to ' + status, 'danger');
		});
	}

	// show the related ASRs pop-up
	$scope.showPrvdrRelatedAsrs = function() {
		console.log('Inside showPrvdrRelatedAsrs function.');
		
		//show full page overlay
		$.LoadingOverlay("show");
		
		//call the summary Modal service		
		detailsFactory.getRelatedAsrsData($scope.restURL, $scope.asrDetailsDbIdParam, $scope.scopeUserId).success(function(data) {
			//display the modal window
			$("#relatedAsrsModal").modal("show");
			
			//initiate the modal table
			$("#relatedAsrsTable").bootstrapTable({});
			
			//get the relatedAsrs Object from the Response				
			$('#relatedAsrsTable').bootstrapTable('load', data.responseData.relatedAsrs);
			
			//hide modal overlay
    		$.LoadingOverlay("hide");			
			
		}).error(function(data, status) {
			console.log('showPrvdrRelatedAsrs REST Error:' + status);
			
			//hide modal overlay
    		$.LoadingOverlay("hide");
			
			//show message to user that the summary modal service failed
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load Related ASRs data due to ' + status, 'danger');
		});
	}

	// show the Total Payment by Jurisdiction pop-up
	$scope.viewTotalPaymentModal = function() {
		console.log('Inside viewTotalPaymentModal function.');
		
		//show full page overlay
		$.LoadingOverlay("show");
		
		//call the summary Modal service		
		detailsFactory.getTotalPaymentModalData($scope.restURL, $scope.asrDetailsDbIdParam, $scope.scopeUserId).success(function(data) {
			
			//display the modal window
			$("#totalPmntByZoneModal").modal("show");
			
			//initiate the modal table
			$("#totalPmntTable").bootstrapTable({});
			
			//get the totalCostZones Object from the Response				
			$('#totalPmntTable').bootstrapTable('load', data.responseData.totalPymtZones);
			
			//hide modal overlay
    			$.LoadingOverlay("hide");
			
		}).error(function(data, status) {
			console.log('getTotalPaymentModalData REST Error:' + status);
			
			//hide modal overlay
    			$.LoadingOverlay("hide");
			
			//show message to user that the summary modal service failed
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load Total Payment data due to ' + status, 'danger');
		});
	}

	//populate the Billing NPI(s) table when button clicked by user
	$scope.viewBillingNPIClick = function() {
		console.log('Inside viewBillingNPIClick function.');	
		
		//show full page overlay
		$.LoadingOverlay("show");
		
		//call the factory method to call the claims service
		detailsFactory.getASRDetailsData($scope.restURL, $scope.asrDetailsParam, "BILLSUMM", $scope.scopeUserId, $scope.activeASRTab ).success(function(data) {
		// detailsFactory.getTabTotalZnCostData($scope.restURL, $scope.asrDetailsDbIdParam, $scope.scopeUserId).success(function(data) { 
			//show modal window
			$("#medicareViewBillingNPIModal").modal("show");
			//initialize the modal table
			$('#medicareViewBillingNPIModalTable').bootstrapTable({});
			//get the totalCostZones Object from the Response				
			$('#medicareViewBillingNPIModalTable').bootstrapTable('load', data.responseData.billSummary);
			
			//hide full overlay
			$.LoadingOverlay("hide");
			
		}).error(function(data, status) {
			console.log('viewBillingNPIClick REST Error:' + status);	
			//hide full overlay
			$.LoadingOverlay("hide");
			
			//show growl message
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Billing NPI data not available due to ' + status, 'danger');
		});
	
	}

	//populate the Total Cost By Zone table when button clicked by user
	$scope.totalCostByZoneBtnClick = function() {
		console.log('Inside totalCostByZoneBtnClick function.');	
		
		//show full page overlay
		$.LoadingOverlay("show");
		
		//call the factory method to call the claims service
		detailsFactory.getTabTotalZnCostData($scope.restURL, $scope.asrDetailsDbIdParam, $scope.scopeUserId).success(function(data) { 
			//show modal window
			$("#totalCostByZoneModal").modal("show");
			//initialize the modal table
			$('#totalCostTable').bootstrapTable({});
			//get the totalCostZones Object from the Response				
			$('#totalCostTable').bootstrapTable('load', data.responseData.totalCostZones);
			
			//hide full overlay
			$.LoadingOverlay("hide");
			
		}).error(function(data, status) {
			console.log('totalCostByZoneBtnClick REST Error:' + status);	
			//hide full overlay
			$.LoadingOverlay("hide");
			
			//show growl message
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Total Cost By Zone data not available due to ' + status, 'danger');
		});
	
	}
	//populate the Total Cost By Zone table when button clicked by user
	$scope.p1TotalCostByZoneBtnClick = function() {
		console.log('Inside p1TotalCostByZoneBtnClick function.');	
		
		//show full page overlay
		$.LoadingOverlay("show");
		
		//call the factory method to call the claims service
		detailsFactory.getTabp1TotalZnCostData($scope.restURL, $scope.asrDetailsDbIdParam, $scope.scopeUserId).success(function(data) { 

			$("#p1AsrCostPopup").modal("show");
			$("#p1AsrCostPopuplTable").bootstrapTable({});
			$("#p1AsrCostPopuplTable").bootstrapTable('load',  data.responseData.p1TotalCostZones);
			//hide full overlay
			$.LoadingOverlay("hide");
			
		}).error(function(data, status) {
			console.log('p1TotalCostByZoneBtnClick REST Error:' + status);	
			//hide full overlay
			$.LoadingOverlay("hide");
			
			//show growl message
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i>Phase 1 Total Cost By Zone data not available due to ' + status, 'danger');
		});
	
	}
	//openClaimsExport
	$scope.openClaimsExport = function(pURL, pMetricsToken) {
		token =  localStorage.getItem("okta-token-storage");
		accessToken = token != null ? JSON.parse(token).accessToken.accessToken : "";
		var claimswin= window.open(pURL+'&token='+accessToken);	
		if (pMetricsToken != null){
			claimswin.addEventListener('beforeunload', function (e) {
				$rootScope.$broadcast('broadcastSlaMetrics', {message:pMetricsToken, userId: ""});
			});			
		}
	}
		
	//view the claims for a master alerts when the user clicks on the link
	$scope.viewMasterAlertClaims = function(pModelId, pNpi, pInsertDt, pType) {
		return $scope.viewMasterAlertClaims (pModelId, pNpi, pInsertDt, pType, null);
	}
	//view the claims for a master alerts when the user clicks on the link
	$scope.viewMasterAlertClaims = function(pModelId, pNpi, pInsertDt, pType, pState) {
		console.log('Inside viewMasterAlertClaims function. ModelId = ' + pModelId + ', pType = ' + pType + ', pInsertDt = ' + pInsertDt);
			
		// create a scope level unique identifier
		var masterClaimsUniqueId = crypto.randomUUID();
		
		//broadcast this event to the broadcastSlaMetrics listener
		$rootScope.$broadcast('broadcastSlaMetrics', {message:"Query Master Alert Claims - " +(pState == null ? '':'Medicaid')+ " Alert Claims - Start: " + masterClaimsUniqueId, userId: ""});
		
		//set a global model number param for use with part d claim lines
		$scope.modelNumber = pModelId;
		//set a global npi param for use with part d claim lines
		$scope.modelNpiNumber = pNpi;	
		
		//encode the filename
		var encodeFilename = window.btoa('alert-claims-export.csv');
		
		if (pType == 'Y') {
			$scope.openClaimsExport('LoadClaimsDocumentServlet?asrId=' + $scope.asrDetailsDbIdParam + '&userId=' + $scope.scopeUserId + '&searchType=alerty' 
				+ '&fileName=' + encodeFilename+'&npi=' + $scope.asrDetailsParam + '&modelId=' + pModelId+ '&state=' + pState +'&programType='+(pState == null ? 'medicare':'medicaid'),
				"Query Master Alert Claims - " +(pState == null ? '':'Medicaid')+ " Alert Claims - End: " + masterClaimsUniqueId);
					
		
		} else {
			$scope.openClaimsExport('LoadClaimsDocumentServlet?asrId=' + $scope.asrDetailsDbIdParam + '&userId=' + $scope.scopeUserId + '&searchType=alertn' 
				+ '&fileName=' + encodeFilename + '&npi=' + $scope.asrDetailsParam + '&modelId=' + pModelId+ '&state=' + pState +'&programType='+(pState == null ? 'medicare':'medicaid'),
				"Query Master Alert Claims - " +(pState == null ? '':'Medicaid')+"Alert Claims - End: " + masterClaimsUniqueId);
			
		}
		
		//broadcast this event to the broadcastSlaMetrics listener
		//$rootScope.$broadcast('broadcastSlaMetrics', {message:"Query Master Alert Claims - End: " + $scope.masterClaimsUniqueId, userId: ""});
	}
	// this method fetches the drill claims when a user clicks the drill link
	$scope.showDrillClaims = function(pAttrSqncNum, pNpi, pType) {
		$scope.showDrillClaims(pAttrSqncNum, pNpi, pType, null);
	}
	// this method fetches the drill claims when a user clicks the drill link
	$scope.showDrillClaims = function(pAttrSqncNum, pNpi, pType, pState) {
		var loadPageUniqueId = crypto.randomUUID();

		//broadcast this event to the broadcastSlaMetrics listener
		$rootScope.$broadcast('broadcastSlaMetrics', {message:"Query Master Alert Claims - "+(pState == null ? '':'Medicaid')+ " Attribute Claims File - Start: " + loadPageUniqueId, userId: ""});
		
		console.log('Inside showDrillClaims. AttrSqncNum = ' 
				+ pAttrSqncNum + ', pType= ' + $scope.partdDrillReportFlag + ', ModelId= ' + $scope.alertModelId);
		
		//encode the filename
		var encodeFilename = window.btoa('alert-claims-export.csv');
		
		if ($scope.partdDrillReportFlag == 'Y') {
			$scope.openClaimsExport('LoadClaimsDocumentServlet?asrId=' + $scope.asrDetailsDbIdParam + '&userId=' + $scope.scopeUserId + '&searchType=drilly' 
				+ '&fileName=' + encodeFilename + '&npi=' + pNpi + '&modelId=' + $scope.alertModelId + '&state=' + pState +'&attrNum=' + pAttrSqncNum +'&programType='+(pState == null ? 'medicare':'medicaid'),
				"Query Master Alert Claims - "+(pState == null ? '':'Medicaid')+ " Attribute Claims File - End: " + loadPageUniqueId);
		
			
		} else {
			$scope.openClaimsExport('LoadClaimsDocumentServlet?asrId=' + $scope.asrDetailsDbIdParam + '&userId=' + $scope.scopeUserId + '&searchType=drilln' 
			+ '&fileName=' + encodeFilename + '&npi=' + pNpi + '&modelId=' + $scope.alertModelId + '&state=' + pState +'&attrNum=' + pAttrSqncNum +'&programType='+(pState == null ? 'medicare':'medicaid'),	
			"Query Master Alert Claims - "+(pState == null ? '':'Medicaid')+  " Attribute Claims File - End: " + loadPageUniqueId);
		}
	}

	//show the Report Card Modal window
	$scope.showReportCard = function(pModelId, pNPI, pModelTypeCd, pInsertDt, mdcdState) {
		$scope.mdcdState = mdcdState;
		console.log('Inside showReportCard function. pModelId = ' + pModelId + ', pNPI = ' + pNPI + ', pModelTypeCd = ' + pModelTypeCd + ', pInsertDt = ' + pInsertDt);
		console.log("active tab -", $scope.activeASRTab);
		
		// create a scope level unique identifier
		var reportCardUniqueId =  crypto.randomUUID();
		
		//broadcast this event to the broadcastSlaMetrics listener
		$rootScope.$broadcast('broadcastSlaMetrics', {message:"Report Card Load - Start: " + reportCardUniqueId, userId: ""});
		
		
		//destroy custom table tabs
		$scope.customTab1Select = 'false';
		$scope.customTab2Select = 'false';
		$scope.customTab3Select = 'false';
		$scope.customTab4Select = 'false';
		$scope.customTab5Select = 'false';
		$scope.customTab6Select = 'false';
				
		//DEFAULT VALUE FOR TESTING - DELETE WHEN FINISHED
		//pModelTypeCd='4';
		
		//hide all of the tables
		$scope.reportCardTypeSelect = 'hide';
		
		//show modal window
		$("#reportCardsModal").modal("show");
		//show overlay on modal window only
		$("#rptCardModalBody").LoadingOverlay("show");
		
		//destroy all tables
		$("#ruleBasedTable").bootstrapTable('destroy');
		//destroy all tables
		
		// Initialize medicaid tables.
		$("#ruleBasedTableMDCD").bootstrapTable('destroy');
		$("#ruleBasedTableMDCD").bootstrapTable( {});
		
		$("#snaTableMDCD").bootstrapTable('destroy');
		$("#snaTableMDCD").bootstrapTable( {});
		
		
		$("#predictiveTableMDCD").bootstrapTable('destroy');
		$("#predictiveTableMDCD").bootstrapTable( {});

		
		$("#predictiveTable").bootstrapTable('destroy');
		$("#multipleAnomalyTable").bootstrapTable('destroy');
		$("#unknownTable").bootstrapTable('destroy');		
		$("#enhancedRCTable").bootstrapTable({});
		
		
		//initiate the multi anomaly table
		$("#multipleAnomalyTable").bootstrapTable({});
		//initiate the multi anomaly table
		$("#unknownTable").bootstrapTable({});
		
		//if modelId and NPI are not null, then call the web service to get the values from DB
		if (pNPI && pModelId) {
			//call the factory method to call the report card service
			detailsFactory.getReportCardData($scope.restURL, pNPI, pModelId, $scope.scopeUserId, pInsertDt, mdcdState, $scope.activeASRTab).then(function(response) {
//				console.log('getReportCardData REST service call successful.');
				
				//set two global variables to be used by the drill part D claims tab
				$scope.rptCardModelId = pModelId;
				$scope.rptCardNpi = pNPI;
				
				//process the custom table tabs
				$scope.customTablesArray = response.data.customTables;
				$scope.riskScoreRC = response.data.riskScoreRC;
				$scope.customVizTablesArray = response.data.customVizTables;
				
				// set flag to denote partd or non-partd drill report
				$scope.partdDrillReportFlag = response.data.partDClaimInd;
				console.log('partdDrillReportFlag = ' + $scope.partdDrillReportFlag);
				
				
				// Set Enhanced Risk Score contributions header values.
				$scope.eRCNpi = "";
				$scope.eRCPrvdrName =  "";
				$scope.eRCModelName =  "";
				$scope.eRCModelLink =  "";
				$scope.eRCZone =  "";
				$scope.eRCMacZone =  "";
				$scope.eRCAsOfDt =  "";
				$scope.eRCLookback =  "";				
				$scope.eRCModelLinkHide = false;
				
				
				console.log(">>>>>>>>", response);
					
				//perform switch on model reference vals from DB.  Note: Report Card Type 4 = Social Network.
				if (pModelTypeCd == '5') {
					console.log('Display the Rule Based Report Card...');
										
					//set the header information
					if (response.data.ruleBased.length > 0) {
						$scope.ruleBasedNpi = response.data.ruleBased[0].npi;
						$scope.ruleBasedPrvdrName = response.data.ruleBased[0].subjPrvdrName;
						$scope.ruleBasedModelName = response.data.ruleBased[0].modelBusnsId;
						$scope.ruleBasedModelLink = response.data.docUrl;
						$scope.ruleBasedZone = $scope.providerPaneObj.jurisdiction;
						$scope.ruleBasedMacZone = $scope.providerPaneObj.mac;
						$scope.ruleBasedAsOfDt = response.data.ruleBased[0].asOfDt;
						$scope.ruleBasedLookback = response.data.lookback;
						
						$scope.stateMDCD = response.data.ruleBased[0].state;
						$scope.riskScoreMDCD = "";//response.data.ruleBased[0].state;
						
						
						//Enhanced Risk Score Contributions
						$scope.eRCNpi = response.data.ruleBased[0].npi;
						$scope.eRCPrvdrName = response.data.ruleBased[0].subjPrvdrName;
						$scope.eRCModelName = response.data.ruleBased[0].modelBusnsId;
						$scope.eRCModelLink = response.data.docUrl;
						$scope.eRCZone = $scope.providerPaneObj.jurisdiction;
						$scope.eRCMacZone = $scope.providerPaneObj.mac;
						$scope.eRCAsOfDt = response.data.ruleBased[0].asOfDt;
						$scope.eRCLookback = response.data.lookback;
						
						// hide/show the model name as a link to the guidance doc
						if (response.data.docUrl != void(0)&& response.data.docUrl != null) {
							$scope.ruleBasedModelLinkHide = false;
						} else {
							$scope.ruleBasedModelLinkHide = true;
							$scope.eRCModelLinkHide = true;
						}
						
						
					} else {
						$scope.ruleBasedNpi = '';
						$scope.ruleBasedPrvdrName = '';
						$scope.ruleBasedModelName = '';
						$scope.ruleBasedModelLink = '';
						$scope.ruleBasedZone = '';
						$scope.ruleBasedAsOfDt = '';
						$scope.ruleBasedLookback = "";
						$scope.ruleBasedMacZone = "";
					}
					
					//set the rules based table to show
					$scope.reportCardTypeSelect = 'ruleBased';
				//	$scope.reportCardHeaderSelect = 'ruleBased';
					
					//initiate the rules based table
					var exportFilename = 'ReportsExport_' + $scope.ruleBasedAsOfDt + "_" + $scope.providerPaneObj.providerName.replace(/ /g,"_");
					//$("#ruleBasedTable").bootstrapTable({});					
					
					$("#ruleBasedTable").bootstrapTable({exportOptions: {
				        fileName: exportFilename
				    }});
					
					
					
					
					// check the hasMacInd flag to see if the mac rank and mac med columns should be displayed
					console.log('hasMacInd = ' + response.data.hasMac);
					if (response.data.hasMac == null || response.data.hasMac == 'N') {
						// hide the mac rank and mac med columns
						$('#ruleBasedTable').bootstrapTable('hideColumn', 'macPctl');
						//hide the entries in the show column button drop down menu
						$("#ruleBasedTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="macPctl"]').parent().hide();
						
						$('#ruleBasedTable').bootstrapTable('hideColumn', 'macMed');
						//hide the entries in the show column button drop down menu
						$("#ruleBasedTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="macMed"]').parent().hide();
					}
					
					// Hide the columns if PartD
					/*• Inv. Median
					• MAC Median
					• Provider Inv. Rank
					• Provider MAC rank*/
					console.log('Hide the columns if PartD = ' + $scope.partdDrillReportFlag);
					if ($scope.partdDrillReportFlag == 'Y'){
						// hide the mac rank and zoneMed columns
						$('#ruleBasedTable').bootstrapTable('hideColumn', 'zoneMed');
						//hide the entries in the show column button drop down menu
						$("#ruleBasedTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="zoneMed"]').parent().hide();
						
						// hide the mac rank and macMed columns
						$('#ruleBasedTable').bootstrapTable('hideColumn', 'macMed');
						//hide the entries in the show column button drop down menu
						$("#ruleBasedTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="macMed"]').parent().hide();
						
						// hide the mac rank and provderZoneRank columns
						$('#ruleBasedTable').bootstrapTable('hideColumn', 'provderZoneRank');
						//hide the entries in the show column button drop down menu
						$("#ruleBasedTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="provderZoneRank"]').parent().hide();
						
						// hide the mac rank and macPctl columns
						$('#ruleBasedTable').bootstrapTable('hideColumn', 'macPctl');
						//hide the entries in the show column button drop down menu
						$("#ruleBasedTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="macPctl"]').parent().hide();
						
					}
					
					
					//populate the rules based table					
					$('#ruleBasedTable').bootstrapTable('load', response.data.ruleBased);
					$("#ruleBasedTable").bootstrapTable('resetView');
					$("#ruleBasedTable").parent().attr('style', 'margin-left:1px !important;');
					
					//populate the rules based table					
					$('#ruleBasedTableMDCD').bootstrapTable('load', response.data.ruleBased);
					$("#ruleBasedTableMDCD").bootstrapTable('resetView');
					$("#ruleBasedTableMDCD").parent().attr('style', 'margin-left:1px !important;');
					
					
					
				} else if (pModelTypeCd == '3') {
					console.log('Display the Predictive Report Card.');
					
				    if(response.data.predict.length > 0) {
				    	$scope.predictNpi = response.data.predict[0].npi;
				    	$scope.predictPrvdrName = response.data.predict[0].subjPrvdrName;
					$scope.predictModelName = response.data.predict[0].modelBusnsId;
					$scope.predictModelLink = response.data.docUrl;
					$scope.predictModelScore = response.data.predict[0].modelCompScore;
					$scope.predictZone = $scope.providerPaneObj.jurisdiction;
					$scope.predictMacZone = $scope.providerPaneObj.mac;
					$scope.predictModelScoreThresh = response.data.predict[0].modelScoreThreshold;
					$scope.predictAsOfDt = response.data.predict[0].asOfDt;
					$scope.predictLookback = response.data.lookback;
					
					$scope.stateMDCD = response.data.predict[0].state;
					$scope.riskScoreMDCD = "";//response.data.ruleBased[0].state;
					
					
					//Enhanced Risk Score Contributions
					$scope.eRCNpi = response.data.predict[0].npi;
					$scope.eRCPrvdrName = response.data.predict[0].subjPrvdrName;
					$scope.eRCModelName = response.data.predict[0].modelBusnsId;
					$scope.eRCModelLink = response.data.docUrl;
					$scope.eRCZone = $scope.providerPaneObj.jurisdiction;
					$scope.eRCMacZone = $scope.providerPaneObj.mac;
					$scope.eRCAsOfDt = response.data.predict[0].asOfDt;
					$scope.eRCLookback = response.data.lookback;
					
					// hide/show the model name as a link to the guidance doc
					if (response.data.docUrl != void(0)&& response.data.docUrl != null) {
						$scope.predictModelLinkHide = false;
					} else {
						$scope.predictModelLinkHide = true;
						$scope.eRCModelLinkHide = true;
					}
						
				    } else {
				    	$scope.predictNpi = '';
					$scope.predictModelScore = '';
					$scope.predictZone = '';
					$scope.predictModelScoreThresh = '';
					$scope.predictAsOfDt = '';
					$scope.predictMacZone = '';
					$scope.predictLookback = '';
					$scope.predictPrvdrName = '';
					$scope.predictModelName = '';
					$scope.predictModelLink = '';
				    }
					
					//set the predictive table to show
					$scope.reportCardTypeSelect = 'predictive';
										
					var exportFilename = 'ReportsExport_' + $scope.predictAsOfDt + "_" + $scope.providerPaneObj.providerName.replace(/ /g,"_");
					
					// initialize the predictive report card table
					$("#predictiveTable").bootstrapTable({});
					
					$("#predictiveTable").bootstrapTable({exportOptions: {
				        fileName: exportFilename
				    }});
					
					//display the correct Contribution to Alert Priority column name based on FPS version
					console.log('fpsVersionInd = ' + response.data.fpsVersionInd);
					if (response.data.fpsVersionInd == "2") {
						//show the column heading of Contribution to Alert Score
//						console.log('show Alert Score');						
						$("#predictiveTable").find('[data-field=\'contribToAlertPriority\']').find(".th-inner").text("Contribution to Alert Score");						
					} else {
						//show the column heading of Contribution to Alert Priority
//						console.log('show Alert Priority');						
						$("#predictiveTable").find('[data-field=\'contribToAlertPriority\']').find(".th-inner").text("Contribution to Alert Priority");
					}
					
					// check the hasMacInd flag to see if the mac rank and mac med columns should be displayed
					console.log('hasMacInd = ' + response.data.hasMac);
					if (response.data.hasMac == null || response.data.hasMac == 'N') {
						// hide the mac rank and mac med columns
						$('#predictiveTable').bootstrapTable('hideColumn', 'macPctl');
						//hide the entries in the show column button drop down menu
						$("#predictiveTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="macPctl"]').parent().hide();
						
						$('#predictiveTable').bootstrapTable('hideColumn', 'macMed');
						//hide the entries in the show column button drop down menu
						$("#predictiveTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="macMed"]').parent().hide();
					}
					
					// Hide the columns if PartD
					/*• Inv. Median
					• MAC Median
					• Provider Inv. Rank
					• Provider MAC rank*/
					console.log('Hide the columns if PartD = Y ->' + $scope.partdDrillReportFlag);
					if ($scope.partdDrillReportFlag == 'Y'){
						// hide the mac rank and zoneMed columns
						$('#predictiveTable').bootstrapTable('hideColumn', 'zoneMed');
						//hide the entries in the show column button drop down menu
						$("#predictiveTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="zoneMed"]').parent().hide();
						
						// hide the mac rank and macMed columns
						$('#predictiveTable').bootstrapTable('hideColumn', 'macMed');
						//hide the entries in the show column button drop down menu
						$("#predictiveTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="macMed"]').parent().hide();
						
						// hide the mac rank and provderZoneRank columns
						$('#predictiveTable').bootstrapTable('hideColumn', 'provderZoneRank');
						//hide the entries in the show column button drop down menu
						$("#predictiveTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="provderZoneRank"]').parent().hide();
						
						// hide the mac rank and macPctl columns
						$('#predictiveTable').bootstrapTable('hideColumn', 'macPctl');
						//hide the entries in the show column button drop down menu
						$("#predictiveTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="macPctl"]').parent().hide();
						
					}
					
					
					//populate the rules based table
					$('#predictiveTable').bootstrapTable('load', response.data.predict);
	//				$("#predictiveTable").bootstrapTable('resetView');
					$("#predictiveTable").parent().attr('style', 'margin-left:1px !important;');
					
					
					$('#predictiveTableMDCD').bootstrapTable('load', response.data.predict);
					//				$("#predictiveTable").bootstrapTable('resetView');
					$("#predictiveTableMDCD").parent().attr('style', 'margin-left:1px !important;');
					
				} else if (pModelTypeCd == '6' || pModelTypeCd == '7' || pModelTypeCd == '8') {
					console.log('Display the Multi Anomaly Report Card.');
					
					if (response.data.aaMulti.length > 0) {
						//set the header information
						$scope.ruleBasedNpi = response.data.aaMulti[0].npi;
						$scope.ruleBasedPrvdrName = response.data.aaMulti[0].subjPrvdrName;
						$scope.ruleBasedModelName = response.data.aaMulti[0].modelBusnsId;
						$scope.ruleBasedModelLink = response.data.docUrl;
						$scope.ruleBasedZone = $scope.providerPaneObj.jurisdiction;
						$scope.ruleBasedMacZone = $scope.providerPaneObj.mac;
						$scope.ruleBasedAsOfDt = response.data.aaMulti[0].asOfDt;
						$scope.ruleBasedLookback = response.data.lookback;
						
						$scope.stateMDCD = response.data.aaMulti[0].state;
						$scope.riskScoreMDCD = "";//response.data.ruleBased[0].state;
						
						
						//Enhanced Risk Score Contributions
						$scope.eRCNpi = response.data.aaMulti[0].npi;
						$scope.eRCPrvdrName = response.data.aaMulti[0].subjPrvdrName;
						$scope.eRCModelName = response.data.aaMulti[0].modelBusnsId;
						$scope.eRCModelLink = response.data.docUrl;
						$scope.eRCZone = $scope.providerPaneObj.jurisdiction;
						$scope.eRCMacZone = $scope.providerPaneObj.mac;
						$scope.eRCAsOfDt = response.data.aaMulti[0].asOfDt;
						$scope.eRCLookback = response.data.lookback;
												
						// hide/show the model name as a link to the guidance doc
						if (response.data.docUrl != void(0)&& response.data.docUrl != null) {
							$scope.ruleBasedModelLinkHide = false;
						} else {
							$scope.ruleBasedModelLinkHide = true;
							$scope.eRCModelLinkHide = true;
						}
					} else {
						//set the header information
						$scope.ruleBasedNpi = '';
						$scope.ruleBasedZone = '';
						$scope.ruleBasedAsOfDt = '';
						$scope.ruleBasedMacZone = '';
						$scope.ruleBasedLookback = '';
						$scope.ruleBasedPrvdrName = '';
						$scope.ruleBasedModelName = '';
						$scope.ruleBasedModelLink = '';
					}
					
					//set the multi anomaly table to show
					$scope.reportCardTypeSelect = 'ruleBased';
			//		$scope.reportCardHeaderSelect = 'multipleAnomaly';
					
					//initiate the rules based table
					//$("#ruleBasedTable").bootstrapTable({});					
					var exportFilename = 'ReportsExport_' + $scope.ruleBasedAsOfDt + "_" + $scope.providerPaneObj.providerName.replace(/ /g,"_");
					//$("#ruleBasedTable").bootstrapTable({});
					$("#ruleBasedTable").bootstrapTable({exportOptions: {
				        fileName: exportFilename
				    }});
					
					// check the hasMacInd flag to see if the mac rank and mac med columns should be displayed
					console.log('hasMacInd = ' + response.data.hasMac);
					if (response.data.hasMac == null || response.data.hasMac == 'N') {
						// hide the mac rank and mac med columns
						$('#ruleBasedTable').bootstrapTable('hideColumn', 'macPctl');
						//hide the entries in the show column button drop down menu
						$("#ruleBasedTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="macPctl"]').parent().hide();
						
						$('#ruleBasedTable').bootstrapTable('hideColumn', 'macMed');
						//hide the entries in the show column button drop down menu
						$("#ruleBasedTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="macMed"]').parent().hide();
					}
					
					// Hide the columns if PartD
					/*• Inv. Median
					• MAC Median
					• Provider Inv. Rank
					• Provider MAC rank*/
					console.log('Hide the columns if PartD = ' + $scope.partdDrillReportFlag);
					if ($scope.partdDrillReportFlag == 'Y'){
						// hide the mac rank and zoneMed columns
						$('#ruleBasedTable').bootstrapTable('hideColumn', 'zoneMed');
						//hide the entries in the show column button drop down menu
						$("#ruleBasedTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="zoneMed"]').parent().hide();
						
						// hide the mac rank and macMed columns
						$('#ruleBasedTable').bootstrapTable('hideColumn', 'macMed');
						//hide the entries in the show column button drop down menu
						$("#ruleBasedTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="macMed"]').parent().hide();
						
						// hide the mac rank and provderZoneRank columns
						$('#ruleBasedTable').bootstrapTable('hideColumn', 'provderZoneRank');
						//hide the entries in the show column button drop down menu
						$("#ruleBasedTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="provderZoneRank"]').parent().hide();
						
						// hide the mac rank and macPctl columns
						$('#ruleBasedTable').bootstrapTable('hideColumn', 'macPctl');
						//hide the entries in the show column button drop down menu
						$("#ruleBasedTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="macPctl"]').parent().hide();
						
					}
					
					//populate the rules based table
					$('#ruleBasedTable').bootstrapTable('load', response.data.aaMulti);
	//				$("#ruleBasedTable").bootstrapTable('resetView');
					$("#ruleBasedTable").parent().attr('style', 'margin-left:1px !important;');
					
					//populate the rules based table for MDCD
					$('#ruleBasedTableMDCD').bootstrapTable('load', response.data.aaMulti);
	//				$("#ruleBasedTable").bootstrapTable('resetView');
					$("#ruleBasedTableMDCD").parent().attr('style', 'margin-left:1px !important;');
			
				} else if (pModelTypeCd == '4') {
					console.log('Display a SNA Report Card.');
					
					if(response.data.socNet.length > 0) {
				    	$scope.snaNpi = response.data.socNet[0].npi;
						//$scope.snaModelScore = response.data.socNet[0].modelCompScore;
						$scope.snaZone = $scope.providerPaneObj.jurisdiction;
						$scope.snaMacZone = $scope.providerPaneObj.mac;
						//$scope.snaModelScoreThresh = response.data.socNet[0].modelScoreThreshold;
						$scope.snaAsOfDt = response.data.socNet[0].asOfDt;
						$scope.snaLookback = response.data.lookback;
						$scope.snaPrvdrName = response.data.socNet[0].subjPrvdrName;
						$scope.snaModelName = response.data.socNet[0].modelBusnsId;
						$scope.snaModelLink = response.data.docUrl;
												
						$scope.stateMDCD = response.data.socNet[0].state;
						$scope.riskScoreMDCD = "";//response.data.ruleBased[0].state;
						
						
						// hide/show the model name as a link to the guidance doc
						if (response.data.docUrl != void(0)&& response.data.docUrl != null) {
							$scope.snaModelLinkHide = false;
						} else {
							$scope.snaModelLinkHide = true;
							$scope.eRCModelLinkHide = true;
						}
						
						
						//Enhanced Risk Score Contributions
						$scope.eRCNpi = response.data.socNet[0].npi;
						$scope.eRCPrvdrName = response.data.socNet[0].subjPrvdrName;
						$scope.eRCModelName = response.data.socNet[0].modelBusnsId;
						$scope.eRCModelLink = response.data.docUrl;
						$scope.eRCZone = $scope.providerPaneObj.jurisdiction;
						$scope.eRCMacZone = $scope.providerPaneObj.mac;
						$scope.eRCAsOfDt = response.data.socNet[0].asOfDt;
						$scope.eRCLookback = response.data.lookback;
						
				    } else {
				    	$scope.snaNpi = '';
						//$scope.snaModelScore = '';
						$scope.snaZone = '';
						//$scope.snaModelScoreThresh = '';
						$scope.snaAsOfDt = '';
						$scope.snaMacZone = '';
						$scope.snaLookback = '';
						$scope.snaPrvdrName = '';
						$scope.snaModelName = '';
						$scope.snaModelLink = '';
				    }
										
					//set the sna table to show
					$scope.reportCardTypeSelect = 'sna';
					
					//initiate the sna table
					//$("#snaTable").bootstrapTable({});
					var exportFilename = 'ReportsExport_' + $scope.snaAsOfDt + "_" + $scope.providerPaneObj.providerName.replace(/ /g,"_");
					//$("#ruleBasedTable").bootstrapTable({});
					$("#snaTable").bootstrapTable({exportOptions: {
				        fileName: exportFilename
				    }});
					
					//populate the sna table
					$('#snaTable').bootstrapTable('load', response.data.socNet);
					$("#snaTable").bootstrapTable('resetView');
					$("#snaTable").parent().attr('style', 'margin-left:1px !important;');
					
					//populate the sna table for medicaid
					$('#snaTableMDCD').bootstrapTable('load', response.data.socNet);
					$("#snaTableMDCD").bootstrapTable('resetView');
					$("#snaTableMDCD").parent().attr('style', 'margin-left:1px !important;');
					
//					console.log('pecosRltnshp = ' + response.data.socNet[0].pecosRltnshp);
					
					// hide the last four columns when the value for a column is null
					if (response.data.socNet[0].pecosRltnshp == 'empty') {
//						console.log('Hide PECOS Relationship between Subject and Related Providers column.');
						
						// hide the PECOS Relationship between Subject and Related Providers column							
						$('#snaTable').bootstrapTable('hideColumn', 'pecosRltnshp');
						
						// hide the entry in the columns drop down
						$("#snaTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="pecosRltnshp"]').parent().hide();
						
					} else {
//						console.log('Show PECOS Relationship between Subject and Related Providers column.');
						
						// show the PECOS Relationship between Subject and Related Providers column
						$('#snaTable').bootstrapTable('showColumn', 'pecosRltnshp');
						
						// show the entry in the columns drop down
						$("#snaTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="pecosRltnshp"]').parent().show();
					}
					
					if (response.data.socNet[0].rltdPrvdrNum == 'empty') {
//						console.log('Hide Number of Total Related Providers column.');
						
						// hide the Number of Total Related Providers column							
						$('#snaTable').bootstrapTable('hideColumn', 'rltdPrvdrNum');
						
						// hide the entry in the columns drop down
						$("#snaTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="rltdPrvdrNum"]').parent().hide();
						
					} else {
//						console.log('Show Number of Total Related Providers column.');
						
						// show the Number of Total Related Providers column
						$('#snaTable').bootstrapTable('showColumn', 'rltdPrvdrNum');
						
						// show the entry in the columns drop down
						$("#snaTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="rltdPrvdrNum"]').parent().show();
					}
					
					if (response.data.socNet[0].badRltdPrvdrNum == 'empty') {
//						console.log('Hide Number of Bad Related Providers column.');
						
						// hide the Number of Bad Related Providers column							
						$('#snaTable').bootstrapTable('hideColumn', 'badRltdPrvdrNum');
						
						// hide the entry in the columns drop down
						$("#snaTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="badRltdPrvdrNum"]').parent().hide();
						
					} else {
//						console.log('Show Number of Bad Related Providers column.');
						
						// show the Number of Bad Related Providers column
						$('#snaTable').bootstrapTable('showColumn', 'badRltdPrvdrNum');
						
						// show the entry in the columns drop down
						$("#snaTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="badRltdPrvdrNum"]').parent().show();
					}
					
					if (response.data.socNet[0].badRltdPrvdrPct == 'empty') {
//						console.log('Hide Percentage of Bad Related Providers column.');
						
						// hide the Percentage of Bad Related Providers column							
						$('#snaTable').bootstrapTable('hideColumn', 'badRltdPrvdrPct');
						
						// hide the entry in the columns drop down
						$("#snaTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="badRltdPrvdrPct"]').parent().hide();
						
					} else {
//						console.log('Show Percentage of Bad Related Providers column.');
						
						// show the Percentage of Bad Related Providers column
						$('#snaTable').bootstrapTable('showColumn', 'badRltdPrvdrPct');
						
						// show the entry in the columns drop down
						$("#snaTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="badRltdPrvdrPct"]').parent().show();
					}
					
					
					
				} else {
					console.log('Display an Other (empty) Report Card.');
					$scope.ruleBasedNpi = '';
					$scope.ruleBasedZone = '';
					$scope.ruleBasedMacZone = '';
					$scope.ruleBasedAsOfDt = '';
					$scope.ruleBasedLookback = '';
					
					//set the rules based table to show
					$scope.reportCardTypeSelect = 'ruleBased';
				//	$scope.reportCardHeaderSelect = 'unknown';
				
					//initiate the rules based table					
					//$("#ruleBasedTable").bootstrapTable({});
					
					var exportFilename = 'ReportsExport_' + $scope.ruleBasedAsOfDt + "_" + $scope.providerPaneObj.providerName.replace(/ /g,"_");
					//$("#ruleBasedTable").bootstrapTable({});
					$("#ruleBasedTable").bootstrapTable({exportOptions: {
				        fileName: exportFilename
				    }});
				}
				
				
				
				console.log("If navigated through Enhanced Risk Score explainability Tab? =>", $scope.setRcERC);
				
				//make sure the report card tab is always set to active when the tabs are shown
				// Enable active ERC tab when the link is clicked through ASR Risk score explainability tab.
				
				console.log("check partD->", $scope.partdDrillReportFlag); 
				console.log("check  riskScoreRC->", $scope.riskScoreRC.length);
				console.log("check  setRcERC->", $scope.setRcERC);
				
				//part d reports tab
				if ( $scope.riskScoreRC.length>0 ) {
					// if no records, disable the enhanced risk score cotri tab and enable Report cards tab
					
					//enable  Enhanced Risk Score Contributions Tab
					$('#rCardsEnhancedRCTabListItem').removeClass('disabled');
					$('#rCardsEnhancedRCTabListItem').attr('aria-disabled', 'false');
					$('#rCardsEnhancedRCTabLink').css('cursor', 'pointer');
					$('#rCardsEnhancedRCTabLink').css('pointer-events', 'auto');
					$('#rCardsEnhancedRCTabLink').attr('data-toggle','tab');
					console.log("show enhanced Report card tab");
					$("#enhancedRCTable").bootstrapTable('load', $scope.riskScoreRC);
					
					if ($scope.setRcERC == true){
						$('#rCardsEnhancedRCTabLink').tab('show');
						console.log("show enhanced Report card tab");						
					}else {
						// Show full page LoadingOverlay
						$.LoadingOverlay("show");
						
						console.log("Not through explainability tab, show report card by default, but enable Enhanced Report card tab!");	
						$timeout(function() {
							$('#rCardsTab').tab('show');
							// Show full page LoadingOverlay
							$.LoadingOverlay("hide");
							}, 1000);	
					}
				} else {
					
					// Show full page LoadingOverlay
					$.LoadingOverlay("show");
					
					// disbale Enhanced Risk Score Contributions Tab
					$('#rCardsEnhancedRCTabListItem').addClass('disabled');
					$('#rCardsEnhancedRCTabListItem').attr('aria-disabled', 'true');
					$('#rCardsEnhancedRCTabLink').css('cursor', 'not-allowed');
					$('#rCardsEnhancedRCTabLink').css('pointer-events', 'none');
					$('#rCardsEnhancedRCTabLink').removeAttr('data-toggle');		
					console.log("either part-d or non records exists  - diable ERC tab");
				
				
					$timeout(function() {
						$('#rCardsTab').tab('show');
						// Show full page LoadingOverlay
						$.LoadingOverlay("hide");
						}, 1000);				
				}
				
				
				//hide overlay for report card modal window
				$("#rptCardModalBody").LoadingOverlay("hide");
				
				//broadcast this event to the broadcastSlaMetrics listener
				$rootScope.$broadcast('broadcastSlaMetrics', {message:"Report Card Load - End: " + reportCardUniqueId, userId: ""});
				
			}).catch(function(err) {
				console.log('getReportCardData REST Error:' + err.status);	
				//hide overlay for report card modal window
				$("#rptCardModalBody").LoadingOverlay("hide");
				
				//show growl message
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Report Card table data not available due to ' + status, 'danger');
			});
		}
	};
	
	$scope.loadDocument = function(pURL) {
		console.log("Inside detailsFactory.loadDocument");
		var queryString = pURL.substring(pURL.lastIndexOf('?')+1, pURL.length-1);
		var urlParams = new URLSearchParams(queryString);
		if (!urlParams.get("userId")){
			pURL+="&userId="+$scope.uid;
		}
		console.log($scope.uid);
		// broadcast this event to the reset session listener
		$rootScope.$broadcast("factoryMethodCalled");
		config = {};

		detailsFactory.loadDocument(pURL).success(function(response) {	
		
		}).catch(function(err) {
			console.log('loadDocument REST Error:' + err.data);			
		});;
		
	
		console.log('loadDocument REST request = ' + jsonData);
    		    		
    		
    
		
	
    		    		
    		
    };
	
	$scope.loadEenhancedRCTabContent = function(){
		
		console.log("inside loadEenhancedRCTabContent")
//		console.log("$scope.riskScoreRC ->", $scope.riskScoreRC);
		//populate enhanced Risk Score contributions table					
		$("#enhancedRCTable").bootstrapTable('load', $scope.riskScoreRC);
		/*$("#enhancedRCTable").bootstrapTable('resetView');
		$("#enhancedRCTable").parent().attr('style', 'margin-left:1px !important;');*/
		
	}

	$scope.loadsupplementalRCTabContent = function(index, pModelId,tableId){
		//make a call to the getTabvizData factory method to get the Viz data
		detailsFactory.getReportVizData($scope.restURL, pModelId,  $scope.providerPaneObj.npi, tableId,  $scope.scopeUserId, $scope.mdcdState, $scope.activeASRTab).then(function(response) {
		console.log(response);
		$scope.customVizTablesImageArray = response.data.customVizTables[0];
		// ignore index as there will only be one dataRow per response
		$scope.customvizImgSrc = $scope.customVizTablesImageArray.dataRows[0].data[0].columnImgSrc;
		$scope.customvizImgType = $scope.customVizTablesImageArray.dataRows[0].data[0].columnImgSrcType;
		}).catch(function(data) {
			console.log('getReportCardData REST Error:' + data);
		});
	}


	$scope.loadCustomTabContent = function(pTabIndex) {
		console.log("Inside loadCustomTabContent. pTabIndex = " + pTabIndex);
		
		var colArray = [];
		var dataArray = [];
		var counterIndex = pTabIndex-1;
		
		//build the columns array
		colArray = getCustomTableColumns($scope.customTablesArray[counterIndex].columns);
		//build the data for the table
		dataArray = getCustomTableData($scope.customTablesArray[counterIndex].dataRows);
		
//		console.log("colArray = " + JSON.stringify(colArray));
		console.log("dataArray = " + JSON.stringify(dataArray));
		
//		$('#customRptTab' + pTabIndex + 'Table').bootstrapTable('destroy');
//		$('#customRptTab' + pTabIndex + 'Table').bootstrapTable({});
		
		//build the table with the data and columns
		$('#customRptTab' + pTabIndex + 'Table').bootstrapTable({
			data:dataArray,
			columns: colArray
		});
	}

	//this function creates the columns for a dynamic tab/table
	function getCustomTableColumns(pColumnObj) {
		var columns = [];
		var columnsArray = pColumnObj;
		for (j=0; j < columnsArray.length; j++) {
			//console.log('column name # ' + j + ' = ' + columnsArray[j].columnName);
			
			//if column contains a dollar amount, apply currency sorting
			if (columnsArray[j].columnName.indexOf('Claim Dollars for Procedure') != -1 
					|| columnsArray[j].columnName.indexOf('Claim Dollars Above Norm') != -1) {
				columns.push({
	                 field: 'column' + columnsArray[j].columnIndex,                   
	                 title: columnsArray[j].columnName,
	                 sortable: true,
	                 sorter: alphanum
	             });
			} else {
				columns.push({
			        field: 'column' + columnsArray[j].columnIndex,                   
			        title: columnsArray[j].columnName,
			        sortable: true,
			        formatter: 'npiFormatter'
			    });
			} 
		}
		
		return columns;
	}

	//this function creates the data for a dynamic tab/table
	function getCustomTableData(pDataObj) {
		var data = [];
		
		var dataRowsArray = pDataObj;
		console.log('dataRowsArray length = ' + dataRowsArray.length);
		for (k=0; k < dataRowsArray.length; k++) {							
			
			//create a new object to be injected into the data object
			var rowObj = {};
			
			var dataArray = dataRowsArray[k].data;
			console.log('dataArray length = ' + dataArray.length);
			
			//loop through the data in the dataRowsArray to build the columns
			for (n=0; n < dataArray.length; n ++) {
			//	console.log('column data # ' + n + ' = ' + dataArray[n].columnData);
				
				// check the linkToAsrInd value to see if the field should be a hyperlink
				if (dataArray[n].linkToAsrInd == 'Y') {
					// add the flag to the value so the formatter knows to make it a hyperlink					
					rowObj['column' + dataArray[n].columnIndex] = "linkToAsrInd-" + dataArray[n].columnData;
				} else {
					//populate each column
					rowObj['column' + dataArray[n].columnIndex] = dataArray[n].columnData;
				}
				
				
			}
			
			//console.log('rowObj = ' + JSON.stringify(rowObj));

			//add the row data to the data array
			data.push(rowObj);
		}
		
		return data;
	}
	
	//this function refreshes the data in the table presented in the Leads/Investigations tab
	function refreshLeadsTableData(pUserId) {
		//attach a tab overlay to the leads tab 		
		$("#leadsTab").LoadingOverlay("show");
		//initialize the leads Table
		$('#leadsTable').bootstrapTable({});
		
		//make a call to the getTabLeadsData factory method to get the leads data
		detailsFactory.getTabLeadsData($scope.restURL, $scope.asrDetailsParam, pUserId).success(function(data) {
			//console.log('tabDataLeads REST service call successful. leads = ' + JSON.stringify(data.responseData.leads));
			$scope.leadsRespArray = data.responseData.leads;
		
			//if the user is a MAC user, then hide certain columns
			if($scope.rolesArray.indexOf("MAC") != -1){
				//console.log('User is MAC, so hide Leads/Investigations columns.');
				
				$scope.macUser = 'true';
								
				//$('#leadsTable').bootstrapTable('hideColumn', 'assignedTo');
				$('#leadsTable').bootstrapTable('hideColumn', 'activities');
				$('#leadsTable').bootstrapTable('hideColumn', 'actions');
				//$('#leadsTable').bootstrapTable('hideColumn', 'ruling');
				$('#leadsTable').bootstrapTable('hideColumn', 'subRuling');
				//hide the entries in the show column button drop down menu
				//$("#leadsTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="assignedTo"]').parent().hide();
				$("#leadsTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="activities"]').parent().hide();
				$("#leadsTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="actions"]').parent().hide();
				$("#leadsTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="subRuling"]').parent().hide();
			}
			
			//refresh the leads table
			$('#leadsTable').bootstrapTable('load', $scope.leadsRespArray);

			//hide a tab overlay to the leads tab 		
			$("#leadsTab").LoadingOverlay("hide");
			
		}).error(function(data, status) {
			console.log('tabDataLeads REST Error:' + status);	
			//hide a tab overlay to the notes tab 		
			$("#leadsTab").LoadingOverlay("hide");
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Leads table data not refreshed due to ' + status, 'danger');
		});
	}
//this function refreshes the data in the table presented in the Leads/Investigations tab
	function refreshLeadsMdcdTableData(pUserId) {
		//attach a tab overlay to the leads tab 		
		$("#leadsTabMdcd").LoadingOverlay("show");
		//initialize the leads Table
		$('#leadsTableMdcd').bootstrapTable({});
		
		//make a call to the getTabLeadsData factory method to get the leads data
		detailsFactory.getTabLeadsMdcdData($scope.restURL, $scope.asrDetailsParam, pUserId).success(function(data) {
			//console.log('tabDataLeads REST service call successful. leads = ' + JSON.stringify(data.responseData.leads));
			$scope.leadsRespArray = data.responseData.leads;
		
					
			//refresh the leads table
			$('#leadsTableMdcd').bootstrapTable('load', $scope.leadsRespArray);

			//hide a tab overlay to the leads tab 		
			$("#leadsTabMdcd").LoadingOverlay("hide");
			
		}).error(function(data, status) {
			console.log('tabDataLeads REST Error:' + status);	
			//hide a tab overlay to the notes tab 		
			$("#leadsTabMdcd").LoadingOverlay("hide");
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Leads table data not refreshed due to ' + status, 'danger');
		});
	}

	//show Provider Pane PTANs
	$scope.showProviderPanePtans = function() {
		console.log('Inside showProviderPanePtans function.');
		//show modal window
		$("#prvdrPtanModal").modal("show");		
		//initiate the modal table
		$("#prvdrPanePtanTable").bootstrapTable({});
		//populate the table
		$('#prvdrPanePtanTable').bootstrapTable('load', $scope.providerPaneObj.ptans);
	}
	
	//show Provider Pane Alerts 
	$scope.showProviderPaneAlerts = function() {
		console.log('Inside showProviderPaneAlerts function.');
		//show modal window
		$("#prvdrAlertsModal").modal("show");		
		//initiate the modal table
		$("#prvdrPaneAlertsTable").bootstrapTable({});
		//populate the table
		$('#prvdrPaneAlertsTable').bootstrapTable('load', $scope.providerPaneObj.alerts);
	}
	
	// show the enrollment id modal window when link is clicked
	$scope.showProviderPaneEnrollId = function() {
		console.log('Inside showProviderPaneEnrollId function.');
		
		if ( $scope.activeASRTab == "medicaid") {
			
			console.log($scope.providerPaneObj.mdcdEnrollmentIds)
			
			//display the modal window
			$("#medicaidEnrollmentIdModal").modal("show");
			
			//initiate the modal table
			$("#medicaidEnrollmentIdModalTable").bootstrapTable('destroy');
			$("#medicaidEnrollmentIdModalTable").bootstrapTable({});
			
			$("#medicaidEnrollmentIdModalTable").bootstrapTable('load', $scope.providerPaneObj.mdcdEnrollmentIds);
			
		}else {
			//display the modal window
			$("#enrollmentIdModal").modal("show");
			
			//initiate the modal table
			$("#enrollmentIdModalTable").bootstrapTable('destroy');
			$("#enrollmentIdModalTable").bootstrapTable({});
			
			$("#enrollmentIdModalTable").bootstrapTable('load', $scope.providerPaneObj.enrollmentIds);
			
		}
		
		
	}
	
	//show Provider System Tags
	$scope.showProviderPaneSysTags = function() {
		console.log('Inside showProviderPaneSysTags function.');
		//show modal window
		$("#prvdrSysTagsModal").modal("show");		
		//initiate the modal table
		$("#prvdrSysTagsTable").bootstrapTable({});
		//populate the table
		$('#prvdrSysTagsTable').bootstrapTable('load', $scope.providerPaneObj.sysTags.sysTags);
	}

	//show Provider Pane Roles 
	$scope.showProviderPaneRoles = function() {
		console.log('Inside showProviderPaneRoles function.');
		//show modal window
		$("#prvdrRolesModal").modal("show");		
		//initiate the modal table
		$("#prvdrPaneRolesTable").bootstrapTable({});
		//populate the table
		$('#prvdrPaneRolesTable').bootstrapTable('load', $scope.providerPaneObj.subjectRoleCd);
	}

	//show Provider Pane Barrier to Action
	$scope.showProviderPaneBarToAction = function() {
		console.log('Inside showProviderPaneBartoAction function.');
		//show modal window
		$("#prvdrBarToActionModal").modal("show");
		//initialize the modal table
		$('#prvdrBarToActionTable').bootstrapTable({});
		//get the barrierToAction Object from the Response				
		$('#prvdrBarToActionTable').bootstrapTable('load', $scope.providerPaneObj.barrierToAction);	
	}

	// user clicked on Claims tab, so populate HICN multi-select
	// also enable/disable buttons and checkboxes
	$scope.initClaimsForm = function() {
		console.log('User clicked Claims Line tab (initClaimsForm function)');
		
		// clear the form claim lines form
		$scope.resetClaimsSearch();
		
		console.log('atRiskInd = ' + $scope.responseData.availableClaims.atRiskInd);
		if($scope.responseData.availableClaims.atRiskInd == 'Y') {
			// enable the Claims at Risk Button	
			$scope.disableAtRiskBtn = false;			
		} else {
			// disable the Claims at Risk Button
			$scope.disableAtRiskBtn = true;		
		}
		
		console.log('atRiskDInd = ' + $scope.responseData.availableClaims.atRiskDInd);
		if($scope.responseData.availableClaims.atRiskDInd == 'Y') {
			// enable the Part D Claims at Risk button
			$scope.disablePartDSrchBtn = false;
		} else {
			// disable the Part D Claims at Risk button
			$scope.disablePartDSrchBtn = true;
		}
		
		console.log('latestInd = ' + $scope.responseData.availableClaims.latestInd);
		if ($scope.responseData.availableClaims.latestInd  == 'Y') {
			// enable the Latest Claims button
			$scope.disableLatestClmBtn = false;
		} else {
			// disable the Latest Claims button
			$scope.disableLatestClmBtn = true;
		}
		
		console.log('latestDInd = ' + $scope.responseData.availableClaims.latestDInd);
		if ($scope.responseData.availableClaims.latestDInd == 'Y') {
			// enable the Part D Latest Claims button
			$scope.disablePartDLatestBtn = false;
		} else {
			// disable the Part D Latest Claims button
			$scope.disablePartDLatestBtn = true;
		}
		
		// if allClaimsInd = N then A/B/DME should be enabled
		console.log('allClaimsInd = ' + $scope.responseData.availableClaims.allClaimsInd);
		if ($scope.responseData.availableClaims.allClaimsInd == 'Y') {
			console.log("Enable A/B/DME");
			 
			// A/B/DME should be enabled when user picks the All Claims radio button
			$scope.disablePartA = false;
			$scope.disablePartB = false;			
			$scope.disableDme = false;	
			
			// populate the Part A checkbox by default
			//$scope.claimsFormPartA = true;
		} else {
		    console.log("Disable A/B/DME");
			
			$scope.disablePartA = true;
			$scope.disablePartB = true;			
			$scope.disableDme = true;		
		}
		
		console.log('allClaimsDInd = ' + $scope.responseData.availableClaims.allClaimsDInd);
		if ($scope.responseData.availableClaims.allClaimsDInd == 'Y') {
			console.log("Enable D");
			
			// enable Part D check box	
			$scope.disablePartD = false;
			
			// populate the Part D checkbox by default
			//$scope.claimsFormPartD = true;
		} else {
			console.log("Disable D");
			
			// disable Part D check box
			$scope.disablePartD = true;
		}
		
		console.log('rrbInd = ' + $scope.responseData.availableClaims.rrbInd)
		if ($scope.responseData.availableClaims.rrbInd == 'Y') {
			// enable the RRB Claims button
			$scope.disableRrbSrchBtn = false;
		} else {
			$scope.disableRrbSrchBtn = true;
		}
		
		// if all of the checkboxes are disabled, then disable the search button
		if($scope.disablePartA && $scope.disablePartB && $scope.disableDme && $scope.disablePartD) {
			
			//disable the "Claims Search" button
			$scope.disableClmSrchBtn = true;	
			
		} else {
			//enable the "Claims Search" button
			$scope.disableClmSrchBtn = false;	
		}
	}
	// user clicked on Claims tab, so populate states
	$scope.initClaimsFormMdcd = function() {
		console.log('User clicked Mdcd Claims Line tab (initClaimsFormMdcd function)');
		if ($scope.responseData.availableClaims.atRiskInd != 'Y') {
			// enable the claims at risk button
			$scope.disableClmSrchMdcdBtn = true;
			$scope.disableAtRiskMdcdBtn = true;
		
		} else {
			$scope.disableClmSrchMdcdBtn = false;
			$scope.disableAtRiskMdcdBtn = false;
		}
	
		// populate alert models
		$scope.loadMedicaidClaimStates($scope.asrDetailsDbIdParam, $scope.scopeUserId);
		// clear the form claim lines form
		$scope.resetClaimsSearchMdcd();

		
	}

	// capture click to radio buttons, and then disable/enable claim types check boxes accordingly
	$scope.hideShowClaimCheckVals = function(pRadioType) {
		console.log("hideShowClaimCheckVals. Radio Type = " + pRadioType);
		
		// clear all of the checkboxes
		$scope.claimsFormPartA = false;
		$scope.claimsFormPartB = false;
		$scope.claimsFormPartD = false;
		$scope.claimsFormDME = false;
	
		if (pRadioType == "allClaimsVal") {
			// all claims radio button chosen
			
			// if allClaimsInd = N then A/B/DME should be enabled
			console.log('allClaimsInd = ' + $scope.responseData.availableClaims.allClaimsInd);
			if ($scope.responseData.availableClaims.allClaimsInd == 'Y') {
				console.log("Enable A/B/DME");
				 
				// A/B/DME should be enabled when user picks the All Claims radio button
				$scope.disablePartA = false;
				$scope.disablePartB = false;			
				$scope.disableDme = false;	
				
				// populate the Part A checkbox by default
				//$scope.claimsFormPartA = true;
			} else {
			    console.log("Disable A/B/DME");
				
				$scope.disablePartA = true;
				$scope.disablePartB = true;			
				$scope.disableDme = true;		
			}
			
			console.log('allClaimsDInd = ' + $scope.responseData.availableClaims.allClaimsDInd);
			if ($scope.responseData.availableClaims.allClaimsDInd == 'Y') {
				console.log("Enable D");
				
				// enable Part D check box	
				$scope.disablePartD = false;
				
				// populate the Part D checkbox by default
				//$scope.claimsFormPartD = true;
			} else {
				console.log("Disable D");
				
				// disable Part D check box
				$scope.disablePartD = true;
			}
		} else if (pRadioType == "claimsAtRiskVal")  {
			// claims at risk radio button chosen
			
			// if atRiskInd = N then A/B/DME should be enabled
			console.log('atRiskInd = ' + $scope.responseData.availableClaims.atRiskInd);
			if ($scope.responseData.availableClaims.atRiskInd == 'Y') {
				console.log("Enable A/B/DME");
				 
				// A/B/DME should be enabled when user picks the All Claims radio button
				$scope.disablePartA = false;
				$scope.disablePartB = false;			
				$scope.disableDme = false;	
				
				// populate the Part A checkbox by default
				//$scope.claimsFormPartA = true;
			} else {
			    console.log("Disable A/B/DME");
			    
				$scope.disablePartA = true;
				$scope.disablePartB = true;			
				$scope.disableDme = true;		
			}
			
			console.log('atRiskDInd = ' + $scope.responseData.availableClaims.atRiskDInd);
			if ($scope.responseData.availableClaims.atRiskDInd == 'Y') {
				console.log("Enable D");
				
				// enable Part D check box	
				$scope.disablePartD = false;
				
				// populate the Part A checkbox by default
				//$scope.claimsFormPartD = true;
			} else {
				console.log("Disable D");
				
				// disable Part D check box
				$scope.disablePartD = true;
			}
		}
		else{
			$scope.disablePartA = false;
			$scope.disablePartB = false;			
			$scope.disableDme = false;	
			$scope.disablePartD = true;
			$scope.phase1Claims = true;
		}
		
		// if all of the checkboxes are disabled, then disable the search button
		if($scope.disablePartA  && $scope.disablePartB && $scope.disableDme && $scope.disablePartD) {
			
			//disable the "Claims Search" button
			$scope.disableClmSrchBtn = true;	
			
		} else {
			//enable the "Claims Search" button
			$scope.disableClmSrchBtn = false;	
			
		}
		
		// set form as Dirty since user clicked the radio button
		$scope.claimsSearchForm.$setDirty();
	}
	
	$scope.loadMedicaidClaimStates = function(pAsrptId, pUserId) {
		
	
		
		detailsFactory.loadMedicaidClaimStates($scope.restURL, pAsrptId, pUserId).then(function(response) {
			// use the list to populate the medicaid states
			$scope.states = response;
			if (response.data.states != null) {
			// convert alertId to modelId
			var statesArr = [];
			
				for (i=0; i < response.data.states.length; i++) {
					var stateObj = {};
					
					stateObj.state = response.data.states[i].state;
					stateObj.lclState = response.data.states[i].lclState;
					statesArr.push(stateObj);
				}
				
				$scope.claimsFormMdcdStateList = statesArr;
			}

			console.log("states",$scope.claimsFormMdcdStateList);
			});
			
	}
	$scope.conductClaimsSearch = function(pSearchType) {
		//console.log('Inside conductClaimsSearch function. pSearchType = ' + pSearchType);
		
			var slaLabel = "";
			if (pSearchType == "rrb") slaLabel = "RRB ";
			if (pSearchType == "latest") slaLabel = "All ";
			if (pSearchType == "latestD") slaLabel = "Part D All";
			
			var claimsId = crypto.randomUUID();
			//broadcast this event to the broadcastSlaMetrics listener
			$rootScope.$broadcast('broadcastSlaMetrics', {message:"All Claims File - " + slaLabel+"Claims Search - Start: " + claimsId, userId: ""});
		
			//show claims Lines Panel Overlay
			$("#claimLinesTab").LoadingOverlay("show");
			
			// show growl message to user
//			showGrowl('<i class=\'fa fa-info-circle\' aria-hidden=\'true\'></i> Export Started. Please be patient, this may take a moment.', 'info');
			
			//build the search request object
			claimsSearchObj = {};
			//set search asrptId
			claimsSearchObj.npi =  $scope.providerPaneObj.npi;
			
			// check the search type the user is performing
			if (pSearchType == "latest") {
				console.log("Perform search for latest claims.");
				
				claimsSearchObj.fromDt = null;
				claimsSearchObj.toDt = null;
				claimsSearchObj.claimTypes = null;
				claimsSearchObj.hicns = null;
				claimsSearchObj.latest = "Y";
				claimsSearchObj.rrb = "N";
				claimsSearchObj.latestD = "N";
				
			}  else if (pSearchType == "rrb") {
				// build the rrb claims request
				claimsSearchObj.fromDt = null;
				claimsSearchObj.toDt = null;
				claimsSearchObj.claimTypes = null;
				claimsSearchObj.hicns = null;
				claimsSearchObj.latest = "N";
				claimsSearchObj.rrb = "Y";
				claimsSearchObj.latestD = "N";
				
			} else if (pSearchType == "latestD") {
				// conduct the Part D latest claims search				
				claimsSearchObj.fromDt = null;
				claimsSearchObj.toDt = null;
				claimsSearchObj.claimTypes = null;
				claimsSearchObj.hicns = null;
				claimsSearchObj.latest = "N";
				claimsSearchObj.rrb = "N";
				claimsSearchObj.latestD = "Y";
				
			} else if (pSearchType == "main" || pSearchType == "p1Cost" || pSearchType == "p1Claims" ) {
				console.log("Perform main search for claims.");
				
					// add the asr id by default
					claimsSearchObj.asrptId = $scope.asrDetailsDbIdParam;
					
					// all claims/claims risk radio values
//					console.log('radio1 value = ' + $('#claimsFormAllClaims').prop('checked'));
//					console.log('radio2 value = ' + $('#claimsFormClaimsRisk').prop('checked'));
					
					// all claims/claims at risk radio buttons
					if ($('#claimsFormAllClaims').prop('checked')) {
						
						console.log('All Claims. Part D = ' + $scope.claimsFormPartD);
						
						// check to see if the user chose the Part D checkbox. If so, pass PARTDALERTED
						if ($scope.claimsFormPartD === true) {
							// user selected all claims
							claimsSearchObj.searchType = 'PARTDRAW'
						} else {
							// user selected all claims
							claimsSearchObj.searchType = 'RAW'
						}					
						
					} else if ($('#claimsFormClaimsRisk').prop('checked')) {
						console.log('Claims at risk. Part D = ' + $scope.claimsFormPartD);
						
						// check to see if the user chose the Part D checkbox. If so, pass PARTDALERTED
						if ($scope.claimsFormPartD === true) {
							// user selected risk claims
							claimsSearchObj.searchType = 'PARTDALERTED'
						} else {
							// user selected all claims
							claimsSearchObj.searchType = 'ALERTED'
						}
					}
					else if($('#phase1Claims').prop('checked')){
						$scope.phase1Claims = true;
						claimsSearchObj.searchType = 'P1ALERTED'
					}
					
					// hcpcs code
					if ($scope.hcpcsClaimSearch != "" && $scope.hcpcsClaimSearch != void(0) && !$("#hcpcsClaimSearch").prop("disabled")) {
						//claimsSearchObj.hcpcs = $scope.hcpcsClaimSearch;
						var selectedHcpcsArray = [];
						
						// get the number of lines in the hcpcs text area
						var lines = $('#hcpcsClaimSearch').val().trim().split('\n');
						console.log('# of hcpcs claim lines = ' + lines.length);
						
						// limit the number of lines a user can enter to 50
						if (lines.length > 50) {
							console.log('Hcpcs count is over 50 - invalid');
							// number of entries is over 50, so invalidate the the search
							$scope.claimsSearchForm.hcpcsClaimSearch.$setValidity('hcpcserror', false);
						} else {
							console.log('HCPCS count is under 50 - valid');
							
							// number of entries is under 50, so validate the search
							$scope.claimsSearchForm.hcpcsClaimSearch.$setValidity('hcpcserror', true);
							
							// build HCPCS object for REST request
							for (i = 0; i < lines.length; i++) {
								
								var hcpcsObj = {};
								hcpcsObj.code = lines[i];
								selectedHcpcsArray.push(hcpcsObj);
							}
						}
						
						console.log('Selected HCPCS Array = ' + JSON.stringify(selectedHcpcsArray));
						claimsSearchObj.hcpcses = selectedHcpcsArray;
						
					}  else {
						claimsSearchObj.hcpcses = null;
						
						// listing no hcpcs codes is valid, so set validity to true
						$scope.claimsSearchForm.hcpcsClaimSearch.$setValidity('hcpcserror', true);
					}
					
					// procedure code
					if ($scope.icdClaimSearch != "" && $scope.icdClaimSearch != void(0) && !$("#icdClaimSearch").prop("disabled")) {
						// claimsSearchObj.procedure = $scope.icdClaimSearch;						
						var selectedIcdArray = [];
						
						// get the number of lines in the icd text area
						var lines = $('#icdClaimSearch').val().trim().split('\n');
						console.log('# of icd claim lines = ' + lines.length);
						
						// limit the number of lines a user can enter to 50
						if (lines.length > 50) {
							console.log('ICD count is over 50 - invalid');
							// number of entries is over 50, so invalidate the the search
							$scope.claimsSearchForm.icdClaimSearch.$setValidity('icderror', false);
						} else {
							console.log('ICD count is under 50 - valid');
							
							// number of entries is under 50, so validate the search
							$scope.claimsSearchForm.icdClaimSearch.$setValidity('icderror', true);
							
							// build ICD object for REST request
							for (i = 0; i < lines.length; i++) {								
								var icdObj = {};
								icdObj.code = lines[i];
								selectedIcdArray.push(icdObj);
							}
						}
						
						console.log('Selected ICD Array = ' + JSON.stringify(selectedIcdArray));
						claimsSearchObj.procedures = selectedIcdArray;
					}  else {
						claimsSearchObj.procedures = null;
						
						// listing no icd codes is valid, so set validity to true
						$scope.claimsSearchForm.icdClaimSearch.$setValidity('icderror', true);
					}
					
					//end date
					if ($scope.claimsFormEndDate != "" && $scope.claimsFormEndDate != void(0)) {
						claimsSearchObj.toDt = $scope.claimsFormEndDate;
					} else {
						claimsSearchObj.toDt = null;
					}
					
					//start date
					if ($scope.claimsFormStartDate != "" && $scope.claimsFormStartDate != void(0)) {
						claimsSearchObj.fromDt = $scope.claimsFormStartDate;
					} else {
						claimsSearchObj.fromDt = null;
					}
					
					//claims type check boxes
					console.log("Part A = " + $scope.claimsFormPartA + ", Part B = " + $scope.claimsFormPartB 
							+ ", Part D = " + $scope.claimsFormPartD + ", DME = " + $scope.claimsFormDME);
					
					if (($scope.claimsFormPartA === false || $scope.claimsFormPartA === void(0)) && ($scope.claimsFormPartB === false || $scope.claimsFormPartB === void(0)) 
							&& ($scope.claimsFormDME === false || $scope.claimsFormDME === void(0)) && ($scope.claimsFormPartD === false || $scope.claimsFormPartD === void(0))) {
						
						// user did not check a claims type check box, so invalidate
						// invalidate form
						$scope.claimsSearchForm.claimsFormPartA.$setValidity('claimstypeerror', false);
						$scope.claimsSearchForm.claimsFormPartB.$setValidity('claimstypeerror', false);
						$scope.claimsSearchForm.claimsFormPartD.$setValidity('claimstypeerror', false);
						$scope.claimsSearchForm.claimsFormDME.$setValidity('claimstypeerror', false);
						
						// set form to dirty to display error messages
						$scope.claimsSearchForm.$setDirty();						
						
						claimsSearchObj.claimTypes = null;
					} else {
						var claimsTypeArray = [];
						
						if ($scope.claimsFormPartA === true) {
							var claimsTypeObj = {};
							claimsTypeObj.code = "A";
							claimsTypeArray.push(claimsTypeObj);
						}
						
						if ($scope.claimsFormPartB === true) {
							var claimsTypeObj = {};
							claimsTypeObj.code = "B";
							claimsTypeArray.push(claimsTypeObj);
						}
						
						if ($scope.claimsFormPartD === true) {
							var claimsTypeObj = {};
							claimsTypeObj.code = "D";
							claimsTypeArray.push(claimsTypeObj);
						}
						
						if ($scope.claimsFormDME === true) {
							var claimsTypeObj = {};
							claimsTypeObj.code = "DME";
							claimsTypeArray.push(claimsTypeObj);
						}
						
						console.log('Selected Claim Types Array = ' + JSON.stringify(claimsTypeArray));
						claimsSearchObj.claimTypes = claimsTypeArray;
					}
					
					// diagnosis code multi-select
					// console.log("Diagnosis search field disabled = " + $("#diagnosisClaimSearch").prop("disabled"));
					if ($scope.diagnosisClaimSearch != "" && $scope.diagnosisClaimSearch != void(0) && !$("#diagnosisClaimSearch").prop("disabled")) {
						//claimsSearchObj.diagnosis = $scope.diagnosisClaimSearch;
						
						var selectedDiagArray = [];
						
						// get the number of lines in the diagnosis text area
						var lines = $('#diagnosisClaimSearch').val().trim().split('\n');
						console.log('# of diagnosis claim lines = ' + lines.length);
						
						// limit the number of lines a user can enter to 50
						if (lines.length > 50) {
							console.log('Diagnosis count is over 50 - invalid');
							// number of entries is over 50, so invalidate the the search
							$scope.claimsSearchForm.diagnosisClaimSearch.$setValidity('diaglineserror', false);
						} else {
							console.log('Diagnosis count is under 50 - valid');
							
							// number of entries is under 50, so validate the search
							$scope.claimsSearchForm.diagnosisClaimSearch.$setValidity('diaglineserror', true);
							
							// build Diagnosis object for REST request
							for (i = 0; i < lines.length; i++) {
								
								var diagObj = {};
									diagObj.code = lines[i];
									selectedDiagArray.push(diagObj);
							}
						}
						
						console.log('Selected Diagnosis Array = ' + JSON.stringify(selectedDiagArray));
						claimsSearchObj.diagnosises = selectedDiagArray;
						
					}  else {
						claimsSearchObj.diagnosises = null;
						
						// listing no diagnosis codes is valid, so set validity to true
						$scope.claimsSearchForm.diagnosisClaimSearch.$setValidity('diaglineserror', true);
					}
					
					//beneficiary multi-select
					if ($scope.claimsFormBene === void(0) || $scope.claimsFormBene === null || $scope.claimsFormBene === '') {
						claimsSearchObj.hicns = null;
						
						// listing no benes is valid, so set validity to true
						$scope.claimsSearchForm.claimsFormBene.$setValidity('hicnlineserror', true);
					} else {
						var selectedBeneArray = [];
						
						// get the number of lines in the text area
						var lines = $('#claimsFormBene').val().trim().split('\n');
						console.log('# of bene claim lines = ' + lines.length);
						
						// limit the number of lines a user can enter to 50
						if (lines.length > 50) {
							console.log('Bene count is over 50 - invalid');
							// number of entries is over 50, so invalidate the the search
							$scope.claimsSearchForm.claimsFormBene.$setValidity('hicnlineserror', false);
						} else {
							
							console.log('Bene count is under 50 - valid');
							
							// number of entries is under 50, so validate the search
							$scope.claimsSearchForm.claimsFormBene.$setValidity('hicnlineserror', true);
							
							// build HICN/MIB object for REST request
							for (i = 0; i < lines.length; i++) {
								
								var beneObj = {};
								    beneObj.hicn = lines[i];
								    selectedBeneArray.push(beneObj);
							}
						}
						
						console.log('Selected Bene Array = ' + JSON.stringify(selectedBeneArray));
						claimsSearchObj.hicns = selectedBeneArray;
					}
					
					claimsSearchObj.latest = "N";	
					claimsSearchObj.rrb = "N";
				
			}
			
//			console.log('claimsSearchObj = ' + JSON.stringify(claimsSearchObj));
			
		if (pSearchType == "rrb" || pSearchType == "latest" || pSearchType == "latestD" || (pSearchType == "main" && $scope.claimsSearchForm.$valid)) {
			//call the export search service to get the CSV file
			//				detailsFactory.getSearchClaimsExport($scope.restURL, claimsSearchObj).success(function(data) {
			//construct the filename to use for export
			var claimsSearchFilename = $scope.providerPaneObj.providerName + "_" + moment(new Date()).format("YYYY-MM-DD") + "_claimsExport.csv";

			// encode claimsSearchObjpSearchType == "p1Cost"
			var encodedObj = window.btoa(JSON.stringify(claimsSearchObj));

			//encode the filename
			var encodeFilename = window.btoa(claimsSearchFilename);
			$scope.openClaimsExport('LoadClaimsDocumentServlet?asrId=' + $scope.asrDetailsDbIdParam + '&userId=' + $scope.scopeUserId + '&searchType=latest'
				+ '&fileName=' + encodeFilename + '&searchObj=' + encodedObj,
				"All Claims File - " + slaLabel + " Claims Search - End: " + claimsId);
			
			//hide claims Lines Panel Overlay
			$("#claimLinesTab").LoadingOverlay("hide");

		}  else {
				//hide claims Lines Panel Overlay
				$("#claimLinesTab").LoadingOverlay("hide");
				
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Please update all invalid form fields.', 'danger');
				
			}
	}

	$scope.conductClaimsSearchMdcd = function(pSearchType) {
		//console.log('Inside conductClaimsSearchMdcd function. pSearchType = ' + pSearchType);
		
			var claimsId = crypto.randomUUID();
			//broadcast this event to the broadcastSlaMetrics listener
			$rootScope.$broadcast('broadcastSlaMetrics', {message:"All Claims File - " +"MDCD Claims Search - Start: " + claimsId, userId: ""});
		
			//show claims Lines Panel Overlay
			$("#claimLinesMdcdTab").LoadingOverlay("show");
			
			// show growl message to user
//			showGrowl('<i class=\'fa fa-info-circle\' aria-hidden=\'true\'></i> Export Started. Please be patient, this may take a moment.', 'info');
			
			//build the search request object
			claimsSearchObj = {};
			//set search asrptId
			claimsSearchObj.npi =  $scope.providerPaneObj.npi;
			
			// check the search type the user is performing
			if (pSearchType == "main") {
				console.log("Perform main search for claims.");
				
					// add the asr id by default
					claimsSearchObj.asrptId = $scope.asrDetailsDbIdParam;
					
					claimsSearchObj.searchType = 'ALERTED'
					
					// state
					
					
					// hcpcs code
					if ($scope.hcpcsClaimMdcdSearch != "" && $scope.hcpcsClaimMdcdSearch != void(0) ) {
						//claimsSearchObj.hcpcs = $scope.hcpcsClaimSearch;
						var selectedHcpcsArray = [];
						
						// get the number of lines in the hcpcs text area
						var lines = $('#hcpcsClaimMdcdSearch').val().trim().split('\n');
						console.log('# of hcpcs claim lines = ' + lines.length);
						
						// limit the number of lines a user can enter to 50
						if (lines.length > 50) {
							console.log('Hcpcs count is over 50 - invalid');
							// number of entries is over 50, so invalidate the the search
							$scope.claimsSearchMdcdForm.hcpcsClaimMdcdSearch.$setValidity('hcpcserror', false);
						} else {
							console.log('HCPCS count is under 50 - valid');
							
							// number of entries is under 50, so validate the search
							$scope.claimsSearchMdcdForm.hcpcsClaimMdcdSearch.$setValidity('hcpcserror', true);
							
							// build HCPCS object for REST request
							for (i = 0; i < lines.length; i++) {
								
								var hcpcsObj = {};
								hcpcsObj.code = lines[i];
								selectedHcpcsArray.push(hcpcsObj);
							}
						}
						
						console.log('Selected HCPCS Array = ' + JSON.stringify(selectedHcpcsArray));
						claimsSearchObj.hcpcses = selectedHcpcsArray;
						
					}  else {
						claimsSearchObj.hcpcses = null;
						
						// listing no hcpcs codes is valid, so set validity to true
						$scope.claimsSearchMdcdForm.hcpcsClaimMdcdSearch.$setValidity('hcpcserror', true);
					}
					
					// procedure code
					if ($scope.icdClaimMdcdSearch != "" && $scope.icdClaimMdcdSearch != void(0) && !$("#icdClaimMdcdSearch").prop("disabled")) {
						// claimsSearchObj.procedure = $scope.icdClaimMdcdSearch;						
						var selectedIcdArray = [];
						
						// get the number of lines in the icd text area
						var lines = $('#icdClaimMdcdSearch').val().trim().split('\n');
						console.log('# of icd claim lines = ' + lines.length);
						
						// limit the number of lines a user can enter to 50
						if (lines.length > 50) {
							console.log('ICD count is over 50 - invalid');
							// number of entries is over 50, so invalidate the the search
							$scope.claimsSearchMdcdForm.icdClaimMdcdSearch.$setValidity('icderror', false);
						} else {
							console.log('ICD count is under 50 - valid');
							
							// number of entries is under 50, so validate the search
							$scope.claimsSearchMdcdForm.icdClaimMdcdSearch.$setValidity('icderror', true);
							
							// build ICD object for REST request
							for (i = 0; i < lines.length; i++) {								
								var icdObj = {};
								icdObj.code = lines[i];
								selectedIcdArray.push(icdObj);
							}
						}
						
						console.log('Selected ICD Array = ' + JSON.stringify(selectedIcdArray));
						claimsSearchObj.procedures = selectedIcdArray;
					}  else {
						claimsSearchObj.procedures = null;
						
						// listing no icd codes is valid, so set validity to true
						$scope.claimsSearchMdcdForm.icdClaimMdcdSearch.$setValidity('icderror', true);
					}
					
					//end date
					if ($scope.claimsFormMdcdEndDate != "" && $scope.claimsFormMdcdEndDate != void(0)) {
						claimsSearchObj.toDt = $scope.claimsFormMdcdEndDate;
					} else {
						claimsSearchObj.toDt = null;
					}
					
					//start date
					if ($scope.claimsFormMdcdStartDate != "" && $scope.claimsFormMdcdStartDate != void(0)) {
						claimsSearchObj.fromDt = $scope.claimsFormMdcdStartDate;
					} else {
						claimsSearchObj.fromDt = null;
					}
					
					//svc sub cat type check boxes
					console.log("MCO = " + $scope.claimsFormSvcSubcatMCO + ", FFS = " + $scope.claimsFormSvcSubcatFFS);
					var mdcdSvcSubcatsArray = [];
					
					if ($scope.claimsFormSvcSubcatFFS === true) {
						var mdcdSvcSubcatsObj = {};
						mdcdSvcSubcatsObj.code = "FFS";
						mdcdSvcSubcatsArray.push(mdcdSvcSubcatsObj);
					}
					
					
					if ($scope.claimsFormSvcSubcatMCO === true) {
						var mdcdSvcSubcatsObj = {};
						mdcdSvcSubcatsObj.code = "ENCTR";
						mdcdSvcSubcatsArray.push(mdcdSvcSubcatsObj);
					}
					console.log('Selected Svc subCats Array = ' + JSON.stringify(mdcdSvcSubcatsArray));
					claimsSearchObj.mdcdSvcSubcats = mdcdSvcSubcatsArray;
					//svc cat type check boxes
					console.log("Inst = " + $scope.claimsFormSvcCatInst + ", Prof = " + $scope.claimsFormSvcCatProf 
							+ ", Drug = " + $scope.claimsFormSvcCatDrug + ", Dental = " + $scope.claimsFormSvcCatDental
							+ ", Other = " + $scope.claimsFormSvcCatOther 
							+ ", DME = " + $scope.claimsFormSvcCatDME + ", NonClm = " + $scope.claimsFormSvcCatNC);
					
				
					var mdcdSvcCatsArray = [];
					
					if ($scope.claimsFormSvcCatInst === true) {
						var mdcdSvcCatsObj = {};
						mdcdSvcCatsObj.code = "INSTNL";
						mdcdSvcCatsArray.push(mdcdSvcCatsObj);
					}
					
					if ($scope.claimsFormSvcCatProf === true) {
						var mdcdSvcCatsObj = {};
						mdcdSvcCatsObj.code = "PRFNL";
						mdcdSvcCatsArray.push(mdcdSvcCatsObj);
					}
					
					if ($scope.claimsFormSvcCatDrug === true) {
						var mdcdSvcCatsObj = {};
						mdcdSvcCatsObj.code = "DRUG";
						mdcdSvcCatsArray.push(mdcdSvcCatsObj);
					}
					
					if ($scope.claimsFormSvcCatDental === true) {
						var mdcdSvcCatsObj = {};
						mdcdSvcCatsObj.code = "DENTAL";
						mdcdSvcCatsArray.push(mdcdSvcCatsObj);
					}
					if ($scope.claimsFormSvcCatOther === true) {
						var mdcdSvcCatsObj = {};
						mdcdSvcCatsObj.code = "Other";
						mdcdSvcCatsArray.push(mdcdSvcCatsObj);
					}
					if ($scope.claimsFormSvcCatDME === true) {
						var mdcdSvcCatsObj = {};
						mdcdSvcCatsObj.code = "DME";
						mdcdSvcCatsArray.push(mdcdSvcCatsObj);
					}
					if ($scope.claimsFormSvcCatNC === true) {
						var mdcdSvcCatsObj = {};
						mdcdSvcCatsObj.code = "NONCLM";
						mdcdSvcCatsArray.push(mdcdSvcCatsObj);
					}
					console.log('Selected Svc Cats Array = ' + JSON.stringify(mdcdSvcCatsArray));
					claimsSearchObj.mdcdSvcCats = mdcdSvcCatsArray;
					
					
					// diagnosis code multi-select
					// console.log("Diagnosis search field disabled = " + $("#diagnosisClaimSearch").prop("disabled"));
					if ($scope.diagnosisClaimMdcdSearch != "" && $scope.diagnosisClaimMdcdSearch != void(0) && !$("#diagnosisClaimMdcdSearch").prop("disabled")) {
						
						var selectedDiagArray = [];
						
						// get the number of lines in the diagnosis text area
						var lines = $('#diagnosisClaimMdcdSearch').val().trim().split('\n');
						console.log('# of diagnosis claim lines = ' + lines.length);
						
						// limit the number of lines a user can enter to 50
						if (lines.length > 50) {
							console.log('Diagnosis count is over 50 - invalid');
							// number of entries is over 50, so invalidate the the search
							$scope.claimsSearchMdcdForm.diagnosisClaimMdcdSearch.$setValidity('diaglineserror', false);
						} else {
							console.log('Diagnosis count is under 50 - valid');
							
							// number of entries is under 50, so validate the search
							$scope.claimsSearchMdcdForm.diagnosisClaimMdcdSearch.$setValidity('diaglineserror', true);
							
							// build Diagnosis object for REST request
							for (i = 0; i < lines.length; i++) {
								
								var diagObj = {};
									diagObj.code = lines[i];
									selectedDiagArray.push(diagObj);
							}
						}
						
						console.log('Selected Diagnosis Array = ' + JSON.stringify(selectedDiagArray));
						claimsSearchObj.diagnosises = selectedDiagArray;
						
					}  else {
						claimsSearchObj.diagnosises = null;
						
						// listing no diagnosis codes is valid, so set validity to true
						$scope.claimsSearchMdcdForm.diagnosisClaimMdcdSearch.$setValidity('diaglineserror', true);
					}
						
					//if ($scope.claimsFormMdcdState != void(0) && $scope.claimsFormMdcdState != null && $scope.claimsFormMdcdState != '' && $scope.claimsFormMdcdState.length > 0) {
						var stateArray = [];
						var stateListToUse = $scope.claimsFormMdcdStateList;
						if ($scope.claimsFormMdcdState != void(0) && $scope.claimsFormMdcdState != null && $scope.claimsFormMdcdState != '' && $scope.claimsFormMdcdState.length > 0){
							stateListToUse = $scope.claimsFormMdcdState;
						}
						for (i = 0; i < stateListToUse.length; i++) {
							var stateObj = {};
							stateObj.code = stateListToUse[i].lclState;
							stateArray.push(stateObj);
						}
						
						claimsSearchObj.mdcdStates = stateArray;
					//}
					console.log(claimsSearchObj.mdcdStates);
					//beneficiary multi-select
					if ($scope.claimsFormMdcdBene === void(0) || $scope.claimsFormMdcdBene === null || $scope.claimsFormMdcdBene === '') {
						claimsSearchObj.hicns = null;
						
						// listing no benes is valid, so set validity to true
						$scope.claimsSearchMdcdForm.claimsFormMdcdBene.$setValidity('hicnlineserror', true);
					} else {
						var selectedBeneArray = [];
						
						// get the number of lines in the text area
						var lines = $('#claimsFormMdcdBene').val().trim().split('\n');
						console.log('# of bene claim lines = ' + lines.length);
						
						// limit the number of lines a user can enter to 50
						if (lines.length > 50) {
							console.log('Bene count is over 50 - invalid');
							// number of entries is over 50, so invalidate the the search
							$scope.claimsSearchMdcdForm.claimsFormMdcdBene.$setValidity('hicnlineserror', false);
						} else {
							
							console.log('Bene count is under 50 - valid');
							
							// number of entries is under 50, so validate the search
							$scope.claimsSearchMdcdForm.claimsFormMdcdBene.$setValidity('hicnlineserror', true);
							
							// build HICN/MIB object for REST request
							for (i = 0; i < lines.length; i++) {
								
								var beneObj = {};
								    beneObj.hicn = lines[i];
								    selectedBeneArray.push(beneObj);
							}
						}
						
						console.log('Selected Bene Array = ' + JSON.stringify(selectedBeneArray));
						claimsSearchObj.hicns = selectedBeneArray;
					}
					
					claimsSearchObj.latest = "N";	
					claimsSearchObj.rrb = "N";
				
			}
			
//			console.log('claimsSearchObj = ' + JSON.stringify(claimsSearchObj));
			
			if ( (pSearchType == "main" && $scope.claimsSearchMdcdForm.$valid)) {
				//call the export search service to get the CSV file
//				detailsFactory.getSearchClaimsExport($scope.restURL, claimsSearchObj).success(function(data) {
					//construct the filename to use for export
					var claimsSearchFilename = $scope.providerPaneObj.providerName + "_" + moment(new Date()).format("YYYY-MM-DD") + "_claimsExport.csv";
					
					// encode claimsSearchObj
					var encodedObj = window.btoa(JSON.stringify(claimsSearchObj));
					
					//encode the filename
					var encodeFilename = window.btoa(claimsSearchFilename);
					$scope.openClaimsExport('LoadClaimsDocumentServlet?asrId=' + $scope.asrDetailsDbIdParam + '&userId=' + $scope.scopeUserId + '&searchType=latest' 
						+ '&fileName=' + encodeFilename + '&searchObj=' + encodedObj + '&programType=medicaid',
						"All Claims File - " +"MDCD Claims Search - End: " +claimsId);
								
					//hide claims Lines Panel Overlay
					$("#claimLinesMdcdTab").LoadingOverlay("hide");
					
			}  else {
				//hide claims Lines Panel Overlay
				$("#claimLinesMdcdTab").LoadingOverlay("hide");
				
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Please update all invalid form fields.', 'danger');
				
			}
	}

	$scope.resetClaimsSearch = function() {
		//clear the claims search form
		//to and from date
		$.datepicker._clearDate('#claimsFormStartDate');
		$.datepicker._clearDate('#claimsFormEndDate');
		$scope.claimsFormStartDate = null;
		$scope.claimsFormEndDate = null;
		
		//claim type
		$scope.claimsFormPartA = false; 
		$scope.claimsFormPartB = false;
		$scope.claimsFormPartD = false;
		$scope.claimsFormDME = false;
		
		//hicns
		$("#claimsFormBene option:selected").prop("selected", false);
		$scope.claimsFormBene = "";
				
		//set the all claims radio button as the default
		$('.all-claims-radio').prop("checked", true);
				
		// diagnosis
		$("#diagnosisClaimSearch option:selected").prop("selected", false);		
		$scope.diagnosisClaimSearch = "";
		
		//hcpcs/cpt field		
		$("#hcpcsClaimSearch option:selected").prop("selected", false);		
		$scope.hcpcsClaimSearch = "";
		
		// ICD Procedure		
		$("#icdClaimSearch option:selected").prop("selected", false);		
		$scope.icdClaimSearch = "";
		
		//set the form to Pristine
		$scope.claimsSearchForm.$setPristine();
		$scope.claimsSearchForm.$setUntouched();
		
		//set the date fields to valid
		$scope.claimsSearchForm.claimsFormStartDate.$setValidity('claimsdateerror', true);
		$scope.claimsSearchForm.claimsFormEndDate.$setValidity('claimsdateerror', true);
		$scope.claimsSearchForm.claimsFormStartDate.$setValidity('claimsdaterangeerror', true);
		$scope.claimsSearchForm.claimsFormEndDate.$setValidity('claimsdaterangeerror', true);
		
		// set the beneficiary field to valid
		$scope.claimsSearchForm.claimsFormBene.$setValidity('claimsbeneerror', true);
		
		// set the diagnosis field to valid
		$scope.claimsSearchForm.diagnosisClaimSearch.$setValidity('diaglineserror', true);
		
		// set the hcpcs field to valid
		$scope.claimsSearchForm.hcpcsClaimSearch.$setValidity('hcpcserror', true);
		
		// set the icd field to valid
		$scope.claimsSearchForm.icdClaimSearch.$setValidity('icderror', true);
		
		// by default, user has not chosen a claim so invalidate form
//		$scope.claimsSearchForm.claimsFormPartA.$setValidity('claimstypeerror', false);
//		$scope.claimsSearchForm.claimsFormPartB.$setValidity('claimstypeerror', false);
//		$scope.claimsSearchForm.claimsFormPartD.$setValidity('claimstypeerror', false);
//		$scope.claimsSearchForm.claimsFormDME.$setValidity('claimstypeerror', false);	
		
		// enable all checkboxes
//		$("#claimsFormPartB").attr("disabled", false);
//		$("#claimsFormPartA").attr("disabled", false);
//		$("#claimsFormDME").attr("disabled", false);
//		$("#claimsFormPartD").attr("disabled", false);
		
		// set form to dirty to display error messages
//		$scope.claimsSearchForm.$setDirty();
				
	}
	$scope.resetClaimsSearchMdcd = function() {
		//clear the claims search form
		//to and from date
		$.datepicker._clearDate('#claimsFormMdcdStartDate');
		$.datepicker._clearDate('#claimsFormMdcdEndDate');
		$scope.claimsFormMdcdStartDate = null;
		$scope.claimsFormMdcdEndDate = null;
		
		//svc  cat
		$scope.claimsFormSvcCatInst = false; 
		$scope.claimsFormSvcCatProf = false;
		$scope.claimsFormSvcCatDrug = false;
		$scope.claimsFormSvcCatDental = false;
		$scope.claimsFormSvcCatDME = false;
		$scope.claimsFormSvcCatNC = false;
		$scope.claimsFormSvcCatOther = false;
		
		// svc subcat
		$scope.claimsFormSvcSubcatFFS = false;
		$scope.claimsFormSvcSubcatMCO = false;
		
		//state
		$scope.claimsFormMdcdState = false;
		$("#claimsFormMdcdState option:selected").prop("selected", false);
		
		//hicns
		$("#claimsFormMdcdBene option:selected").prop("selected", false);
		$scope.claimsFormMdcdBene = "";
				
		//set the all claims radio button as the default
		$('.all-claims-radio').prop("checked", true);
				
		// diagnosis
		$("#diagnosisClaimMdcdSearch option:selected").prop("selected", false);		
		$scope.diagnosisClaimMdcdSearch = "";
		
		//hcpcs/cpt field		
		$("#hcpcsClaimMdcdSearch option:selected").prop("selected", false);		
		$scope.hcpcsClaimMdcdSearch = "";
		
		// ICD Procedure		
		$("#icdClaimMdcdSearch option:selected").prop("selected", false);		
		$scope.icdClaimMdcdSearch = "";
		
		//set the form to Pristine
		$scope.claimsSearchMdcdForm.$setPristine();
		$scope.claimsSearchMdcdForm.$setUntouched();
		//$scope.claimsSearchMdcdForm.$setValidity();
		
		//set the date fields to valid
		$scope.claimsSearchMdcdForm.claimsFormMdcdStartDate.$setValidity('claimsdateerror', true);
		$scope.claimsSearchMdcdForm.claimsFormMdcdEndDate.$setValidity('claimsdateerror', true);
		$scope.claimsSearchMdcdForm.claimsFormMdcdStartDate.$setValidity('claimsdaterangeerror', true);
		$scope.claimsSearchMdcdForm.claimsFormMdcdEndDate.$setValidity('claimsdaterangeerror', true);
		
		// set the beneficiary field to valid
		$scope.claimsSearchMdcdForm.claimsFormMdcdBene.$setValidity('hicnlineserror', true);
		
		// set the diagnosis field to valid
		$scope.claimsSearchMdcdForm.diagnosisClaimMdcdSearch.$setValidity('diaglineserror', true);
		
		// set the hcpcs field to valid
		$scope.claimsSearchMdcdForm.hcpcsClaimMdcdSearch.$setValidity('hcpcserror', true);
		
		// set the icd field to valid
		$scope.claimsSearchMdcdForm.icdClaimMdcdSearch.$setValidity('icderror', true);
		

				
	}
	// this function shows the edits details modal
	$scope.showEditDetails = function(pEditName) {
		console.log('showEditDetails - Edit Name = ' + pEditName);
		
		//show modal body overlay
		$("#editDetailsModalBody").LoadingOverlay("show");
		
		$("#editDetailsModalTable").bootstrapTable({});
		
		// show the editDetails modal
		$("#editDetailsModal").modal("show");
		
		// all the web service to get edit details
		detailsFactory.getEditDetails($scope.restURL, pEditName, $scope.scopeUserId).success(function(data) {	
			// populate the edit details table
			$("#editDetailsModalTable").bootstrapTable('load', data.activeEditInfos);
			
			// hide modal body overlay
			$("#editDetailsModalBody").LoadingOverlay("hide");
		}).error(function(data, status) {
			console.log('Edit Details REST Error:' + status);
			
			// hide modal body overlay
			$("#editDetailsModalBody").LoadingOverlay("hide");
			
			//alert('Error:  A Lead was not created due to ' + status);
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Cannot retrieve edit details information due to ' + status, 'danger');
		});
	}

	$scope.checkClaimType = function() {
		console.log("Inside checkClaimType function.");
		
		//validate that the user has chosen a claim type
		if (($scope.claimsFormPartA === false || $scope.claimsFormPartA === void(0)) && ($scope.claimsFormPartB === false || $scope.claimsFormPartB === void(0)) 
				&& ($scope.claimsFormDME === false || $scope.claimsFormDME === void(0)) && ($scope.claimsFormPartD === false || $scope.claimsFormPartD === void(0))
				&& $scope.claimsSearchForm.$dirty) {
			
			console.log('Form is dirty and no claim type has been chosen');
			
			// user has not chosen a claim, so invalidate form
			$scope.claimsSearchForm.claimsFormPartA.$setValidity('claimstypeerror', false);
			$scope.claimsSearchForm.claimsFormPartB.$setValidity('claimstypeerror', false);
			$scope.claimsSearchForm.claimsFormPartD.$setValidity('claimstypeerror', false);
			$scope.claimsSearchForm.claimsFormDME.$setValidity('claimstypeerror', false);	
			
		} else if (($scope.claimsFormPartA === true || $scope.claimsFormPartB === true || $scope.claimsFormDME === true || $scope.claimsFormPartD === true)
				&& $scope.claimsSearchForm.$dirty) {
			console.log('Form is dirty, but claims have been chosen');
			
			// user chose claim, so validate form
			$scope.claimsSearchForm.claimsFormPartA.$setValidity('claimstypeerror', true);
			$scope.claimsSearchForm.claimsFormPartB.$setValidity('claimstypeerror', true);
			$scope.claimsSearchForm.claimsFormPartD.$setValidity('claimstypeerror', true);
			$scope.claimsSearchForm.claimsFormDME.$setValidity('claimstypeerror', true);
		}
		
		// validate based requirements for CM-3472
		// if Part D is checked, disable A, B, DME
		if ($scope.claimsFormPartD === true) {
											
			$scope.disablePartA = true;
			$scope.disablePartB = true;
			$scope.disableDme = true;	
			
		} else if ($scope.claimsFormPartA === true || $scope.claimsFormPartB === true || $scope.claimsFormDME === true) {
			// if Part A, B, or DME is selected, disable Part D			
			$scope.disablePartD = true;
		} else {
			// check the radio button value
			//console.log('radio button value = ' + $scope.radioResult);
			
			if($scope.radioResult == 'riskClaims') {
				console.log('radio selected = Claims at Risk');
				
				// initialize the radio buttons
				$scope.hideShowClaimCheckVals('claimsAtRiskVal');
			}
			else if($scope.radioResult == 'phase1Claims') {
				console.log('radio selected = Claims at Risk');
				
				// initialize the radio buttons
				$scope.hideShowClaimCheckVals('phase1Claims');
			} else {
				console.log('radio selected = All Claims');
				
				// initialize the radio buttons
				$scope.hideShowClaimCheckVals('allClaimsVal');
			}
		}
	}

	// this function opens the asr details screen in a separate window
	$scope.asrDetailWindowOpen = function(pAsrId) { 
		$window.open("#/ASRDetails?asrDetailsParam=" + pAsrId+"&viewParam="+'medicare' );
	}

	// get all the claims when user clicks on claims denied column value
	$scope.showClaimsDenied = function(pEditName) {
		console.log('showClaimsDenied - Edit Name = ' + pEditName);
				
		// initialize the claims denied table
		$('#claimsDeniedTable').bootstrapTable({});		
		
		// show the popup window		
		$("#claimsDeniedModal").modal("show");
		
		// show the modal body overlay
		$("#claimsDeniedModalBody").LoadingOverlay("show");
		
		// get the all claims info from the web services
		detailsFactory.getEditAllClaims($scope.restURL, pEditName, $scope.scopeUserId, $scope.providerNPI).success(function(data) {	
			// load the table			
			$("#claimsDeniedTable").bootstrapTable('load', data.editClaims);
			
			//hide modal overlay
			$("#claimsDeniedModalBody").LoadingOverlay("hide");
			
		}).error(function(data, status) {
			console.log('Edit Details REST Error:' + status);
			
			//hide modal overlay
			$("#claimsDeniedModalBody").LoadingOverlay("hide");
			
			//alert('Error:  A Lead was not created due to ' + status);
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Cannot retrieve all claims information due to ' + status, 'danger');
		});
	}

	// user clicked the edit info link on the edits tab
	$scope.editInfoBtnClick = function() {
		console.log('editInfoBtnClick function called');
		
		//initialize the active and inactive table			
		$('#activeEditInfoTable').bootstrapTable({});		
		$('#inactvEditInfoTable').bootstrapTable({});
				
		// show the edit info modal window
		$("#editInfoModal").modal("show");
		
		// show the modal body overlay
		$("#editInfoModalBody").LoadingOverlay("show");
		
		// get the all claims info from the web services
		detailsFactory.getEditInfo($scope.restURL, $scope.scopeUserId).success(function(data) {	
			
			// populate the active tab
			$("#activeEditInfoTable").bootstrapTable('load', data.activeEditInfos);
			
			//populate the inactive tab
			$("#inactvEditInfoTable").bootstrapTable('load', data.inactiveEditInfos);
						
			// hide the modal body overlay
			$("#editInfoModalBody").LoadingOverlay("hide");
			
		}).error(function(data, status) {
			console.log('Edit Info REST Error:' + status);
			
			// hide the modal body overlay
			$("#editInfoModalBody").LoadingOverlay("hide");
			
			//alert('Error:  A Lead was not created due to ' + status);
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Cannot retrieve edit information due to ' + status, 'danger');
		});
	}
	
	
	// this function loads the data required by the ASRRiskScoreExplainability tab
	$scope.showASRRiskScoreExplainabilityTab = function() {
		
		console.log('Inside showASRRiskScoreExplainabilityTab function');
		console.log("length", $scope.providerPaneObj.contribScores.length);
	}
	
	// this function loads the data required by the priority score tab
	$scope.showPriorScore = function() {
		console.log('Inside showPriorScore function');
		//TO-DO
		$("#priorScoreTab").LoadingOverlay("show");
		
		//call the getASRDetailsData in the details factory
		detailsFactory.getASRDetailsData($scope.restURL, $scope.asrDetailsParam, "PRSCORE", $scope.scopeUserId, $scope.activeASRTab )
		.success(function(data) {
		
			// populate the priority score table, footer and headers							
			$scope.priorActionabilityAsr = data.responseData.provider.actionability;
			$scope.actnTimelinessAsr = data.responseData.provider.timeliness;
			$('#priorScoreTable').bootstrapTable('load', data.responseData.provider.priorityCriteria);
			$("#footerTd").html("Priority Score = " + data.responseData.provider.priorityScoreNum);
			
			// hide the modal tab overlay
			$("#priorScoreTab").LoadingOverlay("hide");
		}).catch(function(err){ 
			// hide the modal tab overlay
			$("#priorScoreTab").LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Priority Score data is currently not available due to ' + err.status, 'danger');
		});
	
		//log user activity - removed, this is done by web services.
		//$scope.trackUserActivity('priorScoreTab', null);
	}


	// this function loads the data required by the tpe tab
	$scope.loadTpeData = function() {
		console.log('Inside loadTpeData function');
		
		// show the tab overlay
		$("#tpeTab").LoadingOverlay("show");
		
		// call the factory method to get the tpe data
		detailsFactory.getTpeData($scope.restURL, $scope.asrDetailsDbIdParam, $scope.scopeUserId).then(function(response) {			
			
			$("#tpeTable").bootstrapTable('load', response.data.responseData.tpes);
			
			// hide the modal tab overlay
			$("#tpeTab").LoadingOverlay("hide");
		}).catch(function(err){ 
			// hide the modal tab overlay
			$("#tpeTab").LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> TPE data is currently not available due to ' + err.status, 'danger');
		});
		
		//log user activity
		$scope.trackUserActivity('TPE', null);
	}

	//this function validates date ranges for the claims search form
	$scope.checkDtRangeMdcd = function() {
		
		console.log('claimsFormMdcdStartDate = ' + $scope.claimsFormMdcdStartDate + ', claimsFormMdcdEndDate = ' + $scope.claimsFormMdcdEndDate);
		
		//check to make sure the start date is smaller than the end date
		if ($scope.claimsFormMdcdStartDate != void(0) && $scope.claimsFormMdcdStartDate != null && $scope.claimsFormMdcdEndDate != void(0) && $scope.claimsFormMdcdEndDate != null) {
			
			if (new Date($scope.claimsFormMdcdStartDate) > new Date($scope.claimsFormMdcdEndDate)) {
				console.log('Start date ' + $scope.claimsFormMdcdStartDate + ' is greater than End date ' + $scope.claimsFormMdcdEndDate);
				$scope.claimsSearchMdcdForm.claimsFormMdcdStartDate.$setValidity('claimsdateerror', false);
				$scope.claimsSearchMdcdForm.claimsFormMdcdEndDate.$setValidity('claimsdateerror', false);
			} else {
				$scope.claimsSearchMdcdForm.claimsFormMdcdStartDate.$setValidity('claimsdateerror', true);
				$scope.claimsSearchMdcdForm.claimsFormMdcdEndDate.$setValidity('claimsdateerror', true);
			}
			
			//end date and start date cannot be more than a year from the current date
			var todayDate = moment(new Date()).format("YYYY-MM-DD");
			console.log("todayDate = " + todayDate);
			var todayPlusOneDay = moment(todayDate).add(1,'days').format("YYYY-MM-DD");
			var todayMinusOneYearDate = moment(todayDate).subtract(366,'days').format("YYYY-MM-DD");
			console.log("todayMinusOneYearDate = " + todayMinusOneYearDate);
			var startDateMoment = moment($scope.claimsFormMdcdStartDate).format("YYYY-MM-DD");
			console.log("startDateMoment = " + startDateMoment);
			var endDateMoment = moment($scope.claimsFormMdcdEndDate).format("YYYY-MM-DD");
			console.log("endDateMoment = " + endDateMoment);
			
			console.log("Start date within range = " + moment(startDateMoment).isBetween(todayMinusOneYearDate, todayPlusOneDay));
			console.log("End date within range = " + moment(endDateMoment).isBetween(todayMinusOneYearDate, todayPlusOneDay));
			
			if (moment(startDateMoment).isBetween(todayMinusOneYearDate, todayPlusOneDay) && moment(endDateMoment).isBetween(todayMinusOneYearDate, todayPlusOneDay)) {
				$scope.claimsSearchMdcdForm.claimsFormMdcdStartDate.$setValidity('claimsdaterangeerror', true);
				$scope.claimsSearchMdcdForm.claimsFormMdcdEndDate.$setValidity('claimsdaterangeerror', true);
			} else {
				console.log("Date range is not within the past 365 days.");
				$scope.claimsSearchMdcdForm.claimsFormMdcdStartDate.$setValidity('claimsdaterangeerror', false);
				$scope.claimsSearchMdcdForm.claimsFormMdcdEndDate.$setValidity('claimsdaterangeerror', false);				
			}
		}
	}

	//populate the claim lines tab when clicked on by the user
	$scope.claimLinesSelectClick = function() {
		console.log('Inside claimLinesSelectClick function.' + JSON.stringify($scope.claimTypeSelect));
		
		var selectValStr = JSON.stringify($scope.claimTypeSelect).replace(/['"]+/g, '');
		console.log('selectValStr = ' + selectValStr);	
		var loadPageUniqueId = crypto.randomUUID();
		if (selectValStr == 'Select Claim Lines Type:') {
			//do nothing - no need to search for claim lines
		} else {
			
			//show a tab overlay to the notes tab 		
			$("#claimLinesTab").LoadingOverlay("show");
			
			//broadcast this event to the broadcastSlaMetrics listener
			$rootScope.$broadcast('broadcastSlaMetrics', {message:"TabDataClaims Load - Start: " + loadPageUniqueId, userId: ""});
			
			//make a call to the getTabClaimsData factory method to get the Edits data
			detailsFactory.getTabClaimsData($scope.restURL, $scope.asrDetailsParam, $scope.scopeUserId).success(function(data) {
				console.log('getTabClaimsData REST service call successful. edits = ' + JSON.stringify(data.responseData));
				//initialize the claimLinesPartATable bootstrap table
				$('#claimLinesPartATable').bootstrapTable({});
				//initialize the claimLinesPartBTable bootstrap table
				$('#claimLinesPartBTable').bootstrapTable({});
				//initialize the claimLinesDMETable bootstrap table
				$('#claimLinesDMETable').bootstrapTable({});
				
				//check to see which option was selected by the user
				if (selectValStr === 'partA') {
					console.log('Claims Line dropdown value partA selected.');
					
					//load the data in the claimLinesPartATable
					$('#claimLinesPartATable').bootstrapTable('load', data.responseData.claimLines.partAItems);	
					
				} else if (selectValStr === 'partB') {
					console.log('Claims Line dropdown value partB selected.');
					
					//load the data in the claimLinesPartBTable
					$('#claimLinesPartBTable').bootstrapTable('load', data.responseData.claimLines.partBItems);	
					
				} else if (selectValStr === 'DME') {
					console.log('Claims Line dropdown value DME selected.');
					
					//load the claimLinesDMETable bootstrap table
					$('#claimLinesDMETable').bootstrapTable('load', data.responseData.claimLines.partDMEItems);
				}
							
				//show a tab overlay to the notes tab 		
				$("#claimLinesTab").LoadingOverlay("hide");
				//broadcast this event to the broadcastSlaMetrics listener
				$rootScope.$broadcast('broadcastSlaMetrics', {message:"TabDataClaims Load - End: " + loadPageUniqueId, userId: ""});
				
			}).error(function(data, status) {
				console.log('getTabClaimsData REST Error:' + status);	
				//show a tab overlay to the claims tab 		
				$("#claimLinesTab").LoadingOverlay("hide");
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Claims table data not available due to ' + status, 'danger');
			});
		}

	};

	//populate the notes tab when clicked on by the user
	$scope.fpsNotesTabClick = function() {
//		console.log('Inside fpsNotesTabClick function.' + JSON.stringify($scope.notesObj));
		
		//attach a tab overlay to the notes tab 		
		$("#notesTabPanelBody").LoadingOverlay("show");
		
		//initialize the notes table
		$('#notesTable').bootstrapTable({});
		
		//make a call to the getTabNotesData factory method to get the notes data
		detailsFactory.getTabNotesData($scope.restURL, $scope.asrDetailsParam, $scope.scopeUserId).success(function(data) {
			console.log('fpsNotesTabClick REST sercice call successful.');
			
			//get the notes Object from the Response
			//$scope.notesObj = $scope.responseData.notes;			
			$('#notesTable').bootstrapTable('load', data.responseData.notes);
			
			//hide the tab overlay to the notes tab 		
			$("#notesTabPanelBody").LoadingOverlay("hide");
			
		}).error(function(data, status) {
			console.log('getTabNotesData REST Error:' + status);	
			//hide the tab overlay to the notes tab 		
			$("#notesTabPanelBody").LoadingOverlay("hide");
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Notes table data not loaded due to ' + status, 'danger');
		});
	};

	//populate the leads/investigations tab when clicked on by the user
	$scope.fpsLeadsTabClick = function() {
		console.log('Inside fpsLeadsTabClick function.');
		
		//present the leads data by calling the refreshLeadsTableData() function
		//pass the userId param since it is a tab click and not a table refresh
		refreshLeadsTableData($scope.scopeUserId);		
	};
//populate the leads/investigations tab when clicked on by the user
	$scope.fpsLeadsMdcdTabClick = function() {
		console.log('Inside fpsLeadsMdcdTabClick function.');
		
		//present the leads data by calling the refreshLeadsMdcdTableData() function
		//pass the userId param since it is a tab click and not a table refresh
		refreshLeadsMdcdTableData($scope.scopeUserId);		
	};
	//user has chosen to view the Part D Claim Lines tab
	$scope.partDClaimLinesTabClick = function(pClickedObjType) {
		console.log("Inside the partDClaimLinesTabClick function. pClickedObjType = " + pClickedObjType);
		
		var partDNPI;
		var partDModelId;
		
		if (pClickedObjType == "alert") {
			//show the tab overlay 
			$("#partdClaimLinesTab").LoadingOverlay("show");
			
			//initialize the table
			$('#partdClaimLinesTable').bootstrapTable({});
			
			//set the NPI and Model Id from the value set when the modal was opened
			partDNPI = $scope.modelNpiNumber;
			partDModelId = $scope.modelNumber;
			
		} else if (pClickedObjType == "drill") {
			$("#partdClaimLinesDrillTab").LoadingOverlay("show");
			
			//initialize the table
			$('#partdClaimLinesDrillTable').bootstrapTable({});
			
			//set the NPI and Model Id from the value set when the modal was opened
			partDNPI = $scope.rptCardNpi;
			partDModelId = $scope.rptCardModelId;
		}
		
		//make a call to get the part d claim lines data
		detailsFactory.getPartDClaimLinesData($scope.restURL, partDNPI, partDModelId, $scope.scopeUserId).success(function(data) {
			
			if (pClickedObjType == "alert") {
				//populate the rules based table					
				$('#partdClaimLinesTable').bootstrapTable('load', data.response);
				
				//hide the tab overlay 
				$("#partdClaimLinesTab").LoadingOverlay("hide");
			} else if (pClickedObjType == "drill") {
				//populate the rules based table					
				$('#partdClaimLinesDrillTable').bootstrapTable('load', data.response);
				
				//hide the tab overlay 
				$("#partdClaimLinesDrillTab").LoadingOverlay("hide");
			}
		
		}).error(function(data, status) {
			console.log('getPartDClaimLinesData REST Error:' + status);	
			//hide tab overlay
			$("#partdClaimLinesTab").LoadingOverlay("hide");
			$("#partdClaimLinesDrillTab").LoadingOverlay("hide");
			
			//show growl message
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Part D Claim Lines table data not available due to ' + status, 'danger');
		});

	} 

	$scope.fpsEditsTabClick = function() {
		
		//show a tab overlay to the edits tab 		
		$("#fpsEditsTab").LoadingOverlay("show");
		
		//initialize the table
		$('#fpsEditsTable').bootstrapTable({});
		
		//make a call to the getTabEditsData factory method to get the Edits data
		detailsFactory.getTabEditsData($scope.restURL, $scope.asrDetailsParam, $scope.scopeUserId).success(function(data) {
			console.log('tabDataEdits REST sercice call successful. edits = ' + JSON.stringify(data.responseData.edits));
			
			//refresh the edits table
			$('#fpsEditsTable').bootstrapTable('load', data.responseData.edits);
			
			//hide a tab overlay to the edits tab 		
			$("#fpsEditsTab").LoadingOverlay("hide");
		}).error(function(data, status) {
			console.log('tabDataEdits REST Error:' + status);	
			//show a tab overlay to the edits tab 		
			$("#fpsEditsTab").LoadingOverlay("hide");
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Edits table data not available due to ' + status, 'danger');
		});
	    
	};

	// handle the user's request to view Legacy FPS Info (Leads)
	$scope.viewLegacyFpsInfo = function(pleadId, pAssignedTo, pUcmId) {
		console.log("Inside viewLegacyFpsInfo function. LeadId = " + pleadId + ", Assigned To = " + pAssignedTo + ", pUcmId = " + pUcmId);
		
		// display the modal window
		$("#legacyFpsInfoModal").modal("show");
    	
		// destroy and initiate the modal tables
//		$("#legacyFpsActivityTable").bootstrapTable('destroy');
		$("#legacyFpsActivityTable").bootstrapTable({});
		
//		$("#legacyFpsRulingTable").bootstrapTable('destroy');
		$("#legacyFpsRulingTable").bootstrapTable({});
		
//		$("#legacyFpsActionTable").bootstrapTable('destroy');
		$("#legacyFpsActionTable").bootstrapTable({});
		
//		$("#legacyFpsBarToActionTable").bootstrapTable('destroy');
		$("#legacyFpsBarToActionTable").bootstrapTable({});
		
//		$("#legacyFpsRateModelTable").bootstrapTable('destroy');
		$("#legacyFpsRateModelTable").bootstrapTable({});
		
		//show full page overlay
		$.LoadingOverlay("show");
		
		//call the web service to populate the tables in the modal
		detailsFactory.getUcmLeadData($scope.restURL, $scope.asrDetailsDbIdParam, pleadId).success(function(data) {	
			console.log('getUcmLeadData REST service call successful. Populate Legacy FPS Info to the user');
			
			// disable the Activity tab if no data exists
			if (data.responseData.leads[0].ucmActivities != void(0) && data.responseData.leads[0].ucmActivities != null 
					&& data.responseData.leads[0].ucmActivities.length > 0) {
				//enable the tab 
				$('#legacyFpsActivityTabItem').removeClass('disabled');				
				$('#legacyFpsActivityTabLink').css('cursor', 'pointer');
				$('#legacyFpsActivityTabLink').css('pointer-events', 'auto');
				$('#legacyFpsActivityTabLink').attr('data-toggle','tab');
			} else {
				//disable the tab
				$('#legacyFpsActivityTabItem').addClass('disabled');
				//$('#legacyFpsActivityTabItem').removeClass('active');
				$('#legacyFpsActivityTabLink').css('cursor', 'not-allowed');
				$('#legacyFpsActivityTabLink').css('pointer-events', 'none');
				$('#legacyFpsActivityTabLink').removeAttr('data-toggle');				
			}
			
			// disable the Ruling tab if no data exists
			if (data.responseData.leads[0].ucmRulings != void(0) && data.responseData.leads[0].ucmRulings != null 
					&& data.responseData.leads[0].ucmRulings.length > 0) {
				//enable the tab
				$('#legacyFpsRulingTabItem').removeClass('disabled');
				$('#legacyFpsRulingTabLink').css('cursor', 'pointer');
				$('#legacyFpsRulingTabLink').css('pointer-events', 'auto');
				$('#legacyFpsRulingTabLink').attr('data-toggle','tab');
			} else {
				//disable the tab
				$('#legacyFpsRulingTabItem').addClass('disabled');
				//$('#legacyFpsRulingTabItem').removeClass('active');
				$('#legacyFpsRulingTabLink').css('cursor', 'not-allowed');
				$('#legacyFpsRulingTabLink').css('pointer-events', 'none');
				$('#legacyFpsRulingTabLink').removeAttr('data-toggle');				
			}
			
			// disable the Action tab if no data exist
			if (data.responseData.leads[0].ucmActions != void(0) && data.responseData.leads[0].ucmActions != null 
					&& data.responseData.leads[0].ucmActions.length > 0) {
				//enable the tab 
				$('#legacyFpsActionTabItem').removeClass('disabled');
				$('#legacyFpsActionTabLink').css('cursor', 'pointer');
				$('#legacyFpsActionTabLink').css('pointer-events', 'auto');
				$('#legacyFpsActionTabLink').attr('data-toggle','tab');
			} else {
				//disable the tab
				$('#legacyFpsActionTabItem').addClass('disabled');
				//$('#legacyFpsActionTabItem').removeClass('active');
				$('#legacyFpsActionTabLink').css('cursor', 'not-allowed');
				$('#legacyFpsActionTabLink').css('pointer-events', 'none');
				$('#legacyFpsActionTabLink').removeAttr('data-toggle');				
			}
			
			// disable the Barrier to Action
			if (data.responseData.leads[0].ucmBarriers != void(0) && data.responseData.leads[0].ucmBarriers != null 
					&& data.responseData.leads[0].ucmBarriers.length > 0) {
				//enable the tab 
				$('#legacyFpsBarToActionTabItem').removeClass('disabled');
				$('#legacyFpsBarToActionTabLink').css('cursor', 'pointer');
				$('#legacyFpsBarToActionTabLink').css('pointer-events', 'auto');
				$('#legacyFpsBarToActionTabLink').attr('data-toggle','tab');
			} else {
				//disable the tab
				$('#legacyFpsBarToActionTabItem').addClass('disabled');
				//$('#legacyFpsBarToActionTabItem').removeClass('active');
				$('#legacyFpsBarToActionTabLink').css('cursor', 'not-allowed');
				$('#legacyFpsBarToActionTabLink').css('pointer-events', 'none');
				$('#legacyFpsBarToActionTabLink').removeAttr('data-toggle');				
			}
			
			// disable the Rate Model tab if no data exists
			if (data.responseData.leads[0].ucmModelRatings != void(0) && data.responseData.leads[0].ucmModelRatings != null 
					&& data.responseData.leads[0].ucmModelRatings.length > 0) {
				//enable the tab tab
				$('#legacyFpsRateModelTabItem').removeClass('disabled');
				$('#legacyFpsRateModelTabLink').css('cursor', 'pointer');
				$('#legacyFpsRateModelTabLink').css('pointer-events', 'auto');
				$('#legacyFpsRateModelTabLink').attr('data-toggle','tab');
			} else {
				//disable the tab
				$('#legacyFpsRateModelTabItem').addClass('disabled');
				//$('#legacyFpsRateModelTabItem').removeClass('active');
				$('#legacyFpsRateModelTabLink').css('cursor', 'not-allowed');
				$('#legacyFpsRateModelTabLink').css('pointer-events', 'none');
				$('#legacyFpsRateModelTabLink').removeAttr('data-toggle');				
			}
			
			//populate the tables in the modal
			$('#legacyFpsActivityTable').bootstrapTable('load', data.responseData.leads[0].ucmActivities);
			$('#legacyFpsRulingTable').bootstrapTable('load', data.responseData.leads[0].ucmRulings);
			$('#legacyFpsActionTable').bootstrapTable('load', data.responseData.leads[0].ucmActions);
			$('#legacyFpsBarToActionTable').bootstrapTable('load', data.responseData.leads[0].ucmBarriers);
			$('#legacyFpsRateModelTable').bootstrapTable('load', data.responseData.leads[0].ucmModelRatings);
			
			//hide full page overlay
			$.LoadingOverlay("hide");
			
		}).error(function(data, status) {
			console.log('viewLead REST Error:' + status);
			
			//hide full page overlay
			$.LoadingOverlay("hide");
			
			//alert('Error:  A Lead was not created due to ' + status);
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Cannot retrieve legacy FPS information due to ' + status, 'danger');
		});
		
		
	}


	//handle the user's request to view an Investigation
	$scope.viewLead = function(pleadId, pAssignedTo, pUcmId) {
		console.log("Inside viewLead function. LeadId = " + pleadId + ", Assigned To = " + pAssignedTo + ", pUcmId = " + pUcmId);
		
		//check to see if the user chose to view a UCM or FPS based lead
		if (pUcmId != void(0) && pUcmId != null) {
			console.log("User is attempting to view a UCM or MPP based Lead/Investigation. Type = " + pUcmId.substring(0,3));
			
			//connected to ng-show directive for Investigations tabs
			$scope.showMppInv = true;
			
			//if investigation is of type MPP, then only show the Actions tab
			if (pUcmId.substring(0,3) == 'MPP') {
				
				//set the hide/show of the mpp tabs
				$scope.showMppInv = false;
				
				//remove active from all other tabs
				$('#ucmActivTab').removeClass("active");
				$('#ucmActivitiesTab').removeClass("active");
				$('#ucmRulTab').removeClass("active");
				$('#ucmRulingTab').removeClass("active");
				$('#ucmBarTab').removeClass("active");
				$('#ucmBarrierToActionTab').removeClass("active");
				$('#ucmRateTab').removeClass("active");
				$('#ucmRateModelTab').removeClass("active");
				$('#ucmActionsTab').removeClass("active").removeClass("fade");		
				//set activity tab as the active tab
				$('#ucmActivTab').addClass("active");
				$('#ucmActivitiesTab').addClass("active").removeClass("fade")	
				$('#ucmActivitiesTabTable').bootstrapTable({});
				
				
			} else {
				//remove the active class from the actions tab
				//set the action tab as the active tab
				$('#ucmActnTab').removeClass("active");
				$('#ucmActionsTab').removeClass("active");
				$('#ucmRulTab').removeClass("active");
				$('#ucmRulingTab').removeClass("active");
				$('#ucmBarTab').removeClass("active");
				$('#ucmBarrierToActionTab').removeClass("active");
				$('#ucmRateTab').removeClass("active");
				$('#ucmRateModelTab').removeClass("active");
				//set activity tab as the active tab
				$('#ucmActivTab').addClass("active");
				$('#ucmActivitiesTab').addClass("active").removeClass("fade");
				
				//initialize the tables in the modal
				$('#ucmActivitiesTabTable').bootstrapTable({});
				$('#ucmRulingTabTable').bootstrapTable({});					
				$('#ucmBarrierToActionTabTable').bootstrapTable({});	
				$('#ucmRateModelTabTable').bootstrapTable({});	
			}		
			
			//initialize the actions table			
			$('#ucmActionsTabTable').bootstrapTable({});
			
			//show the ucmCaseDataModal Modal Window
			$("#ucmCaseDataModal").modal("show");
			
			//show full page overlay
			$.LoadingOverlay("show");
			
			//call the web service to populate the tables in the modal
			detailsFactory.getUcmLeadData($scope.restURL, $scope.asrDetailsDbIdParam, pleadId).success(function(data) {	
				console.log('getUcmLeadData REST service call successful.');
				
				//populate the tables in the modal
				if (pUcmId.substring(0,3) == 'MPP') {
					//only load the actions/activities table when the investigation is of type MPP
					$('#ucmActionsTabTable').bootstrapTable('load', data.responseData.leads[0].ucmActions);
					$('#ucmActivitiesTabTable').bootstrapTable('load', data.responseData.leads[0].ucmActivities);
				} else {
					$('#ucmActivitiesTabTable').bootstrapTable('load', data.responseData.leads[0].ucmActivities);
					$('#ucmRulingTabTable').bootstrapTable('load', data.responseData.leads[0].ucmRulings);
					$('#ucmActionsTabTable').bootstrapTable('load', data.responseData.leads[0].ucmActions);
					$('#ucmBarrierToActionTabTable').bootstrapTable('load', data.responseData.leads[0].ucmBarriers);
					$('#ucmRateModelTabTable').bootstrapTable('load', data.responseData.leads[0].ucmModelRatings);
				}				
				
				//hide full page overlay
				$.LoadingOverlay("hide");
				
			}).error(function(data, status) {
				console.log('viewLead REST Error:' + status);
				
				//hide full page overlay
				$.LoadingOverlay("hide");
				
				//alert('Error:  A Lead was not created due to ' + status);
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Cannot retrieve lead information due to ' + status, 'danger');
			});
			
			
		} else {
			console.log("User is attempting to view a FPS based Lead/Investigation");	
		}
		
		//log user activity
		$scope.trackUserActivity('BPMINVEST', null);
	}

	// this function handles the user clicking the Google button click
	$scope.googleMapBtnClick = function() {
		console.log('Google Maps function');
		
		// show the modal window - modal open event will trigger map rendering
		$('#asrGoogleMapModal').modal('show');
	}
	
	$scope.showAsrGoogleMap = function() {
		//load the google map
		detailsFactory.getAsrMapsInfo($scope.restURL, $scope.asrDetailsDbIdParam, $scope.scopeUserId, $scope.asrMapResultsIndex).then(function(response) {
			$scope.providerAddrObj = response.data.responseData.provider.address;
			$scope.beneArrayObj = response.data.responseData.provider.benes;
			
			console.log("Provider Address = " + JSON.stringify($scope.providerAddrObj));
			
			//call the displayAsrMap() java script method
			displayAsrMap($scope.providerAddrObj, $scope.beneArrayObj, $scope.asrMapResultsIndex);
			
			//$("#googleMapsPanel").LoadingOverlay("hide");
		}).catch(function(err) {
			console.log('getAsrMapsInfo REST Error:' + err.data);
			//$("#googleMapsPanel").LoadingOverlay("hide");
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to retrieve maps data due to ' + err.data, 'danger');
		});
	}

	//the user clicked the Prioritize for UCM button on the details screen
	$scope.prioritizeUCMBtnClick = function() {
//		console.log('Inside prioritizeUCMBtnClick.');
		
		// set default to do not show tiger team zones	
		$scope.showPriorUcmZones = false;
		
		//first, check to see if the user is permitted to prioritize for UCM
		if($scope.rolesArray.indexOf("Admin") != -1  
				|| $scope.rolesArray.indexOf("Prioritize Sup") != -1
				|| ($scope.rolesArray.indexOf("MAC") != -1 && $scope.userAttrArray.indexOf('ASR Prioritization') != -1)) {
			
			// variable to allow/disallow prioritization
			var allowPrioritization = true;	
			var errorMsg = '';
			
			// check for PrioritizeSup role
			if ($scope.rolesArray.indexOf("Prioritize Sup") != -1) {
				
				// user has MEDIC jurisdiction - can only prioritize Part D ASRs
				if ($scope.scopeUserZone == 'MEDIC') {
					// note: there are 2 hasPartD flags. Use the provider scope value
					if ($scope.providerPaneObj.hasPartD == "N") {
						allowPrioritization = false;
						errorMsg = 'The prioritization of this ASR is not permitted because the ASR is not associated with Part D claims.';
					}
				} //else if ($scope.scopeUserZone != 'UPIC 1' && $sNotcope.scopeUserZone != 'UPIC 2' && $scope.scopeUserZone != 'UPIC 3' 
					//	&& $scope.scopeUserZone != 'UPIC 4' && $scope.scopeUserZone != 'UPIC 5') {
					
				//	allowPrioritization = false;
				//	errorMsg = 'You do not have the proper permissions to perform this action.';
				//}
				
				// check to see if user has the tiger team attribute
				/*if ($scope.userAttrArray.indexOf('CPI Assigned') != -1) {
					console.log('User is a Tiger Team member.');
					
					// show modal overlay
					$("#priorZonesSelect").LoadingOverlay("show");
					
					// set the variable used to hide/show the jurisdiction dropdown
					$scope.showPriorUcmZones = true;
					
					console.log("==>CPI Assigned " );
					
				}*/
			}
			
			
			
			if (allowPrioritization == true) {
				
				// FPS-5981 implementation 
				
				// call the refdata service to get the jurisdiction dropdown
				$("#priorZonesSelect").LoadingOverlay("show");
				detailsFactory.getPrioritizationZones($scope.restURL).then(function(response) {
					$scope.priorZonesOptions = response.data.zones;					
					// hide the modal body overlay
					$("#priorZonesSelect").LoadingOverlay("hide");
				}).catch(function(err){ 
					// hide the modal body overlay
					$("#priorZonesSelect").LoadingOverlay("hide");
					
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Proritize for UCM table could not be loaded due to ' + err.status, 'danger');
				});
				
				console.log("===> ", $scope.prioritizeForUCMTableData)
				// call the refdata service to get the jurisdiction dropdown
				$("#prioritizeUCMModal").LoadingOverlay("show");
				$("#prioritizeForUCMTable").bootstrapTable({});
				$("#prioritizeForUCMTable").bootstrapTable('load',$scope.prioritizeForUCMTableData );
				
				
				$("#prioritizeForUCMTableMDCD").bootstrapTable({});
				$("#prioritizeForUCMTableMDCD").bootstrapTable('load',$scope.prioritizeForUCMTableData );
				
				// check to see if user has the tiger team attribute
				if ($scope.userAttrArray.indexOf('CPI Assigned') != -1) {
					console.log('User is a Tiger Team member.');
					console.log('Show Jurisdiction Column');
					
				}else {
					// hide the zurisdiction column if the user is not belongs to CPI
					$('#prioritizeForUCMTable').bootstrapTable('hideColumn', 'zone');
					$("#prioritizeForUCMTable").parent().parent().parent().find(".fixed-table-toolbar").find(".columns").find("ul").find("label").find('input[data-field="zone"]').parent().hide();
				}
				// hide the modal body overlay
				$("#prioritizeUCMModal").LoadingOverlay("hide");				
				//user is authorized to prioritize for UCM, so show modal window asking the user to confirm submission and enter comments
				$("#prioritizeUCMModal").modal("show");
				// End 
				
			} else {
				// user not authorized to prioritize ASRs
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> ' + errorMsg, 'danger');
			}
				
		} else {
			//console.log('Logged-in user is not permitted to Prioritize for UCM');
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> You do not have the proper permissions to perform this action.', 'danger');
		}
		$("#modalPrioritizeUCMBtn").removeClass("disabled");
		$("#modalPrioritizeUCMBtn").prop("disabled", false);
	}

	//user clicked the Submit Prioritize for UCM button from the Prioritize for UCM modal window
	$scope.modalPrioritizeUCMBtnClick = function() {
		console.log('Inside modalPrioritizeUCMBtnClick.');
		var dataList = $scope.prioritizeForUCMTableData;
		
		var prioritiesArray = [];
		var exitFlag = false;
		
		console.log("====> dataList", dataList);
		if ($scope.activeASRTab == "medicaid"){
			for (x=0; x<dataList.length; x++) {
				var  counter = 0; // No jurisdication alerts
				var alertslen = dataList[x].alerts.length;
				for (y=0; y<alertslen; y++){
					if (dataList[x].alerts[y].disabled == "true"){
						counter++;
					}					
				}
				
				console.log("total alerts ->", alertslen);
				console.log("disabled alerts ->", counter);
				if (counter == alertslen && alertslen >0  ){
					showGrowl('<i aria-hidden=\'true\'></i> Prioritization to UCM can only be done for models that have alerted in a state(s) within your jurisdiction.', 'warning');
					return;
				}
				
			}
		}
		
		
		for (i=0; i<dataList.length; i++) {
			// check to see if user has the tiger team attribute
			var userZone = $scope.scopeUserZone;
			
			// Initialize Prioritization object
			var priorityObj = {};
			// Set the values for saving when priortize.
			priorityObj.asrDbId = dataList[i].asrptId;
			priorityObj.userId = $scope.scopeUserId;
			// set the zone to the current user's zone
			priorityObj.zone = userZone;
			priorityObj.comments =$sanitize( $('#commentsTextArea'+dataList[i].asrptId).val());	
			
			
			var __asrptId = dataList[i].asrptId;
			console.log("ASR ---",__asrptId);
			var tempalertsList = [];
			
			var selectedStates = $('#selectStateId'+dataList[i].asrptId).val();
			var selectedAlerts = $('#selectAlert'+dataList[i].asrptId).val();
			var selectedComments = $('#commentsTextArea'+dataList[i].asrptId).val();
			
			console.log("selectAlert->",selectedAlerts);
			console.log("CommentText->",selectedComments);
			console.log("selectStates->",selectedStates);	
			
			var _alertsLen = dataList[i].alerts.length;	
			
			
			
			if ($scope.userAttrArray.indexOf('CPI Assigned') != -1) {
				console.log('User is a Tiger Team member.');			
				if ($('#selectIdZone'+dataList[i].asrptId).val() == ""){
					showGrowl('<i aria-hidden=\'true\'></i> Please select a Jurisdiction before continuing.', 'warning');
					exitFlag = true;
					break;
				}else {
					userZone = $('#selectIdZone'+dataList[i].asrptId).val();
				}
			}else {

				console.log('User is a NOT Tiger Team member.');		
				if (_alertsLen >0  && (selectedAlerts == undefined || selectedAlerts.length == 0) ){					
					
					showGrowl('<i aria-hidden=\'true\'></i> Please select a model(s) before continuing.', 'warning');
					exitFlag = true;
					break;
				}
				

				var asrPrioritizationModelItems = dataList[i].alerts;	
						
					if (_alertsLen >0 ){						
						console.log("No of Alerts in ASR- ", _alertsLen);

						for (sa =0; sa< selectedAlerts.length; sa++){
							var _selectedAlert = selectedAlerts[sa];



							for (a=0; a<_alertsLen; a++ ){
								var currentAlert = dataList[i].alerts[a];
								if (currentAlert.disabled== undefined || currentAlert.disabled != true){ 
									// console.log("_selectedAlert -", _selectedAlert, "-->currentAlert ", currentAlert.modelBusnsId+'('+currentAlert.status+')');

									if(_selectedAlert == currentAlert.modelBusnsId+'('+currentAlert.status+')'){
										// if matched
										// Filter Zurisdiction alerted states
										var __modelBusnsId = currentAlert.modelBusnsId;
										
										
										//Set temp object for priotization
										var tempalertsObj = {}
										tempalertsObj.modelBusnsId = __modelBusnsId;
										tempalertsObj.createDt = currentAlert.createDt;
										tempalertsObj.status = currentAlert.status;
										tempalertsObj.prioritizedInd = "Y";
										tempalertsObj.disabled = currentAlert.disabled;
										tempalertsObj.states = [];
										asrPrioritizationModelItems = asrPrioritizationModelItems.filter(obj => !(obj.modelBusnsId ===  __modelBusnsId && obj.status === currentAlert.status));
										
										var tempStatesObj = []; 
										if ($scope.activeASRTab == "medicaid") {
											var __statesLen = (currentAlert.states != undefined && currentAlert.states.length >0)?currentAlert.states.length: 0;	
											//States validation is required for medicaid only							
											if (__statesLen > 0){
												if (selectedStates == undefined  || selectedStates.length == 0 ){
													showGrowl('<i aria-hidden=\'true\'></i> Please select a state(s) before continuing.', 'warning');
					exitFlag = true;
					break;
												}else {
													console.log("Selected states",selectedStates );
													var __stateSelectedMatched = false
													for(n=0; n< __statesLen; n++){
														var __state =currentAlert.states[n];
														// identify all the states belongs to current alert and asr
														for (m=0; m<selectedStates.length; m++){											
															var __stateID = selectedStates[m];
															const splitList = __stateID.split("___");
															if (splitList.length>0 && splitList[0] == __asrptId &&  splitList[1]== __modelBusnsId && splitList[2] == __state.modelLabel ){
																console.log("ASR ID, ALERT and State Matched - ", __stateID);
																__stateSelectedMatched = true;	
																tempStatesObj.push( __state);
															}
				}
				
													}
					
													// Atleast one state selected from the alerts.
													if(!__stateSelectedMatched){
						showGrowl('<i aria-hidden=\'true\'></i> Please select a state(s) before continuing.', 'warning');
						exitFlag = true;
						break;
					}
				}
											}else {
												console.log("Alerts has no states in the zurisditiction ", currentAlert.modelBusnsId);
											}
										} else {
											console.log("Medicare.  No states validation required.");
			}
			
										// Set selected states
										tempalertsObj.states = tempStatesObj ;
										asrPrioritizationModelItems.push(tempalertsObj);
									}
								}else {
									console.log("NON Zurisdiction model - ", currentAlert.modelBusnsId);
					}
							}
						}
					}else {
						console.log(" No alerts listed.");
					}
					
				if (dataList[i].alerts.length==0 && $('#commentsTextArea'+dataList[i].asrptId).val() == ""){
					showGrowl('<i aria-hidden=\'true\'></i> Please add a comment before continuing.', 'warning');
					exitFlag = true;
					break;
				}
			}
			
			
			priorityObj.asrPrioritizationModelItems = asrPrioritizationModelItems;
			priorityObj.programType = $scope.activeASRTab;
			prioritiesArray.push(priorityObj);
			
		}
//		Terminate the loop when there are any required fields to be entered by the user
		if (exitFlag)
			return;
		
//		Proceed prioritize all required fields entered by the user.	
		$("#modalPrioritizeUCMBtn").addClass("disabled");
		$("#modalPrioritizeUCMBtn").prop("disabled", true);	
		//show modal overlay
		$("#prioritizeUCMModalBody").LoadingOverlay("show");
		

		console.log("-->prioritiesArray-->", prioritiesArray);
		
		
		detailsFactory.prioritizeASRForUCM($scope.restURL, $scope.scopeUserId,prioritiesArray ).then(function(response) {
			
			// Hide modal LoadingOverlay
			$("#prioritizeUCMModalBody").LoadingOverlay("hide");
			$("#prioritizeUCMModal").modal("hide");
			
			//show growl success message
			showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i>  ASRs successfully Prioritized for UCM.', 'success');
			
			
		}).
		catch(function(err){    			
			console.log("prioritizeASRForUCM REST Error: " + err.status);
			//$("#asrMgmtTable").bootstrapTable('hideLoading');
			// Hide modal LoadingOverlay
			$("#prioritizeUCMModalBody").LoadingOverlay("hide");
			$("#modalPrioritizeUCMBtn").removeClass("disabled");
			$("#modalPrioritizeUCMBtn").prop("disabled", false);	
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Prioritize ASRs for UCM failed due to ' + err.status, 'danger');
		});
		
	}

}]);

//define a factory to perform REST functionality
appDetails.factory('detailsFactory', ['$http', '$rootScope', function($http, $rootScope) {
	return { 
    	getASRDetailsData: function(pURL, pAsrId, pSearchType, pUserId, medicareOrMdcd) {
    		console.log("Inside detailsFactory.getAsrDetailsData.  pUrl = " + pURL + ". pAsrId = " + pAsrId+" - medicare or medicaid -"+medicareOrMdcd);
    		
    		//create the json request object
    		var entryCriteria = {
    			asrId: pAsrId,
    			userId: pUserId,
    			searchType: pSearchType
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getASRDetailsData REST request = ' + jsonData);
    		
    		if (medicareOrMdcd == "medicaid") {
    			return $http.post(pURL + '/rest/portal/asrMdcdDetails', jsonData);
    			
    		}else {
    			return $http.post(pURL + '/rest/portal/asrDetails', jsonData);
    		}
    		
    		

    	},
    	getAsrMdcdDetailsData: function(pURL, pAsrId, pSearchType, pUserId) {
    		console.log("Inside detailsFactory.getAsrMdcdDetailsData.  pUrl = " + pURL + ". pAsrId = " + pAsrId);
    		
    		//create the json request object
    		var entryCriteria = {
    			asrId: pAsrId,
    			userId: pUserId,
    			searchType: pSearchType
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getAsrMdcdDetailsData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/asrMdcdDetails', jsonData);

    	},
    	getTabPriorityForUCMData: function(pURL, pAsrId, pUserId, programType) {
    		console.log("Inside detailsFactory.getTabPriorityForUCMData.  pUrl = " + pURL + ". pAsrId = " + pAsrId);
    		
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId: pUserId,
    			programType: programType
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getTabPriorityForUCMData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/tabDataPrioritizeUCM', jsonData);
    		
    	},
		
    	
		getTabLeadsData: function(pURL, pAsrId, pUserId) {
    		console.log("Inside detailsFactory.getTabLeadsData.  pUrl = " + pURL + ". pAsrId = " + pAsrId);
    		
		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId:	pUserId
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getTabLeadsData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/tabDataLeads', jsonData);
    		
    	},
		getTabLeadsMdcdData: function(pURL, pAsrId, pUserId) {
    		console.log("Inside detailsFactory.getTabLeadsMdcdData.  pUrl = " + pURL + ". pAsrId = " + pAsrId);
    		
		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId:	pUserId,
				programType: "medicaid"
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getTabLeadsData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/tabDataLeads', jsonData);
    		
    	},
    	getTabNotesData: function(pURL, pAsrId, pUserId) {
    		console.log("Inside detailsFactory.getTabNotesData.  pUrl = " + pURL + ". pAsrId = " + pAsrId);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId: pUserId
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getTabNotesData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/tabDataNotes', jsonData);
    		
    	},
    	getTabEditsData: function(pURL, pAsrId, pUserId) {
    		console.log("Inside detailsFactory.getTabEditsData.  pUrl = " + pURL + ". pAsrId = " + pAsrId);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled");        	
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId: pUserId
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getTabEditsData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/tabDataEdits', jsonData);
    		
    	},
    	getReportCardData: function(pURL, pNPI, pModelId, pUserId, pInsertDt, mdcdState, mdcdOrMedicare) {
    		console.log("Inside detailsFactory.getReportCardData.  pUrl = " + pURL + ", pNPI = " + pNPI + ", pModelId = " + pModelId);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled");   
    		
    		//create the json request object
    		var entryCriteria = {
    			npi: pNPI,
    			modelId: pModelId,
    			userId: pUserId,
    			insertDt: pInsertDt,
    			state: mdcdState
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getReportCardData REST request = ' + jsonData);
    		
    		if(mdcdOrMedicare == "medicaid"){
    			console.log("medicaid")
    			return $http.post(pURL + '/rest/portal/mdcdReportCard', jsonData);
    		} else {
    			return $http.post(pURL + '/rest/portal/reportCard', jsonData);
    		}
    		
    	},
		
		getReportVizData: function(pURL, pModelId, pNPI, tableId, pUserId,  mdcdState, mdcdOrMedicare){
			var entryCriteria = {
    			npi: pNPI,
    			modelId: pModelId,
    			userId: pUserId,
    			insertDt: '',
    			state: mdcdState,
    			tableId: tableId
    		};
			jsonData = JSON.stringify(entryCriteria);
			
    		if(mdcdOrMedicare == "medicaid"){
    			console.log("medicaid")
    			return $http.post(pURL + '/rest/portal/mdcdReportCard', jsonData);
    		} else {
    			return $http.post(pURL + '/rest/portal/reportCard', jsonData);
    		}
		},

    	getTabHistoryData: function(pURL, pAsrId) {
    		console.log("Inside detailsFactory.getTabHistoryData.  pUrl = " + pURL + ". pAsrId = " + pAsrId);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled");  
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId	
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getTabHistoryData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/tabDataHistory', jsonData);    		
    	},
    	getTabClaimsData: function(pURL, pAsrId, pUserId) {
    		console.log("Inside detailsFactory.getTabClaimsData.  pUrl = " + pURL + ". pAsrId = " + pAsrId);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled");  
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId: pUserId
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getTabClaimsData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/tabDataClaims', jsonData);
    		
    	},
    	getSysTagsData: function(pURL, pAsrId, pUserId) {
    		console.log("Inside detailsFactory.getTabSysTagsData.  pUrl = " + pURL + ". pAsrId = " + pAsrId);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled"); 
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId: pUserId
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getTabSysTagsData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/tabDataSysTags', jsonData);
    		
    	},
    	getTabTotalZnCostData: function(pURL, pAsrId, pUserId) {
    		console.log("Inside detailsFactory.getTabTotalZnCostData.  pUrl = " + pURL + ". pAsrId = " + pAsrId);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled"); 
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId: pUserId
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getTabTotalZnCostData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/tabDataTotalZoneCost', jsonData);
    		
    	},
		getTabp1TotalZnCostData: function(pURL, pAsrId, pUserId) {
    		console.log("Inside detailsFactory.getTabp1TotalZnCostData.  pUrl = " + pURL + ". pAsrId = " + pAsrId);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled"); 
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId: pUserId
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/tabDatap1TotalZoneCost', jsonData);
    		
    	},
    	getModelBenes: function(pURL, pModelId, pAsrId) {
    		console.log("Inside detailsFactory.getModelBenes.  pModelId = " + pModelId + ". pAsrId = " + pAsrId);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled"); 
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			modelId: pModelId    			
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getModelBenes REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/modelBenes', jsonData);
    	}, 
    	prioritizeASRForUCM: function(pURL, pUserId, prioritiesArray) {
    		console.log("Inside detailsFactory.prioritizeASRForUCM.  pUserId = " + pUserId );
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled"); 
    		
    		//create response similar to "priorities":[{"asrId", "userId", "zone", "comments"}]
    		var prioritiesObj = {};
    		prioritiesObj.priorities = prioritiesArray;
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(prioritiesObj);
    		console.log('prioritizeASRForUCM REST request = ' + jsonData);
    		
    		
    		return $http.post(pURL + '/rest/portal/prioritizeASRsForUCM', jsonData);
    	}, 
    	/*prioritizeASRForUCM: function(pURL, pUserId, pAsrId, pUcmComments, pUserZone) {
    		console.log("Inside detailsFactory.prioritizeASRForUCM.  pUserId = " + pUserId + ", pAsrId = " + pAsrId
    				+ ", pUCMComments = " + pUcmComments + ", pUserZone = " + pUserZone);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled"); 
    		
    		//create response similar to "priorities":[{"asrId", "userId", "zone", "comments"}]
    		var prioritiesObj = {};
    		var prioritiesArray = [];
  			var priorityObj = {};
    			priorityObj.asrDbId = pAsrId;
    			priorityObj.userId = pUserId;
    			priorityObj.zone = pUserZone;
    			priorityObj.comments = pUcmComments;
    			
    			prioritiesArray.push(priorityObj);    			
    		
    		
    		prioritiesObj.priorities = prioritiesArray;
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(prioritiesObj);
    		console.log('prioritizeASRForUCM REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/prioritizeASRsForUCM', jsonData);
    	}, */
    	getUcmLeadData: function(pURL, pAsrId, pLeadId) {
    		console.log("Inside detailsFactory.getUcmLeadData. pAsrId = " + pAsrId
    				+ ", pLeadId = " + pLeadId);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled"); 
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			leadId: pLeadId    			
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getUcmLeadData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/ucmLeadData', jsonData);
    	}, 
    	getAsrMapsInfo: function(pURL, pAsrId, pUserId, pResultsIndex) {
    		console.log("Inside detailsFactory.getAsrMapsInfo. pAsrId = " + pAsrId
    				+ ", pUserId = " + pUserId+ ", pResultsIndex = " + pResultsIndex);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled"); 
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId: pUserId,
    			resultsIndex: pResultsIndex
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getAsrMapsInfo REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/asrMapsInfo', jsonData);
    	},
    	getNetVizHhaData: function(pURL, pAsrId, pModelId, pUserId){
    		console.log("Inside detailsFactory.getNetVizHhaData. pURL = " + pURL
    				+ ", pAsrId = " + pAsrId + ", ModelId = " + pModelId);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled"); 
        	
        	//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			modelId: pModelId,
    			userId: pUserId
        	};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getNetVizHhaData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/networkVizHhaData', jsonData);
    	},
    	getNetVizDmeData: function(pURL, pAsrId, pModelId, pUserId){
    		console.log("Inside detailsFactory.getNetVizDmeData. pURL = " + pURL
    				+ ", pAsrId = " + pAsrId + ", ModelId = " + pModelId);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled"); 
        	
        	//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			modelId: pModelId,
    			userId: pUserId
        	};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getNetVizDmeData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/networkVizDmeData', jsonData);
    	},
    	getNetVizData: function(pURL, pAsrId, pModelId, pUserId){
    		console.log("Inside detailsFactory.getNetVizData. pURL = " + pURL
    				+ ", pAsrId = " + pAsrId + ", ModelId = " + pModelId);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled"); 
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			modelId: pModelId,
    			userId: pUserId
        	};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getNetVizData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/networkVizData', jsonData);
    		
    	},
     	getPartDClaimLinesData: function(pURL, pAsrId, pModelId, pUserId) {
    		console.log("Inside detailsFactory.getPartDClaimLinesData.  pModelId = " + pModelId + ", pAsrId = " + pAsrId);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			modelId: pModelId,
    			userId: pUserId
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getPartDClaimLinesData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/partdClaimLinesData', jsonData);
    	},
    	getTabPartDReportsData: function(pURL, pAsrId, pUserId) {
    		console.log("Inside detailsFactory.getTabPartDReportsData.  pUrl = " + pURL + ". pAsrId = " + pAsrId);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId: pUserId
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getTabPartDReportsData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/tabDataPartDReports', jsonData);
    	},
    	getNetVizExportData: function(pURL, pAsrId, pModelName, pUserId, pModelType) {
    		console.log("Inside detailsFactory.getNetVizExportData.  pModelName = " 
    				+ pModelName + ", pAsrId = " + pAsrId + ", pModelName = " + pModelName);
    		
    		//broadcast this event to the reset session listener
        	$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId: pUserId,
    			modelName: pModelName,
    			modelType: pModelType
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getNetVizExportData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/exportNetVizBin', entryCriteria, {responseType: "blob"});
    	},
    	getFieldExport: function(pURL, pAsrId, pUserId) {
    		console.log("Inside detailsFactory.getFieldExport.  pUrl = " + pURL + ", pAsrId = " + pAsrId);
    		
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId: pUserId,    			
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getFieldExport REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/exportFieldBin', jsonData, {responseType: "blob"});
    	},
		 getFieldExportMdcd: function(pURL, pAsrId, pUserId) {
    		console.log("Inside detailsFactory.getFieldExportMdcd.  pUrl = " + pURL + ", pAsrId = " + pAsrId);
    		
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId: pUserId,    			
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getFieldExportMdcd REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/exportFieldMdcdBin', jsonData, {responseType: "blob"});
    	},
    	getSummaryModalData: function(pURL, pAsrId, pUserId, pLinkType) {
    		console.log("Inside detailsFactory.getSummaryModalData.  pUrl = " + pURL + ", pAsrId = " + pAsrId);
    		
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId: pUserId,
    			linkType: pLinkType
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getSummaryModalData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/querySummaryModalData', jsonData);
    	},
    	getMDCDMedicaidModalData: function(pURL, pAsrId, pUserId, pLinkType) {
    		console.log("Inside detailsFactory.getMDCDMedicaidModalData.  pUrl = " + pURL + ", pAsrId = " + pAsrId);
    		
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId: pUserId,
    			linkType: pLinkType
    			
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getSummaryModalData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/queryMDCDSummaryModalData', jsonData);
    	},
    	addNetVizHhaConnections: function(pURL, pNpi, pModelName, pUserId, pConnectionsIndex) {
    		console.log("Inside detailsFactory.addNetVizHhaConnections.  pUrl = " + pURL + ", pNpi = " + pNpi 
    				+ ", pModelName = " + pModelName + ", pConnectionsIndex = " + pConnectionsIndex);
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			npi: pNpi,
    			modelName: pModelName,
    			userId: pUserId,
    			connectIndex: pConnectionsIndex
        	};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('addNetVizHhaConnections REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/addNetVizHhaConnections', jsonData);
    	},
    	getPrioritizationZones: function(pURL) {
    		console.log("Inside detailsFactory.getPrioritizationZones.");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    //			noRequiredField: 'noRequiredValue'	
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getPrioritizationZones REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/queryPriorUcmZones', jsonData);  
    	},
    	getPrioritizeForUCMTable: function(pURL, ids, uid, programType) {
    		console.log("Inside detailsFactory.getPrioritizationTable.");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    				asrptIds: ids,
    				programType: programType,
    				loggedInUserId: uid
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getPrioritizationTable REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/prioritizeForUCMTable', jsonData);  
    	},
    	getTpeData: function(pURL, pAsrId, pUserId) {
    		console.log("Inside detailsFactory.");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			asrptId: pAsrId,
    			userId: pUserId
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getTpeData REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/tpeData', jsonData); 
    	},
    	getEditDetails: function(pURL, pEditName, pUserId) {
    		console.log("Inside detailsFactory.getEditDetails");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {    			
    			editName: pEditName,
    			userId: pUserId
    			
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getEditDetails REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/editDetails', jsonData); 
    	},
    	loadMedicaidClaimStates: function(pURL, pAsrptId, pUserId) {
    		console.log("Inside detailsFactory.getEditDetails");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {    			
    			asrptId: pAsrptId,
    			userId: pUserId
    			
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getEditDetails REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/claimStates', jsonData); 
    	},
    	getEditAllClaims: function(pURL, pEditName, pUserId, pNpi) {
    		console.log("Inside detailsFactory.getEditAllClaims");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {    			
    			editName: pEditName,
    			userId: pUserId,
    			npi: pNpi
    			
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getEditAllClaims REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/editAllClaims', jsonData); 
    	},
    	getEditInfo: function (pURL, pUserId) {
    		console.log("Inside detailsFactory.getEditInfo");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getEditInfo REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/editInfo', jsonData); 
    	},
    	getTotalPaymentModalData: function (pURL, pAsrptId, pUserId) {
    		console.log("Inside detailsFactory.getTotalPaymentModalData");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			asrptId: pAsrptId
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getTotalPaymentModalData REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/totalPayment', jsonData); 
    	},
    	getRelatedAsrsData: function (pURL, pAsrptId, pUserId) {
    		console.log("Inside detailsFactory.getRelatedAsrsData");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			asrptId: pAsrptId
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getRelatedAsrsData REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/relatedAsrs', jsonData); 
    	},
    	getNonAlertedData: function (pURL, pAsrptId, pUserId) {
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			asrptId: pAsrptId
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getNonAlertedData REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/nonAlertAsrs', jsonData); 
    	},
    	getLandingPageData: function(pURL, pUserId, pUserZone) {
   		 //   		console.log("Inside indexFactory.getLandingPageData");
   		 
   		    		//create the json request object
   		    		var entryCriteria = {
   		    				userId: pUserId,
   		    				userZone: pUserZone
   		    		};
   		    		
   		    		//create the JSON object to be used in the REST Request
   		    		jsonData = JSON.stringify(entryCriteria);
   		    		    		
   		    		return $http.post(pURL + '/rest/portal/queryLandPageData', jsonData);
   		    	},
   		    	
   		    	mdcdTotalPayment: function(pURL,reqAsrDbid,reqUserId) {
   		    		console.log("Inside caseMgmtFactory.mdcdTotalPayment.");
   		    		
   		    		//broadcast this event to the reset session listener
   		    		$rootScope.$broadcast("factoryMethodCalled");
   		    		
   		    		//create the json request object
   		    		var entryCriteria = {
   		    			asrDbid: reqAsrDbid,
   		    			userId: reqUserId
   		    		};
   		    		
   		    		
   		    		
   		    		//create the JSON object to be used in the REST Request
   		    		jsonData = JSON.stringify(entryCriteria);
   		    		console.log('mdcdTotalPayment REST request = ' + jsonData);
   		    		
   		    		//make the rest web service call to get the data
   		    		return $http.post(pURL + '/rest/portal/mdcdTotalPayment', jsonData);
   		    	}, 
   		    	getUserPreferences: function(pURL, pPrefName, pUserId, pPrefJson, pPrefLabel) {
   					//broadcast this event to the reset session listener
   		    		$rootScope.$broadcast("factoryMethodCalled");

   		    		//create the json request object
   		    		var entryCriteria = {
   		    			userId: pUserId,
   		    			prefName: pPrefName,
   		    			prefJson: pPrefJson,
   		    			prefLbl: pPrefLabel 
   		    		};
   		    		
   		    		//create the JSON object to be used in the REST Request
   		    		jsonData = JSON.stringify(entryCriteria);
   		    		console.log('getUserPreferences REST request = ' + jsonData);
   		    		
   		    		return $http.post(pURL + '/rest/portal/retrieveUserPrefs', jsonData);
   		    	},
				loadDocument: function(pURL) {
					console.log("Inside detailsFactory.loadDocument");
					
					// broadcast this event to the reset session listener
					$rootScope.$broadcast("factoryMethodCalled");
					config = {};
					
					$http.get(pURL,{ responseType: 'arraybuffer' }).then(function (response) {
						console.log("response " + response);

						var a = document.createElement("a");
						document.body.appendChild(a);
						a.style = "display: none";
						a.target = "_blank";
						//console.log(response.headers());
						var blobFileName = "";
						//var headerVal = response.headers('Content-Disposition');
						//if (headerVal){
						//	 headerVal.substring(headerVal.lastIndexOf('=')+1, headerVal.length-1);
						//}else{
							
							var queryString = pURL.substring(pURL.lastIndexOf('?')+1, pURL.length-1);
							var urlParams = new URLSearchParams(queryString);
							blobFileName = urlParams.get("fileName");
							//blobFileName= blobFileName.replace("\"", "");
						//}
						//var queryString = pURL.substring(pURL.lastIndexOf('?')+1, pURL.length-1);
						//var urlParams = new URLSearchParams(queryString);
						//var blobFileName = urlParams.get("fileName");
						//blobFileName= blobFileName.replace("\"", "");
						console.log(blobFileName);

						var contentType = response.headers('Content-Type');
						if (!contentType){
							contentType = "application/pdf";
						}
						console.log("contentType = " + contentType);

						var binaryData = response.data;
						if (navigator.msSaveBlob){
							//IE Browsers
							navigator.msSaveBlob(blob, blobFileName);
						} else {

						
							var blob = new Blob([binaryData], {type: contentType})
							var u = URL.createObjectURL(blob);
							a.href = u;
							a.download = blobFileName;
							a.click();
							URL.revokeObjectURL(u);
						}
				
					}).catch(function(e) {
						console.log('Error: ', e);
						throw e;
					});
					console.log('loadDocument REST request = ' + jsonData);
    		    		
    		
		}
   		    	
	}	
}]);




