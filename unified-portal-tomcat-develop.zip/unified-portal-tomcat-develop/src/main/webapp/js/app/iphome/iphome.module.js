/**
 *   This is the module (controller) declaration for the Unified Portal Index screen (index.html)
 */
var appIpHome = angular.module('iphome.module', ['ngRoute', 'ngCookies', 'ngSanitize']);

//define the controller - which is simply a constructor function that takes $scope parameter
appIpHome.controller('ipHomeController', ['$scope', '$rootScope','$cookies', '$window', '$sanitize', '$sce', 'ipHomeFactory', 'utilService', 'utilFactory', 'caseMgmtFactory',  '$http','$q',
                                        function ($scope, $rootScope, $cookies, $window, $sanitize, $sce, ipHomeFactory, utilService, utilFactory, caseMgmtFactory,$http,$q) {	console.log('Inside the ipHomeController.');
	// adding document title for 508 pupose
	function updatePageTitle(newTitle) {
		document.title = newTitle;

		// Announce the new title for screen readers
		const srAnnouncer = document.createElement("div");
		srAnnouncer.setAttribute("role", "alert");
		srAnnouncer.setAttribute("aria-live", "assertive");
		srAnnouncer.style.position = "absolute";
		srAnnouncer.style.width = "1px";
		srAnnouncer.style.height = "1px";
		srAnnouncer.style.margin = "-1px";
		srAnnouncer.style.clip = "rect(0, 0, 0, 0)";
		srAnnouncer.style.overflow = "hidden";
		srAnnouncer.textContent = newTitle;
		document.body.appendChild(srAnnouncer);

		// Remove the announcer after a short delay
		setTimeout(() => {
		  document.body.removeChild(srAnnouncer);
		}, 1000);
	  }

	  // Set the page title for "ASR Summary"
	  $rootScope.pageTitle = "FPS Home Page";
	  updatePageTitle($rootScope.pageTitle);
	
	// variables for medicare medicade toggle
	// make the different models classbased so we can set them in the view when needed
	$scope.asrvalue = 'medicare'; // default
	
	
	$scope.showMedicareAsrInfo = function(asrvalue){
		console.log('show medicare asr info fired ' + asrvalue);
		$("#modelsTable").bootstrapTable('destroy');
		$("#modelsTable").bootstrapTable({})
		if(asrvalue == 'medicare' ||$scope.showMedicaid == false){
			$scope.asrvalue = 'medicare';
			console.log('its inside medicare asr info');
			angular.forEach($scope.medicaremodel, function(obj){
				obj.asrType = 'medicare';
			});
			$("#modelsTable").bootstrapTable('load', $scope.medicaremodel);
			var elementMdcd = document.getElementById('medicaidModelInfoItem')
			if (elementMdcd != null && elementMdcd.classList.contains("active")){
				elementMdcd.classList.remove("active");
				console.log("Active MDCD");
			}			
			if ($scope.showMedicaid == false){
				elementMdcd.classList.add("disabled");
			}
			var element = document.getElementById('medicareModelInfoItem')
			if (element != null)
				element.classList.add("active");
		}
		else {
			$scope.asrvalue = 'medicaid';
			console.log('its inside medicaid asr info');
			$("#modelsTable").bootstrapTable('hideColumn', 'pathToEduInd');
			$("#modelsTable").bootstrapTable('hideColumn', 'p1Ind');
			angular.forEach($scope.medicaidmodel, function(obj){
				obj.asrType = 'medicaid';
			});
			$("#modelsTable").bootstrapTable('load', $scope.medicaidmodel);
			var element = document.getElementById('medicaidModelInfoItem')
			if (element != null)
				element.classList.add("active");
			
			element = document.getElementById('medicareModelInfoItem')
			//element.classList.remove("active");	
			if (element != null && element.classList.contains("active")){
				element.classList.remove("active");
				console.log("Active MEDICARE");
			}
		}	
	}
	
	$scope.$on('broadcastDefaultViewChange', function(event, args){
		
		$scope.showMedicareAsrInfo(args.message);
		$scope.showMedicareWorkbench(args.message);
	});

	$scope.showMedicareWorkbench = function(asrvalue){
		$("#workbenchTable").bootstrapTable('destroy');
		$("#workbenchTable").bootstrapTable({})
		if(asrvalue == 'medicare' ||$scope.showMedicaid == false){
			$scope.workbenchValue = 'medicare';
			console.log('its inside medicare asr info');
			$("#workbenchTable th:eq(1) span").attr('title', 'This column indicates if the type is a working set, saved search, or exclusion set.');
			$("#workbenchTable th:eq(2) span").attr('title', 'This column displays the number of unique ASRs contained within the working set or exclusion set. Note: This shall display N/A& for saved searches.');
			
			var elementMdcd = document.getElementById('medicaidModelWorkbenchItem')
			if (elementMdcd != null && elementMdcd.classList.contains("active")){
				elementMdcd.classList.remove("active");
				console.log("Active MDCD");
			}			
			if ($scope.showMedicaid == false){
				elementMdcd.classList.add("disabled");
				$('#medicaidModelWorkbenchItem').css('pointer-events', 'none');
			}
			var element = document.getElementById('medicareModelWorkbenchItem')
			if (element != null)
				element.classList.add("active");
			if($scope.medicareWorkbench != undefined)
			$("#workbenchTable").bootstrapTable('load', $scope.medicareWorkbench);
		}
		else {
			$scope.workbenchValue = 'medicaid';
			console.log('its inside medicaid asr info');
			$("#workbenchTable th:eq(1) span").attr('title', 'This column indicates if the type is a working set, saved search.');
			$("#workbenchTable th:eq(2) span").attr('title', 'This column displays the number of unique ASRs contained within the working set. Note: This shall display N/A for saved searches.');
			var element = document.getElementById('medicaidModelWorkbenchItem')
			if (element != null)
				element.classList.add("active");
			
			element = document.getElementById('medicareModelWorkbenchItem')
			if (element != null && element.classList.contains("active")){
				element.classList.remove("active");
				console.log("Active MEDICARE");
			}
			if($scope.medicaidWorkbench != undefined)
			$("#workbenchTable").bootstrapTable('load', $scope.medicaidWorkbench);
		}	
	}

	
	// get the Okta authClient object from the util service
	var authClient = utilService.getOktaAuth();

	authClient.tokenManager.getTokens()
	.then(({ accessToken, idToken }) => {
		// handle accessToken and idToken
		if (accessToken) {
			// user has valid access token, so show page contents
			showIndexPageContents(idToken);
		} else {
			// no token and not logged-in, so redirect to login screen               
		authClient.token.getWithRedirect({
				responseType: ['token', 'id_token']
			});
		}
	});

	// this function shows the page to users that have been authenticated via Okta
	showIndexPageContents = function(pIdToken) {

		if (pIdToken) {
			// show the index page Dom objects
			$('#ipHomeContainer').removeAttr('hidden');

			// create a scope level unique identifier for broadcast metrics
			$scope.loadPageUniqueId = Math.floor(Math.random() * 1000) + Date.now();

			// destroy, and then initialize the user requests table
			$("#userRequestsTable").bootstrapTable('destroy');
			$("#userRequestsTable").bootstrapTable({});

			// destroy, and then initialize the reports table
			$("#reportsTable").bootstrapTable('destroy');
			$("#reportsTable").bootstrapTable({});

			// destroy, initialize the work items table
			$("#workbenchTable").bootstrapTable('destroy');
			$("#workbenchTable").bootstrapTable({});

			// destroy, intialize the watchlist table
			$("#watchListTable").bootstrapTable('destroy');
			$("#watchListTable").bootstrapTable({});

			// show portlet overlays
			$("#workbenchPanelBody").LoadingOverlay("show");
			$("#reportFavPanel").LoadingOverlay("show");
			$("#modelsPanelBody").LoadingOverlay("show");
			$("#userReqPanelBody").LoadingOverlay("show");
			$("#watchListPanelBody").LoadingOverlay("show");

			// call the global utilFactory method to get the URL for the current environment
			utilFactory.getURLPropertyFromFile().then(function(response) {	
				//declare a scope level variable for the URL used to make REST web service calls 
				$scope.restURL = response.data;
				//  console.log('Setting REST URL = ' + $scope.restURL);

				// build the URL to the user support portal
				$scope.supportUrl = $scope.restURL.substring(0, $scope.restURL.lastIndexOf("/")+1) + "UserSupportPortal/index.html"; 
						
				// parse the token for the user's id
				$scope.uid = pIdToken.claims.preferred_username;

				// loop through the array to parse all of the values from the array					
				$scope.rolesArray = [];
				$scope.userAttrArray = [];
				$scope.zonesArray = [];
				var groupsArray = pIdToken.claims.groups;					

				for (i = 0; i < groupsArray.length; i++) {
					console.log('group - ' + groupsArray[i]);
					var groupObj = groupsArray[i];

					// populate role array
					if (groupObj.search('FPSUI Role') != -1) {
						$scope.rolesArray.push(groupObj.replace("FPSUI Role", "").trim());
					}

					// populate the zone Array
					if (groupObj.search('FPSUI Zone') != -1) {
						$scope.zonesArray.push(groupObj.replace("FPSUI Zone", "").trim());
					}

					// populate the attributes Array
					if (groupObj.search('FPSUI Attrib') != -1) {
						$scope.userAttrArray.push(groupObj.replace("FPSUI Attrib", "").trim());
					}
				}

				if ($scope.rolesArray.indexOf("MAC") > -1 || $scope.zonesArray.indexOf("MEDIC") > -1){
					$scope.showMedicaid = false;
	
					//disable the medicaid AsrInfo Details tab
					$('#medicaidModelInfoItem').addClass('disabled');
					$('#medicaidModelInfoItem').attr('aria-disabled', 'true');
					$('#medicaidModelInfoTabLink').css('cursor', 'not-allowed');
					$('#medicaidModelInfoTabLink').css('pointer-events', 'none');
					$('#medicaidModelInfoTabLink').removeAttr('data-toggle');
					console.log("Disable Medicaid Model tab");
				}else{
					$scope.showMedicaid = true;
					
					
				}
				// set the org value to the first zone in array
				$scope.oldOrganizationVal = $scope.zonesArray[0];
				console.log("$scope.oldOrganizationVal ->", $scope.oldOrganizationVal);

				$jsUserId = $scope.uid; // servlet param for model guidance

				//broadcast this event to the broadcastSlaMetrics listener
				$rootScope.$broadcast('broadcastSlaMetrics', {message:"Landing Page Load - Start: " + $scope.loadPageUniqueId, userId: $scope.uid, zone:$scope.oldOrganizationVal, restURL:$scope.restURL});

				// get the work items for the current user
				ipHomeFactory.getWorkItemsData($scope.restURL,$scope.uid, "WORKING").then(function(response) {						
										
				// load the workbench table with data
					
					$scope.medicareWorkbench =  response.data.workbenchLists;
					$scope.medicaidWorkbench =  response.data.workbenchMdcdLists;
					if($scope.defaultAsrView == 'medicare'){
						$("#workbenchTable").bootstrapTable('load', $scope.medicareWorkbench);
					}
					
					else{
						$("#workbenchTable").bootstrapTable('load', $scope.medicaidWorkbench);
					}
					
					// hide work items portlet overlay
					$("#workbenchPanelBody").LoadingOverlay("hide");
					
				}).catch(function(err) {
					console.log('getWorkItemsData RESTError:' +  err.data);
					
					// hide work items portlet overlay
					$("#workbenchPanelBody").LoadingOverlay("hide");
					
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> No work items data available due to ' +  err.data + ' error.', 'danger');
				});

				// get the landing page information from DB2
				ipHomeFactory.getAllLandingPageData($scope.restURL,$scope.uid,$scope.oldOrganizationVal, $scope.loadPageUniqueId).then(function(response) {
					$scope.medicareWorkbench =  response.dataWorkbench.workbenchLists;
					$scope.medicaidWorkbench =  response.dataWorkbench.workbenchMdcdLists;
					if($scope.defaultAsrView == 'medicare'){
						$("#workbenchTable").bootstrapTable('load', $scope.medicareWorkbench);
					}
					
					else{
						$("#workbenchTable").bootstrapTable('load', $scope.medicaidWorkbench);
					}
					
					// hide work items portlet overlay
					$("#workbenchPanelBody").LoadingOverlay("hide");
					
					
					//set a scope level variable to the info returned from the services
					$scope.indexData = response.dataLanding
					console.log('here is all the index data');
					console.log($scope.indexData);
					
					if ((response.dataLanding.defaultAsrView != null && response.dataLanding.defaultAsrView != undefined) 
					&& (response.dataLanding.defaultAsrView == "" || response.dataLanding.defaultAsrView == 'medicare' )) {
						$scope.defaultAsrView = 'medicare';
						
						
						
					}else {
						$scope.defaultAsrView = "medicaid";
						
					}
					$scope.medicareasrvalue = 'medicare';
					$scope.medicaidasrvalue = 'medicaid';
					$scope.medicaremodel = $scope.indexData.models;
					$scope.medicaidmodel = $scope.indexData.modelsMdcd;
					$scope.showMedicareAsrInfo($scope.defaultAsrView);
					$scope.showMedicareWorkbench($scope.defaultAsrView);
					console.log("Default ASR View: ", $scope.defaultAsrView);
				
					//only show the User Request table to PrioritizeSup users					
					if (response.dataLanding.requests != null && response.dataLanding.requests != void(0) && response.dataLanding.requests.length >0) {
						
						// adjust the bootstrap grid 
						$("#reportsDiv").toggleClass("col-md-4", false);
						$("#modelsDiv").toggleClass("col-md-8", false);
						$("#reportsDiv").toggleClass("col-md-3", true);
						$("#modelsDiv").toggleClass("col-md-6", true);
						
						//show the User Request table
						$scope.showUserRequests = true;
						
						//load the user requests table
						$("#userRequestsTable").bootstrapTable('load', response.dataLanding.requests);
					
					} else {
						//show the User Request table
						$scope.showUserRequests = false;
						
						// adjust the bootstrap grid 
						$("#reportsDiv").toggleClass("col-md-3", false);
						$("#modelsDiv").toggleClass("col-md-6", false);
						$("#reportsDiv").toggleClass("col-md-4", true);
						$("#modelsDiv").toggleClass("col-md-8", true);
					}

					// load the tableau reports table
					$("#reportsTable").bootstrapTable('load', response.dataLanding.reports);
			
					// hide the overlays for the models, reports, and user requests panels
					$("#reportFavPanel").LoadingOverlay("hide");
					$("#modelsPanelBody").LoadingOverlay("hide");
					$("#userReqPanelBody").LoadingOverlay("hide");
					$("#watchListPanelBody").LoadingOverlay("hide");
					
					// load the watchlist widget	
					if (response.dataLanding.watchlists[0].items.length > 0) {
						$("#watchListTable").bootstrapTable('load', response.dataLanding.watchlists[0].items);
					}							
					
					// broadcast this event to the broadcastSlaMetrics listener
					$rootScope.$broadcast('broadcastSlaMetrics', {message:"Landing Page Load - End: " + $scope.loadPageUniqueId, userId: ""});
				}).catch(function(err) {
					console.log('getLandingPageData RESTError:' +  err.data);
					
					// hide the overlays for the models, reports, and user requests panels
					$("#reportFavPanel").LoadingOverlay("hide");
					$("#modelsPanelBody").LoadingOverlay("hide");
					$("#userReqPanelBody").LoadingOverlay("hide");
					$("#watchListPanelBody").LoadingOverlay("hide");
					$("#workbenchPanelBody").LoadingOverlay("hide");
					

					
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> No Home page data available due to ' +  err.data + ' error.', 'danger');
				}); 	
				
			}).catch(function(err) {
				//		console.log('getURLPropertyFromFile REST Error:' + err.data);
						
						// hide all overlay spinners				
						$("#workbenchPanelBody").LoadingOverlay("hide");
						$("#reportFavPanel").LoadingOverlay("hide");
						$("#modelsPanelBody").LoadingOverlay("hide");
						$("#userReqPanelBody").LoadingOverlay("hide");
						$("#watchListPanelBody").LoadingOverlay("hide");
						
				//		showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load system data due to ' + err.data + ' error.', 'danger');		
			});

		} else {
			// You're not logged in, you need a sessionToken
			authClient.token.getWithRedirect({
				responseType: ['token', 'id_token']
			});
		} 	
	}

	//this function calls the user tracking service
	$scope.trackUserActivity = function(pPageId, pTrackVal) {
		
		//call the user tracking web service to denote the fact that the user has requested a Google Map
		utilFactory.getTrackUserActivity($scope.restURL, $scope.uid, pPageId, pTrackVal).then(function(response) {
			console.log('getTrackUserActivity web service call successful.');
		}).catch(function(err) {
			console.log('getTrackUserActivity REST Error:' + err.data);			
		});		
	}

	// show the delete modal
	$scope.showDeleteModal =  function(pListType) {
		console.log('pListType = ' + pListType);
		$scope.deleteListType = pListType;
		
		// show the delete work item modal		
		$("#deleteWorkSetModal").modal("show");
		
		//apply the scope ng-binding changes to the display
		$scope.$apply();	
	} 

	// rename work item
	$scope.renameWorkSetModal = function() {
		console.log('Inside renameWorkSetModal. Row ID = ' + $scope.selectedRowId + ', new name = ' + $scope.renameWsInput);
		
		// dirty the form since it's been submitted
		$scope.renameModalForm.$setDirty();
				
		// check the form validity
		//if ($scope.renameWsInput == undefined || $scope.renameWsInput == '' || $scope.renameWsInput == void(0)) {
		if ($scope.renameModalForm.$invalid) {
			// process response
			console.log('Invalid - Don\'t process.');
		} else {
			// process response
			console.log('Valid - Process');
			
			var listType;
			
			// set the group type
			if ($scope.selectedRowType == 'Working Set') {
				listType = 'asr';				
				
			} else {
				listType = 'search';
				
			}
			let processReq = true;
			if ($scope.workbenchValue == 'medicare') {

				caseMgmtFactory.checkExistListName($scope.restURL, $scope.uid, $scope.renameWsInput, listType).then(function (response) {
					$scope.checkNmArray = response.data;
					var existingAsrType = null;
					if ($scope.workbenchValue == 'medicare') {
						existingAsrType = 'MDCR'
					}
					else {
						existingAsrType = 'MDCD'
					}

					if ($scope.checkNmArray != null && $scope.checkNmArray.length > 0) {
						// loop through the array looking for match
						for (i = 0; i < $scope.checkNmArray.length; i++) {
							if ($scope.checkNmArray[i].listNm.trim() == $scope.renameWsInput.trim()) {
								console.log("Search already exists.")

								// hide the overlay
								$("#workbenchPanelBody").LoadingOverlay("hide");

								processReq = false;

								break;
							}
						}
					}
					if (processReq == true) {
						if ($scope.workbenchValue == "medicare") {
							var asrSearchType = "asrSearch"
						}
						else {
							asrSearchType = "asrSearchMdcd";
						}
		
						ipHomeFactory.renameList($scope.restURL, $scope.uid, $scope.selectedRowId, $scope.renameWsInput, listType).then(function (response) {
		
							// close the modal window
							$("#renameWorkItemModal").modal("hide");
		
							// show the workbench portlet overlay
							$("#workbenchPanelBody").LoadingOverlay("show");
		
							//destroy, and then initiate the modal table
							$("#workbenchTable").bootstrapTable('destroy');
							$("#workbenchTable").bootstrapTable({});
		
							// update the work set list
							if ($scope.workbenchValue == 'medicare') {
								$("#workbenchTable").bootstrapTable('load', response.data.workbenchLists);
								$scope.medicareWorkbench = response.data.workbenchLists;
							}
							else {
								$("#workbenchTable").bootstrapTable('load', response.data.workbenchMdcdLists);
								$scope.medicaidWorkbench = response.data.workbenchMdcdLists;
							}
		
		
		
							// hide the workbench portlet overlay
							$("#workbenchPanelBody").LoadingOverlay("hide");
		
							//show growl success message
							showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i>  List successfully renamed.', 'success');
		
						}).
							catch(function (err) {
								console.log("Rename List REST Error: " + err.status);
		
								// hide the workbench portlet overlay
								$("#workbenchPanelBody").LoadingOverlay("hide");
		
								showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Rename List failed due to ' + err.status, 'danger');
							});
					}
					else {
						$("#workbenchPanelBody").LoadingOverlay("hide");
		
						// show the warning message
						showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> An item with that name already exists. Please choose another name.', 'danger');
					}
				}).catch(function (err) {
					//hide full page overlay
					$("#workbenchPanelBody").LoadingOverlay("hide");

					// show growl message
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to validate list name due to ' + err.status, 'danger');
				});
			}
			else{
				caseMgmtFactory.checkExistListNameMdcd($scope.restURL, $scope.uid, $scope.renameWsInput, listType).then(function (response) {
					$scope.checkNmArray = response.data;
					if ($scope.checkNmArray != null && $scope.checkNmArray.length > 0) {
						// loop through the array looking for match
						for (i = 0; i < $scope.checkNmArray.length; i++) {
							if ($scope.checkNmArray[i].listNm.trim()  == $scope.renameWsInput.trim()) {
								console.log("Search already exists.")
	
								// hide the overlay
								$("#workbenchPanelBody").LoadingOverlay("hide");
	
								processReq = false;
	
								break;
							}
						}
						
					}
					if (processReq == true) {
						if ($scope.workbenchValue == "medicare") {
							var asrSearchType = "asrSearch"
						}
						else {
							asrSearchType = "asrSearchMdcd";
						}
		
						ipHomeFactory.renameList($scope.restURL, $scope.uid, $scope.selectedRowId, $scope.renameWsInput, listType).then(function (response) {
		
							// close the modal window
							$("#renameWorkItemModal").modal("hide");
		
							// show the workbench portlet overlay
							$("#workbenchPanelBody").LoadingOverlay("show");
		
							//destroy, and then initiate the modal table
							$("#workbenchTable").bootstrapTable('destroy');
							$("#workbenchTable").bootstrapTable({});
		
							// update the work set list
							if ($scope.workbenchValue == 'medicare') {
								$("#workbenchTable").bootstrapTable('load', response.data.workbenchLists);
								$scope.medicareWorkbench = response.data.workbenchLists;
							}
							else {
								$("#workbenchTable").bootstrapTable('load', response.data.workbenchMdcdLists);
								$scope.medicaidWorkbench = response.data.workbenchMdcdLists;
							}
		
		
		
							// hide the workbench portlet overlay
							$("#workbenchPanelBody").LoadingOverlay("hide");
		
							//show growl success message
							showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i>  List successfully renamed.', 'success');
		
						}).
							catch(function (err) {
								console.log("Rename List REST Error: " + err.status);
		
								// hide the workbench portlet overlay
								$("#workbenchPanelBody").LoadingOverlay("hide");
		
								showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Rename List failed due to ' + err.status, 'danger');
							});
					}
					else {
						$("#workbenchPanelBody").LoadingOverlay("hide");
		
						// show the warning message
						showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> An item with that name already exists. Please choose another name.', 'danger');
					}
				}).catch(function (err) {
						//hide full page overlay
						$("#workbenchPanelBody").LoadingOverlay("hide");
		
						// show growl message
						showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to validate list name due to ' + err.status, 'danger');
					});
			}

		}
	}

	// show the archive modal window
	$scope.viewArchiveModal = function(pListType) {
		console.log("Inside viewArchiveModal function.");
		
		$scope.archiveListType = pListType;
		
		// show the modal window
		$("#archiveWorkItemModal").modal("show");
		
		//apply the scope ng-binding changes to the display
		$scope.$apply();
	}

	// show the share list modal window 
	$scope.shareListItemClick = function() {
		console.log("Inside the shareListItemClick function. Row groupId = " + $scope.selectedRowGroupId);
		
		// show the full page overlay
		$.LoadingOverlay("show");
		
		// reset the form
		//document.getElementById("shareWorkSetForm").reset();
		//delete $scope.multiselect;
		
		// set the form to pristine
		$scope.shareUsersNotes = null;
		$scope.multiselect = null;
		$scope.multiselect_to = null;
		$scope.shareIdSearch = null;
//		$scope.shareWorkSetForm.$setPristine();
//		$scope.$apply();
		
		// clear all options from the available multiselect
		//$("#multiselect").empty();
		
		// call the web service required to get the list of shareable users
		if ($scope.selectedRowGroupId == void(0) || $scope.selectedRowGroupId == undefined || $scope.selectedRowGroupId == '') {
			// no group Id is defined, so set groupId to zero (0)
			$scope.selectedRowGroupId = '0';
		}
		if($scope.workbenchValue == 'medicare'){
			ipHomeFactory.getShareableUsersData($scope.restURL, $scope.uid, $scope.selectedRowGroupId, $scope.selectedRowId).success(function(data) {
				// get the list of available users to populate select component
				$scope.availableUsers = data.availableUsers;
				
				// loop through the available users and format entries
				for (i=0; i < $scope.availableUsers.length; i++) {
					// add the full name to the shareUserOptions array
					$scope.availableUsers[i].fullName = $scope.availableUsers[i].lastNm + ', ' + $scope.availableUsers[i].firstNm + ' (' + $scope.availableUsers[i].userId + ' - ' 
						+ $scope.availableUsers[i].jurisdiction + ')';
				}
				
				// assign the response to a scope variable used to populate the options
				$scope.shareUserOptions = data.sharedUsers;
				
				// loop through the shared users and format entries
				for (i=0; i < $scope.shareUserOptions.length; i++) {
					// add the full name to the shareUserOptions array
					$scope.shareUserOptions[i].fullName = $scope.shareUserOptions[i].lastNm + ', ' + $scope.shareUserOptions[i].firstNm + ' (' + $scope.shareUserOptions[i].userId + ' - ' 
						+ $scope.shareUserOptions[i].jurisdiction + ')';
				}
				
				console.log('# of available user = ' + $scope.availableUsers.length);
				console.log('# of shared user = ' + $scope.shareUserOptions.length);
				
				// loop through each option and remove the style attribute		
				$("#multiselect option").each(function() {
					console.log("option value = " + $(this).val());
					
					// add the user id to the temp array
					//$(this).removeAttr("style");
					$(this).removeAttr("disabled").show();
				});	
				
				// create temp array
	//			var tempArr = [];
							
				// build an array of users that should be selected by default
	//			for (i=0; i < $scope.shareUserOptions.length; i++) {
	//				if ($scope.shareUserOptions[i].sharedInd == 'Y') {
	//					tempArr.push($scope.shareUserOptions[i]);
	//				}
					
					// add the full name to the shareUserOptions array
	//				$scope.shareUserOptions[i].fullName = $scope.shareUserOptions[i].lastNm + ', ' + $scope.shareUserOptions[i].firstNm + ' (' + $scope.shareUserOptions[i].userId + ' - ' 
	//					+ $scope.shareUserOptions[i].jurisdiction + ')';
	//			}
				
				// show the share modal		
				$("#shareWorkItemModal").modal("show");
				
	//			$scope.shareUsersSelect = tempArr;
				
				// hide the full page overlay
				$.LoadingOverlay("hide");
				
				// refresh the screen
	//			$scope.$apply();
				
			}).catch(function(err) {
				console.log('getShareableUsersData REST Error:' + err.data);
				// hide the full page overlay
				$.LoadingOverlay("hide");
				
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load shareable users due to ' + err.data + ' error.', 'danger');		
			});

		}

		else{
			ipHomeFactory.getShareableMDCDUsersData($scope.restURL, $scope.uid, $scope.selectedRowGroupId, $scope.selectedRowId).success(function(data) {
				// get the list of available users to populate select component
				$scope.availableUsers = data.availableUsers;
				
				// loop through the available users and format entries
				for (i=0; i < $scope.availableUsers.length; i++) {
					// add the full name to the shareUserOptions array
					$scope.availableUsers[i].fullName = $scope.availableUsers[i].lastNm + ', ' + $scope.availableUsers[i].firstNm + ' (' + $scope.availableUsers[i].userId + ' - ' 
						+ $scope.availableUsers[i].jurisdiction + ')';
				}
				
				// assign the response to a scope variable used to populate the options
				$scope.shareUserOptions = data.sharedUsers;
				
				// loop through the shared users and format entries
				for (i=0; i < $scope.shareUserOptions.length; i++) {
					// add the full name to the shareUserOptions array
					$scope.shareUserOptions[i].fullName = $scope.shareUserOptions[i].lastNm + ', ' + $scope.shareUserOptions[i].firstNm + ' (' + $scope.shareUserOptions[i].userId + ' - ' 
						+ $scope.shareUserOptions[i].jurisdiction + ')';
				}
				
				console.log('# of available user = ' + $scope.availableUsers.length);
				console.log('# of shared user = ' + $scope.shareUserOptions.length);
				
				// loop through each option and remove the style attribute		
				$("#multiselect option").each(function() {
					console.log("option value = " + $(this).val());
					
					// add the user id to the temp array
					$(this).removeAttr("disabled").show();
				});	
				
			
				// show the share modal		
				$("#shareWorkItemModal").modal("show");
				
				// hide the full page overlay
				$.LoadingOverlay("hide");
				
				// refresh the screen
				
			}).catch(function(err) {
				console.log('getShareableMDCDUsersData REST Error:' + err.data);
				// hide the full page overlay
				$.LoadingOverlay("hide");
				
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load shareable users due to ' + err.data + ' error.', 'danger');		
			});
		}
		
	}

	// user wants to change the exclusion list private/public action
	$scope.pubPrivActnClick = function(pToggleVal) {
		console.log('Inside pubPrivActnClick. pToggleVal = ' + pToggleVal);
		
		// set a scope level variable for the toggle value
		$scope.pubPrivActnBool = pToggleVal;
		
		// show warning popup to the user
		$("#privPubActnModal").modal("show");
		
		//apply the scope ng-binding changes to the display
		$scope.$apply();
		
	}

	// view the criminal details popup
	$scope.viewCriminalModal = function(pNpi) {
		console.log('Inside viewCriminalModal function.');	
		
		//display the modal window
		$("#criminalModal").modal("show");
		
		// show the modal body overlay
		$("#criminalModalBody").LoadingOverlay("show");
		
		//initiate the modal table
		$("#criminalTable").bootstrapTable({});
		
		// call the web service to populate the criminal details table
		ipHomeFactory.getCriminalDetails($scope.restURL, pNpi, 'APS', $scope.uid).success(function(data) {
			// hide the modal body overlay
			$("#criminalModalBody").LoadingOverlay("hide");
			
			$("#criminalTable").bootstrapTable('load', data.responseData.aps);
		}).catch(function(err) {
			console.log('getCriminalDetails REST Error:' + err.data);
			
			// hide the modal body overlay
			$("#criminalModalBody").LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to show criminal details due to ' + err.data + ' error.', 'danger');		
		});
		
	}

	// handle user's subscription choice
	$scope.watchListSubscribe = function(pChoice) {
		console.log('watch list subscribe = ' + pChoice);
		
		// show button overlay
		$("#subscribeWatchList").LoadingOverlay("show");
		
		var actionVal;
		var subGrowlMsg;
		
		if (pChoice == 'yes') {
			actionVal = "NEW";
			subGrowlMsg = "Watch List subscribe successful.";
		} else {
			actionVal = "UNSUBSCRIBE";
			subGrowlMsg = "Watch List unsubscribe successful."
		}
		
		// call the web service to subscribe/unsubscribe the user
		ipHomeFactory.watchListSubscribe($scope.restURL, $scope.uid, actionVal, "APS").success(function(data) {
			// hide button overlay
			$("#subscribeWatchList").LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i> ' + subGrowlMsg, 'success');
		}).catch(function(err) {
			console.log('watchListSubscribe REST Error:' + err.data);
			
			// hide button overlay
			$("#subscribeWatchList").LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable subscribe/unsubscribe due to ' + err.data + ' error.', 'danger');		
		});
	}

	// this function opens the asr details screen in a separate window
	$scope.asrDetailWindowOpen = function(pAsrId) { 
		
		// open up the details page
		$window.open("#ASRDetails?asrDetailsParam=" + pAsrId);
	}

	// user clicked the modal button to update the private/public action
	$scope.pubPrivActnModalBtn = function() {
		console.log('Inside pubPrivActnModalBtn.');
		
		// show the button overlay
		$("#updateActnsBtn").LoadingOverlay("show");
		
		// translate the public/private indicator to boolean value
		var privPubBool;
		
		if ($scope.pubPrivActnBool == 'N') {
			privPubBool = 'true';
		} else {
			privPubBool = 'false';
		}
		
		// call the web service to update the public/private action
		ipHomeFactory.updatePubPrivAction($scope.restURL, $scope.uid, privPubBool).success(function(data) {
			// update the workbench table with the response
			
			// reload workbench items
			$("#workbenchTable").bootstrapTable('load', data.workbenchLists);
			
			// hide the button overlay
			$("#updateActnsBtn").LoadingOverlay("hide");
			
			//show growl success message
			showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i> Exclusion Set visibility successfully updated.', 'success');
			
			// close the modal window
			$("#privPubActnModal").modal("hide");
		}).catch(function(err) {
			console.log('updatePubPrivAction REST Error:' + err.data);
			
			// hide the button overlay
			$("#updateActnsBtn").LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to update Exclusion Set visibility due to ' + err.data + ' error.', 'danger');		
		});
	}

	// archive button has been pressed in the archive WS modal
	$scope.archiveWorkSet = function() {
		// show modal button overlay
		$("#archiveModalBtn").LoadingOverlay("show");
		
		console.log('Inside deleteWorkSet. Work Item ID = ' + $scope.selectedRowId
				+ ', Group ID = ' + $scope.selectedRowGroupId);
		
		// call the web service to archive the work item
		ipHomeFactory.archiveWorkItem($scope.restURL, $scope.uid, $scope.selectedRowId, $scope.selectedRowGroupId).success(function(data) {
			
			// hide modal button overlay
			$("#archiveModalBtn").LoadingOverlay("hide");
			
			// show the workbench portlet overlay
			$("#workbenchPanelBody").LoadingOverlay("show");
			
			// reload workbench items
			if($scope.workbenchValue == 'medicare'){
				$("#workbenchTable").bootstrapTable('load', data.workbenchLists);
				$scope.medicareWorkbench = data.workbenchLists;
			}
			else{
				$("#workbenchTable").bootstrapTable('load', data.workbenchMdcdLists);
				$scope.medicaidWorkbench = data.workbenchMdcdLists;
			}
			
			// hide the workbench portlet overlay
			$("#workbenchPanelBody").LoadingOverlay("hide");
			
			// hide the rename work item modal		
			$("#archiveWorkItemModal").modal("hide");
			
			//show growl success message
			showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i> List successfully archived.', 'success');
			
		}).catch(function(err) {
			console.log('archiveWorkItem REST Error:' + err.data);
			
			// hide modal button overlay
			$("#archiveModalBtn").LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to archive item due to ' + err.data + ' error.', 'danger');		
		});
	}

	// delete button has been pressed in the delete WS modal
	$scope.deleteWorkSet = function() {
		console.log('Inside deleteWorkSet. ID = ' + $scope.selectedRowId);
		var listType;
		
		// set the group type
		if ($scope.selectedRowType == 'Working Set') {
			listType = 'asr';
		} else {
			listType = 'search';
		}
		
		// call the web service to delete the working set
		ipHomeFactory.deleteWorkItem($scope.restURL, $scope.uid, $scope.selectedRowId, listType).success(function(data) {
			// show the workbench portlet overlay
			$("#workbenchPanelBody").LoadingOverlay("show");
			
			// reload workbench items
			if($scope.workbenchValue == 'medicare'){
				$("#workbenchTable").bootstrapTable('load', data.workbenchLists);
				$scope.medicareWorkbench = data.workbenchLists;
			}
			else{
				$("#workbenchTable").bootstrapTable('load', data.workbenchMdcdLists);
				$scope.medicaidWorkbench = data.workbenchMdcdLists;
			}
			
			
			// hide the workbench portlet overlay
			$("#workbenchPanelBody").LoadingOverlay("hide");
			
			//show growl success message
			showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i> List successfully deleted.', 'success');
		}).catch(function(err) {
			console.log('deleteWorkItem REST Error:' + err.data);
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to delete list due to ' + err.data + ' error.', 'danger');		
		});
		
		// hide the rename work item modal		
		$("#deleteWorkSetModal").modal("hide");
		
		 
	}

	// user is submitting the form from the share with users modal
	$scope.shareModalSubmit = function() {
		console.log("Inside the shareModalSubmit function.");
		
		// check to see if the multiselect_to select box is empty
		console.log("mutliselect_to options length = " + $("#multiselect_to option").length); 
		
		// show submit button overlay
		$("#shareSubmitBtn").LoadingOverlay("show");
		
		// create an array of the share group user ids
		var shareGroupArr = [];
		
		// set the group type
		if ($scope.selectedRowType == 'Working Set' || $scope.selectedRowType == 'Exclusion Set') {
			$scope.groupType = 'asr';
		} else {
			$scope.groupType = 'search';
		}
		
		if ($("#multiselect_to option").length == 0) {
			// user unselected or didn't select users to share with 
			
			// do nothing - keep the array empty
		} else {
			// user is wanting to share with the chosen users
			
			// loop through the multiselect_to field to get the user id's
			$("#multiselect_to option").each(function() {
				console.log("option value = " + $(this).val());
				
				// add the user id to the temp array
				shareGroupArr.push($(this).val());
			});			
			
		}
		
		// call the web service to share the work item
		ipHomeFactory.shareToGroup($scope.restURL, $scope.uid, $scope.selectedRowGroupId, shareGroupArr, $scope.selectedRowId, $scope.shareUsersNotes, $scope.groupType).success(function(data) {
			
			// hide the submit button overlay
			$("#shareSubmitBtn").LoadingOverlay("hide");
			
			// hide the share modal		
			$("#shareWorkItemModal").modal("hide");	
			
			//show growl success message
			showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i>  List share preference successfully updated.', 'success');
			
		}).catch(function(err) {
			console.log('shareToGroup REST Error:' + err.data);

			// hide the submit button overlay
			$("#shareSubmitBtn").LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load shareable users due to ' + err.data + ' error.', 'danger');		
		});
		
		// dirty the form since it's been submitted
//		$scope.shareWorkSetForm.$setDirty();
		
/*		if ($scope.shareWorkSetForm.$invalid) {
			// process response
			console.log('Invalid - Don\'t process.');
		} else {
			// show modal body overlay
			$("#shareWorkItemModalBody").LoadingOverlay("show");
			
			// process response
			console.log('Valid - Process. ' + JSON.stringify($scope.multiselect_to));
			
			// create an array of the share group user ids
			var shareGroupArr = [];
			
			for (i=0; i < $scope.multiselect_to.length; i++) {
				shareGroupArr.push($scope.multiselect_to[i].userId);
			}
			
			// set the group type
			if ($scope.selectedRowType == 'Working Set') {
				$scope.groupType = 'asr';
			} else {
				$scope.groupType = 'search';
			}
			
			// call the web service to share the work item
			ipHomeFactory.shareToGroup($scope.restURL, $scope.uid, $scope.selectedRowGroupId, shareGroupArr, $scope.selectedRowId, $scope.shareUsersNotes, $scope.groupType).success(function(data) {
				
				// hide modal body overlay
				$("#shareWorkItemModalBody").LoadingOverlay("hide");
				
				// hide the share modal		
				$("#shareWorkItemModal").modal("hide");	
				
				//show growl success message
				showGrowl('<i class=\'fa fa-check-circle\' aria-hidden=\'true\'></i>  List successfully shared.', 'success');
				
			}).catch(function(err) {
				console.log('shareToGroup REST Error:' + err.data);

				// hide modal body overlay
				$("shareWorkItemModalBody").LoadingOverlay("hide");
				
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load shareable users due to ' + err.data + ' error.', 'danger');		
			});
		}  */
	}

	// show the reports favorite modal window
	$scope.showReportFavs = function () {
		localStorage.setItem('lastFocusedId', document.activeElement.id);
		// show modal overlay
		$("#reportFavPanel").LoadingOverlay("show");
		
		// call the reports service to get favorites 		
		ipHomeFactory.getReportFavsData($scope.restURL, $scope.uid, $scope.oldOrganizationVal).success(function(data) {
			// display the the report favorites window
			$("#reportFavsModal").modal("show");
			
			// initiate the report favorites 
			$("#reportFavsModalTable").bootstrapTable('destroy');
			$("#reportFavsModalTable").bootstrapTable({});			
			
			// load the table with the response data
			$('#reportFavsModalTable').bootstrapTable('load', data.reports);
		//	$("#reportFavsModalTable").bootstrapTable('resetView');
			$("#reportFavsModalTable").parent().attr('style', 'margin-left:1px !important;');
			
			// create an array to hold the row values that should have a checked checkbox
			var valuesArray = [];
			
			// loop through the response and build the checkbox array
			for (i=0; i < data.reports.length; i++) {
				if (data.reports[i].checked == 'true') {
					valuesArray.push(data.reports[i].rptNm);
				}
			}
			
			console.log("values array = " + JSON.stringify(valuesArray));
			
			// check the correct checkboxes
			$('#reportFavsModalTable').bootstrapTable('checkBy',{field: 'rptNm', values: valuesArray});
						
			// hide the overlay spinner
			$("#reportFavPanel").LoadingOverlay("hide");
		}).catch(function(err) {
			console.log('getReportFavsData REST Error:' + err.data);
			// hide the overlay spinner
			$("#reportFavPanel").LoadingOverlay("hide");
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load report favorites due to ' + err.data + ' error.', 'danger');		
		});
	}

	// user chose to submit report favorite preferences from the report favorites modal window
	$scope.reportFavsModalBtnClick = function() {
		console.log('Inside reportFavsModalBtnClick.');
		
		// show the modal body overlay
		$('#reportFavsModalBody').LoadingOverlay("show");
		
		// get the checkbox values
		$scope.rptFavsTableSelections = $('#reportFavsModalTable').bootstrapTable('getSelections');
		
//		console.log("Report favs selections = " + JSON.stringify($scope.rptFavsTableSelections));
		
		// create an array to hold the selected preferences		
		var reportFavSelectedArray = [];
		
		// check to see if user selected at least one ASR from summary table
		if($scope.rptFavsTableSelections.length > 0) {
			// loop through the selections to build preferences array
			for (i=0; i < $scope.rptFavsTableSelections.length; i++) {
				reportFavSelectedArray.push($scope.rptFavsTableSelections[i].rptId);
			}
			
			console.log("reportFavSelectedArray = " + JSON.stringify(reportFavSelectedArray));
			
			// save the chosen report favorites
			ipHomeFactory.saveUserPreferences($scope.restURL, $scope.uid, "landingPageReports", JSON.stringify(reportFavSelectedArray)).then(function(response) {
				//hide full page overlay
				$('#reportFavsModalBody').LoadingOverlay("hide");
				
				// present message to user stating that preferences have been saved
				showGrowl('<i class=\'fa fa-info-circle\' aria-hidden=\'true\'></i> Report favorites have been saved.', 'info');	
				
				// prepare for refresh by hiding the modal window 				
				$("#reportFavsModal").modal("hide");
				
				// refresh the landing page to show the updated report list				
				window.location.reload();
								
			}).catch(function(err){ 
				// hide full page overlay
				$('#reportFavsModalBody').LoadingOverlay("hide");			
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Report favorites not saved due to ' + err.status, 'danger');
			});
			
		} else {
			// hide full page overlay
			$('#reportFavsModalBody').LoadingOverlay("hide");	
			
			// remind the user to make at least one choice
			showGrowl('<i class=\'fa fa-info-circle\' aria-hidden=\'true\'></i> Please select at least one report.', 'info');
		}
	}

	//scope variable to handle click events for the inactive/decommissioned tab 
	$scope.inactvModelTabClick = function() {
		console.log('Inside inactvModelTabClick function.');
		
		//destroy, initialize, populate the Inactive/Decommissioned Models table
		$("#inactvModelsModalTable").bootstrapTable('destroy');
		$("#inactvModelsModalTable").bootstrapTable({});
		if($scope.asrvalue == 'medicare'){
			$("#inactvModelsModalTable").bootstrapTable('load', $scope.indexData.nonActiveModels);
		}
		else{
			$("#inactvModelsModalTable").bootstrapTable('load', $scope.indexData.nonActiveModelsMdcd);  
		}
		
	}

	// show the Edits Info Modal
	$scope.showEditsInfoModal = function() {
		console.log('Inside showEditsInfoModal function.');
		
		//initialize the active and inactive table			
		$('#activeEditInfoTable').bootstrapTable({});		
		$('#inactvEditInfoTable').bootstrapTable({});
				
		// show the edit info modal window
		$("#editInfoModal").modal("show");
		
		// show the modal body overlay
		$("#editInfoModalBody").LoadingOverlay("show");
		
		// get the all claims info from the web services
		ipHomeFactory.getEditInfo($scope.restURL, $scope.uid).success(function(data) {	
			
			// populate the active tab
			$("#activeEditInfoTable").bootstrapTable('load', data.activeEditInfos);
			
			//populate the inactive tab
			$("#inactvEditInfoTable").bootstrapTable('load', data.inactiveEditInfos);
						
			// hide the modal body overlay
			$("#editInfoModalBody").LoadingOverlay("hide");
			
		}).error(function(data, status) {
			console.log('Edit Info REST Error:' + status);
			
			// hide the modal body overlay
			$("#editInfoModalBody").LoadingOverlay("hide");
			
			//alert('Error:  A Lead was not created due to ' + status);
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Cannot retrieve edit information due to ' + status, 'danger');
		});
	}

	//show Model Info Guides Modal 
	$scope.showAllModelDetails = function() {
//		console.log('Inside showModelInfoGuides function.');
		//show modal window
		$("#modelsModal").modal("show");		
		//destroy, and then initiate the modal table
		$("#modelsModalTable").bootstrapTable('destroy');	
		$("#modelsModalTable").bootstrapTable({});
		
		//load the models table with 
		if($scope.asrvalue == 'medicare'){
			$("#modelsModalTable").bootstrapTable('load', $scope.medicaremodel);
			$(".mdcrCadence").css('display', 'block')
			$(".mdcdCadence").css('display', 'none')
		}
		else{
			$("#modelsModalTable").bootstrapTable('load', $scope.medicaidmodel);
			$(".mdcrCadence").css('display', 'none')
			$(".mdcdCadence").css('display', 'block')
		}
		
	}
	

	// listen for the skip nav link scope broadcast
	$scope.$on('skipNavEvent', function() {
		console.log('skipNavEvent detected!');
		
		// set the focus on the workbench panel
		$("#workBenchPanelHead").focus();
	});
	
	$scope.loadDocument = function(pURL) {
		console.log("Inside ipHomeFactory.loadDocument");
		var queryString = pURL.substring(pURL.lastIndexOf('?')+1, pURL.length-1);
		var urlParams = new URLSearchParams(queryString);
		if (!urlParams.get("userId")){
			pURL+="&userId="+$scope.uid;
		}
		console.log($scope.uid);
		// broadcast this event to the reset session listener
		$rootScope.$broadcast("factoryMethodCalled");
		config = {};

		ipHomeFactory.loadDocument(pURL).success(function(response) {	
		
		}).catch(function(err) {
			console.log('loadDocument REST Error:' + err.data);			
		});;
		
	
		console.log('loadDocument REST request = ' + jsonData);
    		    		
    		
    };
	
	
}]);
	
//define a factory to perform REST functionality
appIpHome.factory('ipHomeFactory', ['$http', '$rootScope','$q', function($http, $rootScope, $q) {	
	
	return {
		getLandingPageData: function(pURL, pUserId, pUserZone, pRequestId) {
 //   		console.log("Inside ipHomeFactory.getLandingPageData");
 
    		//create the json request object
    		var entryCriteria = {
    				userId: pUserId,
    				userZone: pUserZone,
    				requestId: pRequestId
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		    		
    		return $http.post(pURL + '/rest/portal/queryLandPageData', jsonData);
    	},
    	getReportFavsData: function(pURL, pUserId, pUserZone) {
    		console.log("Inside caseMgmtFactory.getReportFavsData.  pUserId = " + pUserId + ", pUserZone = " + pUserZone);
    		
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			userZone: pUserZone,
    			userId: pUserId
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getReportFavsData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/reportFavorites', jsonData);
    	},
    	saveUserPreferences: function(pURL, pUserId, pPrefName, pPrefJson) {
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			prefName: pPrefName,
    			prefJson: pPrefJson
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('saveUserPreferences REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/saveUserPrefs', jsonData);
    	},
    	getWorkItemsData: function(pURL,pUserId, listType) {
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {
    			userId: pUserId
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    	//	console.log('saveUserPreferences REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/workItems?listType=' + listType , jsonData);
    	},
    	renameList: function(pURL, pUserId, pListId, pListName, pListType) {
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// build the fpsPrioritizationList list object
    		var fpsPrioritizationListObj = {
				audtInsrtId: pUserId, 	
    			listNm: pListName,
    			prioritizationListId: pListId,
    			listType: pListType
    		}
    		
    		// create the json request object
    		var entryCriteria = {
    			fpsPrioritizationList: fpsPrioritizationListObj
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    	//	console.log('renameList REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/renameList', jsonData);
    	},
    	getShareableUsersData: function(pURL, pUserId, pGroupId) {
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			groupId: pGroupId
    		};
    		
       		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    	//	console.log('renameList REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/shareableUsers', jsonData);
    	},
		getShareableMDCDUsersData: function(pURL, pUserId, pGroupId) {
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			groupId: pGroupId
    		};
    		
       		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    	//	console.log('renameList REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/shareableMDCDUsers', jsonData);
    	}, 
    	shareToGroup: function (pURL, pUserId, pGroupId, pGroupArr, pListId, pGroupComments, pGroupType) {
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		var prioritizationShareGrp = {
				grpId: pGroupId,
    			userIds: pGroupArr,
    			grpType: pGroupType,
    			listId: pListId,
    			grpTxt: pGroupComments
    		}
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId,
    			prioritizationShareGrp: prioritizationShareGrp
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/shareToGroup', jsonData);
    	},
    	deleteWorkItem: function(pURL, pUserId, pListId, pListType) {
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
				userId: pUserId,    			
    			listId: pListId,
    			listType: pListType
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/deleteList', jsonData);
    	}, 
    	archiveWorkItem: function (pURL, pUserId, pListId, pGroupId){
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
				userId: pUserId,    			
    			listId: pListId,
    			groupId: pGroupId
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/archiveList', jsonData);
    	},
    	updatePubPrivAction: function(pURL, pUserId, pActnBool) {
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
				userId: pUserId,    			
    			actionBool: pActnBool
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		
    		return $http.post(pURL + '/rest/portal/updateExListAction', jsonData);
    	},
    	getCriminalDetails: function(pURL, pAsrId, pSearchType, pUserId) {
    		console.log("Inside ipHomeFactory.getCriminalDetails.  pUrl = " + pURL + ". pAsrId = " + pAsrId);
    		
    		//create the json request object
    		var entryCriteria = {
    			asrId: pAsrId,
    			userId: pUserId,
    			searchType: pSearchType
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getASRDetailsData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/asrDetails', jsonData);
    	},
    	watchListSubscribe: function(pURL, pUserId, pAction, pEvent) {
    		console.log("Inside ipHomeFactory.watchListSubscribe.");
    		
    		//create the json request object
    		var entryCriteria = {
    			action: pAction,
    			systemID: pUserId,
    			event: pEvent
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getASRDetailsData REST request = ' + jsonData);
    		
    		return $http.post(pURL + '/rest/portal/subscribe', jsonData);
    	},
		getEditInfo: function (pURL, pUserId) {
    		console.log("Inside ipHomeFactory.getEditInfo");
    		
    		// broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		// create the json request object
    		var entryCriteria = {
    			userId: pUserId
    		};
    		
    		// create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getEditInfo REST request = ' + jsonData);
    		    		
    		return $http.post(pURL + '/rest/portal/editInfoIndex', jsonData); 
    	},
		loadDocument: function(pURL) {
			console.log("Inside ipHomeFactory.loadDocument");
			
			// broadcast this event to the reset session listener
			$rootScope.$broadcast("factoryMethodCalled");
			config = {};
			
			$http.get(pURL,{ responseType: 'arraybuffer' }).then(function (response) {
				console.log("response " + response);

				var a = document.createElement("a");
				document.body.appendChild(a);
				a.style = "display: none";
				a.target = "_blank";
				//console.log(response.headers());
				var blobFileName = "";
				//var headerVal = response.headers('Content-Disposition');
				//if (headerVal){
				//	 headerVal.substring(headerVal.lastIndexOf('=')+1, headerVal.length-1);
				//}else{
					
					var queryString = pURL.substring(pURL.lastIndexOf('?')+1, pURL.length-1);
					var urlParams = new URLSearchParams(queryString);
					blobFileName = urlParams.get("fileName");
					//blobFileName= blobFileName.replace("\"", "");
				//}
				//var queryString = pURL.substring(pURL.lastIndexOf('?')+1, pURL.length-1);
				//var urlParams = new URLSearchParams(queryString);
				//var blobFileName = urlParams.get("fileName");
				//blobFileName= blobFileName.replace("\"", "");
				console.log(blobFileName);

				var contentType = response.headers('Content-Type');
				if (!contentType){
					contentType = "application/pdf";
				}
				console.log("contentType = " + contentType);

				var binaryData = response.data;
				if (navigator.msSaveBlob){
					//IE Browsers
					navigator.msSaveBlob(blob, blobFileName);
				} else {

				
					var blob = new Blob([binaryData], {type: contentType})
					var u = URL.createObjectURL(blob);
					a.href = u;
					a.download = blobFileName;
					a.click();
					URL.revokeObjectURL(u);
				}
		
			}).catch(function(e) {
				console.log('Error: ', e);
				throw e;
			});
			console.log('loadDocument REST request = ' + jsonData);
    		    		
    		
		},
		getAllLandingPageData: function (pURL, pUserId, pZone) {
			var workItems = {};
			var landingPage = {};
			var deferred = $q.defer();
			let landingPageChain = {
				dataWorkbench: this.getWorkItemsData(pURL, pUserId, "WORKING"),
				dataLanding: this.getLandingPageData(pURL, pUserId, pZone)
			}
			$q.all(landingPageChain).then((values) => {
				workItems = values.dataWorkbench;
				landingPage = values.dataLanding;
				var resp = {dataWorkbench: workItems.data, dataLanding: landingPage.data};
				deferred.resolve(resp);
			});
			return deferred.promise;
		}
	
    	
	}
}]);

