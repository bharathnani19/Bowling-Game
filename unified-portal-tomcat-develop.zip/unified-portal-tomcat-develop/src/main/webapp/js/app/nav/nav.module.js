/**
 *   This is the module (controller) declaration for the Unified Portal Navigation screen (LandingPageNav.html)
 */
var appNav = angular.module('nav.module', ['ngRoute', 'ngCookies', 'ngSanitize', 'oc.lazyLoad']);

appNav.config(["$routeProvider", function ($routeProvider) {

	$routeProvider.when("/IPHome", {
		templateUrl: "iphome.html",
		resolve: {
			redirectToModernInvestigative: function ($window) {
				$window.location.replace($window.location.origin + '/FPS2UnifiedPortal/Investigative');
			},
			showNavResolve: function ($rootScope) {
				$rootScope.showNav = true;
			}
		}
	}).when("/Index", {
		templateUrl: "index.html",
		controller: "indexController",
		resolve: {
			redirectToModernIndex: function ($window) {
				$window.location.replace($window.location.origin + '/FPS2UnifiedPortal/');
			},
			showNavResolve: function ($rootScope) {
				$rootScope.showNav = false;
			}
		}
	}).when("/Administration", {
		templateUrl: "administration.html",
		resolve: {
			loadAdminModule: function ($ocLazyLoad) {
				return $ocLazyLoad.load('js/app/admin/admin.module.js');
			},
			showNavResolve: function ($rootScope) {
				$rootScope.showNav = true;
			}
		}
	}).when("/CaseManagement", {
		templateUrl: "case-mgmt.html",
		resolve: {
			redirectToModernTriage: function ($window) {
				$window.location.replace($window.location.origin + '/FPS2UnifiedPortal/Investigative/Triage');
			},
			showNavResolve: function ($rootScope) {
				$rootScope.showNav = true;
			}
		}
	}).when("/ASRDetails", {
		templateUrl: "asr-details.html",
		resolve: {
			redirectToModernDetails: function ($window) {
				$window.location.replace($window.location.origin + '/FPS2UnifiedPortal/Investigative/Details');
			},
			showNavResolve: function ($rootScope) {
				$rootScope.showNav = true;
			}
		}
	}).otherwise({
		redirectTo:'/Index'
	})

}]);

appNav.controller("navController", ['$scope', '$location', '$rootScope', '$interval', '$timeout','$cookies', '$http', '$routeParams', 'navFactory', 'utilService', 'utilFactory',  '$ocLazyLoad', '$http',
                                    function ($scope, $location, $rootScope, $interval, $timeout, $cookies, $http, $routeParams, navFactory, utilService, utilFactory,$ocLazyLoad, $http) {
	
	// required okta config


	// create a new okta auth instance from the util method
	var authClient = utilService.setOktaAuth();

	console.log('Inside the navController. AuthClient = ' + authClient);

	//console.log('authClient.isLoginRedirect = ' + authClient.isLoginRedirect());
	
	// check to see if the user is logged-in by calling isLoginRedirect
	if (authClient.isLoginRedirect()) {
			console.log('Inside the navController. isLoginRedirect ');

		// start the authClient as a service to support enable certain token features
		authClient.start();

		// Successful redirect from Okta login page, so parse token from redirect url
		authClient.token.parseFromUrl()
			.then(data => {
				
			const { idToken } = data.tokens;
			const { accessToken } = data.tokens; 
			//console.log(`Hi ${idToken.claims.preferred_username}!`);

			var state = data.state; // passed to getWithRedirect(), can be any string
			console.log('state from LoginRedirect = ' + state);
					
			// Store parsed token in Token Manager
			authClient.tokenManager.add('idToken', idToken);
			authClient.tokenManager.add('accessToken', accessToken);
			console.log(idToken);
			console.log(accessToken);		    
			console.log('Inside the navController. recordLogin ');

			recordLogin(idToken);		
			// call the showPageContents function
			showPageContents(idToken);

		})
		.catch(function(err) {
			// handle OAuthError
			console.log('parseFromUrl error: ' + err);

			// parse error could be from opening a new tab/window, so check for valid token
			// Attempt to retrieve ID Token from Token Manager
			authClient.tokenManager.get('idToken')
			.then(idToken => {
				console.log('parseURL error, but user has a token - ' + idToken);

				// display navigation bar
				// call the showPageContents function
				showPageContents(idToken);
			})
		});
	} else {
		// User is logged-in but was not redirected from login page	
			console.log('Inside the navController. not redirected ');
		// Attempt to retrieve ID Token from Token Manager
		authClient.tokenManager.get('idToken')
			.then(idToken => {
				console.log(idToken);
				if (idToken) {
					
					//console.log(`Hi ${idToken.claims.email}!`);
					console.log("location = " + window.location.href);
					
					// call the showPageContents function
					showPageContents(idToken);
					
				} else {
					// You're not logged in, you need a sessionToken
					console.log('User is not logged-in and does not have a token... redirect to login screen');
					authClient.token.getWithRedirect({
						responseType: ['token', 'id_token'],
						state: 'token-from-redirect '
					})
					.catch(function(err){
						console.log('getWithRedirect error: ' + err);
					});
				}
			})
		}
		// sends the login to Splunk
	recordLogin= function(pIdToken) {
			utilFactory.getURLPropertyFromFile().then(function(response) {
					//declare a scope level variable for the URL used to make REST web service calls 
				$scope.restURL = response.data;			
	    		console.log("Inside .recordLogin "+pIdToken);
	    		var groupsArray = pIdToken.claims.groups;
	    		var role = '';
	    		var zone = '';
	    		var attrs = [];
	    		for (i = 0; i < groupsArray.length; i++) {
					console.log('group - ' + groupsArray[i]);
					var groupObj = groupsArray[i];
	
					// populate role array
					if (groupObj.search('FPSUI Role') != -1) {
						role = groupObj.replace("FPSUI Role", "").trim();
					}
	
					// populate the zone Array
					if (groupObj.search('FPSUI Zone') != -1) {
						zone = groupObj.replace("FPSUI Zone", "").trim();
					}
	
					// populate the attributes Array
					if (groupObj.search('FPSUI Attrib') != -1) {
						attrs.push(groupObj.replace("FPSUI Attrib", "").trim());
					}
				}
	    	
	    		//create the json request object
	    		var entryCriteria = {
	    			email: pIdToken.claims.email,
					firstNm: pIdToken.claims.first_name,
					lastNm: pIdToken.claims.last_name,
					userId: pIdToken.claims.preferred_username,
					role:  role,
					zone: zone,
					attributes: attrs,
					system: "UP"
	    		};
	    		  		
	    		//create the JSON object to be used in the REST Request
	    		jsonData = JSON.stringify(entryCriteria);
	    		console.log('recordLogin REST request = ' + jsonData);
	    		
	    		//make the rest web service call to log the data
	    		$http.post($scope.restURL + '/rest/portal/record', jsonData);
	    		console.log('done recordLogin REST request = ' + jsonData);
    		});
    	}
	// this function shows the page to users that have been authenticated via Okta
	showPageContents = function(pIdToken) {
		if (pIdToken) {
			
			// start a check for valid session idle time every 60 seconds. 
			// session should not be refreshed, so first param = false
			//reset the interval to be as close to the beginning of the session reset as possible
			//$interval.cancel($scope.intervalVar);					
			getSessionIdleTimeCheck('true');

			// parse the group claim array from the token
			// loop through the array to parse all of the values from the array						
			$scope.rolesArray = [];
			$scope.userAttrArray = [];
			$scope.zonesArray = [];
			var groupsArray = [];
			$scope.uid = pIdToken.claims.preferred_username;
			if (pIdToken.claims.groups != void(0) && pIdToken.claims.groups != null) {
				groupsArray = pIdToken.claims.groups;
			}				
			
			$scope.trainingUrl = utilService.getTrainingUrl();
			$scope.editsandModelsLifecycleUrl = utilService.getEditsandModelsLifecycleUrl();
			var environment = utilService.getEnvironment();
			
			console.log('groupsArray =  ' + groupsArray);

			for (i = 0; i < groupsArray.length; i++) {
				console.log('group - ' + groupsArray[i]);
				var groupObj = groupsArray[i];

				// populate role array
				if (groupObj.search('FPSUI Role') != -1) {
					$scope.rolesArray.push(groupObj.replace("FPSUI Role", "").trim());
				}

				// populate the zone Array
				if (groupObj.search('FPSUI Zone') != -1) {
					$scope.zonesArray.push(groupObj.replace("FPSUI Zone", "").trim());
				}

				// populate the attributes Array
				if (groupObj.search('FPSUI Attrib') != -1) {
					$scope.userAttrArray.push(groupObj.replace("FPSUI Attrib", "").trim());
				}
				
				// populate the attributes Array
				if (groupObj.search('FPSUI EML') != -1) {
					$scope.userAttrArray.push(groupObj.replace("FPSUI", "").trim());
				}
			}

			// if the user has a role, then let them proceed, else redirect them to UM
			if ($scope.rolesArray == null || $scope.rolesArray.length == 0) {
				console.log("User does NOT have a role... redirect to UM.");
				//call the global utilFactory method to get the URL for the current environment
				utilFactory.getURLPropertyFromFile().then(function(response) {
					// redirect to the User Management URL
					window.location = response.data.substring(0, response.data.lastIndexOf("/")+1) + "UserManagement/";
				}).catch(function(err) {
					console.log('getURLPropertyFromFile REST Error:' + err.data);						
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load system data due to ' + err.data, 'danger');		
				});
				
			} else {
				console.log("User has a role... load navigation bar info.");
				// user has a role so proceed to load the navigation bar
				// valid token... proceed to load navigation bar			

				// show the navbar Dom objects
				$('#navbar').removeAttr('hidden');
				
				//retrieve the Reports URL from the Util service	
				$scope.ReportsUrl = utilService.getReportsUrl();		
				
				//call the global utilFactory method to get the URL for the current environment
				utilFactory.getURLPropertyFromFile().then(function(response) {
					//declare a scope level variable for the URL used to make REST web service calls 
					$scope.restURL = response.data;			
					console.log('Setting REST URL = ' + $scope.restURL);
					
					
					
					
					//build the URL used for the User Management link 		
					$rootScope.umLinkUrl = $scope.restURL.substring(0, $scope.restURL.lastIndexOf("/")+1) + "UserManagement/#/userprofile"; 
					$rootScope.unifiedportalURL = $scope.restURL.substring(0, $scope.restURL.lastIndexOf("/")+1) + "unified-portal/#/Index"; 
					//build the URL used for the Vulnerability Management link
					$scope.VMUrl = $scope.restURL.substring(0, $scope.restURL.lastIndexOf("/")+1) + "VulnerabilityManagement/"; 
					// build the URL to the user support portal
					$scope.supportUrl = $scope.restURL.substring(0, $scope.restURL.lastIndexOf("/")+1) + "UserSupportPortal/index.html"; 
											
							
							
							// extract the user info from the okta id token
							$scope.scopeUserId = pIdToken.claims.preferred_username;
							$scope.fullName = pIdToken.claims.name;
							$scope.rolesStr = $scope.rolesArray.toString();
							$rootScope.rolesStr = $scope.rolesStr;
							$scope.oldOrganizationVal = $scope.zonesArray[0];
							
							// map old org values to new org values
							if($scope.oldOrganizationVal == 'UPIC 1') {
								$scope.organization = 'UPIC MW';
							} else if($scope.oldOrganizationVal == 'UPIC 2') {
								$scope.organization = 'UPIC NE';
							} else if($scope.oldOrganizationVal == 'UPIC 3') {
								$scope.organization = 'UPIC W';
							} else if($scope.oldOrganizationVal == 'UPIC 4') {
								$scope.organization = 'UPIC SW';
							} else if($scope.oldOrganizationVal == 'UPIC 5') {
								$scope.organization = 'UPIC SE';
							} else {
								$scope.organization = $scope.oldOrganizationVal;
							}
							$rootScope.organization = $scope.organization;
							
							console.log('scopeUserId = ' + $scope.scopeUserId);
							console.log('fullname = ' + $scope.fullName);
							console.log("user attributes array = " + $scope.userAttrArray.toString());	
							
							if ($scope.rolesArray.indexOf("MAC") > -1 || $scope.zonesArray.indexOf("MEDIC") > -1){
								$scope.showAsrDefault = false;
							}else{
								$scope.showAsrDefault = true;
							}
							
							//if the user attributes array is not empty, then display attributes					
							//return user attributes to the DOM
							console.log("user attributes array size = " + $scope.userAttrArray.length);
							if ($scope.userAttrArray.length > 0) {
								//display the attributes component
								$scope.showAttributes = true;
								//set the value of the attributes field
								$scope.attributes = $scope.userAttrArray.toString();
								$rootScope.attributes = $scope.attributes;
							} else {
								//don't display the attributes component
								$scope.showAttributes = false;
							}
							
							// user management approver link is only accessible to approvers
							if ($scope.userAttrArray.indexOf("Master Approver") != -1 || $scope.userAttrArray.indexOf("DMA Approver") != -1  
								|| $scope.userAttrArray.indexOf("MAC Approver") != -1 || $scope.userAttrArray.indexOf("IO Approver") != -1 || $scope.rolesArray.indexOf("Admin") != -1) {
								
								console.log("User is an Approver... so show the User Management link.");
								$('#umApproverLink').removeClass('hidden');
								$scope.umApprvrLinkUrl = $scope.restURL.substring(0, $scope.restURL.lastIndexOf("/")+1) + "UserManagement/#/list";
							} else {
								console.log("****** NOT Showing UM Link ******");
							}
							if ($scope.rolesArray.indexOf("Admin")!= -1){
								$ocLazyLoad.load('js/app/admin/admin.module.js');

							}else{
								$ocLazyLoad.load('js/app/nav/base.module.js');
							}
							
							// only show the VM link to Admin users, InquiryOnly users with (vm-admin, vm-read, vm-create, vm-update-edit),
							// PrioritizeSup users with (vm-read, vm-create), MAC users with (vm-read, vm-create)
							if ($scope.rolesArray.indexOf("Admin") != -1 
									|| ( $scope.rolesArray.indexOf("Inquiry Only") != -1 && ($scope.userAttrArray.indexOf("VM Admin") != -1  || $scope.userAttrArray.indexOf("VM Read") != -1  || $scope.userAttrArray.indexOf("VM Create") != -1  || $scope.userAttrArray.indexOf("VM Update Edit") != -1 )) 
									|| ( $scope.rolesArray.indexOf("Prioritize Sup") != -1 && ($scope.userAttrArray.indexOf("VM Read") != -1 || $scope.userAttrArray.indexOf("VM Create") != -1)) 
									|| ( $scope.rolesArray.indexOf("MAC") != -1 && ($scope.userAttrArray.indexOf("VM Read") != -1 || $scope.userAttrArray.indexOf("VM Create") != -1))) {
								//show VM link
								console.log("****** Showing VM Link ******");
								$('#vmLink').removeClass('hidden');
							} else {
								//do NOT show VM link
								console.log("****** NOT Showing VM Link ******");
							}
							
							// only show the PRT link to Admin users, InquiryOnly users with (prt-admin, prt-read, prt-write),
							// PrioritizeSup users with (vprt-read, prt-write), MAC users with (vprt-read, prt-write), 				
							if ($scope.rolesArray.indexOf("Admin") != -1 
									|| ($scope.rolesArray.indexOf("Inquiry Only") != -1 && ($scope.userAttrArray.indexOf("PRT Admin") != -1 || $scope.userAttrArray.indexOf("PRT Read") != -1 || $scope.userAttrArray.indexOf("PRT Write") != -1)) 
									|| ($scope.rolesArray.indexOf("Prioritize Sup") != -1 && ($scope.userAttrArray.indexOf("PRT Read") != -1 || $scope.userAttrArray.indexOf("PRT Write") != -1)) 
									|| ($scope.rolesArray.indexOf("MAC") != -1 && ($scope.userAttrArray.indexOf("PRT Read") != -1 || $scope.userAttrArray.indexOf("PRT Write") != -1))) {
								//show VM link
								console.log("****** Showing PRT Link ******");
								$('#prtLink').removeClass('hidden');
								$scope.probReportLinkUrl = $scope.restURL.substring(0, $scope.restURL.lastIndexOf("/")+1) + "ProblemReportingTool/";
							} else {
								//do NOT show VM link
								console.log("****** NOT Showing PRT Link ******");
							}
							
							// lock the administration link if user is not a supervisor				
							if ($scope.rolesArray.indexOf("Admin") == -1) {				
								console.log('User is not an Admin, so do NOT show Administration link');
							} else {
								console.log('User is an Admin, so show Administration link');
								$('#adminLink').removeClass('hidden');		
								// set the URL for the admin link
							//	$('#adminLinkAnchor').attr("href", $scope.restURL + '#Administration');			
							}
							
							/* Following users are allowed to view EML link
							 * FPSUI EML Model Developer
							 FPSUI EML Edits Manager
							 FPSUI EML DMA
							 FPSUI EML System Maintainer
							 FPSUI EML Edits Developer
							 FPSUI EML DISM
							 FPSUI EML Model Manager
							 FPSUI EML Model Developer
							 */
							
							if (environment){
								console.log("Env - ", environment);
								
								// Any Jurisdiction can view the link except MAc and medic
								

								if ($scope.rolesArray.indexOf("MAC") > -1 ){
									
								}
								
//								else{
//									$('#emlLink').removeClass('hidden'); 
//								}								
								//I am a FPSUI EML DISM, FPSUI EML DMA, FPSUI EML Model Operations, FPSUI EML Model Developer or FPSUI EML Model Manager role 

								
								if (
									$scope.userAttrArray.indexOf("EML Model Developer") != -1 ||
									//										|| $scope.userAttrArray.indexOf("EML Edits Manager") != -1
									$scope.userAttrArray.indexOf("EML DMA") != -1 ||
									$scope.userAttrArray.indexOf("EML System Maintainer") != -1 ||
									//										|| $scope.userAttrArray.indexOf("EML Edits Developer") != -1
									$scope.userAttrArray.indexOf("EML DISM") != -1 ||
									$scope.userAttrArray.indexOf("EML Model Manager") != -1 ||
									$scope.userAttrArray.indexOf("EML Model Developer") != -1 ||
									//										|| $scope.userAttrArray.indexOf("VM Create") != -1
									$scope.userAttrArray.indexOf("EML Model Operations") != -1
									//										|| $scope.userAttrArray.indexOf("EML FIG") != -1
									) {
									console.log("****** Showing EML Link ******");
									$("#emlLink").removeClass("hidden");
									} else if (
									($scope.rolesArray.indexOf("Inquiry Only") != -1 ||
										$scope.rolesArray.indexOf("Prioritize Sup") != -1) &&
									($scope.organization.includes("UPIC") ||
										$scope.organization.includes("Deloitte") ||
										$scope.organization.includes("GDIT") ||
										$scope.organization.includes("MEDIC"))
									) {
									// Keep the link open for VM proposal - FPS-26202 - AC1
									$("#emlLink").removeClass("hidden");
									}

							}else {
								console.log("EML URL is restricted for the environment-", environment);
							}
								
							//  Medicaid or Medicare toggle							
							// Get the User details to check if he is belongs to medicare or medicaid.
							navFactory.getLandingPageData($scope.restURL,$scope.scopeUserId, $scope.oldOrganizationVal).then(function(response) {
									//set a scope level variable to the info returned from the services								
									console.log("default asr -",response);

									if (response.data.defaultAsrView != null && response.data.defaultAsrView != undefined && response.data.defaultAsrView != "") {
										$scope.defaultAsrView = response.data.defaultAsrView;
									}else {
										$scope.defaultAsrView = "medicare";
									}
									console.log("Default ASR View: ", $scope.defaultAsrView);	

								}).catch(function(err) {
								console.log('getLandingPageData RESTError:' +  err.data);	
								showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> No User details available due to  ' +  err.data + ' error.', 'danger');
							}); 
							

							
							//call the /landingpage/header/{userId}/{userZone} web service to get the user requests and messages					
							navFactory.getHeaderInfo($scope.restURL, $scope.oldOrganizationVal, $scope.scopeUserId).then(function(response) {
								// extract the messages and user requests from the response
								$scope.outages = response.data.outages;
								$scope.messages = response.data.messages;
								$rootScope.messages = response.data.messages;
								$scope.requests = response.data.requests;
								
								console.log("$scope.requests = " + $scope.requests);
																		
								// set the badge number if messages isn't empty
								if (response.data.newSysMsgCt != "" && response.data.newSysMsgCt > 0 ){
									//show the badge
									$scope.showMsgsBadge = true;
									//set the badge number
									$scope.sysMsgsBadgeVal = response.data.newSysMsgCt;
									
								} else {
									//hide the badge
									$scope.showMsgsBadge = false;
									$scope.sysMsgsBadgeVal = "";
								}
								$rootScope.showMsgsBadge = $scope.showMsgsBadge;
								$rootScope.sysMsgsBadgeVal = $scope.sysMsgsBadgeVal;
								//build the user requests array
								var userRequestsArray = [];
								for (i = 0; i < $scope.requests.length; i++) {
									userRequestsArray.push($scope.requests[i].status);
								}
								
								if (userRequestsArray.length > 0) {
									//set the value of the attributes field
									$scope.userRequests = userRequestsArray.toString();
								} else {
									$scope.userRequests = "";
								}
								$rootScope.userRequests = $scope.userRequests;
								
								//only show the User Request table to PrioritizeSup users					
								if (userRequestsArray.length > 0) {
									
									//show the User Request table
									$scope.showUserRequests = true;
								} else {
									//show the User Request table
									$scope.showUserRequests = false;
								}
								
								
							}).catch(function(err) {
								console.log('getHeaderInfo REST Error:' + err.status);
								
								showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Navigation Bar info failed to load due to ' + err.status, 'danger');
							});
							
				}).catch(function(err) {
					console.log('getURLPropertyFromFile REST Error:' + err.data);						
					showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Unable to load system data due to ' + err.data, 'danger');		
				});

				// check the original URL to see where to redirect the user
				console.log('Originating URL = ' + window.location.href);

				if (window.location.href.indexOf('ASRDetails') !== -1) {
					console.log('Redirect legacy ASRDetails to modern Details screen');
					window.location.replace(window.location.origin + '/FPS2UnifiedPortal/Investigative/Details');
				} else if (window.location.href.indexOf('Administration') !== -1) {
					// do nothing
					console.log('Redirect to Administration screen');
				} else if (window.location.href.indexOf('CaseManagement') !== -1) {
					console.log('Redirect legacy CaseManagement to modern Triage screen');
					window.location.replace(window.location.origin + '/FPS2UnifiedPortal/Investigative/Triage');
				} else if (window.location.href.indexOf('IPHome') !== -1) {
					console.log('Redirect legacy IPHome to modern Investigative screen');
					window.location.replace(window.location.origin + '/FPS2UnifiedPortal/Investigative');
				} else {			
					console.log('Redirect legacy Index/default to modern home screen');
					window.location.replace(window.location.origin + '/FPS2UnifiedPortal/');
				}

			}
		} else {
			// You're not logged in, you need a sessionToken
			authClient.token.getWithRedirect({
				responseType: ['token', 'id_token']
			});
		} 
	};
	$scope.loadDocument = function(pURL) {
		console.log("Inside loadDocument");
		var queryString = pURL.substring(pURL.lastIndexOf('?')+1, pURL.length-1);

		var urlParams = new URLSearchParams(queryString);
		if (!urlParams.get("userId")){
			pURL+="&userId="+$scope.uid;
		}
				console.log("qs "+pURL);

		console.log($scope.uid);
		// broadcast this event to the reset session listener
		$rootScope.$broadcast("factoryMethodCalled");
		config = {};

		navFactory.loadDocument(pURL).success(function(response) {	
		
		}).catch(function(err) {
			console.log('loadDocument REST Error:' + err.data);			
		});;
		
	
		console.log('loadDocument REST request = ' + jsonData);
    		    		
    		
    
		
	
    		    		
    		
    };
	
	$scope.signOutOkta = function() {
		
		//stop the interval
		$interval.cancel($scope.intervalVar);

		// stop the authClient service
		//authClient.stop();

		// sign the user out of Okta
		authClient.signOut();
	}
	
	// this functions captures the input from the search form on the navigation bar
	$scope.searchFormSubmit = function() {
		console.log("Inside searchFormSubmit function. ASR ID to search = " + $scope.navSearchAsrId);
		
		// show the overlay for nav search component
		$("#navSearchAsrId").LoadingOverlay("show");
		
		// save the value of the Nav ASR ID field to the util service
		utilService.getNavAsrIdVal($.trim($scope.navSearchAsrId));
		
		// conduct a search to see if results comeback for the ASR
		// create new search object		
		var navSearchObj = utilService.getSearchReqObj();	
		navSearchObj.asrptId = $.trim($scope.navSearchAsrId);
		navSearchObj.searchType = "QUICK"; //pass QUICK to denote a quick search
		navSearchObj.loggedInUserId = $scope.scopeUserId;
		navSearchObj.programType = $scope.defaultAsrView;

		
		//call the search function
		navFactory.getCaseMgmtData($scope.restURL, navSearchObj).then(function(response) {
			//hide the overlay for nav search component
			$("#navSearchAsrId").LoadingOverlay("hide");
			
			//check to see if the response contains any values
			var responseLength = "medicaid" == navSearchObj.programType ? response.data.responseDataMdcd.length : response.data.responseData.length;
			if (responseLength > 0) {
				console.log("Search results returned for ASR... forward to the details screen.");
				console.log(response.data);
				
				//save the value of the ASR DB ID field to the util service
//				selectedAsrId = navSearchObj.programType ? response.data.responseDataMdcd[0].mdcdAsrDbId : response.data.responseData[0].asrDbid;
				selectedAsrId = response.data.responseDataMdcd.length>0 ? response.data.responseDataMdcd[0].mdcdAsrDbId : response.data.responseData.length>0?response.data.responseData[0].asrDbid:"";
				utilService.setNavAsrDbIdVal(selectedAsrId);
				
				//redirect the user to the ASR Detail Page
				window.location = "#ASRDetails?navAsrSearch=true";
				
				//move the focus out of search input - 508 fix
				$scope.navSearchAsrId = null;
				
				
				//move the focus out of search input - 508 fix
				$( "input#navSearchAsrId" ).blur();
				
//				if ("medicaid" == navSearchObj.programType) {
//					$('a#medicaidAsrDetailTabLink').focus();
//				}else {
//					$('a#medicareAsrDetailTabLink').focus();
//				}
				
			} else {
				console.log("No search results returned for ASR... show growl message.");
				
				//show growl message
				showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> No ASR Found for ' + utilService.getNavAsrIdVal(), 'danger');
			}
		}).
		catch(function(err){    			
			console.log("ASR Management REST Error: " + err.status);
			//hide the overlay for nav search component
			$("#navSearchAsrId").LoadingOverlay("hide");
			
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Search failed due to ' + err.status, 'danger');
		});
		
		//move the focus out of search input - 508 fix
		$( "input#navSearchAsrId" ).blur();		
		
			
	}
	
	// user to continue their session after 25 minutes of idle time.
	function getSessionIdleTimeCheck(pRefreshSession) {
		console.log('Inside getSessionIdleTimeCheck function. pRefreshSession = ' + pRefreshSession);

		if (pRefreshSession == 'true') {
			// set the idleTimeExp local storage object to the current time + 30 mins
			localStorage.setItem('idleTimeExp', moment().add(30, 'm'));

			// get the date from local storage		
			console.log('%%%%%%%%%%% Reset Idle Time Expiration to ' + localStorage.getItem('idleTimeExp') + ' %%%%%%%%%%%');
		}
		

		// check to see if localstorage item exists for session
//		if (localStorage.getItem('idleTime') == null) {
//			console.log('localStorage time is null, so set to 30 minutes');

			//set the initial timer to 30 minutes
//			localStorage.setItem('idleTime', 30);
//		} else {
//			console.log('localStorage is NOT null. Time remaining = ' + localStorage.getItem('idleTime'));
			
//		}

		// initialize the session timeout at 30 seconds
		//$scope.remainingIdleTimeResp  = 30;
		//$scope.remainingIdleTimeResp = localStorage.getItem('idleTime');

		//reset the interval to help sync start times across browser tabs
		$interval.cancel($scope.intervalVar);
		
		//start interval to check the session idle time using Okta Access Token
		$scope.intervalVar = $interval(function() {
			console.log("getSessionIdleTimeCheck: Interval method called.");

			// get the date/time from local storage
			var idleTimeFromStorage = moment(localStorage.getItem('idleTimeExp'));

			// get the current date/time
			var currentTime = moment();

			// assign the remaining time (minutes) to scope variable
			$scope.remainingIdleTimeResp = idleTimeFromStorage.diff(currentTime, 'minutes');
			console.log("%%%%% Remaining Time until Idle Expiration = " + $scope.remainingIdleTimeResp + " %%%%%");

			// check to see if the modal window is showing (in possibly multiple tabs)			
//			console.log('Timeout modal opened = ' + $scope.timeoutModalShown);
			
			//not called during page load, so check the session idle time after first interval
			// Attempt to retrieve ID Token from Token Manager
//			authClient.tokenManager.get('accessToken')
//			.then(accessToken => {
			  //console.log(idToken);
//			  if (accessToken) {
				// parse the expiration time of the access token
//				var accessTokenExp = accessToken.claims.exp;
//				console.log("Access Token Exp Date = " + accessTokenExp);

				// convert to date
//				var accessTokenExpDt = new Date(accessTokenExp * 1000);

				// get the current date
//				var currentDate = new Date();

				// get the amount of seconds left in the token 
//				var secondsLeft = parseInt((accessTokenExpDt - currentDate)/1000);
				// get the amount of minutes left in the token
//				$scope.remainingIdleTimeResp = parseInt(secondsLeft/60);


			//	$scope.remainingIdleTimeResp =  localStorage.getItem('idleTime') - 1;
				// update the local storage with the new session time
			//	localStorage.setItem('idleTime', $scope.remainingIdleTimeResp);
			//	console.log('***User Idle time remaining (minutes)= ' + localStorage.getItem('idleTime') + ' ***');

				//check to see if the user idle time is more than 10 minutes
				if ($scope.remainingIdleTimeResp <= 5) {
					//check to see if the timer reached zero
					if ( $scope.remainingIdleTimeResp <= 0) {

						// sign out of Okta
						$scope.signOutOkta();
						
					} else {
						//set whether the messages says minutes or minute
						if($scope.remainingIdleTimeResp <= 1){
							$('#idleTimeSpanMsg').text($scope.remainingIdleTimeResp + ' minute');
						} else {
							$('#idleTimeSpanMsg').text($scope.remainingIdleTimeResp + ' minutes');
						}

						//do not let user escape modal
						$('#idleTimeModal').modal({
							backdrop: 'static',
							keyboard: false
					 	})
					  
						//show the modal 
						$("#idleTimeModal").modal("show");
					}
				} else {
					
					// modal may be open across tabs, so shut the modal if time > 5 mins and modal is opened
//					if ($scope.timeoutModalShown != 'undefined' && $scope.timeoutModalShown != void(0) && $scope.timeoutModalShown === true){
						// close the modal window
//						$("#idleTimeModal").modal("hide");
//					}
				}
			   				
//			  } else {
				// You're not logged in, you need a sessionToken
//				authClient.token.getWithRedirect({
//				  responseType: ['token', 'id_token']
//				});
//			  }
//			})
		}, 60000);	//check every 60 seconds
	}

	// Alternatively, you can subscribe to the 'renewed' event:
//	authClient.tokenManager.on('renewed', function (key, newToken, oldToken) {
//		console.log(newToken);
//	});
	
	
	// user has engaged the session timeout modal buttons
	$scope.contSessBtnClick = function(pContinueSessBool) {
		console.log('Inside contSessBtnClick.  pContinueSessBool = ' + pContinueSessBool);
		
		if (pContinueSessBool == 'true') {

			//reset the interval to be as close to the beginning of the session reset as possible
			//$interval.cancel($scope.intervalVar);
			getSessionIdleTimeCheck('true');

			//hide the warning dialog window
			$("#idleTimeModal").modal("hide");

			// broadcast to other tabs as local storage event listener
	//		localStorage.setItem('continueSession', 'true');


			//broadcast this event to the sessionKeepAlive listener
			//$rootScope.$broadcast('sessionKeepAlive', {message:"continueSession"});		
			
			// broadcast state change so other tabs know to close modal
			//authClient.authStateManager.updateAuthState();

		} else {

			//hide the warning dialog window
			$("#idleTimeModal").modal("hide");
			
			//press the logout button to redirect user to logout screen
			//$scope.signOutOkta();

			//stop the interval
			$interval.cancel($scope.intervalVar);

			// stop the authClient service
			//authClient.stop();

			// sign the user out of Okta
			//authClient.signOut();
			authClient.signOut();
		}
	}

	// track global logout of okta
	$scope.$on('sessionKeepAlive', function(event, args) {
		console.log('Session Keep Alive callled! Message = ' + args.message);
	});
	
	// this function calls the user tracking service
	$scope.trackUserActivity = function(pPageId, pTrackVal) {
		// call the user tracking web service to denote the fact that the user clicked the support portal link
		utilFactory.getTrackUserActivity($scope.restURL, $scope.scopeUserId, pPageId, pTrackVal).then(function(response) {
			console.log('getTrackUserActivity web service call successful.');
		}).catch(function(err) {
			console.log('getTrackUserActivity REST Error:' + err.data);			
		});
	}
	
	// handle the link click when a user clicks on the Reports link
	$scope.reportsLinkClicked = function() {
		console.log('Inside reportsLinkClicked function.');
		
		//log user activity
		$scope.trackUserActivity("RPT");
	}
		// handle the link click when a user clicks on the Reports link
	$scope.emlLinkClicked = function() {
		
		//log user activity
		$scope.trackUserActivity("EML");
	}
	// handle the link click when a user clicks on the Vulnerability Management link
	$scope.vmLinkClicked = function() {
		console.log('Inside vmLinkClicked function.');
		
		//log user activity
		$scope.trackUserActivity("BPMVM");
	}
	
	// this method handles the skip Navigation link for 508 compliancy
	$scope.skipNavFunc = function() {
        console.log('Inside the skipNavFunc function.');
        
      //broadcast to all scopes that the user has clicked the skip nav link
        $rootScope.$broadcast("skipNavEvent");
	}
	
	$rootScope.readMoreLinkLenCheck = function(pTextStr) {
		console.log('Inside the readMoreLinkLenCheck function.');
		
		if (pTextStr.length > 101) {
			var oTextStr = pTextStr.substr(0,150) + "...&nbsp;<a tabindex='0' href='' title='show more' role='link' style='cursor:pointer;font-weight:normal;' class='moreLinkClass'>Show More</a>";
			
			return oTextStr;
		} else {
			return pTextStr;
		}
	}
	
	// this function notifies the web services that the user has read the System Messages
	$scope.markMsgsAsReadByUser = function() {
		console.log('Inside the markMsgsAsReadByUser function.');
		
		//call /rest/landingpage/messages/view/{userId} to indicate the user has read the messages
		navFactory.setMsgsAsReadByUser($scope.restURL, $scope.scopeUserId).then(function(response) {
			
			if (response.data.validResponse == 'true') {
				console.log("Messages have been marked as read by user " + $scope.scopeUserId + ".")
			} else {
				console.log("Messages have NOT been marked as read by user " + $scope.scopeUserId + ".")
			}
			
		}).catch(function(err) {
			console.log('Request setMsgsAsReadByUser REST Error:' + err.status);
		});
	}
	
	$rootScope.showMoreClick = function(pMsgObjId, pLinkType) {
		console.log('Inside the showMoreClick function.' + pMsgObjId);
		var indexNum = pMsgObjId.substr(0, pMsgObjId.indexOf("message"));
		var msgArrayVal = $rootScope.messages[indexNum].message;
		//console.log("indexNum = " + $scope.messages[indexNum].message);
		
		if (pLinkType == "more") {
			//$("#" + pMsgObjId).html(msgArrayVal).append("&nbsp;<a style='cursor:pointer;' class='lessLinkClass'>Show Less</a>");
			$("#" + pMsgObjId).html(msgArrayVal + "&nbsp;<a style='cursor:pointer;font-weight:normal;' title='show less' href='' role='link' class='lessLinkClass'>Show Less</a>");
		} else {
			//$("#" + pMsgObjId).html(msgArrayVal.substr(0,100)).append("...&nbsp;<a style='cursor:pointer;' class='moreLinkClass'>Show More</a>");
			$("#" + pMsgObjId).html(msgArrayVal.substr(0,150) + "...&nbsp;<a tabindex='0' href='' title='show more' role='link' style='cursor:pointer;font-weight:normal;' class='moreLinkClass'>Show More</a>");
		}
		
	}
	
	// Toggle ASR default view
	
	$scope.updateDefaultView = function (){
		console.log("toggle asr view-", $scope.defaultAsrView);
		
		
		// call the save search web service
		navFactory.saveUserPreferences($scope.restURL, $scope.scopeUserId, "defaultAsrView",  JSON.stringify($scope.defaultAsrView), null).then(function(response) {
			
			//hide full page overlay
			//$("#saveSearchModalBody").LoadingOverlay("hide");
			
			//present message to user stating that preferences have been saved
			showGrowl('<i class=\'fa fa-info-circle\' aria-hidden=\'true\'></i> Default ASR view preference successfully saved.', 'info');
			//broadcast this event to the bodcastDefaultView change listener
			// used to communicate change to indexpage            
			$rootScope.$broadcast('broadcastDefaultViewChange', 
			{message: $scope.defaultAsrView});
			
			// hide the modal window
			//$("#saveSearchModal").modal("hide");
			
		}).catch(function(err){ 
			//hide full page overlay
			//$("#saveSearchModalBody").LoadingOverlay("hide");
			
			// show growl message
			showGrowl('<i class=\'fa fa-exclamation-triangle\' aria-hidden=\'true\'></i> Default ASR view preference not saved due to ' + err.status, 'danger');
		});
	};
	
	// listen for a broadcast from the module methods to log SLA metrics
	$scope.$on('broadcastSlaMetrics', function(event, args) {
		console.log("^^^^^^^^^^^ SLA Metrics Broadcast Detected ^^^^^^^^^^^");
		
		// get the current date and time to log
		var currentDate = moment(new Date()).format("MMMM DD, YYYY hh:mm:ss a");
		var userId;
		
		// note: only the landing page load function should pass a userId
		if(args.userId != null && args.userId != ''){			
			userId = args.userId
		} else {
			userId = $scope.scopeUserId;
		}
		var restUrl = args.restURL;
		if (restUrl == null){
				restUrl = $scope.restURL;	
		}
			
		// call the util factory's logSlaMetrics method
		utilFactory.logSlaMetrics(restUrl, userId, currentDate, args.message).then(function(response) {
			console.log('SLA Metrics captured from Factory Broadcast.');
		}).catch(function(err) {
			console.log('logSlaMetrics REST Error:' + err.data);			
		});
	});
	
	// listen for a broadcast from the factory methods to reset the user's session
	$scope.$on('factoryMethodCalled', function(event, args) {
		console.log("^^^^^^^^^^^ Factory method called ^^^^^^^^^^^");

		//reset the interval to be as close to the beginning of the session reset as possible
		//$interval.cancel($scope.intervalVar);
		getSessionIdleTimeCheck('true');		
	});

	//listen for session timeout modal to open
//	$("#idleTimeModal").on('shown.bs.modal', function() {
//		console.log("Session timeout modal has been opened.");
		
		// set the scope level variable to true
//		$scope.timeoutModalShown = true;
//	});

	// listen for the session timeout modal to close
//	$("#idleTimeModal").on('hide.bs.modal', function() {
//		console.log("Session timeout modal has been closed.");
		
		// set the scope level variable to true
//		$scope.timeoutModalShown = false;
//	});

	
	// listen for the authstate change
	authClient.authStateManager.subscribe(authState => {
		// handle emitted latest authState
		console.log('--- AuthState Change ---');
		console.log('is Authenticated = ' + authState.isAuthenticated);

		// if the user has been logged out of another tab, log them out of the current tab
		if (!authState.isAuthenticated) {
			console.log('isAuthenticated is false, so logout user...');
			//$scope.signOutOkta();

			//hide the warning dialog window
			$("#idleTimeModal").modal("hide");
			
			//press the logout button to redirect user to logout screen
			//$scope.signOutOkta();

			//stop the interval
			$interval.cancel($scope.intervalVar);

			// stop the authClient service
			//authClient.stop();

			// sign the user out of Okta
			authClient.signOut();
			authClient.signOut();
		} else {
			console.log('isAuthenticated is NOT false.');
		}
	});

	window.addEventListener('storage', function (e) {
		console.log("storage event occured here: " + e.key);

		if (e.key == 'continueSession') {
			// user clicked the continue session button in different tab, so call local continue session method			
			
		} else if (e.key == 'idleTimeExp') {
			// session was reset in another window, so hide modal				
			$("#idleTimeModal").modal("hide");

			//reset the interval to be as close to the beginning of the session reset as possible
			//$interval.cancel($scope.intervalVar);

			getSessionIdleTimeCheck('false');

		}
  	},false);

	$('#sessionLink').click(function () {
		console.log('sessionLink clicked');

		//call the controller function
		angular.element('#navController').scope().contSessBtnClick('true');
	 });
	
	$('#sessionLinkEnd').click(function () {
		console.log('sessionLinkEnd clicked');
		//call the controller function
		angular.element('#navController').scope().contSessBtnClick('false');
	});
}]);


//define a factory to perform REST functionality
appNav.factory('navFactory', ['$http', '$rootScope', function($http, $rootScope) {
	return {
		getCaseMgmtData: function(pURL, pSearchCriteriaObj) {
			//retrieve data for when a user searches by npi from the nav bar
    		console.log("Inside navFactory.getCaseMgmtData: ");
    		
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		  		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(pSearchCriteriaObj);
    		console.log('getCaseMgmtData REST request = ' + jsonData);
    		
    		//make the rest web service call to get the data
    		return $http.post(pURL + '/rest/portal/caseMgmtSearch', jsonData);
    	},
		getHeaderInfo: function(pURL, pUserZone, pUserId) {
    		console.log("Inside navFactory.getHeaderInfo");
    		
    		//create the json request object
    		var entryCriteria = {
    			userZone: pUserZone,
    			userId: pUserId
    		};
    		  		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('getHeaderInfo REST request = ' + jsonData);
    		
    		//make the rest web service call to get the data
    		return $http.post(pURL + '/rest/portal/navBarData', jsonData);
    	},
		
    	setMsgsAsReadByUser: function(pURL, pUserId) {
    		//notify web services that user clicked the sys msgs link in nav bar
    		console.log("Inside navFactory.setMsgsAsReadByUser");
    		
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {    			
    			userId: pUserId
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('setMsgsAsReadByUser REST request = ' + jsonData);
    		
    		//make the rest web service call to get the data
    		return $http.post(pURL + '/rest/portal/readMessages', jsonData);
    	},
    	getLandingPageData: function(pURL, pUserId, pUserZone) {
   		 //   		console.log("Inside indexFactory.getLandingPageData");
   		 
   		    		//create the json request object
   		    		var entryCriteria = {
   		    				userId: pUserId,
   		    				userZone: pUserZone
   		    		};
   		    		
   		    		//create the JSON object to be used in the REST Request
   		    		jsonData = JSON.stringify(entryCriteria);
   		    		    		
   		    		return $http.post(pURL + '/rest/portal/queryLandPageData', jsonData);
   		    	},
   		    	saveUserPreferences: function(pURL, pUserId, pPrefName, pPrefJson, pPrefLabel) {
   		    		//broadcast this event to the reset session listener
   		    		$rootScope.$broadcast("factoryMethodCalled");
   		    		
   		    		//create the json request object
   		    		var entryCriteria = {
   		    			userId: pUserId,
   		    			prefName: pPrefName,
   		    			prefJson: pPrefJson,
   		    			prefLbl: pPrefLabel
   		    		};
   		    		
   		    		//create the JSON object to be used in the REST Request
   		    		jsonData = JSON.stringify(entryCriteria);
   		    		console.log('saveUserPreferences REST request = ' + jsonData);
   		    		
   		    		return $http.post(pURL + '/rest/portal/saveUserPrefs', jsonData);
   		    	}
				,
				loadDocument: function(pURL) {
					console.log("Inside navFactory.loadDocument");
					
					// broadcast this event to the reset session listener
					$rootScope.$broadcast("factoryMethodCalled");
					config = {};
					
					$http.get(pURL,{ responseType: 'arraybuffer' }).then(function (response) {
						console.log("response " + response);

						var a = document.createElement("a");
						document.body.appendChild(a);
						a.style = "display: none";
						a.target = "_blank";
						//console.log(response.headers());
						var blobFileName = "";
						//var headerVal = response.headers('Content-Disposition');
						//if (headerVal){
						//	 headerVal.substring(headerVal.lastIndexOf('=')+1, headerVal.length-1);
						//}else{
							
							var queryString = pURL.substring(pURL.lastIndexOf('?')+1, pURL.length-1);
							var urlParams = new URLSearchParams(queryString);
							blobFileName = urlParams.get("fileName");
							//blobFileName= blobFileName.replace("\"", "");
						//}
						//var queryString = pURL.substring(pURL.lastIndexOf('?')+1, pURL.length-1);
						//var urlParams = new URLSearchParams(queryString);
						//var blobFileName = urlParams.get("fileName");
						//blobFileName= blobFileName.replace("\"", "");
						console.log(blobFileName);

						var contentType = response.headers('Content-Type');
						if (!contentType){
							contentType = "application/pdf";
						}
						console.log("contentType = " + contentType);

						var binaryData = response.data;
						if (navigator.msSaveBlob){
							//IE Browsers
							navigator.msSaveBlob(blob, blobFileName);
						} else {

						
							var blob = new Blob([binaryData], {type: contentType})
							var u = URL.createObjectURL(blob);
							a.href = u;
							a.download = blobFileName;
							a.click();
							URL.revokeObjectURL(u);
						}
				
					}).catch(function(e) {
						console.log('Error: ', e);
						throw e;
					});
					console.log('loadDocument REST request = ' + jsonData);
    		    		
    		
		},
   		    	
   		    	
 /*   	enhanceReqSbmt: function(pURL, pUserId, pFirstName, pLastName, pEmailAddress, 
				pPhone, pDescription) {
    		
    		console.log("Inside navFactory.enhanceReqSbmt");
    		
    		//broadcast this event to the reset session listener
    		$rootScope.$broadcast("factoryMethodCalled");
    		
    		//create the json request object
    		var entryCriteria = {    			
    			userId: pUserId,
    			firstName: pFirstName,
    			lastName: pLastName,
    			email: pEmailAddress,
    			phone: pPhone,
    			messageTxt: pDescription
    		};
    		
    		//create the JSON object to be used in the REST Request
    		jsonData = JSON.stringify(entryCriteria);
    		console.log('setMsgsAsReadByUser REST request = ' + jsonData);
    		
    		//make the rest web service call to get the data
    		return $http.post(pURL + '/rest/portal/enhanceReq', jsonData);
    	} */
	}
}]);

//the following is a custom directive that controls the nav bar components status
 appNav.directive('navActiveLink', ['$location', function($location) {	
	console.log("Loaded Route Change Directive.");
	return {
		restrict: 'A', //use as an attribute
		replace: false,
		link: function (scope, elem) {
			//after the route has changed
			scope.$on("$routeChangeSuccess", function() {

				var hrefs = ['/#' + $location.path(), '#' + $location.path(), $location.path()]; 
				
				angular.forEach(elem.find('a'), function(a) {
					a = angular.element(a);
					
					if (-1 !== hrefs.indexOf(a.attr('href'))) {
						a.parent().addClass('active');
					} else {
						a.parent().removeClass('active');
					};
				});		
				
			}); 
		}
	}
}]);



//function to show Growl messages to the user
function showGrowl(pMessage, pType){	
	$.bootstrapGrowl(pMessage, {
		  ele: 'body', // which element to append to
		  type: pType, // (null, 'info', 'danger', 'success')
		  offset: {from: 'top', amount: 60}, // 'top', or 'bottom'
		  align: 'center', // ('left', 'right', or 'center')
		  width: 350, // (integer, or 'auto')
		  delay: 4000, // Time while the message will be displayed. It's not equivalent to the *demo* timeOut!
		  allow_dismiss: true, // If true then will display a cross to close the popup.
		  stackup_spacing: 10 // spacing between consecutively stacked growls.
		});
}

//handle click of session link
$(function () {

	$("body").on("click", ".moreLinkClass", function(e){
		// alert($(this).parents(".messageClass").first().attr("id"));			 
		 var msgElementId = $(this).parents(".messageClass").first().attr("id");
		 angular.element('#navController').scope().showMoreClick(msgElementId, "more");
		 
		 e.preventDefault();
		 e.stopPropagation();
	 });
	 
	 $("body").on("click", ".lessLinkClass", function(e){
		 //alert($(this).parent(".messageClass").attr("id"));
		 var msgElementId = $(this).parents(".messageClass").first().attr("id");
		 angular.element('#navController').scope().showMoreClick(msgElementId, "less");
		 
		 e.preventDefault();
		 e.stopPropagation();
	 });
	 
	 //custom style to make the browser scroll bar work when there are multiple modals open
	 //and then one of the modals is closed
	$('body').on('hidden.bs.modal', function() {
		console.log('Number of open modals = ' + $('.modal.in').length);
		if ($('.modal.in').length > 0) {
			$('body').addClass('modal-open');
		}
		var focusele  = localStorage.getItem('currentActiveElement');
		console.log("currentActiveElement ", focusele); 
//		angular.element('#indexController').scope().focusElement(elem);
		
		$(focusele).focus();
		localStorage.removeItem('currentActiveElement');
		
		
	});	 
	
	$('#myModal').on('shown.bs.modal', function () {
		  $('#myInput').trigger('focus')
		})
	
	
	
	
});

