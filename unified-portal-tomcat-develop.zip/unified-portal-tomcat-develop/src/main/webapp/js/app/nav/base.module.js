var appAdmin = angular.module('admin.module', ['ngRoute', 'ngCookies', 'ngSanitize']);

appAdmin.controller("adminController", ['$scope', '$location', '$cookies', '$window', '$filter', '$sanitize', 'adminFactory', 'utilService', 'utilFactory', 
                                        function ($scope, $location, $cookies, $window, $filter, $sanitize, adminFactory, utilService, utilFactory) {
	console.log('Inside the adminController.');

	// get the Okta authClient object from the util service
	var authClient = utilService.getOktaAuth();

	// check for a valid okta token
	authClient.tokenManager.getTokens()
	.then(({ accessToken, idToken }) => {
		// handle accessToken and idToken
		if (accessToken) {
			// user has valid access token, so show page contents
			console.log("administration controller - valid access token");

			showAdminPageContents(idToken);
		} else {
			// no token and not logged-in, so redirect to login screen               
			authClient.token.getWithRedirect({
				responseType: ['token', 'id_token']
			});
		}
	});

	 // this function shows the page to users that have been authenticated via Okta
	 showAdminPageContents = function(pIdToken) {
		console.log(`showAdminPageContents pIdToken = ${pIdToken} `);

		
		$('#authModal').modal("show");
	
	}
			
	}]);

//define a factory to perform REST functionality
appAdmin.factory('adminFactory', ['$http', '$rootScope', function($http, $rootScope) {	
	return {
		
	}	
}]);	
