/**
 *   This is the module (controller) declaration for the Unified Portal Index screen (index.html)
 */
var appIndex = angular.module('index.module', ['ngRoute', 'ngCookies', 'ngSanitize', 'ngMaterial', 'ngAnimate']);

appIndex.controller('indexController', [
	'$scope', '$rootScope', '$cookies', '$window', '$sanitize', '$sce',
	'indexFactory', 'utilService', 'utilFactory', 'caseMgmtFactory', '$http', 'navFactory',
	function ($scope, $rootScope, $cookies, $window, $sanitize, $sce,
		indexFactory, utilService, utilFactory, caseMgmtFactory, $http, navFactory) {

		console.log('Inside the indexController.');
		$scope.pIdToken = null;
		function updatePageTitle(newTitle) {
			document.title = newTitle;

			const srAnnouncer = document.createElement("div");
			srAnnouncer.setAttribute("role", "alert");
			srAnnouncer.setAttribute("aria-live", "assertive");
			srAnnouncer.style.position = "absolute";
			srAnnouncer.style.width = "1px";
			srAnnouncer.style.height = "1px";
			srAnnouncer.style.margin = "-1px";
			srAnnouncer.style.clip = "rect(0, 0, 0, 0)";
			srAnnouncer.style.overflow = "hidden";
			srAnnouncer.textContent = newTitle;
			document.body.appendChild(srAnnouncer);

			setTimeout(() => {
				document.body.removeChild(srAnnouncer);
			}, 1000);
		}
		$rootScope.pageTitle = "FPS Home Page";

		updatePageTitle($rootScope.pageTitle);

		var authClient = utilService.getOktaAuth();
		var rendered = false;

		function tryRenderFromTokens() {
			return authClient.tokenManager.getTokens()
				.then(({ accessToken, idToken }) => {
					if (rendered) return;                   // already rendered
					if (accessToken && idToken) {
						rendered = true;
						showIndexPageContents(idToken);
					} else {
						console.log('[index] No tokens yet; navController will handle login.');
					}
				})
				.catch(err => console.error('[index] getTokens error', err));
		}

		tryRenderFromTokens();

		authClient.authStateManager.subscribe((authState) => {
			if (!rendered && authState && authState.isAuthenticated) {
				tryRenderFromTokens();
			}
		});

		// ---------------- page render ----------------
		function showIndexPageContents(pIdToken) {
			if (!pIdToken) {
				return;
			}

			$scope.pIdToken = pIdToken;
			$scope.scopeUserId = pIdToken.claims.preferred_username;
			$scope.fullName = pIdToken.claims.name;
			$scope.firstName = pIdToken.claims.first_name;

			if (window.$ && $("#tilesContainer").length && $("#tilesContainer").LoadingOverlay) {
				$("#tilesContainer").LoadingOverlay("show");
			}
			utilFactory.getURLPropertyFromFile().then(function (response) {
				$scope.restURL = response.data;
				$scope.uid = pIdToken.claims.preferred_username;

				return indexFactory.loadHomepageTiles($scope.restURL);
			}).then(function (response) {
				$scope.homepageTiles = response.data.homepageTiles || [];
			}).catch(function (err) {
				console.log('index init error:', err && (err.data || err.message || err));
			}).finally(function () {
				if (window.$ && $("#tilesContainer").length && $("#tilesContainer").LoadingOverlay) {
					$("#tilesContainer").LoadingOverlay("hide");
				}
			});
		}

		$scope.trackUserActivity = function (pPageId, pTrackVal) {
			utilFactory.getTrackUserActivity($scope.restURL, $scope.uid, pPageId, pTrackVal)
				.then(() => console.log('getTrackUserActivity OK'))
				.catch(err => console.log('getTrackUserActivity REST Error:', err && err.data));
		};

		$scope.loadDocument = function (pURL) {
			console.log("Inside loadDocument");
			var queryString = pURL.substring(pURL.lastIndexOf('?') + 1, pURL.length - 1);
			var urlParams = new URLSearchParams(queryString);
			if (!urlParams.get("userId")) {
				var uid = ($scope.pIdToken && $scope.pIdToken.claims)
					? $scope.pIdToken.claims.preferred_username
					: "";
				pURL += "&userId=" + uid;
			}

			$rootScope.$broadcast("factoryMethodCalled");
			navFactory.loadDocument(pURL)
				.success(function () { })
				.catch(function (err) { console.log('loadDocument REST Error:', err && err.data); });
		};

		$scope.signOutOkta = function () {
			authClient.signOut();
		};

		$scope.markMsgsAsReadByUser = function () {
			if (!$scope.restURL || !$scope.scopeUserId) return;
			navFactory.setMsgsAsReadByUser($scope.restURL, $scope.scopeUserId)
				.then(function (response) {
					if (response.data.validResponse == 'true') {
						console.log("Messages marked as read for", $scope.scopeUserId);
					} else {
						console.log("Messages NOT marked as read for", $scope.scopeUserId);
					}
				})
				.catch(function (err) {
					console.log('setMsgsAsReadByUser REST Error:', err && err.status);
				});
		};

		$scope.$on('skipNavEvent', function () {
			console.log('skipNavEvent detected!');

			$("#pageTitle").focus();
		});
	
	}
]);

appIndex.factory('indexFactory', ['$http', '$rootScope', function ($http, $rootScope) {
	return {
		loadHomepageTiles: function (pURL) {
			console.log("Inside indexFactory.loadHomepageTiles");
			$rootScope.$broadcast("factoryMethodCalled");
			var entryCriteria = {};
			var jsonData = JSON.stringify(entryCriteria);
			return $http.post(pURL + '/rest/portal/homepageTiles', jsonData);
		}
	}
}]);


$(function () {

	$("body").on("click", ".moreLinkClass", function(e){
		// alert($(this).parents(".messageClass").first().attr("id"));			 
		 var msgElementId = $(this).parents(".messageClass").first().attr("id");
		 angular.element('#indexController').scope().showMoreClick(msgElementId, "more");
		 
		 e.preventDefault();
		 e.stopPropagation();
	 });
	 
	 $("body").on("click", ".lessLinkClass", function(e){
		 //alert($(this).parent(".messageClass").attr("id"));
		 var msgElementId = $(this).parents(".messageClass").first().attr("id");
		 angular.element('#indexController').scope().showMoreClick(msgElementId, "less");
		 
		 e.preventDefault();
		 e.stopPropagation();
	 });

	})