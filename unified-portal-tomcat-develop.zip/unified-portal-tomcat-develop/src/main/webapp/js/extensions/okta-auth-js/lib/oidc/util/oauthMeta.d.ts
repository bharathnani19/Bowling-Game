import { OAuthTransactionMeta, OktaAuth, PKCETransactionMeta, TokenParams } from '../../types';
export declare function createOAuthMeta(sdk: OktaAuth, tokenParams: TokenParams): OAuthTransactionMeta | PKCETransactionMeta;
