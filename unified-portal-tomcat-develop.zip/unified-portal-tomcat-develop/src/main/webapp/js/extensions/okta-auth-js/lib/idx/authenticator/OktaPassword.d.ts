import { Authenticator } from './Authenticator';
export declare type OktaPasswordInputValues = {
    password: string;
};
export declare class OktaPassword extends Authenticator {
    canVerify(values: any): boolean;
    mapCredentials(values: any): {
        passcode: any;
    };
    getInputs(idxRemediationValue: any): any;
}
