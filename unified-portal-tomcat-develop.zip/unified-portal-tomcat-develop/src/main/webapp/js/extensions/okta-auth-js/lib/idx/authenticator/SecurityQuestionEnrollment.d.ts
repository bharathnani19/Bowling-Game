import { Authenticator } from './Authenticator';
export declare class SecurityQuestionEnrollment extends Authenticator {
    canVerify(values: any): any;
    mapCredentials(values: any): {
        questionKey: any;
        question: any;
        answer: any;
    };
    getInputs(): ({
        name: string;
        type: string;
        require: boolean;
        label?: undefined;
        required?: undefined;
    } | {
        name: string;
        type: string;
        label: string;
        require?: undefined;
        required?: undefined;
    } | {
        name: string;
        type: string;
        label: string;
        required: boolean;
        require?: undefined;
    })[];
}
