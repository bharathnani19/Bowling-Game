import { OktaAuth, IdxTransactionMeta } from '../types';
export interface InteractOptions {
    withCredentials?: boolean;
    state?: string;
    scopes?: string[];
    codeChallenge?: string;
    codeChallengeMethod?: string;
    activationToken?: string;
    recoveryToken?: string;
}
export interface InteractResponse {
    state?: string;
    interactionHandle: string;
    meta: IdxTransactionMeta;
}
export declare function interact(authClient: OktaAuth, options?: InteractOptions): Promise<InteractResponse>;
