import { Authenticator } from './Authenticator';
export declare class SecurityQuestionVerification extends Authenticator {
    canVerify(values: any): any;
    mapCredentials(values: any): {
        questionKey: string;
        answer: any;
    };
    getInputs(): {
        name: string;
        type: string;
        label: string;
        required: boolean;
    }[];
}
