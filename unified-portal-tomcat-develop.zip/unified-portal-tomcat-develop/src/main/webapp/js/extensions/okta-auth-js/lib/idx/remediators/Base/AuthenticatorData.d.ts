/*!
 * Copyright (c) 2015-present, Okta, Inc. and/or its affiliates. All rights reserved.
 * The Okta software accompanied by this notice is provided pursuant to the Apache License, Version 2.0 (the "License.")
 *
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0.
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *
 * See the License for the specific language governing permissions and limitations under the License.
 */
import { Remediator, RemediationValues } from './Remediator';
import { IdxRemediationValue, IdxOption, IdxRemediation } from '../../types/idx-js';
import { Authenticator } from '../../types';
export declare type AuthenticatorDataValues = RemediationValues & {
    methodType?: string;
};
export declare class AuthenticatorData extends Remediator {
    map: {
        authenticator: never[];
    };
    values: AuthenticatorDataValues;
    authenticator: Authenticator;
    constructor(remediation: IdxRemediation, values?: AuthenticatorDataValues);
    protected formatAuthenticatorData(): void;
    protected getAuthenticatorData(): Authenticator | undefined;
    canRemediate(): boolean;
    getNextStep(): {
        options: IdxOption[];
        name: string;
        authenticator?: import("../../types/idx-js").IdxAuthenticator | undefined;
        canSkip?: boolean | undefined;
        canResend?: boolean | undefined;
        inputs?: import("../../types").Input[] | undefined;
        poll?: import("../../types").IdxPollOptions | undefined;
    };
    protected mapAuthenticatorDataFromValues(authenticatorData?: any): any;
    protected getAuthenticatorFromRemediation(): IdxRemediationValue;
    private getMethodTypes;
    getValuesAfterProceed(): RemediationValues;
}
