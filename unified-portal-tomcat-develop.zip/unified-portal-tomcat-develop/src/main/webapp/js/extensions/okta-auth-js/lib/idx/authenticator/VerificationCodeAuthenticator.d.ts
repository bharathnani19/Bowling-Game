import { Authenticator, Credentials } from './Authenticator';
interface VerificationCodeCredentials extends Credentials {
    passcode: string;
}
export declare class VerificationCodeAuthenticator extends Authenticator {
    canVerify(values: any): any;
    mapCredentials(values: any): VerificationCodeCredentials | Credentials;
    getInputs(idxRemediationValue: any): any;
}
export {};
