/*!
 * Copyright (c) 2015-present, Okta, Inc. and/or its affiliates. All rights reserved.
 * The Okta software accompanied by this notice is provided pursuant to the Apache License, Version 2.0 (the "License.")
 *
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0.
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *
 * See the License for the specific language governing permissions and limitations under the License.
 */
import { Remediator, RemediationValues } from './Base/Remediator';
export interface EnrollProfileValues extends RemediationValues {
    firstName?: string;
    lastName?: string;
    email?: string;
}
export declare class EnrollProfile extends Remediator {
    static remediationName: string;
    values: EnrollProfileValues;
    map: {
        userProfile: never[];
    };
    canRemediate(): boolean;
    mapUserProfile({ form: { value: profileAttributes } }: {
        form: {
            value: any;
        };
    }): any;
    getInputUserProfile(input: any): any[];
    getErrorMessages(errorRemediation: any): any;
}
