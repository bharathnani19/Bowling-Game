/*!
 * Copyright (c) 2015-present, Okta, Inc. and/or its affiliates. All rights reserved.
 * The Okta software accompanied by this notice is provided pursuant to the Apache License, Version 2.0 (the "License.")
 *
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0.
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *
 * See the License for the specific language governing permissions and limitations under the License.
 */
import { OktaAuth, IdxTransaction } from '../types';
import { AuthenticationOptions } from './authenticate';
import { EnrollPollValues as EnrollPollOptions, SelectEnrollmentChannelValues as SelectEnrollmentChannelOptions } from './remediators';
import { RegistrationOptions } from './register';
import { PasswordRecoveryOptions } from './recoverPassword';
export declare type ProceedOptions = AuthenticationOptions & RegistrationOptions & PasswordRecoveryOptions & EnrollPollOptions & SelectEnrollmentChannelOptions & {
    step?: string;
};
export declare function canProceed(authClient: OktaAuth, options?: {
    state?: string;
}): boolean;
export declare function proceed(authClient: OktaAuth, options?: ProceedOptions): Promise<IdxTransaction>;
