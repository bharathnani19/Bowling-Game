import { OktaAuth, TokenParams } from '../../types';
export declare function assertPKCESupport(sdk: OktaAuth): void;
export declare function validateCodeChallengeMethod(sdk: OktaAuth, codeChallengeMethod?: string): Promise<string>;
export declare function preparePKCE(sdk: OktaAuth, tokenParams: TokenParams): Promise<TokenParams>;
export declare function prepareTokenParams(sdk: OktaAuth, tokenParams?: TokenParams): Promise<TokenParams>;
