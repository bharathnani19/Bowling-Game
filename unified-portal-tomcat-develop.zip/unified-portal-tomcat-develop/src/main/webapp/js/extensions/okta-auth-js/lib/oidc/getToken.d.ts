import { OktaAuth, TokenParams, PopupParams } from '../types';
export declare function getToken(sdk: OktaAuth, options: TokenParams & PopupParams): Promise<import("../types").TokenResponse>;
