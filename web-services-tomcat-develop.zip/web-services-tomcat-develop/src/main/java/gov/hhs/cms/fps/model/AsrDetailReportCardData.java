package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import gov.hhs.cms.fps.model.generated.FpsClm;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailReportCardData implements Serializable {

	private String attrDef;
	private String overThreshold;
	private String infoOrAction;
	private String drill;
	private String drillD;
	private Short attrSqncNum;
	private Integer modelId;
	private List<AsrDetailClaimLineItem> drillClaims;
	private List<AsrDetailClaimLineItem> partDDrillClaims;
	private String providerValue;
	private String nationalMed;
	private String zoneMed;
	private String zoneThreshold;
	private String providerNatRank;
	private String provderZoneRank;
	private String contribToAlertPriority;
	private String relatedPrvdrNpi;
	private String relatedPrvdrName;
	private String subjPrvdrBeneCnt;
	private String relatedPrvdrBeneCnt;
	private String sharedBeneCnt;
	private String subjectPrvdrSharedBenePct;
	private String relatedPrvdrSharedBenePct;
	private String riskRelationshipRsn;
	private String reportCardType;
	private String type;
	private String npi;
	private String jurisdiction;
	private String modelCompScore;
	private String modelScoreThreshold;
	private String asOfDt;
	private String zone;
	private String subjPrvdrName;
	private String modelBusnsId;
	private String macMed;
	private String macPctl;
	private String pecosRltnshp;
	private String rltdPrvdrNum;
	private String badRltdPrvdrNum;
	private String badRltdPrvdrPct;
	// enhanced risk score, FPS-7118
	private Integer attrIndex;
	private Integer attrRank;
	private String contribDef;
	private String contribType;
	private String prvdrErsVal;
	private BigDecimal contribVal;
	private String alertedPrvdrPct;
	private String contribImpact;
	// medicaid
	private String state;
	private String mdcdState;
	private String mdcdId;
	private String riskScoreNum; 
	private String rltdPrvdrType;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getNpi() {
		return npi;
	}

	public void setNpi(String npi) {
		this.npi = npi;
	}

	public String getJurisdiction() {
		return jurisdiction;
	}

	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	public String getModelCompScore() {
		return modelCompScore;
	}

	public void setModelCompScore(String modelCompScore) {
		this.modelCompScore = modelCompScore;
	}

	public String getModelScoreThreshold() {
		return modelScoreThreshold;
	}

	public void setModelScoreThreshold(String modelScoreThreshold) {
		this.modelScoreThreshold = modelScoreThreshold;
	}

	public String getAsOfDt() {
		return asOfDt;
	}

	public void setAsOfDt(String asOfDt) {
		this.asOfDt = asOfDt;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}



	public String getSubjPrvdrName() {
		return subjPrvdrName;
	}

	public void setSubjPrvdrName(String subjPrvdrName) {
		this.subjPrvdrName = subjPrvdrName;
	}
	
	public String getAttrDef() {
		return attrDef;
	}
	public void setAttrDef(String attrDef) {
		this.attrDef = attrDef;
	}
	public String getOverThreshold() {
		return overThreshold;
	}
	public void setOverThreshold(String overThreshold) {
		this.overThreshold = overThreshold;
	}
	public String getInfoOrAction() {
		return infoOrAction;
	}
	public void setInfoOrAction(String infoOrAction) {
		this.infoOrAction = infoOrAction;
	}
	public String getDrill() {
		return drill;
	}
	public void setDrill(String drill) {
		this.drill = drill;
	}
	public String getProviderValue() {
		return providerValue;
	}
	public void setProviderValue(String providerValue) {
		this.providerValue = providerValue;
	}
	public String getNationalMed() {
		return nationalMed;
	}
	public void setNationalMed(String nationalMed) {
		this.nationalMed = nationalMed;
	}
	public String getZoneMed() {
		return zoneMed;
	}
	public void setZoneMed(String zoneMed) {
		this.zoneMed = zoneMed;
	}
	public String getZoneThreshold() {
		return zoneThreshold;
	}
	public void setZoneThreshold(String zoneThreshold) {
		this.zoneThreshold = zoneThreshold;
	}
	public String getProviderNatRank() {
		return providerNatRank;
	}
	public void setProviderNatRank(String providerNatRank) {
		this.providerNatRank = providerNatRank;
	}
	public String getProvderZoneRank() {
		return provderZoneRank;
	}
	public void setProvderZoneRank(String provderZoneRank) {
		this.provderZoneRank = provderZoneRank;
	}
	public String getContribToAlertPriority() {
		return contribToAlertPriority;
	}
	public void setContribToAlertPriority(String contribToAlertPriority) {
		this.contribToAlertPriority = contribToAlertPriority;
	}
	public String getRelatedPrvdrNpi() {
		return relatedPrvdrNpi;
	}
	public void setRelatedPrvdrNpi(String relatedPrvdrNpi) {
		this.relatedPrvdrNpi = relatedPrvdrNpi;
	}
	public String getRelatedPrvdrName() {
		return relatedPrvdrName;
	}
	public void setRelatedPrvdrName(String relatedPrvdrName) {
		this.relatedPrvdrName = relatedPrvdrName;
	}
	public String getSubjPrvdrBeneCnt() {
		return subjPrvdrBeneCnt;
	}
	public void setSubjPrvdrBeneCnt(String subjPrvdrBeneCnt) {
		this.subjPrvdrBeneCnt = subjPrvdrBeneCnt;
	}
	public String getRelatedPrvdrBeneCnt() {
		return relatedPrvdrBeneCnt;
	}
	public void setRelatedPrvdrBeneCnt(String relatedPrvdrBeneCnt) {
		this.relatedPrvdrBeneCnt = relatedPrvdrBeneCnt;
	}
	public String getSharedBeneCnt() {
		return sharedBeneCnt;
	}
	public void setSharedBeneCnt(String sharedBeneCnt) {
		this.sharedBeneCnt = sharedBeneCnt;
	}
	public String getSubjectPrvdrSharedBenePct() {
		return subjectPrvdrSharedBenePct;
	}
	public void setSubjectPrvdrSharedBenePct(String subjectPrvdrSharedBenePct) {
		this.subjectPrvdrSharedBenePct = subjectPrvdrSharedBenePct;
	}
	public String getRelatedPrvdrSharedBenePct() {
		return relatedPrvdrSharedBenePct;
	}
	public void setRelatedPrvdrSharedBenePct(String relatedPrvdrSharedBenePct) {
		this.relatedPrvdrSharedBenePct = relatedPrvdrSharedBenePct;
	}
	public String getRiskRelationshipRsn() {
		return riskRelationshipRsn;
	}
	public void setRiskRelationshipRsn(String riskRelationshipRsn) {
		this.riskRelationshipRsn = riskRelationshipRsn;
	}
	public String getReportCardType() {
		return reportCardType;
	}
	public void setReportCardType(String reportCardType) {
		this.reportCardType = reportCardType;
	}
	public List<AsrDetailClaimLineItem> getDrillClaims() {
		return drillClaims;
	}

	public void setDrillClaims(List<AsrDetailClaimLineItem> drillClaims) {
		this.drillClaims = drillClaims;
	}
	
	public Integer getModelId() {
		return modelId;
	}
	public void setModelId(Integer modelId) {
		this.modelId = modelId;
	}

//	public AsrDetailAlert getLatestAlert() {
//		return latestAlert;
//	}
//
//	public void setLatestAlert(AsrDetailAlert latestAlert) {
//		this.latestAlert = latestAlert;
//	}



	public String getModelBusnsId() {
		return modelBusnsId;
	}

	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}

	public List<AsrDetailClaimLineItem> getPartDDrillClaims() {
		return partDDrillClaims;
	}

	public void setPartDDrillClaims(List<AsrDetailClaimLineItem> partDDrillClaims) {
		this.partDDrillClaims = partDDrillClaims;
	}

	public Short getAttrSqncNum() {
		return attrSqncNum;
	}

	public void setAttrSqncNum(Short attrSqncNum) {
		this.attrSqncNum = attrSqncNum;
	}

	public String getMacMed() {
		return macMed;
	}

	public void setMacMed(String macMed) {
		this.macMed = macMed;
	}

	public String getMacPctl() {
		return macPctl;
	}

	public void setMacPctl(String macPctl) {
		this.macPctl = macPctl;
	}

	public String getDrillD() {
		return drillD;
	}

	public void setDrillD(String drillD) {
		this.drillD = drillD;
	}

	public String getPecosRltnshp() {
		return pecosRltnshp;
	}

	public void setPecosRltnshp(String pecosRltnshp) {
		this.pecosRltnshp = pecosRltnshp;
	}

	public String getRltdPrvdrNum() {
		return rltdPrvdrNum;
	}

	public void setRltdPrvdrNum(String rltdPrvdrNum) {
		this.rltdPrvdrNum = rltdPrvdrNum;
	}

	public String getBadRltdPrvdrNum() {
		return badRltdPrvdrNum;
	}

	public void setBadRltdPrvdrNum(String badRltdPrvdrNum) {
		this.badRltdPrvdrNum = badRltdPrvdrNum;
	}

	public String getBadRltdPrvdrPct() {
		return badRltdPrvdrPct;
	}

	public void setBadRltdPrvdrPct(String badRltdPrvdrPct) {
		this.badRltdPrvdrPct = badRltdPrvdrPct;
	}

	public Integer getAttrIndex() {
		return attrIndex;
	}

	public void setAttrIndex(Integer attrIndex) {
		this.attrIndex = attrIndex;
	}

	public Integer getAttrRank() {
		return attrRank;
	}

	public void setAttrRank(Integer attrRank) {
		this.attrRank = attrRank;
	}

	public String getContribDef() {
		return contribDef;
	}

	public void setContribDef(String contribDef) {
		this.contribDef = contribDef;
	}

	public String getContribType() {
		return contribType;
	}

	public void setContribType(String contribType) {
		this.contribType = contribType;
	}

	public String getPrvdrErsVal() {
		return prvdrErsVal;
	}

	public void setPrvdrErsVal(String prvdrErsVal) {
		this.prvdrErsVal = prvdrErsVal;
	}

	public String getAlertedPrvdrPct() {
		return alertedPrvdrPct;
	}

	public void setAlertedPrvdrPct(String alertedPrvdrPct) {
		this.alertedPrvdrPct = alertedPrvdrPct;
	}

	public String getContribImpact() {
		return contribImpact;
	}
	public void  setContribImpact(String contribImpact) {
		this.contribImpact = contribImpact;
	}
	public void updateContribImpact() {
		setContribImpact( contribVal == null || contribVal.signum() == 0 ? "N/A" : contribVal.signum() > 0 ? "increase" : "decrease") ;
	}

	public BigDecimal getContribVal() {
		return contribVal;
	}

	public void setContribVal(BigDecimal contribVal) {
		this.contribVal = contribVal;
		updateContribImpact();

	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getMdcdId() {
		return mdcdId;
	}

	public void setMdcdId(String mdcdId) {
		this.mdcdId = mdcdId;
	}

	public String getMdcdState() {
		return mdcdState;
	}

	public void setMdcdState(String mdcdState) {
		this.mdcdState = mdcdState;
	}

	public String getRiskScoreNum() {
		return riskScoreNum;
	}

	public void setRiskScoreNum(String riskScoreNum) {
		this.riskScoreNum = riskScoreNum;
	}

	public String getRltdPrvdrType() {
		return rltdPrvdrType;
	}

	public void setRltdPrvdrType(String rltdPrvdrType) {
		this.rltdPrvdrType = rltdPrvdrType;
	}

	





}