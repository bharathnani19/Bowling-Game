package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class FpsVisualization implements Serializable {

	private List<FpsVisualizationEdge> edges;
	private List<FpsVisualizationNode> nodes;
	private List<FpsVisualizationAttribute> attributes;
	public List<FpsVisualizationEdge> getEdges() {
		return edges;
	}
	public void setEdges(List<FpsVisualizationEdge> edges) {
		this.edges = edges;
	}
	public List<FpsVisualizationNode> getNodes() {
		return nodes;
	}
	public void setNodes(List<FpsVisualizationNode> nodes) {
		this.nodes = nodes;
	}
	public List<FpsVisualizationAttribute> getAttributes() {
		return attributes;
	}
	public void setAttributes(List<FpsVisualizationAttribute> attributes) {
		this.attributes = attributes;
	}
}
