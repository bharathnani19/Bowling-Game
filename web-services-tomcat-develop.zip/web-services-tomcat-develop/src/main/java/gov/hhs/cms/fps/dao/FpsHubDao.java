package gov.hhs.cms.fps.dao;

import java.util.List;
import java.util.Set;

import org.springframework.dao.DataAccessException;

import gov.hhs.cms.fps.model.FpsUser;
import gov.hhs.cms.fps.model.NvUcmSummary;
import gov.hhs.cms.fps.model.generated.FpsActnBrrRfrnc;
import gov.hhs.cms.fps.model.generated.FpsActnTypeRfrnc;
import gov.hhs.cms.fps.model.generated.FpsActvtyTypeRfrnc;
import gov.hhs.cms.fps.model.generated.FpsAlertUsflnsRfrnc;
import gov.hhs.cms.fps.model.generated.FpsApsWatchlist;
import gov.hhs.cms.fps.model.generated.FpsAsrpt;
import gov.hhs.cms.fps.model.generated.FpsAsrptInvstgtn;
import gov.hhs.cms.fps.model.generated.FpsAsrptPrrty;
import gov.hhs.cms.fps.model.generated.FpsAsrptPrrtyMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptUserActvty;
import gov.hhs.cms.fps.model.generated.FpsAsrptUserAdminvActn;
import gov.hhs.cms.fps.model.generated.FpsFdsEvntTrans;
import gov.hhs.cms.fps.model.generated.FpsFdsEvntTransMdcd;
import gov.hhs.cms.fps.model.generated.FpsFdsEvntTypeRfrnc;
import gov.hhs.cms.fps.model.generated.FpsFdsNtfctn;
import gov.hhs.cms.fps.model.generated.FpsFdsNtfctnMdcd;
import gov.hhs.cms.fps.model.generated.FpsFdsSbscrptn;
import gov.hhs.cms.fps.model.generated.FpsFdsSysRfrnc;
import gov.hhs.cms.fps.model.generated.FpsPrvdrZnRstctnDtlFact;
import gov.hhs.cms.fps.model.generated.FpsRulngRfrnc;
import gov.hhs.cms.fps.model.generated.FpsRulngRsnRfrnc;
import gov.hhs.cms.fps.util.FpsEnums.ApiDeleteActionType;
import gov.hhs.cms.fps.util.FpsEnums.EventType;

public interface FpsHubDao {

	// look for events
		// save subscription
		// save notification
		
		// call retrieval service
		// return URL for sending notifications
		// retreive URL fo retrieval service
	
	public List<FpsFdsEvntTrans> findEvents();
	public FpsFdsEvntTrans insertEvent(FpsFdsEvntTrans evnt);
	public FpsFdsSbscrptn insertUpdateSubscription(FpsFdsSbscrptn sub)  throws DataAccessException;
	FpsFdsEvntTrans setEventAsPublished(FpsFdsEvntTrans evnt);
	public void insertPriority(FpsAsrptPrrty p);
	List<FpsFdsSbscrptn> findSubscriptions(String url);
	public List<FpsFdsSysRfrnc> findSystem(String systemName);
	public FpsFdsNtfctn insertSentNotification(FpsFdsNtfctn dbNot);
	public List<FpsFdsNtfctn> findSentEvents(Integer eventId, String systemId);
	public FpsFdsNtfctn findSentEvent(Integer sentEventId);
	public void updateNotification(Integer sentEventId, boolean b);
	public List<FpsFdsSbscrptn> findSubscriptions(String eventType, String entityId, String systemId);
	public List<FpsFdsEvntTrans> findEvents(EventType caseExists);
	public List<FpsAsrptInvstgtn> findUcmInvestigations(String caseId);
	public void deleteUcmCases(String caseId);
	List<FpsRulngRfrnc> findRulingByDesc(String desc);
	List<FpsActvtyTypeRfrnc> findActivityByDesc(String desc);
	List<FpsActnBrrRfrnc> findBarrierByDesc(String desc);
	List<FpsActnTypeRfrnc> findActionByDesc(String desc);
	List<FpsAlertUsflnsRfrnc> findUsefulnessByDesc(String desc);
	public List<FpsRulngRsnRfrnc> findRulingReasonByDesc(String description);
	List<FpsFdsSbscrptn> findSubscriptionsForNotifications(String eventType, String entityId, String systemId);
	public void processZoneRestriction(FpsPrvdrZnRstctnDtlFact zr);
	public void deleteZoneRestriction(FpsPrvdrZnRstctnDtlFact zr);
	FpsPrvdrZnRstctnDtlFact loadZoneRestriction(String npi);
	public List<FpsFdsNtfctn> findUnsentEvents(int failedNum);
	public void updateAsrUcmLink(String asr, String npi);
	public void updateMdcdAsrUcmLink(String asr, String npi);
	public FpsAsrptUserActvty loadActivityByUcmId(String ucmId);
	public FpsAsrptUserAdminvActn loadActionByUcmId(String ucmId);
	public void refreshMqt(String table);
	public List<FpsAsrpt> findNewApsAsrs();
	public List<FpsAsrpt> findFollowUpAsrs();
	public void insertSys(FpsFdsSysRfrnc sys);
	List<FpsFdsSbscrptn> findSubscriptionsForWatchlist(String userId);
	List<FpsFdsEvntTypeRfrnc> findWatchlistTypes();
	List<FpsFdsEvntTrans> findWatchlistEvents();
	List<FpsFdsEvntTrans> findWatchlistEvents(EventType type);
	public void autoPruneExclusionLists();
	List<String> loadZonesByAsrptId(Integer asrptId);
	public List<FpsFdsSbscrptn> findSubscriptionsForNotifications(String eventType, String entityId, String systemId,
			List<String> zones);
	public void insertWatchlistItem(FpsApsWatchlist wl);
	public Set<Object> submitCustomASRRequest(FpsUser user, List<Object> asrptIds);
	public boolean isInsightEngineRunning();
	public void markCustomAsrListAsProcessed(Integer listId);
	public List<NvUcmSummary> findUcmSummaryForNpis(List<String> npis);
	public void checkForExpiredExclusionSets();
	public List<String> getOnePiCasesForAsrs();
	void deleteUcmCases(String caseId, ApiDeleteActionType deleteType, Integer investId);
	void insertPriority(FpsAsrptPrrtyMdcd p);
	public FpsFdsEvntTransMdcd setMdcdEventAsPublished(FpsFdsEvntTransMdcd dbEvent);
	public void updateMdcdNotification(Integer sentEventId, boolean b);
	public List<FpsFdsEvntTransMdcd> findMdcdEvents(EventType caseExists);
	public List<FpsFdsNtfctnMdcd> findMdcdSentEvents(Integer eventId, String systemID);
	public FpsFdsNtfctnMdcd insertMdcdSentNotification(FpsFdsNtfctnMdcd dbNot);
	FpsFdsNtfctnMdcd findMdcdSentEvent(Integer sentEventId);
	public FpsFdsEvntTransMdcd insertEvent(FpsFdsEvntTransMdcd dbEvent);
	void updateCrosswalk();
	void deleteUcmCases(String caseId, ApiDeleteActionType deleteType, Integer investId, String eventId);
	void deleteStandaloneUcmRecord(String caseId, ApiDeleteActionType deleteType, String npi, String eventId);

}
	
