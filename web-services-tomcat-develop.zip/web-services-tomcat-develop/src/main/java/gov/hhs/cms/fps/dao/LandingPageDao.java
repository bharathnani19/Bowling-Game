package gov.hhs.cms.fps.dao;

import java.util.List;

import gov.hhs.cms.fps.model.AsrManagementReportItem;
import gov.hhs.cms.fps.model.FpsSystemStatus;
import gov.hhs.cms.fps.model.WatchlistItem;
import gov.hhs.cms.fps.model.generated.FpsPlndSysOutge;
import gov.hhs.cms.fps.model.generated.FpsPrtlAcsRqst;
import gov.hhs.cms.fps.model.generated.FpsRptAcsMtrxVw;
import gov.hhs.cms.fps.model.generated.FpsSysMsg;
import gov.hhs.cms.fps.util.FpsEnums.EventType;

public interface LandingPageDao {
	public List<FpsSysMsg> loadSystemMessages();
	/**
	 * Adds the update system message.
	 *
	 * @param message the message
	 */
	public FpsSysMsg addUpdateSystemMessage(FpsSysMsg message);
	public void deleteSystemMessage(int sysMsgId);
	public List<FpsPlndSysOutge> loadSystemOutages();
	/**
	 * Adds the update planned system outage.
	 *
	 * @param outage the outage
	 */
	public FpsPlndSysOutge addUpdatePlannedSystemOutage(FpsPlndSysOutge outage);
	public void deleteSystemOutage(int sysOutageId);

	public List<FpsPrtlAcsRqst> loadUserAccessRequests(String zone);
	List<FpsSystemStatus> loadSystemStatus();
	List<AsrManagementReportItem> loadAsrManagementReport(String userId, String userZone, String role);
	Integer getSystemMessageNewCount(String userId);
	public List<FpsSysMsg> loadSystemMessages(boolean admin);
	List<FpsRptAcsMtrxVw> loadReportLinks(String userId, String userZone, String role, Integer[] ids, boolean isVmReports);
	List<FpsRptAcsMtrxVw> loadAllReportLinks(String userId, String userZone, String role, boolean isVmReports);
}
