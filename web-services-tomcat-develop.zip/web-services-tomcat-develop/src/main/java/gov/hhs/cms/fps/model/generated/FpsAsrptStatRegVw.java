package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import gov.hhs.cms.fps.util.VarcharIntegerType;
@Entity
@Table(name="FPS_ASRPT_STAT_REG_VW")
@TypeDefs({

    @TypeDef(name = VarcharIntegerType.NAME, typeClass = VarcharIntegerType.class)

})

public class FpsAsrptStatRegVw implements Serializable {
 
	public FpsAsrptStatRegVw() {
		super();
	}
	public FpsAsrptStatRegVw(Integer asrptId, String type, String value) {
		super();
		this.asrptId = asrptId;
		this.type = type;
		this.value = value;
	}
	private Integer asrptId;
	private String type;
	private String value;
	private FpsAsrpt fpsAsrpt;
	@Id
	@Column(name="ASRPT_ID")
	@Type(type=VarcharIntegerType.NAME)
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	@Id
	@Column(name="TYPE")
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Id
	@Column(name="VALUE")
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_ID", updatable=false, insertable=false)
	public FpsAsrpt getFpsAsrpt() {
		return fpsAsrpt;
	}
	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
		this.fpsAsrpt = fpsAsrpt;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((asrptId == null) ? 0 : asrptId.hashCode());
		result = prime * result + ((fpsAsrpt == null) ? 0 : fpsAsrpt.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FpsAsrptStatRegVw other = (FpsAsrptStatRegVw) obj;
		if (asrptId == null) {
			if (other.asrptId != null)
				return false;
		} else if (!asrptId.equals(other.asrptId))
			return false;
		if (fpsAsrpt == null) {
			if (other.fpsAsrpt != null)
				return false;
		} else if (!fpsAsrpt.equals(other.fpsAsrpt))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}

}
