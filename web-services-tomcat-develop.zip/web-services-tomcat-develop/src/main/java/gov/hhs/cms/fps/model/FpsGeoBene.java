package gov.hhs.cms.fps.model;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.io.Serializable;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonInclude(Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.ANY, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class FpsGeoBene extends FpsGeoBase implements Serializable {
	private Long beneSk;
	private String hicn;
	private String mbi;
	private String birthDt;
	private String deathDt;
	private int age;
	private String gender;
	private String phone;


	public String getHicn() {
		return this.hicn;
	}

	public void setHicn(String hicn) {
		this.hicn = hicn;
	}

	public String getBirthDt() {
		return this.birthDt;
	}

	public void setBirthDt(String birthDt) {
		this.birthDt = birthDt;
	}

	public String getDeathDt() {
		return this.deathDt;
	}

	public void setDeathDt(String deathDt) {
		this.deathDt = deathDt;
	}

	public int getAge() {
		return this.age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Long getBeneSk() {
		return this.beneSk;
	}

	public void setBeneSk(Long beneSk) {
		this.beneSk = beneSk;
	}

	public int hashCode() {
		int prime = 31;
		int result = 1;
		result = 31 * result + (this.beneSk == null ? 0 : this.beneSk.hashCode());
		result = 31 * result + (this.hicn == null ? 0 : this.hicn.hashCode());
		return result;
	}

	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		FpsGeoBene other = (FpsGeoBene) obj;
		if (this.beneSk == null) {
			if (other.beneSk != null) {
				return false;
			}
		} else if (!this.beneSk.equals(other.beneSk)) {
			return false;
		}
		if (this.hicn == null) {
			if (other.hicn != null) {
				return false;
			}
		} else if (!this.hicn.equals(other.hicn)) {
			return false;
		}
		return true;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMbi() {
		return mbi;
	}

	public void setMbi(String mbi) {
		this.mbi = mbi;
	}
}
