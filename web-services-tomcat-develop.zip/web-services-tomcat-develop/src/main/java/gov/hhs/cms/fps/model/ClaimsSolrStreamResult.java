package gov.hhs.cms.fps.model;

import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class ClaimsSolrStreamResult {

	private List<SolrStreamAsrDetailClaimLineItem> docs;

	public List<SolrStreamAsrDetailClaimLineItem> getDocs() {
		return docs;
	}

	public void setDocs(List<SolrStreamAsrDetailClaimLineItem> docs) {
		this.docs = docs;
	}
}
