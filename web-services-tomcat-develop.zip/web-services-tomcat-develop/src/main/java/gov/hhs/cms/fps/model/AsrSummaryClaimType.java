/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class AsrSummaryClaimType.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrSummaryClaimType  implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2243941694856418623L;
	
	/** The claim type cd. */
	private String claimTypeCd;
	
	/** The claim type desc. */
	private String claimTypeDesc;
	
	public AsrSummaryClaimType() {
		
	}
	public AsrSummaryClaimType(String cd, String desc) {
		this.claimTypeCd = cd;
		this.claimTypeDesc = desc;
	}
	/**
	 * Gets the claim type cd.
	 *
	 * @return the claim type cd
	 */
	public String getClaimTypeCd() {
		return claimTypeCd;
	}
	
	/**
	 * Sets the claim type cd.
	 *
	 * @param claimTypeCd the new claim type cd
	 */
	public void setClaimTypeCd(String claimTypeCd) {
		this.claimTypeCd = claimTypeCd;
	}
	
	/**
	 * Gets the claim type desc.
	 *
	 * @return the claim type desc
	 */
	public String getClaimTypeDesc() {
		return claimTypeDesc;
	}
	
	/**
	 * Sets the claim type desc.
	 *
	 * @param claimTypeDesc the new claim type desc
	 */
	public void setClaimTypeDesc(String claimTypeDesc) {
		this.claimTypeDesc = claimTypeDesc;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((claimTypeCd == null) ? 0 : claimTypeCd.hashCode());
		result = prime * result + ((claimTypeDesc == null) ? 0 : claimTypeDesc.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AsrSummaryClaimType other = (AsrSummaryClaimType) obj;
		if (claimTypeCd == null) {
			if (other.claimTypeCd != null)
				return false;
		} else if (!claimTypeCd.equals(other.claimTypeCd))
			return false;
		if (claimTypeDesc == null) {
			if (other.claimTypeDesc != null)
				return false;
		} else if (!claimTypeDesc.equals(other.claimTypeDesc))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "AsrSummaryClaimType [" + (claimTypeCd != null ? "claimTypeCd=" + claimTypeCd : "") + "]";
	}
	public String toSearchString() {
		return "[" + (claimTypeCd != null ? "claimTypeCd=" + claimTypeCd : "") + "]";
	}
}
