package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.hibernate.annotations.Where;

@Entity
@Table(name="FPS_PRE_PYMT_DNL", schema = "MIE")
@BatchSize(size=100)
public class FpsPrePymtDnl implements Serializable {
	private int fpsPrePymtDnlId;
	private String npiNum;
	private Date lastRcncldDt;
	private String modelName;
	private Date dtctn1stDnlDt;
	private Date dtctnLastDnlDt;
	private Long dndClmCnt;
	private BigDecimal totClmPymtDndAmt;
	private Long lineItmDndCnt;
	private BigDecimal totCllPymnDndAmt;
	private Long uniqPrcdrCnt; 
	private String fpsVrsnInd;
	private FpsPrvdr fpsPrvdr;
	private FpsEditNumRfrnc fpsEditNumRfrnc;
	private Long rjctdCdCnt;

	@Id
	@GeneratedValue
	@Column(name="FPS_PRE_PYMT_DNL_ID")
	public int getFpsPrePymtDnlId() {
		return fpsPrePymtDnlId;
	}
	public void setFpsPrePymtDnlId(int fpsPrePymtDnlId) {
		this.fpsPrePymtDnlId = fpsPrePymtDnlId;
	}
	@Column(name="NPI_NUM")
	public String getNpiNum() {
		return npiNum;
	}
	public void setNpiNum(String npiNum) {
		this.npiNum = npiNum;
	}
	@Temporal(TemporalType.DATE)
	@Column(name="LAST_RCNCLD_DT")
	public Date getLastRcncldDt() {
		return lastRcncldDt;
	}
	public void setLastRcncldDt(Date lastRcncldDt) {
		this.lastRcncldDt = lastRcncldDt;
	}
	@Column(name="MODEL_NAME")
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	@Temporal(TemporalType.DATE)
	@Column(name="DTCTN_1ST_DNL_DT")
	public Date getDtctn1stDnlDt() {
		return dtctn1stDnlDt;
	}
	public void setDtctn1stDnlDt(Date dtctn1stDnlDt) {
		this.dtctn1stDnlDt = dtctn1stDnlDt;
	}
	@Temporal(TemporalType.DATE)
	@Column(name="DTCTN_LAST_DNL_DT")
	public Date getDtctnLastDnlDt() {
		return dtctnLastDnlDt;
	}
	public void setDtctnLastDnlDt(Date dtctnLastDnlDt) {
		this.dtctnLastDnlDt = dtctnLastDnlDt;
	}
	@Column(name="DND_CLM_CNT")
	public Long getDndClmCnt() {
		return dndClmCnt;
	}
	public void setDndClmCnt(Long dndClmCnt) {
		this.dndClmCnt = dndClmCnt;
	}
	@Column(name="TOT_CLM_PYMT_DND_AMT")
	public BigDecimal getTotClmPymtDndAmt() {
		return totClmPymtDndAmt;
	}
	public void setTotClmPymtDndAmt(BigDecimal totClmPymtDndAmt) {
		this.totClmPymtDndAmt = totClmPymtDndAmt;
	}
	@Column(name="LINE_ITM_DND_CNT")
	public Long getLineItmDndCnt() {
		return lineItmDndCnt;
	}
	public void setLineItmDndCnt(Long lineItmDndCnt) {
		this.lineItmDndCnt = lineItmDndCnt;
	}
	@Column(name="TOT_CLL_PYMT_DND_AMT")
	public BigDecimal getTotCllPymnDndAmt() {
		return totCllPymnDndAmt;
	}
	public void setTotCllPymnDndAmt(BigDecimal totCllPymnDndAmt) {
		this.totCllPymnDndAmt = totCllPymnDndAmt;
	}
	@Column(name="UNIQ_PRCDR_CNT")
	public Long getUniqPrcdrCnt() {
		return uniqPrcdrCnt;
	}
	public void setUniqPrcdrCnt(Long uniqPrcdrCnt) {
		this.uniqPrcdrCnt = uniqPrcdrCnt;
	}
	@Column(name="FPS_VRSN_IND")
	public String getFpsVrsnInd() {
		return fpsVrsnInd;
	}
	public void setFpsVrsnInd(String fpsVrsnInd) {
		this.fpsVrsnInd = fpsVrsnInd;
	}
	
	@Fetch(FetchMode.SELECT)
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "NPI_NUM",referencedColumnName = "PRVDR_NPI_NUM", updatable=false, insertable=false)
	@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
	@NotFound(action=NotFoundAction.IGNORE) 
	public FpsPrvdr getFpsPrvdr() {
		return fpsPrvdr;
	}
	public void setFpsPrvdr(FpsPrvdr fpsPrvdr) {
		this.fpsPrvdr = fpsPrvdr;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MODEL_NAME", referencedColumnName="FPS_EDIT_NAME", updatable=false, insertable=false)
	@Where(clause="actv_ind != 'D' ")
	public FpsEditNumRfrnc getFpsEditNumRfrnc() {
		return fpsEditNumRfrnc;
	}
	public void setFpsEditNumRfrnc(FpsEditNumRfrnc fpsEditNumRfrnc) {
		this.fpsEditNumRfrnc = fpsEditNumRfrnc;
	}
	@Transient
	public Long getRjctdCdCnt() {
		return rjctdCdCnt;
	}
	public void setRjctdCdCnt(Long rjctdCdCnt) {
		this.rjctdCdCnt = rjctdCdCnt;
	}

}
