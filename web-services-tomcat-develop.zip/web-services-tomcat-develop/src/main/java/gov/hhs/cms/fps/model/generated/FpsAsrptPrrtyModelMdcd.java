package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="FPS_ASRPT_PRRTY_MODEL_MDCD")
public class FpsAsrptPrrtyModelMdcd implements Serializable {
	private Integer asrptPrrtyModelId;
	private Integer asrptPrrtyId;
	private FpsAsrptPrrtyMdcd fpsAsrptPrrty;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private Date modelRunDt;
	private String modelBusnsId;
	private String userPrrtyInd;
	private String stateCd;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)

	@Column(name="ASRPT_PRRTY_MODEL_MDCD_ID")
	public Integer getAsrptPrrtyModelId() {
		return asrptPrrtyModelId;
	}
	public void setAsrptPrrtyModelId(Integer asrptPrrtyModelId) {
		this.asrptPrrtyModelId = asrptPrrtyModelId;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_PRRTY_MDCD_ID", updatable=false, insertable=false)
	public FpsAsrptPrrtyMdcd getFpsAsrptPrrty() {
		return fpsAsrptPrrty;
	}
	public void setFpsAsrptPrrty(FpsAsrptPrrtyMdcd fpsAsrptPrrty) {
		this.fpsAsrptPrrty = fpsAsrptPrrty;
	}
	@Column(name="AUDT_INSRT_ID")
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	@Column(name="AUDT_INSRT_TS")
	public Date getAudtInsrtTs() {
		return audtInsrtTs;
	}
	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	@Column(name="MODEL_RUN_DT")
	public Date getModelRunDt() {
		return modelRunDt;
	}
	public void setModelRunDt(Date modelRunDt) {
		this.modelRunDt = modelRunDt;
	}
	@Column(name="MODEL_BUSNS_ID")
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	@Column(name="USER_PRRTY_IND")
	public String getUserPrrtyInd() {
		return userPrrtyInd;
	}
	public void setUserPrrtyInd(String userPrrtyInd) {
		this.userPrrtyInd = userPrrtyInd;
	}
	@Column(name="ASRPT_PRRTY_MDCD_ID")
	public Integer getAsrptPrrtyId() {
		return asrptPrrtyId;
	}
	public void setAsrptPrrtyId(Integer asrptPrrtyId) {
		this.asrptPrrtyId = asrptPrrtyId;
	}
	@Column(name="STATE_CD")
	public String getStateCd() {
		return stateCd;
	}
	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}
	


}
