package gov.hhs.cms.fps.model;

import java.io.Serializable;

public class FpsSentEvent implements Serializable {
	private Integer sentEventId;
	private Integer eventId;
	private String status;
	private Integer attemptCnt;
	public Integer getSentEventId() {
		return sentEventId;
	}
	public void setSentEventId(Integer sentEventId) {
		this.sentEventId = sentEventId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getAttemptCnt() {
		return attemptCnt;
	}
	public void setAttemptCnt(Integer attemptCnt) {
		this.attemptCnt = attemptCnt;
	}
	public Integer getEventId() {
		return eventId;
	}
	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

}
