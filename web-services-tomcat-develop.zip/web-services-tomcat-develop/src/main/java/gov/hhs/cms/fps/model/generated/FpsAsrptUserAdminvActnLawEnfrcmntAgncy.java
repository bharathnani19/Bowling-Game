package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.BatchSize;
@Entity
@Table(name = "FPS_ASRPT_USER_ADMINV_ACTN_RFRL_AGNCY_DTL")
@BatchSize(size = 100)
public class FpsAsrptUserAdminvActnLawEnfrcmntAgncy implements Serializable {
	private Integer asrptUserAdminvLawEnfrcmntId;
	private String agncyNm;
	private String agncyRspns;
	private Date rfrdDt;
	private Date rspnsDt;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private String audtUpdtId;
	private Date audtUpdtTs;
	private FpsAsrptUserAdminvActnLawEnfrcmnt fpsAsrptUserAdminvActnLawEnfrcmnt;
	@Column(name = "AGNCY_NM")

	public String getAgncyNm() {
		return agncyNm;
	}

	public void setAgncyNm(String agncyNm) {
		this.agncyNm = agncyNm;
	}
	@Column(name = "AGNCY_RSPNS")

	public String getAgncyRspns() {
		return agncyRspns;
	}

	public void setAgncyRspns(String agncyRspns) {
		this.agncyRspns = agncyRspns;
	}
	@Temporal(TemporalType.DATE)
	@Column(name = "RFRD_DT")
	public Date getRfrdDt() {
		return rfrdDt;
	}

	public void setRfrdDt(Date rfrdDt) {
		this.rfrdDt = rfrdDt;
	}
	@Temporal(TemporalType.DATE)
	@Column(name = "RSPNS_DT")
	public Date getRspnsDt() {
		return rspnsDt;
	}

	public void setRspnsDt(Date rspnsDt) {
		this.rspnsDt = rspnsDt;
	}




	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_USER_ADMINV_ACTN_RFRL_DTL_ID")
	public FpsAsrptUserAdminvActnLawEnfrcmnt getFpsAsrptUserAdminvActnLawEnfrcmnt() {
		return fpsAsrptUserAdminvActnLawEnfrcmnt;
	}

	public void setFpsAsrptUserAdminvActnLawEnfrcmnt(FpsAsrptUserAdminvActnLawEnfrcmnt fpsAsrptUserAdminvActnLawEnfrcmnt) {
		this.fpsAsrptUserAdminvActnLawEnfrcmnt = fpsAsrptUserAdminvActnLawEnfrcmnt;
	}
	@Column(name = "AUDT_INSRT_ID", nullable = false, length = 128)
	public String getAudtInsrtId() {
		return this.audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_INSRT_TS")
	public Date getAudtInsrtTs() {
		return this.audtInsrtTs;
	}

	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	@Column(name = "AUDT_UPDT_ID", length = 128)
	public String getAudtUpdtId() {
		return this.audtUpdtId;
	}

	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_UPDT_TS", length = 26)
	public Date getAudtUpdtTs() {
		return this.audtUpdtTs;
	}

	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}

	@Id
	@SequenceGenerator(name="asrpt_user_adminv_actn_rfrl_agncy_dtl_id_seq",  sequenceName = "asrpt_user_adminv_actn_rfrl_agncy_dtl_id_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "asrpt_user_adminv_actn_rfrl_agncy_dtl_id_seq")	
	
	@Column(name="ASRPT_USER_ADMINV_ACTN_RFRL_AGNCY_DTL_ID")
	public Integer getAsrptUserAdminvLawEnfrcmntId() {
		return asrptUserAdminvLawEnfrcmntId;
	}

	public void setAsrptUserAdminvLawEnfrcmntId(Integer asrptUserAdminvLawEnfrcmntId) {
		this.asrptUserAdminvLawEnfrcmntId = asrptUserAdminvLawEnfrcmntId;
	}
	
	
}
