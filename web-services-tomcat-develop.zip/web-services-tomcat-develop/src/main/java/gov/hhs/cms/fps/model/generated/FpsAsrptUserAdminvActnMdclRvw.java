package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.hibernate.annotations.Type;
@Entity
@Table(name="FPS_ASRPT_USER_ADMINV_ACTN_MDCL_RVW")
public class FpsAsrptUserAdminvActnMdclRvw implements Serializable {
	private Integer asrptUserAdminvActnMdclRvwId;
	private FpsAsrptUserAdminvActn fpsAsrptUserAdminvActn;
	private String mrRecordId;
	private String mrRecordType;
	private String programType;
	private String benefitType;
	private String status;
	private String subStatus;
	private String npiNum;
	private String parentRecordId;

	private LocalDateTime openDt;	

	private LocalDateTime closedDt;

	private LocalDateTime cancelDt;
	private BigDecimal denialRate;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private String audtUpdtId;
	private Date audtUpdtTs;
	private String recChgInd;
	private List<FpsAsrptUserAdminvActnMdclRvwDnl> fpsAsrptUserAdminvActnMdclRvwDnls;
	private List<FpsAsrptUserAdminvActnMdclRvwModelCntrbtn> fpsAsrptUserAdminvActnMdclRvwModelCntrbtns;
	@Id
	@SequenceGenerator(name="asrpt_user_adminv_actn_mdcl_rvw_id_seq",  sequenceName = "asrpt_user_adminv_actn_mdcl_rvw_id_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "asrpt_user_adminv_actn_mdcl_rvw_id_seq")
	@Column(name = "ASRPT_USER_ADMINV_ACTN_MDCL_RVW_ID", unique = true, nullable = false)
	public Integer getAsrptUserAdminvActnMdclRvwId() {
		return asrptUserAdminvActnMdclRvwId;
	}
	public void setAsrptUserAdminvActnMdclRvwId(Integer asrptUserAdminvActnMdclRvwId) {
		this.asrptUserAdminvActnMdclRvwId = asrptUserAdminvActnMdclRvwId;
	}

	@Column(name = "MR_RCRD_ID")
	public String getMrRecordId() {
		return mrRecordId;
	}
	public void setMrRecordId(String mrRecordId) {
		this.mrRecordId = mrRecordId;
	}
	@Column(name = "MR_RCRD_TYPE")
	public String getMrRecordType() {
		return mrRecordType;
	}
	public void setMrRecordType(String mrRecordType) {
		this.mrRecordType = mrRecordType;
	}
	@Column(name = "PGM_TYPE")
	public String getProgramType() {
		return programType;
	}
	public void setProgramType(String programType) {
		this.programType = programType;
	}
	@Column(name = "BNFT_TYPE")
	public String getBenefitType() {
		return benefitType;
	}
	public void setBenefitType(String benefitType) {
		this.benefitType = benefitType;
	}
	@Column(name = "MR_STUS")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Column(name = "MR_SUB_STUS")
	public String getSubStatus() {
		return subStatus;
	}
	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}
	@Column(name = "NPI_NUM")
	public String getNpiNum() {
		return npiNum;
	}
	public void setNpiNum(String npiNum) {
		this.npiNum = npiNum;
	}
	@Column(name = "PRNT_RCRD_ID")
	public String getParentRecordId() {
		return parentRecordId;
	}
	public void setParentRecordId(String parentRecordId) {
		this.parentRecordId = parentRecordId;
	}
	@Column(name = "RCRD_OPEN_TS")
//	@Type(type = "gov.hhs.cms.fps.util.LocalDateTimeWrapperType")
	public LocalDateTime getOpenDt() {
		return openDt;
	}
	public void setOpenDt(LocalDateTime openDt) {
		this.openDt = openDt;
	}
	@Column(name = "RCRD_CLSD_TS")
//	@Type(type = "gov.hhs.cms.fps.util.LocalDateTimeWrapperType")

	public LocalDateTime getClosedDt() {
		return closedDt;
	}
	public void setClosedDt(LocalDateTime closedDt) {
		this.closedDt = closedDt;
	}
	@Column(name = "RCRD_CNCLD_TS")
//	@Type(type = "gov.hhs.cms.fps.util.LocalDateTimeWrapperType")
	public LocalDateTime getCancelDt() {
		return cancelDt;
	}
	public void setCancelDt(LocalDateTime cancelDt) {
		this.cancelDt = cancelDt;
	}
	@Column(name = "DNL_RATE_AMT")
	public BigDecimal getDenialRate() {
		return denialRate;
	}
	public void setDenialRate(BigDecimal denialRate) {
		this.denialRate = denialRate;
	}


	@Column(name = "AUDT_INSRT_ID", nullable = false, length = 128)
	public String getAudtInsrtId() {
		return this.audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_INSRT_TS", nullable = false, length = 26)
	public Date getAudtInsrtTs() {
		return this.audtInsrtTs;
	}

	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	@Column(name = "AUDT_UPDT_ID", length = 128)
	public String getAudtUpdtId() {
		return this.audtUpdtId;
	}

	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_UPDT_TS", length = 26)
	public Date getAudtUpdtTs() {
		return this.audtUpdtTs;
	}

	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}

	@Column(name = "REC_CHG_IND", length = 1)
	public String getRecChgInd() {
		return this.recChgInd;
	}

	public void setRecChgInd(String recChgInd) {
		this.recChgInd = recChgInd;
	}
	
	@Fetch(FetchMode.SELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "fpsAsrptUserAdminvActnMdclRvw", cascade = CascadeType.ALL)
	@BatchSize(size=1000)
	@NotFound(action = NotFoundAction.IGNORE)
	public List<FpsAsrptUserAdminvActnMdclRvwDnl> getFpsAsrptUserAdminvActnMdclRvwDnls() {
		return fpsAsrptUserAdminvActnMdclRvwDnls;
	}
	public void setFpsAsrptUserAdminvActnMdclRvwDnls(
			List<FpsAsrptUserAdminvActnMdclRvwDnl> fpsAsrptUserAdminvActnMdclRvwDnls) {
		this.fpsAsrptUserAdminvActnMdclRvwDnls = fpsAsrptUserAdminvActnMdclRvwDnls;
	}
	
	@Fetch(FetchMode.SELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "fpsAsrptUserAdminvActnMdclRvw", cascade = CascadeType.ALL)
	@BatchSize(size=1000)
	@NotFound(action = NotFoundAction.IGNORE)
	public List<FpsAsrptUserAdminvActnMdclRvwModelCntrbtn> getFpsAsrptUserAdminvActnMdclRvwModelCntrbtns() {
		return fpsAsrptUserAdminvActnMdclRvwModelCntrbtns;
	}
	public void setFpsAsrptUserAdminvActnMdclRvwModelCntrbtns(
			List<FpsAsrptUserAdminvActnMdclRvwModelCntrbtn> fpsAsrptUserAdminvActnMdclRvwModelCntrbtns) {
		this.fpsAsrptUserAdminvActnMdclRvwModelCntrbtns = fpsAsrptUserAdminvActnMdclRvwModelCntrbtns;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_USER_ADMINV_ACTN_ID")
	
	public FpsAsrptUserAdminvActn getFpsAsrptUserAdminvActn() {
		return fpsAsrptUserAdminvActn;
	}
	public void setFpsAsrptUserAdminvActn(FpsAsrptUserAdminvActn fpsAsrptUserAdminvActn) {
		this.fpsAsrptUserAdminvActn = fpsAsrptUserAdminvActn;
	}

}
