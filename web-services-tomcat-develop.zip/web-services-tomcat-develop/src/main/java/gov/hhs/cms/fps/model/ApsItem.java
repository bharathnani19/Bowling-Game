package gov.hhs.cms.fps.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.hhs.cms.fps.util.NAStringSerializer;
import gov.hhs.cms.fps.util.FpsEnums.EntityType;
import gov.hhs.cms.fps.util.FpsEnums.EventType;

public class ApsItem extends WatchlistItem {
	private String userEmail;
	private String userId;
	private EntityType type = EntityType.WATCHLIST;
	private EventType eventType = EventType.APS;
	private String eventName = "APS";
	private String emailSubject = "APS Criminal Data Watchlist Notification";
	private String subjId;
	private String name;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String newAlerts;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String agedAlerts;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private Date lastAlertCreateDt;
	private String prioritizeMine;
	private String prioritizeOther;
	private Integer asrId;
	public ApsItem() {}
	public ApsItem(String userId) {
		this.userId = userId;
	}
	@Override
	public EntityType getType() {
		// TODO Auto-generated method stub
		return type;
	}

	@Override
	public String getUserId() {
		// TODO Auto-generated method stub
		return userId;
	}

	@Override
	public String getUserEmail() {
		// TODO Auto-generated method stub
		return userEmail;
	}

	public EventType getEventType() {
		return eventType;
	}

	public void setEventType(EventType eventType) {
		this.eventType = eventType;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEmailSubject() {
		return emailSubject;
	}

	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNewAlerts() {
		return newAlerts;
	}
	public void setNewAlerts(String newAlerts) {
		this.newAlerts = newAlerts;
	}
	public String getAgedAlerts() {
		return agedAlerts;
	}
	public void setAgedAlerts(String agedAlerts) {
		this.agedAlerts = agedAlerts;
	}
	public Date getLastAlertCreateDt() {
		return lastAlertCreateDt;
	}
	public void setLastAlertCreateDt(Date lastAlertCreateDt) {
		this.lastAlertCreateDt = lastAlertCreateDt;
	}
	public String getPrioritizeMine() {
		return prioritizeMine;
	}
	public void setPrioritizeMine(String prioritizeMine) {
		this.prioritizeMine = prioritizeMine;
	}
	public String getPrioritizeOther() {
		return prioritizeOther;
	}
	public void setPrioritizeOther(String prioritizeOther) {
		this.prioritizeOther = prioritizeOther;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public void setType(EntityType type) {
		this.type = type;
	}
	public String getSubjId() {
		return subjId;
	}
	public void setSubjId(String subjId) {
		this.subjId = subjId;
	}
	public Integer getAsrId() {
		return asrId;
	}
	public void setAsrId(Integer asrId) {
		this.asrId = asrId;
	}

}
