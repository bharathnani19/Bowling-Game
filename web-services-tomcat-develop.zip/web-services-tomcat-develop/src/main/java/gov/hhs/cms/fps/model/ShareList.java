package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class ShareList implements Serializable{

	private List<PrioritizationShareGroupUser> availableUsers;
	private List<PrioritizationShareGroupUser> sharedUsers;
	public List<PrioritizationShareGroupUser> getAvailableUsers() {
		return availableUsers;
	}
	public void setAvailableUsers(List<PrioritizationShareGroupUser> availableUsers) {
		this.availableUsers = availableUsers;
	}
	public List<PrioritizationShareGroupUser> getSharedUsers() {
		return sharedUsers;
	}
	public void setSharedUsers(List<PrioritizationShareGroupUser> sharedUsers) {
		this.sharedUsers = sharedUsers;
	}
	
}
