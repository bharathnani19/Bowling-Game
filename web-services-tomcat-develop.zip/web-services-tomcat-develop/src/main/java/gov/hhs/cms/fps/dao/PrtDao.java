package gov.hhs.cms.fps.dao;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import gov.hhs.cms.fps.model.generated.FpsEditNumRfrnc;
import gov.hhs.cms.fps.model.generated.FpsFilStore;
import gov.hhs.cms.fps.model.generated.FpsStusRfrnc;
import gov.hhs.cms.fps.model.generated.prt.FpsAfctdSysRfrnc;
import gov.hhs.cms.fps.model.generated.prt.FpsClmCntRngRfrnc;
import gov.hhs.cms.fps.model.generated.prt.FpsCmsCreqRfrnc;
import gov.hhs.cms.fps.model.generated.prt.FpsDfctCtgryRfrnc;
import gov.hhs.cms.fps.model.generated.prt.FpsIssCtgryRfrnc;
import gov.hhs.cms.fps.model.generated.prt.FpsMacJrsdctnRfrnc;
import gov.hhs.cms.fps.model.generated.prt.FpsPrblmPrrtyRfrnc;
import gov.hhs.cms.fps.model.generated.prt.FpsProdnPrblmRpt;
import gov.hhs.cms.fps.model.generated.prt.FpsProdnPrblmRptOrgPoc;
import gov.hhs.cms.fps.model.generated.prt.FpsProdnPrblmRptStusRfrnc;

public interface PrtDao {

	public List<FpsAfctdSysRfrnc> loadAffectedSystems(boolean hideDeleted);
	public List<FpsClmCntRngRfrnc> loadClaimCountRanges(boolean hideDeleted);
	public List<FpsCmsCreqRfrnc> loadCmsCreqs(boolean hideDeleted);
	public List<FpsDfctCtgryRfrnc> loadDefectCategories(boolean hideDeleted);
	public List<FpsEditNumRfrnc> loadEditNumbers(boolean hideDeleted);
	public List<FpsIssCtgryRfrnc> loadIssueCategories(boolean hideDeleted);
	public List<FpsPrblmPrrtyRfrnc> loadProblemPriorities(boolean hideDeleted);
	
	public FpsProdnPrblmRpt loadPrt(Integer prtId);
	public Integer savePrt(FpsProdnPrblmRpt prt);
	public void deletePrt(Integer prtId);
	public Integer saveFile(Integer id, String userId, MultipartFile file)  throws IOException;
	public FpsFilStore loadFile(Integer id);
	public List<FpsMacJrsdctnRfrnc> loadMacs(boolean hideDeleted);
	List<FpsProdnPrblmRptOrgPoc> loadContactsByOrg(String org);
	List<FpsProdnPrblmRptStusRfrnc> loadStatuses(boolean hideDeleted);
	List<FpsProdnPrblmRptOrgPoc> loadEmailPocs(boolean hideDeleted);
	public List<FpsProdnPrblmRpt> getPrtSummary();
	public <T> T saveRefData(T target);
	public <T> T deleteEntityData(T target);
	List<FpsFilStore> deleteFile(Integer id, String userId);
	List<FpsFilStore> loadPrtFiles(Integer id);
	public void deleteChildren(FpsProdnPrblmRpt dbPrt);
	String loadStatusByCode(Integer statusCd);
	public Integer saveFile(Integer id, String loggedInUserId, FpsFilStore file);
	void deleteDbFile(Integer id);
}
