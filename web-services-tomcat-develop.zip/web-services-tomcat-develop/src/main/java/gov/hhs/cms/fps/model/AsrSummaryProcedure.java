/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class AsrSummaryProcedure.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrSummaryProcedure  implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -503370469236319920L;
	
	/** The procedure type cd. */
	private String procedureTypeCd;
	
	/** The procedure type desc. */
	private String procedureTypeDesc;
	
	/**
	 * Gets the procedure type cd.
	 *
	 * @return the procedure type cd
	 */
	public String getProcedureTypeCd() {
		return procedureTypeCd;
	}
	
	/**
	 * Sets the procedure type cd.
	 *
	 * @param procedureTypeCd the new procedure type cd
	 */
	public void setProcedureTypeCd(String procedureTypeCd) {
		this.procedureTypeCd = procedureTypeCd;
	}
	
	/**
	 * Gets the procedure type desc.
	 *
	 * @return the procedure type desc
	 */
	public String getProcedureTypeDesc() {
		return procedureTypeDesc;
	}
	
	/**
	 * Sets the procedure type desc.
	 *
	 * @param procedureTypeDesc the new procedure type desc
	 */
	public void setProcedureTypeDesc(String procedureTypeDesc) {
		this.procedureTypeDesc = procedureTypeDesc;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((procedureTypeCd == null) ? 0 : procedureTypeCd.hashCode());
		result = prime * result + ((procedureTypeDesc == null) ? 0 : procedureTypeDesc.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AsrSummaryProcedure other = (AsrSummaryProcedure) obj;
		if (procedureTypeCd == null) {
			if (other.procedureTypeCd != null)
				return false;
		} else if (!procedureTypeCd.equals(other.procedureTypeCd))
			return false;
		if (procedureTypeDesc == null) {
			if (other.procedureTypeDesc != null)
				return false;
		} else if (!procedureTypeDesc.equals(other.procedureTypeDesc))
			return false;
		return true;
	}
}
