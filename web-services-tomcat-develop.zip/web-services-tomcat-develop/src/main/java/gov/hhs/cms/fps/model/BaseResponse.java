/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * The Class BaseResponse.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class BaseResponse  implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7304361723231342657L;
	
	/** The transaction ID. */
	private String transactionID;
	
	/** The status. */
	private String status;
	
	private String statusDescription;
	
	/** The response data. */
	private List<FpsCommon> responseData;
	
	/**
	 * Gets the transaction ID.
	 *
	 * @return the transaction ID
	 */
	public String getTransactionID() {
		return transactionID;
	}
	
	/**
	 * Sets the transaction ID.
	 *
	 * @param transactionID the new transaction ID
	 */
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Gets the response data.
	 *
	 * @return the responseData
	 */
	public List<FpsCommon> getResponseData() {
		return responseData;
	}
	
	/**
	 * Sets the response data.
	 *
	 * @param responseData the responseData to set
	 */
	public void setResponseData(List<FpsCommon> responseData) {
		this.responseData = responseData;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AsrDiscoveryResponse [transactionID=" + transactionID
				+ ", status=" + status + ", responseData=" + responseData + "]";
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	
	
}
