package gov.hhs.cms.fps.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import gov.hhs.cms.fps.model.AsrDetailAlert;
import gov.hhs.cms.fps.model.AsrDetailTotalCostZone;
import gov.hhs.cms.fps.model.AsrDetailViewRequest;
import gov.hhs.cms.fps.model.AsrGenericCode;
import gov.hhs.cms.fps.model.AvailableClaims;
import gov.hhs.cms.fps.model.ClaimsSearchParameter;
import gov.hhs.cms.fps.model.ClaimsSolrStream;
import gov.hhs.cms.fps.model.FpsVisualization;
import gov.hhs.cms.fps.model.FpsVisualizationEdge;
import gov.hhs.cms.fps.model.MdcdModelState;
import gov.hhs.cms.fps.model.generated.FpsAlertClmAsctn;
import gov.hhs.cms.fps.model.generated.FpsAlertMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrDetailsPageCounts;
import gov.hhs.cms.fps.model.generated.FpsAsrptMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptPrrtyScreDtlVw;
import gov.hhs.cms.fps.model.generated.FpsAsrptRiskScreHstryVw;
import gov.hhs.cms.fps.model.generated.FpsCstmTblClmnNameMdcd;
import gov.hhs.cms.fps.model.generated.FpsCstmTblDtlMdcd;
import gov.hhs.cms.fps.model.generated.FpsCstmTblLabelSnpshtMdcd;
import gov.hhs.cms.fps.model.generated.FpsCstmTblMdcd;
import gov.hhs.cms.fps.model.generated.FpsEditNumRfrnc;
import gov.hhs.cms.fps.model.generated.FpsModel;
import gov.hhs.cms.fps.model.generated.FpsRcncltnClmline;
import gov.hhs.cms.fps.model.generated.FpsRiskScreRptCardDtl;
import gov.hhs.cms.fps.model.generated.FpsRptCardAttrLabelMdcd;
import gov.hhs.cms.fps.model.generated.FpsRptCardDtlMdcd;
import gov.hhs.cms.fps.model.generated.FpsRptCardLabelSnpShtMdcd;
import gov.hhs.cms.fps.model.generated.FpsRptCardRskSnaDtlMdcd;
import gov.hhs.cms.fps.model.generated.FpsSplmntlVizDtlMdcd;
import gov.hhs.cms.fps.model.generated.FpsSplmntlVizLabelSnpshtMdcd;
import gov.hhs.cms.fps.model.generated.MdcdBaseClaim;

public interface AsrMdcdDetailDao {

	public FpsAsrptMdcd getAsrDetail(AsrDetailViewRequest paramAsrDetailViewRequest);

	public FpsAsrptMdcd getAsrDetail(List<Integer> paramList, String paramString);



	public List<AsrDetailTotalCostZone> loadTotalCostByZone(int asrptId);

	public List<AsrDetailAlert> loadAlertsForProvider(String paramString);
	



	public Date getLastAlertDateForAsr(int paramInt);

	public List<FpsRptCardDtlMdcd> loadReportCardForModelAndNpi(int paramInt, String paramString,String state);
	public List<FpsRptCardDtlMdcd> loadReportCardForModelAndNpi(int paramInt, String paramString,String state,  Date runDate);

	public List<FpsRptCardRskSnaDtlMdcd> loadSnaReportCardForModelAndNpi(int paramInt, String paramString,String state);
	
	public HashMap<String, String> loadReportCardClaimExistInd(int paramInt, String paramString);

	public FpsAlertMdcd loadReportCardMostRecentAlert(FpsRptCardDtlMdcd paramFpsRptCardDtl);

	public FpsAlertMdcd loadReportCardMostRecentAlert(FpsRptCardRskSnaDtlMdcd paramFpsRptCardRskSnaDtl);
	public FpsAlertMdcd loadReportCardMostRecentAlert(String npi, Integer modelId,String state, Date runDate);

	public List<FpsRptCardDtlMdcd> loadReportCardClaims(int paramInt, String paramString);

	public List<FpsRptCardAttrLabelMdcd> loadReportCardLabels(FpsRptCardDtlMdcd paramFpsRptCardDtl);

	public List<FpsAlertClmAsctn> loadClaimsForModel(int paramInt, String paramString);

	public Date getLastAlertDateForReportCard(int paramInt, String paramString,String state);
	public Date getLastAlertDateForSnaReportCard(int paramInt, String paramString,String state);



	public List<FpsCstmTblMdcd> loadCustomTablesForModel(String paramString1, String paramString2,String state);

	public List<FpsCstmTblClmnNameMdcd> loadCustomTablesForModelColumns(String paramString1, String paramString2,String state);

	public List<FpsCstmTblDtlMdcd> loadCustomTablesForModelData(String modelBusnsId, String npi,String state, Date model,
			String cstmTblId);

	public Date getLastAlertDateForCustomTable(String paramString1, String paramString2,String state);
	


	
	//public List<FpsClmMdcd> loadClaimsForModel2(int modelId, String npi, boolean isPartD, Integer asrptId, Integer alertId) ;

	FpsAlertMdcd loadReportCardMostRecentAlert(String subjId, String modelBusnsId,String state);

	

	List<Date> getReportCardDatesForModel(String model, String npi,String state);

//	List<FpsClm> loadClaimsForAsr2(Integer asrptId, int rows, List<String> claimTypes,
//			Date fromDate, Date toDate, List<String> hicns, boolean isLatest, String npi, int startAt, int maxResults,SolrClaimType claimsCollection);

//	int getClaimCount(Integer asrptId, List<String> claimTypes, Date fromDate, Date toDate,
//			List<String> hicns, boolean isLatest, String npi,SolrClaimType claimsCollection);

	public List<Object[]> getHicnsForASR(int asrptId);

	List<Date> getSnaReportCardDatesForModel(String model, String npi, String state);

	List<FpsRptCardRskSnaDtlMdcd> loadSnaReportCardForModelAndNpi(int modelId, String npi,String state, Date runDate);

	List<FpsAsrptPrrtyScreDtlVw> getPriorityScoreForASR(int asrptId);

	public int getAsrIdFromReportCard(short attrSqncNum, int alertId);

	public List<FpsAsrptRiskScreHstryVw> loadRiskScoreTrend(int asrptId);


	List<FpsAsrptRiskScreHstryVw> loadRiskScoreTrend(int asrptId, Date startDt, Date endDt);

	Date getLastAlertDateForModelAndNpi(String modelId, String npi, String state);

	List<FpsAlertMdcd> loadAlertsForByModelAndNpi(String model, String npi, String state);
	FpsAlertMdcd loadAlertByAlertId(Integer alertId);

	public int getLastAlertForAsrAndModel(int asrptId, int modelId, String state);


	public List<FpsEditNumRfrnc> loadEditInfoByModel(String editNm, Boolean showInactives);
	public List<FpsRcncltnClmline> loadClaimsForNpiAndEdit(String npi, String editNm);

	List<AsrDetailTotalCostZone> loadTotalPaymentByZone(int asrptId);

	public Date getLastAlertDateForAsr(String asrNpi);

	public long getClaimCount(ClaimsSearchParameter param);

	public List<? extends MdcdBaseClaim> loadClaimsForAsr2(ClaimsSearchParameter param, int pageSize, int index);

	public List<? extends MdcdBaseClaim> getClaimsForAlertCsv(int modelId, String subjId, Integer asrptId, Integer alertId,
			String state, int pageSize, int index);

	public long getClaimsForAlertCount(int modelId, String subjId, Integer asrptId, String state, int alertId);

	public long getClaimsForReportCardCount(short attrId, Integer alertId, Integer asrptId, String state);

	public List<? extends MdcdBaseClaim> getClaimsForReportCardCsv(Short attrSqncNum, int alertId, int asrptId, String state,
			int pageSize, int index);


	AvailableClaims getAvailableClaimsForAsr(Integer asrptId, String npi, String zone);

	ClaimsSolrStream loadVizSharedBenes(FpsModel model, String npi, Date modelRunDt, List<String> relatedNPIs);

	FpsVisualization loadVisualization(String subjId, String modelId, Date modelRunDt);

	List<FpsVisualizationEdge> loadVisualizationDates(String subjId, String modelId, int rows);

	List<FpsVisualizationEdge> loadVisualizationDates(String subjId, String modelId);

	FpsVisualization loadVisualization(String subjId, String modelId);

	FpsVisualization loadHhaVisualization(String subjId, Integer ranking);

	FpsVisualization loadDmeVisualization(String subjId, Integer ranking);

	public String checkForVisualization(String subjId);

	public String checkForDmeVisualization(String subjId);

	public List<Integer> loadAvailableRptCardAttrs(int alertId, boolean isPartD);

	FpsAsrDetailsPageCounts getAllClaimCount(String npi);

	public List<FpsRiskScreRptCardDtl> loadReportCardContribModelAndNpi(String modelBusnsId, String npi, Date runDate);


	public Date loadReportCardContribMostRecentAlert(String npi, String modelBusnsId);

	public List<Object[]> loadTotalPayment(int asrptId);


	public List<MdcdModelState> loadStatesForAlert(String npi, String modelBusnsId, String status, String loggedInUserId);

	List<MdcdModelState> loadStatesForASR(Integer asrptId, String zone);

	List<AsrGenericCode> loadStatesForASRForSearch(Integer asrptId, String zone);



	Date getLastAlertDateForCustomTableViz(String modelBusnsId, String npi, Integer vizId, String state);

	List<FpsSplmntlVizDtlMdcd> loadSplmntlVizForModelRun(String modelBusnsId, String npi, Date modelRunDt,
			Integer splmtnVizId, String state);

	List<FpsSplmntlVizDtlMdcd> loadSplmntlVizForModelRun(String modelBusnsId, String npi, Date modelRunDt,
			String state);

	List<FpsRptCardLabelSnpShtMdcd> loadReportCardLabelsSnapshot(FpsRptCardDtlMdcd rptCardDtl);

	public List<FpsCstmTblLabelSnpshtMdcd> loadCustomTablesForModelSnapshot(String modelBusnsId, Date runDate);

	FpsSplmntlVizLabelSnpshtMdcd loadSplmntlVizTablesForModelSnapshot(String modelBusnsId, Date runDate,
			Integer splmtlVizId);







}
