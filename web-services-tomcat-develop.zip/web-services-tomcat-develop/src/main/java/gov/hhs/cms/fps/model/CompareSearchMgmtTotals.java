package gov.hhs.cms.fps.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL) 
public class CompareSearchMgmtTotals implements Serializable {

	private String value;
	private int landingPageCnt;
	private int summaryCnt;
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public int getLandingPageCnt() {
		return landingPageCnt;
	}
	public void setLandingPageCnt(int landingPageCnt) {
		this.landingPageCnt = landingPageCnt;
	}
	public int getSummaryCnt() {
		return summaryCnt;
	}
	public void setSummaryCnt(int summaryCnt) {
		this.summaryCnt = summaryCnt;
	}
}
