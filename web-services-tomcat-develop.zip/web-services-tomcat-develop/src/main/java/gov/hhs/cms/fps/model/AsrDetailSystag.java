/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class AsrDetailSystags.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailSystag  implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6293354856832271158L;

	private List<String> bius;
	private String nac;
	private String dnp;
	private String rev;
	private List<String> fids;
	private List<FpsCommon> ucms;
	private List<String> prepays;
	
	public List<String> getBius() {
		return bius;
	}
	public void setBius(List<String> bius) {
		this.bius = bius;
	}
	public String getNac() {
		return nac;
	}
	public void setNac(String nac) {
		this.nac = nac;
	}
	public String getDnp() {
		return dnp;
	}
	public void setDnp(String dnp) {
		this.dnp = dnp;
	}
	public String getRev() {
		return rev;
	}
	public void setRev(String rev) {
		this.rev = rev;
	}
	public List<String> getFids() {
		return fids;
	}
	public void setFids(List<String> fids) {
		this.fids = fids;
	}
	public List<FpsCommon> getUcms() {
		return ucms;
	}
	public void setUcms(List<FpsCommon> ucms) {
		this.ucms = ucms;
	}
	public List<String> getPrepays() {
		return prepays;
	}
	public void setPrepays(List<String> prepays) {
		this.prepays = prepays;
	}
}
