package gov.hhs.cms.fps.model.generated;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="FPS_ASR_DETAILS_PAGE_COUNTS")
public class FpsAsrDetailsPageCounts {
	private String npi;
	private Integer ssfCnt = 0;
	private Integer ptdCnt = 0;
	private Integer ssf90Cnt = 0;
	private Integer ptd90Cnt = 0;
	private Integer rrbCnt = 0;
	
	@Id
	@Column(name="NPI")
	public String getNpi() {
		return npi;
	}
	public void setNpi(String npi) {
		this.npi = npi;
	}
	@Column(name="ALL_SSF_CLMS_CNT")
	public Integer getSsfCnt() {
		return ssfCnt;
	}
	public void setSsfCnt(Integer ssfCnt) {
		this.ssfCnt = ssfCnt;
	}
	@Column(name="ALL_PTD_CLMS_CNT")
	public Integer getPtdCnt() {
		return ptdCnt;
	}
	public void setPtdCnt(Integer ptdCnt) {
		this.ptdCnt = ptdCnt;
	}
	@Column(name="ALL_SSF_CLMS_CNT_90D")
	public Integer getSsf90Cnt() {
		return ssf90Cnt;
	}
	public void setSsf90Cnt(Integer ssf90Cnt) {
		this.ssf90Cnt = ssf90Cnt;
	}
	@Column(name="ALL_PTD_CLMS_CNT_90D")
	public Integer getPtd90Cnt() {
		return ptd90Cnt;
	}
	public void setPtd90Cnt(Integer ptd90Cnt) {
		this.ptd90Cnt = ptd90Cnt;
	}
	@Column(name="ALL_SSF_CLMS_CNT_RRB")
	public Integer getRrbCnt() {
		return rrbCnt;
	}
	public void setRrbCnt(Integer rrbCnt) {
		this.rrbCnt = rrbCnt;
	}
}
