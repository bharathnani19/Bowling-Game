/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class AsrDiscoveryRequest.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDiscoveryRequest extends BaseRequest implements Serializable{


	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5354419867723979741L;

	/** The parameters. */
	private AsrDiscoveryParameter parameters;
	
	public AsrDiscoveryRequest(){
		
	}

	/* (non-Javadoc)
	 * @see gov.hhs.cms.fps.model.BaseRequest#getParameters()
	 */
	public AsrDiscoveryParameter getParameters() {
		return parameters;
	}

	/**
	 * Sets the parameters.
	 *
	 * @param parameters the new parameters
	 */
	public void setParameters(AsrDiscoveryParameter parameters) {
		this.parameters = parameters;
	}
	
	
	
	
}
