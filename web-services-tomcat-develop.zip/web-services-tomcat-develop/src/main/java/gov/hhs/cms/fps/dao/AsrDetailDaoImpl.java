package gov.hhs.cms.fps.dao;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.hibernate.type.DateType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.hibernate.type.Type;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

import gov.hhs.cms.fps.model.AsrDetailAlert;
import gov.hhs.cms.fps.model.AsrDetailProviderSummary;
import gov.hhs.cms.fps.model.AsrDetailTotalCostZone;
import gov.hhs.cms.fps.model.AsrDetailViewRequest;
import gov.hhs.cms.fps.model.AsrGenericCode;
import gov.hhs.cms.fps.model.AvailableClaims;
import gov.hhs.cms.fps.model.ClaimsSearchParameter;
import gov.hhs.cms.fps.model.ClaimsSolrStream;
import gov.hhs.cms.fps.model.ClaimsSolrStreamResult;
import gov.hhs.cms.fps.model.FpsCommonBeneficiary;
import gov.hhs.cms.fps.model.FpsVisualization;
import gov.hhs.cms.fps.model.FpsVisualizationEdge;
import gov.hhs.cms.fps.model.FpsVisualizationNode;
import gov.hhs.cms.fps.model.NvUcmSummary;
import gov.hhs.cms.fps.model.SolrStreamAsrDetailClaimLineItem;
import gov.hhs.cms.fps.model.generated.BaseClaim;
import gov.hhs.cms.fps.model.generated.FpsAlert;
import gov.hhs.cms.fps.model.generated.FpsAlertClmAsctn;
import gov.hhs.cms.fps.model.generated.FpsAsrDetailsPageCounts;
import gov.hhs.cms.fps.model.generated.FpsAsrpt;
import gov.hhs.cms.fps.model.generated.FpsAsrptPrrtyScreDtlVw;
import gov.hhs.cms.fps.model.generated.FpsAsrptRiskScreHstryVw;
import gov.hhs.cms.fps.model.generated.FpsClm;
import gov.hhs.cms.fps.model.generated.FpsClmP1;
import gov.hhs.cms.fps.model.generated.FpsCstmTbl;
import gov.hhs.cms.fps.model.generated.FpsCstmTblClmnName;
import gov.hhs.cms.fps.model.generated.FpsCstmTblData;
import gov.hhs.cms.fps.model.generated.FpsCstmTblLabelSnpsht;
import gov.hhs.cms.fps.model.generated.FpsEditNumRfrnc;
import gov.hhs.cms.fps.model.generated.FpsModel;
import gov.hhs.cms.fps.model.generated.FpsPrvdrPrflBlngPrvdr;
import gov.hhs.cms.fps.model.generated.FpsPtdAdhocData;
import gov.hhs.cms.fps.model.generated.FpsPtdClm;
import gov.hhs.cms.fps.model.generated.FpsPtdEclClm;
import gov.hhs.cms.fps.model.generated.FpsPtdOpAdvrsEfct;
import gov.hhs.cms.fps.model.generated.FpsPtdOpBzo;
import gov.hhs.cms.fps.model.generated.FpsPtdOpPrscrbr;
import gov.hhs.cms.fps.model.generated.FpsRcncltnClmline;
import gov.hhs.cms.fps.model.generated.FpsRiskScreRptCardDtl;
import gov.hhs.cms.fps.model.generated.FpsRptCardAttrLabel;
import gov.hhs.cms.fps.model.generated.FpsRptCardDtl;
import gov.hhs.cms.fps.model.generated.FpsRptCardLabelSnpSht;
import gov.hhs.cms.fps.model.generated.FpsRptCardRskSnaDtl;
import gov.hhs.cms.fps.model.generated.FpsSplmntlVizDtl;
import gov.hhs.cms.fps.model.generated.FpsSplmntlVizLabelSnpsht;
import gov.hhs.cms.fps.model.generated.FpsSsfEclClm;
import gov.hhs.cms.fps.model.generated.FpsUsrGuiPrfrnc;
import gov.hhs.cms.fps.model.generated.VizDmeEdge;
import gov.hhs.cms.fps.model.generated.VizDmeNode;
import gov.hhs.cms.fps.model.generated.VizHhaEdge;
import gov.hhs.cms.fps.model.generated.VizHhaNode;
import gov.hhs.cms.fps.model.generated.VizSnaEdge;
import gov.hhs.cms.fps.model.generated.VizSnaNode;
import gov.hhs.cms.fps.model.generated.VwFpsPtdAsrSummary;
import gov.hhs.cms.fps.util.ClaimToReviewOrder;
import gov.hhs.cms.fps.util.EnhancedRiskScoreContribOrder;
import gov.hhs.cms.fps.util.FpsDomainObjectConverter;
import gov.hhs.cms.fps.util.FpsEnums.SolrClaimType;
import gov.hhs.cms.fps.util.GenericOrderBy;

@Repository(value = "asrDetailDao")
public class AsrDetailDaoImpl extends BaseDao<Integer, FpsAsrpt> implements AsrDetailDao {
	private static final Logger logger = Logger.getLogger(AsrDetailDaoImpl.class.getName());
	@Value("${solr.collection.viz.edges}")
	private String collVizEdges;
	@Value("${solr.collection.viz.nodes}")
	private String collVizNodes;
	@Value("${solr.collection.viz.hha.edges}")
	private String collVizHhaEdges;
	@Value("${solr.collection.viz.hha.nodes}")
	private String collVizHhaNodes;
	@Value("${solr.collection.viz.dme.edges}")
	private String collVizDmeEdges;
	@Value("${solr.collection.viz.dme.nodes}")
	private String collVizDmeNodes;
	
	@Autowired
	private FpsHubDao fpsHubDao;
	@Autowired
	private FpsTrackingDao fpsTrackingDao;
	@Autowired
	private Environment env;
	@Value("${p1.enabled:false}")
	private String p1EnabledInd;


	@Override
	@Deprecated
	public List<FpsClm> loadClaimsForAsr2(Integer asrptId) {
		return loadClaimsForAsr2(asrptId, 1000, SolrClaimType.ALERTED);
	}

	@Override
	@Deprecated
	public List<FpsClm> loadClaimsForAsr2(Integer asrptId, int rows, List<String> claimTypes, Date fromDate,
			Date toDate, List<String> hicns, boolean isLatest, String subjId, SolrClaimType claimsCollection) {
		return null; // loadClaimsForAsr2(asrptId, rows, claimTypes, fromDate, toDate, hicns,
						// isLatest, subjId, -1, 1000, claimsCollection);
	}

	@Override
	public List<? extends BaseClaim> loadClaimsForAsr2(ClaimsSearchParameter search, int pageSize, int index) {
		List<? extends FpsClm> rows2 = new ArrayList<>();

		search.setPageSize(pageSize);
		search.setStartAt(index);
		Criteria query = buildSnowflakeClaimsQuery2(search, false);

		query.setMaxResults(pageSize);
		query.setFirstResult(index);

		logger.fine("start snowflake query");
		rows2 = query.list();
		logger.fine("end snowflake query with rows = " + rows2.size());

		return rows2;
	}

	@Override
	@Deprecated
	public List<FpsClm> loadClaimsForAsr2(Integer asrptId, int rows, SolrClaimType claimsCollection) {
		ClaimsSearchParameter p = new ClaimsSearchParameter();
		p.setAsrptId(asrptId);
		p.setSearchType(claimsCollection);

		return loadClaimsForAsr2(asrptId, rows, null, null, null, null, false, null, claimsCollection);

	}

	@Override
	public FpsPtdOpAdvrsEfct loadOAEPartDReport(FpsAsrpt asr, VwFpsPtdAsrSummary summ) {
		FpsPtdOpAdvrsEfct report = (FpsPtdOpAdvrsEfct) getCurrentSession()
				.createCriteria(FpsPtdOpAdvrsEfct.class, "partD").add(Restrictions.eq("id.prscrbrNpi", asr.getSubjId()))
				.add(Restrictions.eq("stdyPrdStrt", summ.getStdyPrdStrt())).uniqueResult();
		return report;
	}

	@Override
	public FpsPtdOpBzo loadOBPartDReport(FpsAsrpt asr, VwFpsPtdAsrSummary summ) {
		FpsPtdOpBzo report = (FpsPtdOpBzo) getCurrentSession().createCriteria(FpsPtdOpBzo.class, "partD")
				.add(Restrictions.eq("id.prscrbrNpi", asr.getSubjId()))
				.add(Restrictions.eq("stdyPrdStrt", summ.getStdyPrdStrt()))

				.uniqueResult();
		return report;
	}

	@Override
	public FpsPtdOpPrscrbr loadOPPartDReport(FpsAsrpt asr, VwFpsPtdAsrSummary summ) {
		FpsPtdOpPrscrbr report = (FpsPtdOpPrscrbr) getCurrentSession().createCriteria(FpsPtdOpPrscrbr.class, "partD")
				.add(Restrictions.eq("id.prscrbrNpi", asr.getSubjId()))
				.add(Restrictions.eq("stdyPrdStrt", summ.getStdyPrdStrt()))

				.uniqueResult();
		return report;
	}

	@Override
	public FpsPtdAdhocData loadAdHocPartDReport(FpsAsrpt asr, VwFpsPtdAsrSummary summ) {
		Criteria c = getCurrentSession().createCriteria(FpsPtdAdhocData.class, "partD")
				.add(Restrictions.eq("adhocRptNm", summ.getRptName()))
				.add(Restrictions.eq("stdyPrdStrt", summ.getStdyPrdStrt()));
		// if (summ.getRptName().toLowerCase().contains("hospice")){
		// c.add(Restrictions.or(Restrictions.eq("prscrbrNpi", asr.getSubjId()),
		// Restrictions.eq("var014", asr.getSubjId()),
		// Restrictions.eq("var015", asr.getSubjId()),
		// Restrictions.eq("var016", asr.getSubjId()),
		// Restrictions.eq("var017", asr.getSubjId()),
		// Restrictions.eq("var018", asr.getSubjId()),
		// Restrictions.eq("var019", asr.getSubjId()),
		// Restrictions.eq("var020", asr.getSubjId()),
		// Restrictions.eq("var021", asr.getSubjId()),
		// Restrictions.eq("var022", asr.getSubjId()),
		// Restrictions.eq("var023", asr.getSubjId()),
		// Restrictions.eq("var024", asr.getSubjId()),
		// Restrictions.eq("var025", asr.getSubjId())));
		// }else{
		c.add(Restrictions.eq("prscrbrNpi", asr.getSubjId()));

		// }
		FpsPtdAdhocData report = (FpsPtdAdhocData) c.uniqueResult();

		return report;
	}

	@Override
	@Deprecated
	public int getReportCardHasClaims(Short attrSqncNum, int alertId) {
		String sql2 = "select count(*) cnt " +
		//
				"from  fps2.FPS_ALERT_CLM_ASCTN this_ "
				+ "inner join fps2.fps_clm clm on this_.clm_id = clm.fps_clm_id "
				+ "where this_.attr_sqnc_num =  :attrSqncNum " + "and this_.alert_id =  :alertId ";
		SQLQuery query = (SQLQuery) getCurrentSession().createSQLQuery(sql2).setParameter("alertId", alertId)
				.setParameter("attrSqncNum", attrSqncNum);

		Integer count = (Integer) query.uniqueResult();

		return count;

	}

	@Override
	@Deprecated
	public List<FpsClm> loadClaimsForReportCard2(Short attrSqncNum, int alertId) {

		int rows = 500;
		String sql2 = "with claims as " + "( " + "select  distinct "
				+ "(case when this_.CLM_RVW_IND is null then '-1' else this_.CLM_RVW_IND end) as CLM_RVW_IND, "
				+ "(case when clm.CLM_THRU_DT is null then date('1900-01-01') else clm.CLM_THRU_DT end) as CLM_THRU_DT, "
				+ "clm.CLM_HIC_NUM, " + "this_.CLM_ID " +
				// "asr3_.asrpt_id, " +
				// "asr3_.subj_id " +
				"from  fps2.FPS_ALERT_CLM_ASCTN this_ " +
				// "inner join fps2.FPS_ASRPT_ALERT_ASCTN alertassoc2_ on
				// this_.ALERT_ID=alertassoc2_.ALERT_ID " +
				// "inner join fps2.FPS_ASRPT asr3_ on
				// alertassoc2_.ASRPT_ID=asr3_.ASRPT_ID " +
				"inner join fps2.fps_clm clm on this_.clm_id = clm.fps_clm_id " +
				// "inner join fps2.fps_alert alert on alertassoc2_.alert_id =
				// alert.alert_id " +
				"where this_.attr_sqnc_num =  :attrSqncNum " + "and this_.alert_id =  :alertId "
				+ "order by 1 desc, 2 desc, 3 " + "fetch first " + rows + " rows only " + ") "
				+ FpsDomainObjectConverter.CLAIMS_SELECT + "from " + FpsDomainObjectConverter.CLAIMS_JOINS;
		SQLQuery query = (SQLQuery) getCurrentSession().createSQLQuery(sql2).setParameter("alertId", alertId)
				.setParameter("attrSqncNum", attrSqncNum);

		List<FpsClm> rows2 = query.list();

		return rows2;

	}

	@Override
	public List<FpsCstmTbl> loadCustomTablesForModel(String modelBusnsId, String npi) {
		List<FpsCstmTbl> tables = getCurrentSession().createCriteria(FpsCstmTbl.class, "table")

				.add(Restrictions.eq("modelBusnsId", modelBusnsId))
				.addOrder(new GenericOrderBy("cast(trim(cstm_Tbl_id) as INTEGER)"))

				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return tables;
	}

	@Transactional
	@Override
	public List<AsrDetailAlert> loadAlertsForProvider(String npi) {
		List<AsrDetailAlert> alerts = new ArrayList<AsrDetailAlert>();
		Calendar cal180 = Calendar.getInstance();
		cal180.add(Calendar.DATE, -180);
		Calendar cal14 = Calendar.getInstance();
		cal14.add(Calendar.DATE, -14);


		List<Object[]> objs = getCurrentSession().createCriteria(FpsAlert.class, "fpsAlert")
				.add(Restrictions.eq("subjId", npi))
				.add(Restrictions.ge("alertCreatDt", cal180.getTime()))
				.add(Restrictions.not(Restrictions.ilike("model.clmTypeCd", "P1%")))
				.createAlias("fpsAlert.fpsModel", "model")
				.setProjection(Projections.projectionList().add(Projections.max("alertCreatDt"))
						.add(Projections.groupProperty("model.modelBusnsId"))
						.add(Projections.groupProperty("alertStusCd")))
				.addOrder(Order.asc("alertStusCd")).addOrder(Order.asc("model.modelBusnsId").ignoreCase()).list();
		if (objs != null) {
			for (Object[] obj : objs) {
				AsrDetailAlert alert = new AsrDetailAlert();
				alert.setModelBusnsId((String) obj[1]);
				if (obj[0] != null) {
					Date d = (Date) obj[0];
					alert.setCreateDt(FpsDomainObjectConverter.convertDateToShortString(d));
				}
				String status = (String) obj[2];
				alert.setStatus("12".equalsIgnoreCase(status) ? "New" : "Aged");
				alerts.add(alert);
			}
		}
		List<Object[]> objsP1 = getCurrentSession().createCriteria(FpsAlert.class, "fpsAlertP1")
				.add(Restrictions.eq("subjId", npi))
				.add(Restrictions.ge("alertCreatDt", cal14.getTime()))
				.add(Restrictions.ilike("modelP1.clmTypeCd", "P1%"))
				.createAlias("fpsAlertP1.fpsModel", "modelP1")
				.setProjection(Projections.projectionList().add(Projections.max("alertCreatDt"))
						.add(Projections.groupProperty("modelP1.modelBusnsId"))
						.add(Projections.groupProperty("alertStusCd")))
				.addOrder(Order.asc("alertStusCd")).addOrder(Order.asc("modelP1.modelBusnsId").ignoreCase()).list();
		if (objsP1 != null) {
			for (Object[] obj : objsP1) {
				AsrDetailAlert alert = new AsrDetailAlert();
				alert.setModelBusnsId((String) obj[1]);
				if (obj[0] != null) {
					Date d = (Date) obj[0];
					alert.setCreateDt(FpsDomainObjectConverter.convertDateToShortString(d));
				}
				String status = (String) obj[2];
				alert.setStatus("12".equalsIgnoreCase(status) ? "New" : "Aged");
				alerts.add(alert);
			}
		}
		Comparator<AsrDetailAlert> comp = Comparator.comparing(AsrDetailAlert::getStatus).reversed().thenComparing(AsrDetailAlert::getModelBusnsId, String.CASE_INSENSITIVE_ORDER);

		alerts.sort(comp);
		return alerts;
	}

	@Transactional
	@Override
	public List<FpsAlert> loadAlertsForByModelAndNpi(String model, String npi) {
		List<FpsAlert> alerts = getCurrentSession().createCriteria(FpsAlert.class, "alert")
				.createAlias("alert.fpsModel", "model", JoinType.INNER_JOIN)
				.add(Restrictions.eq("model.modelBusnsId", model)).add(Restrictions.eq("subjId", npi))
				.add(Restrictions.ne("alertStusCd", "14")).addOrder(Order.desc("alertCreatDt")).list();

		return alerts;
	}

	@Transactional
	@Override
	public FpsAlert loadAlertByAlertId(Integer alertId) {
		FpsAlert alerts = (FpsAlert) getCurrentSession().createCriteria(FpsAlert.class, "alert")
				.createAlias("alert.fpsModel", "model", JoinType.INNER_JOIN).add(Restrictions.eq("alertId", alertId))
				.uniqueResult();

		return alerts;
	}

	@Override
	public List<FpsCstmTblClmnName> loadCustomTablesForModelColumns(String modelBusnsId, String customTableId) {
		List<FpsCstmTblClmnName> tables = getCurrentSession().createCriteria(FpsCstmTblClmnName.class, "table")

				.add(Restrictions.eq("table.cstmTblId", customTableId))
				.add(Restrictions.eq("table.modelBusnsId", modelBusnsId))
				.addOrder(new GenericOrderBy("cast(trim(cstm_Tbl_Clmn_Num) as INTEGER)"))
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return tables;
	}

	@Override
	public List<FpsCstmTblData> loadCustomTablesForModelData(String modelBusnsId, String npi, Date modelRunDate,
			String cstmTblId) {
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

		String dStr = format.format(modelRunDate);
		List<FpsCstmTblData> tables = getCurrentSession().createCriteria(FpsCstmTblData.class, "table")

				.add(Restrictions.eq("table.npiNum", npi)).add(Restrictions.eq("table.modelBusnsId", modelBusnsId))
				.add(Restrictions.or(Restrictions.eq("table.modelRunDtStr", dStr),
						Restrictions.isNull("table.modelRunDtStr")))
				.add(Restrictions.or(Restrictions.eq("table.modelRunDt", modelRunDate),
						Restrictions.isNull("table.modelRunDt")))
				.add(Restrictions.eq("table.cstmTblId", cstmTblId))
				.addOrder(new GenericOrderBy("cast(trim(cstm_Tbl_row_Num) as INTEGER)"))
				.addOrder(new GenericOrderBy("cast(trim(cstm_Tbl_Clmn_Num) as INTEGER)"))
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return tables;
	}

	@Transactional(readOnly = true)
	@Override
	public FpsAsrpt getAsrDetail(AsrDetailViewRequest request) {
		return getAsrDetail(request.getParameters().getAsr(), null);
	}

	@Transactional(readOnly = true)
	@Override
	public FpsAsrpt getAsrDetail(List<Integer> ids, String xtab) {
		Criteria c = getCurrentSession().createCriteria(FpsAsrpt.class, "fpsAsrpt");
		if ((ids != null) && (ids.size() > 0)) {
			if (ids.size() > 1) {
				c.add(Restrictions.in("asrptId", ids));
			} else {
				c.add(Restrictions.eq("asrptId", ids.get(0)));
			}
			FpsAsrpt retval = new FpsAsrpt();
			c.setMaxResults(100);
			List<FpsAsrpt> l = c.list();
			if ((l != null) && (l.size() > 0)) {
				retval = (FpsAsrpt) l.get(0);
			}
			return retval;
		}
		return null;
	}

	@Transactional
	@Override
	public List<AsrDetailTotalCostZone> loadTotalCostByZone(int asrptId) {
		List<AsrDetailTotalCostZone> items = new ArrayList<AsrDetailTotalCostZone>();

		// get the distinct list of claims, then map the state to the zone.
		// DME = clm_bene_state_cd
		// A = CLM_BLG_PRVDR_USPS_STATE_CD. State code in CCN format. Join on
		// the State/CCN table to get the alpha coe
		// B = CLM_BLG_PRVDR_USPS_STATE_CD
		SQLQuery query = getCurrentSession().createSQLQuery(

				"select " + " CNTRCTR_DESC  , sum(CLM_CNT) CLM_CNT_SUM,sum(CLM_COST  ) CLM_COST_SUM " + "from fps2.FPS_ASRPT_ZONE_COST_CNT_VW "
						+ " where asrpt_id = :asrptId " + " group by CNTRCTR_DESC "
						+ "order by case when CNTRCTR_DESC = 'Unknown' then 'ZZ' else CNTRCTR_DESC end");
		try {
			List<Object[]> rows = query.setInteger("asrptId", asrptId).list();

			for (Object[] row : rows) {
				AsrDetailTotalCostZone item = new AsrDetailTotalCostZone();
				if (row[0] != null) {
					item.setZone(row[0].toString());
					item.setTotalClaimLines(Integer.parseInt(row[1].toString()));

					item.setTotalCost(
							FpsDomainObjectConverter.convertDecimalToDollar(new BigDecimal(row[2].toString())));
//				item.setTotalClaimLinesAll(Integer.parseInt(row[2].toString()));
//
//				item.setTotalCostAll(FpsDomainObjectConverter.convertDecimalToDollar(new BigDecimal(row[3].toString())));
					items.add(item);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return items;
	}
	@Transactional
	@Override
	public List<AsrDetailTotalCostZone> loadP1TotalCostByZone(int asrptId) {
		List<AsrDetailTotalCostZone> items = new ArrayList<AsrDetailTotalCostZone>();

		// get the distinct list of claims, then map the state to the zone.
		// DME = clm_bene_state_cd
		// A = CLM_BLG_PRVDR_USPS_STATE_CD. State code in CCN format. Join on
		// the State/CCN table to get the alpha coe
		// B = CLM_BLG_PRVDR_USPS_STATE_CD
		SQLQuery query = getCurrentSession().createSQLQuery(

				"select " + " CNTRCTR_DESC  , sum(CLM_CNT) CLM_CNT_SUM,sum(CLM_COST  ) CLM_COST_SUM " + "from fps2.fps_asrpt_p1_zone_cost_cnt_vw "
						+ " where asrpt_id = :asrptId " + " group by CNTRCTR_DESC "
						+ "order by case when CNTRCTR_DESC = 'Unknown' then 'ZZ' else CNTRCTR_DESC end");
		try {
			List<Object[]> rows = query.setInteger("asrptId", asrptId).list();

			for (Object[] row : rows) {
				AsrDetailTotalCostZone item = new AsrDetailTotalCostZone();
				if (row[0] != null) {
					item.setZone(row[0].toString());
					item.setTotalClaimLines(Integer.parseInt(row[1].toString()));

					item.setTotalCost(
							FpsDomainObjectConverter.convertDecimalToDollar(new BigDecimal(row[2].toString())));
//				item.setTotalClaimLinesAll(Integer.parseInt(row[2].toString()));
//
//				item.setTotalCostAll(FpsDomainObjectConverter.convertDecimalToDollar(new BigDecimal(row[3].toString())));
					items.add(item);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return items;
	}

	@Transactional
	@Override
	public List<AsrDetailTotalCostZone> loadTotalPaymentByZone(int asrptId) {
		List<AsrDetailTotalCostZone> items = new ArrayList<AsrDetailTotalCostZone>();

		SQLQuery query = getCurrentSession().createSQLQuery(

				" select " + "  CNTRCTR_CD, CLM_CNT, CLM_PMT_AMT "
						+ "from fps2.FPS_PRIORITIZATION_WKLY_DATASET_CLM_AMT_BY_JURISDICTION "
						+ "where asrpt_id = :asrptId "
						+ "order by case when lower(CNTRCTR_CD) = 'unknown' then 'ZZ' else CNTRCTR_CD end ");
		List<Object[]> rows = query.setInteger("asrptId", asrptId).list();
		for (Object[] row : rows) {
			AsrDetailTotalCostZone item = new AsrDetailTotalCostZone();
			if (row[0] != null) {
				item.setZone(row[0].toString());
				item.setTotalClaimLines(Integer.parseInt(row[1].toString()));

				item.setTotalCost(FpsDomainObjectConverter.convertDecimalToDollar(new BigDecimal(row[2].toString())));
//				
				items.add(item);
			}
		}
		return items;
	}

	@Override
	@Deprecated
	public List<AsrDetailProviderSummary> getAsrProviderSummary(int asrptId) {
		List<AsrDetailProviderSummary> benes = new ArrayList<AsrDetailProviderSummary>();
		String sql = "select distinct clm_Atndg_Prvdr_Npi_Num, PRVDR_DRVD_NPI_NAME, 'Attending' as role from fps_asrpt a inner join fps_asrpt_alert_asctn b on a.asrpt_id = b.asrpt_id inner join fps_alert_clm_asctn c on b.alert_id = c.alert_id inner join fps_clm d on c.CLM_ID = d.FPS_CLM_ID inner join fps_prvdr on clm_Atndg_Prvdr_Npi_Num = prvdr_npi_num and length(clm_Atndg_Prvdr_Npi_Num) > 0 where a.asrpt_id = :asrptId union select distinct clm_Blg_Prvdr_Npi_Num, PRVDR_DRVD_NPI_NAME, 'Billing' as role from fps_asrpt a inner join fps_asrpt_alert_asctn b on a.asrpt_id = b.asrpt_id inner join fps_alert_clm_asctn c on b.alert_id = c.alert_id inner join fps_clm d on c.CLM_ID = d.FPS_CLM_ID inner join fps_prvdr on clm_Blg_Prvdr_Npi_Num = prvdr_npi_num and length(clm_Blg_Prvdr_Npi_Num) > 0 where a.asrpt_id = :asrptId union select distinct clm_rfrg_Prvdr_Npi_Num, PRVDR_DRVD_NPI_NAME, 'Referring' as role from fps_asrpt a inner join fps_asrpt_alert_asctn b on a.asrpt_id = b.asrpt_id inner join fps_alert_clm_asctn c on b.alert_id = c.alert_id inner join fps_clm d on c.CLM_ID = d.FPS_CLM_ID inner join fps_prvdr on clm_rfrg_Prvdr_Npi_Num = prvdr_npi_num and length(clm_rfrg_Prvdr_Npi_Num) > 0 where a.asrpt_id = :asrptId union select distinct clm_rndrg_Prvdr_Npi_Num, PRVDR_DRVD_NPI_NAME, 'Rendering' as role from fps_asrpt a inner join fps_asrpt_alert_asctn b on a.asrpt_id = b.asrpt_id inner join fps_alert_clm_asctn c on b.alert_id = c.alert_id inner join fps_clm d on c.CLM_ID = d.FPS_CLM_ID inner join fps_prvdr on clm_rndrg_Prvdr_Npi_Num = prvdr_npi_num and length(clm_rndrg_Prvdr_Npi_Num) > 0 where a.asrpt_id = :asrptId union select distinct clm_oprtg_Prvdr_Npi_Num, PRVDR_DRVD_NPI_NAME, 'Operating' as role from fps_asrpt a inner join fps_asrpt_alert_asctn b on a.asrpt_id = b.asrpt_id inner join fps_alert_clm_asctn c on b.alert_id = c.alert_id inner join fps_clm d on c.CLM_ID = d.FPS_CLM_ID inner join fps_prvdr on clm_oprtg_Prvdr_Npi_Num = prvdr_npi_num and length(clm_oprtg_Prvdr_Npi_Num) > 0 where a.asrpt_id = :asrptId";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("asrptId", Integer.valueOf(asrptId));
		List<Object[]> rows = query.list();
		for (Object[] row : rows) {
			AsrDetailProviderSummary item = new AsrDetailProviderSummary();
			item.setNpi(row[0].toString());
			if (row[1] != null) {
				item.setProviderName(row[1].toString());
			} else {
				item.setProviderName("");
			}
			item.setRole(row[2].toString());
			benes.add(item);
		}
		return benes;
	}

	@Override
	public Date getLastAlertDateForAsr(int asrptId) {
		String sql = "select max(case when c.audt_updt_ts is not null then c.audt_updt_ts else c.alert_creat_dt end) as updtdt from fps2.fps_asrpt a inner join fps2.fps_asrpt_alert_asctn b on a.asrpt_id = b.asrpt_id inner join fps2.fps_alert c on b.alert_id = c.alert_id where a.asrpt_id = :asrptId";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("asrptId", Integer.valueOf(asrptId));
		List<Date> rows = query.list();
		if (rows != null) {
			return (Date) rows.get(0);
		}
		return null;
	}

	@Override
	public Date getLastAlertDateForModelAndNpi(String modelId, String npi) {
		String sql = "select max(alert_creat_dt) as updtdt from fps2.fps_alert a inner join fps2.fps_model b on a.model_id = b.model_id where b.model_busns_id = :modelId and a.subj_id = :npi";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("modelId", modelId);
		query.setParameter("npi", npi);
		List<Date> rows = query.list();
		if (rows != null) {
			return (Date) rows.get(0);
		}
		return null;
	}

	@Override
	public Date getLastAlertDateForReportCard(int modelId, String npi) {
		String sql = "select max(model_run_dt) as updtdt from fps2.fps_rpt_card_dtl a inner join fps2.fps_model b on a.model_busns_id = b.model_busns_id where a.subj_id = :npi and  b.model_id = :modelId";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("modelId", Integer.valueOf(modelId));
		query.setParameter("npi", npi);
		List<Date> rows = query.list();
		if (rows != null) {
			return (Date) rows.get(0);
		}
		return null;
	}

	@Override
	public Date getLastAlertDateForSnaReportCard(int modelId, String npi) {
		String sql = "select max(model_run_dt) as updtdt from fps2.FPS_RPT_CARD_RSK_SNA_DTL a inner join fps2. fps_model b on a.model_busns_id = b.model_busns_id where a.SUBJ_PRVDR_NPI = :npi and  b.model_id = :modelId";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("modelId", Integer.valueOf(modelId));
		query.setParameter("npi", npi);
		List<Date> rows = query.list();
		if (rows != null) {
			return (Date) rows.get(0);
		}
		return null;
	}

	@Override
	public Date getLastAlertDateForCustomTable(String modelBusnsId, String npi) {
		String sql = "select max(case when model_run_dt is not null then model_run_dt else date(to_date(model_run_dt_str, 'MM/DD/YYYY')) end) as updtdt from fps2.FPS_CSTM_TBL_DTL a where a.npi_num = :npi and  a.model_busns_id = :modelBusnsId";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("modelBusnsId", modelBusnsId);
		query.setParameter("npi", npi);
		List<Date> rows = query.list();
		if (rows != null) {
			return (Date) rows.get(0);
		}
		return null;
	}

	@Override
	public Date getLastAlertDateForCustomTableViz(String modelBusnsId, String npi, Integer vizId) {
		String sql = "select max(model_run_dt) as updtdt from fps2.FPS_SUPPLEMENTALVIZ_DTL a where a.npi_num = :npi and  a.model_busns_id = :modelBusnsId ";
		if (vizId != null) {
			sql += "and a.SPLMTL_VIZ_ID = :vizId";
		}

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("modelBusnsId", modelBusnsId);
		query.setParameter("npi", npi);
		if (vizId != null) {
			query.setParameter("vizId", vizId);
		}
		List<Date> rows = query.list();
		if (rows != null) {
			return (Date) rows.get(0);
		}
		return null;
	}

	@Transactional(readOnly = true)
	@Override
	public List<FpsRptCardDtl> loadReportCardForModelAndNpi(int modelId, String npi) {
		return loadReportCardForModelAndNpi(modelId, npi, null);
	}

	@Transactional(readOnly = true)
	@Override
	public List<FpsRptCardDtl> loadReportCardForModelAndNpi(int modelId, String npi, Date runDate) {
		Date d = null;
		boolean useDateRange = false;
		if (runDate != null) {
			d = runDate;
			useDateRange = true;
		} else {
			d = getLastAlertDateForReportCard(modelId, npi);
		}

		Criteria c = getCurrentSession().createCriteria(FpsRptCardDtl.class, "card")
				.createAlias("card.fpsModel", "model", JoinType.INNER_JOIN)

				.add(Restrictions.eq("model.modelId", Integer.valueOf(modelId)))
				.add(Restrictions.eq("card.subjId", npi));
		// if (useDateRange) {
		// Calendar calMinus = Calendar.getInstance();
		// calMinus.setTime(runDate);
		// calMinus.add(Calendar.DATE, -2);
		// calMinus.set(Calendar.HOUR, 0);
		// calMinus.set(Calendar.MINUTE, 0);
		// calMinus.set(Calendar.SECOND, 0);
		//
		// Calendar calPlus = Calendar.getInstance();
		// calPlus.setTime(runDate);
		// calPlus.add(Calendar.DATE, 1);
		// calPlus.set(Calendar.HOUR, 23);
		// calPlus.set(Calendar.MINUTE, 59);
		// calPlus.set(Calendar.SECOND, 59);
		// c.add(Restrictions.between("card.audtInsrtTs", calMinus.getTime(),
		// calPlus.getTime()));
		// } else {
		c.add(Restrictions.eq("card.modelRunDt", d));
		// }

		c.addOrder(Order.asc("attrSqncNum"));
		List<FpsRptCardDtl> rcs = c.list();
		return rcs;
	}

	@Transactional(readOnly = true)
	@Override
	public List<FpsRptCardRskSnaDtl> loadSnaReportCardForModelAndNpi(int modelId, String npi) {
		return loadSnaReportCardForModelAndNpi(modelId, npi, null);
	}

	@Transactional(readOnly = true)
	@Override
	public List<FpsRptCardRskSnaDtl> loadSnaReportCardForModelAndNpi(int modelId, String npi, Date runDate) {
		Date d = null;
		if (runDate != null) {
			d = runDate;
		} else {
			d = getLastAlertDateForSnaReportCard(modelId, npi);
		}
		List<FpsRptCardRskSnaDtl> rcs = getCurrentSession().createCriteria(FpsRptCardRskSnaDtl.class, "card")

				.createAlias("card.fpsModel", "model", JoinType.INNER_JOIN)

				.add(Restrictions.eq("model.modelId", Integer.valueOf(modelId)))
				.add(Restrictions.eq("card.subjPrvdrNpi", npi)).add(Restrictions.eq("card.modelRunDt", d))
				.addOrder(Order.asc("attrSqncNum")).list();

		return rcs;
	}

	@Transactional(readOnly = true)
	@Override
	public List<FpsRptCardAttrLabel> loadReportCardLabels(FpsRptCardDtl rptCardDtl) {
		Criteria criteria = getCurrentSession().createCriteria(FpsRptCardAttrLabel.class);
		criteria.setFirstResult(0);
		criteria.setMaxResults(1);
		if ("1".equals(rptCardDtl.getFpsVrsnInd())) {
			if (rptCardDtl.getRptCardAttrLabelId() == null) {
				return new ArrayList<FpsRptCardAttrLabel>();
			}
			criteria.add(Restrictions.eq("rptCardAttrLabelId", rptCardDtl.getRptCardAttrLabelId()));
		} else {
			criteria.add(Restrictions.eq("modelBusnsId", rptCardDtl.getModelBusnsId()))
					.add(Restrictions.eq("attrSqncNum", rptCardDtl.getAttrSqncNum()));
		}
		List<FpsRptCardAttrLabel> labels = criteria.add(Restrictions.eq("fpsVrsnInd", rptCardDtl.getFpsVrsnInd()))
				.addOrder(Order.desc("audtInsrtTs")).list();

		return labels;
	}

	@Transactional(readOnly = true)
	@Override
	public FpsAlert loadReportCardMostRecentAlert(String npi, Integer modelId, Date runDate) {
		Criteria criteria = getCurrentSession().createCriteria(FpsAlert.class, "alert").createAlias("alert.fpsModel",
				"model", JoinType.INNER_JOIN);
		criteria.setFirstResult(0);
		criteria.setMaxResults(1);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		criteria.add(Restrictions.eq("model.modelId", modelId)).add(Restrictions.eq("subjId", npi));
		if (runDate != null) {
			criteria.add(Restrictions.eq("alertCreatDt", runDate));
		}
		criteria.addOrder(Order.desc("alertCreatDt"));
		List<FpsAlert> alerts = criteria.list();
		FpsAlert alert = new FpsAlert();
		if (alerts != null && alerts.size() > 0) {
			alert = (FpsAlert) alerts.get(0);
		}
		return alert;
	}

	@Transactional(readOnly = true)
	@Override
	public FpsAlert loadReportCardMostRecentAlert(FpsRptCardDtl rptCardDtl) {
		Criteria criteria = getCurrentSession().createCriteria(FpsAlert.class, "alert").createAlias("alert.fpsModel",
				"model", JoinType.INNER_JOIN);
		criteria.setFirstResult(0);
		criteria.setMaxResults(1);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<FpsAlert> alerts = criteria.add(Restrictions.eq("model.modelBusnsId", rptCardDtl.getModelBusnsId()))
				.add(Restrictions.eq("subjId", rptCardDtl.getSubjId())).addOrder(Order.desc("alertCreatDt")).list();

		FpsAlert alert = new FpsAlert();
		if (alerts != null && alerts.size() > 0) {
			alert = (FpsAlert) alerts.get(0);
		}
		return alert;
	}

	@Transactional(readOnly = true)
	@Override
	public FpsAlert loadReportCardMostRecentAlert(String subjId, String modelBusnsId) {
		Criteria criteria = getCurrentSession().createCriteria(FpsAlert.class, "alert").createAlias("alert.fpsModel",
				"model", JoinType.INNER_JOIN);
		criteria.setFirstResult(0);
		criteria.setMaxResults(1);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<FpsAlert> alerts = criteria.add(Restrictions.eq("model.modelBusnsId", modelBusnsId))
				.add(Restrictions.eq("subjId", subjId)).addOrder(Order.desc("alertCreatDt")).list();

		FpsAlert alert = new FpsAlert();
		if (alerts != null && alerts.size() > 0) {
			alert = (FpsAlert) alerts.get(0);
		}
		return alert;
	}

	@Transactional(readOnly = true)
	@Override
	public FpsAlert loadReportCardMostRecentAlert(FpsRptCardRskSnaDtl rptCardDtl) {
		Criteria criteria = getCurrentSession().createCriteria(FpsAlert.class, "alert").createAlias("alert.fpsModel",
				"model", JoinType.INNER_JOIN);
		criteria.setFirstResult(0);
		criteria.setMaxResults(1);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<FpsAlert> alerts = criteria.add(Restrictions.eq("model.modelBusnsId", rptCardDtl.getModelBusnsId()))
				.add(Restrictions.eq("subjId", rptCardDtl.getSubjPrvdrNpi())).addOrder(Order.desc("alertCreatDt"))
				.list();

		FpsAlert alert = new FpsAlert();
		if (alerts != null && alerts.size() > 0) {
			alert = (FpsAlert) alerts.get(0);
		}
		return alert;
	}

	@Deprecated
	@Override
	public List<FpsRptCardDtl> loadReportCardClaims(int modelId, String npi) {
		List<FpsRptCardDtl> rcs = getCurrentSession().createCriteria(FpsRptCardDtl.class, "card")
				.createAlias("card.fpsModel", "model", JoinType.INNER_JOIN)
				.createAlias("fpsAlert", "alert", JoinType.LEFT_OUTER_JOIN)

				.add(Restrictions.eq("clmAssoc.attrSqncNum", "card.attrSqncNum"))
				.add(Restrictions.eq("model.modelId", Integer.valueOf(modelId))).add(Restrictions.eq("subjId", npi))
				.list();

		return rcs;
	}

	@Override
	public HashMap<String, String> loadReportCardClaimExistInd(int modelId, String npi) {
		HashMap<String, String> seqCount = new HashMap<String, String>();
		String sql = "select a.ATTR_SQNC_NUM,count(*) from fps2.FPS_ALERT b ,fps2.FPS_ALERT_CLM_ASCTN c,fps2.FPS_RPT_CARD_DTL a  where b.SUBJ_ID= :subjId and b.MODEL_ID= :modelId and b.ALERT_ID=c.ALERT_ID and a.SUBJ_ID=b.SUBJ_ID  and a.MODEL_BUSNS_ID=(select m.MODEL_BUSNS_ID from fps_model m where m.model_id=b.MODEL_ID)  and a.ATTR_SQNC_NUM=c.ATTR_SQNC_NUM group by a.ATTR_SQNC_NUM ";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("subjId", npi);
		query.setParameter("modelId", Integer.valueOf(modelId));
		List<Object[]> rows = query.list();
		for (Object[] row : rows) {
			if (rows != null) {
				String seq = row[0].toString();
				int count = Integer.parseInt(row[1].toString());
				seqCount.put(seq, count > 0 ? "Y" : "N");
			}
		}
		return seqCount;
	}

	@Override
	@Deprecated
	public List<FpsClm> loadClaimsForModel2(int modelId, String npi, boolean isPartD, Integer asrptId,
			Integer alertId) {
		String table = "FpsClm";
		if (isPartD) {
			table = "FpsPtdClm";
		}
		if (alertId == -1) {
			alertId = getLastAlertForAsrAndModel(asrptId, modelId);
		}
//		RequestContextHolder.getRequestAttributes().setAttribute("table", table, RequestAttributes.SCOPE_REQUEST);

		String attrKey = "%," + asrptId + "^" + alertId + "%";
		String alertKey = "%," + asrptId + "^" + modelId + "^" + npi + "%";
		String sql = " from " + table + " where attributeKey like :attrKey and alertKey like :alertKey ";
		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setString("attrKey", attrKey)
				.setString("alertKey", alertKey);

		logger.fine("start snowflake query");
		List<FpsClm> rows2 = query.list();

		return rows2;
	}

	@Override
	@Deprecated
	public List<FpsAlertClmAsctn> loadClaimsForAsr(int asrptId) {
		return loadClaimsForAsr(asrptId, 1000);
	}

	@Override
	@Deprecated
	public List<FpsAlertClmAsctn> loadClaimsForAsr(int asrptId, int maxRows) {
		List<Object[]> alerts = getCurrentSession().createCriteria(FpsAlertClmAsctn.class, "clmAssoc")
				.createAlias("clmAssoc.fpsAlert", "alert", JoinType.INNER_JOIN)
				.createAlias("alert.fpsAsrptAlertAsctns", "alertAssoc", JoinType.INNER_JOIN)
				.createAlias("alertAssoc.fpsAsrpt", "asr", JoinType.INNER_JOIN)
				.createAlias("clmAssoc.fpsClm", "clm", JoinType.INNER_JOIN)

				.add(Restrictions.eq("asr.asrptId", asrptId)).addOrder(new ClaimToReviewOrder())

				.setProjection(Projections.projectionList()
						// .add(Projections.distinct(Projections.property("clmAssoc.fpsClmId")))
						.add(Projections.sqlGroupProjection(
								"CLM_ID, (case when CLM_RVW_IND is null then '-1' else CLM_RVW_IND  end) as CLM_RVW_IND,(case when CLM_THRU_DT is null then date('1900-01-01') else CLM_THRU_DT end) as CLM_THRU_DT , CLM_HIC_NUM  ",
								"CLM_ID,(case when CLM_RVW_IND is null then '-1' else CLM_RVW_IND  end) ,(case when CLM_THRU_DT is null then date('1900-01-01') else CLM_THRU_DT end) , CLM_HIC_NUM  ",
								new String[] { "CLM_ID", "CLM_RVW_IND", "CLM_THRU_DT", "CLM_HIC_NUM" },
								new Type[] { new IntegerType(), new StringType(), new DateType(), new StringType() }))
				// .add(Projections.sqlProjection(
				// "(case when CLM_RVW_IND is null then '-1' else CLM_RVW_IND
				// end) as CLM_RVW_IND,(ca se when CLM_THRU_DT is null then
				// date('1900-01-01') else CLM_THRU_DT end) as CLM_THRU_DT ,
				// CLM_HIC_NUM asc ",
				// new String[] { "CLM_RVW_IND" , "CLM_THRU_DT", "CLM_HIC_NUM"},
				// new Type[] { new StringType(), new DateType(), new
				// StringType() }))
				).setMaxResults(maxRows).list();
		List<Integer> claimIds = new ArrayList<Integer>();
		for (Object[] row : alerts) {
			claimIds.add(Integer.valueOf(Integer.parseInt(row[0].toString())));
		}
		if (claimIds.size() == 0) {
			return new ArrayList<FpsAlertClmAsctn>();
		}
		List<FpsAlertClmAsctn> claims = getCurrentSession().createCriteria(FpsAlertClmAsctn.class, "clmAssoc")

				.add(Restrictions.in("clmAssoc.clmId", claimIds)).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
				.addOrder(new ClaimToReviewOrder())

				.list();
		return claims;
	}

	@Deprecated
	@Override
	public List<FpsAlertClmAsctn> loadClaimsForReportCard(Short attrSqncNum, int alertId) {
		// List<FpsAlertClmAsctn> alerts =
		// getCurrentSession().createCriteria(FpsAlertClmAsctn.class,
		// "alertAsctn")
		// .createAlias("alertAsctn.fpsAlert", "alert",
		// JoinType.INNER_JOIN).setMaxResults(500)
		// .add(Restrictions.eq("alert.alertId", Integer.valueOf(alertId)))
		// .add(Restrictions.eq("attrSqncNum", attrSqncNum)).list();
		//

		List<Object[]> alerts = getCurrentSession().createCriteria(FpsAlertClmAsctn.class, "alertAsctn")
				.createAlias("alertAsctn.fpsAlert", "alert", JoinType.INNER_JOIN)
				.createAlias("alertAsctn.fpsClm", "clm", JoinType.INNER_JOIN).setMaxResults(500)
				.createAlias("clm.fpsBene", "bene", JoinType.LEFT_OUTER_JOIN)
				.add(Restrictions.eq("alert.alertId", Integer.valueOf(alertId)))
				.add(Restrictions.eq("attrSqncNum", attrSqncNum))

				.addOrder(new ClaimToReviewOrder())

				.setProjection(Projections.projectionList()
						// .add(Projections.distinct(Projections.property("clmAssoc.clmId")))
						.add(Projections.sqlGroupProjection(
								"CLM_ID, (case when CLM_RVW_IND is null then '-1' else CLM_RVW_IND  end) as CLM_RVW_IND,(case when CLM_THRU_DT is null then date('1900-01-01') else CLM_THRU_DT end) as CLM_THRU_DT , CLM_HIC_NUM  ",
								"CLM_ID,(case when CLM_RVW_IND is null then '-1' else CLM_RVW_IND  end) ,(case when CLM_THRU_DT is null then date('1900-01-01') else CLM_THRU_DT end) , CLM_HIC_NUM  ",
								new String[] { "CLM_ID", "CLM_RVW_IND", "CLM_THRU_DT", "CLM_HIC_NUM" },
								new Type[] { new StringType(), new StringType(), new DateType(), new StringType() }))
				// .add(Projections.sqlProjection(
				// "(case when CLM_RVW_IND is null then '-1' else CLM_RVW_IND
				// end) as CLM_RVW_IND,(case when CLM_THRU_DT is null then
				// date('1900-01-01') else CLM_THRU_DT end) as CLM_THRU_DT ,
				// CLM_HIC_NUM asc ",
				// new String[] { "CLM_RVW_IND" , "CLM_THRU_DT", "CLM_HIC_NUM"},
				// new Type[] { new StringType(), new DateType(), new
				// StringType() }))
				).setMaxResults(500).list();
		List<Integer> claimIds = new ArrayList<Integer>();
		for (Object[] row : alerts) {
			claimIds.add(Integer.valueOf(Integer.parseInt(row[0].toString())));
		}
		if (claimIds.size() == 0) {
			return new ArrayList<FpsAlertClmAsctn>();
		}
		List<FpsAlertClmAsctn> claims = getCurrentSession().createCriteria(FpsAlertClmAsctn.class, "clmAssoc")

				.add(Restrictions.in("clmAssoc.clmId", claimIds)).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
				.addOrder(new ClaimToReviewOrder())

				.list();
		return claims;

	}

	@Deprecated
	public List<FpsAlertClmAsctn> loadClaimsForModel(int modelId, String npi) {
		List<Object[]> alerts = getCurrentSession().createCriteria(FpsAlertClmAsctn.class, "clmAssoc")
				.createAlias("clmAssoc.fpsAlert", "alert", JoinType.INNER_JOIN)
				.createAlias("clmAssoc.fpsClm", "clm", JoinType.INNER_JOIN)
				.createAlias("alert.fpsModel", "model", JoinType.INNER_JOIN)
				.createAlias("clm.fpsBene", "bene", JoinType.LEFT_OUTER_JOIN)

				.add(Restrictions.eq("model.modelId", Integer.valueOf(modelId)))
				.add(Restrictions.eq("alert.subjId", npi))

				.addOrder(new ClaimToReviewOrder())

				.setProjection(Projections.projectionList()
						// .add(Projections.distinct(Projections.property("clmAssoc.clmId")))
						.add(Projections.sqlGroupProjection(
								"CLM_ID, (case when CLM_RVW_IND is null then '-1' else CLM_RVW_IND  end) as CLM_RVW_IND,(case when CLM_THRU_DT is null then date('1900-01-01') else CLM_THRU_DT end) as CLM_THRU_DT , CLM_HIC_NUM  ",
								"CLM_ID,(case when CLM_RVW_IND is null then '-1' else CLM_RVW_IND  end) ,(case when CLM_THRU_DT is null then date('1900-01-01') else CLM_THRU_DT end) , CLM_HIC_NUM  ",
								new String[] { "CLM_ID", "CLM_RVW_IND", "CLM_THRU_DT", "CLM_HIC_NUM" },
								new Type[] { new StringType(), new StringType(), new DateType(), new StringType() }))
				// .add(Projections.sqlProjection(
				// "(case when CLM_RVW_IND is null then '-1' else CLM_RVW_IND
				// end) as CLM_RVW_IND,(case when CLM_THRU_DT is null then
				// date('1900-01-01') else CLM_THRU_DT end) as CLM_THRU_DT ,
				// CLM_HIC_NUM asc ",
				// new String[] { "CLM_RVW_IND" , "CLM_THRU_DT", "CLM_HIC_NUM"},
				// new Type[] { new StringType(), new DateType(), new
				// StringType() }))
				).setMaxResults(500).list();
		List<Integer> claimIds = new ArrayList<Integer>();
		for (Object[] row : alerts) {
			claimIds.add(Integer.valueOf(Integer.parseInt(row[0].toString())));
		}
		if (claimIds.size() == 0) {
			return new ArrayList<FpsAlertClmAsctn>();
		}
		List<FpsAlertClmAsctn> claims = getCurrentSession().createCriteria(FpsAlertClmAsctn.class, "clmAssoc")

				.add(Restrictions.in("clmAssoc.clmId", claimIds)).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
				.addOrder(new ClaimToReviewOrder())

				.list();
		return claims;
	}

	@Override
	public List<Date> getReportCardDatesForModel(String model, String npi) {
		Criteria c = getCurrentSession().createCriteria(FpsRptCardDtl.class, "card")
				.setProjection(Projections.distinct(Projections.property("modelRunDt")));
		if (model != null) {
			c.add(Restrictions.eq("modelBusnsId", model));
		}
		c.add(Restrictions.eq("subjId", npi)).addOrder(Order.desc("modelRunDt"));
		List<Date> rcs = c.list();

		return rcs;
	}

	@Override
	public List<Date> getSnaReportCardDatesForModel(String model, String npi) {
		Criteria c = getCurrentSession().createCriteria(FpsRptCardRskSnaDtl.class, "card")
				.setProjection(Projections.distinct(Projections.property("modelRunDt")))
				.add(Restrictions.eq("subjNpiName", npi));
		if (model != null) {
			c.add(Restrictions.eq("modelBusnsId", model));
		}
		c.addOrder(Order.desc("modelRunDt"));
		List<Date> rcs = c.list();

		return rcs;
	}

	@Override
	public long getClaimCount(ClaimsSearchParameter search) {
		if (SolrClaimType.ASRCOST.equals(search.getSearchType())
				|| SolrClaimType.PARTDASRCOST.equals(search.getSearchType())) {
			Criteria query = buildSnowflakeClaimsQuery2(search, true);
			query.setProjection(Projections.countDistinct("fpsclm.id"));
			Number totalRows = (Number) query.uniqueResult();
			return totalRows == null ? 0 : totalRows.longValue();
		}

		Query query = buildSnowflakeClaimsQuery(search, true);

		Long totalRows = (Long) query.uniqueResult();

		return totalRows.intValue();
	}

	@Override
	public FpsAsrDetailsPageCounts getAllClaimCount(String npi) {

		FpsAsrDetailsPageCounts summ = new FpsAsrDetailsPageCounts();
		String sql = " from FpsAsrDetailsPageCounts where npi = :npi ";
		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setParameter("npi", npi);

		List<FpsAsrDetailsPageCounts> summs = query.list();
		if (summs != null && summs.size() > 0) {
			summ = summs.get(0);
		}
		return summ;
	}

	private Class getClaimClass(SolrClaimType param) {
		Class c = null;
		switch (param) {
		case RAW:
			c = FpsSsfEclClm.class;
			break;
		case ALERTED:
		case ASRCOST:
			c = FpsClm.class;
//			subTable = "fpsclm.fpsClmAsrpts fpsclmasrpts";
//			subTable2 = "fpsclm.fpsAsrptClmModels ";
			break;
		case PARTDALERTED:
		case PARTDASRCOST:
			c = FpsPtdClm.class;
//			subTable = "fpsclm.fpsPtdClmAsrpts fpsclmasrpts";
//			subTable2 = "fpsclm.fpsAsrptPtdClmModels fpsAsrptPtdClmModels";

			break;
		case PARTDRAW:
			c = FpsPtdEclClm.class;
			break;
		case P1ALERTED:
		case P1ASRCOST:
			c = FpsClmP1.class;
			break;
		
		}
		return c;
	}

	public static String ensureJoinAlias(String subTable) {
		if (StringUtils.isBlank(subTable)) {
			return null;
		}
		String alias = "fpsclmasrpts";
		String trimmed = subTable.trim();
		if (trimmed.contains(" ")) {
			String[] parts = trimmed.split("\\s+");
			if (parts.length > 1 && alias.equals(parts[parts.length - 1])) {
				return trimmed;
			}
			return trimmed + " " + alias;
		}
		return trimmed + " " + alias;
	}

	public Criteria buildSnowflakeClaimsQuery2(ClaimsSearchParameter param, boolean countOnly) {
		String table = "FpsClm  fpsclm";
		String subTable = null;
		String subTable2 = null;
		switch (param.getSearchType()) {
		case RAW:
			table = "FpsSsfEclClm fpsclm";
			break;
		case ALERTED:
			table = "FpsClm fpsclm";
			subTable = "fpsclm.fpsClmAsrpts";
			break;
		case ASRCOST:
			table = "FpsClm fpsclm";
			subTable = "fpsclm.fpsClmAsrptAsrCosts";
			break;
		case PARTDALERTED:
			table = "FpsPtdClm fpsclm";
			subTable = "fpsclm.fpsPtdClmAsrpts";

			break;
		case PARTDASRCOST:
			table = "FpsPtdClm fpsclm";
			subTable = "fpsclm.fpsPtdClmAsrptAsrCosts";

			break;
		case PARTDRAW:
			table = "FpsPtdEclClm fpsclm";
			break;
		case P1ALERTED:
			table = "FpsClmP1 fpsclm";
			subTable = "fpsclm.fpsP1ClmAsrpts";
			break;
		case P1ASRCOST:
			table = "FpsClmP1 fpsclm";
			subTable = "fpsclm.fpsClmAsrptP1AsrCosts";
			break;
		}

		List<AsrGenericCode> claimTypeCodes = param.getClaimTypes();
		Date fromDate = param.getFromDt();
		Date toDate = param.getToDt();
		List<FpsCommonBeneficiary> hicnCodes = param.getHicns();
		boolean isLatest = "Y".equals(param.getLatest());
		boolean isLatestD = "Y".equals(param.getLatestD());
		boolean isRrb = "Y".equals(param.getRrb());
		boolean searchAllNpis = "Y".equals(param.getSearchAllRoles());
		String subjId = param.getNpi();
		Integer asrptId = param.getAsrptId();
		SolrClaimType claimCollection = param.getSearchType();
		Criteria c = getSnowflakeCurrentSession().createCriteria(getClaimClass(claimCollection), "fpsclm");
		if (subTable != null) {
			c.createAlias(subTable, "fpsclmasrpts", JoinType.LEFT_OUTER_JOIN);
			c.setFetchMode(subTable, FetchMode.JOIN);

		}
		c.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		String sql = "";
//		(countOnly ? "select count(*) " : " select distinct fpsclm  ") + " from " + table
//				+ (subTable != null ? " inner join " + (countOnly ? "" : "  ") + subTable : "")
//				+ (subTable2 != null && !countOnly ? " inner join fetch  " + subTable2 : "") + " where 1=1 ";
		Map<String, Object> params = new HashMap<String, Object>();
		String p = "";
		if (fromDate != null) {
			Calendar fromCal = Calendar.getInstance();
			fromCal.setTime(fromDate);
			fromCal.set(Calendar.HOUR_OF_DAY, 0);
			fromCal.set(Calendar.MINUTE, 0);
			fromDate = fromCal.getTime();

		}
		if (toDate != null) {
			Calendar toCal = Calendar.getInstance();
			toCal.setTime(toDate);
			toCal.set(Calendar.HOUR_OF_DAY, 23);
			toCal.set(Calendar.MINUTE, 59);
			toDate = toCal.getTime();

		}
		if (isRrb) {
			c.add(Restrictions.eq("fpsclm.clmSrcType", "B"));
			c.add(Restrictions.isNotNull("fpsclm.beneRrbNum"));
			c.add(Restrictions.or(Restrictions.eq("fpsclm.clmRndrgPrvdrNpiNum", param.getNpi()),
					Restrictions.eq("fpsclm.clmBlgPrvdrNpiNum", param.getNpi())));
			c.add(Restrictions.eq("fpsclm.clmCntrctrNum", "00882"));

			sql += " and fpsclm.beneRrbNum is not null and fpsclm.clmSrcType = :clmType and (fpsclm.clmRndrgPrvdrNpiNum = :rrbNpi or fpsclm.clmBlgPrvdrNpiNum = :rrbNpi) and fpsclm.clmCntrctrNum = '00882' ";

			params.put("clmType", "B");
			params.put("rrbNpi", param.getNpi());
		}
		if (claimTypeCodes != null && claimTypeCodes.size() > 0) {
			List<String> claimTypes = new ArrayList<String>();
			// ignore "D" since there is no clm_src_type column in D claims
			// this is handled via the searchType field
			for (AsrGenericCode claimTypeCode : claimTypeCodes) {
				if ("D".equals(claimTypeCode.getCode())) {
					continue;
				}
				claimTypes.add(claimTypeCode.getCode());
			}
			if (claimTypes.size() > 0) {
				c.add(Restrictions.in("fpsclm.clmSrcType", claimTypes));

				sql += " and fpsclm.clmSrcType in (:clmTypes) ";
				params.put("clmTypes", claimTypes);
			}
		}
		if (hicnCodes != null && hicnCodes.size() > 0) {
			List<String> hicns = new ArrayList<String>();
			for (FpsCommonBeneficiary hicnCode : hicnCodes) {
				hicns.add(hicnCode.getHicn());
			}
			sql += " and fpsclm.clmHicNum in (:hicns) ";
			c.add(Restrictions.in("fpsclm.clmHicNum", hicns));

			params.put("hicns", hicns);

		}
		String dateParam = "";
		if (fromDate == null && toDate == null && !isLatest && !isLatestD) {
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.YEAR, -1);
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			Calendar toCal = Calendar.getInstance();
			toCal.set(Calendar.HOUR_OF_DAY, 23);
			toCal.set(Calendar.MINUTE, 59);
			dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(cal.getTime()) + " TO "
					+ FpsDomainObjectConverter.convertDateToSolrString(toCal.getTime()) + "]";
//			params.put("fromDate", cal.getTime());
//			params.put("toDate", toCal.getTime());
//			sql += " and clmThruDt between :fromDate and :toDate ";
			GregorianCalendar gc1 = new GregorianCalendar();
			GregorianCalendar gc2 = new GregorianCalendar();
			gc1.setTimeInMillis(cal.getTimeInMillis());
			gc2.setTimeInMillis(toCal.getTimeInMillis());
//			c.add(Restrictions.between("fpsclm.clmThruDt", gc1.getTime(), gc2.getTime()));
		}
		if (fromDate != null || toDate != null) {
			GregorianCalendar gc1 = new GregorianCalendar();
			GregorianCalendar gc2 = new GregorianCalendar();

			if (fromDate != null) {
				if (toDate != null) {
					dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(fromDate) + " TO "
							+ FpsDomainObjectConverter.convertDateToSolrString(toDate) + "]";
					params.put("fromDate", fromDate);
					params.put("toDate", toDate);
					gc1.setTimeInMillis(fromDate.getTime());
					gc2.setTimeInMillis(toDate.getTime());
					c.add(Restrictions.between("fpsclm.clmThruDt", gc1.getTime(), gc2.getTime()));
					sql += " and fpsclm.clmThruDt between :fromDate and :toDate ";

				} else {
					dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(fromDate) + " TO *]";
					params.put("fromDate", fromDate);
					gc1.setTimeInMillis(fromDate.getTime());
					c.add(Restrictions.ge("fpsclm.clmThruDt", gc1.getTime()));
					sql += " and fpsclm.clmThruDt >= :fromDate  ";
				}
			} else {
				dateParam = "[* TO " + FpsDomainObjectConverter.convertDateToSolrString(toDate) + "]";
				sql += " and fpsclm.clmThruDt <= :toDate  ";
				gc2.setTimeInMillis(toDate.getTime());

				c.add(Restrictions.le("fpsclm.clmThruDt", gc2.getTime()));
				params.put("toDate", toDate);
			}

		}
		if (isLatest || isLatestD) {
			Calendar cal = Calendar.getInstance();
			Calendar toCal = Calendar.getInstance();
			GregorianCalendar gc1 = new GregorianCalendar();
			GregorianCalendar gc2 = new GregorianCalendar();

			if (isLatestD) {
				String ptdTable = env.getProperty("snowflake.claims.ptdalerted", "FPS_ALL_PTD_CLM");
				String latestSql = "select max(clm_from_dt) from fps_portal." + ptdTable + " where ";
				latestSql += "  ( prvdr_prscrbng_prvdr_npi_num =:subjId";
				latestSql += " OR prvdr_srvc_prvdr_npi_num =:subjId";
				latestSql += ")";
				List<Date> latestDate = getSnowflakeCurrentSession().createSQLQuery(latestSql)
						.setString("subjId", subjId).list();
				Date d = latestDate != null && latestDate.size() > 0 && latestDate.get(0) != null ? latestDate.get(0)
						: new Date();
				cal.setTime(d);
				toCal.setTime(d);
			}
			cal.add(Calendar.DAY_OF_YEAR, -90);

			toCal.set(Calendar.HOUR_OF_DAY, 23);
			toCal.set(Calendar.MINUTE, 59);
			gc1.setTimeInMillis(cal.getTimeInMillis());
			gc2.setTimeInMillis(toCal.getTimeInMillis());
			logger.info("start " + gc1.getTime());
			logger.info("end " + gc2.getTime());

			dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(cal.getTime()) + " TO "
					+ FpsDomainObjectConverter.convertDateToSolrString(toCal.getTime()) + "]";
			sql += " and fpsclm.clmThruDt between :fromDate and :toDate ";
			c.add(Restrictions.between("fpsclm.clmThruDt", gc1.getTime(), gc2.getTime()));
			params.put("fromDate", cal.getTime());
			params.put("toDate", toCal.getTime());
		}
		if (param.getDiagnosises() != null && param.getDiagnosises().size() > 0) {
			List<String> diagnoses = new ArrayList<String>();
			for (AsrGenericCode diagnosis : param.getDiagnosises()) {

				diagnoses.add(diagnosis.getCode());
			}

			sql += "and fpsclm.clmLineDgnsCd in :diagnoses ";
			c.add(Restrictions.in("fpsclm.clmLineDgnsCd", diagnoses));
			params.put("diagnoses", diagnoses);

		}
		// search on multiple hcpcs codes
		if (param.getHcpcses() != null && param.getHcpcses().size() > 0) {
			List<String> hcpcss = new ArrayList<String>();
			for (AsrGenericCode hcpcs : param.getHcpcses()) {

				hcpcss.add(hcpcs.getCode());
			}
			sql += "and fpsclm.clmLineHcpcsCd in :hcpcss ";
			c.add(Restrictions.in("fpsclm.clmLineHcpcsCd", hcpcss));
			params.put("hcpcss", hcpcss);

		}
		// search on multiple procedure codes
		if (param.getProcedures() != null && param.getProcedures().size() > 0) {
			List<String> procs = new ArrayList<String>();
			for (AsrGenericCode proc : param.getProcedures()) {

				procs.add(proc.getCode());
			}
			sql += "and fpsclm.clmPrcdr1Cd in :procs ";
			c.add(Restrictions.in("fpsclm.clmPrcdr1Cd", procs));
			params.put("procs", procs);

		}

//		if (StringUtils.isNotBlank(param.getDiagnosis())) {
//			sql += " and fpsclm.clmLineDgnsCd = :diagnosis ";
//			c.add(Restrictions.eq("fpsclm.clmLineDgnsCd", procs));
//			params.put("diagnosis", param.getDiagnosis());
//		}
//		if (StringUtils.isNotBlank(param.getHcpcs())) {
//			sql += " and fpsclm.clmLineHcpcsCd = :hcpcs ";
//			params.put("hcpcs", param.getHcpcs());
//		}
//		if (StringUtils.isNotBlank(param.getProcedure())) {
//			sql += " and fpsclm.clmPrcdr1Cd = :procedure ";
//			params.put("procedure", param.getProcedure());
//		}
		// default - only alerted claims have asr_key
		if (!SolrClaimType.RAW.equals(claimCollection) && !SolrClaimType.PARTDRAW.equals(claimCollection)) {
//			sql += " and asrKey like :asrptId ";
//			if (SolrClaimType.ALERTED.equals(claimCollection)) {
//				sql += " and fpsclmasrpts.asrptId = :asrptId ";
//
//			}else {
			sql += " and fpsclmasrpts.asrptId = :asrptId ";

//			}
			c.add(Restrictions.eq("fpsclmasrpts.asrptId", asrptId));
			if (subTable2 != null) {
				c.add(Restrictions.eq("fpsclmasrptskey.asrptId", asrptId));

			}
			params.put("asrptId", asrptId);
		}

		int i = 1;
		for (String key : params.keySet()) {
			p += key + ":" + params.get(key);
			if (i < params.keySet().size())
				p += " AND ";
			i++;
		}
		if (searchAllNpis) {
			if (sql.length() > 0) {
				sql += " AND ";
			}
			sql += "  ( fpsclm.clmRndrgPrvdrNpiNum = :subjId ";
			sql += " OR fpsclm.clmBlgPrvdrNpiNum = :subjId ";
			sql += " OR fpsclm.clmRfrgPrvdrNpiNum = :subjId ";
			sql += " OR fpsclm.clmAtndgPrvdrNpiNum = :subjId ";
			sql += ")";
			c.add(Restrictions.or(Restrictions.eq("fpsclm.clmRndrgPrvdrNpiNum", subjId),
					Restrictions.eq("fpsclm.clmBlgPrvdrNpiNum", subjId),
					Restrictions.eq("fpsclm.clmRfrgPrvdrNpiNum", subjId),
					Restrictions.eq("fpsclm.clmAtndgPrvdrNpiNum", subjId)));
			params.put("subjId", subjId);

		}
		if (SolrClaimType.PARTDRAW.equals(claimCollection)) {
			if (sql.length() > 0) {
				sql += " AND ";
			}
			sql += "  ( fpsclm.clmPrsbngPrvdrGnrcIdNum = :subjId ";
			sql += " OR fpsclm.clmSrvcPrvdrGnrcIdNum = :subjId ";
			sql += ")";
			c.add(Restrictions.or(Restrictions.eq("fpsclm.clmSrvcPrvdrGnrcIdNum", subjId),
					Restrictions.eq("fpsclm.clmPrsbngPrvdrGnrcIdNum", subjId)));

			params.put("subjId", subjId);

		}
		// sort
		if (!countOnly) {
			c.addOrder(Order.desc("fpsclm.clmFromDt"));
			c.addOrder(Order.desc("fpsclm.clmThruDt"));
			c.addOrder(Order.asc("fpsclm.clmHicNum"));
			c.addOrder(Order.asc("fpsclm.id"));
			sql += " order by fpsclm.clmFromDt desc,fpsclm.clmThruDt desc, fpsclm.clmHicNum asc, fpsclm.id asc";
		}
		if (param.getStartAt() != null) {
			sql += " offset " + param.getStartAt() + " rows ";
			c.setFirstResult(param.getStartAt());
		}
		if (param.getPageSize() != null) {
			sql += " fetch next " + param.getPageSize() + " rows ";
			c.setMaxResults(param.getPageSize());

		}
//		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql);
//		for (String key : params.keySet()) {
//			if (params.get(key) instanceof List) {
//				query.setParameterList(key, (Collection) params.get(key));
//			} else {
//				query.setParameter(key, params.get(key));
//			}
//
//		}
		return c;
	}

	public Query buildSnowflakeClaimsQuery(ClaimsSearchParameter param, boolean countOnly) {
		String table = "FpsClm  fpsclm";
		String subTable = null;
		switch (param.getSearchType()) {
		case RAW:
			table = "FpsSsfEclClm fpsclm";
			break;
		case ALERTED:
			table = "FpsClm fpsclm";
			subTable = "fpsclm.fpsClmAsrpts";
			break;
		case ASRCOST:
			table = "FpsClm fpsclm";
			subTable = "fpsclm.fpsClmAsrptAsrCosts";
			break;
		case PARTDALERTED:
			table = "FpsPtdClm fpsclm";
			subTable = "fpsclm.fpsPtdClmAsrpts";

			break;
		case PARTDASRCOST:
			table = "FpsPtdClm fpsclm";
			subTable = "fpsclm.fpsPtdClmAsrptAsrCosts";
			break;
		case PARTDRAW:
			table = "FpsPtdEclClm fpsclm";
			break;
		case P1ALERTED:
			table = "FpsClmP1 fpsclm";
			subTable = "fpsclm.fpsP1ClmAsrpts";
			break;
		case P1ASRCOST:
			table = "FpsClmP1 fpsclm";
			subTable = "fpsclm.fpsClmAsrptP1AsrCosts";
			break;
		}
		if (StringUtils.isNotBlank(subTable)) {
			subTable = ensureJoinAlias(subTable);
		}

		List<AsrGenericCode> claimTypeCodes = param.getClaimTypes();
		Date fromDate = param.getFromDt();
		Date toDate = param.getToDt();
		List<FpsCommonBeneficiary> hicnCodes = param.getHicns();
		boolean isLatest = "Y".equals(param.getLatest());
		boolean isLatestD = "Y".equals(param.getLatestD());
		boolean isRrb = "Y".equals(param.getRrb());
		boolean searchAllNpis = "Y".equals(param.getSearchAllRoles());
		String subjId = param.getNpi();
		Integer asrptId = param.getAsrptId();
		SolrClaimType claimCollection = param.getSearchType();
		String sql = (countOnly ? "select count(*) " : " select distinct fpsclm  ") + " from " + table
				+ (subTable != null ? " inner join " + (countOnly ? "" : " fetch ") + subTable : "") + " where 1=1 ";
		Map<String, Object> params = new HashMap<String, Object>();
		String p = "";
		if (fromDate != null) {
			Calendar fromCal = Calendar.getInstance();
			fromCal.setTime(fromDate);
			fromCal.set(Calendar.HOUR_OF_DAY, 0);
			fromCal.set(Calendar.MINUTE, 0);
			fromDate = fromCal.getTime();

		}
		if (toDate != null) {
			Calendar toCal = Calendar.getInstance();
			toCal.setTime(toDate);
			toCal.set(Calendar.HOUR_OF_DAY, 23);
			toCal.set(Calendar.MINUTE, 59);
			toDate = toCal.getTime();

		}
		if (isRrb) {
			sql += " and fpsclm.beneRrbNum is not null and fpsclm.clmSrcType = :clmType and (fpsclm.clmRndrgPrvdrNpiNum = :rrbNpi or fpsclm.clmBlgPrvdrNpiNum = :rrbNpi) and clmCntrctrNum = '00882' ";

			params.put("clmType", "B");
			params.put("rrbNpi", param.getNpi());
		}
		if (claimTypeCodes != null && claimTypeCodes.size() > 0) {
			List<String> claimTypes = new ArrayList<String>();
			// ignore "D" since there is no clm_src_type column in D claims
			// this is handled via the searchType field
			for (AsrGenericCode claimTypeCode : claimTypeCodes) {
				if ("D".equals(claimTypeCode.getCode())) {
					continue;
				}
				claimTypes.add(claimTypeCode.getCode());
			}
			if (claimTypes.size() > 0) {
				sql += " and fpsclm.clmSrcType in (:clmTypes) ";
				params.put("clmTypes", claimTypes);
			}
		}
		if (hicnCodes != null && hicnCodes.size() > 0) {
			List<String> hicns = new ArrayList<String>();
			for (FpsCommonBeneficiary hicnCode : hicnCodes) {
				hicns.add(hicnCode.getHicn());
			}
			sql += " and fpsclm.clmHicNum in (:hicns) ";

			params.put("hicns", hicns);

		}
		String dateParam = "";
		if (fromDate == null && toDate == null && !isLatest && !isLatestD) {
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.YEAR, -1);
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			Calendar toCal = Calendar.getInstance();
			toCal.set(Calendar.HOUR_OF_DAY, 23);
			toCal.set(Calendar.MINUTE, 59);
			dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(cal.getTime()) + " TO "
					+ FpsDomainObjectConverter.convertDateToSolrString(toCal.getTime()) + "]";
//			params.put("fromDate", cal.getTime());
//			params.put("toDate", toCal.getTime());
//			sql += " and clmThruDt between :fromDate and :toDate ";
		}
		if (fromDate != null || toDate != null) {
			if (fromDate != null) {
				if (toDate != null) {
					dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(fromDate) + " TO "
							+ FpsDomainObjectConverter.convertDateToSolrString(toDate) + "]";
					params.put("fromDate", fromDate);
					params.put("toDate", toDate);
					sql += " and fpsclm.clmThruDt between :fromDate and :toDate ";

				} else {
					dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(fromDate) + " TO *]";
					params.put("fromDate", fromDate);
					sql += " and fpsclm.clmThruDt >= :fromDate  ";
				}
			} else {
				dateParam = "[* TO " + FpsDomainObjectConverter.convertDateToSolrString(toDate) + "]";
				sql += " and fpsclm.clmThruDt <= :toDate  ";
				params.put("toDate", toDate);
			}

		}
		if (isLatest || isLatestD) {
			Calendar cal = Calendar.getInstance();
			Calendar toCal = Calendar.getInstance();
			if (isLatestD) {
				String ptdTable = env.getProperty("snowflake.claims.ptdalerted", "FPS_ALL_PTD_CLM");
				String latestSql = "select max(clm_from_dt) from fps_portal." + ptdTable + " where ";
				latestSql += "  ( prvdr_prscrbng_prvdr_npi_num =:subjId";
				latestSql += " OR prvdr_srvc_prvdr_npi_num =:subjId";
				latestSql += ")";
				List<Date> latestDate = getSnowflakeCurrentSession().createSQLQuery(latestSql)
						.setString("subjId", subjId).list();
				Date d = latestDate != null && latestDate.size() > 0 && latestDate.get(0) != null ? latestDate.get(0)
						: new Date();
				cal.setTime(d);
				toCal.setTime(d);
			}
			cal.add(Calendar.DAY_OF_YEAR, -90);

			toCal.set(Calendar.HOUR_OF_DAY, 23);
			toCal.set(Calendar.MINUTE, 59);
			dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(cal.getTime()) + " TO "
					+ FpsDomainObjectConverter.convertDateToSolrString(toCal.getTime()) + "]";
			sql += " and fpsclm.clmThruDt between :fromDate and :toDate ";
			params.put("fromDate", cal.getTime());
			params.put("toDate", toCal.getTime());
		}
		if (param.getDiagnosises() != null && param.getDiagnosises().size() > 0) {
			List<String> diagnoses = new ArrayList<String>();
			for (AsrGenericCode diagnosis : param.getDiagnosises()) {

				diagnoses.add(diagnosis.getCode());
			}

			sql += "and fpsclm.clmLineDgnsCd in :diagnoses ";
			params.put("diagnoses", diagnoses);

		}
		// search on multiple hcpcs codes
		if (param.getHcpcses() != null && param.getHcpcses().size() > 0) {
			List<String> hcpcss = new ArrayList<String>();
			for (AsrGenericCode hcpcs : param.getHcpcses()) {

				hcpcss.add(hcpcs.getCode());
			}
			sql += "and fpsclm.clmLineHcpcsCd in :hcpcss ";
			params.put("hcpcss", hcpcss);

		}
		// search on multiple procedure codes
		if (param.getProcedures() != null && param.getProcedures().size() > 0) {
			List<String> procs = new ArrayList<String>();
			for (AsrGenericCode proc : param.getProcedures()) {

				procs.add(proc.getCode());
			}
			sql += "and fpsclm.clmPrcdr1Cd in :procs ";
			params.put("procs", procs);

		}

		if (StringUtils.isNotBlank(param.getDiagnosis())) {
			sql += " and fpsclm.clmLineDgnsCd = :diagnosis ";
			params.put("diagnosis", param.getDiagnosis());
		}
		if (StringUtils.isNotBlank(param.getHcpcs())) {
			sql += " and fpsclm.clmLineHcpcsCd = :hcpcs ";
			params.put("hcpcs", param.getHcpcs());
		}
		if (StringUtils.isNotBlank(param.getProcedure())) {
			sql += " and fpsclm.clmPrcdr1Cd = :procedure ";
			params.put("procedure", param.getProcedure());
		}
		// default - only alerted claims have asr_key
		if (!SolrClaimType.RAW.equals(claimCollection) && !SolrClaimType.PARTDRAW.equals(claimCollection)) {
//			sql += " and asrKey like :asrptId ";
//			if (SolrClaimType.ALERTED.equals(claimCollection)) {
//				sql += " and fpsclmasrpts.asrptId = :asrptId ";
//
//			}else {
			sql += " and fpsclmasrpts.asrptId = :asrptId ";

//			}
			params.put("asrptId", asrptId);
		}

		int i = 1;
		for (String key : params.keySet()) {
			p += key + ":" + params.get(key);
			if (i < params.keySet().size())
				p += " AND ";
			i++;
		}
		if (searchAllNpis) {
			if (sql.length() > 0) {
				sql += " AND ";
			}
			sql += "  ( fpsclm.clmRndrgPrvdrNpiNum = :subjId ";
			sql += " OR fpsclm.clmBlgPrvdrNpiNum = :subjId ";
			sql += " OR fpsclm.clmRfrgPrvdrNpiNum = :subjId ";
			sql += " OR fpsclm.clmAtndgPrvdrNpiNum = :subjId ";
			sql += ")";
			params.put("subjId", subjId);

		}
		if (SolrClaimType.PARTDRAW.equals(claimCollection)) {
			if (sql.length() > 0) {
				sql += " AND ";
			}
			sql += "  ( fpsclm.clmPrsbngPrvdrGnrcIdNum = :subjId ";
			sql += " OR fpsclm.clmSrvcPrvdrGnrcIdNum = :subjId ";
			sql += ")";
			params.put("subjId", subjId);

		}
		// sort
		if (!countOnly)
			sql += " order by fpsclm.clmFromDt desc,fpsclm.clmThruDt desc, fpsclm.clmHicNum asc, fpsclm.id asc";

//		if (param.getStartAt() != null) {
//			sql += " offset " + param.getStartAt() + " rows ";
//		}
//		if (param.getPageSize() != null) {
//			sql += " fetch next " + param.getPageSize() + " rows ";
//		}
		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql);
		query.setMaxResults(100000);
		for (String key : params.keySet()) {
			if (params.get(key) instanceof List) {
				query.setParameterList(key, (Collection) params.get(key));
			} else {
				query.setParameter(key, params.get(key));
			}

		}
		return query;
	}

	@Override
	public List<Object[]> getHicnsForASR(int asrptId) {
		String sql = "   select " + "       d.clm_hic_num,max(d.clm_thru_dt) "
				+ "      from fps2.fps_asrpt_alert_asctn b "
				+ "      inner join fps2.fps_alert_clm_asctn c on b.alert_id = c.alert_id "
				+ "      inner join fps2.fps_clm d on c.CLM_ID = d.FPS_CLM_ID " + "      where b.asrpt_id = :asrptId "
				+ "      and c.fps_vrsn_ind = '2' " + "      and d.fps_vrsn_ind = '2' "
				+ "		and d.clm_hic_num is not null and length(d.clm_hic_num) > 0 "
				+ "     group by  d.clm_hic_num order by d.clm_hic_num fetch first 1000 rows only ";
		SQLQuery query = (SQLQuery) getCurrentSession().createSQLQuery(sql).setParameter("asrptId", asrptId);

		return query.list();
	}

	@Override
	public List<FpsAsrptPrrtyScreDtlVw> getPriorityScoreForASR(int asrptId) {
		List<FpsAsrptPrrtyScreDtlVw> scores = getCurrentSession().createCriteria(FpsAsrptPrrtyScreDtlVw.class, "score")
				.add(Restrictions.eq("asrptId", asrptId)).addOrder(Order.desc("prrtyScreDt"))
				.addOrder(Order.asc("prrtyCrtraId")).list();

		return scores;
	}

	@Override
	public int getAsrIdFromReportCard(short attrSqncNum, int alertId) {
		Integer asrptId = (Integer) getCurrentSession().createCriteria(FpsAlert.class, "alert")
				.createAlias("alert.fpsAsrptAlertAsctns", "asrAlert").createAlias("asrAlert.fpsAsrpt", "asr")
				.add(Restrictions.eq("alert.alertId", alertId)).setProjection(Projections.property("asr.asrptId"))
				.uniqueResult();
		return asrptId;
	}

	@Override
	public List<FpsAsrptRiskScreHstryVw> loadRiskScoreTrend(int asrptId) {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_YEAR, -365);
		return loadRiskScoreTrend(asrptId, cal.getTime(), new Date());

	}

	@Override
	public List<FpsAsrptRiskScreHstryVw> loadRiskScoreTrend(int asrptId, Date startDt, Date endDt) {
		List<FpsAsrptRiskScreHstryVw> trends = getCurrentSession()
				.createCriteria(FpsAsrptRiskScreHstryVw.class, "trend").add(Restrictions.eq("asrptId", asrptId))
				.add(Restrictions.between("riskScreHstryDt", startDt, endDt)).addOrder(Order.desc("riskScreHstryDt"))
				.list();

		return trends;

	}

	@Override
	public int getLastAlertForAsrAndModel(int asrptId, int modelId) {
		String sql = "select max(c.alert_id) alert_id from fps2.fps_asrpt_alert_asctn a inner join fps2.fps_alert c on a.alert_id = c.alert_id where a.asrpt_id = :asrptId and c.model_id = :modelId";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("asrptId", Integer.valueOf(asrptId));
		query.setParameter("modelId", Integer.valueOf(modelId));
		Integer result = (Integer) query.uniqueResult();
		return result;
	}

	@Override
	public List<FpsEditNumRfrnc> loadEditInfoByModel(String editNm, Boolean showInactive) {
		// TODO Auto-generated method stub
		Criteria c = getCurrentSession().createCriteria(FpsEditNumRfrnc.class);
		if (editNm != null) {
			c.add(Restrictions.eq("fpsEditName", editNm));
		}
		c.add(Restrictions.eq("actvInd", showInactive != null && showInactive ? "N" : "Y"));
		c.addOrder(Order.asc("fpsEditNum"));
		return c.list();
	}

	@Override
	public List<FpsRcncltnClmline> loadClaimsForNpiAndEdit(String npi, String editNm) {
		Criteria c = getCurrentSession().createCriteria(FpsRcncltnClmline.class)
				.add(Restrictions.eq("prvdrNpiNum", npi)).add(Restrictions.eq("modelName", editNm));
		return c.list();
	}

	@Override
	public Date getLastAlertDateForAsr(String asrNpi) {
		String sql = "select max(case when c.audt_updt_ts is not null then c.audt_updt_ts else c.alert_creat_dt end) as updtdt from fps2.fps_asrpt a inner join fps2.fps_asrpt_alert_asctn b on a.asrpt_id = b.asrpt_id inner join fps2.fps_alert c on b.alert_id = c.alert_id where a.subj_id = :subjId";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("subjId", asrNpi);
		List<Date> rows = query.list();
		if (rows != null) {
			return (Date) rows.get(0);
		}
		return null;

	}

	@Override
	public List<? extends BaseClaim> getClaimsForAlertCsv(Integer alertId,
			boolean isPartD, boolean isP1, int pageSize, int index) {
		List<? extends BaseClaim> rows2 = new ArrayList<>();

		String table = "FpsClm fpsclm";
		String subTable = "fpsclm.fpsClmAlerts";
		if (isPartD) {
			table = "FpsPtdClm fpsclm";
			subTable = "fpsclm.fpsPtdClmAlerts";

		}else if (isP1) {
			table = "FpsClmP1 fpsclm";
			subTable = "fpsclm.fpsP1ClmAlerts";
		}
		Criteria c = getSnowflakeCurrentSession().createCriteria((isPartD ? FpsPtdClm.class : isP1 ? FpsClmP1.class :  FpsClm.class), "fpsclm")
				.createAlias((isPartD ? "fpsclm.fpsPtdClmAlerts" : isP1 ? "fpsclm.fpsP1ClmAlerts" : "fpsclm.fpsClmAlerts"), "fpsclmalerts",
						JoinType.LEFT_OUTER_JOIN)
				.add(Restrictions.eq("fpsclmalerts.alertId", alertId))
				.setMaxResults(pageSize).setFirstResult(index)
				.setFetchMode(subTable, FetchMode.JOIN);
		if (isPartD) {
			c.createAlias("fpsclm.fpsPtdClmAsrpts", "fpsclamasrpts", JoinType.NONE);			
		} else if (isP1) {
			c.createAlias("fpsclm.fpsP1ClmAsrpts", "fpsclamasrpts", JoinType.NONE);
		}else {
			c.createAlias("fpsclm.fpsClmAsrpts", "fpsclamasrpts", JoinType.NONE);
		}
		c.addOrder(Order.desc("fpsclm.clmFromDt"));
		c.addOrder(Order.desc("fpsclm.clmThruDt"));
		c.addOrder(Order.asc("fpsclm.clmHicNum"));
		c.addOrder(Order.asc("fpsclm.id"));


		logger.fine("start snowflake query");
		rows2 = c.list();
		logger.fine("end snowflake query");

		return rows2;
	}

	@Override
	public long getClaimsForAlertCount(int alertId, boolean isPartD, boolean isP1) {

		String table = "FpsClm fpsclm";
		String subTable = "fpsclm.fpsClmAlerts fpsclmalerts";
		if (isPartD) {
			table = "FpsPtdClm fpsclm";
			subTable = "fpsclm.fpsPtdClmAlerts fpsclmalerts";

		}else if (isP1) {
			table = "FpsClmP1 fpsclm";
			subTable = "fpsclm.fpsP1ClmAlerts fpsclmalerts";
		}

		String sql = "select count(distinct fpsclm.id)  from " + table + " inner join " + subTable
//				+ " inner join " + subTable2
				+ "  where fpsclmalerts.alertId =  :alertId ";

//				+ "   where attributeKey like :attrKey and alertKey like :alertKey ";

		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setInteger("alertId", alertId);
		Long totalRows = (Long) query.uniqueResult();

		return totalRows.intValue();
	}

	@Override
	public long getClaimsForReportCardCount(short attrId, Integer alertId,  boolean isPartD, boolean isP1) {

		String table = "FpsClm fpsclm";
		String subTable = "fpsclm.fpsClmAttrs fpsclmattrs";
		if (isPartD) {
			table = "FpsPtdClm fpsclm";
			subTable = "fpsclm.fpsPtdClmAttrs fpsclmattrs";

		}else if (isP1) {
			table = "FpsClmP1 fpsclm";
			subTable = "fpsclm.fpsP1ClmAttrs fpsclmattrs";
		}

		String sql = "select count(distinct fpsclm.id) from " + table + " inner join " + subTable
				+ "  where fpsclmattrs.alertId =  :alertId and fpsclmattrs.attrSqncNum = :attrId ";

		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setInteger("alertId", alertId)
				.setInteger("attrId", attrId);
		Long totalRows = (Long) query.uniqueResult();

		return totalRows.intValue();
	}

	@Override
	public List<? extends BaseClaim> getClaimsForReportCardCsv(Short attrSqncNum, int alertId, 
			boolean isPartD,boolean isP1, int pageSize, int index) {
		List<? extends BaseClaim> rows2 = new ArrayList<>();

		String table = "FpsClm fpsclm";
		String subTable = "fpsclm.fpsClmAttrs fpsclmattrs";

		if (isPartD) {
			table = "FpsPtdClm fpsclm";
			subTable = "fpsclm.fpsPtdClmAttrs fpsclmattrs";

		}else if (isP1) {
			table = "FpsClmP1 fpsclm";
			subTable = "fpsclm.fpsP1ClmAttrs fpsclmattrs";
		}

		String sql = "select fpsclm from " + table + " inner join fetch " + subTable
				+ "  where fpsclmattrs.alertId =  :alertId and fpsclmattrs.attrSqncNum = :attrId  "
				+ " order by fpsclm.clmFromDt desc, fpsclm.clmThruDt desc, fpsclm.clmHicNum asc, fpsclm.id asc ";
//
		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setInteger("alertId", alertId)
				.setInteger("attrId", attrSqncNum);
		query.setMaxResults(pageSize);
		query.setFirstResult(index);



		logger.fine("start snowflake query");
		rows2 = query.list();
		return rows2;
	}

	@Override
	public AvailableClaims getAvailableClaimsForAsr(Integer asrptId, String npi) {
		AvailableClaims ac = new AvailableClaims();

		FpsAsrDetailsPageCounts summ = getAllClaimCount(npi);
		ClaimsSearchParameter search = new ClaimsSearchParameter();
		long x = 0;
		// latest claims
		ac.setLatestInd(summ.getSsf90Cnt() > 0 ? "Y" : "N");
		// latest Part D claims


		ac.setLatestDInd(summ.getPtd90Cnt() > 0 ? "Y" : "N");

		// all claims

		ac.setAllClaimsInd(summ.getSsfCnt() > 0 ? "Y" : "N");
		// all Part D claims


		ac.setAllClaimsDInd(summ.getPtdCnt() > 0 ? "Y" : "N");

		// all RRB claims


		ac.setRrbInd(summ.getRrbCnt() > 0 ? "Y" : "N");

		// claims at risk
		search = new ClaimsSearchParameter();
		search.setAsrptId(asrptId);
		search.setSearchType(SolrClaimType.ALERTED);
		x = getClaimCount(search);
		ac.setAtRiskInd(x > 0 ? "Y" : "N");

		// part D claims at risk
		search = new ClaimsSearchParameter();
		search.setAsrptId(asrptId);
		search.setSearchType(SolrClaimType.PARTDALERTED);
		x = getClaimCount(search);
		ac.setAtRiskDInd(x > 0 ? "Y" : "N");

		boolean p1Enabled = false;
		if ("true".equals(p1EnabledInd)) {
			p1Enabled = (true);
			
		}else {
			FpsUsrGuiPrfrnc p1EnabledIndPref = fpsTrackingDao.loadUserPrefs("FPSP1", "p1EnabledInd");
			p1Enabled = ((p1EnabledIndPref!= null && "true".equals(p1EnabledIndPref.getPrfrncOptions())?true:false));
		}
		if (p1Enabled) {
			// phase 1 claims at risk
			search = new ClaimsSearchParameter();
			search.setAsrptId(asrptId);
			search.setSearchType(SolrClaimType.P1ALERTED);
			x = getClaimCount(search);
			ac.setAtRiskP1Ind(x > 0 ? "Y" : "N");
			
			// phase 1 ASR cost
			search = new ClaimsSearchParameter();
			search.setAsrptId(asrptId);
			search.setSearchType(SolrClaimType.P1ASRCOST);
			x = getClaimCount(search);
			ac.setAsrCostP1Ind(x > 0 ? "Y" : "N");
		}
		// ASR cost
		search = new ClaimsSearchParameter();
		search.setAsrptId(asrptId);
		search.setSearchType(SolrClaimType.ASRCOST);
		x = getClaimCount(search);
		ac.setAsrCostInd(x > 0 ? "Y" : "N");

		// PTD ASR cost
		search = new ClaimsSearchParameter();
		search.setAsrptId(asrptId);
		search.setSearchType(SolrClaimType.PARTDASRCOST);
		x = getClaimCount(search);
		ac.setAsrCostDInd(x > 0 ? "Y" : "N");
		return ac;
	}

	private List<FpsVisualizationEdge> loadDmeEdges(List<FpsVisualizationEdge> srcEdges, int tier, boolean export)
			throws  IOException {

		List<FpsVisualizationEdge> edges = new ArrayList<FpsVisualizationEdge>();
		List<String> founds = new ArrayList<String>();

		for (FpsVisualizationEdge edge : srcEdges) {
			Map<String, String> p = new HashMap<String, String>();
			String to = edge.getTo();
			if (!founds.contains(to) && (export || (!export && StringUtils.isNumeric(to)))) {
				// data can contain { since we receive it like that. Just escape it, don't
				// remove it.
				founds.add(to.replace("{", "\\{"));
			}
		}
		Map<String, String> p = new HashMap<String, String>();
		String exportStr = export ? "  " : " AND label != 'referring_to_bene' ";
		String sql = "";
		sql = "from VizDmeEdge where src in :founds  " + exportStr + " AND ranking <= :ranking order by ranking asc";

		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setInteger("ranking", 66)
				.setParameterList("founds", founds).setMaxResults(2000);
		List<VizDmeEdge> dbEdges = query.list();
		edges = FpsDomainObjectConverter.convertRequestDbToBean(dbEdges, FpsVisualizationEdge.class);

		logger.info("dme edges found for tier " + (tier + 1) + ": " + edges.size());
		// if the subject provider is a referring (vs billing) provider
		// load the tiers above and below that NPI. Otherwise load 2
		// tiers below.
		boolean isReferring = false;
		if (tier == 0) {
			for (FpsVisualizationEdge edge : edges) {
				if (edge.getLabel().startsWith("referring")) {
					isReferring = true;
					break;
				}
			}
		}
		if (isReferring) {
			logger.info("referring dme found, loading one tier above and below");
			edges.addAll(loadDmeEdgesReverse(edges, -1, false, srcEdges));
			edges.addAll(loadDmeEdges(edges, 2, export));
		} else {

			logger.info("billing dme found, two tiers below at tier " + tier);

			if (edges.size() > 0 && tier < 2) {
				edges.addAll(loadDmeEdges(edges, tier == 0 ? 1 : tier + 1, export));

			}
		}

		return edges;

	}

	private List<FpsVisualizationEdge> loadDmeEdgesReverse(List<FpsVisualizationEdge> srcEdges, int tier,
			boolean export, List<FpsVisualizationEdge> rootEdges) throws  IOException {

		List<FpsVisualizationEdge> edges = new ArrayList<FpsVisualizationEdge>();
		List<String> founds = new ArrayList<String>();
		srcEdges.addAll(rootEdges);
		for (FpsVisualizationEdge edge : srcEdges) {
			Map<String, String> p = new HashMap<String, String>();
			String to = edge.getTo();
			if (!founds.contains(to) && (export || (!export && StringUtils.isNumeric(to)))) {
				// data can contain { since we receive it like that. Just escape it, don't
				// remove it.
				founds.add(to.replace("{", "\\{"));
			}
		}
		Map<String, String> p = new HashMap<String, String>();
// search only NPIs.  Could use "label" but it's currently not index in Solr
		String exportStr = export ? " " : " AND label != 'referring_to_bene' ";
//		
		String sql = "";
		sql = "from VizDmeEdge where dst in :founds  " + exportStr + " AND ranking <= :ranking order by ranking asc";

		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setInteger("ranking", 66)
				.setParameterList("founds", founds).setMaxResults(2000);
		List<VizDmeEdge> dbEdges = query.list();
		edges = FpsDomainObjectConverter.convertRequestDbToBean(dbEdges, FpsVisualizationEdge.class);

		return edges;

	}

	@Override
	public FpsVisualization loadDmeVisualization(String subjId, final Integer ranking) {

		// p.put("debug", "all");
		Map<String, String> p = new HashMap<String, String>();
		//
		final Integer rankingBucketMax = ranking * 22;
		final Integer rankingBucketMin = ranking == 1 ? 1 : ((ranking - 1) * 22) + 1;
		FpsVisualization viz = new FpsVisualization();
		try {

			List<FpsVisualizationEdge> parents = new ArrayList<FpsVisualizationEdge>();
			FpsVisualizationEdge parent = new FpsVisualizationEdge();
			parent.setTo(subjId);
			parents.add(parent);
			// start with level 0 which is just the ASR NPI
			// load all edges because the UI needs all edges.
			List<FpsVisualizationEdge> edges = loadDmeEdges(parents, 0, ranking == -1);
			// eliminate duplicate edges (based on to/from) as these can clutter the UI
			// when the same edge is displayed more than once
			edges = Lists.newArrayList(Sets.newHashSet(edges));
			// load just the edges for this tier to find the nodes to load.
			List<FpsVisualizationEdge> rawEdges = edges;

			viz.setEdges(edges);

			List<String> edgeTo = new ArrayList<String>();
			if (ranking == 1 || ranking == -1) {
				edgeTo.add(subjId.replace("{", "\\{"));
			}
			for (FpsVisualizationEdge edge : edges) {
				// if edge.getto doesn't exist as a from in edges with lower ranking.
				edgeTo.add(edge.getTo().replace("{", "\\{"));
				if (edge.getFrom() != null)
					edgeTo.add(edge.getFrom().replace("{", "\\{"));
			}
			// remove duplicates
			edgeTo = Lists.newArrayList(Sets.newHashSet(edgeTo));

			List<FpsVisualizationNode> nodes = new ArrayList<FpsVisualizationNode>();
			if (edgeTo.size() > 0) {
				int start = 0;
				int cap = 1024;
				int loaded = 0;
				// the NPIs in edgeTo may be greater than what is actually in the nodes
				// collection
				// so just loop through the expected nodes even if the actual nodes are smaller
				while (start < edgeTo.size()) {
					logger.info("start = " + start + ", loaded = " + loaded);

					String sql = "from VizDmeNode where id in :ids";
					logger.info("query dme nodes start with " + ranking);

					Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setParameterList("ids",
							edgeTo.size() > cap ? Lists.newArrayList(edgeTo).subList(start,
									cap + loaded < edgeTo.size() ? cap + loaded : edgeTo.size()) : edgeTo)
							.setMaxResults(ranking == -1 ? 1024 : 500);
					List<VizDmeNode> dbNodes = query.list();
					nodes.addAll(FpsDomainObjectConverter.convertRequestDbToBean(dbNodes, FpsVisualizationNode.class));

					logger.info("query dme nodes complete");

					loaded += nodes.size();
					start += cap + 1;
				}

//				nodes = ranking > -1 && nodes.size() > 22 ? nodes.subList(0, 22) : nodes;

				FpsVisualizationNode parentNode = new FpsVisualizationNode();
				parentNode.setId(subjId);
				if (!nodes.contains(parentNode) && ranking == 1) {

					logger.info("query parent dme nodes start with " + ranking);
					String sql2 = "from VizDmeNode where id = :id";
					Query query = (Query) getSnowflakeCurrentSession().createQuery(sql2).setString("id", subjId);
					List<VizDmeNode> parentNodes = query.list();
					nodes.addAll(
							FpsDomainObjectConverter.convertRequestDbToBean(parentNodes, FpsVisualizationNode.class));

					logger.info("query parent dme nodes complete");
				}

			}
			List<NvUcmSummary> zrData = fpsHubDao.findUcmSummaryForNpis(edgeTo);
			for (FpsVisualizationNode node : nodes) {
				NvUcmSummary template = new NvUcmSummary();
				template.setNpi(node.getNpi());
				if (zrData.contains(template)) {
					node.setZr(zrData.get(zrData.indexOf(template)).getZrStatus());
					node.setInvestigations(zrData.get(zrData.indexOf(template)).getCaseStatus());
					node.setLeadInd(zrData.get(zrData.indexOf(template)).getLeadInd());
				}

			}
			viz.setNodes(nodes);
		}  catch (IOException e) {
			logger.log(Level.SEVERE, "io solr error loading viz dme data", e);
		}

		return viz;
	}

	private List<FpsVisualizationEdge> loadHhaEdges(List<FpsVisualizationEdge> srcEdges, int tier, boolean export)
			throws  IOException {
		List<FpsVisualizationEdge> edges = new ArrayList<FpsVisualizationEdge>();
		List<String> founds = new ArrayList<String>();

		for (FpsVisualizationEdge edge : srcEdges) {
			Map<String, String> p = new HashMap<String, String>();
			String to = edge.getTo();
			if (!founds.contains(to) && (export || (!export && StringUtils.isNumeric(to)))) {
				// data can contain { since we receive it like that. Just escape it, don't
				// remove it.
				founds.add(to.replace("{", "\\{"));
			}
		}
		String exportStr = export ? "  " : " AND label != 'referring_to_bene' ";
		String sql = "";
		sql = "from VizHhaEdge where src in :founds  " + exportStr + " AND ranking <= :ranking order by ranking asc";

		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setInteger("ranking", 66)
				.setParameterList("founds", founds).setMaxResults(2000);
		List<VizHhaEdge> dbEdges = query.list();
		edges = FpsDomainObjectConverter.convertRequestDbToBean(dbEdges, FpsVisualizationEdge.class);
		logger.info("edges found for tier " + (tier + 1) + ": " + edges.size());
		// only load details for 3 levels.
		if (edges.size() > 0 && tier < 2) {
			edges.addAll(loadHhaEdges(edges, tier == 0 ? 1 : tier + 1, export));

		}

		return edges;
	}

	@Override
	public FpsVisualization loadHhaVisualization(String subjId, final Integer ranking) {
		// p.put("debug", "all");
		Map<String, String> p = new HashMap<String, String>();
		//
		final Integer rankingBucketMax = ranking * 22;
		final Integer rankingBucketMin = ranking == 1 ? 1 : ((ranking - 1) * 22) + 1;
		FpsVisualization viz = new FpsVisualization();
		try {

			List<FpsVisualizationEdge> parents = new ArrayList<FpsVisualizationEdge>();
			FpsVisualizationEdge parent = new FpsVisualizationEdge();
			parent.setTo(subjId);
			parents.add(parent);
			// start with level 0 which is just the ASR NPI
			// load all edges because the UI needs all edges.
			List<FpsVisualizationEdge> edges = loadHhaEdges(parents, 0, ranking == -1);
			// eliminate duplicate edges (based on to/from) as these can clutter the UI
			// when the same edge is displayed more than once
			edges = Lists.newArrayList(Sets.newHashSet(edges));
			// load just the edges for this tier to find the nodes to load.
			List<FpsVisualizationEdge> rawEdges = edges;

			viz.setEdges(edges);

			List<String> edgeTo = new ArrayList<String>();
			if (ranking == 1 || ranking == -1) {
				edgeTo.add(subjId.replace("{", "\\{"));
			}
			for (FpsVisualizationEdge edge : edges) {
				// if edge.getto doesn't exist as a from in edges with lower ranking.
				edgeTo.add(edge.getTo().replace("{", "\\{"));
			}
			// remove duplicates
			edgeTo = Lists.newArrayList(Sets.newHashSet(edgeTo));

			List<FpsVisualizationNode> nodes = new ArrayList<FpsVisualizationNode>();
			if (edgeTo.size() > 0) {

				logger.info("query hha nodes start with " + ranking);

				String sql = "from VizHhaNode where id in :ids";

				Query query = (Query) getSnowflakeCurrentSession().createQuery(sql)
						.setParameterList("ids",
								edgeTo.size() > 1024 ? Lists.newArrayList(edgeTo).subList(0, 1024) : edgeTo)
						.setMaxResults(ranking == -1 ? 1024 : 500);
				List<VizHhaNode> dbNodes = query.list();
				nodes.addAll(FpsDomainObjectConverter.convertRequestDbToBean(dbNodes, FpsVisualizationNode.class));
				logger.info("query hha nodes complete");

//				nodes = response.getBeans(FpsVisualizationNode.class);

//				nodes = ranking > -1 && nodes.size() > 22 ? nodes.subList(0, 22) : nodes;

				FpsVisualizationNode parentNode = new FpsVisualizationNode();
				parentNode.setId(subjId);
				if (!nodes.contains(parentNode) && ranking == 1) {
					edgeTo.add(subjId);

					logger.info("query parent hha nodes start with " + ranking);

					String sql2 = "from VizHhaNode where id = :id";
					query = (Query) getSnowflakeCurrentSession().createQuery(sql2).setString("id", subjId);
					List<VizHhaNode> parentNodes = query.list();
					nodes.addAll(
							FpsDomainObjectConverter.convertRequestDbToBean(parentNodes, FpsVisualizationNode.class));

					logger.info("query parent hha nodes complete");
				}

			}
			List<NvUcmSummary> zrData = fpsHubDao.findUcmSummaryForNpis(edgeTo);
			for (FpsVisualizationNode node : nodes) {
				NvUcmSummary template = new NvUcmSummary();
				template.setNpi(node.getNpi());
				if (zrData.contains(template)) {
					node.setZr(zrData.get(zrData.indexOf(template)).getZrStatus());
					node.setInvestigations(zrData.get(zrData.indexOf(template)).getCaseStatus());
					node.setLeadInd(zrData.get(zrData.indexOf(template)).getLeadInd());
				}

			}
			viz.setNodes(nodes);
		}  catch (IOException e) {
			logger.log(Level.SEVERE, "io solr error loading viz hha data", e);
		}

		return viz;

	}

	@Override
	public FpsVisualization loadVisualization(String subjId, String modelId) {
		return loadVisualization(subjId, modelId, null);
	}

	@Override
	public List<FpsVisualizationEdge> loadVisualizationDates(String subjId, String modelId) {
		return loadVisualizationDates(subjId, modelId, 1);
	}

	@Override
	public List<FpsVisualizationEdge> loadVisualizationDates(String subjId, String modelId, int rows) {
		List<FpsVisualizationEdge> edges = new ArrayList<FpsVisualizationEdge>();

		try {

			String sql = " select max(e.modelRunDt) from VizSnaEdge e where e.subjPrvdrNpi = :subjId and e.modelBusnsId = :modelId order by e.modelRunDt desc ";

			Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setString("subjId", subjId)
					.setString("modelId", modelId);
			Object maxDate = query.uniqueResult();
			logger.info("query max edges date start");

//			
			// if we didn't find a max date, then return a blank object
			if (maxDate == null) {
				logger.info("query max edges date complete, no data found");
				return edges;
			}
			FpsVisualizationEdge maxEdge = new FpsVisualizationEdge();
			maxEdge.setModelRunDt((Date) maxDate);
			edges.add(maxEdge);

		} catch (Exception e) {
			logger.log(Level.SEVERE, "io snowflake error loading viz data", e);
		}

		return edges;
	}

	@Override
	public FpsVisualization loadVisualization(String subjId, String modelId, Date modelRunDt) {
		// p.put("debug", "all");
		Map<String, String> p = new HashMap<String, String>();
		Map<String, String> maxP = new HashMap<String, String>();
		//

		FpsVisualization viz = new FpsVisualization();
		try {

			Date d = modelRunDt;
			if (d == null) {
				logger.info("query max edges date start");
				List<FpsVisualizationEdge> maxDate = loadVisualizationDates(subjId, modelId);
//				response = solrClient.query(collVizEdges, new MapSolrParams(maxP), METHOD.GET);
				// if we didn't find a max date, then return a blank object
				if (maxDate == null || maxDate.size() == 0) {
					logger.info("query max edges date complete, no data found");
					return viz;
				}
				d = maxDate.get(0).getModelRunDt();
			}
			logger.info("query edges start with " + FpsDomainObjectConverter.convertDateToString(d));

			String sql = " from VizSnaEdge where subjPrvdrNpi = :subjId and modelBusnsId = :modelId and modelRunDt = :modelRunDt ";

			Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setString("subjId", subjId)
					.setDate("modelRunDt", d).setString("modelId", modelId).setMaxResults(300);

//			response = solrClient.query(collVizEdges, new MapSolrParams(p), METHOD.GET);

			logger.info("query edges complete");
			List<VizSnaEdge> dbEdges = query.list();
			List<FpsVisualizationEdge> edges = FpsDomainObjectConverter.convertRequestDbToBean(dbEdges,
					FpsVisualizationEdge.class);
			viz.setEdges(edges);

			// p.put("q", "node_id:" + subjId);//+" AND
			// model_busns_id:"+modelId);
			List<String> edgeTo = new ArrayList<String>();
			edgeTo.add(subjId);
			for (FpsVisualizationEdge edge : edges) {
				edgeTo.add(edge.getRltdPrvdrNpi());
			}
			String sql2 = "from VizSnaNode where npi in :edgeTo and modelBusnsId = :modelId and modelRunDt = :runDate";

			p.put("fl", "*,subj_prvdr_role:subj_prvdr_type");
			Query query2 = (Query) getSnowflakeCurrentSession().createQuery(sql2).setParameterList("edgeTo", edgeTo)
					.setDate("runDate", d).setString("modelId", modelId).setMaxResults(300);
			List<VizSnaNode> dbNodes = query2.list();
			logger.info("query nodes start with " + d);
//			response = solrClient.query(collVizNodes, new MapSolrParams(p), METHOD.GET);
			logger.info("query nodes complete");

			List<FpsVisualizationNode> nodes = FpsDomainObjectConverter.convertRequestDbToBean(dbNodes,
					FpsVisualizationNode.class);
			viz.setNodes(nodes);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "io solr error loading viz data", e);
		}

		return viz;

	}

	@Override
	public ClaimsSolrStream loadVizSharedBenes(FpsModel model, String npi, Date modelRunDt, List<String> relatedNPIs) {

		String npiList = StringUtils.join(relatedNPIs, " ");
		String alertKey = "*\\^" + model.getModelId() + "\\^" + npi + "*";
		ClaimsSolrStream css = new ClaimsSolrStream();
		String sql = "with x as (select distinct clm_hic_num from fps_portal.FPS_ALERTED_SSF_CLM where clm_rndrg_prvdr_npi_num in (:npis) OR clm_blg_prvdr_npi_num in (:npis) OR clm_atndg_prvdr_npi_num in (:npis) OR clm_rfrg_prvdr_npi_num in (:npis)) "
				+ "select distinct clm_mbi,a.clm_hic_num,clm_bene_state_cd,src_zip5_cd,bene_1st_name,bene_last_name,bene_line_1_adr,bene_line_2_adr,src_zip_plc_name "
				+ "from fps_portal.FPS_ALERTED_SSF_CLM a inner join x on x.clm_hic_num = a.clm_hic_num inner join fps_portal.FPS_ALERTED_SSF_ALERT_KEY ak on "
				+ "a.clm_Id=ak.clm_Id where ak.model_Id = :modelId and ak.subj_Id = :npi ";

		try {
			Query query2 = (Query) getSnowflakeCurrentSession().createSQLQuery(sql)
					.setParameterList("npis", relatedNPIs).setInteger("modelId", model.getModelId())
					.setString("npi", npi);
			List<Object[]> retval = query2.list();
			ClaimsSolrStreamResult result = new ClaimsSolrStreamResult();
			List<SolrStreamAsrDetailClaimLineItem> items = new ArrayList<>();
			for (Object[] o : retval) {
				SolrStreamAsrDetailClaimLineItem item = new SolrStreamAsrDetailClaimLineItem();
				item.setMbi(o[0] != null ? o[0].toString() : "");
				item.setBeneId(o[1] != null ? o[1].toString() : "");
				item.setBeneStateCd(o[2] != null ? o[2].toString() : "");
				item.setBeneZip(o[3] != null ? o[3].toString() : "");
				item.setBeneFirstName(o[4] != null ? o[4].toString() : "");
				item.setBeneLastName(o[5] != null ? o[5].toString() : "");
				item.setBeneAddress(o[6] != null ? o[6].toString() : "");
				item.setBeneAddress2(o[7] != null ? o[7].toString() : "");
				item.setBeneCity(o[8] != null ? o[8].toString() : "");
				items.add(item);

			}
			result.setDocs(items);
			css.setResult(result);
			return css;

		} catch (HibernateException ce) {
			logger.log(Level.SEVERE, "error querying snowflake", ce);
		}
		return null;
	}

	@Override
	public String checkForVisualization(String subjId) {

		String sql = "select count(*)  from VizHhaEdge where src = :src and ranking between 0 and 66 ";

		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setString("src", subjId);
		Long totalRows = (Long) query.uniqueResult();

		return totalRows > 0 ? "Y" : "N";
	}

	@Override
	public String checkForDmeVisualization(String subjId) {

		String sql = "select count(*)  from VizDmeEdge where src = :src and ranking between 0 and 66 ";

		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setString("src", subjId);
		Long totalRows = (Long) query.uniqueResult();

		return totalRows > 0 ? "Y" : "N";
	}

	@Override
	public List<Integer> loadAvailableRptCardAttrs(int alertId, boolean isPartD, boolean isP1) {
		String table = "FpsClm fpsclm";
		String subTable = "fpsclm.fpsClmAttrs fpsclmattrs";
		if (isPartD) {
			table = "FpsPtdClm fpsclm";
			subTable = "fpsclm.fpsPtdClmAttrs fpsclmattrs";
		}else  if (isP1) {
			table = "FpsClmP1 fpsclm";
			subTable = "fpsclm.fpsP1ClmAttrs fpsclmattrs";
		}

		String sql = "select distinct fpsclmattrs.attrSqncNum   from " + table + " inner join " + subTable
				+ "  where fpsclmattrs.alertId =  :alertId ";

//				+ "   where attributeKey like :attrKey and alertKey like :alertKey ";

		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql)
//				.setString("attrKey", attrKey)
//				.setString("alertKey", alertKey);
				.setInteger("alertId", alertId);
		List<Object> rawResults = query.list();
		List<Integer> results = new ArrayList<>();
		if (rawResults != null) {
			for (Object o : rawResults) {
				results.add((Integer) o);
			}
		}
		return results;
	}

	@Override
	public List<FpsRiskScreRptCardDtl> loadReportCardContribModelAndNpi(String modelBusnsId, String npi, Date runDate) {
		Date d = null;
		if (runDate != null) {
			d = runDate;
		} else {
			d = loadReportCardContribMostRecentAlert(npi, modelBusnsId);
		}

		Criteria c = getCurrentSession().createCriteria(FpsRiskScreRptCardDtl.class, "card")

				.add(Restrictions.eq("modelBusnsId", modelBusnsId)).add(Restrictions.eq("card.prvdrNpiNum", npi));

		c.add(Restrictions.eq("card.alertCreatDt", d));
		// }

		c.addOrder(new EnhancedRiskScoreContribOrder());
		List<FpsRiskScreRptCardDtl> rcs = c.list();
		return rcs;

	}

	@Override
	public Date loadReportCardContribMostRecentAlert(String subjId, String modelBusnsId) {
		Criteria criteria = getCurrentSession().createCriteria(FpsRiskScreRptCardDtl.class, "alert");
		criteria.setFirstResult(0);
		criteria.setMaxResults(1);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<FpsRiskScreRptCardDtl> alerts = criteria.add(Restrictions.eq("modelBusnsId", modelBusnsId))
				.add(Restrictions.eq("prvdrNpiNum", subjId)).addOrder(Order.desc("alertCreatDt")).list();

		FpsRiskScreRptCardDtl alert = new FpsRiskScreRptCardDtl();
		if (alerts != null && alerts.size() > 0) {
			alert = (FpsRiskScreRptCardDtl) alerts.get(0);
			return alert.getAlertCreatDt();
		}
		return null;
	}

	@Override
	public List<FpsPrvdrPrflBlngPrvdr> getBillingSummary(Integer asrptId) {
		Criteria criteria = getCurrentSession().createCriteria(FpsPrvdrPrflBlngPrvdr.class, "bill");

		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<FpsPrvdrPrflBlngPrvdr> bills = criteria.add(Restrictions.eq("asrptId", asrptId))
				.addOrder(Order.desc("clmBlngPrvdrNpiNum")).list();

		return bills;
	}

	@Override
	public List<FpsSplmntlVizDtl> loadSplmntlVizForModelRun(String modelBusnsId, String npi, Date modelRunDt) {
		return loadSplmntlVizForModelRun(modelBusnsId, npi, modelRunDt, null);
	}

	@Override
	public List<FpsSplmntlVizDtl> loadSplmntlVizForModelRun(String modelBusnsId, String npi, Date modelRunDt,
			Integer splmtnVizId) {
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

		String dStr = format.format(modelRunDt);

		Criteria c = getCurrentSession().createCriteria(FpsSplmntlVizDtl.class, "table")

				.add(Restrictions.eq("table.npiNum", npi)).add(Restrictions.eq("table.modelBusnsId", modelBusnsId))

				.add(Restrictions.eq("table.modelRunDt", modelRunDt));
		if (splmtnVizId != null) {
			c.add(Restrictions.eq("table.splmntlVizId", splmtnVizId));
		}
		List<FpsSplmntlVizDtl> tables = c.addOrder(new GenericOrderBy("SPLMTL_VIZ_ID"))
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return tables;

	}
	@Transactional(readOnly = true)
	@Override
	public List<FpsRptCardLabelSnpSht> loadReportCardLabelsSnapshot(FpsRptCardDtl rptCardDtl) {
		Criteria criteria = getCurrentSession().createCriteria(FpsRptCardLabelSnpSht.class);
		criteria.setFirstResult(0);
		criteria.setMaxResults(1);

		criteria.add(Restrictions.eq("modelBusnsId", rptCardDtl.getModelBusnsId()))
				.add(Restrictions.eq("attrSqncNum", rptCardDtl.getAttrSqncNum()))
				.add(Restrictions.eq("modelRunDt", rptCardDtl.getModelRunDt()));

		List<FpsRptCardLabelSnpSht> labels = criteria.addOrder(Order.desc("audtInsrtTs")).list();

		return labels;
	}
	@Override
	public List<FpsCstmTblLabelSnpsht> loadCustomTablesForModelSnapshot(String modelBusnsId, Date runDate) {
		List<FpsCstmTblLabelSnpsht> tables = getCurrentSession().createCriteria(FpsCstmTblLabelSnpsht.class, "table")

				.add(Restrictions.eq("modelBusnsId", modelBusnsId))
				.add(Restrictions.eq("modelRunDt", runDate))
				.addOrder(new GenericOrderBy("cast(trim(cstm_Tbl_id) as INTEGER)"))

				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return tables;
	}

	@Override
	public FpsSplmntlVizLabelSnpsht loadSplmntlVizTablesForModelSnapshot(String modelBusnsId, Date runDate, Integer splmtlVizId ) {
		List<FpsSplmntlVizLabelSnpsht> tables = getCurrentSession().createCriteria(FpsSplmntlVizLabelSnpsht.class, "table")

				.add(Restrictions.eq("modelBusnsId", modelBusnsId))
				.add(Restrictions.eq("modelRunDt", runDate))
				.add(Restrictions.eq("splmtlVizId", splmtlVizId))
				.addOrder(Order.asc("splmtlVizId"))

				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return tables!= null && tables.size() > 0 ? tables.get(0) : null;
	}

}
