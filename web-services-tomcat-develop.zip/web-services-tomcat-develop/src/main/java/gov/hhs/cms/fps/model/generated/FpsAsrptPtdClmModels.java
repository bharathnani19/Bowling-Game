package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Table(name="FPS_ALERTED_PTD_ASR_KEY_MODELS")
@Entity
public class FpsAsrptPtdClmModels  implements Serializable { 
	private Integer clmId;
	private Integer asrptId;
	private String modelIds;
	private FpsClm fpsClm;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PTD_CLM_ID", updatable = false, insertable = false)
	public FpsClm getFpsClm() {
		return fpsClm;
	}
	public void setFpsClm(FpsClm fpsClm) {
		this.fpsClm = fpsClm;
	}
	@Id
	@Column(name="PTD_CLM_ID")
	public Integer getClmId() {
		return clmId;
	}
	public void setClmId(Integer clmId) {
		this.clmId = clmId;
	}
	@Column(name="ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	@Column(name="MODEL_BUSNS_IDS")
	public String getModelIds() {
		return modelIds;
	}
	public void setModelIds(String modelIds) {
		this.modelIds = modelIds;
	}

}
