/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class AsrDetailTotalCostZone.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailTotalCostZone  implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6954749602806751746L;

	private String zone;
	private String jurisdiction;
	private int totalClaimLines;
	private String totalCost;
	
	public AsrDetailTotalCostZone() {
		
	}
	public AsrDetailTotalCostZone(String jurisdiction, Integer totalClaimLines, String totalCost) {
		this.jurisdiction = jurisdiction;
		this.totalClaimLines = totalClaimLines;
		this.totalCost = totalCost;
	}
	
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public int getTotalClaimLines() {
		return totalClaimLines;
	}
	public void setTotalClaimLines(int totalClaimLines) {
		this.totalClaimLines = totalClaimLines;
	}
	public String getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(String totalCost) {
		this.totalCost = totalCost;
	}
	public String getJurisdiction() {
		return jurisdiction;
	}
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

}
