package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
@Entity
@Table(name = "FPS_ASRPT_USER_ADMINV_ACTN_RFRL_DTL")
@BatchSize(size = 100)
public class FpsAsrptUserAdminvActnLawEnfrcmnt implements Serializable {
	private Integer asrptUserAdminvLawEnfrcmntId;

	private String audtInsrtId;
	private Date audtInsrtTs;
	private String audtUpdtId;
	private Date audtUpdtTs;
	private FpsAsrptUserAdminvActn fpsAsrptUserAdminvActn;
	// law enforcement
	private String referredToAgencyType;
	private String leReferralType;

	private Set<FpsAsrptUserAdminvActnLawEnfrcmntAgncy> fpsAsrptUserAdminvActnLawEnfrcmntAgncys;

	
	



	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_USER_ADMINV_ACTN_ID")
	public FpsAsrptUserAdminvActn getFpsAsrptUserAdminvActn() {
		return fpsAsrptUserAdminvActn;
	}

	public void setFpsAsrptUserAdminvActn(FpsAsrptUserAdminvActn fpsAsrptUserAdminvActn) {
		this.fpsAsrptUserAdminvActn = fpsAsrptUserAdminvActn;
	}
	@Column(name = "AUDT_INSRT_ID", nullable = false, length = 128)
	public String getAudtInsrtId() {
		return this.audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_INSRT_TS")
	public Date getAudtInsrtTs() {
		return this.audtInsrtTs;
	}

	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	@Column(name = "AUDT_UPDT_ID", length = 128)
	public String getAudtUpdtId() {
		return this.audtUpdtId;
	}

	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_UPDT_TS", length = 26)
	public Date getAudtUpdtTs() {
		return this.audtUpdtTs;
	}

	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}

	@Id
	@SequenceGenerator(name="asrpt_user_adminv_actn_rfrl_dtl_id_seq",  sequenceName = "asrpt_user_adminv_actn_rfrl_dtl_id_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "asrpt_user_adminv_actn_rfrl_dtl_id_seq")

	@Column(name="ASRPT_USER_ADMINV_ACTN_RFRL_DTL_ID")
	public Integer getAsrptUserAdminvLawEnfrcmntId() {
		return asrptUserAdminvLawEnfrcmntId;
	}

	public void setAsrptUserAdminvLawEnfrcmntId(Integer asrptUserAdminvLawEnfrcmntId) {
		this.asrptUserAdminvLawEnfrcmntId = asrptUserAdminvLawEnfrcmntId;
	}
	@Column(name = "RFRD_TO_AGNCY_TYPE")

	public String getReferredToAgencyType() {
		return referredToAgencyType;
	}

	public void setReferredToAgencyType(String referredToAgencyType) {
		this.referredToAgencyType = referredToAgencyType;
	}
	@Column(name = "LE_RFRL_TYPE")

	public String getLeReferralType() {
		return leReferralType;
	}

	public void setLeReferralType(String leReferralType) {
		this.leReferralType = leReferralType;
	}
	
	@Fetch(FetchMode.SELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "fpsAsrptUserAdminvActnLawEnfrcmnt", cascade = CascadeType.ALL)
	@BatchSize(size=1000)
	@NotFound(action = NotFoundAction.IGNORE)
	public Set<FpsAsrptUserAdminvActnLawEnfrcmntAgncy> getFpsAsrptUserAdminvActnLawEnfrcmntAgncys() {
		return fpsAsrptUserAdminvActnLawEnfrcmntAgncys;
	}

	public void setFpsAsrptUserAdminvActnLawEnfrcmntAgncys(
			Set<FpsAsrptUserAdminvActnLawEnfrcmntAgncy> fpsAsrptUserAdminvActnLawEnfrcmntAgncys) {
		this.fpsAsrptUserAdminvActnLawEnfrcmntAgncys = fpsAsrptUserAdminvActnLawEnfrcmntAgncys;
	}
}
