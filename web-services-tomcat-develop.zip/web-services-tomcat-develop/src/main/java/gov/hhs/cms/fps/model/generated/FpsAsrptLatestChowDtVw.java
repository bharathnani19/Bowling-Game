package gov.hhs.cms.fps.model.generated;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name="FPS_ASRPT_LATEST_CHOW_DT_VW")
@BatchSize(size = 500)
public class FpsAsrptLatestChowDtVw {

	private Integer asrptId;
	private String subjId;
	private Date latestChowDt;
	private FpsAsrpt fpsAsrpt;
	
	@Id
	@Column(name="ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}

	@Column(name="SUBJ_ID")

	public String getSubjId() {
		return subjId;
	}	
	public void setSubjId(String subjId) {
		this.subjId = subjId;
	}
	@Column(name="LATEST_CHOW_DT")

	public Date getLatestChowDt() {
		return latestChowDt;
	}
	public void setLatestChowDt(Date latestChowDt) {
		this.latestChowDt = latestChowDt;
	}
	
	@Fetch(FetchMode.JOIN)	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_ID", updatable = false, insertable = false)
	public FpsAsrpt getFpsAsrpt() {
		return fpsAsrpt;
	}
	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
		this.fpsAsrpt = fpsAsrpt;
	}
}
