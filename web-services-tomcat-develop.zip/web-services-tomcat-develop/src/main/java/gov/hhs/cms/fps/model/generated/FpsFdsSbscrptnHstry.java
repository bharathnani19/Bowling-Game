package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="FPS_FDS_SBSCRPTN_HSTRY")
public class FpsFdsSbscrptnHstry implements Serializable {
	
	private Integer sbscrptnHstryId;
	private Integer sbscrptnActnId;
	private Integer sysId;
	private String eventTypeCd;
	private Integer objTypeId;
	private String transId;
	private String objSrchId;
	private String ntfctnUrlTxt;
	private Date efctvDt;
	private Date trmntnDt;
	private String urlUpdtInd;
	
	
	@Id
	@Column(name="SBSCRPTN_HSTRY_ID")
	public Integer getSbscrptnHstryId() {
		return sbscrptnHstryId;
	}
	public void setSbscrptnHstryId(Integer sbscrptnHstryId) {
		this.sbscrptnHstryId = sbscrptnHstryId;
	}
	@Column(name="SBSCRPTN_ACTN_ID")
	public Integer getSbscrptnActnId() {
		return sbscrptnActnId;
	}
	public void setSbscrptnActnId(Integer sbscrptnActnId) {
		this.sbscrptnActnId = sbscrptnActnId;
	}
	@Column(name="SYS_ID")
	public Integer getSysId() {
		return sysId;
	}
	public void setSysId(Integer sysId) {
		this.sysId = sysId;
	}
	@Column(name="EVNT_TYPE_CD")
	public String getEventTypeCd() {
		return eventTypeCd;
	}
	public void setEventTypeCd(String eventTypeCd) {
		this.eventTypeCd = eventTypeCd;
	}
	@Column(name="OBJ_TYPE_ID")
	public Integer getObjTypeId() {
		return objTypeId;
	}
	public void setObjTypeId(Integer objTypeId) {
		this.objTypeId = objTypeId;
	}
	@Column(name="TRANS_ID")
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}
	@Column(name="OBJ_SRCH_ID")
	public String getObjSrchId() {
		return objSrchId;
	}
	public void setObjSrchId(String objSrchId) {
		this.objSrchId = objSrchId;
	}
	@Column(name="NTFCTN_URL_TXT")
	public String getNtfctnUrlTxt() {
		return ntfctnUrlTxt;
	}
	public void setNtfctnUrlTxt(String ntfctnUrlTxt) {
		this.ntfctnUrlTxt = ntfctnUrlTxt;
	}
	@Column(name="EFCTV_DT")
	public Date getEfctvDt() {
		return efctvDt;
	}
	public void setEfctvDt(Date efctvDt) {
		this.efctvDt = efctvDt;
	}
	@Column(name="TRMNTN_DT")
	public Date getTrmntnDt() {
		return trmntnDt;
	}
	public void setTrmntnDt(Date trmntnDt) {
		this.trmntnDt = trmntnDt;
	}
	@Column(name="URL_UPDT_IND")
	public String getUrlUpdtInd() {
		return urlUpdtInd;
	}
	public void setUrlUpdtInd(String urlUpdtInd) {
		this.urlUpdtInd = urlUpdtInd;
	}
	

}
