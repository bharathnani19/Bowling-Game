/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class FpsCommonBeneficiary.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class FpsCommonBeneficiary implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5848913279735267377L;
	
	/** The hicn. */
//	@Field("clm_hic_num")
	private String hicn;
	private String mbi;
	
	private FpsGeoBase address;

	/**
	 * Gets the hicn.
	 *
	 * @return the hicn
	 */
	public String getHicn() {
		return hicn;
	}

	/**
	 * Sets the hicn.
	 *
	 * @param hicn the hicn to set
	 */
	public void setHicn(String hicn) {
		this.hicn = hicn;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FpsCommonBeneficiary [hicn=" + hicn + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((hicn == null) ? 0 : hicn.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FpsCommonBeneficiary other = (FpsCommonBeneficiary) obj;
		if (hicn == null) {
			if (other.hicn != null)
				return false;
		} else if (!hicn.equals(other.hicn))
			return false;
		return true;
	}

	public FpsGeoBase getAddress() {
		return address;
	}

	public void setAddress(FpsGeoBase address) {
		this.address = address;
	}

	public String getMbi() {
		return mbi;
	}

	public void setMbi(String mbi) {
		this.mbi = mbi;
	}
}
