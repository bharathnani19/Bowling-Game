package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

public class FpsCustomAsrListItem implements Serializable {

	private Integer customAsrListItemId;
	private FpsCustomAsrList fpsCustomAsrList;
	private String prvdrNpiNum;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private String audtUpdtId;
	private Date audtUpdtTs;
	public Integer getCustomAsrListItemId() {
		return customAsrListItemId;
	}
	public void setCustomAsrListItemId(Integer customAsrListItemId) {
		this.customAsrListItemId = customAsrListItemId;
	}
	public FpsCustomAsrList getFpsCustomAsrList() {
		return fpsCustomAsrList;
	}
	public void setFpsCustomAsrList(FpsCustomAsrList fpsCustomAsrList) {
		this.fpsCustomAsrList = fpsCustomAsrList;
	}
	public String getPrvdrNpiNum() {
		return prvdrNpiNum;
	}
	public void setPrvdrNpiNum(String prvdrNpiNum) {
		this.prvdrNpiNum = prvdrNpiNum;
	}
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	public Date getAudtInsrtTs() {
		return audtInsrtTs;
	}
	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	public String getAudtUpdtId() {
		return audtUpdtId;
	}
	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	public Date getAudtUpdtTs() {
		return audtUpdtTs;
	}
	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
}
