package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="FPS_ASRPT_INVSTGTN_STUS_SMRY_VW")
public class FpsAsrptInvstgnStusSmryVw implements Serializable{

	private Integer asrptId;
	private String type;
	private String openZone;
	private String closedZone;
	@Id
	@Column(name="ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	
	@Id
	@Column(name="TYPE")
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Column(name="OPEN_ZONE")
	public String getOpenZone() {
		return openZone;
	}
	public void setOpenZone(String openZone) {
		this.openZone = openZone;
	}
	@Column(name="CLOSED_ZONE")
	public String getClosedZone() {
		return closedZone;
	}
	public void setClosedZone(String closedZone) {
		this.closedZone = closedZone;
	}
	
}
