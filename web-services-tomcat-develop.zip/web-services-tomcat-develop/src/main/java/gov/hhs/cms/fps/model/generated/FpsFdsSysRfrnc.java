package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "FPS_FDS_SYS_RFRNC")
public class FpsFdsSysRfrnc implements Serializable {

	private String sysId;
	private String sysShrtName;
	private String sysLongName;
	private String baseUrlTxt;
	private String sprtEmail;
	private String sprtPhneNum;
	private Date audtInsrtTs;
	private String audtInsrtId;
	private String sysJrsdctn;

	@Id
	@Column(name = "SYS_ID")
	public String getSysId() {
		return sysId;
	}

	public void setSysId(String sysId) {
		this.sysId = sysId;
	}

	@Column(name = "SYS_SHRT_NAME")
	public String getSysShrtName() {
		return sysShrtName;
	}

	public void setSysShrtName(String sysShrtName) {
		this.sysShrtName = sysShrtName;
	}

	@Column(name = "SYS_LONG_NAME")
	public String getSysLongName() {
		return sysLongName;
	}

	public void setSysLongName(String sysLongName) {
		this.sysLongName = sysLongName;
	}

	@Column(name = "BASE_URL_TXT")
	public String getBaseUrlTxt() {
		return baseUrlTxt;
	}

	public void setBaseUrlTxt(String baseUrlTxt) {
		this.baseUrlTxt = baseUrlTxt;
	}

	@Column(name = "SPRT_EMAIL")
	public String getSprtEmail() {
		return sprtEmail;
	}

	public void setSprtEmail(String sprtEmail) {
		this.sprtEmail = sprtEmail;
	}

	@Column(name = "SPRT_PHNE_NUM")
	public String getSprtPhneNum() {
		return sprtPhneNum;
	}

	public void setSprtPhneNum(String sprtPhneNum) {
		this.sprtPhneNum = sprtPhneNum;
	}

	@Column(name = "AUDT_INSRT_TS")

	public Date getAudtInsrtTs() {
		return audtInsrtTs;
	}

	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	@Column(name = "AUDT_INSRT_ID")

	public String getAudtInsrtId() {
		return audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	@Column(name = "SYS_JRSDCTN")
	public String getSysJrsdctn() {
		return sysJrsdctn;
	}

	public void setSysJrsdctn(String sysJrsdctn) {
		this.sysJrsdctn = sysJrsdctn;
	}

}
