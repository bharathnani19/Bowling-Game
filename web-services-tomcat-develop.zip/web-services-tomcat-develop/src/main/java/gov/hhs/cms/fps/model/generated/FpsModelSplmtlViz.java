package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="FPS_MODEL_SPLMTL_VIZ")
public class FpsModelSplmtlViz implements Serializable {
	private Integer fpsModelSplmtlVizId;
	private String modelBusnsId;
	private Integer splmtlVizId;
	private String splmtlVizTitle;
	private String splmtlVizDesc;
	@Id
	@Column(name="FPS_MODEL_SPLMTL_VIZ_ID")
	public Integer getFpsModelSplmtlVizId() {
		return fpsModelSplmtlVizId;
	}
	public void setFpsModelSplmtlVizId(Integer fpsModelSplmtlVizId) {
		this.fpsModelSplmtlVizId = fpsModelSplmtlVizId;
	}
	@Column(name="MODEL_BUSNS_ID")
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	@Column(name="SPLMTL_VIZ_ID")
	public Integer getSplmtlVizId() {
		return splmtlVizId;
	}
	public void setSplmtlVizId(Integer splmtlVizId) {
		this.splmtlVizId = splmtlVizId;
	}
	@Column(name="SPLMTL_VIZ_TITLE")
	public String getSplmtlVizTitle() {
		return splmtlVizTitle;
	}
	public void setSplmtlVizTitle(String splmtlVizTitle) {
		this.splmtlVizTitle = splmtlVizTitle;
	}
	@Column(name="SPLMTL_VIZ_DESC")
	public String getSplmtlVizDesc() {
		return splmtlVizDesc;
	}
	public void setSplmtlVizDesc(String splmtlVizDesc) {
		this.splmtlVizDesc = splmtlVizDesc;
	}
	
	

}
