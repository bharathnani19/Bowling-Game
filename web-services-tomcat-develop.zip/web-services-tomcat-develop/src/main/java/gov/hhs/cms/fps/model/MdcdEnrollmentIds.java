package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class MdcdEnrollmentIds implements Serializable{
	
	private String mdcdId;
	private String state;
	private String status;
	private String efctvDt;
	private String termDt;
	public String getMdcdId() {
		return mdcdId;
	}
	public void setMdcdId(String mdcdId) {
		this.mdcdId = mdcdId;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEfctvDt() {
		return efctvDt;
	}
	public void setEfctvDt(String efctvDt) {
		this.efctvDt = efctvDt;
	}
	public String getTermDt() {
		return termDt;
	}
	public void setTermDt(String termDt) {
		this.termDt = termDt;
	}
	

}
