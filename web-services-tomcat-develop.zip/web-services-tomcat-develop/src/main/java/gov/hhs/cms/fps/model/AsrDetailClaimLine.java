package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.HashSet;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailClaimLine implements Serializable {

	private HashSet<AsrDetailClaimLineItem> partAItems = new HashSet<AsrDetailClaimLineItem> ();
	private HashSet<AsrDetailClaimLineItem> partBItems = new HashSet<AsrDetailClaimLineItem> ();
	private HashSet<AsrDetailClaimLineItem> partDMEItems = new HashSet<AsrDetailClaimLineItem> ();
	
	public HashSet<AsrDetailClaimLineItem> getPartAItems() {
		return partAItems;
	}
	public void setPartAItems(HashSet<AsrDetailClaimLineItem> partAItems) {
		this.partAItems = partAItems;
	}
	public HashSet<AsrDetailClaimLineItem> getPartBItems() {
		return partBItems;
	}
	public void setPartBItems(HashSet<AsrDetailClaimLineItem> partBItems) {
		this.partBItems = partBItems;
	}
	public HashSet<AsrDetailClaimLineItem> getPartDMEItems() {
		return partDMEItems;
	}
	public void setPartDMEItems(HashSet<AsrDetailClaimLineItem> partDMEItems) {
		this.partDMEItems = partDMEItems;
	}
}
