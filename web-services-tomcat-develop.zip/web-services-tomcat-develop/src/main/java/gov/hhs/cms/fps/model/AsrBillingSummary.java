package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.math.BigDecimal;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrBillingSummary implements Serializable {

	private Integer asrptId;
	private String prvdrNpiNum;
	private String prvdrNm;
	private String upicJrsdctn;
	private String npiAlertTypeCd;
	private String clmBlngPrvdrNpiNum;
	private String rltdPrvdrName;
	private BigDecimal clmPmtAmt;
	private Integer clmLineCnt;
	private BigDecimal clmSbmtAmt;
	private Integer clmBeneCnt;
	private String modelBusnsId;
	private String clmSrcType;
	private Integer blngAsrptId;
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	public String getPrvdrNpiNum() {
		return prvdrNpiNum;
	}
	public void setPrvdrNpiNum(String prvdrNpiNum) {
		this.prvdrNpiNum = prvdrNpiNum;
	}
	public String getPrvdrNm() {
		return prvdrNm;
	}
	public void setPrvdrNm(String prvdrNm) {
		this.prvdrNm = prvdrNm;
	}
	public String getUpicJrsdctn() {
		return upicJrsdctn;
	}
	public void setUpicJrsdctn(String upicJrsdctn) {
		this.upicJrsdctn = upicJrsdctn;
	}
	public String getNpiAlertTypeCd() {
		return npiAlertTypeCd;
	}
	public void setNpiAlertTypeCd(String npiAlertTypeCd) {
		this.npiAlertTypeCd = npiAlertTypeCd;
	}
	public String getClmBlngPrvdrNpiNum() {
		return clmBlngPrvdrNpiNum;
	}
	public void setClmBlngPrvdrNpiNum(String clmBlngPrvdrNpiNum) {
		this.clmBlngPrvdrNpiNum = clmBlngPrvdrNpiNum;
	}
	public String getRltdPrvdrName() {
		return rltdPrvdrName;
	}
	public void setRltdPrvdrName(String rltdPrvdrName) {
		this.rltdPrvdrName = rltdPrvdrName;
	}
	public BigDecimal getClmPmtAmt() {
		return clmPmtAmt;
	}
	public void setClmPmtAmt(BigDecimal clmPmtAmt) {
		this.clmPmtAmt = clmPmtAmt;
	}
	public Integer getClmLineCnt() {
		return clmLineCnt;
	}
	public void setClmLineCnt(Integer clmLineCnt) {
		this.clmLineCnt = clmLineCnt;
	}
	public BigDecimal getClmSbmtAmt() {
		return clmSbmtAmt;
	}
	public void setClmSbmtAmt(BigDecimal clmSbmtAmt) {
		this.clmSbmtAmt = clmSbmtAmt;
	}
	public Integer getClmBeneCnt() {
		return clmBeneCnt;
	}
	public void setClmBeneCnt(Integer clmBeneCnt) {
		this.clmBeneCnt = clmBeneCnt;
	}
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	public String getClmSrcType() {
		return clmSrcType;
	}
	public void setClmSrcType(String clmSrcType) {
		this.clmSrcType = clmSrcType;
	}
	public Integer getBlngAsrptId() {
		return blngAsrptId;
	}
	public void setBlngAsrptId(Integer blngAsrptId) {
		this.blngAsrptId = blngAsrptId;
	}
}
