/*
 * 
 */
package gov.hhs.cms.fps.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class FpsCommonActionType.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class FpsCommonBarrierType {
	
	private String barrierCd;
	private String barrierDesc;
	
	public String getBarrierCd() {
		return barrierCd;
	}
	public void setBarrierCd(String barrierCd) {
		this.barrierCd = barrierCd;
	}
	public String getBarrierDesc() {
		return barrierDesc;
	}
	public void setBarrierDesc(String barrierDesc) {
		this.barrierDesc = barrierDesc;
	}
}
