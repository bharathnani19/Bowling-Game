package gov.hhs.cms.fps.model.generated;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.cache.annotation.Cacheable;

@Entity
@Table(name = "FPS_ALERTED_SSF_ATTR_KEY")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY, region = "claim")
@BatchSize(size = 1000)

public class FpsClmAttr implements java.io.Serializable {

	private Integer clmId;
	private Integer asrptId;
	private Integer alertId;
	private Integer attrSqncNum;
	private Integer clmRvwInd;
	private FpsClm fpsClm;

	@Id
	@Column(name = "CLM_ID")
	public Integer getClmId() {
		return clmId;
	}

	public void setClmId(Integer clmId) {
		this.clmId = clmId;
	}

	@Id
	@Column(name = "ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}

	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}

	@Id
	@Column(name = "ALERT_ID")
	public Integer getAlertId() {
		return alertId;
	}

	public void setAlertId(Integer alertId) {
		this.alertId = alertId;
	}

	@Id
	@Column(name = "ATTR_SQNC_NUM")
	public Integer getAttrSqncNum() {
		return attrSqncNum;
	}

	public void setAttrSqncNum(Integer attrSqncNum) {
		this.attrSqncNum = attrSqncNum;
	}

	@Id
	@Column(name = "CLM_RVW_IND")
	public Integer getClmRvwInd() {
		return clmRvwInd;
	}

	public void setClmRvwInd(Integer clmRvwInd) {
		this.clmRvwInd = clmRvwInd;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CLM_ID", updatable = false, insertable = false)
	public FpsClm getFpsClm() {
		return fpsClm;
	}

	public void setFpsClm(FpsClm fpsClm) {
		this.fpsClm = fpsClm;
	}

}
