package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="FPS_FDS_OBJ_TYPE_RFRNC")
public class FpsFdsObjTypeRfrnc implements Serializable {
	private Integer objTypeId;
	private String objTypeName;
	private String objTypeDesc;
	
	@Id
	@Column(name="OBJ_TYPE_ID")
	public Integer getObjTypeId() {
		return objTypeId;
	}
	public void setObjTypeId(Integer objTypeId) {
		this.objTypeId = objTypeId;
	}
	@Column(name="OBJ_TYPE_NAME")
	public String getObjTypeName() {
		return objTypeName;
	}
	public void setObjTypeName(String objTypeName) {
		this.objTypeName = objTypeName;
	}
	@Column(name="OBJ_TYPE_DESC")
	public String getObjTypeDesc() {
		return objTypeDesc;
	}
	public void setObjTypeDesc(String objTypeDesc) {
		this.objTypeDesc = objTypeDesc;
	}

}
