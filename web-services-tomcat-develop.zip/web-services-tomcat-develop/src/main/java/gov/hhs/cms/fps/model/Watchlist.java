package gov.hhs.cms.fps.model;

import java.util.List;

public class Watchlist {
	private String name;
	private List<WatchlistItem> items;
	private String type;
	private String email;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<WatchlistItem> getItems() {
		return items;
	}
	public void setItems(List<WatchlistItem> items) {
		this.items = items;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

}
