package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class FpsSystemStatus implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9053410242520757354L;
	private String modelName;
	private String lastProcessedTime;
	private String modelDesc;
	private String modelDocPath;
	private String cpiInd;
	//private String lookback = "TBD";
	
	public String getLastProcessedTime() {
		return lastProcessedTime;
	}
	public void setLastProcessedTime(String lastProcessedTime) {
		this.lastProcessedTime = lastProcessedTime;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getModelDesc() {
		return modelDesc;
	}
	public void setModelDesc(String modelDesc) {
		this.modelDesc = modelDesc;
	}
	public String getModelDocPath() {
		return modelDocPath;
	}
	public void setModelDocPath(String modelDocPath) {
		this.modelDocPath = modelDocPath;
	}
	public String getCpiInd() {
		return cpiInd;
	}
	public void setCpiInd(String cpiInd) {
		this.cpiInd = cpiInd;
	}
}
