package gov.hhs.cms.fps.model;

public class AllClaimCountSummary {

	private String npi;
	private Integer ssfCnt;
	private Integer ptdCnt;
	private Integer ssf90Cnt;
	private Integer ptd90Cnt;
	private Integer rrbCnt;
	public String getNpi() {
		return npi;
	}
	public void setNpi(String npi) {
		this.npi = npi;
	}
	public Integer getSsfCnt() {
		return ssfCnt;
	}
	public void setSsfCnt(Integer ssfCnt) {
		this.ssfCnt = ssfCnt;
	}
	public Integer getPtdCnt() {
		return ptdCnt;
	}
	public void setPtdCnt(Integer ptdCnt) {
		this.ptdCnt = ptdCnt;
	}
	public Integer getSsf90Cnt() {
		return ssf90Cnt;
	}
	public void setSsf90Cnt(Integer ssf90Cnt) {
		this.ssf90Cnt = ssf90Cnt;
	}
	public Integer getPtd90Cnt() {
		return ptd90Cnt;
	}
	public void setPtd90Cnt(Integer ptd90Cnt) {
		this.ptd90Cnt = ptd90Cnt;
	}
	public Integer getRrbCnt() {
		return rrbCnt;
	}
	public void setRrbCnt(Integer rrbCnt) {
		this.rrbCnt = rrbCnt;
	}
}
