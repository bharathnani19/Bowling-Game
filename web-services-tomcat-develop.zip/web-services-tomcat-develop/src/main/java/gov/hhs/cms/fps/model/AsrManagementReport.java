package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrManagementReport implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4620562575948008759L;
	private List<AsrManagementReportItem> items;
	public List<AsrManagementReportItem> getItems() {
		return items;
	}
	public void setItems(List<AsrManagementReportItem> items) {
		this.items = items;
	}

}
