package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.Subselect;
@Entity
@Subselect("select  distinct x.NPI_NUM,cast(case "
			+ " when x.ucm_proc_name in ('Temp-Partial', 'Partial', 'Partial ZR') then 'Yes - Partial' "
			+ " when x.ucm_proc_name in( 'Temp-Full','Full ZR', 'Full') then 'Yes - Full' "
			+ " when x.ucm_proc_name in (  'No', 'N/A', 'ZR Withdrawn') or x.ucm_proc_name is null then 'No' else 'Yes'  end as varchar(20)) as zr_txt  "
			+ " from fps2.FPS_PRVDR_ZN_RSTCTN_DTL_FACT x  "
			)
public class FpsNpiZrSmry implements Serializable {
	private String npiNum;
	private String zrTxt;
	
	@Id
	@Column(name = "ZR_TXT")
	public String getZrTxt() {
		return zrTxt;
	}
	public void setZrTxt(String zrTxt) {
		this.zrTxt = zrTxt;
	}
	@Id
	@Column(name = "NPI_NUM")
	public String getNpiNum() {
		return npiNum;
	}
	public void setNpiNum(String npiNum) {
		this.npiNum = npiNum;
	}
	
	

}
