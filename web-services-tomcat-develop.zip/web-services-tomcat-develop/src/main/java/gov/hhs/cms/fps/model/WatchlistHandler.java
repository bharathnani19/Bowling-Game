package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WatchlistHandler implements Serializable {

	private Map<String,Map<String,List<WatchlistItem>>> watchlists = new HashMap<String,Map<String,List<WatchlistItem>>>();
	
	public Map<String,List<WatchlistItem>> getWatchlistMap(String type){
		if (watchlists.get(type) == null) addWatchlistMap(type);
		return watchlists.get(type);
	}
	public Map<String,List<WatchlistItem>> addWatchlistMap(String type){
		if (watchlists.get(type) == null) {
			Map<String,List<WatchlistItem>> map = new HashMap<String,List<WatchlistItem>>();
			watchlists.put(type, map);
		}
		return watchlists.get(type);
	}
	public Map<String,List<WatchlistItem>> addToWatchlistMap(String type, String key, WatchlistItem item){
		if (watchlists.get(type) == null) addWatchlistMap(type);
		Map<String,List<WatchlistItem>> map2 = watchlists.get(type);
		initWatchlistItems(map2, key);
		map2.get(key).add(item);
		return watchlists.get(type);
	}
	public Map<String,List<WatchlistItem>> addToWatchlistMap(String type,String key,List<WatchlistItem> items){
		if (watchlists.get(type) == null) addWatchlistMap(type);
		Map<String,List<WatchlistItem>> map2 = watchlists.get(type);
		initWatchlistItems(map2, key);
		watchlists.get(type).get(key).addAll(items);
		return watchlists.get(type);
	}
	private void initWatchlistItems(Map<String,List<WatchlistItem>> map2, String key) {
		if (map2.get(key) == null) {
			List<WatchlistItem> l = new ArrayList<WatchlistItem>();
			map2.put(key, l);
		}
	}
	public Map<String, Map<String, List<WatchlistItem>>> getWatchlists() {
		return watchlists;
	}
}
