package gov.hhs.cms.fps.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MicroserviceController {

	@RequestMapping("/micro")
	public ModelAndView test() {
		return new ModelAndView("micro");
	}

	
}
