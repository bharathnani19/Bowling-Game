package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrManagementReportItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4620562575948008759L;
	private String label;
	private int count;
	private String preSetFlag;
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getPreSetFlag() {
		return preSetFlag;
	}
	public void setPreSetFlag(String preSetFlag) {
		this.preSetFlag = preSetFlag;
	}

}
