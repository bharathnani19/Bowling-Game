/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class AsrSummaryActivity.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrSummaryActivity  implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8270015608990908419L;
	
	/** The user activity id. */
	private int userActivityId;
	
	private String activityTypeDesc;
	
	private String source;

	/**
	 * Gets the user activity id.
	 *
	 * @return the user activity id
	 */
	public int getUserActivityId() {
		return userActivityId;
	}
	
	/**
	 * Sets the user activity id.
	 *
	 * @param userActivityId the new user activity id
	 */
	public void setUserActivityId(int userActivityId) {
		this.userActivityId = userActivityId;
	}

	public String getActivityTypeDesc() {
		return activityTypeDesc;
	}

	public void setActivityTypeDesc(String activityTypeDesc) {
		this.activityTypeDesc = activityTypeDesc;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

}
