package gov.hhs.cms.fps.dao;

import java.util.Date;
import java.util.List;
import java.util.Set;

import gov.hhs.cms.fps.model.AsrDeleteLead;
import gov.hhs.cms.fps.model.AsrInvestigation;
import gov.hhs.cms.fps.model.AsrSearchParameter;
import gov.hhs.cms.fps.model.AsrSummaryRollupCounts;
import gov.hhs.cms.fps.model.BaseRequest;
import gov.hhs.cms.fps.model.FpsUser;
import gov.hhs.cms.fps.model.generated.FpsAlert;
import gov.hhs.cms.fps.model.generated.FpsAsrpt;
import gov.hhs.cms.fps.model.generated.FpsAsrptInvstgtn;
import gov.hhs.cms.fps.model.generated.FpsAsrptLog;
import gov.hhs.cms.fps.model.generated.FpsAsrptMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptSummaryAsrsMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptUser;
import gov.hhs.cms.fps.model.generated.FpsAsrptUserActvty;
import gov.hhs.cms.fps.model.generated.FpsAsrptUserAdminvActn;
import gov.hhs.cms.fps.model.generated.FpsModel;
import gov.hhs.cms.fps.model.generated.FpsModelMdcd;
import gov.hhs.cms.fps.model.generated.FpsPrvdrAnlys;
import gov.hhs.cms.fps.model.generated.VwFpsAsrptIdXwalkSmry;
import gov.hhs.cms.fps.model.okta.OktaGroup;

public interface FpsServiceDao {
	public void getTest();

	public List<FpsAsrpt> searchAsrCases(BaseRequest paramBaseRequest);

	public void clearCache();


	

	public AsrSummaryRollupCounts getAsrSummaryRollupCounts(int paramInt);

	public FpsModel updateModel(FpsModel paramFpsModel);

	public FpsModel loadModelById(int paramInt);
	public FpsModelMdcd loadMdcdModelById(int paramInt);

	public FpsAsrpt findAsrBySubjId(String subjId);

	public FpsAsrpt findAsrByAsrId(Integer asrId);

	public void insertAsrHistory(FpsAsrptLog log);

	public FpsModel loadModelByBusnsId(String modelBusnsId);
	public FpsModelMdcd loadMdcdModelByBusnsId(String modelBusnsId);

	public FpsAsrptInvstgtn getInvestigationById(int investId);

	public <T> T save(T o);

	public void insertAsrHistory(String userId, String superId, Integer invId, Integer asrId, Double riskScore,
			String text, String version, String action);

	public String assignAsr(int paramInt, String paramString1, String paramString2);

	public String reassignAsr(int paramInt, String paramString1, String paramString2, String paramString3);


	public void reassignInvestigation(int paramInt, String paramString);

	public FpsAsrptInvstgtn addInvestigationLink(AsrInvestigation paramAsrInvestigation);

	public List<FpsAsrptUser> loadAsrUser(int paramInt);

	public FpsAsrptUser loadAsrUser(int paramInt, String paramString);


	public String softDeleteLead(AsrDeleteLead inv);

	List<Integer> getFidsForAsr(String npi);

	List<FpsUser> getOpenAMUser(String userId);


	public List<FpsAsrpt> searchAsrCases3(BaseRequest request, int maxResults, int startAt);

	public int searchAsrCasesCount(BaseRequest request);

	public FpsAlert findHistoricAlert(int modelId, String npi, Date convertDateStringToString);

	public List<FpsUser> getOpenAMUsersByRoleOrAttribute(String roleAttr);

	public List<FpsUser> getOpenAMUsersByRoleOrAttribute(String role, String rqstrCntrctrCd);

	Integer findAsrIdBySubjId(String subjId);
	Integer findMdcdAsrIdBySubjId(String subjId);

	List<FpsModel> loadModels(boolean activeOnly);

	FpsAlert findHistoricAlert(String modelId, String npi, Date alertDt);

	List<FpsUser> getOpenAMGroupByUser(String userId, String groupId);

	List<VwFpsAsrptIdXwalkSmry> searchAsrCasesProviderAnalysis(AsrSearchParameter request);

	public Set<Object> verifyAsrs(List<Object> asrptIds);


	FpsPrvdrAnlys findPrvdrAnylsByAsrId(Integer asrId);
	FpsAsrptSummaryAsrsMdcd findMdcdSummaryByAsrId(Integer asrId);

	FpsPrvdrAnlys findPrvdrAnlysBySubjId(String subjId);

	Set<Object> verifyAsrs(List<Object> asrptIds, boolean returnMissing);

	List<FpsModel> loadAllModels();
	List<FpsModelMdcd> loadAllModelsMdcd();

	List<FpsUser> getOktaGroupByUser(String userId, String groupId);

	List<FpsUser> getOktaUser(String userId);
	FpsUser getSingleOktaUser(String userId);

	List<FpsUser> getOktaGroupMembership(String groupId);

	OktaGroup getOktaGroupIdFromName(String groupName);
	
	public <T> void  saveBatch(List<T> o);

	public FpsAsrptInvstgtn loadInvestigation(String ucmRecordID, Integer asrptId);

	public void deleteAdminAction(int asrptInvstgtnId, String parentRecord);

	Set<Object> verifyMdcdAsrs(List<Object> asrptIds);

	Set<Object> verifyMdcdAsrs(List<Object> asrptIds, boolean returnMissing);

	List<VwFpsAsrptIdXwalkSmry> searchAsrCasesMedicaid(AsrSearchParameter request);

	FpsAsrptMdcd findMdcdAsrBySubjId(String subjId);

	public FpsAsrptMdcd findMdcdAsrByAsrId(int parseInt);

	
	void insertMdcdAsrHistory(String userId, String superId, Integer invId, Integer asrId, Double riskScore,
			String text, String version, String action);

	public FpsAsrptUserAdminvActn findAdminAction(int asrptInvstgtnId, String adminActionId);

	public FpsAsrptUserActvty findActivity(int asrptInvstgtnId, String activityId);

	FpsAsrptInvstgtn loadInvestigationByNpi(String ucmRecordID, String npi, boolean isMdcd);

	

	
	


}
