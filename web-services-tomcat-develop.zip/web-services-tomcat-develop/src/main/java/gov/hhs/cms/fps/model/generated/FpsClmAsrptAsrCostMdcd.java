package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="FPS_ALERTED_CLM_LINE_ASR_KEY_VW_MDCD")
public class FpsClmAsrptAsrCostMdcd implements Serializable {
	
	private Integer asrptId;
	
	private String subjId;
	private Integer fpsClmId;
	
	private Integer fpsClmLineId;
	
	@Id
	@Column(name="ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	@Column(name="SUBJ_ID")	
	public String getSubjId() {
		return subjId;
	}
	public void setSubjId(String subjId) {
		this.subjId = subjId;
	}
	@Id
	@Column(name="FPS_CLM_ID")	
	public Integer getFpsClmId() {
		return fpsClmId;
	}
	public void setFpsClmId(Integer fpsClmId) {
		this.fpsClmId = fpsClmId;
	}
	@Id
	@Column(name="FPS_CLM_LINE_ID")
	public Integer getFpsClmLineId() {
		return fpsClmLineId;
	}
	public void setFpsClmLineId(Integer fpsClmLineId) {
		this.fpsClmLineId = fpsClmLineId;
	}
}
