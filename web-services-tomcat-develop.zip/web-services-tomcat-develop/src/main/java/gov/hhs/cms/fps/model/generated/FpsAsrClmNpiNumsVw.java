package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import gov.hhs.cms.fps.util.FpsEnums.PartDEnum;


/**
 * The persistent class for the VW_FPS_PTD_ASR_SUMMARY database table.
 * 
 */
@Entity
@Table(name="FPS_ASR_CLM_NPI_NUMS_VW")
public class FpsAsrClmNpiNumsVw implements Serializable {
	private static final long serialVersionUID = 1L;
	private int asrptId;
	private String prvdrNpiNum;
	private String prvdrDrvdNpiName;
	private String role;
	private FpsAsrpt fpsAsrpt;

	public FpsAsrClmNpiNumsVw() {
	}

	@Id
	@Column(name="ASRPT_ID")
	public int getAsrptId() {
		return this.asrptId;
	}

	public void setAsrptId(int asrptId) {
		this.asrptId = asrptId;
	}



	@ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="ASRPT_ID", referencedColumnName="ASRPT_ID", updatable=false, insertable=false)
	public FpsAsrpt getFpsAsrpt() {
		return fpsAsrpt;
	}


	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
		this.fpsAsrpt = fpsAsrpt;
	}

	
	@Id
	@Column(name="PRVDR_NPI_NUM")
	public String getPrvdrNpiNum() {
		return prvdrNpiNum;
	}

	public void setPrvdrNpiNum(String prvdrNpiNum) {
		this.prvdrNpiNum = prvdrNpiNum;
	}
	@Column(name="PRVDR_DRVD_NPI_NAME")
	public String getPrvdrDrvdNpiName() {
		return prvdrDrvdNpiName;
	}

	public void setPrvdrDrvdNpiName(String prvdrDrvdNpiName) {
		this.prvdrDrvdNpiName = prvdrDrvdNpiName;
	}
	@Id
	@Column(name="ROLE")
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}