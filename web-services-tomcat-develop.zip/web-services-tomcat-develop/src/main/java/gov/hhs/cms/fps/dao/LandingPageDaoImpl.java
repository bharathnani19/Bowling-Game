package gov.hhs.cms.fps.dao;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gov.hhs.cms.fps.model.AsrManagementReportItem;
import gov.hhs.cms.fps.model.FpsSystemStatus;
import gov.hhs.cms.fps.model.generated.FpsPlndSysOutge;
import gov.hhs.cms.fps.model.generated.FpsPrtlAcsRqst;
import gov.hhs.cms.fps.model.generated.FpsRptAcsMtrxVw;
import gov.hhs.cms.fps.model.generated.FpsSysMsg;
import gov.hhs.cms.fps.util.FpsDomainObjectConverter;

@Repository("landingPageDao")
public class LandingPageDaoImpl extends BaseDao<Integer, Object> implements LandingPageDao {
	private static Logger logger = Logger.getLogger(LandingPageDaoImpl.class.getName());
	@Value("${tableau.env}")
	private String tableauServerEnv;
	

	@Override
	public List<FpsPlndSysOutge> loadSystemOutages() {
		// TODO Auto-generated method stub
		Criteria c = getCurrentSession().createCriteria(FpsPlndSysOutge.class);
		Calendar cal = Calendar.getInstance();

		c.add(Restrictions.ge("outgeEndDt", cal.getTime()));
		return c.list();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.hhs.cms.fps.dao.FpsServiceDao#addUpdatePlannedSystemOutage(gov.hhs.
	 * cms.fps.model.dao.FpsPlannedSystemOutage)
	 */
	@Override
	public FpsPlndSysOutge addUpdatePlannedSystemOutage(FpsPlndSysOutge outage) {
		getCurrentSession().saveOrUpdate(outage);
		return outage;

	}

	@Override
	public void deleteSystemOutage(int sysOutageId) {
		FpsPlndSysOutge outage = new FpsPlndSysOutge();
		outage.setPlndSysOutgeId(sysOutageId);
		getCurrentSession().delete(outage);

	}

	@Override
	public List<FpsSysMsg> loadSystemMessages() {

		return loadSystemMessages(false);

	}

	@Override
	public List<FpsSysMsg> loadSystemMessages(boolean admin) {

		Criteria c = getCurrentSession().createCriteria(FpsSysMsg.class);

		if (admin) {
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.DAY_OF_YEAR, -90);
			c.add(Restrictions.ge("audtInsrtTs", cal.getTime()));

		} else {
			// only show messages within the bounds of that message.
			Calendar cal = Calendar.getInstance();
			c.add(Restrictions.ge("sysEndDt", cal.getTime()));
			c.add(Restrictions.le("sysStrtDt", cal.getTime()));
		}
		c.addOrder(Order.desc("audtInsrtTs"));
		return c.list();

	}

	@Override
	public Integer getSystemMessageNewCount(String userId) {

		int retval = 0;
		String sql = "select count(*) from  fps2.fps_sys_msg m where SYS_END_TS >= localtimestamp and SYS_STRT_TS <= localtimestamp and date(audt_insrt_ts) >= current_date - interval '7 days' "
				+ "and not exists (select 1 from fps2.fps_portal_actvty_hstry h where h.audt_insrt_id = :userId and h.audt_insrt_ts > m.audt_insrt_ts and ACTVTY_PAGE_NAME = 'VIEWSYSMSG') "
				+ "and not exists (select 1 from fps2.fps_portal_actvty_hstry h where h.audt_insrt_id = :userId and (h.audt_insrt_ts - interval '1 day') > m.audt_insrt_ts and ACTVTY_PAGE_NAME = 'LANDING') ";

		SQLQuery query = (SQLQuery) getCurrentSession().createSQLQuery(sql).setParameter("userId", userId);
		BigInteger retval2 = (BigInteger) query.uniqueResult();
		return retval2 != null ? retval2.intValue() : 0;
	}

	@Override
	public List<FpsPrtlAcsRqst> loadUserAccessRequests(String zone) {
		Criteria c = getCurrentSession().createCriteria(FpsPrtlAcsRqst.class, "req");
		// Calendar cal = Calendar.getInstance();

		c.add(Restrictions.eq("rqstrCntrctrCd", zone));
		return c.list();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gov.hhs.cms.fps.dao.FpsServiceDao#addUpdateSystemMessage(gov.hhs.cms.fps.
	 * model.dao.FpsSystemMessage)
	 */
	@Override
	public FpsSysMsg addUpdateSystemMessage(FpsSysMsg sysMessage) {
		getCurrentSession().saveOrUpdate(sysMessage);
		return sysMessage;

	}

	@Override
	public void deleteSystemMessage(int sysMsgId) {
		FpsSysMsg msg = new FpsSysMsg();
		msg.setSysMsgId(sysMsgId);
		getCurrentSession().delete(msg);

	}

	@Transactional
	@Override
	public List<AsrManagementReportItem> loadAsrManagementReport(String userId, String userZone, String role) {
		logger.fine("ASR report for " + userId + ", " + userZone);
		// admin sees all
		// inquiry only - zasr, zwl
		// priority sup - inquiry only links plus: zwlSuspect, highRiskUn,
		// asrWithCpiPriority, asrPriorityNoUcm,
		// juridsidction asrs asrNoUcm
		// mac - MACNOUCM, MACASR30,MACASR30NOUCM,MACNOUCMCURRENT
		// mac + RRB SMAC zone - mac links plus MACRRB
		boolean isMac = "MAC".equalsIgnoreCase(role);
		boolean isAdmin = "admin".equalsIgnoreCase(role);
		boolean isRrb = isMac && "RRB SMAC".equals(userZone);
		boolean isMedic = "MEDIC".equals(userZone);
		List<AsrManagementReportItem> items = new ArrayList<AsrManagementReportItem>();
		HashMap<String, Integer> links = FpsDomainObjectConverter.buildDefaultAsrManagementMap(isMac, isAdmin,
				"prioritizesup".equalsIgnoreCase(role), isRrb, isMedic);

		if (StringUtils.isBlank(userZone)) {
			userZone = "NONE";
		}
		List<Object[]> upicRows = new ArrayList<Object[]>();
		List<Object[]> macRows = new ArrayList<Object[]>();
		if (!isMac) {
			String sql = "with x as ( select a.asrpt_id, d.cntrctr_cd, alert.alert_creat_dt, a.asrpt_Risk_Scre_Num, a.asrpt_creat_dt from fps_asrpt a "
					+ "inner join fps_asrpt_alert_asctn aa on a.asrpt_id = aa.asrpt_id "
					+ "inner join fps_alert alert on aa.alert_id = alert.alert_id "
					+ "inner join fps_prvdr_zn_asctn d on a.subj_id= d.prvdr_npi_num "
					+ "where alert.alert_creat_dt >= localtimestamp - interval '180 days'), "
					+ "inv as (select b.asrpt_invstgtn_id, b.asrpt_id, b.stus_cd, c.asgned_cntrctr, b.extrnl_case_id from FPS_ASRPT_INVSTGTN b "
					+ "inner join FPS_ASRPT_USER_INVSTGTN c on c.asrpt_invstgtn_id = b.asrpt_invstgtn_id "
					+ "where b.rec_chg_ind not in ('R','D') ) " + "select count(cnt), label from ( ";
			sql += "select " + "distinct x.asrpt_id cnt,'zasr' label " + "from x " + "where x.cntrctr_cd = :userZone "
					+ " and x.alert_creat_dt >= localtimestamp - interval '180 days' " + "union " + "all " + "select "
					+ "distinct x.asrpt_id cnt,'zwl' label " + "from x "
					+ "inner join inv on x.asrpt_id = inv.asrpt_id "
					+ "inner join FPS_ASRPT_USER_RULNG d on d.asrpt_invstgtn_id = inv.asrpt_invstgtn_id "
					+ "where   d.CRNT_RULNG_CD != '1' " + "and d.CRNT_RULNG_CD != '-1' "
					+ "and inv.ASGNED_CNTRCTR = :userZone " + " and x.alert_creat_dt >= localtimestamp - interval '180 days' "
					+ "and inv.stus_cd = '11' ";
			if (isMedic || isAdmin) {
				sql += "union " + "all " + "select " + "distinct x.asrpt_id cnt,'MEDIC' label "
						+ "from x " +
				       " inner join fps_asrpt_stat_mat_Vw vw on x.asrpt_id = vw.asrpt_id and vw.type='CLAIM TYPE' and vw.value= 'D' "
						+ " where x.asrpt_id not in  (select asrpt_id from inv "
						+ "where x.asrpt_id = inv.asrpt_id  and inv.asgned_Cntrctr = :userZone "
						+ "   and inv.EXTRNL_CASE_ID is not null " + "   and inv.stus_cd = '11') ";
			}
			if (("prioritizesup".equalsIgnoreCase(role) && !isMedic) || isAdmin) {

				sql += "union " + "all " + "select " + "distinct x.asrpt_id cnt,'highRiskUn' label " + "from x "
						+ "where x.cntrctr_cd = :userZone " + "and (x.asrpt_Risk_Scre_Num > 0.5 ) "
						+ "and x.asrpt_id not in (select pr.asrpt_id from fps_asrpt_prrty pr where pr.cntrctr_cd = :userZone ) "
						+ " and x.alert_creat_dt >= localtimestamp - interval '180 days' " + "union " + "all " + "select "
						+ "distinct x.asrpt_id cnt,'zwlSuspect' label " + "from x "
						+ "inner join inv on x.asrpt_id = inv.asrpt_id "
						+ "inner join fpS_ASRPT_USER_RULNG d on d.asrpt_invstgtn_id = inv.asrpt_invstgtn_id "
						+ "where ASGNED_CNTRCTR = :userZone " + "and d.CRNT_RULNG_CD = '6' "
						+ " and x.alert_creat_dt >= localtimestamp - interval '180 days' " + "union all " + "select "
						+ "distinct x.asrpt_id cnt,'asrNoUcm' label " + "from x "
						+ "left join inv on x.asrpt_id = inv.asrpt_id " + "where x.cntrctr_cd = :userZone "
						+ "and inv.EXTRNL_CASE_ID is null " + " and x.alert_creat_dt >= localtimestamp - interval '180 days' "
						+ "union " + "all " + "select " + "distinct x.asrpt_id cnt,'ASRNOUCM30' label " + "from x "
						+ "where x.cntrctr_cd = :userZone and x.asrpt_id not in (select asrpt_id from inv "
						+ "where x.asrpt_id = inv.asrpt_id  and inv.asgned_Cntrctr = :userZone "
						+ "   and inv.EXTRNL_CASE_ID is not null " + "   and inv.stus_cd = '11') " + "and " + "( "
						+ "   x.asrpt_creat_dt >= localtimestamp - interval '30 days' or x.alert_creat_dt >= localtimestamp - interval '30 days' "
						+ ") " + "union " + "all " + "select " + "distinct x.asrpt_id cnt,'ASRUCMNOPRIORITY' label "
						+ "from x " + "inner join inv on inv.asrpt_id = x.asrpt_id "
						+ "left join fps_asrpt_prrty p on x.asrpt_id= p.asrpt_id " + "and p.cntrctr_cd = :userZone "
						+ "where x.cntrctr_cd = :userZone " + " and inv.asgned_cntrctr = :userZone "
						+ "and inv.stus_cd = '11' " + "and p.asrpt_id is null "
						+ " and x.alert_creat_dt >= localtimestamp - interval '180 days' " + "union " + "all " + "select "
						+ "distinct x.asrpt_id cnt,'ASR30' label " + "from x " + "where x.cntrctr_cd = :userZone "
						+ "and " + "( "
						+ "   x.asrpt_creat_dt >= localtimestamp - interval '30 days' or x.alert_creat_dt >= localtimestamp - interval '30 days' "
						+ ") " + "union " + "all " + "select " + "distinct x.asrpt_id cnt,'OTHERZONEWORKLOAD' label "
						+ "from x " + "inner join inv on x.asrpt_id = inv.asrpt_id "
						+ "where    inv.ASGNED_CNTRCTR != :userZone " + "and inv.stus_cd = '11' "
						+ " and  x.cntrctr_cd = :userZone " + " and x.alert_creat_dt >= localtimestamp - interval '180 days' "
						+ "union " + "all " + "select " + "distinct x.asrpt_id cnt,'asrPriorityNoUcm' label "
						+ "from x " + "left join inv on x.asrpt_id = inv.asrpt_id "
						+ "inner join fps_asrpt_prrty p on x.asrpt_id = p.asrpt_id "
						+ "where x.cntrctr_cd = :userZone and p.cntrctr_cd = :userZone "
						+ "and inv.EXTRNL_CASE_ID is null " + " and x.alert_creat_dt >= localtimestamp - interval '180 days' ";

			}

			sql += ") group by label  ";
			SQLQuery query = (SQLQuery) getCurrentSession().createSQLQuery(sql).setParameter("userZone", userZone);

			// .setParameter("userId", userId);

			upicRows = query.list();

		}

		if (isMac || isAdmin) {
			String sql2 = "with macasr as (select a.asrpt_id, d.MAC_JURISDICTION, alert.alert_creat_dt, a.asrpt_Risk_Scre_Num, a.asrpt_creat_dt, alert_stus_cd  from fps_asrpt a "
					+ "inner join fps_asrpt_mac_asctn_vw d on a.asrpt_id= d.asrpt_id "
					+ "inner join fps_asrpt_alert_asctn aa on a.asrpt_id = aa.asrpt_id "
					+ "inner join fps_alert alert on aa.alert_id = alert.alert_id "
					+ "where alert.alert_creat_dt >= localtimestamp - interval '180 days') "
					+ "select count(cnt), label from ( ";

			sql2 += "select " + "distinct macasr.asrpt_id cnt,'MACNOUCM' label " + "from macasr "
					+ "where macasr.MAC_JURISDICTION = :userZone " + "and (macasr.asrpt_Risk_Scre_Num <= 0.5 ) "
					+ "AND macasr.asrpt_id not in " + "( " + "   select " + "   innerInv.asrpt_id "
					+ "   from FPS_ASRPT_INVSTGTN innerInv " + "   where innerInv.rec_chg_ind not in ('R','D') "
					+ "   and innerInv.stus_cd = '11' " + "   and innerInv.EXTRNL_CASE_ID is not null " + ") "
					+ "union " + "all " + "select distinct macasr.asrpt_id cnt,'MACNOUCMCURRENT' label "
					+ "from macasr " + "where macasr.MAC_JURISDICTION = :userZone "
					+ "and (macasr.asrpt_Risk_Scre_Num <= 0.5 ) " + "AND macasr.asrpt_id not in " + "( " + "   select "
					+ "   innerInv.asrpt_id " + "   from FPS_ASRPT_INVSTGTN innerInv "
					+ "   where innerInv.rec_chg_ind not in ('R','D') " + "   and innerInv.stus_cd = '11' "
					+ "   and innerInv.EXTRNL_CASE_ID is not null " + ") " + "AND macasr.alert_stus_cd = '12' "
					+ "union " + "all " + "select " + "distinct macasr.asrpt_id cnt,'MACASR30' label " + "from macasr "
					+ "where macasr.MAC_JURISDICTION = :userZone " + "and " + "( "
					+ "   macasr.asrpt_creat_dt >= localtimestamp - interval '30 days' or macasr.alert_creat_dt >= localtimestamp - interval '30 days' "
					+ ") " + "and (macasr.asrpt_Risk_Scre_Num <= 0.5 ) " + "union " + "all " + "select "
					+ "distinct macasr.asrpt_id cnt,'MACASR30NOUCM' label " + "from macasr "
					+ "where macasr.MAC_JURISDICTION = :userZone " + "and (macasr.asrpt_Risk_Scre_Num <= 0.5 ) "
					+ "AND macasr.asrpt_id not in " + "( " + "   select " + "   innerInv.asrpt_id "
					+ "   from FPS_ASRPT_INVSTGTN innerInv " + "   where innerInv.rec_chg_ind not in ('R','D') "
					+ "   and innerInv.stus_cd = '11' " + "   and innerInv.EXTRNL_CASE_ID is not null " + ") " + "and "
					+ "( "
					+ "   macasr.asrpt_creat_dt >= localtimestamp - interval '30 days' or macasr.alert_creat_dt >= localtimestamp - interval '30 days' "
					+ ") ";
			if ("RRB SMAC".equals(userZone) || isAdmin) {
				sql2 += " union all " + "select " + "distinct macasr.asrpt_id cnt,'MACRRB' label " + "from macasr "
						+ "inner join FPS_ASRPT_BENE_RRB_VW b on macasr.asrpt_id = b.asrpt_id "
						+ "where macasr.MAC_JURISDICTION = :userZone " + "AND macasr.asrpt_id not in " + "( "
						+ "   select " + "   innerInv.asrpt_id " + "   from FPS_ASRPT_INVSTGTN innerInv "
						+ "inner join FPS_ASRPT_USER_INVSTGTN innerUserInv on innerInv.asrpt_invstgtn_id = innerUserInv.asrpt_invstgtn_id "
						+ "   where innerInv.rec_chg_ind not in ('R','D') " + "   and innerInv.stus_cd = '11' "
						+ "   and innerInv.EXTRNL_CASE_ID is not null "
						+ " and innerUserInv.ASGNED_CNTRCTR = :userZone " + ") and macasr.alert_Creat_dt >= localtimestamp -30 days ";
			}
			sql2 += ") group by label  ";
//			logger.info(sql2);
			SQLQuery query2 = (SQLQuery) getCurrentSession().createSQLQuery(sql2).setParameter("userZone", userZone);

			// .setParameter("userId", userId);

			macRows = query2.list();

		}
		List<Object[]> allRows = ListUtils.union(upicRows, macRows);
//		logger.info("allrows size " + allRows.size());
//		logger.info("upicRows size " + upicRows.size());
//		logger.info("macRows size " + macRows.size());
		for (String key : links.keySet()) {
//			logger.info("key " + key);

			Integer count = links.get(key);
			AsrManagementReportItem item = new AsrManagementReportItem();
			item.setCount(count);
			item.setLabel(key);
			for (Object[] row : allRows) {
				String label = row[1].toString();
				if (label.equals(key)) {
					item.setCount(Integer.parseInt(row[0].toString()));
				}
			}
			items.add(item);
		}
		return items;
	}

	@Transactional
	@Override
	public List<FpsSystemStatus> loadSystemStatus() {
		List<FpsSystemStatus> items = new ArrayList<FpsSystemStatus>();
		SQLQuery query = getCurrentSession().createSQLQuery(
				// "select distinct model_name, max(model_run_dt) from fps_model
				// a inner join fps_rpt_card_dtl b on a.MODEL_BUSNS_ID =
				// b.MODEL_BUSNS_ID group by model_name order by model_name");
				"select v.model_name, max_run_dt, model_desc, MODEL_GUIDANCE_DOC_FILE_PATH from fps2.FPS_MAX_MODEL_RUN_DT_VW v inner join fps2.fps_model m on v.model_busns_id = m.model_busns_id order by model_name");

		List<Object[]> rows = query.list();
		for (Object[] row : rows) {
			FpsSystemStatus item = new FpsSystemStatus();
			item.setModelName(row[0].toString());
			item.setLastProcessedTime(FpsDomainObjectConverter.convertDateToShortString((Date) row[1]));

			items.add(item);
		}
		return items;
	}

	@Override
	public List<FpsRptAcsMtrxVw> loadReportLinks(String userId, String userZone, String role, Integer[] ids, boolean isVmReports){
		List<String> cmsZones = Arrays.asList(new String[] {"CMS", "GDIT", "Deloitte", "NGC", "Peraton", "SMRC", "DOJ"});
		List<String> searchRoles = new ArrayList<>();
		// if not a UPIC or MAC, search on zone
		if (cmsZones.contains(userZone)) {
			searchRoles.add(userZone.toUpperCase());
		}
		searchRoles.add(role.toUpperCase());
		
		if (isVmReports) {
			searchRoles.add("VM_REPORTS");
		}
		String sql = "from FpsRptAcsMtrxVw where upper(openamRole) in (:role) and upper(serverNm)= :server ";
		if (ids != null) {
			sql += " and rptId in (:ids) ";
		} else {
			sql += " and defaultFavoriteInd = 'Y' ";
		}
		sql += " order by rptNm asc";
//		String roleZone =  isVmReports ? "VM_Reports"  : cmsRoles.contains(userZone) ?  userZone :role != null ? role : "NONE";
		logger.fine("using roleZone of " + StringUtils.join(searchRoles, ", "));
		Query q1 = getCurrentSession().createQuery(sql).setParameterList("role", searchRoles).setString("server",
				tableauServerEnv.toUpperCase());
		if (ids != null) {
			q1.setParameterList("ids", ids);
		}
		List<FpsRptAcsMtrxVw> list = q1.list();
		if (list != null && list.size() > 0) {
			list = list.stream().filter(FpsDomainObjectConverter.distinctByKey(FpsRptAcsMtrxVw::getWorkbookNm)).collect(Collectors.toList());

		}
		return list;
	}

	@Override
	public List<FpsRptAcsMtrxVw> loadAllReportLinks(String userId, String userZone, String role, boolean isVmReports) {
		List<String> cmsZones = Arrays.asList(new String[] {"CMS", "GDIT", "Deloitte", "NGC", "Peraton", "SMRC", "DOJ"});
		List<String> searchRoles = new ArrayList<>();
		// if not a UPIC or MAC, search on zone
		if (cmsZones.contains(userZone)) {
			searchRoles.add(userZone.toUpperCase());
		}
		searchRoles.add(role.toUpperCase());
		
		if (isVmReports) {
			searchRoles.add("VM_REPORTS");
		}		
		String sql = "from FpsRptAcsMtrxVw where upper(openamRole) in (:role) and upper(serverNm)= :server ";
		List<FpsRptAcsMtrxVw> reports = new ArrayList<>();
		sql += " order by workbookNm asc";
		reports = getCurrentSession().createQuery(sql).setParameterList("role", searchRoles).setString("server",
				tableauServerEnv.toUpperCase()).list();
		
		if (reports != null && reports.size() > 0) {
			reports = reports.stream().filter(FpsDomainObjectConverter.distinctByKey(FpsRptAcsMtrxVw::getWorkbookNm)).collect(Collectors.toList());

		}
		return reports;
	}



}
