package gov.hhs.cms.fps.dao;

import java.util.List;

import gov.hhs.cms.fps.model.generated.FpsAlert;
import gov.hhs.cms.fps.model.generated.FpsAlertMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrpt;
import gov.hhs.cms.fps.model.generated.FpsRptCardDtl;
import gov.hhs.cms.fps.model.generated.FpsRptCardRskSnaDtl;
import gov.hhs.cms.fps.model.ucm.CaseDetail;
import gov.hhs.cms.fps.model.ucm.Claims;
import gov.hhs.cms.fps.model.ucm.PartDClaims;

public interface FpsApiDao {
  FpsAsrpt getAsrBySection(Integer paramInteger, String paramString);
  
  void saveCaseEvent(CaseDetail paramCaseDetail);
  
  List<Claims> getASRClaims(Integer paramInteger);
  
  List<PartDClaims> getASRClaimsPtd(Integer paramInteger);
  
  List<PartDClaims> getPtdReportCardClaims(Integer paramInteger1, Integer paramInteger2);
  
  List<Claims> getReportCardClaims(Integer paramInteger);
  
  List<FpsRptCardDtl> getReportCard(Integer paramInteger);
  
  List<FpsRptCardRskSnaDtl> getReportCardSna(Integer paramInteger);
  
  List<Claims> getReportCardClaimsAttr(Integer paramInteger1, Integer paramInteger2);
  
  List<PartDClaims> getPtdReportCardClaims(Integer paramInteger);
  
  FpsAlert getAlertFromAlertId(Integer paramInteger);
  FpsAlertMdcd getMdcdAlertFromAlertId(Integer paramInteger);
  
  Integer getAsrptIdFromAlertId(Integer alertId);
  Integer getMdcdAsrptIdFromAlertId(Integer alertId);

  String getModelTypeFromAlert(Integer alertId);
  String getMdcdModelTypeFromAlert(Integer alertId);

}
