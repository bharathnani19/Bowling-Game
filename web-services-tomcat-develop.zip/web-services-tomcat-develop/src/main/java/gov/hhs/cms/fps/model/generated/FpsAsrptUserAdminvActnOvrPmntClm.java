package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.BatchSize;
@Entity
@Table(name = "FPS_ASRPT_USER_ADMINV_ACTN_OVRPYMT_CLM_TYPE_DTL")
@BatchSize(size = 100)
public class FpsAsrptUserAdminvActnOvrPmntClm implements Serializable {
	private Integer asrptUserAdminvActnOvrpmntClmId;
	private String clmType;
	private String mdclyRvwd;
	private String smplType;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private String audtUpdtId;
	private Date audtUpdtTs;

	private FpsAsrptUserAdminvActnOvrPmnt fpsAsrptUserAdminvActnOvrPmnt;
	@Column(name = "CLM_TYPE")

	public String getClmType() {
		return clmType;
	}
	public void setClmType(String clmType) {
		this.clmType = clmType;
	}
	@Column(name = "MDCLY_RVWD")

	public String getMdclyRvwd() {
		return mdclyRvwd;
	}
	public void setMdclyRvwd(String mdclyRvwd) {
		this.mdclyRvwd = mdclyRvwd;
	}
	@Column(name = "SMPL_TYPE")

	public String getSmplType() {
		return smplType;
	}
	public void setSmplType(String smplType) {
		this.smplType = smplType;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_USER_ADMINV_ACTN_OVRPYMT_DTL_ID")
	public FpsAsrptUserAdminvActnOvrPmnt getFpsAsrptUserAdminvActnOvrPmnt() {
		return fpsAsrptUserAdminvActnOvrPmnt;
	}
	public void setFpsAsrptUserAdminvActnOvrPmnt(FpsAsrptUserAdminvActnOvrPmnt fpsAsrptUserAdminvActnOvrPmnt) {
		this.fpsAsrptUserAdminvActnOvrPmnt = fpsAsrptUserAdminvActnOvrPmnt;
	}
	@Column(name = "AUDT_INSRT_ID", nullable = false, length = 128)
	public String getAudtInsrtId() {
		return this.audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_INSRT_TS", nullable = false, length = 26)
	public Date getAudtInsrtTs() {
		return this.audtInsrtTs;
	}

	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	@Column(name = "AUDT_UPDT_ID", length = 128)
	public String getAudtUpdtId() {
		return this.audtUpdtId;
	}

	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_UPDT_TS", length = 26)
	public Date getAudtUpdtTs() {
		return this.audtUpdtTs;
	}

	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
	@Id
	@SequenceGenerator(name="asrpt_user_adminv_actn_ovrpymt_clm_type_dtl_id_seq",  sequenceName = "asrpt_user_adminv_actn_ovrpymt_clm_type_dtl_id_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "asrpt_user_adminv_actn_ovrpymt_clm_type_dtl_id_seq")

	@Column(name = "ASRPT_USER_ADMINV_ACTN_OVRPYMT_CLM_TYPE_DTL_ID")

	public Integer getAsrptUserAdminvActnOvrpmntClmId() {
		return asrptUserAdminvActnOvrpmntClmId;
	}
	public void setAsrptUserAdminvActnOvrpmntClmId(Integer asrptUserAdminvActnOvrpmntClmId) {
		this.asrptUserAdminvActnOvrpmntClmId = asrptUserAdminvActnOvrpmntClmId;
	}

}
