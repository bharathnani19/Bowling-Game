/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

// TODO: Auto-generated Javadoc
/**
 * The Class TestBean.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)

public class TestBean implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6342546884696040968L;
	
	/** The host. */
	private String host;
	
	/** The service. */
	private String service;
	
	/** The post data. */
	private String postData;
	
	/**
	 * Gets the host.
	 *
	 * @return the host
	 */
	public String getHost() {
		return host;
	}
	
	/**
	 * Sets the host.
	 *
	 * @param host the new host
	 */
	public void setHost(String host) {
		this.host = host;
	}
	
	/**
	 * Gets the service.
	 *
	 * @return the service
	 */
	public String getService() {
		return service;
	}
	
	/**
	 * Sets the service.
	 *
	 * @param service the new service
	 */
	public void setService(String service) {
		this.service = service;
	}
	
	/**
	 * Gets the post data.
	 *
	 * @return the post data
	 */
	public String getPostData() {
		return postData;
	}
	
	/**
	 * Sets the post data.
	 *
	 * @param postData the new post data
	 */
	public void setPostData(String postData) {
		this.postData = postData;
	}
}
