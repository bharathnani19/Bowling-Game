package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;

public class CustomAsrResponse implements Serializable {
	private List<Integer> existingAsrs;
	private List<WatchlistItem> watchlistItems;
	
	public List<Integer> getExistingAsrs() {
		return existingAsrs;
	}
	public void setExistingAsrs(List<Integer> existingAsrs) {
		this.existingAsrs = existingAsrs;
	}
	public List<WatchlistItem> getWatchlistItems() {
		return watchlistItems;
	}
	public void setWatchlistItems(List<WatchlistItem> watchlistItems) {
		this.watchlistItems = watchlistItems;
	}

}
