package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrInvestigation implements Serializable {

	private int asrptId;
	private String bpmProcNum;
	private String taskId;
	private String userId;
	private String assignedUserId;
	private String userRole;
	private int investId;
	private String ucmCaseId;
	private String assignedZone;
	private String subjId;
	private String ucmStatus;
	private String ucmState;
	private String ucmCaseType;
	private Date ucmCaseCloseDt;
	private String ucmCaseCloseRsn;
	private Date ucmCaseDt;
	// reopened data
	private String ucmCaseReOpenedRationale;
	private Date ucmCaseReOpenedDate;
	private List<FpsGenericKeyValue> assignees;
	private String eventTrigger;
	private Date updateDt;
	private String subStatus;
	private String programType;
	private String claimType;
	private String stateCd;

	public int getAsrptId() {
		return asrptId;
	}

	public void setAsrptId(int asrptId) {
		this.asrptId = asrptId;
	}

	public String getBpmProcNum() {
		return bpmProcNum;
	}

	public void setBpmProcNum(String bpmProcNum) {
		this.bpmProcNum = bpmProcNum;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public int getInvestId() {
		return investId;
	}

	public void setInvestId(int investId) {
		this.investId = investId;
	}

	public String getAssignedUserId() {
		return assignedUserId;
	}

	public void setAssignedUserId(String assignedUserId) {
		this.assignedUserId = assignedUserId;
	}

	public String getUcmCaseId() {
		return ucmCaseId;
	}

	public void setUcmCaseId(String ucmCaseId) {
		this.ucmCaseId = ucmCaseId;
	}

	public String getAssignedZone() {
		return assignedZone;
	}

	public void setAssignedZone(String assignedZone) {
		this.assignedZone = assignedZone;
	}

	public String getSubjId() {
		return subjId;
	}

	public void setSubjId(String subjId) {
		this.subjId = subjId;
	}

	public String getUcmStatus() {
		return ucmStatus;
	}

	public void setUcmStatus(String ucmStatus) {
		this.ucmStatus = ucmStatus;
	}

	public String getUcmState() {
		return ucmState;
	}

	public void setUcmState(String ucmState) {
		this.ucmState = ucmState;
	}

	public String getUcmCaseType() {
		return ucmCaseType;
	}

	public void setUcmCaseType(String ucmCaseType) {
		this.ucmCaseType = ucmCaseType;
	}

	public Date getUcmCaseDt() {
		return ucmCaseDt;
	}

	public void setUcmCaseDt(Date ucmCaseDt) {
		this.ucmCaseDt = ucmCaseDt;
	}

	public Date getUcmCaseCloseDt() {
		return ucmCaseCloseDt;
	}

	public void setUcmCaseCloseDt(Date ucmCaseCloseDt) {
		this.ucmCaseCloseDt = ucmCaseCloseDt;
	}

	public String getUcmCaseCloseRsn() {
		return ucmCaseCloseRsn;
	}

	public void setUcmCaseCloseRsn(String ucmCaseCloseRsn) {
		this.ucmCaseCloseRsn = ucmCaseCloseRsn;
	}

	public String getUcmCaseReOpenedRationale() {
		return ucmCaseReOpenedRationale;
	}

	public void setUcmCaseReOpenedRationale(String ucmCaseReOpenedRationale) {
		this.ucmCaseReOpenedRationale = ucmCaseReOpenedRationale;
	}

	public Date getUcmCaseReOpenedDate() {
		return ucmCaseReOpenedDate;
	}

	public void setUcmCaseReOpenedDate(Date ucmCaseReOpenedDate) {
		this.ucmCaseReOpenedDate = ucmCaseReOpenedDate;
	}

	public List<FpsGenericKeyValue> getAssignees() {
		return assignees;
	}

	public void setAssignees(List<FpsGenericKeyValue> assignees) {
		this.assignees = assignees;
	}

	public String getEventTrigger() {
		return eventTrigger;
	}

	public void setEventTrigger(String eventTrigger) {
		this.eventTrigger = eventTrigger;
	}

	public Date getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}

	public String getSubStatus() {
		return subStatus;
	}

	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	public String getProgramType() {
		return programType;
	}

	public void setProgramType(String programType) {
		this.programType = programType;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getStateCd() {
		return stateCd;
	}

	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}
}
