package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Id;

//@Field;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;
import org.joda.time.LocalDate;
import org.joda.time.Years;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import gov.hhs.cms.fps.util.FpsDomainObjectConverter;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailClaimLineItem implements Serializable, Comparable<AsrDetailClaimLineItem> {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1412523468117408784L;
	@Id
	//@Field("id")
	private String solrId = "123";
	//@Field("clm_cntrctr_num")
	private String macId;
	//@Field("fps_clm_id")
	private Integer claimId;

	//@Field("clm_id")
	private Integer alertClaimId;
	//@Field("clm_src_type")
	private String claimType;

	//@Field("cntrctr_desc")
	private String jurisdiction;
	//@Field("clm_sbmtr_id")
	private String submitterId;
	//@Field("asrpt_id")
	private String asrptId;
	
	private Integer modelId;
	
	private String modelBusnsId;
	@JsonIgnore
	private Integer alertId;
	
	private Integer attrSqncNum;
	//@Field("clm_rndrg_prvdr_npi_num")
	private String performNpi;
	//@Field("prvdr_mdcr_id")
	private String performPtan;
	//@Field("prvdr_drvd_npi_name")
	private String providerName;
	//@Field("clm_rndrg_fed_prvdr_spclty_cd")
	private String performSpecialty;
	//@Field("prvdr_mlg_plc_name")
	private String performPrvdrCity;
	//@Field("prvdr_mlg_state_cd")
	private String performPrvdrStateCd;
	//@Field("prvdr_mlg_zip_cd")
	private String providerZip;
	//@Field("clm_atndg_prvdr_npi_num")
	private String attendNpi;
	private String attendPtan;
	//@Field("clm_atndg_prvdr_npi_name")
	private String attendNpiName;
	//@Field("clm_atndg_fed_prvdr_spclty_cd")
	private String attendSpecialty;
	@JsonProperty("clm_hic_num")
	//@Field("clm_hic_num")
	private String beneId = "";
	@JsonProperty("bene_1st_name")
	//@Field("bene_1st_name")
	private String beneFirstName = "";
	@JsonProperty("bene_last_name")
	//@Field("bene_last_name")
	private String beneLastName = "";
	@JsonProperty("src_zip_plc_name")
	//@Field("src_zip_plc_name")
	private String beneCity = "";
	@JsonProperty("bene_line_1_adr")
	//@Field("bene_line_1_adr")
	private String beneAddress = "";
	@JsonProperty("bene_line_2_adr")
	//@Field("bene_line_2_adr")
	private String beneAddress2 = "";
	@JsonProperty("clm_bene_state_cd")
	//@Field("clm_bene_state_cd")
	private String beneStateCd = "";
	@JsonProperty("src_zip5_cd")
	//@Field("src_zip5_cd")
	private String beneZip = "";
	private Integer age;

	private String birthDt;

	private String deathDt;
	//@Field("bene_dual_mdcd_elgbl_stus_sw")
	private String dualInd = "";
	//@Field("clm_cntl_num")
	private String claimNum;
	//@Field("clm_line_num")
	private Integer claimLineNum;
	//@Field("clm_prcdr_1_cd")
	private String procedure;
	private Integer procTimeHrs;
	//@Field("clm_prncpl_dgns_cd")
	private String diagnosis;
	//@Field("hcpcs_1_mdfr_cd")
	private String mod1;
	//@Field("hcpcs_2_mdfr_cd")
	private String mod2;
	//@Field("hcpcs_3_mdfr_cd")
	private String mod3;
	//@Field("hcpcs_4_mdfr_cd")
	private String mod4;
	//@Field("hcpcs_5_mdfr_cd")
	private String mod5;
	
	private String lineFromDt;
	
	private String lineToDt;
	
	private String claimFromDt;
	
	private String claimToDt;
	////@Field("clm_rvw_ind")
	private String claimToReview;

	private String unitsService;
	private String lineSubmittedAmt;

	private String lineAllowedAmt;

	private String lineProviderPaidAmt;

	private String claimSubmittedAmt;

	private String claimAllowedAmt;

	private String claimProviderPaidAmt;
	//@Field("clm_sbmtr_id")
	private String tinEinOnClaim;
	//@Field("clm_bill_type_cd")
	private String billType;
	//@Field("clm_rev_cntr_cd")
	private String revenueCode;
	//@Field("bene_dual_mdcd_elgbl_stus_sw")
	private String crossoverInd;
	private String alertAttributeName;
	//@Field("clm_rfrg_prvdr_npi_num")
	private String referNpi;
	private String referPtan;
	//@Field("clm_rfrg_prvdr_npi_name")
	private String referNpiName;
	//@Field("clm_rndrg_fed_prvdr_spclty_cd")
	private String referNpiSpecialty;
	//@Field("clm_blg_prvdr_npi_num")
	private String billNpi;
	//@Field("clm_blg_prvdr_pin_num")
	private String billPtan;
	//@Field("clm_blg_prvdr_npi_name")
	private String billPrvdrName;
	//@Field("bene_phne_num")
	private String benePhone;
	//@Field("clm_mbi")
	@JsonProperty("clm_mbi")
	private String mbi;
	private String modelString;
	//@Field("clm_dgns_1_cd")
	private String diagnosis1;
	//@Field("clm_dgns_2_cd")
	private String diagnosis2;
	//@Field("clm_pos_cd")
	private String pos;
	
	private String admitDt;
	
	private String dischargeDt;

	private String paymentAmt;

	private String unitsAlwd;
	//@Field("dgns_drg_cd")
	private Integer drg;
	//@Field("clm_line_dgns_cd")
	private String lineDiagnosis;
	//@Field("clm_line_hcpcs_cd")
	private String hcpcsCd;
	//@Field("clm_line_rev_unit_num")
	private Integer lineRevUnitNum;
	
	//@Field("asr_key")
	@JsonIgnore
	private String asrKey;
	//@Field("alert_key")
	@JsonIgnore
	private String alertKey;
	//@Field("attribute_key")
	@JsonIgnore
	private String attributeKey;
	
	//@Field("linehcpcsdesc")
	private String hcpcsDesc;
	//@Field("diag1desc")
	private String diag1Desc;
	//@Field("diag2desc")
	private String diag2Desc;
	//@Field("hcpcs_cd_shrt_desc")
	private String prcdrDesc;
	//@Field("linediagdesc")
	private String diagDesc;
	
	
	// Solr-only
	@JsonIgnore
	private Date birthDtSolr = new Date();
	@JsonIgnore
	private Date deathDtSolr = new Date();

	@JsonIgnore
	private Integer unitsServiceSolr =1;

	@JsonIgnore
	private Double lineSubmittedAmtSolr = 1.0;

	@JsonIgnore
	private Double lineAllowedAmtSolr = 1.0;

	@JsonIgnore
	private Double lineProviderPaidAmtSolr = 1.0;

	@JsonIgnore
	private Double claimSubmittedAmtSolr = 1.0;

	@JsonIgnore
	private Double claimAllowedAmtSolr = 1.0;

	@JsonIgnore
	private Double claimProviderPaidAmtSolr = 1.0;
	@JsonIgnore
	private Double paymentAmtSolr = 1.0;
	@JsonIgnore
	private Integer unitsAlwdSolr=1;
	@JsonIgnore
	private Date lineFromDtSolr;
	@JsonIgnore
	private Date lineToDtSolr;
	@JsonIgnore
	private Date claimFromDtSolr;
	@JsonIgnore
	private Date claimToDtSolr;
	@JsonIgnore
	private Date admitDtSolr;
	@JsonIgnore
	private Date dischargeDtSolr;
	
	
	// Part D columns
	private Double clmLineBenePmtAmt;
	//@Field("clm_ctstrphc_cvrg_ind_cd")
	private String clmCtstrphcCvrgIndCd;
	//@Field("clm_ctstrphc_cvrg_ind_cd_desc")
	private String clmCtstrphcCvrgIndDesc;	
	//@Field("clm_uniq_id")
	private Long clmUniqId;
	//@Field("clm_cmpnd_cd")
	private String clmCmpndCd;
	//@Field("clm_cmpnd_cd_desc")
	private String clmCmpndDesc;
	private Double  clmLineCvrdPdAmt;
	//@Field("clm_line_days_suply_qty")
	private Integer clmLineDaysSuplyQty;
	//@Field("clm_daw_prod_slctn_cd")
	private String clmDawProdSlctnCd;
	//@Field("clm_daw_prod_slctn_cd_desc")
	private String clmDawProdSlctnDesc;	
	//@Field("clm_dspnsng_stus_cd")
	private String clmDspnsngStusCd;
	//@Field("clm_dspnsng_stus_cd_desc")
	private String clmDspnsngStusDesc;	
	//@Field("clm_drug_cvrg_stus_cd")
	private String clmDrugCvrgStusCd;
	//@Field("clm_drug_cvrg_stus_cd_desc")
	private String clmDrugCvrgStusDesc;
	//@Field("clm_line_rx_num")
	private String clmLineRxNum;
	//@Field("clm_line_rx_fill_num")
	private Integer clmLineRxFillNum;
	private Double clmLineLisAmt;
	//@Field("clm_line_ndc_cd")
	private String clmLineNdcCd;
	//@Field("clm_line_ndc_cd_desc")
	private String clmLineNdcDesc;	
	//@Field("clm_line_ndc_qty")
	private Double clmLineNdcQty;
	//@Field("clm_line_ndc_qty_qlfyr_cd")
	private String clmLineNdcQtyQlfyrCd;

	private Double clmLineNcvrdPdAmt;
	private Double clmLinePlroAmt;
	//@Field("clm_pd_dt")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy/MM/dd")
	private Date clmPdDt;
	//@Field("prvdr_prsbng_id_qlfyr_cd")
	private String prvdrPrsbngIdQlfyrCd;
	//@Field("prvdr_prsbng_id_qlfyr_cd_desc")
	private String prvdrPrsbngIdQlfyrDesc;	
	//@Field("clm_prsbng_prvdr_gnrc_id_num")
	private String clmPrsbngPrvdrGnrcIdNum;
	//@Field("clm_cntrct_of_rec_cntrct_num")
	private String clmCntrctOfRecCntrctNum;
	//@Field("clm_srvc_prvdr_gnrc_id_num")
	private String clmSrvcPrvdrGnrcIdNum;
	//@Field("clm_sbmtr_cntrct_num")
	private String clmSbmtrCntrctNum;
	//@Field("clm_sbmtr_cntrct_pbp_num")
	private String clmSbmtrCntrctPbpNum;
	private Double clmLineOthrTpPdAmt;
	private Double clmLineIngrdntCstAmt;
	private Double clmLineSlsTaxAmt;
	private Double clmLineSrvcCstAmt;
	//@Field("prvdr_srvc_id_qlfyr_cd")
	private String prvdrSrvcIdQlfyrCd;
	//@Field("prvdr_srvc_id_qlfyr_cd_desc")
	private String prvdrSrvcIdQlfyrDesc;	
	//@Field("clm_line_rx_srvc_rfrnc_num")
	private Integer clmLineRxSrvcRfrncNum;
	//@Field("prvdr_ncpdp_1_dspnsr_type_cd")
	private String prvdrNcpdp1DspnsrTypeCd;
	//@Field("prvdr_ncpdp_1_dspnsr_type_desc")
	private String prvdrNcpdp1DspnsrTypeDesc;
	//@Field("prvdr_ncpdp_2_dspnsr_type_cd")
	private String prvdrNcpdp2DspnsrTypeCd;
	//@Field("prvdr_ncpdp_2_dspnsr_type_desc")
	private String prvdrNcpdp2DspnsrTypeDesc;
	//@Field("prvdr_ncpdp_3_dspnsr_type_cd")
	private String prvdrNcpdp3DspnsrTypeCd;
	//@Field("prvdr_ncpdp_3_dspnsr_type_desc")
	private String prvdrNcpdp3DspnsrTypeDesc;
	//@Field("prvdr_ncpdp_dspnsr_cls_cd")
	private String prvdrNcpdpDspnsrClsCd;
	//@Field("prvdr_ncpdp_dspnsr_cls_cd_desc")
	private String prvdrNcpdpDspnsrClsCdDesc;
	//@Field("prvdr_ncpdp_id")
	private String prvdrNcpdpId;
	//@Field("prvdr_ncpdp_npi")
	private String prvdrNcpdpNpi;
	//@Field("prvdr_ncpdp_dba_name")
	private String prvdrNcpdpDbaName;
	//@Field("ndc_brnd_gnrc_ind")
	private String ndcBrndGnrcInd;
	//@Field("ndc_cd")
	private String ndcCd;
	//@Field("ndc_dea_class_desc")
	private String ndcDeaClassDesc;
	//@Field("ndc_fdb_dea_cls_cd")
	private String ndcFdbDeaClsCd;
	//@Field("ndc_dea_cls_cd")
	private String ndcDeaClsCd;	
	//@Field("ndc_dsg_form_desc")
	private String ndcDsgFormDesc;
	//@Field("ndc_fdb_brnd_gnrc_desc")
	private String ndcFdbBrndGnrcDesc;
	//@Field("ndc_fdb_pkg_size_amt")
	private Double ndcFdbPkgSizeAmt;
	//@Field("ndc_gpi_name_extnsn_cd")
	private String ndcGpiNameExtnsnCd;
	//@Field("ndc_gpi_name_extnsn_desc")
	private String ndcGpiNameExtnsnDesc;
	//@Field("ndc_gpi_stgth_cd")
	private String ndcGpiStgthCd;
	//@Field("ndc_label_name")
	private String ndcLabelName;
	//@Field("ndc_mddb_brnd_gnrc_cd")
	private String ndcMddbBrndGnrcCd;
	//@Field("ndc_mlt_type_cd")
	private String ndcMltTypeCd;
	//@Field("ndc_prod_abrvtn_desc")
	private String ndcProdAbrvtnDesc;
	//@Field("cdc_mme_class")
	private String cdcMmeClass;
	//@Field("clm_cntl_num")
	private String clmCntlNum;
	
	
	private String totalPaidAmt;
	private String totalBilledAmt;
	
//	//@Field("bene_rrb_num")
	private String beneRrbNum;
	
	public String getClaimType() {
		return this.claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getMacId() {
		return this.macId;
	}

	public void setMacId(String macId) {
		this.macId = macId;
	}

	public String getJurisdiction() {
		return this.jurisdiction;
	}

	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	public String getSubmitterId() {
		return this.submitterId;
	}

	public void setSubmitterId(String submitterId) {
		this.submitterId = submitterId;
	}

	public String getPerformNpi() {
		return this.performNpi;
	}

	public void setPerformNpi(String performNpi) {
		this.performNpi = performNpi;
	}

	public String getPerformPtan() {
		return this.performPtan;
	}

	public void setPerformPtan(String performPtan) {
		this.performPtan = performPtan;
	}

	public String getProviderName() {
		return this.providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getPerformSpecialty() {
		return this.performSpecialty;
	}

	public void setPerformSpecialty(String performSpecialty) {
		this.performSpecialty = performSpecialty;
	}

	public String getPerformPrvdrCity() {
		return this.performPrvdrCity;
	}

	public void setPerformPrvdrCity(String performPrvdrCity) {
		this.performPrvdrCity = performPrvdrCity;
	}

	public String getPerformPrvdrStateCd() {
		return this.performPrvdrStateCd;
	}

	public void setPerformPrvdrStateCd(String performPrvdrStateCd) {
		this.performPrvdrStateCd = performPrvdrStateCd;
	}

	public String getProviderZip() {
		return this.providerZip;
	}

	public void setProviderZip(String providerZip) {
		this.providerZip = providerZip;
	}

	public String getAttendNpi() {
		return this.attendNpi;
	}

	public void setAttendNpi(String attendNpi) {
		this.attendNpi = attendNpi;
	}

	public String getAttendPtan() {
		return this.attendPtan;
	}

	public void setAttendPtan(String attendPtan) {
		this.attendPtan = attendPtan;
	}

	public String getAttendNpiName() {
		return this.attendNpiName;
	}

	public void setAttendNpiName(String attendNpiName) {
		this.attendNpiName = attendNpiName;
	}

	public String getAttendSpecialty() {
		return this.attendSpecialty;
	}

	public void setAttendSpecialty(String attendSpecialty) {
		this.attendSpecialty = attendSpecialty;
	}

	public String getBeneId() {
		return this.beneId;
	}

	public void setBeneId(String beneId) {
		this.beneId = beneId;
	}

	public String getBeneFirstName() {
		return this.beneFirstName;
	}

	public void setBeneFirstName(String beneFirstName) {
		this.beneFirstName = beneFirstName;
	}

	public String getBeneLastName() {
		return this.beneLastName;
	}

	public void setBeneLastName(String beneLastName) {
		this.beneLastName = beneLastName;
	}

	public String getBeneCity() {
		return this.beneCity;
	}

	public void setBeneCity(String beneCity) {
		this.beneCity = beneCity;
	}

	public String getBeneStateCd() {
		return this.beneStateCd;
	}

	public void setBeneStateCd(String beneStateCd) {
		this.beneStateCd = beneStateCd;
	}

	public String getBeneZip() {
		return this.beneZip;
	}

	public void setBeneZip(String beneZip) {
		this.beneZip = beneZip;
	}

	public Integer getAge() {
		return this.age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getBirthDt() {
		return this.birthDt;
	}

	public void setBirthDt(String birthDt) {
		this.birthDt = birthDt;
	}

	public String getDeathDt() {
		return this.deathDt;
	}

	public void setDeathDt(String deathDt) {
		this.deathDt = deathDt;
	}

	public String getDualInd() {
		return this.dualInd;
	}

	public void setDualInd(String dualInd) {
		this.dualInd = dualInd;
	}

	public String getClaimNum() {
		return this.claimNum;
	}

	public void setClaimNum(String claimNum) {
		this.claimNum = claimNum;
	}

	public Integer getClaimLineNum() {
		return this.claimLineNum;
	}

	public void setClaimLineNum(Integer claimLineNum) {
		this.claimLineNum = Integer.valueOf(claimLineNum);
	}

	public String getProcedure() {
		return this.procedure;
	}

	public void setProcedure(String procedure) {
		this.procedure = procedure;
	}

	public Integer getProcTimeHrs() {
		return this.procTimeHrs;
	}

	public void setProcTimeHrs(Integer procTimeHrs) {
		this.procTimeHrs = Integer.valueOf(procTimeHrs);
	}

	public String getDiagnosis() {
		return this.diagnosis;
	}

	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}

	public String getMod1() {
		return this.mod1;
	}

	public void setMod1(String mod1) {
		this.mod1 = mod1;
	}

	public String getMod2() {
		return this.mod2;
	}

	public void setMod2(String mod2) {
		this.mod2 = mod2;
	}

	public String getMod3() {
		return this.mod3;
	}

	public void setMod3(String mod3) {
		this.mod3 = mod3;
	}

	public String getMod4() {
		return this.mod4;
	}

	public void setMod4(String mod4) {
		this.mod4 = mod4;
	}

	public String getMod5() {
		return this.mod5;
	}

	public void setMod5(String mod5) {
		this.mod5 = mod5;
	}

	public String getLineFromDt() {
		return this.lineFromDt;
	}

	public void setLineFromDt(String lineFromDt) {
		this.lineFromDt = lineFromDt;
	}

	public String getLineToDt() {
		return this.lineToDt;
	}

	public void setLineToDt(String lineToDt) {
		this.lineToDt = lineToDt;
	}

	public String getClaimFromDt() {
		return this.claimFromDt;
	}

	public void setClaimFromDt(String claimFromDt) {
		this.claimFromDt = claimFromDt;
	}

	public String getClaimToDt() {
		return this.claimToDt;
	}

	public void setClaimToDt(String claimToDt) {
		this.claimToDt = claimToDt;
	}

	public String getClaimToReview() {
		if (this.asrKey!= null){
			this.claimToReview =  FpsDomainObjectConverter.getFromAsrKey(asrKey, 1, asrptId+"");
		}
		return this.claimToReview;
	}

	public void setClaimToReview(String claimToReview) {
		this.claimToReview = claimToReview;
	}

	public String getUnitsService() {
		return this.unitsService;
	}

	public void setUnitsService(String unitsService) {
		this.unitsService = unitsService;
	}

	public String getLineSubmittedAmt() {
		return this.lineSubmittedAmt;
	}

	public void setLineSubmittedAmt(String lineSubmittedAmt) {
		this.lineSubmittedAmt = lineSubmittedAmt;
	}

	public String getLineAllowedAmt() {
		return this.lineAllowedAmt;
	}

	public void setLineAllowedAmt(String lineAllowedAmt) {
		this.lineAllowedAmt = lineAllowedAmt;
	}

	public String getLineProviderPaidAmt() {
		return this.lineProviderPaidAmt;
	}

	public void setLineProviderPaidAmt(String lineProviderPaidAmt) {
		this.lineProviderPaidAmt = lineProviderPaidAmt;
	}

	public String getClaimSubmittedAmt() {
		return this.claimSubmittedAmt;
	}

	public void setClaimSubmittedAmt(String claimSubmittedAmt) {
		this.claimSubmittedAmt = claimSubmittedAmt;
	}

	public String getClaimAllowedAmt() {
		return this.claimAllowedAmt;
	}

	public void setClaimAllowedAmt(String claimAllowedAmt) {
		this.claimAllowedAmt = claimAllowedAmt;
	}

	public String getClaimProviderPaidAmt() {
		return this.claimProviderPaidAmt;
	}

	public void setClaimProviderPaidAmt(String claimProviderPaidAmt) {
		this.claimProviderPaidAmt = claimProviderPaidAmt;
	}

	public String getTinEinOnClaim() {
		return this.tinEinOnClaim;
	}

	public void setTinEinOnClaim(String tinEinOnClaim) {
		this.tinEinOnClaim = tinEinOnClaim;
	}

	public String getBillType() {
		return this.billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	public String getRevenueCode() {
		return this.revenueCode;
	}

	public void setRevenueCode(String revenueCode) {
		this.revenueCode = revenueCode;
	}

	public String getCrossoverInd() {
		return this.crossoverInd;
	}

	public void setCrossoverInd(String crossoverInd) {
		this.crossoverInd = crossoverInd;
	}

	public String getAlertAttributeName() {
		return this.alertAttributeName;
	}

	public void setAlertAttributeName(String alertAttributeName) {
		this.alertAttributeName = alertAttributeName;
	}

	public String getReferNpi() {
		return this.referNpi;
	}

	public void setReferNpi(String referNpi) {
		this.referNpi = referNpi;
	}

	public String getReferPtan() {
		return this.referPtan;
	}

	public void setReferPtan(String referPtan) {
		this.referPtan = referPtan;
	}

	public String getReferNpiName() {
		return this.referNpiName;
	}

	public void setReferNpiName(String referNpiName) {
		this.referNpiName = referNpiName;
	}

	public String getReferNpiSpecialty() {
		return this.referNpiSpecialty;
	}

	public void setReferNpiSpecialty(String referNpiSpecialty) {
		this.referNpiSpecialty = referNpiSpecialty;
	}

	public String getBillNpi() {
		return this.billNpi;
	}

	public void setBillNpi(String billNpi) {
		this.billNpi = billNpi;
	}

	public String getBillPtan() {
		return this.billPtan;
	}

	public void setBillPtan(String billPtan) {
		this.billPtan = billPtan;
	}

	public String getBillPrvdrName() {
		return this.billPrvdrName;
	}

	public void setBillPrvdrName(String billPrvdrName) {
		this.billPrvdrName = billPrvdrName;
	}

	public String getBeneAddress() {
		return this.beneAddress;
	}

	public void setBeneAddress(String beneAddress) {
		this.beneAddress = beneAddress;
	}

	public int compareTo(AsrDetailClaimLineItem target) {
		String review1 = getClaimToReview();
		String review2 = target.getClaimToReview();
		Integer review1Num = Integer.valueOf(-1);
		Integer review2Num = Integer.valueOf(-1);
		if ("Y".equals(review1)) {
			review1Num = Integer.valueOf(1);
		}
		if ("N".equals(review1)) {
			review1Num = Integer.valueOf(0);
		}
		if ("Y".equals(review2)) {
			review2Num = Integer.valueOf(1);
		}
		if ("N".equals(review2)) {
			review2Num = Integer.valueOf(0);
		}
		return review2Num.compareTo(review1Num);
	}

	public String getBenePhone() {
		return this.benePhone;
	}

	public void setBenePhone(String benePhone) {
		this.benePhone = benePhone;
	}

	public String getMbi() {
		return mbi;
	}

	public void setMbi(String mbi) {
		this.mbi = mbi;
	}

	public void setModelString(String modelString) {
		this.modelString = modelString;

	}

	public String getModelString() {
		if (this.asrKey!= null){
			modelString = FpsDomainObjectConverter.getFromAsrKey(asrKey, 2,asrptId+"");
		}
		return modelString;
	}

	public Integer getClaimId() {
		return claimId;
	}

	public void setClaimId(Integer claimId) {
		this.claimId = claimId;
	}

	public Integer getAlertClaimId() {
		return alertClaimId;
	}

	public void setAlertClaimId(Integer alertClaimId) {
		this.alertClaimId = alertClaimId;
	}

	public String getDiagnosis1() {
		return diagnosis1;
	}

	public void setDiagnosis1(String diagnosis1) {
		this.diagnosis1 = diagnosis1;
	}

	public String getDiagnosis2() {
		return diagnosis2;
	}

	public void setDiagnosis2(String diagnosis2) {
		this.diagnosis2 = diagnosis2;
	}

	public String getPos() {
		return pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getAdmitDt() {
		return admitDt;
	}

	public void setAdmitDt(String admitDt) {
		this.admitDt = admitDt;
	}

	public String getDischargeDt() {
		return dischargeDt;
	}

	public void setDischargeDt(String dischargeDt) {
		this.dischargeDt = dischargeDt;
	}

	public String getPaymentAmt() {
		return paymentAmt;
	}

	public void setPaymentAmt(String paymentAmt) {
		this.paymentAmt = paymentAmt;
	}

	public String getUnitsAlwd() {
		return unitsAlwd;
	}

	public void setUnitsAlwd(String unitsAlwd) {
		this.unitsAlwd = unitsAlwd;
	}

	public Integer getDrg() {
		return drg;
	}

	public void setDrg(Integer drg) {
		this.drg = drg;
	}

	public String getLineDiagnosis() {
		return lineDiagnosis;
	}

	public void setLineDiagnosis(String lineDiagnosis) {
		this.lineDiagnosis = lineDiagnosis;
	}

	public String getHcpcsCd() {
		return hcpcsCd;
	}

	public void setHcpcsCd(String hcpcsCd) {
		this.hcpcsCd = hcpcsCd;
	}

	@Override
	public String toString() {
		return "AsrDetailClaimLineItem [solrId=" + solrId + ", macId=" + macId + ", claimId=" + claimId
				+ ", alertClaimId=" + alertClaimId + ", claimType=" + claimType + ", jurisdiction=" + jurisdiction
				+ ", submitterId=" + submitterId + ", asrptId=" + asrptId + ", modelId=" + modelId + ", modelBusnsId="
				+ modelBusnsId + ", alertId=" + alertId + ", attrSqncNum=" + attrSqncNum + ", performNpi=" + performNpi
				+ ", performPtan=" + performPtan + ", providerName=" + providerName + ", performSpecialty="
				+ performSpecialty + ", performPrvdrCity=" + performPrvdrCity + ", performPrvdrStateCd="
				+ performPrvdrStateCd + ", providerZip=" + providerZip + ", attendNpi=" + attendNpi + ", attendPtan="
				+ attendPtan + ", attendNpiName=" + attendNpiName + ", attendSpecialty=" + attendSpecialty + ", beneId="
				+ beneId + ", beneFirstName=" + beneFirstName + ", beneLastName=" + beneLastName + ", beneCity="
				+ beneCity + ", beneAddress=" + beneAddress + ", beneAddress2=" + beneAddress2 + ", beneStateCd="
				+ beneStateCd + ", beneZip=" + beneZip + ", age=" + age + ", birthDt=" + birthDt + ", deathDt="
				+ deathDt + ", dualInd=" + dualInd + ", claimNum=" + claimNum + ", claimLineNum=" + claimLineNum
				+ ", procedure=" + procedure + ", procTimeHrs=" + procTimeHrs + ", diagnosis=" + diagnosis + ", mod1="
				+ mod1 + ", mod2=" + mod2 + ", mod3=" + mod3 + ", mod4=" + mod4 + ", mod5=" + mod5 + ", lineFromDt="
				+ lineFromDt + ", lineToDt=" + lineToDt + ", claimFromDt=" + claimFromDt + ", claimToDt=" + claimToDt
				+ ", claimToReview=" + claimToReview + ", unitsService=" + unitsService + ", lineSubmittedAmt="
				+ lineSubmittedAmt + ", lineAllowedAmt=" + lineAllowedAmt + ", lineProviderPaidAmt="
				+ lineProviderPaidAmt + ", claimSubmittedAmt=" + claimSubmittedAmt + ", claimAllowedAmt="
				+ claimAllowedAmt + ", claimProviderPaidAmt=" + claimProviderPaidAmt + ", tinEinOnClaim="
				+ tinEinOnClaim + ", billType=" + billType + ", revenueCode=" + revenueCode + ", crossoverInd="
				+ crossoverInd + ", alertAttributeName=" + alertAttributeName + ", referNpi=" + referNpi
				+ ", referPtan=" + referPtan + ", referNpiName=" + referNpiName + ", referNpiSpecialty="
				+ referNpiSpecialty + ", billNpi=" + billNpi + ", billPtan=" + billPtan + ", billPrvdrName="
				+ billPrvdrName + ", benePhone=" + benePhone + ", mbi=" + mbi + ", modelString=" + modelString
				+ ", diagnosis1=" + diagnosis1 + ", diagnosis2=" + diagnosis2 + ", pos=" + pos + ", admitDt=" + admitDt
				+ ", dischargeDt=" + dischargeDt + ", paymentAmt=" + paymentAmt + ", unitsAlwd=" + unitsAlwd + ", drg="
				+ drg + ", lineDiagnosis=" + lineDiagnosis + ", hcpcsCd=" + hcpcsCd + ", lineRevUnitNum="
				+ lineRevUnitNum + ", asrKey=" + asrKey + ", alertKey=" + alertKey + ", attributeKey=" + attributeKey
			    + ", birthDtSolr=" + birthDtSolr + ", deathDtSolr="
				+ deathDtSolr + ", unitsServiceSolr=" + unitsServiceSolr + ", lineSubmittedAmtSolr="
				+ lineSubmittedAmtSolr + ", lineAllowedAmtSolr=" + lineAllowedAmtSolr + ", lineProviderPaidAmtSolr="
				+ lineProviderPaidAmtSolr + ", claimSubmittedAmtSolr=" + claimSubmittedAmtSolr
				+ ", claimAllowedAmtSolr=" + claimAllowedAmtSolr + ", claimProviderPaidAmtSolr="
				+ claimProviderPaidAmtSolr + ", paymentAmtSolr=" + paymentAmtSolr + ", unitsAlwdSolr=" + unitsAlwdSolr
				+ "]";
	}

	public String getSolrId() {
		return solrId;
	}

	public void setSolrId(String solrId) {
		this.solrId = solrId;
	}

	public String getAsrptId() {
		return asrptId;
	}

	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}

	public Integer getModelId() {
		return modelId;
	}

	public void setModelId(Integer modelId) {
		this.modelId = modelId;
	}

	public String getModelBusnsId() {
		return modelBusnsId;
	}

	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}

	public Integer getAlertId() {
		return alertId;
	}

	public void setAlertId(Integer alertId) {
		this.alertId = alertId;
	}

	public Integer getAttrSqncNum() {
		return attrSqncNum;
	}

	public void setAttrSqncNum(Integer attrSqncNum) {
		this.attrSqncNum = attrSqncNum;
	}

	public String getBeneAddress2() {
		return beneAddress2;
	}

	public void setBeneAddress2(String beneAddress2) {
		this.beneAddress2 = beneAddress2;
	}

	public Integer getLineRevUnitNum() {
		return lineRevUnitNum;
	}

	public void setLineRevUnitNum(Integer lineRevUnitNum) {
		this.lineRevUnitNum = lineRevUnitNum;
	}

	public Date getBirthDtSolr() {
		return birthDtSolr;
	}

	//@Field("bene_brth_dt")
	public void setBirthDtSolr(Date birthDtSolr) {
		this.birthDtSolr = birthDtSolr;
		if (birthDtSolr != null) {
			setBirthDt(FpsDomainObjectConverter.convertDateToShortString(birthDtSolr));
			updateAge();
		}
	}

	public Date getDeathDtSolr() {
		return deathDtSolr;
	}

	//@Field("bene_death_dt")
	public void setDeathDtSolr(Date deathDtSolr) {
		this.deathDtSolr = deathDtSolr;
		if (deathDtSolr != null) {
			setDeathDt(FpsDomainObjectConverter.convertDateToShortString(deathDtSolr));
		}
	}

	public Integer getUnitsServiceSolr() {
		return unitsServiceSolr;
	}
	//@Field("clm_line_srvc_unit_qty")
	public void setUnitsServiceSolr(Integer unitsServiceSolr) {
		this.unitsServiceSolr = unitsServiceSolr;
		if (unitsServiceSolr != null) {
			setUnitsService(FpsDomainObjectConverter.parseObject(unitsServiceSolr));
		}
	}

	public Double getLineSubmittedAmtSolr() {
		return lineSubmittedAmtSolr;
	}
	//@Field("clm_line_tot_chrg_amt")
	public void setLineSubmittedAmtSolr(Double lineSubmittedAmtSolr) {
		this.lineSubmittedAmtSolr = lineSubmittedAmtSolr;
		if (lineSubmittedAmtSolr != null) {
			setLineSubmittedAmt(FpsDomainObjectConverter.convertDecimalToDollar(lineSubmittedAmtSolr));
		}
	}

	public Double getLineAllowedAmtSolr() {
		return lineAllowedAmtSolr;
	}
	//@Field("clm_line_alowd_chrg_amt")
	public void setLineAllowedAmtSolr(Double lineAllowedAmtSolr) {
		this.lineAllowedAmtSolr = lineAllowedAmtSolr;
		if (lineAllowedAmtSolr != null) {
			setLineAllowedAmt(FpsDomainObjectConverter.convertDecimalToDollar(lineAllowedAmtSolr));
		}
	}

	public Double getLineProviderPaidAmtSolr() {
		return lineProviderPaidAmtSolr;
	}
	//@Field("clm_line_prvdr_pmt_amt")
	public void setLineProviderPaidAmtSolr(Double lineProviderPaidAmtSolr) {
		this.lineProviderPaidAmtSolr = lineProviderPaidAmtSolr;
		if (lineProviderPaidAmtSolr != null) {
			setLineProviderPaidAmt(FpsDomainObjectConverter.convertDecimalToDollar(lineProviderPaidAmtSolr));
		}
	}

	public Double getClaimSubmittedAmtSolr() {
		return claimSubmittedAmtSolr;
	}
	//@Field("clm_sbmt_chrg_amt")
	public void setClaimSubmittedAmtSolr(Double claimSubmittedAmtSolr) {
		this.claimSubmittedAmtSolr = claimSubmittedAmtSolr;
		if (claimSubmittedAmtSolr != null) {
			setClaimSubmittedAmt(FpsDomainObjectConverter.convertDecimalToDollar(claimSubmittedAmtSolr));
		}
	}

	public Double getClaimAllowedAmtSolr() {
		return claimAllowedAmtSolr;
	}
	//@Field("clm_alowd_chrg_amt")
	public void setClaimAllowedAmtSolr(Double claimAllowedAmtSolr) {
		this.claimAllowedAmtSolr = claimAllowedAmtSolr;
		if (claimAllowedAmtSolr != null) {
			setClaimAllowedAmt(FpsDomainObjectConverter.convertDecimalToDollar(claimAllowedAmtSolr));
		}
	}

	public Double getClaimProviderPaidAmtSolr() {
		return claimProviderPaidAmtSolr;
	}
	//@Field("clm_prvdr_pmt_amt")
	public void setClaimProviderPaidAmtSolr(Double claimProviderPaidAmtSolr) {
		this.claimProviderPaidAmtSolr = claimProviderPaidAmtSolr;
		if (claimProviderPaidAmtSolr != null) {
			setClaimProviderPaidAmt(FpsDomainObjectConverter.convertDecimalToDollar(claimProviderPaidAmtSolr));
		}
	}

	public Double getPaymentAmtSolr() {
		return paymentAmtSolr;
	}

	//@Field("clm_pmt_amt")
	public void setPaymentAmtSolr(Double paymentAmtSolr) {
		this.paymentAmtSolr = paymentAmtSolr;
		if (paymentAmtSolr != null) {
			setPaymentAmt(FpsDomainObjectConverter.convertDecimalToDollar(paymentAmtSolr));
		}
	}

	public Integer getUnitsAlwdSolr() {
		return unitsAlwdSolr;
	}

	//@Field("clm_line_alowd_unit_qty")
	public void setUnitsAlwdSolr(Integer unitsAlwdSolr) {
		this.unitsAlwdSolr = unitsAlwdSolr;
		if (unitsAlwdSolr != null) {
			setUnitsAlwd(FpsDomainObjectConverter.parseObject(unitsAlwdSolr));
		}
	}



	public String getAsrKey() {
		return asrKey;
	}

	public void setAsrKey(String asrKey) {
		this.asrKey = asrKey;
		setClaimToReview(FpsDomainObjectConverter.getFromAsrKey(asrKey, 1, asrptId+""));
	}

	public String getAlertKey() {
		return alertKey;
	}

	public void setAlertKey(String alertKey) {
		this.alertKey = alertKey;
	}

	public String getAttributeKey() {
		return attributeKey;
	}

	public void setAttributeKey(String attributeKey) {
		this.attributeKey = attributeKey;
	}

	public String getHcpcsDesc() {
		return hcpcsDesc;
	}

	public void setHcpcsDesc(String hcpcsDesc) {
		this.hcpcsDesc = hcpcsDesc;
	}

	public String getDiag1Desc() {
		return diag1Desc;
	}

	public void setDiag1Desc(String diag1Desc) {
		this.diag1Desc = diag1Desc;
	}

	public String getDiag2Desc() {
		return diag2Desc;
	}

	public void setDiag2Desc(String diag2Desc) {
		this.diag2Desc = diag2Desc;
	}

	public String getPrcdrDesc() {
		return prcdrDesc;
	}

	public void setPrcdrDesc(String prcdrDesc) {
		this.prcdrDesc = prcdrDesc;
	}

	public String getDiagDesc() {
		return diagDesc;
	}

	public void setDiagDesc(String diagDesc) {
		this.diagDesc = diagDesc;
	}

	public char[] toCsv() {
		// TODO Auto-generated method stub
		return null;
	}

	public Date getLineFromDtSolr() {
		return lineFromDtSolr;
	}
	//@Field("clm_line_from_dt")
	public void setLineFromDtSolr(Date lineFromDtSolr) {
		this.lineFromDtSolr = lineFromDtSolr;
		if (lineFromDtSolr != null) {
			setLineFromDt(FpsDomainObjectConverter.convertDateToShortString(lineFromDtSolr));
		}
	}

	public Date getLineToDtSolr() {
		return lineToDtSolr;
	}
	//@Field("clm_line_thru_dt")
	public void setLineToDtSolr(Date lineToDtSolr) {
		this.lineToDtSolr = lineToDtSolr;
		if (lineToDtSolr != null) {
			setLineToDt(FpsDomainObjectConverter.convertDateToShortString(lineToDtSolr));
		}
	}

	public Date getClaimFromDtSolr() {
		return claimFromDtSolr;
	}
	//@Field("clm_from_dt")
	public void setClaimFromDtSolr(Date claimFromDtSolr) {
		this.claimFromDtSolr = claimFromDtSolr;
		if (claimFromDtSolr != null) {
			setClaimFromDt(FpsDomainObjectConverter.convertDateToShortString(claimFromDtSolr));
		}
	}

	public Date getClaimToDtSolr() {
		return claimToDtSolr;
	}
	//@Field("clm_thru_dt")
	public void setClaimToDtSolr(Date claimToDtSolr) {
		this.claimToDtSolr = claimToDtSolr;
		if (claimToDtSolr != null) {
			setClaimToDt(FpsDomainObjectConverter.convertDateToShortString(claimToDtSolr));
		}
	}

	public Date getAdmitDtSolr() {
		return admitDtSolr;
	}
	//@Field("clm_actv_care_from_dt")
	public void setAdmitDtSolr(Date admitDtSolr) {
		this.admitDtSolr = admitDtSolr;
		if (admitDtSolr != null) {
			setAdmitDt(FpsDomainObjectConverter.convertDateToShortString(admitDtSolr));
		}
	}

	public Date getDischargeDtSolr() {
		return dischargeDtSolr;
	}
	//@Field("clm_dschrg_dt")
	public void setDischargeDtSolr(Date dischargeDtSolr) {
		this.dischargeDtSolr = dischargeDtSolr;
		if (dischargeDtSolr != null) {
			setDischargeDt(FpsDomainObjectConverter.convertDateToShortString(dischargeDtSolr));
		}
	}

	public Double getClmLineBenePmtAmt() {
		return clmLineBenePmtAmt;
	}
	//@Field("clm_line_bene_pmt_amt")

	public void setClmLineBenePmtAmt(Double clmLineBenePmtAmt) {
		
		this.clmLineBenePmtAmt = clmLineBenePmtAmt;
		updateTotalPaidAmt();
	}

	public String getClmCtstrphcCvrgIndCd() {
		return clmCtstrphcCvrgIndCd;
	}

	public void setClmCtstrphcCvrgIndCd(String clmCtstrphcCvrgIndCd) {
		this.clmCtstrphcCvrgIndCd = clmCtstrphcCvrgIndCd;
	}

	public Long getClmUniqId() {
		return clmUniqId;
	}

	public void setClmUniqId(Long clmUniqId) {
		this.clmUniqId = clmUniqId;
	}

	public String getClmCmpndCd() {
		return clmCmpndCd;
	}

	public void setClmCmpndCd(String clmCmpndCd) {
		this.clmCmpndCd = clmCmpndCd;
	}
	
	public Double getClmLineCvrdPdAmt() {
		return clmLineCvrdPdAmt;
	}
	//@Field("clm_line_cvrd_pd_amt")

	public void setClmLineCvrdPdAmt(Double clmLineCvrdPdAmt) {
		
		this.clmLineCvrdPdAmt = clmLineCvrdPdAmt;
		updateTotalPaidAmt();
	}

	public Integer getClmLineDaysSuplyQty() {
		return clmLineDaysSuplyQty;
	}

	public void setClmLineDaysSuplyQty(Integer clmLineDaysSuplyQty) {
		this.clmLineDaysSuplyQty = clmLineDaysSuplyQty;
	}

	public String getClmDawProdSlctnCd() {
		return clmDawProdSlctnCd;
	}

	public void setClmDawProdSlctnCd(String clmDawProdSlctnCd) {
		this.clmDawProdSlctnCd = clmDawProdSlctnCd;
	}

	public String getClmDspnsngStusCd() {
		return clmDspnsngStusCd;
	}

	public void setClmDspnsngStusCd(String clmDspnsngStusCd) {
		this.clmDspnsngStusCd = clmDspnsngStusCd;
	}

	public String getClmDrugCvrgStusCd() {
		return clmDrugCvrgStusCd;
	}

	public void setClmDrugCvrgStusCd(String clmDrugCvrgStusCd) {
		this.clmDrugCvrgStusCd = clmDrugCvrgStusCd;
	}

	public String getClmLineRxNum() {
		return clmLineRxNum;
	}

	public void setClmLineRxNum(String clmLineRxNum) {
		this.clmLineRxNum = clmLineRxNum;
	}

	public Integer getClmLineRxFillNum() {
		return clmLineRxFillNum;
	}

	public void setClmLineRxFillNum(Integer clmLineRxFillNum) {
		this.clmLineRxFillNum = clmLineRxFillNum;
	}

	public Double getClmLineLisAmt() {
		return clmLineLisAmt;
	}
	//@Field("clm_line_lis_amt")

	public void setClmLineLisAmt(Double clmLineLisAmt) {
		this.clmLineLisAmt = clmLineLisAmt;
		updateTotalPaidAmt();
	}

	public String getClmLineNdcCd() {
		return clmLineNdcCd;
	}

	public void setClmLineNdcCd(String clmLineNdcCd) {
		this.clmLineNdcCd = clmLineNdcCd;
	}

	public Double getClmLineNdcQty() {
		return clmLineNdcQty;
	}

	public void setClmLineNdcQty(Double clmLineNdcQty) {
		this.clmLineNdcQty = clmLineNdcQty;
	}

	public String getClmLineNdcQtyQlfyrCd() {
		return clmLineNdcQtyQlfyrCd;
	}

	public void setClmLineNdcQtyQlfyrCd(String clmLineNdcQtyQlfyrCd) {
		this.clmLineNdcQtyQlfyrCd = clmLineNdcQtyQlfyrCd;
	}

	public Double getClmLineNcvrdPdAmt() {
		return clmLineNcvrdPdAmt;
	}
	//@Field("clm_line_ncvrd_pd_amt")
	public void setClmLineNcvrdPdAmt(Double clmLineNcvrdPdAmt) {
		this.clmLineNcvrdPdAmt = clmLineNcvrdPdAmt;
		updateTotalPaidAmt();

	}

	public Double getClmLinePlroAmt() {
		return clmLinePlroAmt;
	}
	//@Field("clm_line_plro_amt")

	public void setClmLinePlroAmt(Double clmLinePlroAmt) {
		this.clmLinePlroAmt = clmLinePlroAmt;
		updateTotalPaidAmt();

	}

	public Date getClmPdDt() {
		return clmPdDt;
	}

	public void setClmPdDt(Date clmPdDt) {
		this.clmPdDt = clmPdDt;
	}

	public String getPrvdrPrsbngIdQlfyrCd() {
		return prvdrPrsbngIdQlfyrCd;
	}

	public void setPrvdrPrsbngIdQlfyrCd(String prvdrPrsbngIdQlfyrCd) {
		this.prvdrPrsbngIdQlfyrCd = prvdrPrsbngIdQlfyrCd;
	}

	public String getClmPrsbngPrvdrGnrcIdNum() {
		return clmPrsbngPrvdrGnrcIdNum;
	}

	public void setClmPrsbngPrvdrGnrcIdNum(String clmPrsbngPrvdrGnrcIdNum) {
		this.clmPrsbngPrvdrGnrcIdNum = clmPrsbngPrvdrGnrcIdNum;
	}

	public String getClmCntrctOfRecCntrctNum() {
		return clmCntrctOfRecCntrctNum;
	}

	public void setClmCntrctOfRecCntrctNum(String clmCntrctOfRecCntrctNum) {
		this.clmCntrctOfRecCntrctNum = clmCntrctOfRecCntrctNum;
	}

	public String getClmSrvcPrvdrGnrcIdNum() {
		return clmSrvcPrvdrGnrcIdNum;
	}

	public void setClmSrvcPrvdrGnrcIdNum(String clmSrvcPrvdrGnrcIdNum) {
		this.clmSrvcPrvdrGnrcIdNum = clmSrvcPrvdrGnrcIdNum;
	}

	public String getClmSbmtrCntrctNum() {
		return clmSbmtrCntrctNum;
	}

	public void setClmSbmtrCntrctNum(String clmSbmtrCntrctNum) {
		this.clmSbmtrCntrctNum = clmSbmtrCntrctNum;
	}

	public String getClmSbmtrCntrctPbpNum() {
		return clmSbmtrCntrctPbpNum;
	}

	public void setClmSbmtrCntrctPbpNum(String clmSbmtrCntrctPbpNum) {
		this.clmSbmtrCntrctPbpNum = clmSbmtrCntrctPbpNum;
	}

	public Double getClmLineOthrTpPdAmt() {
		return clmLineOthrTpPdAmt;
	}
	//@Field("clm_line_othr_tp_pd_amt")

	public void setClmLineOthrTpPdAmt(Double clmLineOthrTpPdAmt) {
		this.clmLineOthrTpPdAmt = clmLineOthrTpPdAmt;
		updateTotalPaidAmt();
	}

	public Double getClmLineIngrdntCstAmt() {
		return clmLineIngrdntCstAmt;
	}
	//@Field("clm_line_ingrdnt_cst_amt")

	public void setClmLineIngrdntCstAmt(Double clmLineIngrdntCstAmt) {
		
		this.clmLineIngrdntCstAmt = clmLineIngrdntCstAmt;
		updateTotalBilledAmt();
	
	}

	public Double getClmLineSlsTaxAmt() {
		return clmLineSlsTaxAmt;
	}
	//@Field("clm_line_sls_tax_amt")

	public void setClmLineSlsTaxAmt(Double clmLineSlsTaxAmt) {
		this.clmLineSlsTaxAmt = clmLineSlsTaxAmt;
		updateTotalBilledAmt();
		
	}

	public Double getClmLineSrvcCstAmt() {
		return clmLineSrvcCstAmt;
	}
	//@Field("clm_line_srvc_cst_amt")

	public void setClmLineSrvcCstAmt(Double clmLineSrvcCstAmt) {
		this.clmLineSrvcCstAmt = clmLineSrvcCstAmt;
		updateTotalBilledAmt();
		
	}

	public String getPrvdrSrvcIdQlfyrCd() {
		return prvdrSrvcIdQlfyrCd;
	}

	public void setPrvdrSrvcIdQlfyrCd(String prvdrSrvcIdQlfyrCd) {
		this.prvdrSrvcIdQlfyrCd = prvdrSrvcIdQlfyrCd;
	}

	public Integer getClmLineRxSrvcRfrncNum() {
		return clmLineRxSrvcRfrncNum;
	}

	public void setClmLineRxSrvcRfrncNum(Integer clmLineRxSrvcRfrncNum) {
		this.clmLineRxSrvcRfrncNum = clmLineRxSrvcRfrncNum;
	}

	public String getPrvdrNcpdp1DspnsrTypeCd() {
		return prvdrNcpdp1DspnsrTypeCd;
	}

	public void setPrvdrNcpdp1DspnsrTypeCd(String prvdrNcpdp1DspnsrTypeCd) {
		this.prvdrNcpdp1DspnsrTypeCd = prvdrNcpdp1DspnsrTypeCd;
	}

	public String getPrvdrNcpdp1DspnsrTypeDesc() {
		return prvdrNcpdp1DspnsrTypeDesc;
	}

	public void setPrvdrNcpdp1DspnsrTypeDesc(String prvdrNcpdp1DspnsrTypeDesc) {
		this.prvdrNcpdp1DspnsrTypeDesc = prvdrNcpdp1DspnsrTypeDesc;
	}

	public String getPrvdrNcpdp2DspnsrTypeCd() {
		return prvdrNcpdp2DspnsrTypeCd;
	}

	public void setPrvdrNcpdp2DspnsrTypeCd(String prvdrNcpdp2DspnsrTypeCd) {
		this.prvdrNcpdp2DspnsrTypeCd = prvdrNcpdp2DspnsrTypeCd;
	}

	public String getPrvdrNcpdp2DspnsrTypeDesc() {
		return prvdrNcpdp2DspnsrTypeDesc;
	}

	public void setPrvdrNcpdp2DspnsrTypeDesc(String prvdrNcpdp2DspnsrTypeDesc) {
		this.prvdrNcpdp2DspnsrTypeDesc = prvdrNcpdp2DspnsrTypeDesc;
	}

	public String getPrvdrNcpdp3DspnsrTypeCd() {
		return prvdrNcpdp3DspnsrTypeCd;
	}

	public void setPrvdrNcpdp3DspnsrTypeCd(String prvdrNcpdp3DspnsrTypeCd) {
		this.prvdrNcpdp3DspnsrTypeCd = prvdrNcpdp3DspnsrTypeCd;
	}

	public String getPrvdrNcpdp3DspnsrTypeDesc() {
		return prvdrNcpdp3DspnsrTypeDesc;
	}

	public void setPrvdrNcpdp3DspnsrTypeDesc(String prvdrNcpdp3DspnsrTypeDesc) {
		this.prvdrNcpdp3DspnsrTypeDesc = prvdrNcpdp3DspnsrTypeDesc;
	}

	public String getPrvdrNcpdpDspnsrClsCd() {
		return prvdrNcpdpDspnsrClsCd;
	}

	public void setPrvdrNcpdpDspnsrClsCd(String prvdrNcpdpDspnsrClsCd) {
		this.prvdrNcpdpDspnsrClsCd = prvdrNcpdpDspnsrClsCd;
	}

	public String getPrvdrNcpdpDspnsrClsCdDesc() {
		return prvdrNcpdpDspnsrClsCdDesc;
	}

	public void setPrvdrNcpdpDspnsrClsCdDesc(String prvdrNcpdpDspnsrClsCdDesc) {
		this.prvdrNcpdpDspnsrClsCdDesc = prvdrNcpdpDspnsrClsCdDesc;
	}

	public String getPrvdrNcpdpId() {
		return prvdrNcpdpId;
	}

	public void setPrvdrNcpdpId(String prvdrNcpdpId) {
		this.prvdrNcpdpId = prvdrNcpdpId;
	}

	public String getPrvdrNcpdpNpi() {
		return prvdrNcpdpNpi;
	}

	public void setPrvdrNcpdpNpi(String prvdrNcpdpNpi) {
		this.prvdrNcpdpNpi = prvdrNcpdpNpi;
	}

	public String getPrvdrNcpdpDbaName() {
		return prvdrNcpdpDbaName;
	}

	public void setPrvdrNcpdpDbaName(String prvdrNcpdpDbaName) {
		this.prvdrNcpdpDbaName = prvdrNcpdpDbaName;
	}

	public String getNdcBrndGnrcInd() {
		return ndcBrndGnrcInd;
	}

	public void setNdcBrndGnrcInd(String ndcBrndGnrcInd) {
		this.ndcBrndGnrcInd = ndcBrndGnrcInd;
	}

	public String getNdcCd() {
		return ndcCd;
	}

	public void setNdcCd(String ndcCd) {
		this.ndcCd = ndcCd;
	}

	public String getNdcDeaClassDesc() {
		return ndcDeaClassDesc;
	}

	public void setNdcDeaClassDesc(String ndcDeaClassDesc) {
		this.ndcDeaClassDesc = ndcDeaClassDesc;
	}

	public String getNdcDeaClsCd() {
		return ndcDeaClsCd;
	}

	public void setNdcDeaClsCd(String ndcDeaClsCd) {
		this.ndcDeaClsCd = ndcDeaClsCd;
	}

	public String getNdcDsgFormDesc() {
		return ndcDsgFormDesc;
	}

	public void setNdcDsgFormDesc(String ndcDsgFormDesc) {
		this.ndcDsgFormDesc = ndcDsgFormDesc;
	}

	public String getNdcFdbBrndGnrcDesc() {
		return ndcFdbBrndGnrcDesc;
	}

	public void setNdcFdbBrndGnrcDesc(String ndcFdbBrndGnrcDesc) {
		this.ndcFdbBrndGnrcDesc = ndcFdbBrndGnrcDesc;
	}

	public Double getNdcFdbPkgSizeAmt() {
		return ndcFdbPkgSizeAmt;
	}

	public void setNdcFdbPkgSizeAmt(Double ndcFdbPkgSizeAmt) {
		this.ndcFdbPkgSizeAmt = ndcFdbPkgSizeAmt;
	}

	public String getNdcGpiNameExtnsnCd() {
		return ndcGpiNameExtnsnCd;
	}

	public void setNdcGpiNameExtnsnCd(String ndcGpiNameExtnsnCd) {
		this.ndcGpiNameExtnsnCd = ndcGpiNameExtnsnCd;
	}

	public String getNdcGpiNameExtnsnDesc() {
		return ndcGpiNameExtnsnDesc;
	}

	public void setNdcGpiNameExtnsnDesc(String ndcGpiNameExtnsnDesc) {
		this.ndcGpiNameExtnsnDesc = ndcGpiNameExtnsnDesc;
	}

	public String getNdcGpiStgthCd() {
		return ndcGpiStgthCd;
	}

	public void setNdcGpiStgthCd(String ndcGpiStgthCd) {
		this.ndcGpiStgthCd = ndcGpiStgthCd;
	}

	public String getNdcLabelName() {
		return ndcLabelName;
	}

	public void setNdcLabelName(String ndcLabelName) {
		this.ndcLabelName = ndcLabelName;
	}

	public String getNdcMddbBrndGnrcCd() {
		return ndcMddbBrndGnrcCd;
	}

	public void setNdcMddbBrndGnrcCd(String ndcMddbBrndGnrcCd) {
		this.ndcMddbBrndGnrcCd = ndcMddbBrndGnrcCd;
	}

	public String getNdcMltTypeCd() {
		return ndcMltTypeCd;
	}

	public void setNdcMltTypeCd(String ndcMltTypeCd) {
		this.ndcMltTypeCd = ndcMltTypeCd;
	}

	public String getNdcProdAbrvtnDesc() {
		return ndcProdAbrvtnDesc;
	}

	public void setNdcProdAbrvtnDesc(String ndcProdAbrvtnDesc) {
		this.ndcProdAbrvtnDesc = ndcProdAbrvtnDesc;
	}

	public String getCdcMmeClass() {
		return cdcMmeClass;
	}

	public void setCdcMmeClass(String cdcMmeClass) {
		this.cdcMmeClass = cdcMmeClass;
	}
	// sum
	public void updateTotalPaidAmt() {
		Double total = (clmLineCvrdPdAmt == null ? 0 : clmLineCvrdPdAmt)
				+ (clmLineNcvrdPdAmt == null ? 0 : clmLineNcvrdPdAmt) 
				+ (clmLinePlroAmt==null ? 0 : clmLinePlroAmt)
				+ (clmLineOthrTpPdAmt==null ? 0 : clmLineOthrTpPdAmt)
				+ (clmLineLisAmt==null ? 0 :clmLineLisAmt)
				+ (clmLineBenePmtAmt==null ? 0 : clmLineBenePmtAmt);
		totalPaidAmt = FpsDomainObjectConverter.convertDecimalToDollar(total);
	}
	// sum
	public void updateTotalBilledAmt() {
		Double total = (clmLineIngrdntCstAmt == null ? 0 : clmLineIngrdntCstAmt)
				+ (clmLineSlsTaxAmt==null ? 0 : clmLineSlsTaxAmt) + 
				(clmLineSrvcCstAmt== null ? 0 : clmLineSrvcCstAmt);
		totalBilledAmt = FpsDomainObjectConverter.convertDecimalToDollar(total);
	}

	public String getClmDrugCvrgStusDesc() {
		return clmDrugCvrgStusDesc;
	}

	public void setClmDrugCvrgStusDesc(String clmDrugCvrgStusDesc) {
		this.clmDrugCvrgStusDesc = clmDrugCvrgStusDesc;
	}

	public String getClmLineNdcDesc() {
		return clmLineNdcDesc;
	}

	public void setClmLineNdcDesc(String clmLineNdcDesc) {
		this.clmLineNdcDesc = clmLineNdcDesc;
	}

	public String getClmCntlNum() {
		return clmCntlNum;
	}

	public void setClmCntlNum(String clmCntlNum) {
		this.clmCntlNum = clmCntlNum;
	}

	public void setTotalPaidAmt(String totalPaidAmt) {
		this.totalPaidAmt = totalPaidAmt;
	}

	public void setTotalBilledAmt(String totalBilledAmt) {
		this.totalBilledAmt = totalBilledAmt;
	}

	public String getClmCtstrphcCvrgIndDesc() {
		return clmCtstrphcCvrgIndDesc;
	}

	public void setClmCtstrphcCvrgIndDesc(String clmCtstrphcCvrgIndDesc) {
		this.clmCtstrphcCvrgIndDesc = clmCtstrphcCvrgIndDesc;
	}

	public String getClmDawProdSlctnDesc() {
		return clmDawProdSlctnDesc;
	}

	public void setClmDawProdSlctnDesc(String clmDawProdSlctnDesc) {
		this.clmDawProdSlctnDesc = clmDawProdSlctnDesc;
	}

	public String getPrvdrSrvcIdQlfyrDesc() {
		return prvdrSrvcIdQlfyrDesc;
	}

	public void setPrvdrSrvcIdQlfyrDesc(String prvdrSrvcIdQlfyrDesc) {
		this.prvdrSrvcIdQlfyrDesc = prvdrSrvcIdQlfyrDesc;
	}

	public String getClmDspnsngStusDesc() {
		return clmDspnsngStusDesc;
	}

	public void setClmDspnsngStusDesc(String clmDspnsngStusDesc) {
		this.clmDspnsngStusDesc = clmDspnsngStusDesc;
	}

	public String getPrvdrPrsbngIdQlfyrDesc() {
		return prvdrPrsbngIdQlfyrDesc;
	}

	public void setPrvdrPrsbngIdQlfyrDesc(String prvdrPrsbngIdQlfyrDesc) {
		this.prvdrPrsbngIdQlfyrDesc = prvdrPrsbngIdQlfyrDesc;
	}

	public String getNdcFdbDeaClsCd() {
		return ndcFdbDeaClsCd;
	}

	public void setNdcFdbDeaClsCd(String ndcFdbDeaClsCd) {
		this.ndcFdbDeaClsCd = ndcFdbDeaClsCd;
	}

	public String getClmCmpndDesc() {
		return clmCmpndDesc;
	}

	public void setClmCmpndDesc(String clmCmpndDesc) {
		this.clmCmpndDesc = clmCmpndDesc;
	}

	public String getTotalPaidAmt() {
		return totalPaidAmt;
	}

	public String getTotalBilledAmt() {
		return totalBilledAmt;
	}

	private void updateAge(){
		Calendar calDob = Calendar.getInstance();

		calDob.setTime(birthDtSolr);
		LocalDate birthdate = new LocalDate(calDob.get(1), calDob.get(2) + 1, calDob.get(5));
		LocalDate now = new LocalDate();
		Years years = Years.yearsBetween(birthdate, now);
		setAge(years.getYears());
	}

	public String getBeneRrbNum() {
		return beneRrbNum;
	}

	public void setBeneRrbNum(String beneRrbNum) {
		this.beneRrbNum = beneRrbNum;
	}



}
