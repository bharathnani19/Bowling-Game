/*
 * 
 */
package gov.hhs.cms.fps.dao;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gov.hhs.cms.fps.model.AvailableClaims;
import gov.hhs.cms.fps.model.generated.FpsModel;


// TODO: Auto-generated Javadoc
/**
 * The Class BaseDao.
 *
 * @param <PK> the generic type
 * @param <T> the generic type
 */
public abstract class BaseDao<PK extends Serializable, T> {

	/** The persistent class. */
	private final Class<T> persistentClass;
	
	/** The session factory. */
	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private SessionFactory snowflakeSessionFactory;
	
	/**
	 * Instantiates a new base dao.
	 */
	@SuppressWarnings("unchecked")
	public BaseDao(){ 
		this.persistentClass = (Class<T>) ((ParameterizedType) this.getClass().getGenericSuperclass()).getActualTypeArguments()[1];
	}
	
	/**
	 * Gets the current session.
	 *
	 * @return the current session
	 */
	protected Session getCurrentSession(){
		return sessionFactory.getCurrentSession();
	}
	protected Session getSnowflakeCurrentSession(){
		return snowflakeSessionFactory.getCurrentSession();
	}
	public Class<T> getPersistentClass() {
		return persistentClass;
	}



}
