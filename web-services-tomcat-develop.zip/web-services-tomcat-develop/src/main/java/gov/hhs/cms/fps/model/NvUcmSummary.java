package gov.hhs.cms.fps.model;

import java.io.Serializable;

public class NvUcmSummary implements Serializable {
	private String npi;
	private String caseStatus;
	private String zrStatus;
	private String leadInd;
	public String getNpi() {
		return npi;
	}
	public void setNpi(String npi) {
		this.npi = npi;
	}
	public String getCaseStatus() {
		return caseStatus;
	}
	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}
	public String getZrStatus() {
		return zrStatus;
	}
	public void setZrStatus(String zrStatus) {
		this.zrStatus = zrStatus;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((npi == null) ? 0 : npi.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NvUcmSummary other = (NvUcmSummary) obj;
		if (npi == null) {
			if (other.npi != null)
				return false;
		} else if (!npi.equals(other.npi))
			return false;
		return true;
	}
	public String getLeadInd() {
		return leadInd;
	}
	public void setLeadInd(String leadInd) {
		this.leadInd = leadInd;
	}

}
