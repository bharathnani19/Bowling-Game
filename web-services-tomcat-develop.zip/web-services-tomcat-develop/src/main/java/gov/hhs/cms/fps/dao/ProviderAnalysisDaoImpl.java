package gov.hhs.cms.fps.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import gov.hhs.cms.fps.model.AsrGenericCode;
import gov.hhs.cms.fps.model.ExclusionSet;
import gov.hhs.cms.fps.model.ExclusionSetItem;
import gov.hhs.cms.fps.model.FpsUser;
import gov.hhs.cms.fps.model.FpsWorkbenchAction;
import gov.hhs.cms.fps.model.FpsWorkbenchList;
import gov.hhs.cms.fps.model.LdapQuery;
import gov.hhs.cms.fps.model.PrioritizationShareGroup;
import gov.hhs.cms.fps.model.generated.FpsPrioritizationExclsnItem;
import gov.hhs.cms.fps.model.generated.FpsPrioritizationExclsnItemCtgryAsctn;
import gov.hhs.cms.fps.model.generated.FpsPrioritizationList;
import gov.hhs.cms.fps.model.generated.FpsPrioritizationListItem;
import gov.hhs.cms.fps.model.generated.FpsPrioritizationShareGrp;
import gov.hhs.cms.fps.model.generated.FpsPrioritizationShareGrpUserAsctn;
import gov.hhs.cms.fps.model.generated.FpsPrvdrAnlys;
import gov.hhs.cms.fps.model.generated.FpsUsrGuiPrfrnc;
import gov.hhs.cms.fps.util.FpsDomainObjectConverter;
import gov.hhs.cms.fps.util.FpsEnums.ModelProgram;
import gov.hhs.cms.fps.util.FpsEnums.WorkbenchListType;
import gov.hhs.cms.fps.util.LdapUtil;

@Repository("providerAnalysisDao")
public class ProviderAnalysisDaoImpl extends BaseDao<Integer, FpsPrvdrAnlys> implements ProviderAnalysisDao {

	@Autowired
	private static Logger logger = Logger.getLogger(ProviderAnalysisDaoImpl.class.getName());

	@Autowired
	private Environment env;

	@Override
	public List<FpsPrioritizationList> loadAsrListsByUser(FpsUser user) {
		return loadAsrListsByUser(user, false);
	}

	@Override
	public List<FpsPrioritizationList> loadAsrListsByUser(FpsUser user, boolean mdcd) {
		String userId = user.getUserId();
		List<FpsPrioritizationList> fpList = new ArrayList<>();
		Criteria c = getCurrentSession().createCriteria(FpsPrioritizationList.class, "list")
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
				// share removed in PI-25-4
//				.createAlias("list.fpsPrioritizationShareGrps", "group", JoinType.LEFT_OUTER_JOIN)
//				.createAlias("group.fpsPrioritizationShareGrpUserAsctns", "user", JoinType.LEFT_OUTER_JOIN)
				.add(Restrictions.eq("list.audtInsrtId", userId.toLowerCase()).ignoreCase())
				.add(Restrictions.eq("actvInd", "Y"));
				// share removed in PI-25-4
//				.add(Restrictions.or(Restrictions.eq("list.audtInsrtId", userId.toLowerCase()).ignoreCase(),
//						Restrictions.eq("user.shareUserId", userId.toLowerCase()).ignoreCase()))
//				.add(Restrictions.eq("actvInd", "Y"))
//				.add(Restrictions.disjunction().add(Restrictions.eq("user.actvInd", "Y"))
//						.add(Restrictions.isNull("user.actvInd"))
//						.add(Restrictions.and(Restrictions.eq("user.actvInd", "N"),
//								Restrictions.ne("user.shareUserId", userId.toLowerCase()).ignoreCase()))
//						);
		if (!mdcd) {
			// share removed in PI-25-4
//			c.add(Restrictions.or(Restrictions.eq("listType", "WORKING"), Restrictions.eq("listType", "EXCLUSION")));
			c.add(Restrictions.eq("listType", "WORKING"));

		} else {
			c.add(Restrictions.eq("listType", "WORKINGMDCD"));
		}
//		fpList.addAll(c.list());
//		c = getCurrentSession().createCriteria(FpsPrioritizationList.class, "list")
//				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
//				.add(Restrictions.eq("list.audtInsrtId", userId.toLowerCase()).ignoreCase())
//				.add(Restrictions.eq("actvInd", "Y")).add(Restrictions.eq("listType", "EXCLUSION"));
		fpList.addAll(c.list());
		return fpList;
	}

	@Override
	public List<FpsWorkbenchList> loadAsrNamesListsByUser(String userId) {
		return loadAsrNamesListsByUser(userId, "WORKING");
	}

	@Override
	public List<FpsWorkbenchList> loadAsrNamesListsByUser(String userId, String type) {
		Criteria c = getCurrentSession().createCriteria(FpsPrioritizationList.class, "list")
				.setProjection(Projections.projectionList().add(Projections.property("prioritizationListId"))
						.add(Projections.property("listNm")))
				.add(Restrictions.eq("list.audtInsrtId", userId).ignoreCase()).add(Restrictions.eq("actvInd", "Y"))
				.add(Restrictions.eq("listType", type));
		List<Object[]> rows = c.list();
		List<FpsWorkbenchList> lists = new ArrayList<FpsWorkbenchList>();
		for (Object[] row : rows) {
			FpsWorkbenchList list = new FpsWorkbenchList();
			list.setListId(Integer.parseInt(row[0].toString()));
			list.setListNm(StringEscapeUtils.unescapeHtml(row[1].toString()));

			lists.add(list);
		}
		return lists;
	}

	@Override
	public FpsPrioritizationList loadAsrListByListId(Integer listId) {
		Criteria c = getCurrentSession().createCriteria(FpsPrioritizationList.class, "list")
				.createAlias("list.fpsPrioritizationListItems", "items", JoinType.LEFT_OUTER_JOIN)
//				.createAlias("list.fpsPrioritizationExclsnItems", "exItems", JoinType.LEFT_OUTER_JOIN)
				.createAlias("items.fpsPrvdrAnlys", "asrs", JoinType.LEFT_OUTER_JOIN)
//				.createAlias("exItems.fpsPrvdrAnlys", "exAsrs", JoinType.LEFT_OUTER_JOIN)
				.add(Restrictions.eq("list.prioritizationListId", listId)).add(Restrictions.eq("actvInd", "Y"))
				.add(Restrictions.eq("list.actvInd", "Y"));
		FpsPrioritizationList f = (FpsPrioritizationList) c.uniqueResult();
		if (f != null) {
			Hibernate.initialize(f.getFpsPrioritizationListItems());
			Hibernate.initialize(f.getFpsPrioritizationExclsnItems());
		}

		return f;
	}

	@Override
	public List<Integer> loadAsrIdsByListId(Integer listId) {
		String sql = " select distinct asrpt_id  from fps2.FPS_PRIORITIZATION_LIST_ITEM  where PRIORITIZATION_LIST_ID = :listId and ACTV_IND = 'Y'";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("listId", Integer.valueOf(listId));
		List<Integer> asrs = new ArrayList<Integer>();
		List<Integer> rows = query.list();
		for (Integer i : rows) {
			asrs.add(i);
		}

		return asrs;
	}

	@Override
	public List<Integer> loadExcludedAsrIdsByListId(Integer listId) {
		String sql = " select distinct asrpt_id  from fps2.FPS_PRIORITIZATION_EXCLSN_ITEM  where PRIORITIZATION_LIST_ID = :listId and ACTV_IND = 'Y'";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("listId", Integer.valueOf(listId));
		List<Integer> asrs = new ArrayList<Integer>();
		List<Integer> rows = query.list();
		for (Integer i : rows) {
			asrs.add(i);
		}

		return asrs;
	}

	@Override
	public Integer saveListGroup(PrioritizationShareGroup grp, String shareUserId) {
		if (grp.getGrpType().equals("search")) {
			return saveSearchGroup(grp, shareUserId);
		}
		Integer dbGrpId = grp.getGrpId();
		if (grp.getGrpId() == null || grp.getGrpId() == 0) {
			// don't create a group if there are no user IDs submitted
			if (grp.getUserIds().size() > 0) {
				FpsPrioritizationShareGrp dbGrp = new FpsPrioritizationShareGrp();
				dbGrp.setShareNm(grp.getGrpNm());
				dbGrp.setShareTxt(grp.getGrpTxt());
				dbGrp.setActvInd("Y");
				dbGrp.setAudtInsrtId(shareUserId);
				dbGrp.setAudtInsrtTs(new Date());
				dbGrp.setAudtUpdtId(shareUserId);
				dbGrp.setAudtUpdtTs(new Date());
				dbGrpId = (Integer) getCurrentSession().save(dbGrp);
				getCurrentSession().createQuery(
						" update  FpsPrioritizationList set shareGrpId = :grpId,  audtUpdtId = :userId, audtUpdtTs = :currDate where prioritizationListId = :listId")
						.setInteger("grpId", dbGrpId).setInteger("listId", grp.getListId())
						.setDate("currDate", new Date()).setString("userId", shareUserId).executeUpdate();
			}
		} else {
			getCurrentSession().createQuery(" delete from   FpsPrioritizationShareGrpUserAsctn where shareGrpId = :id")
					.setInteger("id", dbGrpId).executeUpdate();
			// unshare the group if no user IDs are submitted
			if (grp.getUserIds().size() == 0) {
				getCurrentSession().createQuery(
						" update  FpsPrioritizationList set shareGrpId = null,  audtUpdtId = :userId, audtUpdtTs = :currDate where prioritizationListId = :listId")
						.setInteger("listId", grp.getListId()).setDate("currDate", new Date())
						.setString("userId", shareUserId).executeUpdate();
			}
		}

		for (String userId : grp.getUserIds()) {
			FpsPrioritizationShareGrpUserAsctn grpA = new FpsPrioritizationShareGrpUserAsctn();
			grpA.setShareGrpId(dbGrpId);
			grpA.setShareUserId(userId);
			grpA.setAudtInsrtId(shareUserId);
			grpA.setAudtUpdtId(shareUserId);
			grpA.setAudtInsrtTs(new Date());
			grpA.setAudtUpdtTs(new Date());
			grpA.setActvInd("Y");
			getCurrentSession().save(grpA);
			getCurrentSession().flush();
		}
		return dbGrpId;
	}

	@Override
	public Integer saveSearchGroup(PrioritizationShareGroup grp, String shareUserId) {
		Integer dbGrpId = grp.getGrpId();
		if (grp.getGrpId() == null || grp.getGrpId() == 0) {
			FpsPrioritizationShareGrp dbGrp = new FpsPrioritizationShareGrp();
			dbGrp.setShareNm(grp.getGrpNm());
			dbGrp.setActvInd("Y");
			dbGrp.setShareTxt(grp.getGrpTxt());
			dbGrp.setAudtInsrtId(shareUserId);
			dbGrp.setAudtInsrtTs(new Date());
			dbGrp.setAudtUpdtId(shareUserId);
			dbGrp.setAudtUpdtTs(new Date());
			dbGrpId = (Integer) getCurrentSession().save(dbGrp);
			getCurrentSession().createQuery(
					" update  FpsUsrGuiPrfrnc set shareGrpId = :grpId,  audtUpdtId = :userId, audtUpdtTs = :currDate where usrGuiPrfrncId = :listId")
					.setInteger("grpId", dbGrpId).setInteger("listId", grp.getListId()).setDate("currDate", new Date())
					.setString("userId", shareUserId).executeUpdate();
		} else {
			getCurrentSession().createQuery(" delete from   FpsPrioritizationShareGrpUserAsctn where shareGrpId = :id")
					.setInteger("id", dbGrpId).executeUpdate();
			if (grp.getUserIds() == null || grp.getUserIds().size() == 0) {
				getCurrentSession().createQuery(
						" update  FpsUsrGuiPrfrnc set shareGrpId = null,  audtUpdtId = :userId, audtUpdtTs = :currDate where usrGuiPrfrncId = :listId")
						.setInteger("listId", grp.getListId()).setDate("currDate", new Date())
						.setString("userId", shareUserId).executeUpdate();
			}

		}

		for (String userId : grp.getUserIds()) {
			FpsPrioritizationShareGrpUserAsctn grpA = new FpsPrioritizationShareGrpUserAsctn();
			grpA.setShareGrpId(dbGrpId);
			grpA.setShareUserId(userId);
			grpA.setAudtInsrtId(shareUserId);
			grpA.setAudtInsrtTs(new Date());
			grpA.setActvInd("Y");
			getCurrentSession().save(grpA);
			getCurrentSession().flush();
		}
		return dbGrpId;
	}

	@Override
	public FpsPrioritizationList pruneList(Integer listId, FpsWorkbenchAction items, String userId) {
		for (Integer item : items.getAsrptIds()) {
			getCurrentSession().createQuery(
					" update  FpsPrioritizationListItem set actvInd = 'N', actvIndUserId = :userId, actvIndTs = :currDate, audtUpdtId = :userId, audtUpdtTs = :currDate where asrptId = :asrptId and prioritizationListId = :id")
					.setInteger("id", listId).setInteger("asrptId", item).setDate("currDate", new Date())
					.setString("userId", userId).executeUpdate();
		}
		return null;
	}

	@Override
	public void pruneExclusionList(Integer listId, FpsWorkbenchAction items, String userId) {
		for (Integer item : items.getAsrptIds()) {
			getCurrentSession().createQuery(
					" update  FpsPrioritizationExclsnItem set actvInd = 'N', audtUpdtId = :userId, audtUpdtTs = :currDate, actvUpdtId = :userId, actvUpdtTs = :currDate, actvUpdtRsn='user removed' where asrptId = :asrptId and audtInsrtId = :userId")
					.setInteger("asrptId", item).setDate("currDate", new Date()).setString("userId", userId)
					.executeUpdate();
		}
	}

	@Override
	public Integer saveAsList(FpsPrioritizationList list) {
		list.setAudtInsrtTs(new Date());
		list.setActvInd("Y");
		list.setExclsnPublicInd("N");
		Integer listId = (Integer) getCurrentSession().save(list);
		if (list.getFpsPrioritizationListItems() != null) {
			for (FpsPrioritizationListItem item : list.getFpsPrioritizationListItems()) {
				item.setAudtInsrtId(list.getAudtInsrtId());
				item.setAudtUpdtId(list.getAudtInsrtId());
				item.setAudtInsrtTs(new Date());
				item.setAudtUpdtTs(new Date());
				item.setActvInd("Y");
				item.setActvIndTs(new Date());
				item.setActvIndUserId(list.getAudtInsrtId());
				item.setPrioritizationListId(listId);
				getCurrentSession().save(item);

			}
		}
		return listId;
	}

	@Override
	public FpsPrioritizationList addToList(Integer listId, FpsWorkbenchAction items, String userId) {
		List<Integer> asrs = loadAsrIdsByListId(listId);
		// make sure an ASR Id isn't added twice.
		for (Integer asrptId : items.getAsrptIds()) {
			if (asrs.contains(asrptId)) {
				continue;
			}
			FpsPrioritizationListItem item = new FpsPrioritizationListItem();
			item.setPrioritizationListId(listId);
			item.setAsrptId(asrptId);
			item.setActvInd("Y");
			item.setActvIndUserId(userId);
			item.setActvIndTs(new Date());
			item.setAudtInsrtId(userId);
			item.setAudtInsrtTs(new Date());
			item.setAudtUpdtId(userId);
			item.setAudtUpdtTs(new Date());
			getCurrentSession().save(item);
		}
		return null;
	}

	@Override
	public FpsPrioritizationList renameList(Integer listId, FpsPrioritizationList list, WorkbenchListType type) {
		String listNm = FpsDomainObjectConverter.clean(list.getListNm(), 100);
		switch (type) {
		case ASRLIST:
			getCurrentSession()
					.createQuery(" update FpsPrioritizationList set listNm = :listNm where prioritizationListId = :id")
					.setInteger("id", listId).setString("listNm", listNm).executeUpdate();
			break;
		case ASRSEARCH:
			getCurrentSession().createQuery(" update FpsUsrGuiPrfrnc set prfrncNm = :listNm where usrGuiPrfrncId = :id")
					.setInteger("id", listId).setString("listNm", listNm).executeUpdate();
			break;
		}

		return loadAsrListByListId(listId);
	}

	@Override
	public List<FpsPrioritizationShareGrpUserAsctn> loadGroupMembers(Integer groupId) {
		Criteria c = getCurrentSession().createCriteria(FpsPrioritizationShareGrpUserAsctn.class, "users")
				.add(Restrictions.eq("shareGrpId", groupId));
		return (List<FpsPrioritizationShareGrpUserAsctn>) c.list();
	}

	@Override
	@Cacheable("oktausersmdcd")
	public List<FpsUser> loadOpenAmUsersMdcd() {

		List<FpsUser> fpsUsers = LdapUtil.getAllOktaUsers(true);
		;

		return fpsUsers;
	}

	@Override
	@Cacheable("oktausers")
	public List<FpsUser> loadOpenAmUsers() {
		String oktaEnabled = this.env.getProperty("okta.enabled", "false");

		List<FpsUser> fpsUsers = null;
		if ("true".equals(oktaEnabled)) {
			fpsUsers = LdapUtil.getAllOktaUsers();
		} else {
			String ldapUser = this.env.getProperty("ldap.user");
			String ldapUrl = this.env.getProperty("ldap.url");
			String ldapPasswordEnc = this.env.getProperty("ldap.password");
			String ldapPassword = new String(Base64.decodeBase64(ldapPasswordEnc.getBytes()));
			String ldapBaseDn = this.env.getProperty("ldap.baseDn");
			LdapQuery query = new LdapQuery();
			query.setUrl(ldapUrl);
			query.setBaseDn(ldapBaseDn);
			query.setPassword(ldapPassword);
			query.setUsername(ldapUser);
			String localMode = this.env.getProperty("ldap.test");
			query.setMode(localMode != null ? "Y" : "N");
			query.setFilter("(&(uid=*)(employeeType=*)(businessCategory=*))");
			fpsUsers = LdapUtil.getOpenAMUser(query);

		}

		return fpsUsers;
	}

	@Override
	public List<FpsUsrGuiPrfrnc> getSavedSearchesForUser(String userId) {
		return getSavedSearchesForUser(userId, ModelProgram.MDCR);
	}

	@Override
	public List<FpsUsrGuiPrfrnc> getSavedSearchesForUser(String userId, ModelProgram pgm) {
		List<FpsUsrGuiPrfrnc> results = getCurrentSession().createCriteria(FpsUsrGuiPrfrnc.class, "pref")
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
//				.createAlias("pref.fpsPrioritizationShareGrps", "group", JoinType.LEFT_OUTER_JOIN)
//				.createAlias("group.fpsPrioritizationShareGrpUserAsctns", "user", JoinType.LEFT_OUTER_JOIN)
				.add(pgm.equals(ModelProgram.BOTH) ? Restrictions.ilike("prfrncGrp", "asrSearch%")
						: Restrictions.eq("prfrncGrp", pgm.equals(ModelProgram.MDCD) ? "asrSearchMdcd" : "asrSearch"))
//				.add(Restrictions.eq("user.actvInd", "Y"))
				.add(Restrictions.eq("usrId", userId).ignoreCase())
				// share removed in PI-25-4		
//				.add(Restrictions.isNull("user.actvInd"))
//				.add(Restrictions.and(Restrictions.eq("user.actvInd", "N"),
//								Restrictions.ne("user.shareUserId", userId.toLowerCase()).ignoreCase())))
//				.add(Restrictions.or(Restrictions.eq("usrId", userId).ignoreCase(),
//						Restrictions.eq("user.shareUserId", userId).ignoreCase()))
				.addOrder(Order.asc("prfrncNm").ignoreCase()).list();
	
		return results;
	}

	@Override
	public List<FpsUsrGuiPrfrnc> getP1SavedSearch(String userId, String searchName) {

		List<FpsUsrGuiPrfrnc> results = getCurrentSession().createCriteria(FpsUsrGuiPrfrnc.class, "prefP1")
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
				.createAlias("prefP1.fpsPrioritizationShareGrps", "group", JoinType.LEFT_OUTER_JOIN)
				.createAlias("group.fpsPrioritizationShareGrpUserAsctns", "user", JoinType.LEFT_OUTER_JOIN)
				.add(Restrictions.eq("prfrncGrp", searchName))
				.add(Restrictions.eq("usrId", "fpsp1").ignoreCase())
				.add(Restrictions.or(
						Restrictions.isNull("user.shareUserId"),
						Restrictions.conjunction()
							.add(Restrictions.eq("user.shareUserId", userId.toLowerCase()).ignoreCase())
							.add(	Restrictions.eq("user.actvInd", "Y")))
						)
				

				.list();

		return results;
	}

	@Override
	public FpsUser loadOpenAmUser(String userId) {
//		String ldapUser = this.env.getProperty("ldap.user");
//		String ldapUrl = this.env.getProperty("ldap.url");
//		String ldapPasswordEnc = this.env.getProperty("ldap.password");
//		String ldapPassword = new String(Base64.decodeBase64(ldapPasswordEnc.getBytes()));
//		String ldapBaseDn = this.env.getProperty("ldap.baseDn");
//		LdapQuery query = new LdapQuery();
//		query.setUrl(ldapUrl);
//		query.setBaseDn(ldapBaseDn);
//		query.setPassword(ldapPassword);
//		query.setUsername(ldapUser);
//		String localMode = this.env.getProperty("ldap.test");
//		query.setMode(localMode != null ? "Y" : "N");
//		query.setFilter("(uid=" + userId + ")");
//		query.setSearchVal(userId);
		List<FpsUser> fpsUsers = null;

		fpsUsers = LdapUtil.getUser(userId);

		return fpsUsers != null && fpsUsers.size() > 0 ? fpsUsers.get(0) : null;
	}

	@Override
	public FpsPrioritizationShareGrp loadSharedUsers(Integer shareGrpId) {
		return (FpsPrioritizationShareGrp) getCurrentSession()
				.createQuery("from FpsPrioritizationShareGrp where shareGrpId = :shareGrpId")
				.setInteger("shareGrpId", shareGrpId).uniqueResult();
	}

	@Override
	public void markAsrAsPrioritized(Integer listItemId, String userId) {
		getCurrentSession().createQuery(
				" update  FpsPrioritizationListItem set prioritizedInd = 'Y', prioritizedByUserId = :userId, prioritizedByUserTs = :currDate, audtUpdtId = :userId, audtUpdtTs = :currDate where prioritizationListItemId = :id")
				.setInteger("id", listItemId).setDate("currDate", new Date()).setString("userId", userId)
				.executeUpdate();

	}

	@Override
	public void markAsrAsPrioritizedMdcd(Integer listItemId, String userId) {
		markAsrAsPrioritizedMdcd(listItemId, userId);

	}

	@Override
	public void deleteList(Integer listId, String userId) {
		getCurrentSession().createQuery(
				" update FpsPrioritizationList set actvInd = 'N', audtUpdtId= :userId, audtUpdtTs = :currDate where prioritizationListId = :id")
				.setInteger("id", listId).setDate("currDate", new Date()).setString("userId", userId).executeUpdate();
	}

	@Override
	public FpsUsrGuiPrfrnc loadSavedSearchBySearchId(Integer listId) {

		FpsUsrGuiPrfrnc results = (FpsUsrGuiPrfrnc) getCurrentSession().createCriteria(FpsUsrGuiPrfrnc.class, "pref")
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).add(Restrictions.eq("usrGuiPrfrncId", listId))
				.uniqueResult();
		return results;

	}

	@Override
	public void deleteSearch(Integer listId, String userId) {
		getCurrentSession().createQuery(" delete from FpsUsrGuiPrfrnc where usrGuiPrfrncId = :id")
				.setInteger("id", listId).executeUpdate();

	}

	@Override
	public synchronized FpsPrioritizationList addToList(Integer listId, ExclusionSet exItems, String userId) {
		List<Integer> asrs = loadExcludedAsrIdsByListId(listId);

		for (ExclusionSetItem exItem : exItems.getExclusions()) {
			// deactivate any current exclusions for that ASR
			if (asrs.contains(exItem.getAsrptId())) {
				getCurrentSession().createQuery(
						" update  FpsPrioritizationExclsnItem set actvInd = 'N', audtUpdtId = :userId, audtUpdtTs = current_timestamp() where asrptId = :asrptId and prioritizationListId = :listId and actvInd = 'Y'")
						.setInteger("asrptId", exItem.getAsrptId()).setInteger("listId", listId)
						.setString("userId", userId).executeUpdate();
			}
			FpsPrioritizationExclsnItem item = new FpsPrioritizationExclsnItem();
			item.setPrioritizationListId(listId);
			item.setAsrptId(exItem.getAsrptId());
			item.setActvInd("Y");

			item.setAudtInsrtId(userId);
			item.setAudtInsrtTs(new Date());
			item.setAudtUpdtId(userId);
			item.setAudtUpdtTs(new Date());
			item.setRollOffDt(exItem.getRollOffDt());

			String s = FpsDomainObjectConverter.stripMSWordCharacters(exItem.getComments());
			item.setExclsnCmt(s);
//			

			getCurrentSession().save(item);
			Set<FpsPrioritizationExclsnItemCtgryAsctn> cats = new HashSet<FpsPrioritizationExclsnItemCtgryAsctn>();

			for (AsrGenericCode excl : exItem.getExclusions()) {
				FpsPrioritizationExclsnItemCtgryAsctn cat = new FpsPrioritizationExclsnItemCtgryAsctn();

				cat.setAudtInsrtId(userId);
				cat.setAudtInsrtTs(new Date());
				cat.setExclsnCtgryCd(excl.getCode());
				cat.setPrioritizationExclsnItemId(item.getPrioritizationExclsnItemId());
//				cat.setFpsPrioritizationExclsnItem(item);
				getCurrentSession().save(cat);
				cats.add(cat);
			}
//			item.setFpsPrioritizationExclsnItemCtgryAsctns(cats);
//			getCurrentSession().save(item);	
			getCurrentSession().flush();
		}
		return null;
	}

	@Override
	public Integer findExclusionListByUserId(String userId) {
		Criteria c = getCurrentSession().createCriteria(FpsPrioritizationList.class, "list")
				.add(Restrictions.eq("list.audtInsrtId", userId.toLowerCase()).ignoreCase())
				.add(Restrictions.eq("actvInd", "Y")).add(Restrictions.eq("listType", "EXCLUSION"));
		FpsPrioritizationList f = (FpsPrioritizationList) c.uniqueResult();
		return f != null ? f.getPrioritizationListId() : null;
	}

	@Override
	public List<FpsPrioritizationExclsnItem> loadExclusionListHistoryByAsrId(Integer asrptId, String userId,
			String businessCategory) {
		String sql = "from FpsPrioritizationExclsnItem exItems where exItems.asrptId = :asrptId and  exItems.prioritizationListId in ";
		String sql2 = " (select distinct list.prioritizationListId from FpsPrioritizationList list where list.listType = 'EXCLUSION' ";
		boolean notCms = false;
//		DetachedCriteria subquery = DetachedCriteria.forClass(FpsPrioritizationList.class, "list")
//				.add(Restrictions.eq("list.listType", "EXCLUSION"))
//				.add(Restrictions.eq("list.actvInd", "Y"));
		// pimasc contractors can see all
		if (!"CMS".equals(businessCategory) && !FpsDomainObjectConverter.isPimascContractor(businessCategory)) {
			sql2 += " and (lower(list.audtInsrtId) = :userId or (list.usrJrsdctn = :businessCategory and list.exclsnPublicInd = 'Y')) ";
//					subquery.add(Restrictions.or(Restrictions.eq("list.audtInsrtId", userId).ignoreCase(), 
//							Restrictions.and(Restrictions.eq("list.usrJrsdctn", businessCategory).ignoreCase(), 
//									Restrictions.eq("list.exclsnPublicInd", "Y").ignoreCase())));
			notCms = true;
		}
		sql2 += " )";

//				subquery.setProjection(Projections.distinct(Projections.property("list.prioritizationListId")));
//		Criteria c = getCurrentSession().createCriteria(FpsPrioritizationExclsnItem.class, "items")
//				.add(Restrictions.eq("items.asrptId",asrptId))
//				.addOrder(Order.desc("audtInsrtTs"))
//				.add(Subqueries.propertyIn("prioritizationListId", subquery));

		// .add(Restrictions.eq("items.actvInd", "Y"))
		;
		String queryStringx = sql + sql2 + " order by exItems.audtInsrtTs desc";
		String queryString = "select " + "fpspriorit0_.PRIORITIZATION_EXCLSN_ITEM_ID as PRIORITI1_117_, "
				+ "fpspriorit0_.ACTV_IND as ACTV_IND2_117_, " + "fpspriorit0_.ACTV_UPDT_ID as ACTV_UPD3_117_, "
				+ "fpspriorit0_.ACTV_UPDT_RSN as ACTV_UPD4_117_, " + "fpspriorit0_.ACTV_UPDT_TS as ACTV_UPD5_117_, "
				+ "fpspriorit0_.ASRPT_ID as ASRPT_ID6_117_, " + "fpspriorit0_.AUDT_INSRT_ID as AUDT_INS7_117_, "
				+ "fpspriorit0_.AUDT_INSRT_TS as AUDT_INS8_117_, " + "fpspriorit0_.AUDT_UPDT_ID as AUDT_UPD9_117_, "
				+ "fpspriorit0_.AUDT_UPDT_TS as AUDT_UP10_117_, " + "fpspriorit0_.EXCLSN_CMT as EXCLSN_11_117_, "
				+ "fpspriorit0_.PRIORITIZATION_LIST_ID as PRIORIT12_117_, "
				+ "fpspriorit0_.EXCLSN_AUTO_INACTV_DT as EXCLSN_13_117_ "
				+ "from FPS_PRIORITIZATION_EXCLSN_ITEM fpspriorit0_ " + "where   fpspriorit0_.ASRPT_ID= :asrptId ";
		if (!"CMS".equals(businessCategory) && !FpsDomainObjectConverter.isPimascContractor(businessCategory)) {
			notCms = true;
			queryString += " and " + "( " + "   fpspriorit0_.PRIORITIZATION_LIST_ID in " + "   ( " + "      select "
					+ "      distinct fpspriorit1_.PRIORITIZATION_LIST_ID "
					+ "      from fps2.FPS_PRIORITIZATION_LIST fpspriorit1_ "
					+ "      where fpspriorit1_.LIST_TYPE_CD='EXCLUSION' " + "      and " + "      ( "
					+ "         lower(fpspriorit1_.AUDT_INSRT_ID)= :userId or fpspriorit1_.USR_JRSDCTN= :businessCategory "
					+ "         and fpspriorit1_.EXCLSN_PUBLIC_IND='Y' " + "      ) " + "   ) " + ") ";
		}
		queryString += " order by fpspriorit0_.AUDT_INSRT_TS desc  ";
		org.hibernate.Query q = getCurrentSession().createSQLQuery(queryString).setInteger("asrptId", asrptId);
		if (notCms) {
			q.setString("userId", userId.toLowerCase());
			q.setString("businessCategory", businessCategory);
		}
		List<FpsPrioritizationExclsnItem> returnItems = new ArrayList<>();

		List<Object[]> tempItems = q.list();
		for (Object[] tempItem : tempItems) {
			FpsPrioritizationExclsnItem returnItem = new FpsPrioritizationExclsnItem();
			returnItem.setPrioritizationExclsnItemId((Integer) tempItem[0]);
			if (tempItem[1] != null) {
				returnItem.setActvInd(((Character) tempItem[1]).toString());
			}
			returnItem.setAudtInsrtTs((Date) tempItem[7]);
			returnItem.setAudtInsrtId((String) tempItem[6]);
			returnItem.setActvUpdtRsn((String) tempItem[3]);
			returnItem.setAsrptId((Integer) tempItem[5]);
			returnItem.setExclsnCmt((String) tempItem[10]);
			returnItem.setPrioritizationListId((Integer) tempItem[11]);
			if (tempItem[4] != null) {
				returnItem.setActvUpdtTs((Date) tempItem[4]);
			}
			String asctnSql = "from FpsPrioritizationExclsnItemCtgryAsctn where prioritizationExclsnItemId = :prioritizationExclsnItemId";
			org.hibernate.Query q2 = getCurrentSession().createQuery(asctnSql).setInteger("prioritizationExclsnItemId",
					returnItem.getPrioritizationExclsnItemId());
			List<FpsPrioritizationExclsnItemCtgryAsctn> asctns = q2.list();
			returnItem.setFpsPrioritizationExclsnItemCtgryAsctns(new HashSet<>(asctns));
			returnItems.add(returnItem);
		}
		return returnItems;
	}

	@Override
	public List<FpsPrvdrAnlys> loadPicExclusionList() {
		DetachedCriteria subquery = DetachedCriteria.forClass(FpsPrioritizationList.class, "list")
				.createAlias("list.fpsPrioritizationExclsnItems", "items")
				.add(Restrictions.eq("list.listType", "EXCLUSION")).add(Restrictions.eq("list.actvInd", "Y"))
				.setProjection(Projections.distinct(Projections.property("items.asrptId")));
		Criteria c = getCurrentSession().createCriteria(FpsPrvdrAnlys.class, "asrs")

				.add(Subqueries.propertyIn("asrptId", subquery));

		return c.list();
	}

	@Override
	public void updateExclusion(Integer listId, ExclusionSetItem item, String userId) {
		FpsPrioritizationExclsnItem dbItem = (FpsPrioritizationExclsnItem) getCurrentSession()
				.byId(FpsPrioritizationExclsnItem.class).load(item.getItemId());
//		dbItem.setAsrptId(item.getAsrptId());
		dbItem.setAudtUpdtId(userId);
		dbItem.setAudtUpdtTs(new Date());
		dbItem.setExclsnCmt(item.getComments());
		dbItem.setRollOffDt(item.getRollOffDt());
		if (dbItem.getFpsPrioritizationExclsnItemCtgryAsctns() != null) {
			List<FpsPrioritizationExclsnItemCtgryAsctn> toRemove = new ArrayList<>();

			for (FpsPrioritizationExclsnItemCtgryAsctn dbEx : dbItem.getFpsPrioritizationExclsnItemCtgryAsctns()) {
				AsrGenericCode ex = new AsrGenericCode(dbEx.getExclsnCtgryCd());
				if (!item.getExclusions().contains(ex)) {
					toRemove.add(dbEx);
				}
			}
			dbItem.getFpsPrioritizationExclsnItemCtgryAsctns().removeAll(toRemove);

		}
		for (AsrGenericCode ex : item.getExclusions()) {

			FpsPrioritizationExclsnItemCtgryAsctn cat = new FpsPrioritizationExclsnItemCtgryAsctn(ex.getCode(),
					item.getItemId());
			if (!dbItem.getFpsPrioritizationExclsnItemCtgryAsctns().contains(cat)) {
				cat.setAudtInsrtId(userId);
				cat.setAudtInsrtTs(new Date());
				dbItem.getFpsPrioritizationExclsnItemCtgryAsctns().add(cat);
			}
		}
		getCurrentSession().merge(dbItem);
		getCurrentSession().flush();
	}

	@Override
	public void toggleExclusionSetVisibility(String userId, boolean toggle) {
		Integer listId = findExclusionListByUserId(userId);
		getCurrentSession().createQuery(
				" update  FpsPrioritizationList set audtUpdtId = :userId, audtUpdtTs = :currDate,exclsnPublicInd = :toggle  where prioritizationListId = :listId")
				.setInteger("listId", listId).setDate("currDate", new Date()).setString("userId", userId)
				.setString("toggle", (toggle ? "Y" : "N")).executeUpdate();

	}

	@Override
	public void archiveList(Integer groupId, String userId) {
		// temporary Phase 1 saved search
		if (groupId > 99999990) {
			FpsPrioritizationShareGrpUserAsctn asctn = new FpsPrioritizationShareGrpUserAsctn();
			asctn.setActvInd("N");
			asctn.setShareGrpId(groupId);
			asctn.setShareUserId(userId);
			asctn.setAudtInsrtId(userId);
			asctn.setAudtInsrtTs(new Date());
			getCurrentSession().save(asctn);
		}else {
		getCurrentSession().createQuery(
				" update FpsPrioritizationShareGrpUserAsctn set actvInd = 'N', audtUpdtId= :userId, audtUpdtTs = :currDate where shareGrpId = :groupId and lower(shareUserId) = :userId")
				.setInteger("groupId", groupId).setDate("currDate", new Date())
				.setString("userId", userId.toLowerCase()).executeUpdate();
		}

	}

}
