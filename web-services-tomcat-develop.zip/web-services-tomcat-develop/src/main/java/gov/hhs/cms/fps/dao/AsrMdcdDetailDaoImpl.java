package gov.hhs.cms.fps.dao;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gov.hhs.cms.fps.model.AsrDetailAlert;
import gov.hhs.cms.fps.model.AsrDetailTotalCostZone;
import gov.hhs.cms.fps.model.AsrDetailViewRequest;
import gov.hhs.cms.fps.model.AsrGenericCode;
import gov.hhs.cms.fps.model.AvailableClaims;
import gov.hhs.cms.fps.model.ClaimsSearchParameter;
import gov.hhs.cms.fps.model.ClaimsSolrStream;
import gov.hhs.cms.fps.model.ClaimsSolrStreamResult;
import gov.hhs.cms.fps.model.FpsCommonBeneficiary;
import gov.hhs.cms.fps.model.FpsVisualization;
import gov.hhs.cms.fps.model.FpsVisualizationEdge;
import gov.hhs.cms.fps.model.MdcdModelState;
import gov.hhs.cms.fps.model.SolrStreamAsrDetailClaimLineItem;
import gov.hhs.cms.fps.model.generated.FpsAlert;
import gov.hhs.cms.fps.model.generated.FpsAlertClmAsctn;
import gov.hhs.cms.fps.model.generated.FpsAlertMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrDetailsPageCounts;
import gov.hhs.cms.fps.model.generated.FpsAsrpt;
import gov.hhs.cms.fps.model.generated.FpsAsrptMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptPrrtyScreDtlVw;
import gov.hhs.cms.fps.model.generated.FpsAsrptRiskScreHstryVw;
import gov.hhs.cms.fps.model.generated.FpsClmMdcd;
import gov.hhs.cms.fps.model.generated.FpsCstmTblClmnNameMdcd;
import gov.hhs.cms.fps.model.generated.FpsCstmTblDtlMdcd;
import gov.hhs.cms.fps.model.generated.FpsCstmTblLabelSnpshtMdcd;
import gov.hhs.cms.fps.model.generated.FpsCstmTblMdcd;
import gov.hhs.cms.fps.model.generated.FpsEditNumRfrnc;
import gov.hhs.cms.fps.model.generated.FpsModel;
import gov.hhs.cms.fps.model.generated.FpsRcncltnClmline;
import gov.hhs.cms.fps.model.generated.FpsRiskScreRptCardDtl;
import gov.hhs.cms.fps.model.generated.FpsRptCardAttrLabelMdcd;
import gov.hhs.cms.fps.model.generated.FpsRptCardDtlMdcd;
import gov.hhs.cms.fps.model.generated.FpsRptCardLabelSnpShtMdcd;
import gov.hhs.cms.fps.model.generated.FpsRptCardRskSnaDtlMdcd;
import gov.hhs.cms.fps.model.generated.FpsSplmntlVizDtlMdcd;
import gov.hhs.cms.fps.model.generated.FpsSplmntlVizLabelSnpshtMdcd;
import gov.hhs.cms.fps.model.generated.MdcdBaseClaim;
import gov.hhs.cms.fps.util.EnhancedRiskScoreContribOrder;
import gov.hhs.cms.fps.util.FpsDomainObjectConverter;
import gov.hhs.cms.fps.util.FpsEnums.SolrClaimType;
import gov.hhs.cms.fps.util.GenericOrderBy;

@Repository(value = "asrMdcdDetailDao")
public class AsrMdcdDetailDaoImpl extends BaseDao<Integer, FpsAsrpt> implements AsrMdcdDetailDao {
	private static final Logger logger = Logger.getLogger(AsrMdcdDetailDaoImpl.class.getName());
	@Value("${solr.collection.viz.edges}")
	private String collVizEdges;
	@Value("${solr.collection.viz.nodes}")
	private String collVizNodes;
	@Value("${solr.collection.viz.hha.edges}")
	private String collVizHhaEdges;
	@Value("${solr.collection.viz.hha.nodes}")
	private String collVizHhaNodes;
	@Value("${solr.collection.viz.dme.edges}")
	private String collVizDmeEdges;
	@Value("${solr.collection.viz.dme.nodes}")
	private String collVizDmeNodes;
	private static List<String> cmsRoles = Arrays.asList(new String[] { "cms", "gdit", "deloitte", "ngc", "peraton" , "doj"});
	private static List<String> naRoles = Arrays.asList(new String[] { "mac", "medic" });
	@Autowired
	private FpsHubDao fpsHubDao;
	@Autowired
	private Environment env;
	@Value("${buildfor}")
	private String buildFor;

	@Override
	public List<? extends MdcdBaseClaim> loadClaimsForAsr2(ClaimsSearchParameter search, int pageSize, int index) {
		search.setPageSize(pageSize);
		search.setStartAt(index);
		Criteria query = buildSnowflakeClaimsQuery2(search, false);

		query.setMaxResults(pageSize);
		query.setFirstResult(index);

		logger.info("start mdcd snowflake query");
		List<? extends FpsClmMdcd> rows2 = query.list();
		logger.info("end mdcd snowflake query with rows = " + rows2.size());

		return rows2;
	}

	@Override
	public List<FpsCstmTblMdcd> loadCustomTablesForModel(String modelBusnsId, String npi, String state) {
		List<FpsCstmTblMdcd> tables = getCurrentSession().createCriteria(FpsCstmTblMdcd.class, "table")

				.add(Restrictions.eq("modelBusnsId", modelBusnsId))
				.addOrder(new GenericOrderBy("cast(trim(cstm_Tbl_id) as INTEGER)"))

				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return tables;
	}

	@Transactional
	@Override
	public List<AsrDetailAlert> loadAlertsForProvider(String npi) {
		List<AsrDetailAlert> alerts = new ArrayList<AsrDetailAlert>();
		Calendar cal180 = Calendar.getInstance();
		cal180.add(Calendar.DATE, -365);

		List<Object[]> objs = getCurrentSession().createCriteria(FpsAlertMdcd.class, "fpsAlert")
				.add(Restrictions.eq("subjId", npi)).add(Restrictions.ge("alertCreatDt", cal180.getTime()))
				.createAlias("fpsAlert.fpsModel", "model")
				.setProjection(Projections.projectionList().add(Projections.max("alertCreatDt"))
						.add(Projections.groupProperty("model.modelBusnsId"))
						.add(Projections.groupProperty("alertStusCd")))
				.addOrder(Order.asc("alertStusCd")).addOrder(Order.asc("model.modelBusnsId").ignoreCase()).list();
		if (objs != null) {
			for (Object[] obj : objs) {
				AsrDetailAlert alert = new AsrDetailAlert();
				alert.setModelBusnsId((String) obj[1]);
				if (obj[0] != null) {
					Date d = (Date) obj[0];
					alert.setCreateDt(FpsDomainObjectConverter.convertDateToShortString(d));
				}
				String status = (String) obj[2];
				alert.setStatus("12".equalsIgnoreCase(status) ? "New" : "Aged");
				alerts.add(alert);
			}
		}
		return alerts;
	}

	@Transactional
	@Override
	public List<FpsAlertMdcd> loadAlertsForByModelAndNpi(String model, String npi, String state) {
		List<FpsAlertMdcd> alerts = getCurrentSession().createCriteria(FpsAlertMdcd.class, "alert")
				.createAlias("alert.fpsModel", "model", JoinType.INNER_JOIN)
				.add(Restrictions.eq("model.modelBusnsId", model)).add(Restrictions.eq("subjId", npi))
				.add(Restrictions.ne("alertStusCd", "14")).addOrder(Order.desc("alertCreatDt")).list();

		return alerts;
	}

	@Transactional
	@Override
	public FpsAlertMdcd loadAlertByAlertId(Integer alertId) {
		FpsAlertMdcd alerts = (FpsAlertMdcd) getCurrentSession().createCriteria(FpsAlertMdcd.class, "alert")
				.createAlias("alert.fpsModel", "model", JoinType.INNER_JOIN).add(Restrictions.eq("alertId", alertId))
				.uniqueResult();

		return alerts;
	}

	@Override
	public List<FpsCstmTblClmnNameMdcd> loadCustomTablesForModelColumns(String modelBusnsId, String customTableId,
			String state) {
		List<FpsCstmTblClmnNameMdcd> tables = getCurrentSession().createCriteria(FpsCstmTblClmnNameMdcd.class, "table")
				.add(Restrictions.eq("table.cstmTblId", customTableId))
				.add(Restrictions.eq("table.modelBusnsId", modelBusnsId))
				.addOrder(new GenericOrderBy("cast(trim(cstm_Tbl_Clmn_Num) as INTEGER)"))
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return tables;
	}

	@Override
	public List<FpsCstmTblDtlMdcd> loadCustomTablesForModelData(String modelBusnsId, String npi, String state,
			Date modelRunDate, String cstmTblId) {
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

		String dStr = format.format(modelRunDate);
		List<FpsCstmTblDtlMdcd> tables = getCurrentSession().createCriteria(FpsCstmTblDtlMdcd.class, "table")
				.createAlias("table.mdcdGeoLclStateCd", "stateCd", JoinType.INNER_JOIN)
				.add(Restrictions.eq("stateCd.geoMdcdUspsStateCd", state)).add(Restrictions.eq("table.npiNum", npi))
				.add(Restrictions.eq("table.modelBusnsId", modelBusnsId))
				.add(Restrictions.or(Restrictions.eq("table.modelRunDt", modelRunDate),
						Restrictions.isNull("table.modelRunDt")))
				.add(Restrictions.eq("table.cstmTblId", cstmTblId))
				.addOrder(new GenericOrderBy("cast(trim(cstm_Tbl_row_Num) as INTEGER)"))
				.addOrder(new GenericOrderBy("cast(trim(cstm_Tbl_Clmn_Num) as INTEGER)"))
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return tables;
	}

	@Transactional(readOnly = true)
	@Override
	public FpsAsrptMdcd getAsrDetail(AsrDetailViewRequest request) {
		return getAsrDetail(request.getParameters().getAsr(), null);
	}

	@Transactional(readOnly = true)
	@Override
	public FpsAsrptMdcd getAsrDetail(List<Integer> ids, String xtab) {
		Criteria c = getCurrentSession().createCriteria(FpsAsrptMdcd.class, "fpsAsrpt");
		if ((ids != null) && (ids.size() > 0)) {
			if (ids.size() > 1) {
				c.add(Restrictions.in("asrptId", ids));
			} else {
				c.add(Restrictions.eq("asrptId", ids.get(0)));
			}
			FpsAsrptMdcd retval = new FpsAsrptMdcd();
			c.setMaxResults(100);
			List<FpsAsrptMdcd> l = c.list();
			if ((l != null) && (l.size() > 0)) {
				retval = (FpsAsrptMdcd) l.get(0);
			}
			return retval;
		}
		return null;
	}

	@Transactional
	@Override
	public List<AsrDetailTotalCostZone> loadTotalCostByZone(int asrptId) {
		List<AsrDetailTotalCostZone> items = new ArrayList<AsrDetailTotalCostZone>();

		// get the distinct list of claims, then map the state to the zone.
		// DME = clm_bene_state_cd
		// A = CLM_BLG_PRVDR_USPS_STATE_CD. State code in CCN format. Join on
		// the State/CCN table to get the alpha coe
		// B = CLM_BLG_PRVDR_USPS_STATE_CD
		SQLQuery query = getCurrentSession().createSQLQuery(

				"with claims as (select " + "  CLM_STATE_CD, " + "CLM_SRC_TYPE, " + "CLM_COST, " + "CLM_CNT "
						+ "from fps2.FPS_ASRPT_ZONE_COST_CNT_VW " + "where asrpt_id = :asrptId " + "), "
						+ "claimupics as " + "( " + "   select "
						+ " coalesce(refstate.cntrctr_desc,'Unknown') as zone, " + "CLM_CNT, " + "CLM_COST "
						+ "from claims "
						+ "left join fps2.fps_state_cntrctr_info state on state.STATE_CD = CLM_STATE_CD "
						+ "left join FPS2.fps_cntrctr_rfrnc refstate on state.UPIC = refstate.cntrctr_cd "
						+ " ) " + "select " + "zone, sum(CLM_CNT),sum(CLM_COST  ) " + "from claimupics "
						+ " group by zone " + "order by case when zone = 'Unknown' then 'ZZ' else zone end ");
		List<Object[]> rows = query.setInteger("asrptId", asrptId).list();
		for (Object[] row : rows) {
			AsrDetailTotalCostZone item = new AsrDetailTotalCostZone();
			if (row[0] != null) {
				item.setZone(row[0].toString());
				item.setTotalClaimLines(Integer.parseInt(row[1].toString()));

				item.setTotalCost(FpsDomainObjectConverter.convertDecimalToDollar(new BigDecimal(row[2].toString())));
//				item.setTotalClaimLinesAll(Integer.parseInt(row[2].toString()));
//
//				item.setTotalCostAll(FpsDomainObjectConverter.convertDecimalToDollar(new BigDecimal(row[3].toString())));
				items.add(item);
			}
		}
		return items;
	}

	@Transactional
	@Override
	public List<AsrDetailTotalCostZone> loadTotalPaymentByZone(int asrptId) {
		List<AsrDetailTotalCostZone> items = new ArrayList<AsrDetailTotalCostZone>();

		SQLQuery query = getCurrentSession().createSQLQuery(

				" select " + "  CNTRCTR_CD, CLM_CNT, CLM_PMT_AMT "
						+ "from fps2.FPS_PRIORITIZATION_WKLY_DATASET_CLM_AMT_BY_JURISDICTION "
						+ "where asrpt_id = :asrptId "
						+ "order by case when lower(CNTRCTR_CD) = 'unknown' then 'ZZ' else CNTRCTR_CD end ");
		List<Object[]> rows = query.setInteger("asrptId", asrptId).list();
		for (Object[] row : rows) {
			AsrDetailTotalCostZone item = new AsrDetailTotalCostZone();
			if (row[0] != null) {
				item.setZone(row[0].toString());
				item.setTotalClaimLines(Integer.parseInt(row[1].toString()));

				item.setTotalCost(FpsDomainObjectConverter.convertDecimalToDollar(new BigDecimal(row[2].toString())));
//				
				items.add(item);
			}
		}
		return items;
	}

	@Override
	public Date getLastAlertDateForAsr(int asrptId) {
		String sql = "select max(case when c.audt_updt_ts is not null then c.audt_updt_ts else c.alert_creat_dt end) as updtdt from fps2.fps_asrpt a inner join fps2.fps_asrpt_alert_asctn b on a.asrpt_id = b.asrpt_id inner join fps2.fps_alert c on b.alert_id = c.alert_id where a.asrpt_id = :asrptId";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("asrptId", Integer.valueOf(asrptId));
		List<Date> rows = query.list();
		if (rows != null) {
			return (Date) rows.get(0);
		}
		return null;
	}

	@Override
	public Date getLastAlertDateForModelAndNpi(String modelId, String npi, String state) {
		String sql = "select max(alert_creat_dt) as updtdt from fps2.fps_alert_mdcd a "
				+ "inner join fps2.fps_model_mdcd b on a.model_id = b.model_id "
				+ "where b.model_busns_id = :modelId and a.subj_id = :npi and a.SUBMTG_MDCD_USPS_STATE_CD = :state";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("modelId", modelId);
		query.setParameter("npi", npi);
		query.setParameter("state", state);
		List<Date> rows = query.list();
		if (rows != null) {
			return (Date) rows.get(0);
		}
		return null;
	}

	@Override
	public Date getLastAlertDateForReportCard(int modelId, String npi, String state) {
		String sql = "select max(model_run_dt) as updtdt from fps2.fps_rpt_card_dtl_mdcd a "
				+ "inner join fps2.fps_model_mdcd b on a.model_busns_id = b.model_busns_id "
				+ "inner join fps2.MDCD_GEO_LCL_STATE_CD c on a.SUBMTG_MDCD_LCL_STATE_CD = c.GEO_MDCD_LCL_STATE_CD "
				+ "where a.subj_id = :npi and  b.model_id = :modelId and  c.GEO_MDCD_USPS_STATE_CD = :state";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("modelId", Integer.valueOf(modelId));
		query.setParameter("npi", npi);
		query.setParameter("state", state);

		List<Date> rows = query.list();
		if (rows != null) {
			return (Date) rows.get(0);
		}
		return null;
	}

	@Override
	public Date getLastAlertDateForSnaReportCard(int modelId, String npi, String state) {
		String sql = "select max(model_run_dt) as updtdt from fps2.FPS_RPT_CARD_RSK_SNA_DTL_mdcd a "
				+ "inner join fps2.fps_model_mdcd b on a.model_busns_id = b.model_busns_id "
				+ "inner join fps2.MDCD_GEO_LCL_STATE_CD c on a.SUBMTG_MDCD_LCL_STATE_CD = c.GEO_MDCD_LCL_STATE_CD "
				+ "where a.SUBJ_PRVDR_NPI = :npi and  b.model_id = :modelId and  c.GEO_MDCD_USPS_STATE_CD = :state";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("modelId", Integer.valueOf(modelId));
		query.setParameter("npi", npi);
		query.setParameter("state", state);

		List<Date> rows = query.list();
		if (rows != null) {
			return (Date) rows.get(0);
		}
		return null;
	}

	@Override
	public Date getLastAlertDateForCustomTable(String modelBusnsId, String npi, String state) {
		String sql = "select max(MODEL_RUN_DT) as updtdt " + "from fps2.FPS_CSTM_TBL_DTL_MDCD a "
				+ "inner join fps2.MDCD_GEO_LCL_STATE_CD c on a.SUBMTG_MDCD_LCL_STATE_CD = c.GEO_MDCD_LCL_STATE_CD "
				+ "where a.npi_num = :npi and  a.model_busns_id = :modelBusnsId  and  c.GEO_MDCD_USPS_STATE_CD = :state";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("modelBusnsId", modelBusnsId);
		query.setParameter("npi", npi);
		query.setParameter("state", state);

		List<Date> rows = query.list();
		if (rows != null) {
			return (Date) rows.get(0);
		}
		return null;
	}

	@Transactional(readOnly = true)
	@Override
	public List<FpsRptCardDtlMdcd> loadReportCardForModelAndNpi(int modelId, String npi, String state) {
		return loadReportCardForModelAndNpi(modelId, npi, state, null);
	}

	@Transactional(readOnly = true)
	@Override
	public List<FpsRptCardDtlMdcd> loadReportCardForModelAndNpi(int modelId, String npi, String state, Date runDate) {
		Date d = null;
		boolean useDateRange = false;
		if (runDate != null) {
			d = runDate;
			useDateRange = true;
		} else {
			d = getLastAlertDateForReportCard(modelId, npi, state);
		}

		Criteria c = getCurrentSession().createCriteria(FpsRptCardDtlMdcd.class, "card")
				.createAlias("card.fpsModel", "model", JoinType.INNER_JOIN)
				.createAlias("card.mdcdGeoLclStateCd", "stateCd", JoinType.INNER_JOIN)
				.add(Restrictions.eq("stateCd.geoMdcdUspsStateCd", state))
				.add(Restrictions.eq("model.modelId", Integer.valueOf(modelId)))
				.add(Restrictions.eq("card.subjId", npi));
		// if (useDateRange) {
		// Calendar calMinus = Calendar.getInstance();
		// calMinus.setTime(runDate);
		// calMinus.add(Calendar.DATE, -2);
		// calMinus.set(Calendar.HOUR, 0);
		// calMinus.set(Calendar.MINUTE, 0);
		// calMinus.set(Calendar.SECOND, 0);
		//
		// Calendar calPlus = Calendar.getInstance();
		// calPlus.setTime(runDate);
		// calPlus.add(Calendar.DATE, 1);
		// calPlus.set(Calendar.HOUR, 23);
		// calPlus.set(Calendar.MINUTE, 59);
		// calPlus.set(Calendar.SECOND, 59);
		// c.add(Restrictions.between("card.audtInsrtTs", calMinus.getTime(),
		// calPlus.getTime()));
		// } else {
		c.add(Restrictions.eq("card.modelRunDt", d));
		// }

		c.addOrder(Order.asc("attrSqncNum"));
		List<FpsRptCardDtlMdcd> rcs = c.list();
		return rcs;
	}

	@Transactional(readOnly = true)
	@Override
	public List<FpsRptCardRskSnaDtlMdcd> loadSnaReportCardForModelAndNpi(int modelId, String npi, String state) {
		return loadSnaReportCardForModelAndNpi(modelId, npi, state, null);
	}

	@Transactional(readOnly = true)
	@Override
	public List<FpsRptCardRskSnaDtlMdcd> loadSnaReportCardForModelAndNpi(int modelId, String npi, String state,
			Date runDate) {
		Date d = null;
		if (runDate != null) {
			d = runDate;
		} else {
			d = getLastAlertDateForSnaReportCard(modelId, npi, state);
		}
		List<FpsRptCardRskSnaDtlMdcd> rcs = getCurrentSession().createCriteria(FpsRptCardRskSnaDtlMdcd.class, "card")

				.createAlias("card.fpsModel", "model", JoinType.INNER_JOIN)
				.createAlias("card.mdcdGeoLclStateCd", "stateCd", JoinType.INNER_JOIN)
				.add(Restrictions.eq("stateCd.geoMdcdUspsStateCd", state))
				.add(Restrictions.eq("model.modelId", Integer.valueOf(modelId)))
				.add(Restrictions.eq("card.subjPrvdrNpi", npi)).add(Restrictions.eq("card.modelRunDt", d))
				.addOrder(Order.asc("attrSqncNum")).list();

		return rcs;
	}

	@Transactional(readOnly = true)
	@Override
	public List<FpsRptCardAttrLabelMdcd> loadReportCardLabels(FpsRptCardDtlMdcd rptCardDtl) {
		Criteria criteria = getCurrentSession().createCriteria(FpsRptCardAttrLabelMdcd.class);
		criteria.setFirstResult(0);
		criteria.setMaxResults(1);

		criteria.add(Restrictions.eq("modelBusnsId", rptCardDtl.getModelBusnsId()))
				.add(Restrictions.eq("attrSqncNum", rptCardDtl.getAttrSqncNum()));

		List<FpsRptCardAttrLabelMdcd> labels = criteria.addOrder(Order.desc("audtInsrtTs")).list();

		return labels;
	}
	@Transactional(readOnly = true)
	@Override
	public List<FpsRptCardLabelSnpShtMdcd> loadReportCardLabelsSnapshot(FpsRptCardDtlMdcd rptCardDtl) {
		Criteria criteria = getCurrentSession().createCriteria(FpsRptCardLabelSnpShtMdcd.class);
		criteria.setFirstResult(0);
		criteria.setMaxResults(1);

		criteria.add(Restrictions.eq("modelBusnsId", rptCardDtl.getModelBusnsId()))
				.add(Restrictions.eq("attrSqncNum", rptCardDtl.getAttrSqncNum()))
				.add(Restrictions.eq("modelRunDt", rptCardDtl.getModelRunDt()));

		List<FpsRptCardLabelSnpShtMdcd> labels = criteria.addOrder(Order.desc("audtInsrtTs")).list();

		return labels;
	}

	@Transactional(readOnly = true)
	@Override
	public FpsAlertMdcd loadReportCardMostRecentAlert(String npi, Integer modelId, String state, Date runDate) {
		Criteria criteria = getCurrentSession().createCriteria(FpsAlertMdcd.class, "alert")
				.createAlias("alert.mdcdGeoLclStateCd", "uspsState")
				.createAlias("alert.fpsModel", "model", JoinType.INNER_JOIN);
		criteria.setFirstResult(0);
		criteria.setMaxResults(1);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		criteria.add(Restrictions.eq("model.modelId", modelId))
				.add(Restrictions.eq("uspsState.geoMdcdUspsStateCd", state)).add(Restrictions.eq("subjId", npi));
		if (runDate != null) {
			criteria.add(Restrictions.eq("alertCreatDt", runDate));
		}
		criteria.addOrder(Order.desc("alertCreatDt"));
		List<FpsAlertMdcd> alerts = criteria.list();
		FpsAlertMdcd alert = new FpsAlertMdcd();
		if (alerts != null && alerts.size() > 0) {
			alert = (FpsAlertMdcd) alerts.get(0);
		}
		return alert;
	}

	@Transactional(readOnly = true)
	@Override
	public FpsAlertMdcd loadReportCardMostRecentAlert(FpsRptCardDtlMdcd rptCardDtl) {
		Criteria criteria = getCurrentSession().createCriteria(FpsAlertMdcd.class, "alert")
				.createAlias("alert.fpsModel", "model", JoinType.INNER_JOIN);
		criteria.setFirstResult(0);
		criteria.setMaxResults(1);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<FpsAlertMdcd> alerts = criteria.add(Restrictions.eq("model.modelBusnsId", rptCardDtl.getModelBusnsId()))
				.add(Restrictions.eq("subjId", rptCardDtl.getSubjId())).addOrder(Order.desc("alertCreatDt")).list();

		FpsAlertMdcd alert = new FpsAlertMdcd();
		if (alerts != null && alerts.size() > 0) {
			alert = (FpsAlertMdcd) alerts.get(0);
		}
		return alert;
	}

	@Transactional(readOnly = true)
	@Override
	public FpsAlertMdcd loadReportCardMostRecentAlert(String subjId, String modelBusnsId, String state) {
		Criteria criteria = getCurrentSession().createCriteria(FpsAlertMdcd.class, "alert")
				.createAlias("alert.mdcdGeoLclStateCd", "uspsState")
				.createAlias("alert.fpsModel", "model", JoinType.INNER_JOIN);
		criteria.setFirstResult(0);
		criteria.setMaxResults(1);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<FpsAlertMdcd> alerts = criteria.add(Restrictions.eq("model.modelBusnsId", modelBusnsId))
				.add(Restrictions.eq("uspsState.geoMdcdUspsStateCd", state)).add(Restrictions.eq("subjId", subjId))
				.addOrder(Order.desc("alertCreatDt")).list();

		FpsAlertMdcd alert = new FpsAlertMdcd();
		if (alerts != null && alerts.size() > 0) {
			alert = (FpsAlertMdcd) alerts.get(0);
		}
		return alert;
	}

	@Transactional(readOnly = true)
	@Override
	public FpsAlertMdcd loadReportCardMostRecentAlert(FpsRptCardRskSnaDtlMdcd rptCardDtl) {
		Criteria criteria = getCurrentSession().createCriteria(FpsAlertMdcd.class, "alert")
				.createAlias("alert.fpsModel", "model", JoinType.INNER_JOIN);
		criteria.setFirstResult(0);
		criteria.setMaxResults(1);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<FpsAlertMdcd> alerts = criteria.add(Restrictions.eq("model.modelBusnsId", rptCardDtl.getModelBusnsId()))
				.add(Restrictions.eq("subjId", rptCardDtl.getSubjPrvdrNpi())).addOrder(Order.desc("alertCreatDt"))
				.list();

		FpsAlertMdcd alert = new FpsAlertMdcd();
		if (alerts != null && alerts.size() > 0) {
			alert = (FpsAlertMdcd) alerts.get(0);
		}
		return alert;
	}

	@Override
	public HashMap<String, String> loadReportCardClaimExistInd(int modelId, String npi) {
		HashMap<String, String> seqCount = new HashMap<String, String>();
		String sql = "select a.ATTR_SQNC_NUM,count(*) from fps2.FPS_ALERT b ,fps2.FPS_ALERT_CLM_ASCTN c,fps2.FPS_RPT_CARD_DTL a  where b.SUBJ_ID= :subjId and b.MODEL_ID= :modelId and b.ALERT_ID=c.ALERT_ID and a.SUBJ_ID=b.SUBJ_ID  and a.MODEL_BUSNS_ID=(select m.MODEL_BUSNS_ID from fps_model m where m.model_id=b.MODEL_ID)  and a.ATTR_SQNC_NUM=c.ATTR_SQNC_NUM group by a.ATTR_SQNC_NUM ";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("subjId", npi);
		query.setParameter("modelId", Integer.valueOf(modelId));
		List<Object[]> rows = query.list();
		for (Object[] row : rows) {
			if (rows != null) {
				String seq = row[0].toString();
				int count = Integer.parseInt(row[1].toString());
				seqCount.put(seq, count > 0 ? "Y" : "N");
			}
		}
		return seqCount;
	}

	@Override
	public List<Date> getReportCardDatesForModel(String model, String npi, String state) {
		Criteria c = getCurrentSession().createCriteria(FpsRptCardDtlMdcd.class, "card")
				.createAlias("alert.mdcdGeoLclStateCd", "uspsState")
				.setProjection(Projections.distinct(Projections.property("modelRunDt")));
		if (model != null) {
			c.add(Restrictions.eq("modelBusnsId", model));
		}
		c.add(Restrictions.eq("uspsState.geoMdcdUspsStateCd", state));

		c.add(Restrictions.eq("subjId", npi)).addOrder(Order.desc("modelRunDt"));
		List<Date> rcs = c.list();

		return rcs;
	}

	@Override
	public List<Date> getSnaReportCardDatesForModel(String model, String npi, String state) {
		Criteria c = getCurrentSession().createCriteria(FpsRptCardRskSnaDtlMdcd.class, "card")
				.createAlias("alert.mdcdGeoLclStateCd", "uspsState")
				.setProjection(Projections.distinct(Projections.property("modelRunDt")))
				.add(Restrictions.eq("subjNpiName", npi));
		if (model != null) {
			c.add(Restrictions.eq("modelBusnsId", model));
		}
		c.add(Restrictions.eq("uspsState.geoMdcdUspsStateCd", state));

		c.addOrder(Order.desc("modelRunDt"));
		List<Date> rcs = c.list();

		return rcs;
	}

	@Override
	public long getClaimCount(ClaimsSearchParameter search) {
		if ("local".equalsIgnoreCase(buildFor)) {
			return 0l; 
		}
		Query query = buildSnowflakeClaimsQuery(search, true);

		Long totalRows = (Long) query.uniqueResult();

		return totalRows.intValue();
	}

	@Override
	public FpsAsrDetailsPageCounts getAllClaimCount(String npi) {
		if ("local".equalsIgnoreCase(buildFor)) {
			return new FpsAsrDetailsPageCounts(); 
		}
		FpsAsrDetailsPageCounts summ = new FpsAsrDetailsPageCounts();
		String sql = " from FpsAsrDetailsPageCounts where npi = :npi ";
		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setParameter("npi", npi);

		List<FpsAsrDetailsPageCounts> summs = query.list();
		if (summs != null && summs.size() > 0) {
			summ = summs.get(0);
		}
		return summ;
	}

	private Class getClaimClass(SolrClaimType param) {
		Class c = FpsClmMdcd.class;
//		
		return c;
	}

	public Criteria buildSnowflakeClaimsQuery2(ClaimsSearchParameter param, boolean countOnly) {
		String table = "FpsClmMdcd  fpsclm";
		String subTable = null;
		String subTable2 = null;

		table = "FpsClmMdcd fpsclm";
		subTable = "fpsclm.fpsClmAsrpts";

		Date fromDate = param.getFromDt();
		Date toDate = param.getToDt();
		List<FpsCommonBeneficiary> hicnCodes = param.getHicns();

		Integer asrptId = param.getAsrptId();
		SolrClaimType claimCollection = param.getSearchType();
		Criteria c = getSnowflakeCurrentSession().createCriteria(getClaimClass(claimCollection), "fpsclm");
		if (subTable != null) {
			c.createAlias(subTable, "fpsclmasrpts", JoinType.LEFT_OUTER_JOIN);
			c.setFetchMode(subTable, FetchMode.JOIN);

		}
		if (param.getMdcdSvcCats() != null | param.getMdcdSvcSubcats() != null) {
			c.createAlias("fpsclm.mdcdClmTypeCd", "clmType");

		}
		c.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		String sql = "";
		String p = "";
		Map<String, Object> params = new HashMap<String, Object>();
		if (fromDate != null) {
			Calendar fromCal = Calendar.getInstance();
			fromCal.setTime(fromDate);
			fromCal.set(Calendar.HOUR_OF_DAY, 0);
			fromCal.set(Calendar.MINUTE, 0);
			fromDate = fromCal.getTime();

		}
		if (toDate != null) {
			Calendar toCal = Calendar.getInstance();
			toCal.setTime(toDate);
			toCal.set(Calendar.HOUR_OF_DAY, 23);
			toCal.set(Calendar.MINUTE, 59);
			toDate = toCal.getTime();

		}

		if (hicnCodes != null && hicnCodes.size() > 0) {
			List<String> hicns = new ArrayList<String>();
			for (FpsCommonBeneficiary hicnCode : hicnCodes) {
				hicns.add(hicnCode.getHicn());
			}
			sql += " and fpsclm.clmHicNum in (:hicns) ";
			c.add(Restrictions.in("fpsclm.clmHicNum", hicns));

			params.put("hicns", hicns);

		}
		String dateParam = "";
		if (fromDate == null && toDate == null) {
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.YEAR, -1);
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			Calendar toCal = Calendar.getInstance();
			toCal.set(Calendar.HOUR_OF_DAY, 23);
			toCal.set(Calendar.MINUTE, 59);
			dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(cal.getTime()) + " TO "
					+ FpsDomainObjectConverter.convertDateToSolrString(toCal.getTime()) + "]";
//			params.put("fromDate", cal.getTime());
//			params.put("toDate", toCal.getTime());
//			sql += " and clmThruDt between :fromDate and :toDate ";
			GregorianCalendar gc1 = new GregorianCalendar();
			GregorianCalendar gc2 = new GregorianCalendar();
			gc1.setTimeInMillis(cal.getTimeInMillis());
			gc2.setTimeInMillis(toCal.getTimeInMillis());
//			c.add(Restrictions.between("fpsclm.clmThruDt", gc1.getTime(), gc2.getTime()));
		}
		if (fromDate != null || toDate != null) {
			GregorianCalendar gc1 = new GregorianCalendar();
			GregorianCalendar gc2 = new GregorianCalendar();

			if (fromDate != null) {
				if (toDate != null) {
					dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(fromDate) + " TO "
							+ FpsDomainObjectConverter.convertDateToSolrString(toDate) + "]";
					params.put("fromDate", fromDate);
					params.put("toDate", toDate);
					gc1.setTimeInMillis(fromDate.getTime());
					gc2.setTimeInMillis(toDate.getTime());
					c.add(Restrictions.between("fpsclm.clmThruDt", gc1.getTime(), gc2.getTime()));
					sql += " and fpsclm.clmThruDt between :fromDate and :toDate ";

				} else {
					dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(fromDate) + " TO *]";
					params.put("fromDate", fromDate);
					gc1.setTimeInMillis(fromDate.getTime());
					c.add(Restrictions.ge("fpsclm.clmThruDt", gc1.getTime()));
					sql += " and fpsclm.clmThruDt >= :fromDate  ";
				}
			} else {
				dateParam = "[* TO " + FpsDomainObjectConverter.convertDateToSolrString(toDate) + "]";
				sql += " and fpsclm.clmThruDt <= :toDate  ";
				gc2.setTimeInMillis(toDate.getTime());

				c.add(Restrictions.le("fpsclm.clmThruDt", gc2.getTime()));
				params.put("toDate", toDate);
			}

		}
		// medicaid states

		if (param.getMdcdStates() != null && param.getMdcdStates().size() > 0) {
//			c.createAlias("fpsclm.mdcdGeoLclStateCd", "states");
			List<String> states = new ArrayList<String>();
			for (AsrGenericCode state : param.getMdcdStates()) {

				states.add(state.getCode().toUpperCase());
			}
			sql += "and fpsclm.submtgMdcdLclStateCd in :states ";
			c.add(Restrictions.in("fpsclm.submtgMdcdLclStateCd", states));
			params.put("states", states);

		}

		// medicaid categories

		if (param.getMdcdSvcCats() != null && param.getMdcdSvcCats().size() > 0) {
			List<String> cats = new ArrayList<String>();
			for (AsrGenericCode cat : param.getMdcdSvcCats()) {

				cats.add(cat.getCode().toUpperCase());
			}
			sql += "and clmType.clmSrvcCtgry in :cats ";
			c.add(Restrictions.in("clmType.clmSrvcCtgry", cats));
			params.put("cats", cats);

		}
		// medicaid subcats

		if (param.getMdcdSvcSubcats() != null && param.getMdcdSvcSubcats().size() > 0) {
			List<String> subcats = new ArrayList<String>();
			for (AsrGenericCode subcat : param.getMdcdSvcSubcats()) {

				subcats.add(subcat.getCode());
			}
			sql += "and clmType.clmSrvcSbctgry in :subcats ";
			c.add(Restrictions.in("clmType.clmSrvcSbctgry", subcats));
			params.put("subcats", subcats);

		}
		// diagnosis codes
		if (param.getDiagnosises() != null && param.getDiagnosises().size() > 0) {
			List<String> diagnoses = new ArrayList<String>();
			for (AsrGenericCode diagnosis : param.getDiagnosises()) {

				diagnoses.add(diagnosis.getCode().toUpperCase());
			}

			sql += "and fpsclm.clmDgns1Cd in :diagnoses ";
			c.add(Restrictions.in("fpsclm.clmDgns1Cd", diagnoses));
			params.put("diagnoses", diagnoses);

		}
		// search on multiple hcpcs codes
		if (param.getHcpcses() != null && param.getHcpcses().size() > 0) {
			List<String> hcpcss = new ArrayList<String>();
			for (AsrGenericCode hcpcs : param.getHcpcses()) {

				hcpcss.add(hcpcs.getCode().toUpperCase());
			}
			sql += "and fpsclm.clmLineSbmtdPrcdrCd in :hcpcss ";
			c.add(Restrictions.in("fpsclm.clmLineSbmtdPrcdrCd", hcpcss));
			params.put("hcpcss", hcpcss);

		}
		// search on multiple procedure codes
		if (param.getProcedures() != null && param.getProcedures().size() > 0) {
			List<String> procs = new ArrayList<String>();
			for (AsrGenericCode proc : param.getProcedures()) {

				procs.add(proc.getCode().toUpperCase());
			}
			sql += "and (" + " fpsclm.clmPrcdr1Cd in :procs1 or" + " fpsclm.clmPrcdr6Cd in :procs6 or"
					+ " fpsclm.clmPrcdr2Cd in :procs2 or" + " fpsclm.clmPrcdr3Cd in :procs3 or"
					+ " fpsclm.clmPrcdr4Cd in :procs4 or" + " fpsclm.clmPrcdr5Cd in :procs5 or"
					+ " fpsclm.clmLineSbmtdPrcdrCd in :procs7 " + " )";
//			c.add(Restrictions.in("fpsclm.clmPrcdr1Cd", procs));
			params.put("procs1", procs);
			params.put("procs2", procs);
			params.put("procs3", procs);
			params.put("procs4", procs);
			params.put("procs5", procs);
			params.put("procs6", procs);
			params.put("procs7", procs);
			Disjunction prcdrCds = Restrictions.or(new Criterion[] {});
			prcdrCds.add(Restrictions.in("fpsclm.clmPrcdr1Cd", procs));
			prcdrCds.add(Restrictions.in("fpsclm.clmPrcdr2Cd", procs));
			prcdrCds.add(Restrictions.in("fpsclm.clmPrcdr3Cd", procs));
			prcdrCds.add(Restrictions.in("fpsclm.clmPrcdr4Cd", procs));
			prcdrCds.add(Restrictions.in("fpsclm.clmPrcdr5Cd", procs));
			prcdrCds.add(Restrictions.in("fpsclm.clmPrcdr6Cd", procs));
			prcdrCds.add(Restrictions.in("fpsclm.clmLineSbmtdPrcdrCd", procs));
			c.add(prcdrCds);
//			c.add(Restrictions.disjunction(Restrictions.in("fpsclm.clmPrcdr1Cd", procs));

		}

		// default - only alerted claims have asr_key
		if (!SolrClaimType.RAW.equals(claimCollection) && !SolrClaimType.PARTDRAW.equals(claimCollection)) {
//			sql += " and asrKey like :asrptId ";
//			if (SolrClaimType.ALERTED.equals(claimCollection)) {
//				sql += " and fpsclmasrpts.asrptId = :asrptId ";
//
//			}else {
			sql += " and fpsclmasrpts.asrptId = :asrptId ";

//			}
			c.add(Restrictions.eq("fpsclmasrpts.asrptId", asrptId));

			params.put("asrptId", asrptId);
		}

		int i = 1;
		for (String key : params.keySet()) {
			p += key + ":" + params.get(key);
			if (i < params.keySet().size())
				p += " AND ";
			i++;
		}

		// sort
		if (!countOnly) {
			c.addOrder(Order.desc("fpsclm.clmFromDt"));
			c.addOrder(Order.desc("fpsclm.clmThruDt"));
			c.addOrder(Order.asc("fpsclm.clmHicNum"));
			c.addOrder(Order.asc("fpsclm.id"));
			sql += " order by fpsclm.clmFromDt desc,fpsclm.clmThruDt desc, fpsclm.clmHicNum asc, fpsclm.id asc";
		}
		if (param.getStartAt() != null) {
			sql += " offset " + param.getStartAt() + " rows ";
			c.setFirstResult(param.getStartAt());
		}
		if (param.getPageSize() != null) {
			sql += " fetch next " + param.getPageSize() + " rows ";
			c.setMaxResults(param.getPageSize());

		}
//		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql);
//		for (String key : params.keySet()) {
//			if (params.get(key) instanceof List) {
//				query.setParameterList(key, (Collection) params.get(key));
//			} else {
//				query.setParameter(key, params.get(key));
//			}
//
//		}
		return c;
	}

	public Query buildSnowflakeClaimsQuery(ClaimsSearchParameter param, boolean countOnly) {
		String table = "FpsClmMdcd  fpsclm";
		String subTable = null;
		subTable = "fpsclm.fpsClmAsrpts fpsclmasrpts";

		String clmTypeTable = null;
		if (param.getMdcdSvcCats() != null || param.getMdcdSvcSubcats() != null) {
			clmTypeTable = "fpsclm.mdcdClmTypeCd clmType";
		}
		String statesTable = null;

		List<AsrGenericCode> claimTypeCodes = param.getClaimTypes();
		Date fromDate = param.getFromDt();
		Date toDate = param.getToDt();
		List<FpsCommonBeneficiary> hicnCodes = param.getHicns();

		String subjId = param.getNpi();
		Integer asrptId = param.getAsrptId();
		SolrClaimType claimCollection = param.getSearchType();
		String sql = (countOnly ? "select count(*) " : " select distinct fpsclm  ") + " from " + table
				+ (subTable != null ? " inner join " + (countOnly ? "" : " fetch ") + subTable : "")
				+ (clmTypeTable != null ? " inner join " + clmTypeTable : "") + " where 1=1 ";
		Map<String, Object> params = new HashMap<String, Object>();
		String p = "";

		if (fromDate != null) {
			Calendar fromCal = Calendar.getInstance();
			fromCal.setTime(fromDate);
			fromCal.set(Calendar.HOUR_OF_DAY, 0);
			fromCal.set(Calendar.MINUTE, 0);
			fromDate = fromCal.getTime();

		}
		if (toDate != null) {
			Calendar toCal = Calendar.getInstance();
			toCal.setTime(toDate);
			toCal.set(Calendar.HOUR_OF_DAY, 23);
			toCal.set(Calendar.MINUTE, 59);
			toDate = toCal.getTime();

		}

		if (hicnCodes != null && hicnCodes.size() > 0) {
			List<String> hicns = new ArrayList<String>();
			for (FpsCommonBeneficiary hicnCode : hicnCodes) {
				hicns.add(hicnCode.getHicn());
			}
			sql += " and fpsclm.clmHicNum in (:hicns) ";

			params.put("hicns", hicns);

		}
		String dateParam = "";
		if (fromDate == null && toDate == null) {
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.YEAR, -1);
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			Calendar toCal = Calendar.getInstance();
			toCal.set(Calendar.HOUR_OF_DAY, 23);
			toCal.set(Calendar.MINUTE, 59);
			dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(cal.getTime()) + " TO "
					+ FpsDomainObjectConverter.convertDateToSolrString(toCal.getTime()) + "]";
//			params.put("fromDate", cal.getTime());
//			params.put("toDate", toCal.getTime());
//			sql += " and clmThruDt between :fromDate and :toDate ";
		}
		if (fromDate != null || toDate != null) {
			if (fromDate != null) {
				if (toDate != null) {
					dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(fromDate) + " TO "
							+ FpsDomainObjectConverter.convertDateToSolrString(toDate) + "]";
					params.put("fromDate", fromDate);
					params.put("toDate", toDate);
					sql += " and fpsclm.clmThruDt between :fromDate and :toDate ";

				} else {
					dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(fromDate) + " TO *]";
					params.put("fromDate", fromDate);
					sql += " and fpsclm.clmThruDt >= :fromDate  ";
				}
			} else {
				dateParam = "[* TO " + FpsDomainObjectConverter.convertDateToSolrString(toDate) + "]";
				sql += " and fpsclm.clmThruDt <= :toDate  ";
				params.put("toDate", toDate);
			}

		}

		// medicaid states

		if (param.getMdcdStates() != null && param.getMdcdStates().size() > 0) {
//			c.createAlias("fpsclm.mdcdGeoLclStateCd", "states");
			List<String> states = new ArrayList<String>();
			for (AsrGenericCode state : param.getMdcdStates()) {

				states.add(state.getCode().toUpperCase());
			}
			sql += "and fpsclm.submtgMdcdLclStateCd in :states ";
//			c.add(Restrictions.in("states.geoMdcdUspsStateCd", states));
			params.put("states", states);

		}

		// medicaid categories

		if (param.getMdcdSvcCats() != null && param.getMdcdSvcCats().size() > 0) {
			List<String> cats = new ArrayList<String>();
			for (AsrGenericCode cat : param.getMdcdSvcCats()) {

				cats.add(cat.getCode().toUpperCase());
			}
			sql += "and clmType.clmSrvcCtgry in :cats ";
//			c.add(Restrictions.in("clmType.clmSrvcCtgry", cats));
			params.put("cats", cats);

		}
		// medicaid subcats

		if (param.getMdcdSvcSubcats() != null && param.getMdcdSvcSubcats().size() > 0) {
			List<String> subcats = new ArrayList<String>();
			for (AsrGenericCode cat : param.getMdcdSvcSubcats()) {

				subcats.add(cat.getCode());
			}
			sql += "and clmType.clmSrvcSbctgry in :subcats ";
//			c.add(Restrictions.in("clmType.clmSrvcSbctgry", cats));
			params.put("subcats", subcats);

		}
		// diagnosis codes
		if (param.getDiagnosises() != null && param.getDiagnosises().size() > 0) {
			List<String> diagnoses = new ArrayList<String>();
			for (AsrGenericCode diagnosis : param.getDiagnosises()) {

				diagnoses.add(diagnosis.getCode().toUpperCase());
			}

			sql += "and fpsclm.clmDgns1Cd in :diagnoses ";
//			c.add(Restrictions.in("fpsclm.clmLineDgnsCd", diagnoses));
			params.put("diagnoses", diagnoses);

		}
		// search on multiple hcpcs codes
		if (param.getHcpcses() != null && param.getHcpcses().size() > 0) {
			List<String> hcpcss = new ArrayList<String>();
			for (AsrGenericCode hcpcs : param.getHcpcses()) {

				hcpcss.add(hcpcs.getCode().toUpperCase());
			}
			sql += "and fpsclm.clmLineSbmtdPrcdrCd in :hcpcss ";
//			c.add(Restrictions.in("fpsclm.clmLineHcpcsCd", hcpcss));
			params.put("hcpcss", hcpcss);

		}
		// search on multiple procedure codes
		if (param.getProcedures() != null && param.getProcedures().size() > 0) {
			List<String> procs = new ArrayList<String>();
			for (AsrGenericCode proc : param.getProcedures()) {

				procs.add(proc.getCode().toUpperCase());
			}
			sql += "and (" + " fpsclm.clmSbmtdPrcdr1Cd in :procs1 or" + " fpsclm.clmSbmtdPrcdr6Cd in :procs6 or"
					+ " fpsclm.clmSbmtdPrcdr2Cd in :procs2 or" + " fpsclm.clmSbmtdPrcdr3Cd in :procs3 or"
					+ " fpsclm.clmSbmtdPrcdr4Cd in :procs4 or" + " fpsclm.clmSbmtdPrcdr5Cd in :procs5 " + " )";
//			c.add(Restrictions.in("fpsclm.clmPrcdr1Cd", procs));
			params.put("procs1", procs);
			params.put("procs2", procs);
			params.put("procs3", procs);
			params.put("procs4", procs);
			params.put("procs5", procs);
			params.put("procs6", procs);

		}

		// default - only alerted claims have asr_key
		if (!SolrClaimType.RAW.equals(claimCollection) && !SolrClaimType.PARTDRAW.equals(claimCollection)) {
//			sql += " and asrKey like :asrptId ";
//			if (SolrClaimType.ALERTED.equals(claimCollection)) {
//				sql += " and fpsclmasrpts.asrptId = :asrptId ";
//
//			}else {
			sql += " and fpsclmasrpts.asrptId = :asrptId ";

//			}
			params.put("asrptId", asrptId);
		}

		int i = 1;
		for (String key : params.keySet()) {
			p += key + ":" + params.get(key);
			if (i < params.keySet().size())
				p += " AND ";
			i++;
		}

		// sort
		if (!countOnly)
			sql += " order by fpsclm.clmFromDt desc,fpsclm.clmThruDt desc, fpsclm.clmHicNum asc, fpsclm.id asc";

//		if (param.getStartAt() != null) {
//			sql += " offset " + param.getStartAt() + " rows ";
//		}
//		if (param.getPageSize() != null) {
//			sql += " fetch next " + param.getPageSize() + " rows ";
//		}
		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql);
		query.setMaxResults(100000);
		for (String key : params.keySet()) {
			if (params.get(key) instanceof List) {
				query.setParameterList(key, (Collection) params.get(key));
			} else {
				query.setParameter(key, params.get(key));
			}

		}
		return query;
	}

	@Override
	public List<Object[]> getHicnsForASR(int asrptId) {
		String sql = "   select " + "       d.clm_hic_num,max(d.clm_thru_dt) "
				+ "      from fps2.fps_asrpt_alert_asctn b "
				+ "      inner join fps2.fps_alert_clm_asctn c on b.alert_id = c.alert_id "
				+ "      inner join fps2.fps_clm d on c.CLM_ID = d.FPS_CLM_ID " + "      where b.asrpt_id = :asrptId "
				+ "      and c.fps_vrsn_ind = '2' " + "      and d.fps_vrsn_ind = '2' "
				+ "		and d.clm_hic_num is not null and length(d.clm_hic_num) > 0 "
				+ "     group by  d.clm_hic_num order by d.clm_hic_num fetch first 1000 rows only ";
		SQLQuery query = (SQLQuery) getCurrentSession().createSQLQuery(sql).setParameter("asrptId", asrptId);

		return query.list();
	}

	@Override
	public List<FpsAsrptPrrtyScreDtlVw> getPriorityScoreForASR(int asrptId) {
		List<FpsAsrptPrrtyScreDtlVw> scores = getCurrentSession().createCriteria(FpsAsrptPrrtyScreDtlVw.class, "score")
				.add(Restrictions.eq("asrptId", asrptId)).addOrder(Order.desc("prrtyScreDt"))
				.addOrder(Order.asc("prrtyCrtraId")).list();

		return scores;
	}

	@Override
	public int getAsrIdFromReportCard(short attrSqncNum, int alertId) {
		Integer asrptId = (Integer) getCurrentSession().createCriteria(FpsAlert.class, "alert")
				.createAlias("alert.fpsAsrptAlertAsctns", "asrAlert").createAlias("asrAlert.fpsAsrpt", "asr")
				.add(Restrictions.eq("alert.alertId", alertId)).setProjection(Projections.property("asr.asrptId"))
				.uniqueResult();
		return asrptId;
	}

	@Override
	public List<FpsAsrptRiskScreHstryVw> loadRiskScoreTrend(int asrptId) {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_YEAR, -365);
		return loadRiskScoreTrend(asrptId, cal.getTime(), new Date());

	}

	@Override
	public List<FpsAsrptRiskScreHstryVw> loadRiskScoreTrend(int asrptId, Date startDt, Date endDt) {
		List<FpsAsrptRiskScreHstryVw> trends = getCurrentSession()
				.createCriteria(FpsAsrptRiskScreHstryVw.class, "trend").add(Restrictions.eq("asrptId", asrptId))
				.add(Restrictions.between("riskScreHstryDt", startDt, endDt)).addOrder(Order.desc("riskScreHstryDt"))
				.list();

		return trends;

	}

	@Override
	public int getLastAlertForAsrAndModel(int asrptId, int modelId, String state) {
		String sql = "select max(c.alert_id) alert_id from fps2.fps_asrpt_alert_asctn_mdcd a "
				+ "inner join fps2.fps_alert_mdcd c on a.alert_id = c.alert_id "
				+ "where a.asrpt_id = :asrptId and c.model_id = :modelId and c.submtg_Mdcd_Lcl_State_Cd = :state";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("asrptId", Integer.valueOf(asrptId));
		query.setParameter("modelId", Integer.valueOf(modelId));
		query.setParameter("state", state);
		Integer result = (Integer) query.uniqueResult();
		return result;
	}

	@Override
	public List<FpsEditNumRfrnc> loadEditInfoByModel(String editNm, Boolean showInactive) {
		// TODO Auto-generated method stub
		Criteria c = getCurrentSession().createCriteria(FpsEditNumRfrnc.class);
		if (editNm != null) {
			c.add(Restrictions.eq("fpsEditName", editNm));
		}
		c.add(Restrictions.eq("actvInd", showInactive != null && showInactive ? "N" : "Y"));
		c.addOrder(Order.asc("fpsEditNum"));
		return c.list();
	}

	@Override
	public List<FpsRcncltnClmline> loadClaimsForNpiAndEdit(String npi, String editNm) {
		Criteria c = getCurrentSession().createCriteria(FpsRcncltnClmline.class)
				.add(Restrictions.eq("prvdrNpiNum", npi)).add(Restrictions.eq("modelName", editNm));
		return c.list();
	}

	@Override
	public Date getLastAlertDateForAsr(String asrNpi) {
		String sql = "select max(case when c.audt_updt_ts is not null then c.audt_updt_ts else c.alert_creat_dt end) as updtdt from fps2.fps_asrpt a inner join fps2.fps_asrpt_alert_asctn b on a.asrpt_id = b.asrpt_id inner join fps2.fps_alert c on b.alert_id = c.alert_id where a.subj_id = :subjId";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("subjId", asrNpi);
		List<Date> rows = query.list();
		if (rows != null) {
			return (Date) rows.get(0);
		}
		return null;

	}

	@Override
	public List<? extends MdcdBaseClaim> getClaimsForAlertCsv(int modelId, String subjId, Integer asrptId,
			Integer alertId, String state, int pageSize, int index) {
		List<? extends MdcdBaseClaim>  rows2 = new ArrayList<>();
		if ("local".equalsIgnoreCase(buildFor)) {
			return rows2; 
		}
		String table = "FpsClm fpsclm";
		String subTable = "fpsclm.fpsClmAlerts";

		Criteria c = getSnowflakeCurrentSession().createCriteria(FpsClmMdcd.class, "fpsclm")
				.createAlias("fpsclm.fpsClmAlerts", "fpsclmalerts", JoinType.LEFT_OUTER_JOIN)
				.add(Restrictions.eq("fpsclm.submtgMdcdLclStateCd", state))
				.add(Restrictions.eq("fpsclmalerts.alertId", alertId)).setMaxResults(pageSize).setFirstResult(index)
				.setFetchMode(subTable, FetchMode.JOIN);
		c.createAlias("fpsclm.fpsClmAsrpts", "fpsclamasrpts", JoinType.NONE);

		c.addOrder(Order.desc("fpsclm.clmFromDt"));
		c.addOrder(Order.desc("fpsclm.clmThruDt"));
		c.addOrder(Order.asc("fpsclm.clmHicNum"));
		c.addOrder(Order.asc("fpsclm.id"));

		logger.fine("start snowflake query");
		rows2 = c.list();
		logger.fine("end snowflake query");

		return rows2;
	}

	@Override
	public long getClaimsForAlertCount(int modelId, String subjId, Integer asrptId, String state, int alertId) {
		if ("local".equalsIgnoreCase(buildFor)) {
			return 0l; 
		}
		String table = "FpsClmMdcd fpsclm";
		String subTable = "fpsclm.fpsClmAlerts fpsclmalerts";

		String sql = "select count(distinct fpsclm.id)  from " + table + " inner join " + subTable
				+ "  where fpsclmalerts.alertId =  :alertId " + " and fpsclm.submtgMdcdLclStateCd = :state";

//				+ "   where attributeKey like :attrKey and alertKey like :alertKey ";

		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setInteger("alertId", alertId)
				.setString("state", state);
		Long totalRows = (Long) query.uniqueResult();

		return totalRows.intValue();
	}

	@Override
	public long getClaimsForReportCardCount(short attrId, Integer alertId, Integer asrptId, String state) {
		if ("local".equalsIgnoreCase(buildFor)) {
			return 0l; 
		}
		String table = "FpsClmMdcd fpsclm";
		String subTable = "fpsclm.fpsClmAttrs fpsclmattrs";

		String sql = "select count(distinct fpsclm.id) from " + table + " inner join " + subTable
				+ "  where fpsclmattrs.alertId =  :alertId and fpsclmattrs.attrSqncNum = :attrId "
				+ " and fpsclm.submtgMdcdLclStateCd = :state";

		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setInteger("alertId", alertId)
				.setInteger("attrId", attrId).setString("state", state);
		;
		Long totalRows = (Long) query.uniqueResult();

		return totalRows.intValue();
	}

	@Override
	public List<? extends MdcdBaseClaim> getClaimsForReportCardCsv(Short attrSqncNum, int alertId, int asrptId,
			String state, int pageSize, int index) {
		List<? extends MdcdBaseClaim>  rows2 = new ArrayList<>();
		if ("local".equalsIgnoreCase(buildFor)) {
			return rows2; 
		}
		String table = "FpsClmMdcd fpsclm";
		String subTable = "fpsclm.fpsClmAttrs fpsclmattrs";

		String sql = "select fpsclm from " + table + " inner join fetch " + subTable
				+ "  where fpsclmattrs.alertId =  :alertId and fpsclmattrs.attrSqncNum = :attrId  "
				+ " and fpsclm.submtgMdcdLclStateCd = :state "
				+ " order by fpsclm.clmFromDt desc, fpsclm.clmThruDt desc, fpsclm.clmHicNum asc, fpsclm.id asc ";
//
		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setInteger("alertId", alertId)
				.setInteger("attrId", attrSqncNum).setString("state", state);

		query.setMaxResults(pageSize);
		query.setFirstResult(index);

		System.out.println("start snowflake query");
		rows2 = query.list();
		return rows2;
	}

	@Override
	public AvailableClaims getAvailableClaimsForAsr(Integer asrptId, String npi, String zone) {
		AvailableClaims ac = new AvailableClaims();
		if ("local".equalsIgnoreCase(buildFor)) {
			return ac; 
		}
		ClaimsSearchParameter search = new ClaimsSearchParameter();
		long x = 0;

		List<AsrGenericCode> states = loadStatesForASRForSearch(asrptId, zone);
		// if no states are available that match the user's zone
		// then they can't see any claims
		if (states == null || states.size() == 0) {
			ac.setAtRiskInd( "N");
		}else {
			// claims at risk
			search = new ClaimsSearchParameter();
			search.setAsrptId(asrptId);
			search.setSearchType(SolrClaimType.ALERTED);
			search.setMdcdStates(states);
			x = getClaimCount(search);
			ac.setAtRiskInd(x > 0 ? "Y" : "N");
		}

		return ac;
	}

	private List<FpsVisualizationEdge> loadDmeEdges(List<FpsVisualizationEdge> srcEdges, int tier, boolean export)
			throws  IOException {

		List<FpsVisualizationEdge> edges = new ArrayList<FpsVisualizationEdge>();
		List<String> founds = new ArrayList<String>();
//
//		for (FpsVisualizationEdge edge : srcEdges) {
//			Map<String, String> p = new HashMap<String, String>();
//			String to = edge.getTo();
//			if (!founds.contains(to) && (export || (!export && StringUtils.isNumeric(to)))) {
//				// data can contain { since we receive it like that. Just escape it, don't
//				// remove it.
//				founds.add(to.replace("{", "\\{"));
//			}
//		}
//		Map<String, String> p = new HashMap<String, String>();
//		String exportStr = export ? "  " : " AND label != 'referring_to_bene' ";
//		String sql = "";
//		sql = "from VizDmeEdge where src in :founds  " + exportStr + " AND ranking <= :ranking order by ranking asc";
//
//		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setInteger("ranking", 66)
//				.setParameterList("founds", founds).setMaxResults(2000);
//		List<VizDmeEdge> dbEdges = query.list();
//		edges = FpsDomainObjectConverter.convertRequestDbToBean(dbEdges, FpsVisualizationEdge.class);
//
//		logger.info("dme edges found for tier " + (tier + 1) + ": " + edges.size());
//		// if the subject provider is a referring (vs billing) provider
//		// load the tiers above and below that NPI. Otherwise load 2
//		// tiers below.
//		boolean isReferring = false;
//		if (tier == 0) {
//			for (FpsVisualizationEdge edge : edges) {
//				if (edge.getLabel().startsWith("referring")) {
//					isReferring = true;
//					break;
//				}
//			}
//		}
//		if (isReferring) {
//			logger.info("referring dme found, loading one tier above and below");
//			edges.addAll(loadDmeEdgesReverse(edges, -1, false, srcEdges));
//			edges.addAll(loadDmeEdges(edges, 2, export));
//		} else {
//
//			logger.info("billing dme found, two tiers below at tier " + tier);
//
//			if (edges.size() > 0 && tier < 2) {
//				edges.addAll(loadDmeEdges(edges, tier == 0 ? 1 : tier + 1, export));
//
//			}
//		}

		return edges;

	}

	private List<FpsVisualizationEdge> loadDmeEdgesReverse(List<FpsVisualizationEdge> srcEdges, int tier,
			boolean export, List<FpsVisualizationEdge> rootEdges) throws  IOException {

		List<FpsVisualizationEdge> edges = new ArrayList<FpsVisualizationEdge>();
//		List<String> founds = new ArrayList<String>();
//		srcEdges.addAll(rootEdges);
//		for (FpsVisualizationEdge edge : srcEdges) {
//			Map<String, String> p = new HashMap<String, String>();
//			String to = edge.getTo();
//			if (!founds.contains(to) && (export || (!export && StringUtils.isNumeric(to)))) {
//				// data can contain { since we receive it like that. Just escape it, don't
//				// remove it.
//				founds.add(to.replace("{", "\\{"));
//			}
//		}
//		Map<String, String> p = new HashMap<String, String>();
//// search only NPIs.  Could use "label" but it's currently not index in Solr
//		String exportStr = export ? " " : " AND label != 'referring_to_bene' ";
////		
//		String sql = "";
//		sql = "from VizDmeEdge where dst in :founds  " + exportStr + " AND ranking <= :ranking order by ranking asc";
//
//		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setInteger("ranking", 66)
//				.setParameterList("founds", founds).setMaxResults(2000);
//		List<VizDmeEdge> dbEdges = query.list();
//		edges = FpsDomainObjectConverter.convertRequestDbToBean(dbEdges, FpsVisualizationEdge.class);

		return edges;

	}

	@Override
	public FpsVisualization loadDmeVisualization(String subjId, final Integer ranking) {

		// p.put("debug", "all");
		Map<String, String> p = new HashMap<String, String>();
		//
		final Integer rankingBucketMax = ranking * 22;
		final Integer rankingBucketMin = ranking == 1 ? 1 : ((ranking - 1) * 22) + 1;
		FpsVisualization viz = new FpsVisualization();
//		QueryResponse response = null;
//		try {
//
//			List<FpsVisualizationEdge> parents = new ArrayList<FpsVisualizationEdge>();
//			FpsVisualizationEdge parent = new FpsVisualizationEdge();
//			parent.setTo(subjId);
//			parents.add(parent);
//			// start with level 0 which is just the ASR NPI
//			// load all edges because the UI needs all edges.
//			List<FpsVisualizationEdge> edges = loadDmeEdges(parents, 0, ranking == -1);
//			// eliminate duplicate edges (based on to/from) as these can clutter the UI
//			// when the same edge is displayed more than once
//			edges = Lists.newArrayList(Sets.newHashSet(edges));
//			// load just the edges for this tier to find the nodes to load.
//			List<FpsVisualizationEdge> rawEdges = edges;
//
//			viz.setEdges(edges);
//
//			List<String> edgeTo = new ArrayList<String>();
//			if (ranking == 1 || ranking == -1) {
//				edgeTo.add(subjId.replace("{", "\\{"));
//			}
//			for (FpsVisualizationEdge edge : edges) {
//				// if edge.getto doesn't exist as a from in edges with lower ranking.
//				edgeTo.add(edge.getTo().replace("{", "\\{"));
//				if (edge.getFrom() != null)
//					edgeTo.add(edge.getFrom().replace("{", "\\{"));
//			}
//			// remove duplicates
//			edgeTo = Lists.newArrayList(Sets.newHashSet(edgeTo));
//
//			List<FpsVisualizationNode> nodes = new ArrayList<FpsVisualizationNode>();
//			if (edgeTo.size() > 0) {
//				int start = 0;
//				int cap = 1024;
//				int loaded = 0;
//				// the NPIs in edgeTo may be greater than what is actually in the nodes
//				// collection
//				// so just loop through the expected nodes even if the actual nodes are smaller
//				while (start < edgeTo.size()) {
//					logger.info("start = " + start + ", loaded = " + loaded);
//
//					String sql = "from VizDmeNode where id in :ids";
//					logger.info("query dme nodes start with " + ranking);
//
//					Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setParameterList("ids",
//							edgeTo.size() > cap ? Lists.newArrayList(edgeTo).subList(start,
//									cap + loaded < edgeTo.size() ? cap + loaded : edgeTo.size()) : edgeTo)
//							.setMaxResults(ranking == -1 ? 1024 : 500);
//					List<VizDmeNode> dbNodes = query.list();
//					nodes.addAll(FpsDomainObjectConverter.convertRequestDbToBean(dbNodes, FpsVisualizationNode.class));
//
//					logger.info("query dme nodes complete");
//
//					loaded += nodes.size();
//					start += cap + 1;
//				}
//
////				nodes = ranking > -1 && nodes.size() > 22 ? nodes.subList(0, 22) : nodes;
//
//				FpsVisualizationNode parentNode = new FpsVisualizationNode();
//				parentNode.setId(subjId);
//				if (!nodes.contains(parentNode) && ranking == 1) {
//
//					logger.info("query parent dme nodes start with " + ranking);
//					String sql2 = "from VizDmeNode where id = :id";
//					Query query = (Query) getSnowflakeCurrentSession().createQuery(sql2).setString("id", subjId);
//					List<VizDmeNode> parentNodes = query.list();
//					nodes.addAll(
//							FpsDomainObjectConverter.convertRequestDbToBean(parentNodes, FpsVisualizationNode.class));
//
//					logger.info("query parent dme nodes complete");
//				}
//
//			}
//			List<NvUcmSummary> zrData = fpsHubDao.findUcmSummaryForNpis(edgeTo);
//			for (FpsVisualizationNode node : nodes) {
//				NvUcmSummary template = new NvUcmSummary();
//				template.setNpi(node.getNpi());
//				if (zrData.contains(template)) {
//					node.setZr(zrData.get(zrData.indexOf(template)).getZrStatus());
//					node.setInvestigations(zrData.get(zrData.indexOf(template)).getCaseStatus());
//					node.setLeadInd(zrData.get(zrData.indexOf(template)).getLeadInd());
//				}
//
//			}
//			viz.setNodes(nodes);
//		} catch (SolrServerException e) {
//			logger.log(Level.SEVERE, "solr error loading viz dme data", e);
//		} catch (IOException e) {
//			logger.log(Level.SEVERE, "io solr error loading viz dme data", e);
//		}

		return viz;
	}

	private List<FpsVisualizationEdge> loadHhaEdges(List<FpsVisualizationEdge> srcEdges, int tier, boolean export)
			throws  IOException {
		List<FpsVisualizationEdge> edges = new ArrayList<FpsVisualizationEdge>();
		List<String> founds = new ArrayList<String>();

//		for (FpsVisualizationEdge edge : srcEdges) {
//			Map<String, String> p = new HashMap<String, String>();
//			String to = edge.getTo();
//			if (!founds.contains(to) && (export || (!export && StringUtils.isNumeric(to)))) {
//				// data can contain { since we receive it like that. Just escape it, don't
//				// remove it.
//				founds.add(to.replace("{", "\\{"));
//			}
//		}
//		String exportStr = export ? "  " : " AND label != 'referring_to_bene' ";
//		String sql = "";
//		sql = "from VizHhaEdge where src in :founds  " + exportStr + " AND ranking <= :ranking order by ranking asc";
//
//		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setInteger("ranking", 66)
//				.setParameterList("founds", founds).setMaxResults(2000);
//		List<VizHhaEdge> dbEdges = query.list();
//		edges = FpsDomainObjectConverter.convertRequestDbToBean(dbEdges, FpsVisualizationEdge.class);
//		logger.info("edges found for tier " + (tier + 1) + ": " + edges.size());
//		// only load details for 3 levels.
//		if (edges.size() > 0 && tier < 2) {
//			edges.addAll(loadHhaEdges(edges, tier == 0 ? 1 : tier + 1, export));
//
//		}

		return edges;
	}

	@Override
	public FpsVisualization loadHhaVisualization(String subjId, final Integer ranking) {
		// p.put("debug", "all");
		Map<String, String> p = new HashMap<String, String>();
		//
		final Integer rankingBucketMax = ranking * 22;
		final Integer rankingBucketMin = ranking == 1 ? 1 : ((ranking - 1) * 22) + 1;
		FpsVisualization viz = new FpsVisualization();
//		QueryResponse response;
//		try {
//
//			List<FpsVisualizationEdge> parents = new ArrayList<FpsVisualizationEdge>();
//			FpsVisualizationEdge parent = new FpsVisualizationEdge();
//			parent.setTo(subjId);
//			parents.add(parent);
//			// start with level 0 which is just the ASR NPI
//			// load all edges because the UI needs all edges.
//			List<FpsVisualizationEdge> edges = loadHhaEdges(parents, 0, ranking == -1);
//			// eliminate duplicate edges (based on to/from) as these can clutter the UI
//			// when the same edge is displayed more than once
//			edges = Lists.newArrayList(Sets.newHashSet(edges));
//			// load just the edges for this tier to find the nodes to load.
//			List<FpsVisualizationEdge> rawEdges = edges;
//
//			viz.setEdges(edges);
//
//			List<String> edgeTo = new ArrayList<String>();
//			if (ranking == 1 || ranking == -1) {
//				edgeTo.add(subjId.replace("{", "\\{"));
//			}
//			for (FpsVisualizationEdge edge : edges) {
//				// if edge.getto doesn't exist as a from in edges with lower ranking.
//				edgeTo.add(edge.getTo().replace("{", "\\{"));
//			}
//			// remove duplicates
//			edgeTo = Lists.newArrayList(Sets.newHashSet(edgeTo));
//
//			List<FpsVisualizationNode> nodes = new ArrayList<FpsVisualizationNode>();
//			if (edgeTo.size() > 0) {
//
//				logger.info("query hha nodes start with " + ranking);
//
//				String sql = "from VizHhaNode where id in :ids";
//
//				Query query = (Query) getSnowflakeCurrentSession().createQuery(sql)
//						.setParameterList("ids",
//								edgeTo.size() > 1024 ? Lists.newArrayList(edgeTo).subList(0, 1024) : edgeTo)
//						.setMaxResults(ranking == -1 ? 1024 : 500);
//				List<VizHhaNode> dbNodes = query.list();
//				nodes.addAll(FpsDomainObjectConverter.convertRequestDbToBean(dbNodes, FpsVisualizationNode.class));
//				logger.info("query hha nodes complete");
//
////				nodes = response.getBeans(FpsVisualizationNode.class);
//
////				nodes = ranking > -1 && nodes.size() > 22 ? nodes.subList(0, 22) : nodes;
//
//				FpsVisualizationNode parentNode = new FpsVisualizationNode();
//				parentNode.setId(subjId);
//				if (!nodes.contains(parentNode) && ranking == 1) {
//					edgeTo.add(subjId);
//
//					logger.info("query parent hha nodes start with " + ranking);
//
//					String sql2 = "from VizHhaNode where id = :id";
//					query = (Query) getSnowflakeCurrentSession().createQuery(sql2).setString("id", subjId);
//					List<VizHhaNode> parentNodes = query.list();
//					nodes.addAll(
//							FpsDomainObjectConverter.convertRequestDbToBean(parentNodes, FpsVisualizationNode.class));
//
//					logger.info("query parent hha nodes complete");
//				}
//
//			}
//			List<NvUcmSummary> zrData = fpsHubDao.findUcmSummaryForNpis(edgeTo);
//			for (FpsVisualizationNode node : nodes) {
//				NvUcmSummary template = new NvUcmSummary();
//				template.setNpi(node.getNpi());
//				if (zrData.contains(template)) {
//					node.setZr(zrData.get(zrData.indexOf(template)).getZrStatus());
//					node.setInvestigations(zrData.get(zrData.indexOf(template)).getCaseStatus());
//					node.setLeadInd(zrData.get(zrData.indexOf(template)).getLeadInd());
//				}
//
//			}
//			viz.setNodes(nodes);
//		} catch (SolrServerException e) {
//			logger.log(Level.SEVERE, "solr error loading viz hha data", e);
//		} catch (IOException e) {
//			logger.log(Level.SEVERE, "io solr error loading viz hha data", e);
//		}

		return viz;

	}

	@Override
	public FpsVisualization loadVisualization(String subjId, String modelId) {
		return loadVisualization(subjId, modelId, null);
	}

	@Override
	public List<FpsVisualizationEdge> loadVisualizationDates(String subjId, String modelId) {
		return loadVisualizationDates(subjId, modelId, 1);
	}

	@Override
	public List<FpsVisualizationEdge> loadVisualizationDates(String subjId, String modelId, int rows) {
		List<FpsVisualizationEdge> edges = new ArrayList<FpsVisualizationEdge>();

		try {

			String sql = " select max(e.modelRunDt) from VizSnaEdge e where e.subjPrvdrNpi = :subjId and e.modelBusnsId = :modelId order by e.modelRunDt desc ";

			Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setString("subjId", subjId)
					.setString("modelId", modelId);
			Object maxDate = query.uniqueResult();
			logger.info("query max edges date start");

//			
			// if we didn't find a max date, then return a blank object
			if (maxDate == null) {
				logger.info("query max edges date complete, no data found");
				return edges;
			}
			FpsVisualizationEdge maxEdge = new FpsVisualizationEdge();
			maxEdge.setModelRunDt((Date) maxDate);
			edges.add(maxEdge);

		} catch (Exception e) {
			logger.log(Level.SEVERE, "io snowflake error loading viz data", e);
		}

		return edges;
	}

	@Override
	public FpsVisualization loadVisualization(String subjId, String modelId, Date modelRunDt) {
		// p.put("debug", "all");
		Map<String, String> p = new HashMap<String, String>();
		Map<String, String> maxP = new HashMap<String, String>();
		//

		FpsVisualization viz = new FpsVisualization();
//		QueryResponse response = null;
//		try {
//
//			Date d = modelRunDt;
//			if (d == null) {
//				logger.info("query max edges date start");
//				List<FpsVisualizationEdge> maxDate = loadVisualizationDates(subjId, modelId);
////				response = solrClient.query(collVizEdges, new MapSolrParams(maxP), METHOD.GET);
//				// if we didn't find a max date, then return a blank object
//				if (maxDate == null || maxDate.size() == 0) {
//					logger.info("query max edges date complete, no data found");
//					return viz;
//				}
//				d = maxDate.get(0).getModelRunDt();
//			}
//			logger.info("query edges start with " + FpsDomainObjectConverter.convertDateToString(d));
//
//			String sql = " from VizSnaEdge where subjPrvdrNpi = :subjId and modelBusnsId = :modelId and modelRunDt = :modelRunDt ";
//
//			Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setString("subjId", subjId)
//					.setDate("modelRunDt", d).setString("modelId", modelId).setMaxResults(300);
//
////			response = solrClient.query(collVizEdges, new MapSolrParams(p), METHOD.GET);
//
//			logger.info("query edges complete");
//			List<VizSnaEdge> dbEdges = query.list();
//			List<FpsVisualizationEdge> edges = FpsDomainObjectConverter.convertRequestDbToBean(dbEdges,
//					FpsVisualizationEdge.class);
//			viz.setEdges(edges);
//
//			// p.put("q", "node_id:" + subjId);//+" AND
//			// model_busns_id:"+modelId);
//			List<String> edgeTo = new ArrayList<String>();
//			edgeTo.add(subjId);
//			for (FpsVisualizationEdge edge : edges) {
//				edgeTo.add(edge.getRltdPrvdrNpi());
//			}
//			String sql2 = "from VizSnaNode where npi in :edgeTo and modelBusnsId = :modelId and modelRunDt = :runDate";
//
//			p.put("fl", "*,subj_prvdr_role:subj_prvdr_type");
//			Query query2 = (Query) getSnowflakeCurrentSession().createQuery(sql2).setParameterList("edgeTo", edgeTo)
//					.setDate("runDate", d).setString("modelId", modelId).setMaxResults(300);
//			List<VizSnaNode> dbNodes = query2.list();
//			logger.info("query nodes start with " + d);
////			response = solrClient.query(collVizNodes, new MapSolrParams(p), METHOD.GET);
//			logger.info("query nodes complete");
//
//			List<FpsVisualizationNode> nodes = FpsDomainObjectConverter.convertRequestDbToBean(dbNodes,
//					FpsVisualizationNode.class);
//			viz.setNodes(nodes);
//		} catch (Exception e) {
//			logger.log(Level.SEVERE, "io solr error loading viz data", e);
//		}

		return viz;

	}

	@Override
	public ClaimsSolrStream loadVizSharedBenes(FpsModel model, String npi, Date modelRunDt, List<String> relatedNPIs) {

		String npiList = StringUtils.join(relatedNPIs, " ");
		String alertKey = "*\\^" + model.getModelId() + "\\^" + npi + "*";
		ClaimsSolrStream css = new ClaimsSolrStream();
		String sql = "with x as (select clm_hic_num from fps_portal.fps_clm_solr where clm_rndrg_prvdr_npi_num in (:npis) OR clm_blg_prvdr_npi_num in (:npis) OR clm_atndg_prvdr_npi_num in (:npis) OR clm_rfrg_prvdr_npi_num in (:npis)) "
				+ "select clm_mbi,a.clm_hic_num,clm_bene_state_cd,src_zip5_cd,bene_1st_name,bene_last_name,bene_line_1_adr,bene_line_2_adr,src_zip_plc_name "
				+ "from fps_portal.fps_clm_solr a inner join x on x.clm_hic_num = a.clm_hic_num inner join fps_portal.fps_alert_key ak on "
				+ "a.clm_Id=ak.clm_Id where ak.model_Id = :modelId and ak.subj_Id = :npi ";

		try {
			Query query2 = (Query) getSnowflakeCurrentSession().createSQLQuery(sql)
					.setParameterList("npis", relatedNPIs).setInteger("modelId", model.getModelId())
					.setString("npi", npi);
			List<Object[]> retval = query2.list();
			ClaimsSolrStreamResult result = new ClaimsSolrStreamResult();
			List<SolrStreamAsrDetailClaimLineItem> items = new ArrayList<>();
			for (Object[] o : retval) {
				SolrStreamAsrDetailClaimLineItem item = new SolrStreamAsrDetailClaimLineItem();
				item.setMbi(o[0] != null ? o[0].toString() : "");
				item.setBeneId(o[1] != null ? o[1].toString() : "");
				item.setBeneStateCd(o[2] != null ? o[2].toString() : "");
				item.setBeneZip(o[3] != null ? o[3].toString() : "");
				item.setBeneFirstName(o[4] != null ? o[4].toString() : "");
				item.setBeneLastName(o[5] != null ? o[5].toString() : "");
				item.setBeneAddress(o[6] != null ? o[6].toString() : "");
				item.setBeneAddress2(o[7] != null ? o[7].toString() : "");
				item.setBeneCity(o[8] != null ? o[8].toString() : "");
				items.add(item);

			}
			result.setDocs(items);
			css.setResult(result);
			return css;

		} catch (HibernateException ce) {
			logger.log(Level.SEVERE, "error querying snowflake", ce);
		}
		return null;
	}

	@Override
	public String checkForVisualization(String subjId) {
		if ("local".equalsIgnoreCase(buildFor)) {
			return "N"; 
		}
		String sql = "select count(*)  from VizHhaEdge where src = :src and ranking between 0 and 66 ";

		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setString("src", subjId);
		Long totalRows = (Long) query.uniqueResult();

		return totalRows > 0 ? "Y" : "N";
	}

	@Override
	public String checkForDmeVisualization(String subjId) {
		if ("local".equalsIgnoreCase(buildFor)) {
			return "N"; 
		}
		String sql = "select count(*)  from VizDmeEdge where src = :src and ranking between 0 and 66 ";

		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql).setString("src", subjId);
		Long totalRows = (Long) query.uniqueResult();

		return totalRows > 0 ? "Y" : "N";
	}

	@Override
	public List<Integer> loadAvailableRptCardAttrs(int alertId, boolean isPartD) {
		String table = "FpsClmMdcd fpsclm";
		String subTable = "fpsclm.fpsClmAttrs fpsclmattrs";

		String sql = "select distinct fpsclmattrs.attrSqncNum   from " + table + " inner join " + subTable
				+ "  where fpsclmattrs.alertId =  :alertId ";

//				+ "   where attributeKey like :attrKey and alertKey like :alertKey ";

		Query query = (Query) getSnowflakeCurrentSession().createQuery(sql)
//				.setString("attrKey", attrKey)
//				.setString("alertKey", alertKey);
				.setInteger("alertId", alertId);
		List<Object> rawResults = query.list();
		List<Integer> results = new ArrayList<>();
		if (rawResults != null) {
			for (Object o : rawResults) {
				results.add((Integer) o);
			}
		}
		return results;
	}

	@Override
	public List<FpsRiskScreRptCardDtl> loadReportCardContribModelAndNpi(String modelBusnsId, String npi, Date runDate) {
		Date d = null;
		if (runDate != null) {
			d = runDate;
		} else {
			d = loadReportCardContribMostRecentAlert(npi, modelBusnsId);
		}

		Criteria c = getCurrentSession().createCriteria(FpsRiskScreRptCardDtl.class, "card")

				.add(Restrictions.eq("modelBusnsId", modelBusnsId)).add(Restrictions.eq("card.prvdrNpiNum", npi));

		c.add(Restrictions.eq("card.alertCreatDt", d));
		// }

		c.addOrder(new EnhancedRiskScoreContribOrder());
		List<FpsRiskScreRptCardDtl> rcs = c.list();
		return rcs;

	}

	@Override
	public Date loadReportCardContribMostRecentAlert(String subjId, String modelBusnsId) {
		Criteria criteria = getCurrentSession().createCriteria(FpsRiskScreRptCardDtl.class, "alert");
		criteria.setFirstResult(0);
		criteria.setMaxResults(1);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<FpsRiskScreRptCardDtl> alerts = criteria.add(Restrictions.eq("modelBusnsId", modelBusnsId))
				.add(Restrictions.eq("prvdrNpiNum", subjId)).addOrder(Order.desc("alertCreatDt")).list();

		FpsRiskScreRptCardDtl alert = new FpsRiskScreRptCardDtl();
		if (alerts != null && alerts.size() > 0) {
			alert = (FpsRiskScreRptCardDtl) alerts.get(0);
			return alert.getAlertCreatDt();
		}
		return null;
	}

	@Override
	public List<Object[]> loadTotalPayment(int asrptId) {
		String sql = "select " +
				"a.BILLING_PRVDR_NPI, " +
				"a.asrpt_id, " +
				"a.subj_id, " +
				"a.model_busns_id, " +
				"a.geo_mdcd_usps_state_cd, " +
				"a.upic_jurisdiction, " +
				"a.npi_alert_type_desc, " +
				"a.clm_srvc_ctgry_desc, " +
				"a.clm_srvc_sbctgry_desc, " +
				"a.clm_plan_num, " +
				"a.mc_name, " +
				"sum(case when a.clm_srvc_sbctgry_desc = 'Encounter' then a.clm_bild_amt else 0 end) mco_billed, " +
				"sum(case when a.clm_srvc_sbctgry_desc = 'FFS' then a.clm_bild_amt else 0 end) ffs_billed, " +
				"sum(case when a.clm_srvc_sbctgry_desc = 'Encounter' then a.clm_pd_amt else 0 end) mco_pd, " +
				"sum(case when a.clm_srvc_sbctgry_desc = 'FFS' then a.clm_pd_amt else 0 end) ffs_pd, " +
				"sum(case when a.clm_srvc_sbctgry_desc = 'Encounter' then a.clm_rcpnt_cnt else 0 end) mco_cnt, " +
				"sum " +
				"( " +
				"   case when a.clm_srvc_sbctgry_desc = 'FFS' then a.clm_rcpnt_cnt else 0 end " +
				") " +
				"ffs_cnt " +
				"from fps2.FPS_ASRPT_SUMMARY_BILLING_PRVDRS_AMT_MDCD a " +
				"where  a.latest_alert_ind = 'Y' " +
				"and a.asrpt_id = :asrptId " +
				"group by a.BILLING_PRVDR_NPI, " +
				"a.subj_id, " +
				"a.asrpt_id, " +
				"a.model_busns_id, " +
				"a.geo_mdcd_usps_state_cd, " +
				"a.upic_jurisdiction, " +
				"a.npi_alert_type_desc, " +
				"a.clm_srvc_ctgry_desc, " +
				"a.clm_srvc_sbctgry_desc, " +
				"a.clm_plan_num, " +
				"a.mc_name " ;
		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		List<Object[]> rows = query.setInteger("asrptId", asrptId).list();

		return rows;

	}

	@Override
	public List<FpsRptCardDtlMdcd> loadReportCardClaims(int paramInt, String paramString) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<FpsAlertClmAsctn> loadClaimsForModel(int paramInt, String paramString) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<MdcdModelState> loadStatesForAlert(String npi, String modelBusnsId, String status, String zone) {
		Criteria criteria = getCurrentSession().createCriteria(FpsAlertMdcd.class, "alerts");
		List<MdcdModelState> states = new ArrayList<>();
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<Object[]> alerts = criteria.add(Restrictions.eq("subjId", npi)).createAlias("alerts.fpsModel", "model")

				.add(Restrictions.eq("model.modelBusnsId", modelBusnsId)).add(Restrictions.eq("drvdZnCd", zone))
				.add(Restrictions.eq("alertStusCd", "new".equalsIgnoreCase(status) ? "12" : "13"))
				.setProjection(Projections.projectionList().add(Projections.property("submtgMdcdUspsStateCd")))
				.addOrder(Order.asc("submtgMdcdUspsStateCd"))

				.list();
		if (alerts != null) {
			for (Object obj : alerts) {
				if (obj != null) {
					MdcdModelState ms = new MdcdModelState();
					String state = (String) obj;
					ms.setState(state);
					ms.setModelLabel(state + " - " + modelBusnsId + " (" + status + ")");
					states.add(ms);

				}
			}
		}
		return states;
	}
	@Override
	public List<AsrGenericCode> loadStatesForASRForSearch(Integer asrptId, String zone) {
		List<AsrGenericCode> searchStates = new ArrayList<>();
		List<MdcdModelState> states = loadStatesForASR(asrptId, zone);
		if (states == null) {
			return searchStates;
		}
		for (MdcdModelState state: states) {
			AsrGenericCode searchState = new AsrGenericCode();
			searchState.setCode(state.getLclState());
			searchStates.add(searchState);
		}
		return searchStates;
	}
	@Override
	public List<MdcdModelState> loadStatesForASR(Integer asrptId, String zone) {
	
		List<MdcdModelState> states = new ArrayList<>();
		// MAC/MEDIC should never get here, but if they do...
		if (zone != null && naRoles.contains(zone.toLowerCase())) {
			return states;
		}
		Criteria criteria = getCurrentSession().createCriteria(FpsAlertMdcd.class, "alerts");
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		criteria.add(Restrictions.eq("asctn.asrptId", asrptId)).createAlias("alerts.fpsAsrptAlertAsctns", "asctn")
				.setProjection(Projections.distinct(Projections.projectionList().add(Projections.property("submtgMdcdUspsStateCd"))
						.add(Projections.property("submtgMdcdLclStateCd"))))
				.addOrder(Order.asc("submtgMdcdUspsStateCd"));
		// if not one of the global roles, filter by zone
		if (zone != null && !cmsRoles.contains(zone.toLowerCase())) {
			criteria.add(Restrictions.eq("drvdZnCd", zone.toLowerCase()).ignoreCase());

		}
		List<Object[]> alerts = criteria.list();

		if (alerts != null) {
			for (Object[] obj : alerts) {
				if (obj != null) {
					MdcdModelState ms = new MdcdModelState();
					String state = (String) obj[0];
					ms.setState(state);
					ms.setLclState((String) obj[1]);
					states.add(ms);

				}
			}
		}
		return states;
	}

	@Override
	public List<FpsSplmntlVizDtlMdcd> loadSplmntlVizForModelRun(String modelBusnsId, String npi, Date modelRunDt, String state) {
		return loadSplmntlVizForModelRun(modelBusnsId, npi, modelRunDt, null, state);
	}

	@Override
	public Date getLastAlertDateForCustomTableViz(String modelBusnsId, String npi, Integer vizId, String state) {
		String sql = "select max(a.model_run_dt) as updtdt from fps2.FPS_SUPPLEMENTALVIZ_DTL_MDCD a inner join fps2.mdcd_geo_lcl_state_cd b on a.submtg_mdcd_lcl_state_cd = b.geo_mdcd_lcl_state_cd where a.npi_num = :npi and  a.model_busns_id = :modelBusnsId "
		+ " and b.geo_mdcd_usps_state_cd = :state ";
		if (vizId != null) {
			sql += "and a.SPLMTL_VIZ_ID = :vizId";
		}

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("modelBusnsId", modelBusnsId);
		query.setParameter("npi", npi);
		query.setParameter("state", state);
		if (vizId != null) {
			query.setParameter("vizId", vizId);
		}
		List<Date> rows = query.list();
		if (rows != null) {
			return (Date) rows.get(0);
		}
		return null;
	}
	
	@Override
	public List<FpsSplmntlVizDtlMdcd> loadSplmntlVizForModelRun(String modelBusnsId, String npi, Date modelRunDt,
			Integer splmtnVizId, String state) {
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

		String dStr = format.format(modelRunDt);

		Criteria c = getCurrentSession().createCriteria(FpsSplmntlVizDtlMdcd.class, "suppViz")
				.createAlias("suppViz.mdcdGeoLclStateCd", "stateCd")
				.add(Restrictions.eq("suppViz.npiNum", npi))
				.add(Restrictions.eq("suppViz.modelBusnsId", modelBusnsId))
				.add(Restrictions.eq("stateCd.geoMdcdUspsStateCd", state))

				.add(Restrictions.eq("suppViz.modelRunDt", modelRunDt));
		if (splmtnVizId != null) {
			c.add(Restrictions.eq("suppViz.splmntlVizId", splmtnVizId));
		}
		List<FpsSplmntlVizDtlMdcd> tables = c.addOrder(new GenericOrderBy("SPLMTL_VIZ_ID"))
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return tables;

	}

	@Override
	public List<FpsCstmTblLabelSnpshtMdcd> loadCustomTablesForModelSnapshot(String modelBusnsId, Date runDate) {
		List<FpsCstmTblLabelSnpshtMdcd> tables = getCurrentSession().createCriteria(FpsCstmTblLabelSnpshtMdcd.class, "table")

				.add(Restrictions.eq("modelBusnsId", modelBusnsId))
				.add(Restrictions.eq("modelRunDt", runDate))
				.addOrder(new GenericOrderBy("cast(trim(cstm_Tbl_id) as INTEGER)"))

				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return tables;
	}

	@Override
	public FpsSplmntlVizLabelSnpshtMdcd loadSplmntlVizTablesForModelSnapshot(String modelBusnsId, Date runDate, Integer splmtlVizId ) {
		List<FpsSplmntlVizLabelSnpshtMdcd> tables = getCurrentSession().createCriteria(FpsSplmntlVizLabelSnpshtMdcd.class, "table")

				.add(Restrictions.eq("modelBusnsId", modelBusnsId))
				.add(Restrictions.eq("modelRunDt", runDate))
				.add(Restrictions.eq("splmtlVizId", splmtlVizId))
				.addOrder(Order.asc("splmtlVizId"))

				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return tables!= null && tables.size() > 0 ? tables.get(0) : null;
	}
}
