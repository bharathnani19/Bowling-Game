package gov.hhs.cms.fps.model.generated;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
@Table(name="FPS_FDS_EVNT_TRANS")
public class FpsFdsEvntTrans {

	private Integer evntTransId;
	private String evntTypeCd;
	private String objTypeCd;
	private String objSrchId;
	private String ntfctnStusCd;
	private Date audtInsrtTs;
	private String audtInsrtId;
	private String audtUpdtId;
	private Date audtUpdtTs;
	private Set<FpsFdsNtfctn>  fpsFdsNtfctns;
	@Id
	@Column(name="EVNT_TRANS_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getEvntTransId() {
		return evntTransId;
	}
	public void setEvntTransId(Integer evntTransId) {
		this.evntTransId = evntTransId;
	}
	@Column(name="EVNT_TYPE_CD")
	public String getEvntTypeCd() {
		return evntTypeCd;
	}
	public void setEvntTypeCd(String evntTypeCd) {
		this.evntTypeCd = evntTypeCd;
	}
	@Column(name="OBJ_TYPE_CD")
	public String getObjTypeCd() {
		return objTypeCd;
	}
	public void setObjTypeCd(String objTypeCd) {
		this.objTypeCd = objTypeCd;
	}
	@Column(name="OBJ_SRCH_ID")
	public String getObjSrchId() {
		return objSrchId;
	}
	public void setObjSrchId(String objSrchId) {
		this.objSrchId = objSrchId;
	}
	@Column(name="NTFCTN_STUS_CD")
	public String getNtfctnStusCd() {
		return ntfctnStusCd;
	}
	public void setNtfctnStusCd(String ntfctnStusCd) {
		this.ntfctnStusCd = ntfctnStusCd;
	}
	@Column(name = "AUDT_INSRT_ID", nullable = false, length = 128)
	public String getAudtInsrtId() {
		return this.audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_INSRT_TS", nullable = false, length = 26)
	public Date getAudtInsrtTs() {
		return this.audtInsrtTs;
	}

	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	@Column(name = "AUDT_UPDT_ID", length = 128)
	public String getAudtUpdtId() {
		return this.audtUpdtId;
	}

	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_UPDT_TS", nullable = false, length = 26)
	public Date getAudtUpdtTs() {
		return audtUpdtTs;
	}
	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "fpsFdsEvntTrans")
	@NotFound(action=NotFoundAction.IGNORE)
	public Set<FpsFdsNtfctn> getFpsFdsNtfctns() {
		return fpsFdsNtfctns;
	}
	public void setFpsFdsNtfctns(Set<FpsFdsNtfctn> fpsFdsNtfctns) {
		this.fpsFdsNtfctns = fpsFdsNtfctns;
	}
}
