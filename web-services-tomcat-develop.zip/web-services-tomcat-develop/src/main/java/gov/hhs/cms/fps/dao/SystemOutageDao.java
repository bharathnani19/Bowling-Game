/*
 * 
 */
package gov.hhs.cms.fps.dao;

import java.util.List;

import gov.hhs.cms.fps.model.generated.FpsPlndSysOutge;

public interface SystemOutageDao {
	public List<FpsPlndSysOutge> loadSystemOutages();
	/**
	 * Adds the update planned system outage.
	 *
	 * @param outage the outage
	 */
	public FpsPlndSysOutge addUpdatePlannedSystemOutage(FpsPlndSysOutge outage);
	public void deleteSystemOutage(int sysOutageId);

	
}
