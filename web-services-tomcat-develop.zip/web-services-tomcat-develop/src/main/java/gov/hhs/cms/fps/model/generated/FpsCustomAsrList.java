package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class FpsCustomAsrList implements Serializable {

	private Integer customAsrListId;
	private String listNm;
	private String actvInd;
	private String userJrsdctn;
	private String userNm;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private String audtUpdtId;
	private Date audtUpdtTs;
	
	private List<FpsCustomAsrListItem> fpsCustomAsrListItems;

	public List<FpsCustomAsrListItem> getFpsCustomAsrListItems() {
		return fpsCustomAsrListItems;
	}

	public void setFpsCustomAsrListItems(List<FpsCustomAsrListItem> fpsCustomAsrListItems) {
		this.fpsCustomAsrListItems = fpsCustomAsrListItems;
	}

	public Integer getCustomAsrListId() {
		return customAsrListId;
	}

	public void setCustomAsrListId(Integer customAsrListId) {
		this.customAsrListId = customAsrListId;
	}

	public String getListNm() {
		return listNm;
	}

	public void setListNm(String listNm) {
		this.listNm = listNm;
	}

	public String getActvInd() {
		return actvInd;
	}

	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}

	public String getUserJrsdctn() {
		return userJrsdctn;
	}

	public void setUserJrsdctn(String userJrsdctn) {
		this.userJrsdctn = userJrsdctn;
	}

	public String getUserNm() {
		return userNm;
	}

	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}

	public String getAudtInsrtId() {
		return audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	public Date getAudtInsrtTs() {
		return audtInsrtTs;
	}

	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	public String getAudtUpdtId() {
		return audtUpdtId;
	}

	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}

	public Date getAudtUpdtTs() {
		return audtUpdtTs;
	}

	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
}
