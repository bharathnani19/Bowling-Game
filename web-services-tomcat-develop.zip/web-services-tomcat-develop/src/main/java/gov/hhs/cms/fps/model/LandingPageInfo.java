package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import gov.hhs.cms.fps.model.generated.FpsRptAcsMtrxVw;
import gov.hhs.cms.fps.model.generated.faq.FpsUsrSprtQstn;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class LandingPageInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4959890814737310495L;
	private List<FpsPlannedSystemOutage> outages;
	private List<FpsSystemMessage> messages;
	private AsrManagementReport asrManagementReport;
	private List<FpsSystemStatus> statuses;
	private List<AsrDetailModel> models;
	private List<AsrDetailModel> nonActiveModels;
	private List<AsrDetailModel> modelsMdcd;
	private List<AsrDetailModel> nonActiveModelsMdcd;
	private String wsBuildMetadata;
	private List<UserAccessRequest> requests;
	private int newSysMsgCt = 0;
	private List<FpsRptAcsMtrxVw>  reports;
	private List<FpsUsrSprtQstn> faqs;
	private List<Watchlist> watchlists;
	private String defaultAsrView;
	private String apsWatchlistSubInd = "N";
	// CM-4211
//	private String customAsrEnabled;
	
	public List<FpsPlannedSystemOutage> getOutages() {
		return outages;
	}
	public void setOutages(List<FpsPlannedSystemOutage> outages) {
		this.outages = outages;
	}
	public List<FpsSystemMessage> getMessages() {
		return messages;
	}
	public void setMessages(List<FpsSystemMessage> messages) {
		this.messages = messages;
	}
	public AsrManagementReport getAsrManagementReport() {
		return asrManagementReport;
	}
	public void setAsrManagementReport(AsrManagementReport asrManagementReport) {
		this.asrManagementReport = asrManagementReport;
	}
	public List<FpsSystemStatus> getStatuses() {
		return statuses;
	}
	public void setStatuses(List<FpsSystemStatus> statuses) {
		this.statuses = statuses;
	}
	public List<AsrDetailModel> getModels() {
		return models;
	}
	public void setModels(List<AsrDetailModel> models) {
		this.models = models;
	}
	public String getWsBuildMetadata() {
		return wsBuildMetadata;
	}
	public void setWsBuildMetadata(String wsBuildMetadata) {
		this.wsBuildMetadata = wsBuildMetadata;
	}
	public List<UserAccessRequest> getRequests() {
		return requests;
	}
	public void setRequests(List<UserAccessRequest> requests) {
		this.requests = requests;
	}
	public int getNewSysMsgCt() {
		return newSysMsgCt;
	}
	public void setNewSysMsgCt(int newSysMsgCt) {
		this.newSysMsgCt = newSysMsgCt;
	}
	public List<AsrDetailModel> getNonActiveModels() {
		return nonActiveModels;
	}
	public void setNonActiveModels(List<AsrDetailModel> nonActiveModels) {
		this.nonActiveModels = nonActiveModels;
	}
	public List<FpsRptAcsMtrxVw> getReports() {
		return reports;
	}
	public void setReports(List<FpsRptAcsMtrxVw> reports) {
		this.reports = reports;
	}
	public List<FpsUsrSprtQstn> getFaqs() {
		return faqs;
	}
	public void setFaqs(List<FpsUsrSprtQstn> faqs) {
		this.faqs = faqs;
	}
	public List<Watchlist> getWatchlists() {
		return watchlists;
	}
	public void setWatchlists(List<Watchlist> watchlists) {
		this.watchlists = watchlists;
	}
//	public String getCustomAsrEnabled() {
//		return customAsrEnabled;
//	}
//	public void setCustomAsrEnabled(String customAsrEnabled) {
//		this.customAsrEnabled = customAsrEnabled;
//	}
	public String getDefaultAsrView() {
		return defaultAsrView;
	}
	public void setDefaultAsrView(String defaultAsrView) {
		this.defaultAsrView = defaultAsrView;
	}
	public List<AsrDetailModel> getModelsMdcd() {
		return modelsMdcd;
	}
	public void setModelsMdcd(List<AsrDetailModel> modelsMdcd) {
		this.modelsMdcd = modelsMdcd;
	}
	public List<AsrDetailModel> getNonActiveModelsMdcd() {
		return nonActiveModelsMdcd;
	}
	public void setNonActiveModelsMdcd(List<AsrDetailModel> nonActiveModelsMdcd) {
		this.nonActiveModelsMdcd = nonActiveModelsMdcd;
	}
	public String getApsWatchlistSubInd() {
		return apsWatchlistSubInd;
	}
	public void setApsWatchlistSubInd(String apsWatchlistSubInd) {
		this.apsWatchlistSubInd = apsWatchlistSubInd;
	}
}
