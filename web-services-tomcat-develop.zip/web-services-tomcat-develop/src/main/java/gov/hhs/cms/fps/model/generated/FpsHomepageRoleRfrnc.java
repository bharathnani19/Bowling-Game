package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Table(name="fps_homepage_role_rfrnc", schema="fps2")
@Entity
public class FpsHomepageRoleRfrnc implements Serializable {
	private String homepageCd;
	private String roleNm;
	private FpsHomepageRfrnc fpsHomepageRfrnc;
	
	@Id
	@Column(name="homepage_cd")
	public String getHomepageCd() {
		return homepageCd;
	}
	public void setHomepageCd(String homepageCd) {
		this.homepageCd = homepageCd;
	}
	@Id
	@Column(name="role_nm")
	public String getRoleNm() {
		return roleNm;
	}
	public void setRoleNm(String roleNm) {
		this.roleNm = roleNm;
	}
	@ManyToOne(fetch = FetchType.LAZY,optional = false)
	@JoinColumn(name="homepage_cd", referencedColumnName = "homepage_cd")
	@JsonIgnore
	public FpsHomepageRfrnc getFpsHomepageRfrnc() {
		return fpsHomepageRfrnc;
	}
	public void setFpsHomepageRfrnc(FpsHomepageRfrnc fpsHomepageRfrnc) {
		this.fpsHomepageRfrnc = fpsHomepageRfrnc;
	}
	

}
