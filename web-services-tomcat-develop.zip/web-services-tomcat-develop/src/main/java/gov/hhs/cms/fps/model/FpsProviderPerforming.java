package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)

public class FpsProviderPerforming implements Serializable {

	private Integer ptanCnt;
	private Integer uniqueBeneCnt;
	private Integer cncBeneCnt;
	private BigDecimal cncBenePct;
	private String cncBenePaidAmt;
	private BigDecimal cncBenePaidPct;
	private String dualEligPaidAmt;
	private BigDecimal dualEligPaidPct;
	private Integer dualEligCnt;
	private BigDecimal dualEligPct;
	private Integer mSuffixBeneCnt;
	private BigDecimal mSuffixBenePct;
	private String mSuffixBenePaidAmt;
	private BigDecimal mSuffixBenePaidPct;
	private String topReferringNpiNum;
	private Integer topReferringClaimsCnt;
	private BigDecimal topReferringClaimsPct;
	private Integer totalReferringNpiCnt;
	private Integer totalReferringNpiCncCnt;
	private String topDiagnosis;
	private Integer paidClaimsTopDiagnosisCnt;
	private Integer uniqueBeneReferredCnt;
	private BigDecimal referredToPerformedPct;
	private Integer dmcClaimsCnt;
	private Integer partBClaimsCnt;
	private BigDecimal dmeToPartBClaimsPct;
	private List<FpsProviderPerfTop5Proc> top5procs;

	private Integer dmeClaimCnt;
	private Integer ptbClaimCnt;
	private Integer hhClaimCnt;
	private Integer ptClaimCnt;
	private Integer pdtryClaimCnt;
	private Integer hospcClaimCnt;
	private Integer chiroClaimCnt;
	
	public Integer getPtanCnt() {
		return ptanCnt;
	}
	public void setPtanCnt(Integer ptanCnt) {
		this.ptanCnt = ptanCnt;
	}
	public Integer getUniqueBeneCnt() {
		return uniqueBeneCnt;
	}
	public void setUniqueBeneCnt(Integer uniqueBeneCnt) {
		this.uniqueBeneCnt = uniqueBeneCnt;
	}
	public Integer getCncBeneCnt() {
		return cncBeneCnt;
	}
	public void setCncBeneCnt(Integer cncBeneCnt) {
		this.cncBeneCnt = cncBeneCnt;
	}
	public BigDecimal getCncBenePct() {
		return cncBenePct;
	}
	public void setCncBenePct(BigDecimal cncBenePct) {
		this.cncBenePct = cncBenePct;
	}
	public String getCncBenePaidAmt() {
		return cncBenePaidAmt;
	}
	public void setCncBenePaidAmt(String cncBenePaidAmt) {
		this.cncBenePaidAmt = cncBenePaidAmt;
	}
	public BigDecimal getCncBenePaidPct() {
		return cncBenePaidPct;
	}
	public void setCncBenePaidPct(BigDecimal cncBenePaidPct) {
		this.cncBenePaidPct = cncBenePaidPct;
	}
	public String getDualEligPaidAmt() {
		return dualEligPaidAmt;
	}
	public void setDualEligPaidAmt(String dualEligPaidAmt) {
		this.dualEligPaidAmt = dualEligPaidAmt;
	}
	public BigDecimal getDualEligPaidPct() {
		return dualEligPaidPct;
	}
	public void setDualEligPaidPct(BigDecimal dualEligPaidPct) {
		this.dualEligPaidPct = dualEligPaidPct;
	}
	public Integer getDualEligCnt() {
		return dualEligCnt;
	}
	public void setDualEligCnt(Integer dualEligCnt) {
		this.dualEligCnt = dualEligCnt;
	}
	public BigDecimal getDualEligPct() {
		return dualEligPct;
	}
	public void setDualEligPct(BigDecimal dualEligPct) {
		this.dualEligPct = dualEligPct;
	}
	public Integer getmSuffixBeneCnt() {
		return mSuffixBeneCnt;
	}
	public void setmSuffixBeneCnt(Integer mSuffixBeneCnt) {
		this.mSuffixBeneCnt = mSuffixBeneCnt;
	}
	public BigDecimal getmSuffixBenePct() {
		return mSuffixBenePct;
	}
	public void setmSuffixBenePct(BigDecimal mSuffixBenePct) {
		this.mSuffixBenePct = mSuffixBenePct;
	}
	public String getmSuffixBenePaidAmt() {
		return mSuffixBenePaidAmt;
	}
	public void setmSuffixBenePaidAmt(String mSuffixBenePaidAmt) {
		this.mSuffixBenePaidAmt = mSuffixBenePaidAmt;
	}
	public BigDecimal getmSuffixBenePaidPct() {
		return mSuffixBenePaidPct;
	}
	public void setmSuffixBenePaidPct(BigDecimal mSuffixBenePaidPct) {
		this.mSuffixBenePaidPct = mSuffixBenePaidPct;
	}
	public String getTopReferringNpiNum() {
		return topReferringNpiNum;
	}
	public void setTopReferringNpiNum(String topReferringNpiNum) {
		this.topReferringNpiNum = topReferringNpiNum;
	}
	public Integer getTopReferringClaimsCnt() {
		return topReferringClaimsCnt;
	}
	public void setTopReferringClaimsCnt(Integer topReferringClaimsCnt) {
		this.topReferringClaimsCnt = topReferringClaimsCnt;
	}
	public BigDecimal getTopReferringClaimsPct() {
		return topReferringClaimsPct;
	}
	public void setTopReferringClaimsPct(BigDecimal topReferringClaimsPct) {
		this.topReferringClaimsPct = topReferringClaimsPct;
	}
	public Integer getTotalReferringNpiCnt() {
		return totalReferringNpiCnt;
	}
	public void setTotalReferringNpiCnt(Integer totalReferringNpiCnt) {
		this.totalReferringNpiCnt = totalReferringNpiCnt;
	}
	public Integer getTotalReferringNpiCncCnt() {
		return totalReferringNpiCncCnt;
	}
	public void setTotalReferringNpiCncCnt(Integer totalReferringNpiCncCnt) {
		this.totalReferringNpiCncCnt = totalReferringNpiCncCnt;
	}
	public String getTopDiagnosis() {
		return topDiagnosis;
	}
	public void setTopDiagnosis(String topDiagnosis) {
		this.topDiagnosis = topDiagnosis;
	}
	public Integer getPaidClaimsTopDiagnosisCnt() {
		return paidClaimsTopDiagnosisCnt;
	}
	public void setPaidClaimsTopDiagnosisCnt(Integer paidClaimsTopDiagnosisCnt) {
		this.paidClaimsTopDiagnosisCnt = paidClaimsTopDiagnosisCnt;
	}
	public Integer getUniqueBeneReferredCnt() {
		return uniqueBeneReferredCnt;
	}
	public void setUniqueBeneReferredCnt(Integer uniqueBeneReferredCnt) {
		this.uniqueBeneReferredCnt = uniqueBeneReferredCnt;
	}
	public BigDecimal getReferredToPerformedPct() {
		return referredToPerformedPct;
	}
	public void setReferredToPerformedPct(BigDecimal referredToPerformedPct) {
		this.referredToPerformedPct = referredToPerformedPct;
	}
	public Integer getDmcClaimsCnt() {
		return dmcClaimsCnt;
	}
	public void setDmcClaimsCnt(Integer dmcClaimsCnt) {
		this.dmcClaimsCnt = dmcClaimsCnt;
	}
	public Integer getPartBClaimsCnt() {
		return partBClaimsCnt;
	}
	public void setPartBClaimsCnt(Integer partBClaimsCnt) {
		this.partBClaimsCnt = partBClaimsCnt;
	}
	public BigDecimal getDmeToPartBClaimsPct() {
		return dmeToPartBClaimsPct;
	}
	public void setDmeToPartBClaimsPct(BigDecimal dmeToPartBClaimsPct) {
		this.dmeToPartBClaimsPct = dmeToPartBClaimsPct;
	}
	public List<FpsProviderPerfTop5Proc> getTop5procs() {
		return top5procs;
	}
	public void setTop5procs(List<FpsProviderPerfTop5Proc> top5procs) {
		this.top5procs = top5procs;
	}
	public Integer getDmeClaimCnt() {
		return dmeClaimCnt;
	}
	public void setDmeClaimCnt(Integer dmeClaimCnt) {
		this.dmeClaimCnt = dmeClaimCnt;
	}
	public Integer getPtbClaimCnt() {
		return ptbClaimCnt;
	}
	public void setPtbClaimCnt(Integer ptbClaimCnt) {
		this.ptbClaimCnt = ptbClaimCnt;
	}
	public Integer getHhClaimCnt() {
		return hhClaimCnt;
	}
	public void setHhClaimCnt(Integer hhClaimCnt) {
		this.hhClaimCnt = hhClaimCnt;
	}
	public Integer getPtClaimCnt() {
		return ptClaimCnt;
	}
	public void setPtClaimCnt(Integer ptClaimCnt) {
		this.ptClaimCnt = ptClaimCnt;
	}
	public Integer getPdtryClaimCnt() {
		return pdtryClaimCnt;
	}
	public void setPdtryClaimCnt(Integer pdtryClaimCnt) {
		this.pdtryClaimCnt = pdtryClaimCnt;
	}
	public Integer getHospcClaimCnt() {
		return hospcClaimCnt;
	}
	public void setHospcClaimCnt(Integer hospcClaimCnt) {
		this.hospcClaimCnt = hospcClaimCnt;
	}
	public Integer getChiroClaimCnt() {
		return chiroClaimCnt;
	}
	public void setChiroClaimCnt(Integer chiroClaimCnt) {
		this.chiroClaimCnt = chiroClaimCnt;
	}
	
	
	
	
	
}
