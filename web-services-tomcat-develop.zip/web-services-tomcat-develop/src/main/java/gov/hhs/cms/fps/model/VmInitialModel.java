package gov.hhs.cms.fps.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class VmInitialModel {
	
	private String modelName;
	private Integer latestVmId;
	
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public Integer getLatestVmId() {
		return latestVmId;
	}
	public void setLatestVmId(Integer latestVmId) {
		this.latestVmId = latestVmId;
	}

}
