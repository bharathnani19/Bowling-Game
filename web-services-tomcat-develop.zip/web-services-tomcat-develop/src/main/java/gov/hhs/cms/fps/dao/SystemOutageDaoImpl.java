/*
 * 
 */
package gov.hhs.cms.fps.dao;

import java.util.Calendar;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import gov.hhs.cms.fps.model.generated.FpsPlndSysOutge;
@Repository("systemOutageDao")
public class SystemOutageDaoImpl extends BaseDao<Integer, FpsPlndSysOutge> implements SystemOutageDao {



	@Override
	@Deprecated
	public List<FpsPlndSysOutge> loadSystemOutages() {
		// TODO Auto-generated method stub
		Criteria c = getCurrentSession().createCriteria(FpsPlndSysOutge.class);
		Calendar cal = Calendar.getInstance();
		
		c.add(Restrictions.ge("outgeEndDt", cal.getTime()));
		return  c.list();
	}
	/* (non-Javadoc)
	 * @see gov.hhs.cms.fps.dao.FpsServiceDao#addUpdatePlannedSystemOutage(gov.hhs.cms.fps.model.dao.FpsPlannedSystemOutage)
	 */
	@Override
	@Deprecated
	public FpsPlndSysOutge  addUpdatePlannedSystemOutage(FpsPlndSysOutge outage) {
		getCurrentSession().saveOrUpdate(outage);
		return outage;
		
	}
	@Override
	@Deprecated
	public void deleteSystemOutage(int sysOutageId) {
		FpsPlndSysOutge outage = new FpsPlndSysOutge();
		outage.setPlndSysOutgeId(sysOutageId);
		getCurrentSession().delete(outage);
		
	}

}
