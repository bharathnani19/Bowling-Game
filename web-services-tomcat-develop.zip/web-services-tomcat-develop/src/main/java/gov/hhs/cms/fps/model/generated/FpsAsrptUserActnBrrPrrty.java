package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name = "FPS_ASRPT_USER_ACTN_BRR_PRRTY")
public class FpsAsrptUserActnBrrPrrty implements Serializable {

	private FpsAsrptUserActnBrr fpsAsrptUserActnBrr;
	private Integer asrptUserActnBrrPrrtyId;
	private Integer asrptUserActnBrrId;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private String extrnlPrrtyId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_USER_ACTN_BRR_ID", updatable = false, insertable = false)
	public FpsAsrptUserActnBrr getFpsAsrptUserActnBrr() {
		return fpsAsrptUserActnBrr;
	}
	public void setFpsAsrptUserActnBrr(FpsAsrptUserActnBrr fpsAsrptUserActnBrr) {
		this.fpsAsrptUserActnBrr = fpsAsrptUserActnBrr;
	}
	@Id
//  @GeneratedValue(strategy=GenerationType.IDENTITY)
	@GeneratedValue(generator = "FpsAsrptUserActnBrrPrrty_SEQ")
	@SequenceGenerator(name = "FpsAsrptUserActnBrrPrrty_SEQ", sequenceName = "fps2.fps_asrpt_user_actn_brr_prrty_asrpt_user_actn_brr_prrty_id_seq", allocationSize = 20)
	@Column(name="ASRPT_USER_ACTN_BRR_PRRTY_ID")
	public Integer getAsrptUserActnBrrPrrtyId() {
		return asrptUserActnBrrPrrtyId;
	}
	public void setAsrptUserActnBrrPrrtyId(Integer asrptUserActnBrrPrrtyId) {
		this.asrptUserActnBrrPrrtyId = asrptUserActnBrrPrrtyId;
	}
	@Column(name="ASRPT_USER_ACTN_BRR_ID")
	public Integer getAsrptUserActnBrrId() {
		return asrptUserActnBrrId;
	}
	public void setAsrptUserActnBrrId(Integer asrptUserActnBrrId) {
		this.asrptUserActnBrrId = asrptUserActnBrrId;
	}
	@Column(name="AUDT_INSRT_ID")
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	@Column(name="AUDT_INSRT_TS")
	public Date getAudtInsrtTs() {
		return audtInsrtTs;
	}
	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	@Column(name="EXTRNL_PRRTY_ID")
	public String getExtrnlPrrtyId() {
		return extrnlPrrtyId;
	}
	public void setExtrnlPrrtyId(String extrnlPrrtyId) {
		this.extrnlPrrtyId = extrnlPrrtyId;
	}
}
