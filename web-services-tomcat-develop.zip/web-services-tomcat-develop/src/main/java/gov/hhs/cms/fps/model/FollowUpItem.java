package gov.hhs.cms.fps.model;

import java.util.List;

import gov.hhs.cms.fps.util.FpsEnums.EntityType;
import gov.hhs.cms.fps.util.FpsEnums.EventType;

public class FollowUpItem extends WatchlistItem {
	
	private List<String> models;
	private Double asrptRiskScreNum;
	private Integer asrptId;
	private String subjId;
	private List<AsrSummary> asrs;
	private String ucmCaseId;
	private String ucmUserId;
	private List<String> oldModels;
	private String ucmClosedDt;
	private String eduInd;
	private Double priorityScore;
	private String userEmail;
	private String userId;
	private EntityType type = EntityType.WATCHLIST;
	private EventType eventType = EventType.FOLLOWUP;
	private String eventName = "Follow Up";
	private String emailSubject = "APS Notification";
	
	public FollowUpItem() {}
	public FollowUpItem(String userId) {
		this.userId = userId;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public List<String> getModels() {
		return models;
	}
	public void setModels(List<String> models) {
		this.models = models;
	}
	public Double getAsrptRiskScreNum() {
		return asrptRiskScreNum;
	}
	public void setAsrptRiskScreNum(Double asrptRiskScreNum) {
		this.asrptRiskScreNum = asrptRiskScreNum;
	}
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	public List<AsrSummary> getAsrs() {
		return asrs;
	}
	public void setAsrs(List<AsrSummary> asrs) {
		this.asrs = asrs;
	}
	public String getSubjId() {
		return subjId;
	}
	public void setSubjId(String subjId) {
		this.subjId = subjId;
	}
	public String getUcmCaseId() {
		return ucmCaseId;
	}
	public void setUcmCaseId(String ucmCaseId) {
		this.ucmCaseId = ucmCaseId;
	}
	public String getUcmUserId() {
		return ucmUserId;
	}
	public void setUcmUserId(String ucmUserId) {
		this.ucmUserId = ucmUserId;
	}
	public List<String> getOldModels() {
		return oldModels;
	}
	public void setOldModels(List<String> oldModels) {
		this.oldModels = oldModels;
	}
	public String getUcmClosedDt() {
		return ucmClosedDt;
	}
	public void setUcmClosedDt(String ucmClosedDt) {
		this.ucmClosedDt = ucmClosedDt;
	}
	public String getEduInd() {
		return eduInd;
	}
	public void setEduInd(String eduInd) {
		this.eduInd = eduInd;
	}
	public Double getPriorityScore() {
		return priorityScore;
	}
	public void setPriorityScore(Double priorityScore) {
		this.priorityScore = priorityScore;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public EntityType getType() {
		return type;
	}
	public void setType(EntityType type) {
		this.type = type;
	}

	public EventType getEventType() {
		return eventType;
	}
	public void setEventType(EventType eventType) {
		this.eventType = eventType;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getEmailSubject() {
		return emailSubject;
	}
	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}
}
