package gov.hhs.cms.fps.controller;

import java.util.logging.Logger;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ApplicationContextEvent;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;
@Component
public class ApplicationEventHandler implements ApplicationListener<ApplicationContextEvent> {
	private static final Logger logger = Logger.getLogger(ApplicationEventHandler.class.getName());
	@Override
	public void onApplicationEvent(ApplicationContextEvent event) {
		if (event instanceof ContextClosedEvent){
			logger.info("FPS2:APPLICATION:STOP:application stopped.  This does not necessarily mean the server was stopped.");
		}else if (event instanceof ContextRefreshedEvent){
			logger.info("FPS2:APPLICATION:START:application started.  This does not necessarily mean the server was started.");

		}else{
			logger.info("FPS2:APPLICATION:OTHER:application " + event.getClass().getName());

		}
		
	}

}
