package gov.hhs.cms.fps.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class FpsUserPreference implements Serializable {

	private String userId;
	private String prefName;
	private String prefJson;
	private String prefLbl;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPrefName() {
		return prefName;
	}
	public void setPrefName(String prefName) {
		this.prefName = prefName;
	}
	public String getPrefJson() {
		return prefJson;
	}
	public void setPrefJson(String prefJson) {
		this.prefJson = prefJson;
	}
	public String getPrefLbl() {
		return prefLbl;
	}
	public void setPrefLbl(String prefLbl) {
		this.prefLbl = prefLbl;
	}
}
