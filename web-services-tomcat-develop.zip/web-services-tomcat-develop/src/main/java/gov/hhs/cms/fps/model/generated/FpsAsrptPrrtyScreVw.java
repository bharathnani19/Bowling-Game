package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;

@Entity
@Table(name="FPS_ASRPT_PRIORITY_SCRE_VW")
@BatchSize(size=500)

public class FpsAsrptPrrtyScreVw implements Serializable {

	private int asrptId;
	private Date scoreDt;
	private BigDecimal score;
	private BigDecimal prevScore;
	private BigDecimal scoreDelta;
//	private FpsAsrpt fpsAsrpt;
	private Integer actionability;
	private Integer timeliness;
	private String postEdInd;
	
	@Id
	@Column(name="ASRPT_ID")
	public int getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(int asrptId) {
		this.asrptId = asrptId;
	}
	
	@Column(name="PRIORITY_SCORE_DT")
	public Date getScoreDt() {
		return scoreDt;
	}
	public void setScoreDt(Date scoreDt) {
		this.scoreDt = scoreDt;
	}
	@Column(name="PRIORITY_SCRE")
	public BigDecimal getScore() {
		return score;
	}
	public void setScore(BigDecimal score) {
		this.score = score;
	}
	@Column(name="PREV_PRIORITY_SCRE")
	public BigDecimal getPrevScore() {
		return prevScore;
	}
	public void setPrevScore(BigDecimal prevScore) {
		this.prevScore = prevScore;
	}
	@Column(name="PRIORITY_SCRE_DELTA")
	public BigDecimal getScoreDelta() {
		return scoreDelta;
	}
	public void setScoreDelta(BigDecimal scoreDelta) {
		this.scoreDelta = scoreDelta;
	}
//	@ManyToOne(fetch=FetchType.LAZY)
//    @JoinColumn(name="ASRPT_ID", referencedColumnName="ASRPT_ID", updatable=false, insertable=false)
//	
//	public FpsAsrpt getFpsAsrpt() {
//		return fpsAsrpt;
//	}
//	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
//		this.fpsAsrpt = fpsAsrpt;
//	}
	@Column(name="PRIORITY_ACTIONABILITY")

	public Integer getActionability() {
		return actionability;
	}
	public void setActionability(Integer actionability) {
		this.actionability = actionability;
	}	
	@Column(name="PRIORITY_TIMELINESS")

	public Integer getTimeliness() {
		return timeliness;
	}
	public void setTimeliness(Integer timeliness) {
		this.timeliness = timeliness;
	}
	@Column(name="PE90_FLAG")
	public String getPostEdInd() {
		return postEdInd;
	}
	public void setPostEdInd(String postEdInd) {
		this.postEdInd = postEdInd;
	}
	
	
}
