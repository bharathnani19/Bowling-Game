package gov.hhs.cms.fps.model.generated;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.cache.annotation.Cacheable;

@Entity
@Table(name = "fps_alerted_ssf_asr_p1_cost_key_vw")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY, region = "claim")
@BatchSize(size = 1000)

public class FpsClmAsrptP1AsrCost implements java.io.Serializable {

	private Integer clmId;
	private Integer asrptId;
	private Integer clmRvwInd;
	private String modelString;
	private FpsClmP1 fpsClm;

	@Id
	@Column(name = "P1_CLM_ID")
	public Integer getClmId() {
		return clmId;
	}

	public void setClmId(Integer clmId) {
		this.clmId = clmId;
	}

	@Id
	@Column(name = "ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}

	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}


	@Column(name = "CLM_RVW_IND")
	public Integer getClmRvwInd() {
		return clmRvwInd;
	}

	public void setClmRvwInd(Integer clmRvwInd) {
		this.clmRvwInd = clmRvwInd;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(referencedColumnName = "ID", name="P1_CLM_ID", updatable = false, insertable = false)
	public FpsClmP1 getFpsClm() {
		return fpsClm;
	}

	public void setFpsClm(FpsClmP1 fpsClm) {
		this.fpsClm = fpsClm;
	}
	//@Id
	@Column(name = "MODEL_BUSNS_IDS")
	public String getModelString() {
		return modelString;
	}

	public void setModelString(String modelString) {
		this.modelString = modelString;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((asrptId == null) ? 0 : asrptId.hashCode());
		result = prime * result + ((clmId == null) ? 0 : clmId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FpsClmAsrptP1AsrCost other = (FpsClmAsrptP1AsrCost) obj;
		if (asrptId == null) {
			if (other.asrptId != null)
				return false;
		} else if (!asrptId.equals(other.asrptId))
			return false;
		if (clmId == null) {
			if (other.clmId != null)
				return false;
		} else if (!clmId.equals(other.clmId))
			return false;
		return true;
	}

}
