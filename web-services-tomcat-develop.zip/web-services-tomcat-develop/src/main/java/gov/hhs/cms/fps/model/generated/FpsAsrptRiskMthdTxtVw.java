package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="FPS_ASR_RISK_MTHD_TXT_VW")
public class FpsAsrptRiskMthdTxtVw implements Serializable {

	private Integer asrptId;
	private BigDecimal riskScreNum;
	private String mthdTxt;
	
	@Id
	@Column(name="ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	@Column(name="ASRPT_RISK_SCRE_NUM")
	public BigDecimal getRiskScreNum() {
		return riskScreNum;
	}
	public void setRiskScreNum(BigDecimal riskScreNum) {
		this.riskScreNum = riskScreNum;
	}
	@Column(name="ASR_RISK_MTHD_TXT")
	public String getMthdTxt() {
		return mthdTxt;
	}
	public void setMthdTxt(String mthdTxt) {
		this.mthdTxt = mthdTxt;
	}
}
