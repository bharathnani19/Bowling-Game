/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class FpsCommonActivityType.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class FpsCommonActivityType implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 295906754247826752L;
	
	/** The actvty type cd. */
	private String actvtyTypeCd;
	
	/** The actvty type desc. */
	private String actvtyTypeDesc;
	
	/**
	 * Gets the actvty type cd.
	 *
	 * @return the actvty type cd
	 */
	public String getActvtyTypeCd() {
		return actvtyTypeCd;
	}
	
	/**
	 * Sets the actvty type cd.
	 *
	 * @param actvtyTypeCd the new actvty type cd
	 */
	public void setActvtyTypeCd(String actvtyTypeCd) {
		this.actvtyTypeCd = actvtyTypeCd;
	}
	
	/**
	 * Gets the actvty type desc.
	 *
	 * @return the actvty type desc
	 */
	public String getActvtyTypeDesc() {
		return actvtyTypeDesc;
	}
	
	/**
	 * Sets the actvty type desc.
	 *
	 * @param actvtyTypeDesc the new actvty type desc
	 */
	public void setActvtyTypeDesc(String actvtyTypeDesc) {
		this.actvtyTypeDesc = actvtyTypeDesc;
	}
}
