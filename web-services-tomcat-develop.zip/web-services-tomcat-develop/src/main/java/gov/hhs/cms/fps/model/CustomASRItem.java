package gov.hhs.cms.fps.model;

import java.util.Date;
import java.util.List;

import gov.hhs.cms.fps.util.FpsEnums.EntityType;
import gov.hhs.cms.fps.util.FpsEnums.EventType;

public class CustomASRItem extends WatchlistItem {
	

	private String userEmail;
	private String userId;
	private EntityType type = EntityType.WATCHLIST;
	private EventType eventType = EventType.CUSTOMASR;
	private String eventName = "Custom ASRs";
	private String emailSubject = "Custom ASR Notification";
	private String listName;
	private Integer listCnt;
	private Date listDt;
	private String listStatus;
	
	public CustomASRItem() {}
	public CustomASRItem(String userId) {
		this.userId = userId;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public EntityType getType() {
		return type;
	}
	public void setType(EntityType type) {
		this.type = type;
	}

	public EventType getEventType() {
		return eventType;
	}
	public void setEventType(EventType eventType) {
		this.eventType = eventType;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getEmailSubject() {
		return emailSubject;
	}
	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}
	public String getListName() {
		return listName;
	}
	public void setListName(String listName) {
		this.listName = listName;
	}
	public Integer getListCnt() {
		return listCnt;
	}
	public void setListCnt(Integer listCnt) {
		this.listCnt = listCnt;
	}
	public Date getListDt() {
		return listDt;
	}
	public void setListDt(Date listDt) {
		this.listDt = listDt;
	}
	public String getListStatus() {
		return listStatus;
	}
	public void setListStatus(String listStatus) {
		this.listStatus = listStatus;
	}
}
