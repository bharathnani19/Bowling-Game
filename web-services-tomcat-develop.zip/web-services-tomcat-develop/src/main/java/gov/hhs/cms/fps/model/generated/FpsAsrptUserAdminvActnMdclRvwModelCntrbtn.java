package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.hibernate.annotations.Type;
@Entity
@Table(name="FPS_ASRPT_USER_ADMINV_ACTN_MDCL_RVW_MODEL_CNTRBTN")
public class FpsAsrptUserAdminvActnMdclRvwModelCntrbtn implements Serializable {

	private Integer asrptUserAdminvActnMdclRvwModelCntrbtnId;
	private FpsAsrptUserAdminvActnMdclRvw fpsAsrptUserAdminvActnMdclRvw;
	private String ucmAsrId;
	private String npiNum;
	private String subjDesc;
	private LocalDateTime ratingDt;
	private String eventType;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private String audtUpdtId;
	private Date audtUpdtTs;
	private String recChgInd;
	private List<FpsAsrptUserAdminvActnMdclRvwModelCntrbtnModel> fpsAsrptUserAdminvActnMdclRvwModelCntrbtnModels;
	
	@Id
	@SequenceGenerator(name="asrpt_user_adminv_actn_mdcl_rvw_model_cntrbtn_id_seq",  sequenceName = "asrpt_user_adminv_actn_mdcl_rvw_model_cntrbtn_id_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "asrpt_user_adminv_actn_mdcl_rvw_model_cntrbtn_id_seq")
	@Column(name = "ASRPT_USER_ADMINV_ACTN_MDCL_RVW_MODEL_CNTRBTN_ID", unique = true, nullable = false)
	public Integer getAsrptUserAdminvActnMdclRvwModelCntrbtnId() {
		return asrptUserAdminvActnMdclRvwModelCntrbtnId;
	}
	public void setAsrptUserAdminvActnMdclRvwModelCntrbtnId(Integer asrptUserAdminvActnMdclRvwModelCntrbtnId) {
		this.asrptUserAdminvActnMdclRvwModelCntrbtnId = asrptUserAdminvActnMdclRvwModelCntrbtnId;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_USER_ADMINV_ACTN_MDCL_RVW_ID")
	public FpsAsrptUserAdminvActnMdclRvw getFpsAsrptUserAdminvActnMdclRvw() {
		return fpsAsrptUserAdminvActnMdclRvw;
	}
	public void setFpsAsrptUserAdminvActnMdclRvw(FpsAsrptUserAdminvActnMdclRvw fpsAsrptUserAdminvActnMdclRvw) {
		this.fpsAsrptUserAdminvActnMdclRvw = fpsAsrptUserAdminvActnMdclRvw;
	}
	@Column(name = "UCM_ASR_RCRD_ID")
	public String getUcmAsrId() {
		return ucmAsrId;
	}
	public void setUcmAsrId(String ucmAsrId) {
		this.ucmAsrId = ucmAsrId;
	}
	@Column(name = "NPI_NUM")
	public String getNpiNum() {
		return npiNum;
	}
	public void setNpiNum(String npiNum) {
		this.npiNum = npiNum;
	}
	@Column(name = "SUBJ_DESC")
	public String getSubjDesc() {
		return subjDesc;
	}
	public void setSubjDesc(String subjDesc) {
		this.subjDesc = subjDesc;
	}
	@Column(name = "RTNG_TS")
//	@Type(type = "gov.hhs.cms.fps.util.LocalDateTimeWrapperType")
	public LocalDateTime getRatingDt() {
		return ratingDt;
	}
	public void setRatingDt(LocalDateTime ratingDt) {
		this.ratingDt = ratingDt;
	}
	@Column(name = "EVNT_TYPE")
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}


	@Column(name = "AUDT_INSRT_ID", nullable = false, length = 128)
	public String getAudtInsrtId() {
		return this.audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_INSRT_TS", nullable = false, length = 26)
	public Date getAudtInsrtTs() {
		return this.audtInsrtTs;
	}

	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	@Column(name = "AUDT_UPDT_ID", length = 128)
	public String getAudtUpdtId() {
		return this.audtUpdtId;
	}

	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_UPDT_TS", length = 26)
	public Date getAudtUpdtTs() {
		return this.audtUpdtTs;
	}

	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}

	@Column(name = "REC_CHG_IND", length = 1)
	public String getRecChgInd() {
		return this.recChgInd;
	}

	public void setRecChgInd(String recChgInd) {
		this.recChgInd = recChgInd;
	}
	
	@Fetch(FetchMode.SELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "fpsAsrptUserAdminvActnMdclRvwModelCntrbtn", cascade = CascadeType.ALL)
	@BatchSize(size=1000)
	@NotFound(action = NotFoundAction.IGNORE)
	public List<FpsAsrptUserAdminvActnMdclRvwModelCntrbtnModel> getFpsAsrptUserAdminvActnMdclRvwModelCntrbtnModels() {
		return fpsAsrptUserAdminvActnMdclRvwModelCntrbtnModels;
	}
	public void setFpsAsrptUserAdminvActnMdclRvwModelCntrbtnModels(
			List<FpsAsrptUserAdminvActnMdclRvwModelCntrbtnModel> fpsAsrptUserAdminvActnMdclRvwModelCntrbtnModels) {
		this.fpsAsrptUserAdminvActnMdclRvwModelCntrbtnModels = fpsAsrptUserAdminvActnMdclRvwModelCntrbtnModels;
	}
	
	
}
