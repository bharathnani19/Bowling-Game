package gov.hhs.cms.fps.dao;

import java.util.List;

import gov.hhs.cms.fps.model.FaqSearchParameter;
import gov.hhs.cms.fps.model.generated.faq.FpsUsrSprtQstn;
import gov.hhs.cms.fps.model.generated.faq.FpsUsrSprtQstnCtgryRfrnc;

public interface UserSupportDao {

	public FpsUsrSprtQstn loadQuestionById(Integer id);
	public List<FpsUsrSprtQstn> loadQuestionsByCategory(String ct);
	public List<FpsUsrSprtQstn> loadQuestionsBySubcategory(String sct);
	public List<FpsUsrSprtQstn> loadQuestions(String ct, String sct);
	public void saveHistory(Integer id, String userId, String zn);
	public List<FpsUsrSprtQstn> search(String criteriaTxt);
	List<FpsUsrSprtQstnCtgryRfrnc> loadDefault();
	List<FpsUsrSprtQstn> loadLandingPageQuestions();
	public void saveSearch(FaqSearchParameter search, String userId, String zn);

}
