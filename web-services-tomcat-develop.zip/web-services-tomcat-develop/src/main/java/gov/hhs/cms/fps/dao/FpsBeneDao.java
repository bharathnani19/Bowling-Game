/*
 * 
 */
package gov.hhs.cms.fps.dao;

import java.util.List;

import gov.hhs.cms.fps.model.FpsCommonBeneficiary;
import gov.hhs.cms.fps.model.generated.FpsBene;

public interface FpsBeneDao {
	public FpsBene loadBene(long beneSk);

	
	public List<Object[]> loadBenesForAsrByModel(int asrptId, int modelId, int pageId);

	public List<FpsCommonBeneficiary> getBeneAddressData(int paramInt, int i);

	

}
