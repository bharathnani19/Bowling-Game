/*
 * 
 */
package gov.hhs.cms.fps.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class FpsCommonActionType.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class FpsCommonActionType {
	
	/** The actn type cd. */
	private String actnTypeCd;
	
	/** The actn type desc. */
	private String actnTypeDesc;
	
	/**
	 * Gets the actn type cd.
	 *
	 * @return the actn type cd
	 */
	public String getActnTypeCd() {
		return actnTypeCd;
	}
	
	/**
	 * Sets the actn type cd.
	 *
	 * @param actnTypeCd the new actn type cd
	 */
	public void setActnTypeCd(String actnTypeCd) {
		this.actnTypeCd = actnTypeCd;
	}
	
	/**
	 * Gets the actn type desc.
	 *
	 * @return the actn type desc
	 */
	public String getActnTypeDesc() {
		return actnTypeDesc;
	}
	
	/**
	 * Sets the actn type desc.
	 *
	 * @param actnTypeDesc the new actn type desc
	 */
	public void setActnTypeDesc(String actnTypeDesc) {
		this.actnTypeDesc = actnTypeDesc;
	}
}
