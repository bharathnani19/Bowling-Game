/*
 * 
 */
package gov.hhs.cms.fps.dao;

import java.util.Calendar;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import gov.hhs.cms.fps.model.generated.FpsPlndSysOutge;
import gov.hhs.cms.fps.model.generated.FpsSysMsg;
@Repository("systemMessageDao")
public class SystemMessageDaoImpl extends BaseDao<Integer, FpsSysMsg> implements SystemMessageDao {

	@Override
	@Deprecated
	public List<FpsSysMsg> loadSystemMessages() {
		// TODO Auto-generated method stub
		// messages w/in 90 days
		Criteria c = getCurrentSession().createCriteria(FpsSysMsg.class);
	
		Calendar cal = Calendar.getInstance();
		
		c.add(Restrictions.ge("sysEndDt", cal.getTime()));
	
		
		return c.list();
		
	}
	/* (non-Javadoc)
	 * @see gov.hhs.cms.fps.dao.FpsServiceDao#addUpdateSystemMessage(gov.hhs.cms.fps.model.dao.FpsSystemMessage)
	 */
	@Override
	@Deprecated
	public FpsSysMsg addUpdateSystemMessage(FpsSysMsg sysMessage) {
		getCurrentSession().saveOrUpdate(sysMessage);
		return sysMessage;
		
	}
	@Override
	@Deprecated
	public void deleteSystemMessage(int sysMsgId) {
		FpsSysMsg msg = new FpsSysMsg();
		msg.setSysMsgId(sysMsgId);
		getCurrentSession().delete(msg);
		
	}

}
