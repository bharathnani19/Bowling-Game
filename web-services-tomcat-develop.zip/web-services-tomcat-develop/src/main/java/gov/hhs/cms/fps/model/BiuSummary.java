package gov.hhs.cms.fps.model;

public class BiuSummary {
	private int day90Cnt;
	private int totalCnt;
	private String biuSummary;
	public int getDay90Cnt() {
		return day90Cnt;
	}
	public void setDay90Cnt(int day90Cnt) {
		this.day90Cnt = day90Cnt;
	}
	public int getTotalCnt() {
		return totalCnt;
	}
	public void setTotalCnt(int totalCnt) {
		this.totalCnt = totalCnt;
	}
	public String getBiuSummary() {
		return biuSummary;
	}
	public void setBiuSummary(String biuSummary) {
		this.biuSummary = biuSummary;
	}
	

}
