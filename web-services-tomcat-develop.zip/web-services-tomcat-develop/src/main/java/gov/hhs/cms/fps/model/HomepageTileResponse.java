package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class HomepageTileResponse implements Serializable {

	private List<HomepageTile> homepageTiles;
	
	public static HomepageTileResponse getTempTile() {
		HomepageTile t = new HomepageTile();
		List<HomepageTile> tiles = new ArrayList<>();
		t.setActvInd("Y");
		t.setHomepageCd("UP");
		t.setHomepageIconUrlNm("fa-user-secret");
		t.setHomepageUrlDesc("Access the Investigative UI for lead and investigation development");
		t.setHomepageUrlNm("Investigative Portal");
		t.setHomepageUrlTxt("/FPS2UnifiedPortal/#/IPHome");
		t.setNewTabInd("N");
		tiles.add(t);
		return new HomepageTileResponse(tiles);
	}
	public HomepageTileResponse() {
		
	}

	public HomepageTileResponse(List<HomepageTile> homepageTiles) {
		this.homepageTiles = homepageTiles;
	}

	public List<HomepageTile> getHomepageTiles() {
		return homepageTiles;
	}

	public void setHomepageTiles(List<HomepageTile> homepageTiles) {
		this.homepageTiles = homepageTiles;
	}
}
