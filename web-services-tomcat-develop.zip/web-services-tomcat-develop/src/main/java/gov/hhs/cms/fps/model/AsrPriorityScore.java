package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrPriorityScore implements Serializable {

	private int asrptId;
	private String criteriaDesc;
	private BigDecimal criteriaScore;
	private String criteriaVal;
	private BigDecimal criteriaWeight;
	private String rangeDesc;
	private String criteriaNm;
	
	public int getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(int asrptId) {
		this.asrptId = asrptId;
	}

	public String getCriteriaDesc() {
		return criteriaDesc;
	}
	public void setCriteriaDesc(String criteriaDesc) {
		this.criteriaDesc = criteriaDesc;
	}
	public BigDecimal getCriteriaScore() {
		return criteriaScore;
	}
	public void setCriteriaScore(BigDecimal criteriaScore) {
		this.criteriaScore = criteriaScore;
	}
	public String getCriteriaVal() {
		return criteriaVal;
	}
	public void setCriteriaVal(String criteriaVal) {
		this.criteriaVal = criteriaVal;
	}
	public BigDecimal getCriteriaWeight() {
		return criteriaWeight;
	}
	public void setCriteriaWeight(BigDecimal criteriaWeight) {
		this.criteriaWeight = criteriaWeight;
	}
	public String getRangeDesc() {
		return rangeDesc;
	}
	public void setRangeDesc(String rangeDesc) {
		this.rangeDesc = rangeDesc;
	}
	public String getCriteriaNm() {
		return criteriaNm;
	}
	public void setCriteriaNm(String criteriaNm) {
		this.criteriaNm = criteriaNm;
	}
	
}
