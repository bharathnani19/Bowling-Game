/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class BaseRequest.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public abstract class BaseRequest implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2267426272876311857L;
	
	/** The system name. */
	private String systemName;
	
	/** The request type. */
	private String requestType;
	
	/** The request sub type. */
	private String requestSubType;
	
	/** The transaction ID. */
	private String transactionID;
	
	
	/**
	 * Gets the system name.
	 *
	 * @return the system name
	 */
	public String getSystemName() {
		return systemName;
	}
	
	/**
	 * Sets the system name.
	 *
	 * @param systemName the new system name
	 */
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	
	/**
	 * Gets the request type.
	 *
	 * @return the request type
	 */
	public String getRequestType() {
		return requestType;
	}
	
	/**
	 * Sets the request type.
	 *
	 * @param requestType the new request type
	 */
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	
	/**
	 * Gets the request sub type.
	 *
	 * @return the request sub type
	 */
	public String getRequestSubType() {
		return requestSubType;
	}
	
	/**
	 * Sets the request sub type.
	 *
	 * @param requestSubType the new request sub type
	 */
	public void setRequestSubType(String requestSubType) {
		this.requestSubType = requestSubType;
	}
	
	/**
	 * Gets the transaction ID.
	 *
	 * @return the transaction ID
	 */
	public String getTransactionID() {
		return transactionID;
	}
	
	/**
	 * Sets the transaction ID.
	 *
	 * @param transactionID the new transaction ID
	 */
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	
	/**
	 * Gets the parameters.
	 *
	 * @return the parameters
	 */
	public abstract BaseSearchParameter getParameters();
	
}
