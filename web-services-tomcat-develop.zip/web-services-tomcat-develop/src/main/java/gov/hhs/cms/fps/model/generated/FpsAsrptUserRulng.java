package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.sql.Clob;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.Where;

@Entity
@Table(name="FPS_ASRPT_USER_RULNG")
@BatchSize(size=100)
@Where(clause="REC_CHG_IND != 'D' and CRNT_RULNG_CD != '-1'  AND REC_CHG_IND != 'R' ")
public class FpsAsrptUserRulng
  implements Serializable
{
  private int asrptUserRulngId;
  private FpsAsrptInvstgtn fpsAsrptInvstgtn;
  private FpsRulngRfrnc fpsRulngRfrnc;
  private String aplctnSuprUserId;
  private Long ptanNum;
  private String rfrdToUserId;
  private Date crntRulngDt;
  private String crntRulngCd;
  private String rulngChgRsnDesc;
  private String subjCntrctrInclsnPrrtyInd;
  private String fpsVrsnInd;
  private String audtInsrtId;
  private Date audtInsrtTs;
  private String audtUpdtId;
  private Date audtUpdtTs;
  private String recChgInd;
  private String crntRulngUserCmtTxt;
  private String lgcyAsrptLoid;
  private String rulngRsnCd;
  private FpsRulngRsnRfrnc fpsRulngRsnRfrnc;
  private String extrnlCaseId;
  private String ucmEvntId;
  
  public FpsAsrptUserRulng() {}
  
  public FpsAsrptUserRulng(int asrptUserRulngId, String fpsVrsnInd, String audtInsrtId, Date audtInsrtTs)
  {
    this.asrptUserRulngId = asrptUserRulngId;
    this.fpsVrsnInd = fpsVrsnInd;
    this.audtInsrtId = audtInsrtId;
    this.audtInsrtTs = audtInsrtTs;
  }
  
  public FpsAsrptUserRulng(int asrptUserRulngId, FpsAsrptInvstgtn fpsAsrptInvstgtn, FpsRulngRfrnc fpsRulngRfrnc, String aplctnSuprUserId, Long ptanNum, String rfrdToUserId, Date crntRulngDt, String rulngChgRsnDesc, String subjCntrctrInclsnPrrtyInd, String fpsVrsnInd, String audtInsrtId, Date audtInsrtTs, String audtUpdtId, Date audtUpdtTs, String recChgInd, String crntRulngUserCmtTxt, String lgcyAsrptLoid)
  {
    this.asrptUserRulngId = asrptUserRulngId;
    this.fpsAsrptInvstgtn = fpsAsrptInvstgtn;
    this.fpsRulngRfrnc = fpsRulngRfrnc;
    this.aplctnSuprUserId = aplctnSuprUserId;
    this.ptanNum = ptanNum;
    this.rfrdToUserId = rfrdToUserId;
    this.crntRulngDt = crntRulngDt;
    this.rulngChgRsnDesc = rulngChgRsnDesc;
    this.subjCntrctrInclsnPrrtyInd = subjCntrctrInclsnPrrtyInd;
    this.fpsVrsnInd = fpsVrsnInd;
    this.audtInsrtId = audtInsrtId;
    this.audtInsrtTs = audtInsrtTs;
    this.audtUpdtId = audtUpdtId;
    this.audtUpdtTs = audtUpdtTs;
    this.recChgInd = recChgInd;
    this.crntRulngUserCmtTxt = crntRulngUserCmtTxt;
    this.lgcyAsrptLoid = lgcyAsrptLoid;
  }
  
  @Id
//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@GeneratedValue(generator = "FpsAsrptUserRulng_SEQ")
	@SequenceGenerator(name = "FpsAsrptUserRulng_SEQ", sequenceName = "fps2.fps_asrpt_user_rulng_asrpt_user_rulng_id_seq", allocationSize = 20)
  @Column(name="ASRPT_USER_RULNG_ID", unique=true, nullable=false)
  public int getAsrptUserRulngId()
  {
    return this.asrptUserRulngId;
  }
  
  public void setAsrptUserRulngId(int asrptUserRulngId)
  {
    this.asrptUserRulngId = asrptUserRulngId;
  }
  
  @ManyToOne(fetch=FetchType.LAZY)
  @JoinColumn(name="ASRPT_INVSTGTN_ID")
  public FpsAsrptInvstgtn getFpsAsrptInvstgtn()
  {
    return this.fpsAsrptInvstgtn;
  }
  
  public void setFpsAsrptInvstgtn(FpsAsrptInvstgtn fpsAsrptInvstgtn)
  {
    this.fpsAsrptInvstgtn = fpsAsrptInvstgtn;
  }
  
  @ManyToOne(fetch=FetchType.LAZY)
  @JoinColumn(name="CRNT_RULNG_CD", updatable=false, insertable=false)
  public FpsRulngRfrnc getFpsRulngRfrnc()
  {
    return this.fpsRulngRfrnc;
  }
  
  public void setFpsRulngRfrnc(FpsRulngRfrnc fpsRulngRfrnc)
  {
    this.fpsRulngRfrnc = fpsRulngRfrnc;
  }
  
  @Column(name="APLCTN_SUPR_USER_ID", length=20)
  public String getAplctnSuprUserId()
  {
    return this.aplctnSuprUserId;
  }
  
  public void setAplctnSuprUserId(String aplctnSuprUserId)
  {
    this.aplctnSuprUserId = aplctnSuprUserId;
  }
  
  @Column(name="PTAN_NUM", precision=10, scale=0)
  public Long getPtanNum()
  {
    return this.ptanNum;
  }
  
  public void setPtanNum(Long ptanNum)
  {
    this.ptanNum = ptanNum;
  }
  
  @Column(name="RFRD_TO_USER_ID", length=20)
  public String getRfrdToUserId()
  {
    return this.rfrdToUserId;
  }
  
  public void setRfrdToUserId(String rfrdToUserId)
  {
    this.rfrdToUserId = rfrdToUserId;
  }
  
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name="CRNT_RULNG_TS")
  public Date getCrntRulngDt()
  {
    return this.crntRulngDt;
  }
  
  public void setCrntRulngDt(Date crntRulngDt)
  {
    this.crntRulngDt = crntRulngDt;
  }
  
  @Column(name="RULNG_CHG_RSN_DESC", length=100)
  public String getRulngChgRsnDesc()
  {
    return this.rulngChgRsnDesc;
  }
  
  public void setRulngChgRsnDesc(String rulngChgRsnDesc)
  {
    this.rulngChgRsnDesc = rulngChgRsnDesc;
  }
  
  @Column(name="SUBJ_CNTRCTR_INCLSN_PRRTY_IND", length=1)
  public String getSubjCntrctrInclsnPrrtyInd()
  {
    return this.subjCntrctrInclsnPrrtyInd;
  }
  
  public void setSubjCntrctrInclsnPrrtyInd(String subjCntrctrInclsnPrrtyInd)
  {
    this.subjCntrctrInclsnPrrtyInd = subjCntrctrInclsnPrrtyInd;
  }
  
  @Column(name="FPS_VRSN_IND", nullable=false, length=1)
  public String getFpsVrsnInd()
  {
    return this.fpsVrsnInd;
  }
  
  public void setFpsVrsnInd(String fpsVrsnInd)
  {
    this.fpsVrsnInd = fpsVrsnInd;
  }
  
  @Column(name="AUDT_INSRT_ID", nullable=false, length=128)
  public String getAudtInsrtId()
  {
    return this.audtInsrtId;
  }
  
  public void setAudtInsrtId(String audtInsrtId)
  {
    this.audtInsrtId = audtInsrtId;
  }
  
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name="AUDT_INSRT_TS", nullable=false, length=26)
  public Date getAudtInsrtTs()
  {
    return this.audtInsrtTs;
  }
  
  public void setAudtInsrtTs(Date audtInsrtTs)
  {
    this.audtInsrtTs = audtInsrtTs;
  }
  
  @Column(name="AUDT_UPDT_ID", length=128)
  public String getAudtUpdtId()
  {
    return this.audtUpdtId;
  }
  
  public void setAudtUpdtId(String audtUpdtId)
  {
    this.audtUpdtId = audtUpdtId;
  }
  
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name="AUDT_UPDT_TS", length=26)
  public Date getAudtUpdtTs()
  {
    return this.audtUpdtTs;
  }
  
  public void setAudtUpdtTs(Date audtUpdtTs)
  {
    this.audtUpdtTs = audtUpdtTs;
  }
  
  @Column(name="REC_CHG_IND", length=1)
  public String getRecChgInd()
  {
    return this.recChgInd;
  }
  
  public void setRecChgInd(String recChgInd)
  {
    this.recChgInd = recChgInd;
  }
  
  @Column(name="CRNT_RULNG_USER_CMT_TXT")
  @Lob
  @Type(type = "org.hibernate.type.TextType")
  public String getCrntRulngUserCmtTxt()
  {
    return this.crntRulngUserCmtTxt;
  }
  
  public void setCrntRulngUserCmtTxt(String crntRulngUserCmtTxt)
  {
    this.crntRulngUserCmtTxt = crntRulngUserCmtTxt;
  }
  
  @Column(name="LGCY_ASRPT_LOID", length=30)
  public String getLgcyAsrptLoid()
  {
    return this.lgcyAsrptLoid;
  }
  
  public void setLgcyAsrptLoid(String lgcyAsrptLoid)
  {
    this.lgcyAsrptLoid = lgcyAsrptLoid;
  }
  
  @ManyToOne(fetch=FetchType.LAZY)
  @JoinColumn(name="RULNG_RSN_CD", updatable=false, insertable=false)
  public FpsRulngRsnRfrnc getFpsRulngRsnRfrnc()
  {
    return this.fpsRulngRsnRfrnc;
  }
  
  public void setFpsRulngRsnRfrnc(FpsRulngRsnRfrnc fpsRulngRsnRfrnc)
  {
    this.fpsRulngRsnRfrnc = fpsRulngRsnRfrnc;
  }
	@Column(name="EXTRNL_CASE_ID")
	public String getExtrnlCaseId() {
		return extrnlCaseId;
	}

	public void setExtrnlCaseId(String extrnlCaseId) {
		this.extrnlCaseId = extrnlCaseId;
	}
	@Column(name="CRNT_RULNG_CD")
	public String getCrntRulngCd() {
		return crntRulngCd;
	}

	public void setCrntRulngCd(String crntRulngCd) {
		this.crntRulngCd = crntRulngCd;
	}
	@Column(name="RULNG_RSN_CD")
	public String getRulngRsnCd() {
		return rulngRsnCd;
	}

	public void setRulngRsnCd(String rulngRsnCd) {
		this.rulngRsnCd = rulngRsnCd;
	}
	@Column(name="UCM_EVNT_ID")
	public String getUcmEvntId() {
		return ucmEvntId;
	}

	public void setUcmEvntId(String ucmEvntId) {
		this.ucmEvntId = ucmEvntId;
	}
}
