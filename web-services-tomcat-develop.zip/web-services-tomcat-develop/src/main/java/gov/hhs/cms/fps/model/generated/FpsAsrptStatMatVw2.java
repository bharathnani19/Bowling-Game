package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import gov.hhs.cms.fps.util.VarcharIntegerType;

@Entity
@Table(name = "FPS_ASRPT_STAT_MAT_VW2")

public class FpsAsrptStatMatVw2 implements Serializable {

	public FpsAsrptStatMatVw2() {
		super();
	}

	public FpsAsrptStatMatVw2(Integer id, Integer asrptId, String type, String value, String desc, FpsAsrpt fpsAsrpt) {
		super();
		this.asrptId = id;
		this.asrptId = asrptId;
		this.type = type;
		this.value = value;
		this.desc = desc;
		this.fpsAsrpt = fpsAsrpt;
	}
	private Integer id;
	private Integer asrptId;
	private String type;
	private String value;
	private String desc;
	private FpsAsrpt fpsAsrpt;
	
	@Column(name = "ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}

	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	
	@Column(name = "TYPE")
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	@Column(name = "VALUE")
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "ASRPT_ID", updatable=false, insertable=false)
//	public FpsAsrpt getFpsAsrpt() {
//		return fpsAsrpt;
//	}
//	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
//		this.fpsAsrpt = fpsAsrpt;
//	}
	@Column(name = "DESC")
	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((asrptId == null) ? 0 : asrptId.hashCode());
		result = prime * result + ((desc == null) ? 0 : desc.hashCode());
		result = prime * result + ((fpsAsrpt == null) ? 0 : fpsAsrpt.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@Id
	@Column(name="ID")
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FpsAsrptStatMatVw2 other = (FpsAsrptStatMatVw2) obj;
		if (asrptId == null) {
			if (other.asrptId != null)
				return false;
		} else if (!asrptId.equals(other.asrptId))
			return false;
		if (desc == null) {
			if (other.desc != null)
				return false;
		} else if (!desc.equals(other.desc))
			return false;
		if (fpsAsrpt == null) {
			if (other.fpsAsrpt != null)
				return false;
		} else if (!fpsAsrpt.equals(other.fpsAsrpt))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}
}
