package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrSummaryRollupCounts implements Serializable {

	private Integer userCnt;
	private Integer activityCnt;
	private Integer assignedZoneCnt;
	private Integer barrierCdCnt;
	private Integer alertCnt;
	private Integer actionCnt;
	private Integer investCnt;
	private Integer specialtyCnt;
	private Integer procedureCnt;
	private Integer claimTypeCnt;
	public Integer getUserCnt() {
		return userCnt;
	}
	public void setUserCnt(Integer userCnt) {
		this.userCnt = userCnt;
	}
	public Integer getActivityCnt() {
		return activityCnt;
	}
	public void setActivityCnt(Integer activityCnt) {
		this.activityCnt = activityCnt;
	}
	public Integer getAssignedZoneCnt() {
		return assignedZoneCnt;
	}
	public void setAssignedZoneCnt(Integer assignedZoneCnt) {
		this.assignedZoneCnt = assignedZoneCnt;
	}
	public Integer getBarrierCdCnt() {
		return barrierCdCnt;
	}
	public void setBarrierCdCnt(Integer barrierCdCnt) {
		this.barrierCdCnt = barrierCdCnt;
	}
	public Integer getAlertCnt() {
		return alertCnt;
	}
	public void setAlertCnt(Integer alertCnt) {
		this.alertCnt = alertCnt;
	}
	public Integer getActionCnt() {
		return actionCnt;
	}
	public void setActionCnt(Integer actionCnt) {
		this.actionCnt = actionCnt;
	}
	public Integer getInvestCnt() {
		return investCnt;
	}
	public void setInvestCnt(Integer investCnt) {
		this.investCnt = investCnt;
	}
	public Integer getSpecialtyCnt() {
		return specialtyCnt;
	}
	public void setSpecialtyCnt(Integer specialtyCnt) {
		this.specialtyCnt = specialtyCnt;
	}
	public Integer getProcedureCnt() {
		return procedureCnt;
	}
	public void setProcedureCnt(Integer procedureCnt) {
		this.procedureCnt = procedureCnt;
	}
	public Integer getClaimTypeCnt() {
		return claimTypeCnt;
	}
	public void setClaimTypeCnt(Integer claimTypeCnt) {
		this.claimTypeCnt = claimTypeCnt;
	}
}
