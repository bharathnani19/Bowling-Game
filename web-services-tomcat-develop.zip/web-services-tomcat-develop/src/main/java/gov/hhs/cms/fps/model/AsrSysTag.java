/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class AsrSummarySysTag.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrSysTag implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2113852056122450965L;
	
	private List<AsrFidNumber> fids = new ArrayList<AsrFidNumber>();
	private List<AsrBiuItem> bius = new ArrayList<AsrBiuItem>();
	private List<UcmCaseData> ucms = new ArrayList<UcmCaseData>();
	private List<AsrSysTagItem> sysTags = new ArrayList<AsrSysTagItem>();
	
	public List<AsrFidNumber> getFids() {
		return fids;
	}
	public void setFids(List<AsrFidNumber> fids) {
		this.fids = fids;
	}
	public List<AsrBiuItem> getBius() {
		return bius;
	}
	public void setBius(List<AsrBiuItem> bius) {
		this.bius = bius;
	}
	public List<UcmCaseData> getUcms() {
		return ucms;
	}
	public void setUcms(List<UcmCaseData> ucms) {
		this.ucms = ucms;
	}
	public void add(Object item){
		if (item instanceof AsrBiuItem){
			bius.add((AsrBiuItem)item);
		}else if (item instanceof AsrFidNumber){
			fids.add((AsrFidNumber)item);
		}else if (item instanceof UcmCaseData){
			ucms.add((UcmCaseData)item);
		}else if (item instanceof AsrSysTagItem){
			sysTags.add((AsrSysTagItem)item);
		}
	}
	public List<AsrSysTagItem> getSysTags() {
		return sysTags;
	}
	public void setSysTags(List<AsrSysTagItem> sysTags) {
		this.sysTags = sysTags;
	}
	
}
