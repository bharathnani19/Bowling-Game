package gov.hhs.cms.fps.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class FpsProviderPerfTop5Proc implements Serializable {

	private String procedureCd;
	private int claimCnt;
	public String getProcedureCd() {
		return procedureCd;
	}
	public void setProcedureCd(String procedureCd) {
		this.procedureCd = procedureCd;
	}
	public int getClaimCnt() {
		return claimCnt;
	}
	public void setClaimCnt(int claimCnt) {
		this.claimCnt = claimCnt;
	}
}
