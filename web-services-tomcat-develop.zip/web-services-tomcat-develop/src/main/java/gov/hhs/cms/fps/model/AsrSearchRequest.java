/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

// TODO: Auto-generated Javadoc
/**
 * The Class AsrSearchRequest.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrSearchRequest extends BaseRequest implements Serializable{


	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5354419867723979741L;

	/** The parameters. */
	private AsrSearchParameter parameters;

	/* (non-Javadoc)
	 * @see gov.hhs.cms.fps.model.BaseRequest#getParameters()
	 */
	public AsrSearchParameter getParameters() {
		return parameters;
	}

	/**
	 * Sets the parameters.
	 *
	 * @param parameters the new parameters
	 */
	public void setParameters(AsrSearchParameter parameters) {
		this.parameters = parameters;
	}
	
	
	
	
}
