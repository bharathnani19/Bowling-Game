/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import gov.hhs.cms.fps.model.generated.FpsRiskScreHstryVw;
import gov.hhs.cms.fps.model.generated.FpsTrnPrbeEdu;
import gov.hhs.cms.fps.model.ucm.ProviderInfo;


// TODO: Auto-generated Javadoc
/**
 * The Class AsrDetail.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetail implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4120570320224550936L;
	
	/** The claim lines. */
	private AsrDetailClaimLine claimLines;
	
	/** The edits. */
	private List<AsrDetailEdit> edits;
	
	/** The foia. */
	private List<AsrDetailFoia> foia;
	
	/** The history. */
	private List<AsrDetailHistory> history;
	
	/** The leads. */
	private List<AsrDetailLead> leads;
	
	/** The leads. */
	private List<AsrDetailLead> ucmInvs;
	
	/** The master alert. */
	private List<AsrDetailMasterAlert> masterAlert;
	private List<AsrDetailMasterAlert> oldAlert;
	
	private List<AsrDetailMasterAlert> currentP1Alert;
	private List<AsrDetailMasterAlert> historyP1Alert;
	
	/** The notes. */
	private List<AsrDetailNote> notes;
	
	/** The provider. */
	private AsrDetailProvider provider;
	
	/** The systag. */
	private AsrSysTag systags;
	
	/** The tota cost zone. */
	private List<AsrDetailTotalCostZone> totalCostZones;
	private List<AsrDetailTotalCostZone> totalPymtZones;
	
	private List<AsrDetailModel> models;
	
	private List<AsrPrioritizeItem> priorities;
	
	private boolean prioritized;
	
	private String partDInd;
	
	private AsrDetailPartD partD;
	
	private List<AsrRiskScoreTrend> trends;
	//SYS-4001
	private String recentAlerts;
	private String recentEdits;
	private String recentInv;
	// SYS-4280
	private List<String> claimTypes;
	// SYS-
	private String hasEdits;
	private String hasInv;
	private String hasLegacyInv;
	private String hasSysTags;
	private String hasNotes;
	private String hasPartD;
	private String hasClaims;
	private Set<FpsTrnPrbeEdu> tpes;
	private List<ApsRecord> aps;
	private Integer relatedAsrCnt;
	private List<RelatedAsr> relatedAsrs;
	private AvailableClaims availableClaims;
	private Integer asrDbId;
	private Integer mdcdAsrDbId;
	private BiuSummary biuSummary;
	private List<RelatedAsr> napParents;
	private List<MdcdTotalPayment> mdcdTotalPayments;
	private List<MdcdModelState> mdcdUserStates;
	private String mdcdPrrtyEnabledInd;
	private List<AsrBillingSummary> billSummary;
	private ProviderInfo providerInfo;
	// phase 1
	private String recentP1Alerts;
	private String hasP1Alerts;
	private String hasAlerts;
	private List<AsrDetailTotalCostZone> p1TotalCostZones;
	private String p1EnabledInd;
	private FpsRiskScreHstryVw fpsRiskScreHstryVw;


	public Integer getAsrDbId() {
		return asrDbId;
	}

	public void setAsrDbId(Integer asrDbId) {
		this.asrDbId = asrDbId;
	}

	/**
	 * Gets the edits.
	 *
	 * @return the edits
	 */
	public List<AsrDetailEdit> getEdits() {
		return edits;
	}
	
	/**
	 * Sets the edits.
	 *
	 * @param edits the new edits
	 */
	public void setEdits(List<AsrDetailEdit> edits) {
		this.edits = edits;
	}
	
	/**
	 * Gets the foia.
	 *
	 * @return the foia
	 */
	public List<AsrDetailFoia> getFoia() {
		return foia;
	}
	
	/**
	 * Sets the foia.
	 *
	 * @param foia the new foia
	 */
	public void setFoia(List<AsrDetailFoia> foia) {
		this.foia = foia;
	}
	
	/**
	 * Gets the history.
	 *
	 * @return the history
	 */
	public List<AsrDetailHistory> getHistory() {
		return history;
	}
	
	/**
	 * Sets the history.
	 *
	 * @param history the new history
	 */
	public void setHistory(List<AsrDetailHistory> history) {
		this.history = history;
	}
	
	/**
	 * Gets the leads.
	 *
	 * @return the leads
	 */
	public List<AsrDetailLead> getLeads() {
		return leads;
	}
	
	/**
	 * Sets the leads.
	 *
	 * @param leads the new leads
	 */
	public void setLeads(List<AsrDetailLead> leads) {
		this.leads = leads;
	}
	
	/**
	 * Gets the master alert.
	 *
	 * @return the master alert
	 */
	public List<AsrDetailMasterAlert> getMasterAlert() {
		return masterAlert;
	}
	
	/**
	 * Sets the master alert.
	 *
	 * @param masterAlert the new master alert
	 */
	public void setMasterAlert(List<AsrDetailMasterAlert> masterAlert) {
		this.masterAlert = masterAlert;
	}
	
	/**
	 * Gets the notes.
	 *
	 * @return the notes
	 */
	public List<AsrDetailNote> getNotes() {
		return notes;
	}
	
	/**
	 * Sets the notes.
	 *
	 * @param notes the new notes
	 */
	public void setNotes(List<AsrDetailNote> notes) {
		this.notes = notes;
	}
	
	/**
	 * Gets the provider.
	 *
	 * @return the provider
	 */
	public AsrDetailProvider getProvider() {
		return provider;
	}
	
	/**
	 * Sets the provider.
	 *
	 * @param provider the new provider
	 */
	public void setProvider(AsrDetailProvider provider) {
		this.provider = provider;
	}


	/**
	 * Gets the risk score history.
	 *
	 * @return the risk score history
	 */
	public FpsRiskScreHstryVw getFpsRiskScreHstryVw() {
		return fpsRiskScreHstryVw;
	}
	

	
	/**
	 * Gets the tota cost zone.
	 *
	 * @return the tota cost zone
	 */
	public List<AsrDetailTotalCostZone> getTotalCostZones() {
		return totalCostZones;
	}
	
	/**
	 * Sets the tota cost zone.
	 *
	 * @param totalCostZone the new tota cost zone
	 */
	public void setTotalCostZones(List<AsrDetailTotalCostZone> totalCostZones) {
		this.totalCostZones = totalCostZones;
	}

	public AsrDetailClaimLine getClaimLines() {
		return claimLines;
	}

	public void setClaimLines(AsrDetailClaimLine claimLines) {
		this.claimLines = claimLines;
	}

	public AsrSysTag getSystags() {
		return systags;
	}

	public void setSystags(AsrSysTag systags) {
		this.systags = systags;
	}

	public List<AsrDetailModel> getModels() {
		return models;
	}

	public void setModels(List<AsrDetailModel> models) {
		this.models = models;
	}

	public List<AsrPrioritizeItem> getPriorities() {
		return priorities;
	}

	public void setPriorities(List<AsrPrioritizeItem> priorities) {
		this.priorities = priorities;
	}

	public List<AsrDetailLead> getUcmInvs() {
		return ucmInvs;
	}

	public void setUcmInvs(List<AsrDetailLead> ucmInvs) {
		this.ucmInvs = ucmInvs;
	}

	public boolean isPrioritized() {
		return prioritized;
	}

	public void setPrioritized(boolean prioritized) {
		this.prioritized = prioritized;
	}

	public String getPartDInd() {
		return partDInd;
	}

	public void setPartDInd(String partDInd) {
		this.partDInd = partDInd;
	}

	public AsrDetailPartD getPartD() {
		return partD;
	}

	public void setPartD(AsrDetailPartD partD) {
		this.partD = partD;
	}

	public List<AsrRiskScoreTrend> getTrends() {
		return trends;
	}

	public void setTrends(List<AsrRiskScoreTrend> trends) {
		this.trends = trends;
	}

	public String getRecentAlerts() {
		return recentAlerts;
	}

	public void setRecentAlerts(String recentAlerts) {
		this.recentAlerts = recentAlerts;
	}

	public String getRecentEdits() {
		return recentEdits;
	}

	public void setRecentEdits(String recentEdits) {
		this.recentEdits = recentEdits;
	}

	public String getRecentInv() {
		return recentInv;
	}

	public void setRecentInv(String recentInv) {
		this.recentInv = recentInv;
	}

	public List<String> getClaimTypes() {
		return claimTypes;
	}

	public void setClaimTypes(List<String> claimTypes) {
		this.claimTypes = claimTypes;
	}

	public String getHasEdits() {
		return hasEdits;
	}

	public void setHasEdits(String hasEdits) {
		this.hasEdits = hasEdits;
	}

	public String getHasInv() {
		return hasInv;
	}

	public void setHasInv(String hasInv) {
		this.hasInv = hasInv;
	}

	public String getHasSysTags() {
		return hasSysTags;
	}

	public void setHasSysTags(String hasSysTags) {
		this.hasSysTags = hasSysTags;
	}

	public String getHasNotes() {
		return hasNotes;
	}

	public void setHasNotes(String hasNotes) {
		this.hasNotes = hasNotes;
	}

	public String getHasPartD() {
		return hasPartD;
	}

	public void setHasPartD(String hasPartD) {
		this.hasPartD = hasPartD;
	}
	public void initIndicators(){
		recentAlerts ="N";
		recentEdits ="N";
		recentInv ="N";
		hasEdits ="N";
		hasInv ="N";
		hasSysTags ="N";
		hasNotes ="N";
		hasPartD ="N";
		hasLegacyInv ="N";
		recentP1Alerts ="N";
		hasP1Alerts ="N";
		hasAlerts ="N";
	}

	public List<AsrDetailMasterAlert> getOldAlert() {
		return oldAlert;
	}

	public void setOldAlert(List<AsrDetailMasterAlert> oldAlert) {
		this.oldAlert = oldAlert;
	}

	public String getHasLegacyInv() {
		return hasLegacyInv;
	}

	public void setHasLegacyInv(String hasLegacyInv) {
		this.hasLegacyInv = hasLegacyInv;
	}

	public Set<FpsTrnPrbeEdu> getTpes() {
		return tpes;
	}

	public void setTpes(Set<FpsTrnPrbeEdu> tpes) {
		this.tpes = tpes;
	}

	public List<ApsRecord> getAps() {
		return aps;
	}

	public void setAps(List<ApsRecord> aps) {
		this.aps = aps;
	}

	public List<AsrDetailTotalCostZone> getTotalPymtZones() {
		return totalPymtZones;
	}

	public void setTotalPymtZones(List<AsrDetailTotalCostZone> totalPymtZones) {
		this.totalPymtZones = totalPymtZones;
	}

	public Integer getRelatedAsrCnt() {
		return relatedAsrCnt;
	}

	public void setRelatedAsrCnt(Integer relatedAsrCnt) {
		this.relatedAsrCnt = relatedAsrCnt;
	}

	public List<RelatedAsr> getRelatedAsrs() {
		return relatedAsrs;
	}

	public void setRelatedAsrs(List<RelatedAsr> relatedAsrs) {
		this.relatedAsrs = relatedAsrs;
	}

	public AvailableClaims getAvailableClaims() {
		return availableClaims;
	}

	public void setAvailableClaims(AvailableClaims availableClaims) {
		this.availableClaims = availableClaims;
	}

	public BiuSummary getBiuSummary() {
		return biuSummary;
	}

	public void setBiuSummary(BiuSummary biuSummary) {
		this.biuSummary = biuSummary;
	}

	public List<RelatedAsr> getNapParents() {
		return napParents;
	}

	public void setNapParents(List<RelatedAsr> napParents) {
		this.napParents = napParents;
	}

	public List<MdcdTotalPayment> getMdcdTotalPayments() {
		return mdcdTotalPayments;
	}

	public void setMdcdTotalPayments(List<MdcdTotalPayment> mdcdTotalPayments) {
		this.mdcdTotalPayments = mdcdTotalPayments;
	}

	public Integer getMdcdAsrDbId() {
		return mdcdAsrDbId;
	}

	public void setMdcdAsrDbId(Integer mdcdAsrDbId) {
		this.mdcdAsrDbId = mdcdAsrDbId;
	}

	public List<MdcdModelState> getMdcdUserStates() {
		return mdcdUserStates;
	}

	public void setMdcdUserStates(List<MdcdModelState> mdcdUserStates) {
		this.mdcdUserStates = mdcdUserStates;
	}

	public String getMdcdPrrtyEnabledInd() {
		return mdcdPrrtyEnabledInd;
	}

	public void setMdcdPrrtyEnabledInd(String mdcdPrrtyEnabledInd) {
		this.mdcdPrrtyEnabledInd = mdcdPrrtyEnabledInd;
	}

	public List<AsrBillingSummary> getBillSummary() {
		return billSummary;
	}

	public void setBillSummary(List<AsrBillingSummary> billSummary) {
		this.billSummary = billSummary;
	}

	public List<AsrDetailMasterAlert> getCurrentP1Alert() {
		return currentP1Alert;
	}

	public void setCurrentP1Alert(List<AsrDetailMasterAlert> currentP1Alert) {
		this.currentP1Alert = currentP1Alert;
	}

	public List<AsrDetailMasterAlert> getHistoryP1Alert() {
		return historyP1Alert;
	}

	public void setHistoryP1Alert(List<AsrDetailMasterAlert> historyP1Alert) {
		this.historyP1Alert = historyP1Alert;
	}

	public String getRecentP1Alerts() {
		return recentP1Alerts;
	}

	public void setRecentP1Alerts(String recentP1Alerts) {
		this.recentP1Alerts = recentP1Alerts;
	}

	public List<AsrDetailTotalCostZone> getP1TotalCostZones() {
		return p1TotalCostZones;
	}

	public void setP1TotalCostZones(List<AsrDetailTotalCostZone> p1TotalCostZones) {
		this.p1TotalCostZones = p1TotalCostZones;
	}

	public String getP1EnabledInd() {
		return p1EnabledInd;
	}

	public void setP1EnabledInd(String p1EnabledInd) {
		this.p1EnabledInd = p1EnabledInd;
	}

	public String getHasP1Alerts() {
		return hasP1Alerts;
	}

	public void setHasP1Alerts(String hasP1Alerts) {
		this.hasP1Alerts = hasP1Alerts;
	}

	public String getHasAlerts() {
		return hasAlerts;
	}

	public void setHasAlerts(String hasAlerts) {
		this.hasAlerts = hasAlerts;
	}

	public String getHasClaims() {
		return hasClaims;
	}

	public void setHasClaims(String hasClaims) {
		this.hasClaims = hasClaims;
	}
	
}
