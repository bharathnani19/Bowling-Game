package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
@Entity
@Table(name="FPS_ASRPT_USER_ADMINV_ACTN_RFI_DTL")
public class FpsAsrptUserAdminvActnRfiDtl implements Serializable {

	private Integer asrptUserAdminvActnRfiDtlId;
	private String recordId;
	private String leCaseNumber;
	private String recordStatus;
	private String migrationStatus;
	private String rfiSubStatus;
	private String decision;
	private String rfiCaseTitle;
	private String cmsWatchListDescription;
	private String upicWatchListDescription;
	private String cmsWatchListInd;
	private String upicWatchListInd;
	private String primarySubject;
	private String primaryNpi;
	private String closingRationale;
	private String ownershipOrganization;
	private String programType;
	private String typeOfWork;
	private String rfiRequesterType;
	private String taskOrder;
	private String rfiPriority;
	private String heatInvolvementInd;
	private String agency;
	private String cntrctrCds;
	private String foiaIndicator;
	private String upicJurisdiction;
	private String partAOther;
	private String homeHealth;
	private String hospice;
	private String billType;
	private String partBOther;
	private String dme;
	private String cpt;
	private String hcpcs;
	private String partC;
	private String partD;
	private Date dateSentToCMS;
	private Date dateOfDecision;
	private Date cmsWatchListDueDate;
	private Date upicWatchListDueDate;
	private Date rfiCreateDate;
	private Date rfiReceivedDate;
	private Date rfiCloseDate;
	private Date dateOfServiceFrom;
	private Date dateOfServiceTo;
	private Integer rfiAge;
	private Integer daysInStatus;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private String audtUpdtId;
	private Date audtUpdtTs;
	private String recChgInd;
	private Set<FpsAsrptUserAdminvActnRfiExtrnlPrtnr> fpsAsrptUserAdminvActnRfiExtrnlPrtnrs;
	private Set<FpsAsrptUserAdminvActnRfiSubj> fpsAsrptUserAdminvActnRfiSubjs;
	private FpsAsrptUserAdminvActn fpsAsrptUserAdminvActn;
	
	@Id
	@SequenceGenerator(name="asrpt_user_adminv_actn_rfi_dtl_id_seq",  sequenceName = "asrpt_user_adminv_actn_rfi_dtl_id_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "asrpt_user_adminv_actn_rfi_dtl_id_seq")
	@Column(name="ASRPT_USER_ADMINV_ACTN_RFI_DTL_ID")
	public Integer getAsrptUserAdminvActnRfiDtlId() {
		return asrptUserAdminvActnRfiDtlId;
	}
	public void setAsrptUserAdminvActnRfiDtlId(Integer asrptUserAdminvActnRfiDtlId) {
		this.asrptUserAdminvActnRfiDtlId = asrptUserAdminvActnRfiDtlId;
	}
	@Column(name="RCRD_ID")
	public String getRecordId() {
		return recordId;
	}
	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}
	@Column(name="LE_CASE_NUM")
	public String getLeCaseNumber() {
		return leCaseNumber;
	}
	public void setLeCaseNumber(String leCaseNumber) {
		this.leCaseNumber = leCaseNumber;
	}
	@Column(name="RCRD_STUS")
	public String getRecordStatus() {
		return recordStatus;
	}
	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}
	@Column(name="MGRTN_STUS")
	public String getMigrationStatus() {
		return migrationStatus;
	}
	public void setMigrationStatus(String migrationStatus) {
		this.migrationStatus = migrationStatus;
	}
	@Column(name="RFI_SUB_STUS")
	public String getRfiSubStatus() {
		return rfiSubStatus;
	}
	public void setRfiSubStatus(String rfiSubStatus) {
		this.rfiSubStatus = rfiSubStatus;
	}
	@Column(name="DCSN")
	public String getDecision() {
		return decision;
	}
	public void setDecision(String decision) {
		this.decision = decision;
	}
	@Column(name="RFI_CASE_TITLE")
	public String getRfiCaseTitle() {
		return rfiCaseTitle;
	}
	public void setRfiCaseTitle(String rfiCaseTitle) {
		this.rfiCaseTitle = rfiCaseTitle;
	}
	@Column(name="CMS_WATCH_LST_DESC")
	public String getCmsWatchListDescription() {
		return cmsWatchListDescription;
	}
	public void setCmsWatchListDescription(String cmsWatchListDescription) {
		this.cmsWatchListDescription = cmsWatchListDescription;
	}
	@Column(name="UPIC_WATCH_LIST_DESC")
	public String getUpicWatchListDescription() {
		return upicWatchListDescription;
	}
	public void setUpicWatchListDescription(String upicWatchListDescription) {
		this.upicWatchListDescription = upicWatchListDescription;
	}
	@Column(name="PRMRY_SUBJ")
	public String getPrimarySubject() {
		return primarySubject;
	}
	public void setPrimarySubject(String primarySubject) {
		this.primarySubject = primarySubject;
	}
	@Column(name="PRMRY_NPI")
	public String getPrimaryNpi() {
		return primaryNpi;
	}
	public void setPrimaryNpi(String primaryNpi) {
		this.primaryNpi = primaryNpi;
	}
	@Column(name="CLSNG_RTNL")
	public String getClosingRationale() {
		return closingRationale;
	}
	public void setClosingRationale(String closingRationale) {
		this.closingRationale = closingRationale;
	}
	@Column(name="OWNRSHP_ORG")
	public String getOwnershipOrganization() {
		return ownershipOrganization;
	}
	public void setOwnershipOrganization(String ownershipOrganization) {
		this.ownershipOrganization = ownershipOrganization;
	}
	@Column(name="PGM_TYPE")
	public String getProgramType() {
		return programType;
	}
	public void setProgramType(String programType) {
		this.programType = programType;
	}
	@Column(name="TYPE_OF_WORK")
	public String getTypeOfWork() {
		return typeOfWork;
	}
	public void setTypeOfWork(String typeOfWork) {
		this.typeOfWork = typeOfWork;
	}
	@Column(name="RFI_RQSTR_TYPE")
	public String getRfiRequesterType() {
		return rfiRequesterType;
	}
	public void setRfiRequesterType(String rfiRequesterType) {
		this.rfiRequesterType = rfiRequesterType;
	}
	@Column(name="TSK_ORDR")
	public String getTaskOrder() {
		return taskOrder;
	}
	public void setTaskOrder(String taskOrder) {
		this.taskOrder = taskOrder;
	}
	@Column(name="RFI_PRRTY")
	public String getRfiPriority() {
		return rfiPriority;
	}
	public void setRfiPriority(String rfiPriority) {
		this.rfiPriority = rfiPriority;
	}
	@Column(name="HEAT_INVLVMT_IND")
	public String getHeatInvolvementInd() {
		return heatInvolvementInd;
	}
	public void setHeatInvolvementInd(String heatInvolvementInd) {
		this.heatInvolvementInd = heatInvolvementInd;
	}
	@Column(name="AGNCY")
	public String getAgency() {
		return agency;
	}
	public void setAgency(String agency) {
		this.agency = agency;
	}
	@Column(name="CNTRCTR_CDS")
	public String getCntrctrCds() {
		return cntrctrCds;
	}
	public void setCntrctrCds(String cntrctrCds) {
		this.cntrctrCds = cntrctrCds;
	}
	@Column(name="FOIA_IND")
	public String getFoiaIndicator() {
		return foiaIndicator;
	}
	public void setFoiaIndicator(String foiaIndicator) {
		this.foiaIndicator = foiaIndicator;
	}
	@Column(name="UPIC_JRSDCTN")
	public String getUpicJurisdiction() {
		return upicJurisdiction;
	}
	public void setUpicJurisdiction(String upicJurisdiction) {
		this.upicJurisdiction = upicJurisdiction;
	}
	@Column(name="PTA_OTHR_IND")
	public String getPartAOther() {
		return partAOther;
	}
	public void setPartAOther(String partAOther) {
		this.partAOther = partAOther;
	}
	@Column(name="HH_IND")
	public String getHomeHealth() {
		return homeHealth;
	}
	public void setHomeHealth(String homeHealth) {
		this.homeHealth = homeHealth;
	}
	@Column(name="HSPC_IND")
	public String getHospice() {
		return hospice;
	}
	public void setHospice(String hospice) {
		this.hospice = hospice;
	}
	@Column(name="BILL_TYPE")
	public String getBillType() {
		return billType;
	}
	public void setBillType(String billType) {
		this.billType = billType;
	}
	@Column(name="PTB_OTHR_IND")
	public String getPartBOther() {
		return partBOther;
	}
	public void setPartBOther(String partBOther) {
		this.partBOther = partBOther;
	}
	@Column(name="DME_IND")
	public String getDme() {
		return dme;
	}
	public void setDme(String dme) {
		this.dme = dme;
	}
	@Column(name="CPT_CD")
	public String getCpt() {
		return cpt;
	}
	public void setCpt(String cpt) {
		this.cpt = cpt;
	}
	@Column(name="HCPCS_CD")
	public String getHcpcs() {
		return hcpcs;
	}
	public void setHcpcs(String hcpcs) {
		this.hcpcs = hcpcs;
	}
	@Column(name="PTC_IND")
	public String getPartC() {
		return partC;
	}
	public void setPartC(String partC) {
		this.partC = partC;
	}
	@Column(name="PTD_IND")
	public String getPartD() {
		return partD;
	}
	public void setPartD(String partD) {
		this.partD = partD;
	}
	@Temporal(TemporalType.DATE)
	@Column(name="DATE_SENT_TO_CMS")
	public Date getDateSentToCMS() {
		return dateSentToCMS;
	}
	public void setDateSentToCMS(Date dateSentToCMS) {
		this.dateSentToCMS = dateSentToCMS;
	}
	@Temporal(TemporalType.DATE)
	@Column(name="DATE_OF_DSCN")
	public Date getDateOfDecision() {
		return dateOfDecision;
	}
	public void setDateOfDecision(Date dateOfDecision) {
		this.dateOfDecision = dateOfDecision;
	}
	@Temporal(TemporalType.DATE)
	@Column(name="CMS_WATCH_LST_DUE_DT")
	public Date getCmsWatchListDueDate() {
		return cmsWatchListDueDate;
	}
	public void setCmsWatchListDueDate(Date cmsWatchListDueDate) {
		this.cmsWatchListDueDate = cmsWatchListDueDate;
	}
	@Temporal(TemporalType.DATE)
	@Column(name="UPIC_WATCH_LIST_DUE_DATE")
	public Date getUpicWatchListDueDate() {
		return upicWatchListDueDate;
	}
	public void setUpicWatchListDueDate(Date upicWatchListDueDate) {
		this.upicWatchListDueDate = upicWatchListDueDate;
	}
	@Temporal(TemporalType.DATE)
	@Column(name="RFI_CREAT_DT")
	public Date getRfiCreateDate() {
		return rfiCreateDate;
	}
	public void setRfiCreateDate(Date rfiCreateDate) {
		this.rfiCreateDate = rfiCreateDate;
	}
	@Temporal(TemporalType.DATE)
	@Column(name="RFI_RCVD_DT")
	public Date getRfiReceivedDate() {
		return rfiReceivedDate;
	}
	public void setRfiReceivedDate(Date rfiReceivedDate) {
		this.rfiReceivedDate = rfiReceivedDate;
	}
	@Temporal(TemporalType.DATE)
	@Column(name="RFI_CLOSE_DT")
	public Date getRfiCloseDate() {
		return rfiCloseDate;
	}
	public void setRfiCloseDate(Date rfiCloseDate) {
		this.rfiCloseDate = rfiCloseDate;
	}
	@Temporal(TemporalType.DATE)
	@Column(name="DATE_OF_SVC_FRM")
	public Date getDateOfServiceFrom() {
		return dateOfServiceFrom;
	}
	public void setDateOfServiceFrom(Date dateOfServiceFrom) {
		this.dateOfServiceFrom = dateOfServiceFrom;
	}
	@Temporal(TemporalType.DATE)
	@Column(name="DATE_OF_SVC_TO")
	public Date getDateOfServiceTo() {
		return dateOfServiceTo;
	}
	public void setDateOfServiceTo(Date dateOfServiceTo) {
		this.dateOfServiceTo = dateOfServiceTo;
	}
	@Column(name="RFI_AGE")
	public Integer getRfiAge() {
		return rfiAge;
	}
	public void setRfiAge(Integer rfiAge) {
		this.rfiAge = rfiAge;
	}
	@Column(name="DAYS_IN_STUS")
	public Integer getDaysInStatus() {
		return daysInStatus;
	}
	
	public void setDaysInStatus(Integer daysInStatus) {
		this.daysInStatus = daysInStatus;
	}
	@Fetch(FetchMode.SELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "fpsAsrptUserAdminvActnRfiDtl", cascade = CascadeType.ALL)
	@BatchSize(size=1000)
	@NotFound(action = NotFoundAction.IGNORE)
	public Set<FpsAsrptUserAdminvActnRfiExtrnlPrtnr> getFpsAsrptUserAdminvActnRfiExtrnlPrtnrs() {
		return fpsAsrptUserAdminvActnRfiExtrnlPrtnrs;
	}
	public void setFpsAsrptUserAdminvActnRfiExtrnlPrtnrs(
			Set<FpsAsrptUserAdminvActnRfiExtrnlPrtnr> fpsAsrptUserAdminvActnRfiExtrnlPrtnrs) {
		this.fpsAsrptUserAdminvActnRfiExtrnlPrtnrs = fpsAsrptUserAdminvActnRfiExtrnlPrtnrs;
	}
	@Fetch(FetchMode.SELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "fpsAsrptUserAdminvActnRfiDtl", cascade = CascadeType.ALL)
	@BatchSize(size=1000)
	@NotFound(action = NotFoundAction.IGNORE)
	public Set<FpsAsrptUserAdminvActnRfiSubj> getFpsAsrptUserAdminvActnRfiSubjs() {
		return fpsAsrptUserAdminvActnRfiSubjs;
	}
	public void setFpsAsrptUserAdminvActnRfiSubjs(Set<FpsAsrptUserAdminvActnRfiSubj> fpsAsrptUserAdminvActnRfiSubjs) {
		this.fpsAsrptUserAdminvActnRfiSubjs = fpsAsrptUserAdminvActnRfiSubjs;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_USER_ADMINV_ACTN_ID")
	public FpsAsrptUserAdminvActn getFpsAsrptUserAdminvActn() {
		return fpsAsrptUserAdminvActn;
	}
	public void setFpsAsrptUserAdminvActn(FpsAsrptUserAdminvActn fpsAsrptUserAdminvActn) {
		this.fpsAsrptUserAdminvActn = fpsAsrptUserAdminvActn;
	}
	@Column(name="AUDT_INSRT_ID")
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="AUDT_INSRT_TS")
	public Date getAudtInsrtTs() {
		return audtInsrtTs;
	}
	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	@Column(name="AUDT_UPDT_ID")
	public String getAudtUpdtId() {
		return audtUpdtId;
	}
	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="AUDT_UPDT_TS")
	public Date getAudtUpdtTs() {
		return audtUpdtTs;
	}
	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
	@Column(name="REC_CHG_IND")
	public String getRecChgInd() {
		return recChgInd;
	}
	public void setRecChgInd(String recChgInd) {
		this.recChgInd = recChgInd;
	}
	@Column(name="CMS_WATCH_LST_IND")
	public String getCmsWatchListInd() {
		return cmsWatchListInd;
	}
	public void setCmsWatchListInd(String cmsWatchListInd) {
		this.cmsWatchListInd = cmsWatchListInd;
	}
	@Column(name="UPIC_WATCH_LST_IND")
	public String getUpicWatchListInd() {
		return upicWatchListInd;
	}
	public void setUpicWatchListInd(String upicWatchListInd) {
		this.upicWatchListInd = upicWatchListInd;
	}

}
