package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.StringEscapeUtils;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.hhs.cms.fps.util.CurrencySerializer;
import gov.hhs.cms.fps.util.FpsDomainObjectConverter;
import gov.hhs.cms.fps.util.NAStringSerializer;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)

public class FpsVisualizationNode implements Serializable {

	//@Field(value="npi")
	private String npi;
	@JsonIgnore
	//@Field(value="spark_id")
	private String npi2;
	//@Field(value="id")
	private String id;
//	//@Field(value="label")
	private String label;
	//@Field(value="label")
	@JsonIgnore
	private String label2;
	private String title;
	//@Field(value="color")
	@JsonIgnore
	private String color2;
	private FpsVisualizationNodeColor color;
	//@Field(value="alert_cst_amt")
	private Double alertCstAmt;
	//@Field(value="model_busns_id")
	private String modelBusnsId;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy/MM/dd", timezone="America/New_York")
	//@Field(value="model_run_dt")
	private Date modelRunDt;
	//@Field(value="prvdr_lgl_name")
	private String prvdrNm;
	//@Field(value="prvdr_1st_name")
	private String prvdr1stNm;
	//@Field(value="prvdr_last_name")
	private String prvdrLastNm;
	//@Field(value="prvdr_prctc_line_1_adr")
	private String prvdrAddr1;
	//@Field(value="prvdr_prctc_line_2_adr")
	private String prvdrAddr2;
	//@Field(value="prvdr_prctc_plc_name")
	private String prvdrCity;
	//@Field(value="prvdr_prctc_state_name")
	private String prvdrState;
	//@Field(value="prvdr_prctc_zip_cd")
	private String prvdrZip;
	//@Field(value="subj_prvdr_role")

	private String subjPrvdrRole;
	private AsrSummary asr;
	// border width set to 3 when 'alerts' is not null
	private String borderWidth = "1";
	// for providers
	//@Field(value="claim_type_txt")
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String claimType;
	//@Field(value="total_pmt")
	@JsonSerialize(using = CurrencySerializer.class,nullsUsing = NAStringSerializer.class)
	private Double totalPymt;
	private String newAlerts;
	private String agedAlerts;
	//@Field(value="alert_status")
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String alertStatus;
	//@Field(value="lead_status")
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String investigations = "None";
	//@Field(value="latest_alert_dt")
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy/MM/dd", timezone="America/New_York")

	private Date lastAlertDt;
	@JsonIgnore
	//@Field(value="asrpt_risk_scre_num")

	private Double riskScore;
	@JsonIgnore
	//@Field(value="priority_scr")
	private Double priorityScore;
	@JsonIgnore
	//@Field(value="mac_jurisdiction")
	private String mac;
	@JsonIgnore
	//@Field(value="upic_jurisdiction")
	private String upic;
	@JsonIgnore
	//@Field(value="prvdr_mdcr_id")
	private String ptan;
	
	private String zr = "No" ;
	private String leadInd = "N";
	

	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLabel() {
		String labelName = "bene".equals(subjPrvdrRole) ? prvdr1stNm + " " + prvdrLastNm : prvdrNm;
		return StringEscapeUtils.escapeJavaScript((getNpi() != null ? getNpi() : "") + "-"+(labelName != null ? labelName : ""));
	}
	public void setLabel(String label) {
		this.label = label;
	}


	public String getTitle() {
		// upic only populated for HHA/DME
		if (getModelBusnsId() == null) {
			String title = "Provider NPI: " + getNpi() + "<br/>Provider Name: " + (prvdrNm != null ? prvdrNm : prvdr1stNm + " " + prvdrLastNm);// + "<br/>Provider Claim Type: " + (claimType != null ? claimType : "N/A");
			return title;
		}else {
		
		String role = "bene".equals(subjPrvdrRole) ? "HICN" : "NPI";
		String roleVal =  getNpi();
		String labelName = "bene".equals(subjPrvdrRole) ? prvdr1stNm + " " + prvdrLastNm : prvdrNm;

		String title = "Name: "  + StringEscapeUtils.escapeJavaScript((labelName != null ? labelName : "")) + "<br/>"+role+":"+(roleVal != null ? roleVal : "")+"<br/>"
				+(alertCstAmt!= null? "Alert Cost:" + FpsDomainObjectConverter.convertDecimalToDollar(alertCstAmt)+"<br/>":"")+"State: " +(prvdrState != null ? prvdrState : "");
		return title;
		}
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Double getAlertCstAmt() {
		return alertCstAmt;
	}
	public void setAlertCstAmt(Double alertCstAmt) {
		this.alertCstAmt = alertCstAmt;
	}
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	public Date getModelRunDt() {
		return modelRunDt;
	}
	public void setModelRunDt(Date modelRunDt) {
		this.modelRunDt = modelRunDt;
	}
	public String getNpi() {
		if (npi2!= null) {
			return npi2;
		}
		return npi;
	}
	public void setNpi(String npi) {
		this.npi = npi;
	}
	public String getPrvdrNm() {
		String actualPrvdrNm = "bene".equals(subjPrvdrRole) ? prvdr1stNm + " " + prvdrLastNm : prvdrNm;
		setPrvdrNm(actualPrvdrNm);
		return this.prvdrNm;
	}
	public void setPrvdrNm(String prvdrNm) {
		this.prvdrNm = prvdrNm;
	}
	public String getPrvdrAddr1() {
		return prvdrAddr1;
	}
	public void setPrvdrAddr1(String prvdrAddr1) {
		this.prvdrAddr1 = prvdrAddr1;
	}
	public String getPrvdrAddr2() {
		return prvdrAddr2;
	}
	public void setPrvdrAddr2(String prvdrAddr2) {
		this.prvdrAddr2 = prvdrAddr2;
	}
	public String getPrvdrCity() {
		return prvdrCity;
	}
	public void setPrvdrCity(String prvdrCity) {
		this.prvdrCity = prvdrCity;
	}
	public String getPrvdrState() {
		return prvdrState;
	}
	public void setPrvdrState(String prvdrState) {
		this.prvdrState = prvdrState;
	}
	public String getPrvdrZip() {
		return prvdrZip;
	}
	public void setPrvdrZip(String prvdrZip) {
		this.prvdrZip = prvdrZip;
	}

	public AsrSummary getAsr() {
		return asr;
	}
	public void setAsr(AsrSummary asr) {
		this.asr = asr;
	}
	public String getSubjPrvdrRole() {
		return subjPrvdrRole;
	}
	public void setSubjPrvdrRole(String subjPrvdrRole) {
		this.subjPrvdrRole = subjPrvdrRole;
	}
	public String getPrvdr1stNm() {
		return prvdr1stNm;
	}
	public void setPrvdr1stNm(String prvdr1stNm) {
		this.prvdr1stNm = prvdr1stNm;
	}
	public String getPrvdrLastNm() {
		return prvdrLastNm;
	}
	public void setPrvdrLastNm(String prvdrLastNm) {
		this.prvdrLastNm = prvdrLastNm;
	}
	public String getNpi2() {
		return npi2;
	}
	public void setNpi2(String npi2) {
		this.npi2 = npi2;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FpsVisualizationNode other = (FpsVisualizationNode) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	public String getBorderWidth() {
		return alertStatus != null ? "3" : "1";
	}
	public void setBorderWidth(String borderWidth) {
		this.borderWidth = borderWidth;
	}
	
	public String getClaimType() {
		return claimType;
	}
	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}
	public Double getTotalPymt() {
		return totalPymt;
	}
	public void setTotalPymt(Double totalPymt) {
		this.totalPymt = totalPymt;
	}
	public String getNewAlerts() {
		return newAlerts;
	}
	public void setNewAlerts(String newAlerts) {
		this.newAlerts = newAlerts;
	}
	public String getAgedAlerts() {
		return agedAlerts;
	}
	public void setAgedAlerts(String agedAlerts) {
		this.agedAlerts = agedAlerts;
	}
	public String getAlertStatus() {
		return alertStatus;
	}
	public void setAlertStatus(String alertStatus) {
		this.alertStatus = alertStatus;
	}
	public String getInvestigations() {
		if ("INVESTIGATION".equals(investigations) || "LEAD".equals(investigations)) {
			return "Open UCM Case";
		}
		if ("CLOSE".equals(investigations)) {
			return "Closed UCM Case";
		}
		if (investigations == null) {
			return "No UCM Case";
		}
		return investigations;
	}
	public void setInvestigations(String investigations) {
		this.investigations = investigations;
	}
	public Date getLastAlertDt() {
		return lastAlertDt;
	}
	public void setLastAlertDt(Date lastAlertDt) {
		this.lastAlertDt = lastAlertDt;
	}
	public String getZr() {
		return zr;
	}
	public void setZr(String zr) {
		this.zr = zr;
	}

	public String getColor2() {
		return color2;
	}
	public void setColor2(String color2) {
		this.color2 = color2;
	}
	public void setColor(FpsVisualizationNodeColor color) {
		this.color = color;
	}
	public FpsVisualizationNodeColor getColor() {
		if (color == null) {
			color = new FpsVisualizationNodeColor(alertStatus != null ? "2" : "1", color2);
		}
		return color;
	}
	public Double getRiskScore() {
		return riskScore;
	}
	public void setRiskScore(Double riskScore) {
		this.riskScore = riskScore;
	}
	public Double getPriorityScore() {
		return priorityScore;
	}
	public void setPriorityScore(Double priorityScore) {
		this.priorityScore = priorityScore;
	}
	public String getMac() {
		return mac;
	}
	public void setMac(String mac) {
		this.mac = mac;
	}
	public String getUpic() {
		return upic;
	}
	public void setUpic(String upic) {
		this.upic = upic;
	}
	public String getPtan() {
		return ptan;
	}
	public void setPtan(String ptan) {
		this.ptan = ptan;
	}
	public String getLeadInd() {
		return leadInd;
	}
	public void setLeadInd(String leadInd) {
		this.leadInd = leadInd;
	}
	public String getLabel2() {
		return label2;
	}
	public void setLabel2(String label2) {
		this.label2 = label2;
	}

}
