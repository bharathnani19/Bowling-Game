package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import gov.hhs.cms.fps.model.um.UserManagementRequest;
@JsonInclude(Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
public class FpsEmail  implements Serializable {
	private String from;
	private List<String> to = new ArrayList<String>();
	private String subject;
	private String body;
	private String template;
	private String type;
	private String entity;
	private String viewUrl;
	private UserManagementRequest request;
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}

	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public String getTemplate() {
		return template;
	}
	public void setTemplate(String template) {
		this.template = template;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getEntity() {
		return entity;
	}
	public void setEntity(String entity) {
		this.entity = entity;
	}
	public UserManagementRequest getRequest() {
		return request;
	}
	public void setRequest(UserManagementRequest request) {
		this.request = request;
	}
	public List<String> getTo() {
		return to;
	}
	public void setTo(List<String> to) {
		this.to = to;
	}
	@Override
	public String toString() {
		return "FpsEmail [from=" + from + ", to=" + to + ", subject=" + subject + ", body=[truncated], template="
				+ template + ", type=" + type + ", entity=" + entity + ", request=" + request + "]";
	}
	public String toStringFull() {
		return "FpsEmail [from=" + from + ", to=" + to + ", subject=" + subject + ", body=" + body + ", template="
				+ template + ", type=" + type + ", entity=" + entity + ", request=" + request + "]";
	}
	public String getViewUrl() {
		return viewUrl;
	}
	public void setViewUrl(String viewUrl) {
		this.viewUrl = viewUrl;
	}

}
