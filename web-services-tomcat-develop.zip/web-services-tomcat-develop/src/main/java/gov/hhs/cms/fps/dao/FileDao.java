package gov.hhs.cms.fps.dao;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import gov.hhs.cms.fps.model.generated.FpsFilStore;

public interface FileDao {
	public FpsFilStore loadFile(Integer id);
	public Integer saveFile(Integer id, String userId, MultipartFile file, String section) throws IOException;
	public List<FpsFilStore> loadVmFiles(Integer id, String section);
	public List<FpsFilStore> deleteFile(Integer id, String userId);


}
