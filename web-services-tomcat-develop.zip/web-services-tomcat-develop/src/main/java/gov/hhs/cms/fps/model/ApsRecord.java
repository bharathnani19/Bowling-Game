package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.sql.Date;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.hhs.cms.fps.util.NAStringSerializer;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(content = Include.ALWAYS)
public class ApsRecord implements Serializable {
	private Integer identityId;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String npi;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String businessName;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String firstName;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String lastName;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	private Date chargeDate;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String chargeType;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String county;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String courtName;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String crimSource;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String disposition;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	private Date dispositionDate;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	private Date incarcerationDate;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String sentence;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	private Date sentenceDate;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String state;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String charge;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String courtJurisdiction;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)

	private String offenseId;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")

	private Date updateDt;
	private String newInd;
	public Integer getIdentityId() {
		return identityId;
	}
	public void setIdentityId(Integer identityId) {
		this.identityId = identityId;
	}
	public String getNpi() {
		return npi;
	}
	public void setNpi(String npi) {
		this.npi = npi;
	}
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getChargeDate() {
		return chargeDate;
	}
	public void setChargeDate(Date chargeDate) {
		this.chargeDate = chargeDate;
	}
	public String getChargeType() {
		return chargeType;
	}
	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public String getCourtName() {
		return courtName;
	}
	public void setCourtName(String courtName) {
		this.courtName = courtName;
	}
	public String getCrimSource() {
		return crimSource;
	}
	public void setCrimSource(String crimSource) {
		this.crimSource = crimSource;
	}
	public String getDisposition() {
		return disposition;
	}
	public void setDisposition(String disposition) {
		this.disposition = disposition;
	}
	public Date getDispositionDate() {
		return dispositionDate;
	}
	public void setDispositionDate(Date dispositionDate) {
		this.dispositionDate = dispositionDate;
	}
	public Date getIncarcerationDate() {
		return incarcerationDate;
	}
	public void setIncarcerationDate(Date incarcerationDate) {
		this.incarcerationDate = incarcerationDate;
	}
	public String getSentence() {
		return sentence;
	}
	public void setSentence(String sentence) {
		this.sentence = sentence;
	}
	public Date getSentenceDate() {
		return sentenceDate;
	}
	public void setSentenceDate(Date sentenceDate) {
		this.sentenceDate = sentenceDate;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCharge() {
		return charge;
	}
	public void setCharge(String charge) {
		this.charge = charge;
	}
	public String getCourtJurisdiction() {
		return courtJurisdiction;
	}
	public void setCourtJurisdiction(String courtJurisdiction) {
		this.courtJurisdiction = courtJurisdiction;
	}
	public String getOffenseId() {
		return offenseId;
	}
	public void setOffenseId(String offenseId) {
		this.offenseId = offenseId;
	}
	public Date getUpdateDt() {
		return updateDt;
	}
	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}
	public String getNewInd() {
		return newInd;
	}
	public void setNewInd(String newInd) {
		this.newInd = newInd;
	}
}
