package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonSerialize(include=Inclusion.NON_NULL)
public class AsrSearchResponse  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7304361723231342657L;
	private String transactionID;
	private String status;
	private String statusDescription;
	private List<AsrSummary> responseData;
	private List<AsrSummary> responseDataMdcd;
	private String owner;
	private String sharedInd;
	private Integer listId;
	private String listNm;
	private String listType;
	private Integer shareGrpId;
	private String mdcdPrrtyEnabledInd;
	public String getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the responseData
	 */
	public List<AsrSummary> getResponseData() {
		return responseData;
	}
	/**
	 * @param responseData the responseData to set
	 */
	public void setResponseData(List<AsrSummary> responseData) {
		this.responseData = responseData;
	}
	@Override
	public String toString() {
		return "AsrDiscoveryResponse [transactionID=" + transactionID
				+ ", status=" + status + ", responseData=" + responseData + "]";
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getSharedInd() {
		return sharedInd;
	}
	public void setSharedInd(String sharedInd) {
		this.sharedInd = sharedInd;
	}
	public Integer getListId() {
		return listId;
	}
	public void setListId(Integer listId) {
		this.listId = listId;
	}
	public String getListNm() {
		return listNm;
	}
	public void setListNm(String listNm) {
		this.listNm = listNm;
	}
	public String getListType() {
		return listType;
	}
	public void setListType(String listType) {
		this.listType = listType;
	}
	public Integer getShareGrpId() {
		return shareGrpId;
	}
	public void setShareGrpId(Integer shareGrpId) {
		this.shareGrpId = shareGrpId;
	}
	public List<AsrSummary> getResponseDataMdcd() {
		return responseDataMdcd;
	}
	public void setResponseDataMdcd(List<AsrSummary> responseDataMdcd) {
		this.responseDataMdcd = responseDataMdcd;
	}
	public String getMdcdPrrtyEnabledInd() {
		return mdcdPrrtyEnabledInd;
	}
	public void setMdcdPrrtyEnabledInd(String mdcdPrrtyEnabledInd) {
		this.mdcdPrrtyEnabledInd = mdcdPrrtyEnabledInd;
	}
	
	
}
