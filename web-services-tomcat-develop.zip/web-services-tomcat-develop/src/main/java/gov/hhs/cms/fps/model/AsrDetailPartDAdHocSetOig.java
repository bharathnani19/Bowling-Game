package gov.hhs.cms.fps.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import gov.hhs.cms.fps.config.PartDColumnFormat;
import gov.hhs.cms.fps.util.FpsEnums.PartDFormat;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.ANY)
@JsonInclude(Include.NON_NULL)
public class AsrDetailPartDAdHocSetOig extends AsrDetailPartDAdHocSet {
	

	
	public String getAdhocRptNm() {
		return adhocRptNm;
	}
	public void setAdhocRptNm(String adhocRptNm) {
		this.adhocRptNm = adhocRptNm;
	}
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var006Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var007Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var008Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var009Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var010Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var011Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var012Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var013Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var014Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var015Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var016Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var017Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var018Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var019Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var020Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var021Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var022Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var023Fmt;
	@PartDColumnFormat(format=PartDFormat.DATE)
	private String var024Fmt;
	@PartDColumnFormat(format=PartDFormat.DATE)
	private String var025Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var026Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var027Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var028Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var029Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var030Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var031Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var032Fmt;

	@PartDColumnFormat(format=PartDFormat.INT)
	private String var033Fmt;
	
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var034Fmt;
	
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var035Fmt;
	
	@PartDColumnFormat(format=PartDFormat.INT)
	private String  var036Fmt;
	
	@PartDColumnFormat(format=PartDFormat.INT)
	private String  var037Fmt;
	
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var038Fmt;
	
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var039Fmt;

	@PartDColumnFormat(format=PartDFormat.INT)
	private String var040Fmt;
 
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var041Fmt;
 
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var042Fmt;
 
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var043Fmt;
 
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var044Fmt;
 
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var045Fmt;
 
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var046Fmt;
 
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var047Fmt;
	
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var048Fmt;
 
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var049Fmt;
	 
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var050Fmt;
	 
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var051Fmt;
	 
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var052Fmt;

	@PartDColumnFormat(format=PartDFormat.INT)
	private String var053Fmt;
	 
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var054Fmt;

	private String var055Fmt;
	
	private String var056Fmt;
	private String var057Fmt;
	private String var058Fmt;
	private String var059Fmt;
	private String var060Fmt;
	private String var061Fmt;
	private String var062Fmt;
	private String var063Fmt;
	private String var064Fmt;
	private String var065Fmt;
	private String var066Fmt;
	private String var067Fmt;
	private String var068Fmt;
	private String var069Fmt;
	private String var070Fmt;
	private String var071Fmt;
	private String var072Fmt;
	private String var073Fmt;
	private String var074Fmt;
	private String var075Fmt;
	private String var076Fmt;
	private String var077Fmt;
	private String var078Fmt;
	private String var079Fmt;
	private String var080Fmt;
	private String var081Fmt;
	private String var082Fmt;
	private String var083Fmt;
	private String var084Fmt;
	private String var085Fmt;
	private String var086Fmt;
	private String var087Fmt;
	private String var088Fmt;
	private String var089Fmt;
	private String var090Fmt;
	private String var091Fmt;
	private String var092Fmt;
	private String var093Fmt;
	private String var094Fmt;
	private String var095Fmt;
	private String var096Fmt;
	private String var097Fmt;
	private String var098Fmt;
	private String var099Fmt;
	private String var100Fmt;
}
