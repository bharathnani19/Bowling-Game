package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonAutoDetect;

import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
@Table(name="FPS_ASRPT_RELATED_ASRS_VW")
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)

public class FpsAsrptRelatedAsrsVw implements Serializable {

	private String subjId;
	private String rltdSubjId;
	private String rltdPrvdrNm;
	private String rltdPrvdrType;
	private Integer rltdAsrptId;
	@JsonIgnore
	private FpsAsrpt fpsAsrpt;
	@JsonIgnore
	private FpsPrvdrAnlys fpsPrvdrAnlys;
	
	@Id
	@Column(name="ASR_SUBJ_ID")
	public String getSubjId() {
		return subjId;
	}
	public void setSubjId(String subjId) {
		this.subjId = subjId;
	}
	@Id
	@Column(name="RLTD_PRVDR_NPI_NUM")
	public String getRltdSubjId() {
		return rltdSubjId;
	}
	public void setRltdSubjId(String rltdSubjId) {
		this.rltdSubjId = rltdSubjId;
	}
	@Column(name="RLTD_PRVDR_NAME")
	public String getRltdPrvdrNm() {
		return rltdPrvdrNm;
	}
	public void setRltdPrvdrNm(String rltdPrvdrNm) {
		this.rltdPrvdrNm = rltdPrvdrNm;
	}
	@Column(name="RLTD_PRVDR_TYPE")
	public String getRltdPrvdrType() {
		return rltdPrvdrType;
	}
	public void setRltdPrvdrType(String rltdPrvdrType) {
		this.rltdPrvdrType = rltdPrvdrType;
	}
	@Column(name="RLTD_ASRPT_ID")
	public Integer getRltdAsrptId() {
		return rltdAsrptId;
	}
	public void setRltdAsrptId(Integer rltdAsrptId) {
		this.rltdAsrptId = rltdAsrptId;
	}
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "RLTD_ASRPT_ID", referencedColumnName = "ASRPT_ID", updatable = false, insertable = false)
	public FpsAsrpt getFpsAsrpt() {
		return fpsAsrpt;
	}
	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
		this.fpsAsrpt = fpsAsrpt;
	}
	@JsonIgnore
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "RLTD_ASRPT_ID", referencedColumnName = "ASRPT_ID", updatable = false, insertable = false, nullable = true)
	public FpsPrvdrAnlys getFpsPrvdrAnlys() {
		return fpsPrvdrAnlys;
	}
	public void setFpsPrvdrAnlys(FpsPrvdrAnlys fpsPrvdrAnlys) {
		this.fpsPrvdrAnlys = fpsPrvdrAnlys;
	}
}
