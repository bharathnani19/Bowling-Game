/*
 * 
 */
package gov.hhs.cms.fps.model;

// TODO: Auto-generated Javadoc
/**
 * The Class AsrDetailView.
 */
public class AsrDetailView {

	/** The ruling cnt. */
	private int rulingCnt;
	
	/** The current ruling dt. */
	private String currentRulingDt;
	
	/** The ruling desc. */
	private String rulingDesc;
	
	/** The ruling comments. */
	private String rulingComments;
	
	/** The prvdr specialty cnt. */
	private int prvdrSpecialtyCnt;
	
	/** The prfmng npi cnt. */
	private int prfmngNpiCnt;
	
	/** The submitter ent id cnt. */
	private int submitterEntIdCnt;
	
	/** The alert cnt. */
	private int alertCnt;
	
	/** The unique bene cnt. */
	private int uniqueBeneCnt;
	
	/** The dual bene cnt. */
	private int dualBeneCnt;
	
	/** The unique prfmng npi spec cnt. */
	private int uniquePrfmngNpiSpecCnt;
	
	/** The unique model names cnt. */
	private int uniqueModelNamesCnt;
	
	/** The all evidence cnt. */
	private int allEvidenceCnt;
	
	/** The unique bene state cnt. */
	private int uniqueBeneStateCnt;
	
	/** The dual bene pct. */
	private double dualBenePct;
	
	/** The unique case ptans cnt. */
	private int uniqueCasePtansCnt;
	
	/** The unique pfrmng npi states cnt. */
	private int uniquePfrmngNpiStatesCnt;
	
	/** The unique refer npis. */
	private int uniqueReferNpis;
	
	/** The unique procedure cnt. */
	private int uniqueProcedureCnt;
	
	/** The dme four week biu cnt. */
	private int dmeFourWeekBiuCnt;
	
	/** The part B four week biu cnt. */
	private int partBFourWeekBiuCnt;
	
	/** The part B year biu cnt. */
	private int partBYearBiuCnt;
	
	/** The total four week biu cnt. */
	private int totalFourWeekBiuCnt;
	
	/** The dme year biu cnt. */
	private int dmeYearBiuCnt;
	
	/** The part A year biu cnt. */
	private int partAYearBiuCnt;
	
	/** The total year biu cnt. */
	private int totalYearBiuCnt;
	
	/** The unique claim type cnt. */
	private int uniqueClaimTypeCnt;
	
	/** The asr id state cd. */
	private String asrIdStateCd;
	
	/** The case type cd. */
	private String caseTypeCd; //desc?
	
	/** The closure rule cd. */
	private String closureRuleCd; //desc?
	
	/** The in workload desc. */
	private String inWorkloadDesc;
	
	/** The status. */
	private String status;
	
	/** The unique prfmng npi ptan pairs. */
	private String uniquePrfmngNpiPtanPairs;
	
	/** The unique attend npi ptan pairs. */
	private String uniqueAttendNpiPtanPairs;
	
	/** The unique asr id ptan S pecialty pairs. */
	private String uniqueAsrIdPtanSPecialtyPairs;
	
	/** The unique asr id provider specialty. */
	private String uniqueAsrIdProviderSpecialty;
	
	/** The unique submitter entity id. */
	private String uniqueSubmitterEntityId;
	
	/** The system tags. */
	private String systemTags;
	
	/** The unique alert types. */
	private String uniqueAlertTypes;
	
	/** The unique prepayment alert types. */
	private String uniquePrepaymentAlertTypes;
	
	/** The unique asr npi roles. */
	private String uniqueAsrNpiRoles;
	
	/** The alert create dt. */
	private String alertCreateDt;
	
	/** The alert update dt. */
	private String alertUpdateDt;
	
	/** The alert priority. */
	private String alertPriority;
	
	/** The alert model type. */
	private String alertModelType;
	
	/** The alert procedure dt. */
	private String alertProcedureDt;
	
	/** The performing npi. */
	private String performingNpi;
	
	/** The attend npi. */
	private String attendNpi;
	
	/** The refer npi. */
	private String referNpi;
	
	/** The billing npi. */
	private String billingNpi;
	
	/** The bene id. */
	private String beneId;
	
	/** The alertd reasons. */
	private String alertdReasons;
	
	/** The unique cnc npi benes cnt. */
	private int uniqueCncNpiBenesCnt;
	
	/** The note dt. */
	private String noteDt;
	
	/** The note. */
	private String note;
	
	/** The user name. */
	private String userName;
	
	/** The role name. */
	private String roleName;
	
	/** The comment cnt. */
	private int commentCnt;
	
	/** The comment dt. */
	private String commentDt;
	
	/** The comments. */
	private String comments;
	
	/**
	 * Gets the ruling cnt.
	 *
	 * @return the ruling cnt
	 */
	public int getRulingCnt() {
		return rulingCnt;
	}
	
	/**
	 * Sets the ruling cnt.
	 *
	 * @param rulingCnt the new ruling cnt
	 */
	public void setRulingCnt(int rulingCnt) {
		this.rulingCnt = rulingCnt;
	}
	
	/**
	 * Gets the current ruling dt.
	 *
	 * @return the current ruling dt
	 */
	public String getCurrentRulingDt() {
		return currentRulingDt;
	}
	
	/**
	 * Sets the current ruling dt.
	 *
	 * @param currentRulingDt the new current ruling dt
	 */
	public void setCurrentRulingDt(String currentRulingDt) {
		this.currentRulingDt = currentRulingDt;
	}
	
	/**
	 * Gets the ruling desc.
	 *
	 * @return the ruling desc
	 */
	public String getRulingDesc() {
		return rulingDesc;
	}
	
	/**
	 * Sets the ruling desc.
	 *
	 * @param rulingDesc the new ruling desc
	 */
	public void setRulingDesc(String rulingDesc) {
		this.rulingDesc = rulingDesc;
	}
	
	/**
	 * Gets the ruling comments.
	 *
	 * @return the ruling comments
	 */
	public String getRulingComments() {
		return rulingComments;
	}
	
	/**
	 * Sets the ruling comments.
	 *
	 * @param rulingComments the new ruling comments
	 */
	public void setRulingComments(String rulingComments) {
		this.rulingComments = rulingComments;
	}
	
	/**
	 * Gets the prvdr specialty cnt.
	 *
	 * @return the prvdr specialty cnt
	 */
	public int getPrvdrSpecialtyCnt() {
		return prvdrSpecialtyCnt;
	}
	
	/**
	 * Sets the prvdr specialty cnt.
	 *
	 * @param prvdrSpecialtyCnt the new prvdr specialty cnt
	 */
	public void setPrvdrSpecialtyCnt(int prvdrSpecialtyCnt) {
		this.prvdrSpecialtyCnt = prvdrSpecialtyCnt;
	}
	
	/**
	 * Gets the prfmng npi cnt.
	 *
	 * @return the prfmng npi cnt
	 */
	public int getPrfmngNpiCnt() {
		return prfmngNpiCnt;
	}
	
	/**
	 * Sets the prfmng npi cnt.
	 *
	 * @param prfmngNpiCnt the new prfmng npi cnt
	 */
	public void setPrfmngNpiCnt(int prfmngNpiCnt) {
		this.prfmngNpiCnt = prfmngNpiCnt;
	}
	
	/**
	 * Gets the submitter ent id cnt.
	 *
	 * @return the submitter ent id cnt
	 */
	public int getSubmitterEntIdCnt() {
		return submitterEntIdCnt;
	}
	
	/**
	 * Sets the submitter ent id cnt.
	 *
	 * @param submitterEntIdCnt the new submitter ent id cnt
	 */
	public void setSubmitterEntIdCnt(int submitterEntIdCnt) {
		this.submitterEntIdCnt = submitterEntIdCnt;
	}
	
	/**
	 * Gets the alert cnt.
	 *
	 * @return the alert cnt
	 */
	public int getAlertCnt() {
		return alertCnt;
	}
	
	/**
	 * Sets the alert cnt.
	 *
	 * @param alertCnt the new alert cnt
	 */
	public void setAlertCnt(int alertCnt) {
		this.alertCnt = alertCnt;
	}
	
	/**
	 * Gets the unique bene cnt.
	 *
	 * @return the unique bene cnt
	 */
	public int getUniqueBeneCnt() {
		return uniqueBeneCnt;
	}
	
	/**
	 * Sets the unique bene cnt.
	 *
	 * @param uniqueBeneCnt the new unique bene cnt
	 */
	public void setUniqueBeneCnt(int uniqueBeneCnt) {
		this.uniqueBeneCnt = uniqueBeneCnt;
	}
	
	/**
	 * Gets the dual bene cnt.
	 *
	 * @return the dual bene cnt
	 */
	public int getDualBeneCnt() {
		return dualBeneCnt;
	}
	
	/**
	 * Sets the dual bene cnt.
	 *
	 * @param dualBeneCnt the new dual bene cnt
	 */
	public void setDualBeneCnt(int dualBeneCnt) {
		this.dualBeneCnt = dualBeneCnt;
	}
	
	/**
	 * Gets the unique prfmng npi spec cnt.
	 *
	 * @return the unique prfmng npi spec cnt
	 */
	public int getUniquePrfmngNpiSpecCnt() {
		return uniquePrfmngNpiSpecCnt;
	}
	
	/**
	 * Sets the unique prfmng npi spec cnt.
	 *
	 * @param uniquePrfmngNpiSpecCnt the new unique prfmng npi spec cnt
	 */
	public void setUniquePrfmngNpiSpecCnt(int uniquePrfmngNpiSpecCnt) {
		this.uniquePrfmngNpiSpecCnt = uniquePrfmngNpiSpecCnt;
	}
	
	/**
	 * Gets the unique model names cnt.
	 *
	 * @return the unique model names cnt
	 */
	public int getUniqueModelNamesCnt() {
		return uniqueModelNamesCnt;
	}
	
	/**
	 * Sets the unique model names cnt.
	 *
	 * @param uniqueModelNamesCnt the new unique model names cnt
	 */
	public void setUniqueModelNamesCnt(int uniqueModelNamesCnt) {
		this.uniqueModelNamesCnt = uniqueModelNamesCnt;
	}
	
	/**
	 * Gets the all evidence cnt.
	 *
	 * @return the all evidence cnt
	 */
	public int getAllEvidenceCnt() {
		return allEvidenceCnt;
	}
	
	/**
	 * Sets the all evidence cnt.
	 *
	 * @param allEvidenceCnt the new all evidence cnt
	 */
	public void setAllEvidenceCnt(int allEvidenceCnt) {
		this.allEvidenceCnt = allEvidenceCnt;
	}
	
	/**
	 * Gets the unique bene state cnt.
	 *
	 * @return the unique bene state cnt
	 */
	public int getUniqueBeneStateCnt() {
		return uniqueBeneStateCnt;
	}
	
	/**
	 * Sets the unique bene state cnt.
	 *
	 * @param uniqueBeneStateCnt the new unique bene state cnt
	 */
	public void setUniqueBeneStateCnt(int uniqueBeneStateCnt) {
		this.uniqueBeneStateCnt = uniqueBeneStateCnt;
	}
	
	/**
	 * Gets the dual bene pct.
	 *
	 * @return the dual bene pct
	 */
	public double getDualBenePct() {
		return dualBenePct;
	}
	
	/**
	 * Sets the dual bene pct.
	 *
	 * @param dualBenePct the new dual bene pct
	 */
	public void setDualBenePct(double dualBenePct) {
		this.dualBenePct = dualBenePct;
	}
	
	/**
	 * Gets the unique case ptans cnt.
	 *
	 * @return the unique case ptans cnt
	 */
	public int getUniqueCasePtansCnt() {
		return uniqueCasePtansCnt;
	}
	
	/**
	 * Sets the unique case ptans cnt.
	 *
	 * @param uniqueCasePtansCnt the new unique case ptans cnt
	 */
	public void setUniqueCasePtansCnt(int uniqueCasePtansCnt) {
		this.uniqueCasePtansCnt = uniqueCasePtansCnt;
	}
	
	/**
	 * Gets the unique pfrmng npi states cnt.
	 *
	 * @return the unique pfrmng npi states cnt
	 */
	public int getUniquePfrmngNpiStatesCnt() {
		return uniquePfrmngNpiStatesCnt;
	}
	
	/**
	 * Sets the unique pfrmng npi states cnt.
	 *
	 * @param uniquePfrmngNpiStatesCnt the new unique pfrmng npi states cnt
	 */
	public void setUniquePfrmngNpiStatesCnt(int uniquePfrmngNpiStatesCnt) {
		this.uniquePfrmngNpiStatesCnt = uniquePfrmngNpiStatesCnt;
	}
	
	/**
	 * Gets the unique refer npis.
	 *
	 * @return the unique refer npis
	 */
	public int getUniqueReferNpis() {
		return uniqueReferNpis;
	}
	
	/**
	 * Sets the unique refer npis.
	 *
	 * @param uniqueReferNpis the new unique refer npis
	 */
	public void setUniqueReferNpis(int uniqueReferNpis) {
		this.uniqueReferNpis = uniqueReferNpis;
	}
	
	/**
	 * Gets the unique procedure cnt.
	 *
	 * @return the unique procedure cnt
	 */
	public int getUniqueProcedureCnt() {
		return uniqueProcedureCnt;
	}
	
	/**
	 * Sets the unique procedure cnt.
	 *
	 * @param uniqueProcedureCnt the new unique procedure cnt
	 */
	public void setUniqueProcedureCnt(int uniqueProcedureCnt) {
		this.uniqueProcedureCnt = uniqueProcedureCnt;
	}
	
	/**
	 * Gets the dme four week biu cnt.
	 *
	 * @return the dme four week biu cnt
	 */
	public int getDmeFourWeekBiuCnt() {
		return dmeFourWeekBiuCnt;
	}
	
	/**
	 * Sets the dme four week biu cnt.
	 *
	 * @param dmeFourWeekBiuCnt the new dme four week biu cnt
	 */
	public void setDmeFourWeekBiuCnt(int dmeFourWeekBiuCnt) {
		this.dmeFourWeekBiuCnt = dmeFourWeekBiuCnt;
	}
	
	/**
	 * Gets the part B four week biu cnt.
	 *
	 * @return the part B four week biu cnt
	 */
	public int getPartBFourWeekBiuCnt() {
		return partBFourWeekBiuCnt;
	}
	
	/**
	 * Sets the part B four week biu cnt.
	 *
	 * @param partBFourWeekBiuCnt the new part B four week biu cnt
	 */
	public void setPartBFourWeekBiuCnt(int partBFourWeekBiuCnt) {
		this.partBFourWeekBiuCnt = partBFourWeekBiuCnt;
	}
	
	/**
	 * Gets the part B year biu cnt.
	 *
	 * @return the part B year biu cnt
	 */
	public int getPartBYearBiuCnt() {
		return partBYearBiuCnt;
	}
	
	/**
	 * Sets the part B year biu cnt.
	 *
	 * @param partBYearBiuCnt the new part B year biu cnt
	 */
	public void setPartBYearBiuCnt(int partBYearBiuCnt) {
		this.partBYearBiuCnt = partBYearBiuCnt;
	}
	
	/**
	 * Gets the total four week biu cnt.
	 *
	 * @return the total four week biu cnt
	 */
	public int getTotalFourWeekBiuCnt() {
		return totalFourWeekBiuCnt;
	}
	
	/**
	 * Sets the total four week biu cnt.
	 *
	 * @param totalFourWeekBiuCnt the new total four week biu cnt
	 */
	public void setTotalFourWeekBiuCnt(int totalFourWeekBiuCnt) {
		this.totalFourWeekBiuCnt = totalFourWeekBiuCnt;
	}
	
	/**
	 * Gets the dme year biu cnt.
	 *
	 * @return the dme year biu cnt
	 */
	public int getDmeYearBiuCnt() {
		return dmeYearBiuCnt;
	}
	
	/**
	 * Sets the dme year biu cnt.
	 *
	 * @param dmeYearBiuCnt the new dme year biu cnt
	 */
	public void setDmeYearBiuCnt(int dmeYearBiuCnt) {
		this.dmeYearBiuCnt = dmeYearBiuCnt;
	}
	
	/**
	 * Gets the part A year biu cnt.
	 *
	 * @return the part A year biu cnt
	 */
	public int getPartAYearBiuCnt() {
		return partAYearBiuCnt;
	}
	
	/**
	 * Sets the part A year biu cnt.
	 *
	 * @param partAYearBiuCnt the new part A year biu cnt
	 */
	public void setPartAYearBiuCnt(int partAYearBiuCnt) {
		this.partAYearBiuCnt = partAYearBiuCnt;
	}
	
	/**
	 * Gets the total year biu cnt.
	 *
	 * @return the total year biu cnt
	 */
	public int getTotalYearBiuCnt() {
		return totalYearBiuCnt;
	}
	
	/**
	 * Sets the total year biu cnt.
	 *
	 * @param totalYearBiuCnt the new total year biu cnt
	 */
	public void setTotalYearBiuCnt(int totalYearBiuCnt) {
		this.totalYearBiuCnt = totalYearBiuCnt;
	}
	
	/**
	 * Gets the unique claim type cnt.
	 *
	 * @return the unique claim type cnt
	 */
	public int getUniqueClaimTypeCnt() {
		return uniqueClaimTypeCnt;
	}
	
	/**
	 * Sets the unique claim type cnt.
	 *
	 * @param uniqueClaimTypeCnt the new unique claim type cnt
	 */
	public void setUniqueClaimTypeCnt(int uniqueClaimTypeCnt) {
		this.uniqueClaimTypeCnt = uniqueClaimTypeCnt;
	}
	
	/**
	 * Gets the asr id state cd.
	 *
	 * @return the asr id state cd
	 */
	public String getAsrIdStateCd() {
		return asrIdStateCd;
	}
	
	/**
	 * Sets the asr id state cd.
	 *
	 * @param asrIdStateCd the new asr id state cd
	 */
	public void setAsrIdStateCd(String asrIdStateCd) {
		this.asrIdStateCd = asrIdStateCd;
	}
	
	/**
	 * Gets the case type cd.
	 *
	 * @return the case type cd
	 */
	public String getCaseTypeCd() {
		return caseTypeCd;
	}
	
	/**
	 * Sets the case type cd.
	 *
	 * @param caseTypeCd the new case type cd
	 */
	public void setCaseTypeCd(String caseTypeCd) {
		this.caseTypeCd = caseTypeCd;
	}
	
	/**
	 * Gets the closure rule cd.
	 *
	 * @return the closure rule cd
	 */
	public String getClosureRuleCd() {
		return closureRuleCd;
	}
	
	/**
	 * Sets the closure rule cd.
	 *
	 * @param closureRuleCd the new closure rule cd
	 */
	public void setClosureRuleCd(String closureRuleCd) {
		this.closureRuleCd = closureRuleCd;
	}
	
	/**
	 * Gets the in workload desc.
	 *
	 * @return the in workload desc
	 */
	public String getInWorkloadDesc() {
		return inWorkloadDesc;
	}
	
	/**
	 * Sets the in workload desc.
	 *
	 * @param inWorkloadDesc the new in workload desc
	 */
	public void setInWorkloadDesc(String inWorkloadDesc) {
		this.inWorkloadDesc = inWorkloadDesc;
	}
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Gets the unique prfmng npi ptan pairs.
	 *
	 * @return the unique prfmng npi ptan pairs
	 */
	public String getUniquePrfmngNpiPtanPairs() {
		return uniquePrfmngNpiPtanPairs;
	}
	
	/**
	 * Sets the unique prfmng npi ptan pairs.
	 *
	 * @param uniquePrfmngNpiPtanPairs the new unique prfmng npi ptan pairs
	 */
	public void setUniquePrfmngNpiPtanPairs(String uniquePrfmngNpiPtanPairs) {
		this.uniquePrfmngNpiPtanPairs = uniquePrfmngNpiPtanPairs;
	}
	
	/**
	 * Gets the unique attend npi ptan pairs.
	 *
	 * @return the unique attend npi ptan pairs
	 */
	public String getUniqueAttendNpiPtanPairs() {
		return uniqueAttendNpiPtanPairs;
	}
	
	/**
	 * Sets the unique attend npi ptan pairs.
	 *
	 * @param uniqueAttendNpiPtanPairs the new unique attend npi ptan pairs
	 */
	public void setUniqueAttendNpiPtanPairs(String uniqueAttendNpiPtanPairs) {
		this.uniqueAttendNpiPtanPairs = uniqueAttendNpiPtanPairs;
	}
	
	/**
	 * Gets the unique asr id ptan S pecialty pairs.
	 *
	 * @return the unique asr id ptan S pecialty pairs
	 */
	public String getUniqueAsrIdPtanSPecialtyPairs() {
		return uniqueAsrIdPtanSPecialtyPairs;
	}
	
	/**
	 * Sets the unique asr id ptan S pecialty pairs.
	 *
	 * @param uniqueAsrIdPtanSPecialtyPairs the new unique asr id ptan S pecialty pairs
	 */
	public void setUniqueAsrIdPtanSPecialtyPairs(
			String uniqueAsrIdPtanSPecialtyPairs) {
		this.uniqueAsrIdPtanSPecialtyPairs = uniqueAsrIdPtanSPecialtyPairs;
	}
	
	/**
	 * Gets the unique asr id provider specialty.
	 *
	 * @return the unique asr id provider specialty
	 */
	public String getUniqueAsrIdProviderSpecialty() {
		return uniqueAsrIdProviderSpecialty;
	}
	
	/**
	 * Sets the unique asr id provider specialty.
	 *
	 * @param uniqueAsrIdProviderSpecialty the new unique asr id provider specialty
	 */
	public void setUniqueAsrIdProviderSpecialty(String uniqueAsrIdProviderSpecialty) {
		this.uniqueAsrIdProviderSpecialty = uniqueAsrIdProviderSpecialty;
	}
	
	/**
	 * Gets the unique submitter entity id.
	 *
	 * @return the unique submitter entity id
	 */
	public String getUniqueSubmitterEntityId() {
		return uniqueSubmitterEntityId;
	}
	
	/**
	 * Sets the unique submitter entity id.
	 *
	 * @param uniqueSubmitterEntityId the new unique submitter entity id
	 */
	public void setUniqueSubmitterEntityId(String uniqueSubmitterEntityId) {
		this.uniqueSubmitterEntityId = uniqueSubmitterEntityId;
	}
	
	/**
	 * Gets the system tags.
	 *
	 * @return the system tags
	 */
	public String getSystemTags() {
		return systemTags;
	}
	
	/**
	 * Sets the system tags.
	 *
	 * @param systemTags the new system tags
	 */
	public void setSystemTags(String systemTags) {
		this.systemTags = systemTags;
	}
	
	/**
	 * Gets the unique alert types.
	 *
	 * @return the unique alert types
	 */
	public String getUniqueAlertTypes() {
		return uniqueAlertTypes;
	}
	
	/**
	 * Sets the unique alert types.
	 *
	 * @param uniqueAlertTypes the new unique alert types
	 */
	public void setUniqueAlertTypes(String uniqueAlertTypes) {
		this.uniqueAlertTypes = uniqueAlertTypes;
	}
	
	/**
	 * Gets the unique prepayment alert types.
	 *
	 * @return the unique prepayment alert types
	 */
	public String getUniquePrepaymentAlertTypes() {
		return uniquePrepaymentAlertTypes;
	}
	
	/**
	 * Sets the unique prepayment alert types.
	 *
	 * @param uniquePrepaymentAlertTypes the new unique prepayment alert types
	 */
	public void setUniquePrepaymentAlertTypes(String uniquePrepaymentAlertTypes) {
		this.uniquePrepaymentAlertTypes = uniquePrepaymentAlertTypes;
	}
	
	/**
	 * Gets the unique asr npi roles.
	 *
	 * @return the unique asr npi roles
	 */
	public String getUniqueAsrNpiRoles() {
		return uniqueAsrNpiRoles;
	}
	
	/**
	 * Sets the unique asr npi roles.
	 *
	 * @param uniqueAsrNpiRoles the new unique asr npi roles
	 */
	public void setUniqueAsrNpiRoles(String uniqueAsrNpiRoles) {
		this.uniqueAsrNpiRoles = uniqueAsrNpiRoles;
	}
	
	/**
	 * Gets the alert create dt.
	 *
	 * @return the alert create dt
	 */
	public String getAlertCreateDt() {
		return alertCreateDt;
	}
	
	/**
	 * Sets the alert create dt.
	 *
	 * @param alertCreateDt the new alert create dt
	 */
	public void setAlertCreateDt(String alertCreateDt) {
		this.alertCreateDt = alertCreateDt;
	}
	
	/**
	 * Gets the alert update dt.
	 *
	 * @return the alert update dt
	 */
	public String getAlertUpdateDt() {
		return alertUpdateDt;
	}
	
	/**
	 * Sets the alert update dt.
	 *
	 * @param alertUpdateDt the new alert update dt
	 */
	public void setAlertUpdateDt(String alertUpdateDt) {
		this.alertUpdateDt = alertUpdateDt;
	}
	
	/**
	 * Gets the alert priority.
	 *
	 * @return the alert priority
	 */
	public String getAlertPriority() {
		return alertPriority;
	}
	
	/**
	 * Sets the alert priority.
	 *
	 * @param alertPriority the new alert priority
	 */
	public void setAlertPriority(String alertPriority) {
		this.alertPriority = alertPriority;
	}
	
	/**
	 * Gets the alert model type.
	 *
	 * @return the alert model type
	 */
	public String getAlertModelType() {
		return alertModelType;
	}
	
	/**
	 * Sets the alert model type.
	 *
	 * @param alertModelType the new alert model type
	 */
	public void setAlertModelType(String alertModelType) {
		this.alertModelType = alertModelType;
	}
	
	/**
	 * Gets the alert procedure dt.
	 *
	 * @return the alert procedure dt
	 */
	public String getAlertProcedureDt() {
		return alertProcedureDt;
	}
	
	/**
	 * Sets the alert procedure dt.
	 *
	 * @param alertProcedureDt the new alert procedure dt
	 */
	public void setAlertProcedureDt(String alertProcedureDt) {
		this.alertProcedureDt = alertProcedureDt;
	}
	
	/**
	 * Gets the performing npi.
	 *
	 * @return the performing npi
	 */
	public String getPerformingNpi() {
		return performingNpi;
	}
	
	/**
	 * Sets the performing npi.
	 *
	 * @param performingNpi the new performing npi
	 */
	public void setPerformingNpi(String performingNpi) {
		this.performingNpi = performingNpi;
	}
	
	/**
	 * Gets the attend npi.
	 *
	 * @return the attend npi
	 */
	public String getAttendNpi() {
		return attendNpi;
	}
	
	/**
	 * Sets the attend npi.
	 *
	 * @param attendNpi the new attend npi
	 */
	public void setAttendNpi(String attendNpi) {
		this.attendNpi = attendNpi;
	}
	
	/**
	 * Gets the refer npi.
	 *
	 * @return the refer npi
	 */
	public String getReferNpi() {
		return referNpi;
	}
	
	/**
	 * Sets the refer npi.
	 *
	 * @param referNpi the new refer npi
	 */
	public void setReferNpi(String referNpi) {
		this.referNpi = referNpi;
	}
	
	/**
	 * Gets the billing npi.
	 *
	 * @return the billing npi
	 */
	public String getBillingNpi() {
		return billingNpi;
	}
	
	/**
	 * Sets the billing npi.
	 *
	 * @param billingNpi the new billing npi
	 */
	public void setBillingNpi(String billingNpi) {
		this.billingNpi = billingNpi;
	}
	
	/**
	 * Gets the bene id.
	 *
	 * @return the bene id
	 */
	public String getBeneId() {
		return beneId;
	}
	
	/**
	 * Sets the bene id.
	 *
	 * @param beneId the new bene id
	 */
	public void setBeneId(String beneId) {
		this.beneId = beneId;
	}
	
	/**
	 * Gets the alertd reasons.
	 *
	 * @return the alertd reasons
	 */
	public String getAlertdReasons() {
		return alertdReasons;
	}
	
	/**
	 * Sets the alertd reasons.
	 *
	 * @param alertdReasons the new alertd reasons
	 */
	public void setAlertdReasons(String alertdReasons) {
		this.alertdReasons = alertdReasons;
	}
	
	/**
	 * Gets the unique cnc npi benes cnt.
	 *
	 * @return the unique cnc npi benes cnt
	 */
	public int getUniqueCncNpiBenesCnt() {
		return uniqueCncNpiBenesCnt;
	}
	
	/**
	 * Sets the unique cnc npi benes cnt.
	 *
	 * @param uniqueCncNpiBenesCnt the new unique cnc npi benes cnt
	 */
	public void setUniqueCncNpiBenesCnt(int uniqueCncNpiBenesCnt) {
		this.uniqueCncNpiBenesCnt = uniqueCncNpiBenesCnt;
	}
	
	/**
	 * Gets the note dt.
	 *
	 * @return the note dt
	 */
	public String getNoteDt() {
		return noteDt;
	}
	
	/**
	 * Sets the note dt.
	 *
	 * @param noteDt the new note dt
	 */
	public void setNoteDt(String noteDt) {
		this.noteDt = noteDt;
	}
	
	/**
	 * Gets the note.
	 *
	 * @return the note
	 */
	public String getNote() {
		return note;
	}
	
	/**
	 * Sets the note.
	 *
	 * @param note the new note
	 */
	public void setNote(String note) {
		this.note = note;
	}
	
	/**
	 * Gets the user name.
	 *
	 * @return the user name
	 */
	public String getUserName() {
		return userName;
	}
	
	/**
	 * Sets the user name.
	 *
	 * @param userName the new user name
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	/**
	 * Gets the role name.
	 *
	 * @return the role name
	 */
	public String getRoleName() {
		return roleName;
	}
	
	/**
	 * Sets the role name.
	 *
	 * @param roleName the new role name
	 */
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	
	/**
	 * Gets the comment cnt.
	 *
	 * @return the comment cnt
	 */
	public int getCommentCnt() {
		return commentCnt;
	}
	
	/**
	 * Sets the comment cnt.
	 *
	 * @param commentCnt the new comment cnt
	 */
	public void setCommentCnt(int commentCnt) {
		this.commentCnt = commentCnt;
	}
	
	/**
	 * Gets the comment dt.
	 *
	 * @return the comment dt
	 */
	public String getCommentDt() {
		return commentDt;
	}
	
	/**
	 * Sets the comment dt.
	 *
	 * @param commentDt the new comment dt
	 */
	public void setCommentDt(String commentDt) {
		this.commentDt = commentDt;
	}
	
	/**
	 * Gets the comments.
	 *
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}
	
	/**
	 * Sets the comments.
	 *
	 * @param comments the new comments
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	
	
	
}
