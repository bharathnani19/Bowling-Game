package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailLead implements Serializable {
	private static final long serialVersionUID = 9199735324719880993L;
	private int id;
	private String category;
	private String status;
	private String assignedTo;
	private String legacyInd;
	private String createdDt;
	private String modDt;
	private String ruling;
	private String bpmTaskId;
	private String bpmProcNum;
	private String subRuling;
	private int activities;
	private int actions;
	private String source;
	private String ucmId;
	private List<AsrDetailUcmEntity> ucmActions;
	private List<AsrDetailUcmEntity> ucmActivities;
	private List<AsrDetailUcmEntity> ucmBarriers;
	private List<AsrDetailUcmEntity> ucmRulings;
	private List<AsrDetailUcmEntity> ucmModelRatings;
	private String state;

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAssignedTo() {
		return this.assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public String getLegacyInd() {
		return this.legacyInd;
	}

	public void setLegacyInd(String legacyInd) {
		this.legacyInd = legacyInd;
	}

	public String getCreatedDt() {
		return this.createdDt;
	}

	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}

	public String getModDt() {
		return this.modDt;
	}

	public void setModDt(String modDt) {
		this.modDt = modDt;
	}

	public String getRuling() {
		return this.ruling;
	}

	public void setRuling(String ruling) {
		this.ruling = ruling;
	}

	public String getBpmTaskId() {
		return this.bpmTaskId;
	}

	public void setBpmTaskId(String bpmTaskId) {
		this.bpmTaskId = bpmTaskId;
	}

	public String getBpmProcNum() {
		return this.bpmProcNum;
	}

	public void setBpmProcNum(String bpmProcNum) {
		this.bpmProcNum = bpmProcNum;
	}

	public int getActivities() {
		return this.activities;
	}

	public void setActivities(int activities) {
		this.activities = activities;
	}

	public int getActions() {
		return this.actions;
	}

	public void setActions(int actions) {
		this.actions = actions;
	}

	public String getSubRuling() {
		return this.subRuling;
	}

	public void setSubRuling(String subRuling) {
		this.subRuling = subRuling;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getUcmId() {
		return ucmId;
	}

	public void setUcmId(String ucmId) {
		this.ucmId = ucmId;
	}

	public List<AsrDetailUcmEntity> getUcmActions() {
		return ucmActions;
	}

	public void setUcmActions(List<AsrDetailUcmEntity> ucmActions) {
		this.ucmActions = ucmActions;
	}

	public List<AsrDetailUcmEntity> getUcmActivities() {
		return ucmActivities;
	}

	public void setUcmActivities(List<AsrDetailUcmEntity> ucmActivities) {
		this.ucmActivities = ucmActivities;
	}

	public List<AsrDetailUcmEntity> getUcmBarriers() {
		return ucmBarriers;
	}

	public void setUcmBarriers(List<AsrDetailUcmEntity> ucmBarriers) {
		this.ucmBarriers = ucmBarriers;
	}

	public List<AsrDetailUcmEntity> getUcmRulings() {
		return ucmRulings;
	}

	public void setUcmRulings(List<AsrDetailUcmEntity> ucmRulings) {
		this.ucmRulings = ucmRulings;
	}

	public List<AsrDetailUcmEntity> getUcmModelRatings() {
		return ucmModelRatings;
	}

	public void setUcmModelRatings(List<AsrDetailUcmEntity> ucmModelRatings) {
		this.ucmModelRatings = ucmModelRatings;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
}
