package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Table(name="FPS_ASRPT_ZN_ASCTN")
@Entity
public class FpsAsrptZnAsctn implements Serializable {
	
	private Integer asrptId;
	private String cntrctrDesc;
	private String cntrctrNm;
	private BigDecimal clmCost;
	private Integer clmCnt;
	
	@Id
	@Column(name="ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	@Column(name="CNTRCTR_DESC")
	public String getCntrctrDesc() {
		return cntrctrDesc;
	}
	public void setCntrctrDesc(String cntrctrDesc) {
		this.cntrctrDesc = cntrctrDesc;
	}
	@Column(name="CNTRCTR_NAME")
	public String getCntrctrNm() {
		return cntrctrNm;
	}
	public void setCntrctrNm(String cntrctrNm) {
		this.cntrctrNm = cntrctrNm;
	}
	@Column(name="CLM_COST")
	public BigDecimal getClmCost() {
		return clmCost;
	}
	public void setClmCost(BigDecimal clmCost) {
		this.clmCost = clmCost;
	}
	@Column(name="CLM_CNT")
	public Integer getClmCnt() {
		return clmCnt;
	}
	public void setClmCnt(Integer clmCnt) {
		this.clmCnt = clmCnt;
	}

}
