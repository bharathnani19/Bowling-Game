package gov.hhs.cms.fps.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class CustomTableData implements Serializable {

	private String columnName;
	private String columnData;
	private Integer columnIndex;
	private Integer rowIndex;
	private String linkToAsrInd="N";
	private byte[] columnImgSrc;
	private String columnImgSrcType;

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getColumnData() {
		return columnData;
	}

	public void setColumnData(String columnData) {
		this.columnData = columnData;
	}

	public Integer getColumnIndex() {
		return columnIndex;
	}

	public void setColumnIndex(Integer columnIndex) {
		this.columnIndex = columnIndex;
	}

	public Integer getRowIndex() {
		return rowIndex;
	}

	public void setRowIndex(Integer rowIndex) {
		this.rowIndex = rowIndex;
	}

	public String getLinkToAsrInd() {
		return linkToAsrInd;
	}

	public void setLinkToAsrInd(String linkToAsrInd) {
		this.linkToAsrInd = linkToAsrInd;
	}

	public byte[] getColumnImgSrc() {
		return columnImgSrc;
	}

	public void setColumnImgSrc(byte[] columnImgSrc) {
		this.columnImgSrc = columnImgSrc;
	}

	public String getColumnImgSrcType() {
		return columnImgSrcType;
	}

	public void setColumnImgSrcType(String columnImgSrcType) {
		this.columnImgSrcType = columnImgSrcType;
	}
}
