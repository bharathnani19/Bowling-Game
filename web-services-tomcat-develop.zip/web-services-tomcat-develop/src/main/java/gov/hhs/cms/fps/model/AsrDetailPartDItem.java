package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import gov.hhs.cms.fps.config.PartDColumnName;
import gov.hhs.cms.fps.util.FpsEnums.PartDEnum;
import gov.hhs.cms.fps.util.FpsEnums.PartDFormat;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailPartDItem implements Serializable {

	private String type;
	private String desc;
	private String name;
	// Common

	private String audtInsrtId;
	private Timestamp audtInsrtTs;
	private String audtUpdtId;
	private Timestamp audtUpdtTs;
	@PartDColumnName(name="Prescriber NPI")
	private String prscrbrNpi;
	@PartDColumnName(name="Prescriber Name", excludes={PartDEnum.OIG2})
	private String prscrbrName;
//	@PartDColumnName(name="Hospice CCN", includes={PartDEnum.OIG2})
//	private String hospiceCcn;
	@PartDColumnName(name="Hospice Name", includes={PartDEnum.OIG2})
	private String hospiceName;
	private Date stdyPrdEnd;
	private Date stdyPrdStrt;
	@PartDColumnName(name="Start Date of Study Period")
	private String stdyPrdStrtStr;
	@PartDColumnName(name="End Date of Study Period")
	private String stdyPrdEndStr;

	@PartDColumnName(name="state_cd_01", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String stateCd1;

	@PartDColumnName(name="state_cd_02", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String stateCd2;
	@PartDColumnName(name="state_cd_03", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String stateCd3;
	@PartDColumnName(name="state_cd_04", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String stateCd4;
	@PartDColumnName(name="state_cd_05", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String stateCd5;
	@PartDColumnName(name="state_cd_06", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String stateCd6;
	@PartDColumnName(name="state_cd_07", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String stateCd7;
	@PartDColumnName(name="state_cd_08", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String stateCd8;
	@PartDColumnName(name="state_cd_09", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String stateCd9;
	@PartDColumnName(name="state_cd_10", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String stateCd10;
	@PartDColumnName(name = "enrlmt_specialty_desc_01", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String enrlmtSpcltyDesc1;
	@PartDColumnName(name = "enrlmt_specialty_desc_02", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String enrlmtSpcltyDesc2;
	@PartDColumnName(name = "enrlmt_specialty_desc_03", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String enrlmtSpcltyDesc3;
	@PartDColumnName(name = "enrlmt_specialty_desc_04", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String enrlmtSpcltyDesc4;
	@PartDColumnName(name = "enrlmt_specialty_desc_05", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String enrlmtSpcltyDesc5;
	@PartDColumnName(name = "fid_active", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String fidActv;
	@PartDColumnName(name = "fid_inactive", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String fidInactv;
	private Date fidLastPmtSuspnsnBgnDt;
	private Date fidLastPmtSuspnsnEndDt;
	@PartDColumnName(name="last_pmt_suspnsn_efctv_dt", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String fidLastPmtSuspnsnBgnDtStr;
	@PartDColumnName(name="last_pmt_suspnsn_end_dt", excludes={PartDEnum.OIG2, PartDEnum.AH})
	private String fidLastPmtSuspnsnEndDtStr;
	@PartDColumnName(name="pecos_enrlmts_total", format =PartDFormat.INT, excludes={PartDEnum.OIG2, PartDEnum.AH})
	private Integer pecosEnrlmtTot;
	@PartDColumnName(name="pecos_enrlmts_approved", format =PartDFormat.INT, excludes={PartDEnum.OIG2, PartDEnum.AH})
	private Integer pecosEnrlmtAprvd;
	@PartDColumnName(name="pecos_enrlmts_revoked", format =PartDFormat.INT, excludes={PartDEnum.OIG2, PartDEnum.AH})
	private Integer pecosEnrlmtRvked;
	@PartDColumnName(name="pecos_enrlmts_deactivated", format =PartDFormat.INT, excludes={PartDEnum.OIG2, PartDEnum.AH})
	private Integer pecosEnrlmtDactvtd;
	@PartDColumnName(name="pecos_enrlmts_optout", format =PartDFormat.INT, excludes={PartDEnum.OIG2, PartDEnum.AH})
	private Integer pecosEnrlmtOptout;
	@PartDColumnName(name="pecos_enrlmts_missing", format =PartDFormat.INT, excludes={PartDEnum.OIG2, PartDEnum.AH})
	private Integer pecosEnrlmtMisg;

	@PartDColumnName(name="pecos_enrlmts_other", format =PartDFormat.INT, excludes={PartDEnum.OIG2, PartDEnum.AH})
	private Integer pecosEnrlmtOthr;
	

	
	@PartDColumnName(name="op_rx_top_1pct", includes={ PartDEnum.OAE}, format =PartDFormat.STR)
	private String opRxTop1Pct;
	@PartDColumnName(name="op_rx_top_5pct", includes={ PartDEnum.OAE}, format =PartDFormat.STR)
	private String opRxTop5Pct;
	@PartDColumnName(name="op_rx_top_10pct", includes={ PartDEnum.OAE}, format =PartDFormat.STR)
	private String opRxTop10Pct;
	@PartDColumnName(name="op_rx_top_25pct", includes={ PartDEnum.OAE}, format =PartDFormat.STR)
	private String opRxTop25Pct;

	@PartDColumnName(name="op_bene_top_1pct", includes={ PartDEnum.OAE}, format =PartDFormat.STR)
	private String opBeneTop1Pct;
	@PartDColumnName(name="op_bene_top_5pct", includes={ PartDEnum.OAE}, format =PartDFormat.STR)
	private String opBeneTop5Pct;
	@PartDColumnName(name="op_bene_top_10pct", includes={ PartDEnum.OAE}, format =PartDFormat.STR)
	private String opBeneTop10Pct;
	@PartDColumnName(name="op_bene_top_25pct", includes={ PartDEnum.OAE}, format =PartDFormat.STR)
	private String opBeneTop25Pct;

	@PartDColumnName(name="op_bene_er_od_dth_90", includes={ PartDEnum.OAE}, format =PartDFormat.INT)
	private Integer opBeneErOd90Days;
	@PartDColumnName(name="op_bene_er_od_dth_30", includes={ PartDEnum.OAE}, format =PartDFormat.INT)
	private Integer opBeneErOd30Days;
	@PartDColumnName(name="op_bene_er_od_dth_7", includes={ PartDEnum.OAE}, format =PartDFormat.INT)
	private Integer opBeneErOd7Days;
	@PartDColumnName(name="op_bene_er_od_dth_1", includes={ PartDEnum.OAE}, format =PartDFormat.INT)
	private Integer opBeneErOd1Day;
	@PartDColumnName(name="op_bene_er_od_dth_30_mme", includes={ PartDEnum.OAE}, format =PartDFormat.INT)
	private Integer opBeneErOd30Mme;
	@PartDColumnName(name="op_bene_er_od_dth_30_mme_vals", includes={ PartDEnum.OAE}, format =PartDFormat.STR)
	private String opBeneErOd30AvgMme;


	@PartDColumnName(name="total_bene",excludes={ PartDEnum.OIG,PartDEnum.AH,PartDEnum.OIG2} , format =PartDFormat.INT)
	private Integer totBene;
	@PartDColumnName(name="op_bene",excludes={ PartDEnum.OIG, PartDEnum.AH,PartDEnum.OIG2}, format =PartDFormat.INT )
	private Integer opBene;
	@PartDColumnName(name="op_bene_pct",excludes={ PartDEnum.OIG, PartDEnum.AH,PartDEnum.OIG2}, format =PartDFormat.PCT)
	private BigDecimal opBenePct;
	
	@PartDColumnName(name="op_daily_MME_bene",  includes={ PartDEnum.OAE,PartDEnum.OP},excludes={ PartDEnum.OIG,PartDEnum.OIG2}, format =PartDFormat.INT)
	private Integer opDailyMmeBene;
	@PartDColumnName(name="op_daily_MME_bene_pct", includes={ PartDEnum.OAE,PartDEnum.OP},excludes={ PartDEnum.OIG,PartDEnum.OIG2}, format =PartDFormat.PCT)
	private BigDecimal opDailyMmeBenePct;
	

	@PartDColumnName(name="op_avg_MME_bene",excludes={ PartDEnum.OIG, PartDEnum.AH,PartDEnum.OIG2}, format =PartDFormat.INT)
	private Integer opAvgMmeBene;
	@PartDColumnName(name="op_avg_MME_bene_pct",excludes={ PartDEnum.OIG, PartDEnum.AH,PartDEnum.OIG2}, format =PartDFormat.PCT)
	private BigDecimal opAvgMmeBenePct;
	
	@PartDColumnName(name="bz_bene", includes={ PartDEnum.OB}, format =PartDFormat.INT)
	private Integer bzoBene;
	@PartDColumnName(name="bz_bene_pct", includes={ PartDEnum.OB}, format =PartDFormat.PCT)
	private BigDecimal bzoBenePct;
	@PartDColumnName(name="op_bz_conc_bene", includes={ PartDEnum.OB}, format =PartDFormat.INT)
	private Integer opBzoCncrntBene;
	@PartDColumnName(name="op_bz_conc_bene_pct", includes={ PartDEnum.OB}, format =PartDFormat.PCT)
	private BigDecimal opBzoCncrntBenePct;
	@PartDColumnName(name="op_bz_conc_7_bene", includes={ PartDEnum.OB}, format =PartDFormat.INT)
	private Integer opBzoCncrnt7Bene;
	@PartDColumnName(name="op_bz_conc_7_bene_pct", includes={ PartDEnum.OB}, format =PartDFormat.PCT)
	private BigDecimal opBzoCncrnt7BenePct;

	@PartDColumnName(name="op_bz_conc_7_mme_bene", includes={ PartDEnum.OB}, format =PartDFormat.INT)
	private Integer opBzoCncrnt7MmeBene;
	@PartDColumnName(name="op_bz_conc_7_mme_bene_pct", includes={ PartDEnum.OB}, format =PartDFormat.PCT)
	private BigDecimal opBzoCncrnt7BeneMmePct;
	@PartDColumnName(name="op_presc_shopping_bene", includes={ PartDEnum.OAE,PartDEnum.OP}, format =PartDFormat.INT)
	private Integer opPrscrbrShpngBene;
	@PartDColumnName(name="op_presc_shopping_bene_pct", includes={ PartDEnum.OAE,PartDEnum.OP}, format =PartDFormat.PCT)
	private BigDecimal opPrscrbrShpngBenePct;
	@PartDColumnName(name="op_pharm_shopping_bene", includes={ PartDEnum.OAE,PartDEnum.OP}, format =PartDFormat.INT)
	private Integer opPhrmcyShpngBene;
	@PartDColumnName(name="op_pharm_shopping_bene_pct", includes={ PartDEnum.OAE,PartDEnum.OP}, format =PartDFormat.PCT)
	private BigDecimal opPhrmcyShpngBenePct;


	
	@PartDColumnName(name="op_dailyMME_shopping_bene", includes={ PartDEnum.OAE,PartDEnum.OP}, format =PartDFormat.INT)
	private Integer opDailyMmeShpngBene;
	@PartDColumnName(name="op_dailyMME_shopping_bene_pct", includes={ PartDEnum.OAE,PartDEnum.OP}, format =PartDFormat.PCT)
	private BigDecimal opDailyMmeShpngBenePct;
	@PartDColumnName(name="op_avgMME_shopping_bene", includes={ PartDEnum.OAE,PartDEnum.OP}, format =PartDFormat.INT)
	private Integer opAvgMmeShpngBene;
	@PartDColumnName(name="op_avgMME_shopping_bene_pct", includes={ PartDEnum.OAE,PartDEnum.OP}, format =PartDFormat.PCT)
	private BigDecimal opAvgMmeShpngBenePct;
	@PartDColumnName(name="total_lines", excludes={ PartDEnum.AH,PartDEnum.OIG,PartDEnum.OIG2}, format =PartDFormat.INT)
	private Integer totLines;
	@PartDColumnName(name="op_lines", format =PartDFormat.INT, excludes={ PartDEnum.AH,PartDEnum.OIG,PartDEnum.OIG2})
	private Integer opLines;
	@PartDColumnName(name="op_lines_pct", format =PartDFormat.PCT, excludes={ PartDEnum.AH,PartDEnum.OIG,PartDEnum.OIG2})
	private BigDecimal opLinesPct;
	@PartDColumnName(name="op_lines_per_bene", format =PartDFormat.DECIMAL, excludes={ PartDEnum.AH,PartDEnum.OIG,PartDEnum.OIG2})
	private BigDecimal opLinesPerBene;
	@PartDColumnName(name="avg_MME_per_bene_per_Day", format =PartDFormat.DECIMAL, excludes={ PartDEnum.AH,PartDEnum.OIG,PartDEnum.OIG2})
	private BigDecimal opLinesPerBenePerDay;
	@PartDColumnName(name="bz_lines", includes={ PartDEnum.OB}, format =PartDFormat.INT)
	private Integer bzoLines;
	@PartDColumnName(name="bz_lines_pct", includes={ PartDEnum.OB}, format =PartDFormat.DECIMAL)
	private BigDecimal bzoLinesPct;
	@PartDColumnName(name="bz_lines_per_bene", includes={ PartDEnum.OB}, format =PartDFormat.DECIMAL)
	private BigDecimal bzoLinesPerBene;
	@PartDColumnName(name="op_NDCs_per_bene", includes={ PartDEnum.OAE, PartDEnum.OP}, format =PartDFormat.DECIMAL)
	private BigDecimal opNdcPerBene;
	@PartDColumnName(name="total_pmt",format =PartDFormat.DOLLAR, excludes={ PartDEnum.AH,PartDEnum.OIG,PartDEnum.OIG2}) //BZ
	private BigDecimal totPmt;
	@PartDColumnName(name="op_pmt", format =PartDFormat.DOLLAR, excludes={ PartDEnum.AH,PartDEnum.OIG,PartDEnum.OIG2})
	private BigDecimal opPmt;
	@PartDColumnName(name="op_pmt_pct", format =PartDFormat.PCT, excludes={ PartDEnum.AH,PartDEnum.OIG,PartDEnum.OIG2})
	private BigDecimal opPmtPct;
	@PartDColumnName(name="op_pmt_per_bene",format =PartDFormat.DOLLAR, excludes={ PartDEnum.AH,PartDEnum.OIG,PartDEnum.OIG2})
	private BigDecimal opPmtPerBene;



	@PartDColumnName(name="bz_pmt", includes={ PartDEnum.OB},format =PartDFormat.DOLLAR)
	private BigDecimal bzoPmt;
	@PartDColumnName(name="bz_pmt_pct", includes={ PartDEnum.OB}, format =PartDFormat.PCT)
	private BigDecimal bzoPmtPct;
	@PartDColumnName(name="bz_pmt_per_bene", includes={ PartDEnum.OB},format =PartDFormat.DOLLAR)
	private BigDecimal bzoPmtPerBene;



	




	private List<AsrDetailPartDAdHocItem> adHocCols;
	private boolean adHocReport;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAudtInsrtId() {
		return audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	public Timestamp getAudtInsrtTs() {
		return audtInsrtTs;
	}

	public void setAudtInsrtTs(Timestamp audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	public String getAudtUpdtId() {
		return audtUpdtId;
	}

	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}

	public Timestamp getAudtUpdtTs() {
		return audtUpdtTs;
	}

	public void setAudtUpdtTs(Timestamp audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}

	public String getEnrlmtSpcltyDesc1() {
		return enrlmtSpcltyDesc1;
	}

	public void setEnrlmtSpcltyDesc1(String enrlmtSpcltyDesc1) {
		this.enrlmtSpcltyDesc1 = enrlmtSpcltyDesc1;
	}

	public String getEnrlmtSpcltyDesc2() {
		return enrlmtSpcltyDesc2;
	}

	public void setEnrlmtSpcltyDesc2(String enrlmtSpcltyDesc2) {
		this.enrlmtSpcltyDesc2 = enrlmtSpcltyDesc2;
	}

	public String getEnrlmtSpcltyDesc3() {
		return enrlmtSpcltyDesc3;
	}

	public void setEnrlmtSpcltyDesc3(String enrlmtSpcltyDesc3) {
		this.enrlmtSpcltyDesc3 = enrlmtSpcltyDesc3;
	}

	public String getEnrlmtSpcltyDesc4() {
		return enrlmtSpcltyDesc4;
	}

	public void setEnrlmtSpcltyDesc4(String enrlmtSpcltyDesc4) {
		this.enrlmtSpcltyDesc4 = enrlmtSpcltyDesc4;
	}

	public String getEnrlmtSpcltyDesc5() {
		return enrlmtSpcltyDesc5;
	}

	public void setEnrlmtSpcltyDesc5(String enrlmtSpcltyDesc5) {
		this.enrlmtSpcltyDesc5 = enrlmtSpcltyDesc5;
	}

	public String getFidActv() {
		return fidActv;
	}

	public void setFidActv(String fidActv) {
		this.fidActv = fidActv;
	}

	public String getFidInactv() {
		return fidInactv;
	}

	public void setFidInactv(String fidInactv) {
		this.fidInactv = fidInactv;
	}

	public Date getFidLastPmtSuspnsnBgnDt() {
		return fidLastPmtSuspnsnBgnDt;
	}

	public void setFidLastPmtSuspnsnBgnDt(Date fidLastPmtSuspnsnBgnDt) {
		this.fidLastPmtSuspnsnBgnDt = fidLastPmtSuspnsnBgnDt;
	}

	public Date getFidLastPmtSuspnsnEndDt() {
		return fidLastPmtSuspnsnEndDt;
	}

	public void setFidLastPmtSuspnsnEndDt(Date fidLastPmtSuspnsnEndDt) {
		this.fidLastPmtSuspnsnEndDt = fidLastPmtSuspnsnEndDt;
	}

	public Integer getOpAvgMmeBene() {
		return opAvgMmeBene;
	}

	public void setOpAvgMmeBene(Integer opAvgMmeBene) {
		this.opAvgMmeBene = opAvgMmeBene;
	}

	public BigDecimal getOpAvgMmeBenePct() {
		return opAvgMmeBenePct;
	}

	public void setOpAvgMmeBenePct(BigDecimal opAvgMmeBenePct) {
		this.opAvgMmeBenePct = opAvgMmeBenePct;
	}

	public Integer getOpAvgMmeShpngBene() {
		return opAvgMmeShpngBene;
	}

	public void setOpAvgMmeShpngBene(Integer opAvgMmeShpngBene) {
		this.opAvgMmeShpngBene = opAvgMmeShpngBene;
	}

	public BigDecimal getOpAvgMmeShpngBenePct() {
		return opAvgMmeShpngBenePct;
	}

	public void setOpAvgMmeShpngBenePct(BigDecimal opAvgMmeShpngBenePct) {
		this.opAvgMmeShpngBenePct = opAvgMmeShpngBenePct;
	}

	public Integer getOpBene() {
		return opBene;
	}

	public void setOpBene(Integer opBene) {
		this.opBene = opBene;
	}

	public BigDecimal getOpBenePct() {
		return opBenePct;
	}

	public void setOpBenePct(BigDecimal opBenePct) {
		this.opBenePct = opBenePct;
	}

	public Integer getOpDailyMmeBene() {
		return opDailyMmeBene;
	}

	public void setOpDailyMmeBene(Integer opDailyMmeBene) {
		this.opDailyMmeBene = opDailyMmeBene;
	}

	public BigDecimal getOpDailyMmeBenePct() {
		return opDailyMmeBenePct;
	}

	public void setOpDailyMmeBenePct(BigDecimal opDailyMmeBenePct) {
		this.opDailyMmeBenePct = opDailyMmeBenePct;
	}

	public Integer getOpDailyMmeShpngBene() {
		return opDailyMmeShpngBene;
	}

	public void setOpDailyMmeShpngBene(Integer opDailyMmeShpngBene) {
		this.opDailyMmeShpngBene = opDailyMmeShpngBene;
	}

	public BigDecimal getOpDailyMmeShpngBenePct() {
		return opDailyMmeShpngBenePct;
	}

	public void setOpDailyMmeShpngBenePct(BigDecimal opDailyMmeShpngBenePct) {
		this.opDailyMmeShpngBenePct = opDailyMmeShpngBenePct;
	}

	public Integer getOpLines() {
		return opLines;
	}

	public void setOpLines(Integer opLines) {
		this.opLines = opLines;
	}

	public BigDecimal getOpLinesPct() {
		return opLinesPct;
	}

	public void setOpLinesPct(BigDecimal opLinesPct) {
		this.opLinesPct = opLinesPct;
	}

	public BigDecimal getOpLinesPerBene() {
		return opLinesPerBene;
	}

	public void setOpLinesPerBene(BigDecimal opLinesPerBene) {
		this.opLinesPerBene = opLinesPerBene;
	}

	public BigDecimal getOpLinesPerBenePerDay() {
		return opLinesPerBenePerDay;
	}

	public void setOpLinesPerBenePerDay(BigDecimal opLinesPerBenePerDay) {
		this.opLinesPerBenePerDay = opLinesPerBenePerDay;
	}

	public BigDecimal getOpNdcPerBene() {
		return opNdcPerBene;
	}

	public void setOpNdcPerBene(BigDecimal opNdcPerBene) {
		this.opNdcPerBene = opNdcPerBene;
	}

	public Integer getOpPhrmcyShpngBene() {
		return opPhrmcyShpngBene;
	}

	public void setOpPhrmcyShpngBene(Integer opPhrmcyShpngBene) {
		this.opPhrmcyShpngBene = opPhrmcyShpngBene;
	}

	public BigDecimal getOpPhrmcyShpngBenePct() {
		return opPhrmcyShpngBenePct;
	}

	public void setOpPhrmcyShpngBenePct(BigDecimal opPhrmcyShpngBenePct) {
		this.opPhrmcyShpngBenePct = opPhrmcyShpngBenePct;
	}

	public BigDecimal getOpPmt() {
		return opPmt;
	}

	public void setOpPmt(BigDecimal opPmt) {
		this.opPmt = opPmt;
	}

	public BigDecimal getOpPmtPct() {
		return opPmtPct;
	}

	public void setOpPmtPct(BigDecimal opPmtPct) {
		this.opPmtPct = opPmtPct;
	}

	public BigDecimal getOpPmtPerBene() {
		return opPmtPerBene;
	}

	public void setOpPmtPerBene(BigDecimal opPmtPerBene) {
		this.opPmtPerBene = opPmtPerBene;
	}

	public Integer getOpPrscrbrShpngBene() {
		return opPrscrbrShpngBene;
	}

	public void setOpPrscrbrShpngBene(Integer opPrscrbrShpngBene) {
		this.opPrscrbrShpngBene = opPrscrbrShpngBene;
	}

	public BigDecimal getOpPrscrbrShpngBenePct() {
		return opPrscrbrShpngBenePct;
	}

	public void setOpPrscrbrShpngBenePct(BigDecimal opPrscrbrShpngBenePct) {
		this.opPrscrbrShpngBenePct = opPrscrbrShpngBenePct;
	}

	public Integer getPecosEnrlmtAprvd() {
		return pecosEnrlmtAprvd;
	}

	public void setPecosEnrlmtAprvd(Integer pecosEnrlmtAprvd) {
		this.pecosEnrlmtAprvd = pecosEnrlmtAprvd;
	}

	public Integer getPecosEnrlmtDactvtd() {
		return pecosEnrlmtDactvtd;
	}

	public void setPecosEnrlmtDactvtd(Integer pecosEnrlmtDactvtd) {
		this.pecosEnrlmtDactvtd = pecosEnrlmtDactvtd;
	}

	public Integer getPecosEnrlmtMisg() {
		return pecosEnrlmtMisg;
	}

	public void setPecosEnrlmtMisg(Integer pecosEnrlmtMisg) {
		this.pecosEnrlmtMisg = pecosEnrlmtMisg;
	}

	public Integer getPecosEnrlmtOptout() {
		return pecosEnrlmtOptout;
	}

	public void setPecosEnrlmtOptout(Integer pecosEnrlmtOptout) {
		this.pecosEnrlmtOptout = pecosEnrlmtOptout;
	}

	public Integer getPecosEnrlmtOthr() {
		return pecosEnrlmtOthr;
	}

	public void setPecosEnrlmtOthr(Integer pecosEnrlmtOthr) {
		this.pecosEnrlmtOthr = pecosEnrlmtOthr;
	}

	public Integer getPecosEnrlmtRvked() {
		return pecosEnrlmtRvked;
	}

	public void setPecosEnrlmtRvked(Integer pecosEnrlmtRvked) {
		this.pecosEnrlmtRvked = pecosEnrlmtRvked;
	}

	public Integer getPecosEnrlmtTot() {
		return pecosEnrlmtTot;
	}

	public void setPecosEnrlmtTot(Integer pecosEnrlmtTot) {
		this.pecosEnrlmtTot = pecosEnrlmtTot;
	}

	public String getPrscrbrName() {
		return prscrbrName;
	}

	public void setPrscrbrName(String prscrbrName) {
		this.prscrbrName = prscrbrName;
	}

	public String getStateCd1() {
		return stateCd1;
	}

	public void setStateCd1(String stateCd1) {
		this.stateCd1 = stateCd1;
	}

	public String getStateCd10() {
		return stateCd10;
	}

	public void setStateCd10(String stateCd10) {
		this.stateCd10 = stateCd10;
	}

	public String getStateCd2() {
		return stateCd2;
	}

	public void setStateCd2(String stateCd2) {
		this.stateCd2 = stateCd2;
	}

	public String getStateCd3() {
		return stateCd3;
	}

	public void setStateCd3(String stateCd3) {
		this.stateCd3 = stateCd3;
	}

	public String getStateCd4() {
		return stateCd4;
	}

	public void setStateCd4(String stateCd4) {
		this.stateCd4 = stateCd4;
	}

	public String getStateCd5() {
		return stateCd5;
	}

	public void setStateCd5(String stateCd5) {
		this.stateCd5 = stateCd5;
	}

	public String getStateCd6() {
		return stateCd6;
	}

	public void setStateCd6(String stateCd6) {
		this.stateCd6 = stateCd6;
	}

	public String getStateCd7() {
		return stateCd7;
	}

	public void setStateCd7(String stateCd7) {
		this.stateCd7 = stateCd7;
	}

	public String getStateCd8() {
		return stateCd8;
	}

	public void setStateCd8(String stateCd8) {
		this.stateCd8 = stateCd8;
	}

	public String getStateCd9() {
		return stateCd9;
	}

	public void setStateCd9(String stateCd9) {
		this.stateCd9 = stateCd9;
	}

	public Date getStdyPrdEnd() {
		return stdyPrdEnd;
	}

	public void setStdyPrdEnd(Date stdyPrdEnd) {
		this.stdyPrdEnd = stdyPrdEnd;
	}

	public Integer getTotBene() {
		return totBene;
	}

	public void setTotBene(Integer totBene) {
		this.totBene = totBene;
	}

	public Integer getTotLines() {
		return totLines;
	}

	public void setTotLines(Integer totLines) {
		this.totLines = totLines;
	}

	public BigDecimal getTotPmt() {
		return totPmt;
	}

	public void setTotPmt(BigDecimal totPmt) {
		this.totPmt = totPmt;
	}

	public Integer getBzoBene() {
		return bzoBene;
	}

	public void setBzoBene(Integer bzoBene) {
		this.bzoBene = bzoBene;
	}

	public BigDecimal getBzoBenePct() {
		return bzoBenePct;
	}

	public void setBzoBenePct(BigDecimal bzoBenePct) {
		this.bzoBenePct = bzoBenePct;
	}

	public Integer getBzoLines() {
		return bzoLines;
	}

	public void setBzoLines(Integer bzoLines) {
		this.bzoLines = bzoLines;
	}

	public BigDecimal getBzoLinesPct() {
		return bzoLinesPct;
	}

	public void setBzoLinesPct(BigDecimal bzoLinesPct) {
		this.bzoLinesPct = bzoLinesPct;
	}

	public BigDecimal getBzoLinesPerBene() {
		return bzoLinesPerBene;
	}

	public void setBzoLinesPerBene(BigDecimal bzoLinesPerBene) {
		this.bzoLinesPerBene = bzoLinesPerBene;
	}

	public BigDecimal getBzoPmt() {
		return bzoPmt;
	}

	public void setBzoPmt(BigDecimal bzoPmt) {
		this.bzoPmt = bzoPmt;
	}

	public BigDecimal getBzoPmtPct() {
		return bzoPmtPct;
	}

	public void setBzoPmtPct(BigDecimal bzoPmtPct) {
		this.bzoPmtPct = bzoPmtPct;
	}

	public BigDecimal getBzoPmtPerBene() {
		return bzoPmtPerBene;
	}

	public void setBzoPmtPerBene(BigDecimal bzoPmtPerBene) {
		this.bzoPmtPerBene = bzoPmtPerBene;
	}

	public Integer getOpBzoCncrnt7Bene() {
		return opBzoCncrnt7Bene;
	}

	public void setOpBzoCncrnt7Bene(Integer opBzoCncrnt7Bene) {
		this.opBzoCncrnt7Bene = opBzoCncrnt7Bene;
	}

	public BigDecimal getOpBzoCncrnt7BeneMmePct() {
		return opBzoCncrnt7BeneMmePct;
	}

	public void setOpBzoCncrnt7BeneMmePct(BigDecimal opBzoCncrnt7BeneMmePct) {
		this.opBzoCncrnt7BeneMmePct = opBzoCncrnt7BeneMmePct;
	}

	public BigDecimal getOpBzoCncrnt7BenePct() {
		return opBzoCncrnt7BenePct;
	}

	public void setOpBzoCncrnt7BenePct(BigDecimal opBzoCncrnt7BenePct) {
		this.opBzoCncrnt7BenePct = opBzoCncrnt7BenePct;
	}

	public Integer getOpBzoCncrnt7MmeBene() {
		return opBzoCncrnt7MmeBene;
	}

	public void setOpBzoCncrnt7MmeBene(Integer opBzoCncrnt7MmeBene) {
		this.opBzoCncrnt7MmeBene = opBzoCncrnt7MmeBene;
	}

	public Integer getOpBzoCncrntBene() {
		return opBzoCncrntBene;
	}

	public void setOpBzoCncrntBene(Integer opBzoCncrntBene) {
		this.opBzoCncrntBene = opBzoCncrntBene;
	}

	public BigDecimal getOpBzoCncrntBenePct() {
		return opBzoCncrntBenePct;
	}

	public void setOpBzoCncrntBenePct(BigDecimal opBzoCncrntBenePct) {
		this.opBzoCncrntBenePct = opBzoCncrntBenePct;
	}

	public Integer getOpBeneErOd1Day() {
		return opBeneErOd1Day;
	}

	public void setOpBeneErOd1Day(Integer opBeneErOd1Day) {
		this.opBeneErOd1Day = opBeneErOd1Day;
	}

	public String getOpBeneErOd30AvgMme() {
		return opBeneErOd30AvgMme;
	}

	public void setOpBeneErOd30AvgMme(String opBeneErOd30AvgMme) {
		this.opBeneErOd30AvgMme = opBeneErOd30AvgMme;
	}

	public Integer getOpBeneErOd30Days() {
		return opBeneErOd30Days;
	}

	public void setOpBeneErOd30Days(Integer opBeneErOd30Days) {
		this.opBeneErOd30Days = opBeneErOd30Days;
	}

	public Integer getOpBeneErOd30Mme() {
		return opBeneErOd30Mme;
	}

	public void setOpBeneErOd30Mme(Integer opBeneErOd30Mme) {
		this.opBeneErOd30Mme = opBeneErOd30Mme;
	}

	public Integer getOpBeneErOd7Days() {
		return opBeneErOd7Days;
	}

	public void setOpBeneErOd7Days(Integer opBeneErOd7Days) {
		this.opBeneErOd7Days = opBeneErOd7Days;
	}

	public String getOpBeneTop1Pct() {
		return opBeneTop1Pct;
	}

	public void setOpBeneTop1Pct(String opBeneTop1Pct) {
		this.opBeneTop1Pct = opBeneTop1Pct;
	}

	public String getOpBeneTop10Pct() {
		return opBeneTop10Pct;
	}

	public void setOpBeneTop10Pct(String opBeneTop10Pct) {
		this.opBeneTop10Pct = opBeneTop10Pct;
	}

	public String getOpBeneTop25Pct() {
		return opBeneTop25Pct;
	}

	public void setOpBeneTop25Pct(String opBeneTop25Pct) {
		this.opBeneTop25Pct = opBeneTop25Pct;
	}

	public String getOpBeneTop5Pct() {
		return opBeneTop5Pct;
	}

	public void setOpBeneTop5Pct(String opBeneTop5Pct) {
		this.opBeneTop5Pct = opBeneTop5Pct;
	}

	public String getOpRxTop1Pct() {
		return opRxTop1Pct;
	}

	public void setOpRxTop1Pct(String opRxTop1Pct) {
		this.opRxTop1Pct = opRxTop1Pct;
	}

	public String getOpRxTop10Pct() {
		return opRxTop10Pct;
	}

	public void setOpRxTop10Pct(String opRxTop10Pct) {
		this.opRxTop10Pct = opRxTop10Pct;
	}

	public String getOpRxTop25Pct() {
		return opRxTop25Pct;
	}

	public void setOpRxTop25Pct(String opRxTop25Pct) {
		this.opRxTop25Pct = opRxTop25Pct;
	}

	public String getOpRxTop5Pct() {
		return opRxTop5Pct;
	}

	public void setOpRxTop5Pct(String opRxTop5Pct) {
		this.opRxTop5Pct = opRxTop5Pct;
	}

	public Date getStdyPrdStrt() {
		return stdyPrdStrt;
	}

	public void setStdyPrdStrt(Date stdyPrdStrt) {
		this.stdyPrdStrt = stdyPrdStrt;
	}

	public Integer getOpBeneErOd90Days() {
		return opBeneErOd90Days;
	}

	public void setOpBeneErOd90Days(Integer opBeneErOd90Days) {
		this.opBeneErOd90Days = opBeneErOd90Days;
	}

	public void setFidLastPmtSuspnsnEndDtStr(String fidLastPmtSuspnsnEndDtStr) {
		this.fidLastPmtSuspnsnEndDtStr = fidLastPmtSuspnsnEndDtStr;
	}

	public String getStdyPrdStrtStr() {
		return stdyPrdStrtStr;
	}

	public void setStdyPrdStrtStr(String stdyPrdStrtStr) {
		this.stdyPrdStrtStr = stdyPrdStrtStr;
	}

	public void setFidLastPmtSuspnsnBgnDtStr(String fidLastPmtSuspnsnBgnDtStr) {
		this.fidLastPmtSuspnsnBgnDtStr = fidLastPmtSuspnsnBgnDtStr;
	}

	public String getStdyPrdEndStr() {
		return stdyPrdEndStr;
	}

	public void setStdyPrdEndStr(String stdyPrdEndStr) {
		this.stdyPrdEndStr = stdyPrdEndStr;
	}

	public String getFidLastPmtSuspnsnBgnDtStr() {
		return fidLastPmtSuspnsnBgnDtStr;
	}

	public String getFidLastPmtSuspnsnEndDtStr() {
		return fidLastPmtSuspnsnEndDtStr;
	}

	public String getPrscrbrNpi() {
		return prscrbrNpi;
	}

	public void setPrscrbrNpi(String prscrbrNpi) {
		this.prscrbrNpi = prscrbrNpi;
	}

	public List<AsrDetailPartDAdHocItem> getAdHocCols() {
		return adHocCols;
	}

	public void setAdHocCols(List<AsrDetailPartDAdHocItem> adHocCols) {
		this.adHocCols = adHocCols;
	}

	public boolean isAdHocReport() {
		return adHocReport;
	}

	public void setAdHocReport(boolean adHocReport) {
		this.adHocReport = adHocReport;
	}

}
