package gov.hhs.cms.fps.model;

import javax.persistence.Id;

import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)

public class SolrAsrAssociation {

	@Id
	//@Field(value="id")
	private String id;
	//@Field(value="asrpt_id")
	private int asrptId;
	//@Field(value="clm_id")
	private int clmId;
	//@Field(value="clm_rvw_ind")
	private String clmRvwInd;
	//@Field(value="models")
	private String modelString;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(int asrptId) {
		this.asrptId = asrptId;
	}
	public int getClmId() {
		return clmId;
	}
	public void setClmId(int clmId) {
		this.clmId = clmId;
	}
	@Override
	public String toString() {
		return "SolrAsrAssociation [id=" + id + ", asrptId=" + asrptId + ", clmId=" + clmId + ", clmRvwInd=" + clmRvwInd
				+ ", modelString=" + modelString + "]";
	}
	public String getClmRvwInd() {
		return clmRvwInd;
	}
	public void setClmRvwInd(String clmRvwInd) {
		this.clmRvwInd = clmRvwInd;
	}
	public String getModelString() {
		return modelString;
	}
	public void setModelString(String modelString) {
		this.modelString = modelString;
	}
}
