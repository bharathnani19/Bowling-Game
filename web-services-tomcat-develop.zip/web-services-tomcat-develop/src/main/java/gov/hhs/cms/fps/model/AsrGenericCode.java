package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)

public class AsrGenericCode implements Serializable,Comparable<AsrGenericCode> {

	private String code;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public AsrGenericCode(){
		
	}
	public AsrGenericCode(String code){
		this.code = code;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AsrGenericCode other = (AsrGenericCode) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AsrGenericCode [code=" + code + "]";
	}
	
	public static AsrGenericCode noneCode(){
		AsrGenericCode noneCode = new AsrGenericCode();
		noneCode.setCode("None");
		return noneCode;
	}
	@Override
	public int compareTo(AsrGenericCode target) {
		
		return this.getCode().compareTo(target.getCode());
	}
	public String toSearchString() {
		return "[code=" + code + "]";

	}
}
