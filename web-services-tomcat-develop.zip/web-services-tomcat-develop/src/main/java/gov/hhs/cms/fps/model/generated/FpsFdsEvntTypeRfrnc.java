package gov.hhs.cms.fps.model.generated;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="FPS_FDS_EVNT_TYPE_RFRNC")
public class FpsFdsEvntTypeRfrnc implements Serializable{

	private String evntTypeCd;
	private String evntTypeDesc;
	private String objTypeCd;
	
	
	@Id
	@Column(name="EVNT_TYPE_CD")
	public String getEvntTypeCd() {
		return evntTypeCd;
	}
	public void setEvntTypeCd(String evntTypeCd) {
		this.evntTypeCd = evntTypeCd;
	}
	@Column(name="EVNT_TYPE_DESC")
	public String getEvntTypeDesc() {
		return evntTypeDesc;
	}
	public void setEvntTypeDesc(String evntTypeDesc) {
		this.evntTypeDesc = evntTypeDesc;
	}
	@Column(name="OBJ_TYPE_CD")
//	@Transient
	public String getObjTypeCd() {
		return objTypeCd;
	}
	public void setObjTypeCd(String objTypeCd) {
		this.objTypeCd = objTypeCd;
	}

}
