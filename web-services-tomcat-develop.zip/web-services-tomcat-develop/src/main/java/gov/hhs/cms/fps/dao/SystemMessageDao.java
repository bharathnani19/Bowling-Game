/*
 * 
 */
package gov.hhs.cms.fps.dao;

import java.util.List;

import gov.hhs.cms.fps.model.generated.FpsSysMsg;

public interface SystemMessageDao {
	public List<FpsSysMsg> loadSystemMessages();
	/**
	 * Adds the update system message.
	 *
	 * @param message the message
	 */
	public FpsSysMsg addUpdateSystemMessage(FpsSysMsg message);
	public void deleteSystemMessage(int sysMsgId);
	
	

}
