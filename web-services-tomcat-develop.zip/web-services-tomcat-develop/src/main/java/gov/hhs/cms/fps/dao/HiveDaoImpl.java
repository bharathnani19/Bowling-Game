package gov.hhs.cms.fps.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import gov.hhs.cms.fps.model.AsrDetailClaimLineItem;
import gov.hhs.cms.fps.util.AsrClaimsRowMapper;
@Repository("hiveDao")
public class HiveDaoImpl implements HiveDao {
//	@Autowired
//	private JdbcTemplate hiveJdbcTemplate;

	@Override
	public List<AsrDetailClaimLineItem> test() {
//		List<AsrDetailClaimLineItem> l = hiveJdbcTemplate.query("select * from z_solr_poc.flat_tom LIMIT 5",
//				new AsrClaimsRowMapper());
//		return l;
//		
		return null;
	}
}
