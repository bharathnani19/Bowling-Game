package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailModel implements Serializable {
	private String modelName;
	private String modelLongName;
	private String modelStatus;
	private String claimType;
	private String implDt;
	private String updateDt;
	private String modelDesc;
	private Integer modelId;
	private String type;
	private String version;
	private String ownerName;
	private String ownerEmail;
	private String ownerPhone;
	private String fpsVersion;
	private String loggedInUserId;
	private String activeStatus;
	private String lastUpdateUser;
	private String docFile;
	private String lookback = "TBD";
	private List<AsrDetailClaimLineItem> claimLines;
	private List<AsrDetailAlert> alerts;
	private List<AsrDetailReportCard> reportCards;
	private String priorityInd;
	private String lastProcessedTime;
	private String statusDt;
	private String priorityDt;
	private String statusChangedBy;
	private String partDClaimInd;
	private String lookbackDates;
	private String cadence;
	private String pathToEduInd;
	private String p1Ind;
	
	public String getModelName() {
		return this.modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getImplDt() {
		return this.implDt;
	}

	public void setImplDt(String implDt) {
		this.implDt = implDt;
	}

	public String getUpdateDt() {
		return this.updateDt;
	}

	public void setUpdateDt(String updateDt) {
		this.updateDt = updateDt;
	}

	public String getModelDesc() {
		return this.modelDesc;
	}

	public void setModelDesc(String modelDesc) {
		this.modelDesc = modelDesc;
	}

	public List<AsrDetailClaimLineItem> getClaimLines() {
		return this.claimLines;
	}

	public void setClaimLines(List<AsrDetailClaimLineItem> claimLines) {
		this.claimLines = claimLines;
	}

	public List<AsrDetailAlert> getAlerts() {
		return this.alerts;
	}

	public void setAlerts(List<AsrDetailAlert> alerts) {
		this.alerts = alerts;
	}

	public List<AsrDetailReportCard> getReportCards() {
		return this.reportCards;
	}

	public void setReportCards(List<AsrDetailReportCard> reportCards) {
		this.reportCards = reportCards;
	}

	public Integer getModelId() {
		return this.modelId;
	}

	public void setModelId(Integer modelId) {
		this.modelId = modelId;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getVersion() {
		return this.version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getOwnerName() {
		return this.ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getOwnerEmail() {
		return this.ownerEmail;
	}

	public void setOwnerEmail(String ownerEmail) {
		this.ownerEmail = ownerEmail;
	}

	public String getOwnerPhone() {
		return this.ownerPhone;
	}

	public void setOwnerPhone(String ownerPhone) {
		this.ownerPhone = ownerPhone;
	}

	public String getFpsVersion() {
		return this.fpsVersion;
	}

	public void setFpsVersion(String fpsVersion) {
		this.fpsVersion = fpsVersion;
	}

	public String toString() {
		return "AsrDetailModel [modelName=" + this.modelName + ", modelId=" + this.modelId + "]";
	}

	public String getModelLongName() {
		return this.modelLongName;
	}

	public void setModelLongName(String modelLongName) {
		this.modelLongName = modelLongName;
	}

	public String getModelStatus() {
		return this.modelStatus;
	}

	public void setModelStatus(String modelStatus) {
		this.modelStatus = modelStatus;
	}

	public String getClaimType() {
		return this.claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getLoggedInUserId() {
		return this.loggedInUserId;
	}

	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}

	public String getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(String activeStatus) {
		this.activeStatus = activeStatus;
	}

	public String getLastUpdateUser() {
		return lastUpdateUser;
	}

	public void setLastUpdateUser(String lastUpdateUser) {
		this.lastUpdateUser = lastUpdateUser;
	}

	public String getDocFile() {
		return docFile;
	}

	public void setDocFile(String docFile) {
		this.docFile = docFile;
	}

	public String getLookback() {
		return lookback;
	}

	public void setLookback(String lookback) {
		this.lookback = lookback;
	}

	public String getPriorityInd() {
		return priorityInd;
	}

	public void setPriorityInd(String priorityInd) {
		this.priorityInd = priorityInd;
	}

	public String getLastProcessedTime() {
		return lastProcessedTime;
	}

	public void setLastProcessedTime(String lastProcessedTime) {
		this.lastProcessedTime = lastProcessedTime;
	}

	public String getStatusDt() {
		return statusDt;
	}

	public void setStatusDt(String statusDt) {
		this.statusDt = statusDt;
	}

	public String getPriorityDt() {
		return priorityDt;
	}

	public void setPriorityDt(String priorityDt) {
		this.priorityDt = priorityDt;
	}

	public String getStatusChangedBy() {
		return statusChangedBy;
	}

	public void setStatusChangedBy(String statusChangedBy) {
		this.statusChangedBy = statusChangedBy;
	}

	public String getPartDClaimInd() {
		return partDClaimInd;
	}

	public void setPartDClaimInd(String partDClaimInd) {
		this.partDClaimInd = partDClaimInd;
	}

	public String getLookbackDates() {
		return lookbackDates;
	}

	public void setLookbackDates(String lookbackDates) {
		this.lookbackDates = lookbackDates;
	}

	public String getCadence() {
		return cadence;
	}

	public void setCadence(String cadence) {
		this.cadence = cadence;
	}
	public String getPathToEduInd() {
		return pathToEduInd;
	}

	public void setPathToEduInd(String pathToEduInd) {
		this.pathToEduInd = pathToEduInd;
	}

	public String getP1Ind() {
		return p1Ind;
	}

	public void setP1Ind(String p1Ind) {
		this.p1Ind = p1Ind;
	}

	
}
