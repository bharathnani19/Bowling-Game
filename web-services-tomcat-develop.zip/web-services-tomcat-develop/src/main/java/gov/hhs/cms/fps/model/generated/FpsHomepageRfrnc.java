package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
@Table(name="fps_homepage_rfrnc", schema="fps2")
public class FpsHomepageRfrnc implements Serializable {
	private String homepageCd;
	private String homepageIconUrlNm;
	private String homepageUrlTxt;
	private String homepageUrlNm;
	private String homepageUrlDesc;
	private Integer homepageSqncNum;
	private String homepageEnvCd;
	private String newTabInd;
	private String actvInd;
	private Set<FpsHomepageRoleRfrnc> fpsHomepageRoleRfrncs;
	
	@Id()
	@Column(name="homepage_cd")
	public String getHomepageCd() {
		return homepageCd;
	}
	public void setHomepageCd(String homepageCd) {
		this.homepageCd = homepageCd;
	}
	@Column(name="homepage_icon_url_nm")
	public String getHomepageIconUrlNm() {
		return homepageIconUrlNm;
	}
	public void setHomepageIconUrlNm(String homepageIconUrlNm) {
		this.homepageIconUrlNm = homepageIconUrlNm;
	}
	@Column(name="homepage_url_txt")
	public String getHomepageUrlTxt() {
		return homepageUrlTxt;
	}
	public void setHomepageUrlTxt(String homepageUrlTxt) {
		this.homepageUrlTxt = homepageUrlTxt;
	}
	@Column(name="homepage_url_nm")
	public String getHomepageUrlNm() {
		return homepageUrlNm;
	}
	public void setHomepageUrlNm(String homepageUrlNm) {
		this.homepageUrlNm = homepageUrlNm;
	}
	@OneToMany(cascade={CascadeType.PERSIST, CascadeType.MERGE}, fetch=FetchType.LAZY, mappedBy="fpsHomepageRfrnc", orphanRemoval = true)
	@BatchSize(size = 1000)
	@NotFound(action = NotFoundAction.IGNORE)
	public Set<FpsHomepageRoleRfrnc> getFpsHomepageRoleRfrncs() {
		return fpsHomepageRoleRfrncs;
	}
	public void setFpsHomepageRoleRfrncs(Set<FpsHomepageRoleRfrnc> fpsHomepageRoleRfrncs) {
		this.fpsHomepageRoleRfrncs = fpsHomepageRoleRfrncs;
	}
	@Column(name="homepage_sqnc_num")
	public Integer getHomepageSqncNum() {
		return homepageSqncNum;
	}
	public void setHomepageSqncNum(Integer homepageSqncNum) {
		this.homepageSqncNum = homepageSqncNum;
	}
	@Column(name="homepage_url_desc")

	public String getHomepageUrlDesc() {
		return homepageUrlDesc;
	}
	public void setHomepageUrlDesc(String homepageUrlDesc) {
		this.homepageUrlDesc = homepageUrlDesc;
	}
	@Column(name="homepage_env_cd")

	public String getHomepageEnvCd() {
		return homepageEnvCd;
	}
	public void setHomepageEnvCd(String homepageEnvCd) {
		this.homepageEnvCd = homepageEnvCd;
	}
	@Column(name="actv_ind")
	public String getActvInd() {
		return actvInd;
	}
	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}
	@Column(name="new_tab_ind")
	public String getNewTabInd() {
		return newTabInd;
	}
	public void setNewTabInd(String newTabInd) {
		this.newTabInd = newTabInd;
	}

}
