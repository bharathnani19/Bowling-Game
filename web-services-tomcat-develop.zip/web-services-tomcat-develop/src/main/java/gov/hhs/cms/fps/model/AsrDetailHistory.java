/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.text.ParseException;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import org.joda.time.DateTimeComparator;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import gov.hhs.cms.fps.util.FpsDomainObjectConverter;
// TODO: Auto-generated Javadoc
/**
 * The Class AsrDetailHistory.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailHistory  implements Serializable, Comparable<AsrDetailHistory>{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8791391555712979065L;
	
	private String userName;
	private String recordedDt;
	private String eventDt;
	private String legacyPriority;
	private Double riskScore;
	private String description;
	private String comments;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getRecordedDt() {
		return recordedDt;
	}
	public void setRecordedDt(String recordedDt) {
		this.recordedDt = recordedDt;
	}
	public String getEventDt() {
		return eventDt;
	}
	public void setEventDt(String eventDt) {
		this.eventDt = eventDt;
	}
	public String getLegacyPriority() {
		return legacyPriority;
	}
	public void setLegacyPriority(String legacyPriority) {
		this.legacyPriority = legacyPriority;
	}
	public Double getRiskScore() {
		return riskScore;
	}
	public void setRiskScore(Double riskScore) {
		this.riskScore = riskScore;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	@Override
	public int compareTo(AsrDetailHistory o) {
		DateTimeComparator d = DateTimeComparator.getInstance();
		Date d1 = null;
		Date d2 = null;
		try {
			d1 = FpsDomainObjectConverter.convertStringToLocalDate(o.getEventDt());
			d2 = FpsDomainObjectConverter.convertStringToLocalDate(this.getEventDt());

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return  d.compare(d1,  d2);
	}

}
