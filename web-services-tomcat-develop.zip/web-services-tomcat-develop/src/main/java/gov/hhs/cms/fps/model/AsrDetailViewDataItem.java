/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

// TODO: Auto-generated Javadoc
/**
 * The Class AsrDetailViewDataItem.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailViewDataItem implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4814390378459093207L;
	
	/** The tab label. */
	private String tabLabel;
	
	/** The layout direction. */
	private String layoutDirection;
	
	/** The columns. */
	private List<AsrDetailViewColumn> columns = new ArrayList<AsrDetailViewColumn>();;
	
	/** The data. */
	private List<Object> data = new ArrayList<Object>();
	//private List<AsrDetailViewColumnData> data;
	
	/**
	 * Gets the columns.
	 *
	 * @return the columns
	 */
	public List<AsrDetailViewColumn> getColumns() {
		return columns;
	}
	
	/**
	 * Sets the columns.
	 *
	 * @param columns the new columns
	 */
	public void setColumns(List<AsrDetailViewColumn> columns) {
		this.columns = columns;
	}
//	public List<AsrDetailViewColumnData> getData() {
//		return data;
//	}
//	public void setData(List<AsrDetailViewColumnData> data) {
//		this.data = data;
/**
 * Gets the tab label.
 *
 * @return the tab label
 */
//	}
	public String getTabLabel() {
		return tabLabel;
	}
	
	/**
	 * Sets the tab label.
	 *
	 * @param tabLabel the new tab label
	 */
	public void setTabLabel(String tabLabel) {
		this.tabLabel = tabLabel;
	}
	
	/**
	 * Gets the layout direction.
	 *
	 * @return the layout direction
	 */
	public String getLayoutDirection() {
		return layoutDirection;
	}
	
	/**
	 * Sets the layout direction.
	 *
	 * @param layoutDirection the new layout direction
	 */
	public void setLayoutDirection(String layoutDirection) {
		this.layoutDirection = layoutDirection;
	}
	
	/**
	 * Adds the data.
	 *
	 * @param key the key
	 * @param value the value
	 */
	public void addData(Object value){
		
		data.add(value);
	}
	
	/**
	 * Adds the column.
	 *
	 * @param field the field
	 * @param name the name
	 */
	public void addColumn(String field, String name){
		AsrDetailViewColumn col = new AsrDetailViewColumn();
		col.setField(field);
		col.setName(name);
		if (!columns.contains(col)){
			columns.add(col);
		}
	}
	public void addColumn(String field, String name, boolean isDrilldown){
		AsrDetailViewColumn col = new AsrDetailViewColumn();
		col.setField(field);
		col.setName(name);
		if (isDrilldown){
			col.setType("drilldown");
		}
		if (!columns.contains(col)){
			columns.add(col);
		}
	}
	public void updateColumn(String field, String name, boolean isDrilldown){
		int idx = -1;
		int index = -1;
		for (int i = 0;i < columns.size() ;i++){
			if (columns.get(i).getField().equals(field)){
				columns.get(i).setType(isDrilldown?"drilldown":null);
				break;
			}
		}
	
	}
	/**
	 * Gets the data.
	 *
	 * @return the data
	 */
	public List<Object> getData() {
		return data;
	}
	
	/**
	 * Sets the data.
	 *
	 * @param data the data
	 */
	public void setData(List<Object> data) {
		this.data = data;
	}

}
