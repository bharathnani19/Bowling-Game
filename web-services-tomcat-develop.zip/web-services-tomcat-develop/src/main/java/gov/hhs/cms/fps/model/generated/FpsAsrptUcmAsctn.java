package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.BatchSize;

@Entity
@Table(name = "FPS_ASRPT_UCM_ASCTN")
@BatchSize(size = 100)
public class FpsAsrptUcmAsctn implements Serializable {
	private int asrptUcmAsctnId;
	private String ucmAsrId;
	private String audtInsrtId;
	private Date audtInsrtTs;

	private FpsAsrpt fpsAsrpt;
	private int asrptId;

	public FpsAsrptUcmAsctn() {
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ASRPT_UCM_ASCTN_ID", unique = true, nullable = false)
	public int getAsrptUcmAsctnId() {
		return this.asrptUcmAsctnId;
	}

	public void setAsrptUcmAsctnId(int asrptUcmAsctnId) {
		this.asrptUcmAsctnId = asrptUcmAsctnId;
	}

	@Column(name = "AUDT_INSRT_ID", nullable = false, length = 128)
	public String getAudtInsrtId() {
		return this.audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_INSRT_TS", nullable = false, length = 26)
	public Date getAudtInsrtTs() {
		return this.audtInsrtTs;
	}

	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_ID", updatable = false, insertable = false)
	public FpsAsrpt getFpsAsrpt() {
		return this.fpsAsrpt;
	}

	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
		this.fpsAsrpt = fpsAsrpt;
	}

	@Column(name = "ASRPT_ID")
	public int getAsrptId() {
		return this.asrptId;
	}

	public void setAsrptId(int asrptId) {
		this.asrptId = asrptId;
	}
	@Column(name = "UCM_ASR_ID")
	public String getUcmAsrId() {
		return ucmAsrId;
	}

	public void setUcmAsrId(String ucmAsrId) {
		this.ucmAsrId = ucmAsrId;
	}
}
