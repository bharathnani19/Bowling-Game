package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;

@Entity
@Table(name="FPS_ASRPT_CRNT_PRIORITY_SCRE_VW")
@BatchSize(size=1000)

public class FpsAsrptPrrtyScreTotalScreVw implements Serializable {

	private int asrptId;
	private BigDecimal score;
	
	private FpsAsrpt fpsAsrpt;
	
	@Id
	@Column(name="ASRPT_ID")
	public int getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(int asrptId) {
		this.asrptId = asrptId;
	}
	
	@Column(name="PRIORITY_SCRE")
	public BigDecimal getScore() {
		return score;
	}
	public void setScore(BigDecimal score) {
		this.score = score;
	}
	
	@ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="ASRPT_ID", referencedColumnName="ASRPT_ID", updatable=false, insertable=false)
	
	public FpsAsrpt getFpsAsrpt() {
		return fpsAsrpt;
	}
	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
		this.fpsAsrpt = fpsAsrpt;
	}
	
	
}
