package gov.hhs.cms.fps.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

@Component
public class JsonDateSerializer extends StdSerializer<Date> {

	public JsonDateSerializer() {
		super(Date.class);
	}
	protected JsonDateSerializer(Class<Date> t) {
		super(t);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void serialize(Date date, JsonGenerator gen, SerializerProvider provider)
			throws IOException, JsonProcessingException {
		if (date != null) {
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			String formattedDate = dateFormat.format(date);
			gen.writeString(formattedDate);
		} else {
			gen.writeString("N/A");
		}
	}
}
