package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name="FPS_ASRPT_BENE_RRB_VW")
public class FpsAsrptBeneRrbVw implements Serializable {
	
	private int asrptId;
	private String beneRrbNum;
	private FpsAsrpt fpsAsrpt;
	private FpsPrvdrAnlys fpsPrvdrAnlys;
	@Id
	@Column(name="ASRPT_ID")
	public int getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(int asrptId) {
		this.asrptId = asrptId;
	}
	@Id
	@Column(name="BENE_RRB_NUM")
	public String getBeneRrbNum() {
		return beneRrbNum;
	}
	public void setBeneRrbNum(String beneRrbNum) {
		this.beneRrbNum = beneRrbNum;
	}
	@ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="ASRPT_ID", referencedColumnName="ASRPT_ID", updatable=false, insertable=false)
	
	public FpsAsrpt getFpsAsrpt() {
		return fpsAsrpt;
	}
	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
		this.fpsAsrpt = fpsAsrpt;
	}
	@ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="ASRPT_ID", referencedColumnName="ASRPT_ID", updatable=false, insertable=false)

	public FpsPrvdrAnlys getFpsPrvdrAnlys() {
		return fpsPrvdrAnlys;
	}
	public void setFpsPrvdrAnlys(FpsPrvdrAnlys fpsPrvdrAnlys) {
		this.fpsPrvdrAnlys = fpsPrvdrAnlys;
	}

}
