package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name="FPS_ASRPT_MAC_ASCTN_VW")
public class FpsAsrptMacAsctn implements Serializable {

	
	private int asrptId;
	
	
	private String macJurisdiction;
	
	private FpsAsrpt fpsAsrpt;
	@Id
	@Column(name="ASRPT_ID")
	public int getAsrptId() {
		return asrptId;
	}

	public void setAsrptId(int asrptId) {
		this.asrptId = asrptId;
	}
	@Id
	@Column(name="MAC_JURISDICTION")
	public String getMacJurisdiction() {
		return macJurisdiction;
	}

	public void setMacJurisdiction(String macJurisdiction) {
		this.macJurisdiction = macJurisdiction;
	}
	@ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="ASRPT_ID", referencedColumnName="ASRPT_ID", updatable=false, insertable=false)
	public FpsAsrpt getFpsAsrpt() {
		return fpsAsrpt;
	}
	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
		this.fpsAsrpt = fpsAsrpt;
	}
}
