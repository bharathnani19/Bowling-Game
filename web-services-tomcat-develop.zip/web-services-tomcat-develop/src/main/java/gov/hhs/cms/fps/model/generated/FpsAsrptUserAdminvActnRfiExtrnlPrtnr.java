package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="FPS_ASRPT_USER_ADMINV_ACTN_RFI_EXTRNL_PRTNR")
public class FpsAsrptUserAdminvActnRfiExtrnlPrtnr implements Serializable {
	private Integer asrptUserAdminvActnRfiExtrnlPrtnrId;
	private FpsAsrptUserAdminvActnRfiDtl fpsAsrptUserAdminvActnRfiDtl;
	private String extrnlPrtnrType;
	private String cntctPrpse;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private String audtUpdtId;
	private Date audtUpdtTs;
	private String recChgInd;
	
	@Id
	@SequenceGenerator(name="asrpt_user_adminv_actn_rfi_extrnl_prtnr_id_seq",  sequenceName = "asrpt_user_adminv_actn_rfi_extrnl_prtnr_id_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "asrpt_user_adminv_actn_rfi_extrnl_prtnr_id_seq")	
	@Column(name="ASRPT_USER_ADMINV_ACTN_RFI_EXTRNL_PRTNR_ID")
	public Integer getAsrptUserAdminvActnRfiExtrnlPrtnrId() {
		return asrptUserAdminvActnRfiExtrnlPrtnrId;
	}
	public void setAsrptUserAdminvActnRfiExtrnlPrtnrId(Integer asrptUserAdminvActnRfiExtrnlPrtnrId) {
		this.asrptUserAdminvActnRfiExtrnlPrtnrId = asrptUserAdminvActnRfiExtrnlPrtnrId;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_USER_ADMINV_ACTN_RFI_DTL_ID")
	public FpsAsrptUserAdminvActnRfiDtl getFpsAsrptUserAdminvActnRfiDtl() {
		return fpsAsrptUserAdminvActnRfiDtl;
	}
	public void setFpsAsrptUserAdminvActnRfiDtl(FpsAsrptUserAdminvActnRfiDtl fpsAsrptUserAdminvActnRfiDtl) {
		this.fpsAsrptUserAdminvActnRfiDtl = fpsAsrptUserAdminvActnRfiDtl;
	}
	@Column(name="EXTRNL_PRTNR_TYPE")
	public String getExtrnlPrtnrType() {
		return extrnlPrtnrType;
	}
	public void setExtrnlPrtnrType(String extrnlPrtnrType) {
		this.extrnlPrtnrType = extrnlPrtnrType;
	}
	@Column(name="CNTCT_PRPSE")
	public String getCntctPrpse() {
		return cntctPrpse;
	}
	public void setCntctPrpse(String cntctPrpse) {
		this.cntctPrpse = cntctPrpse;
	}
	@Column(name="AUDT_INSRT_ID")
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	@Column(name="AUDT_INSRT_TS")
	public Date getAudtInsrtTs() {
		return audtInsrtTs;
	}
	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	@Column(name="AUDT_UPDT_ID	")
	public String getAudtUpdtId() {
		return audtUpdtId;
	}
	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	@Column(name="AUDT_UPDT_TS	")
	public Date getAudtUpdtTs() {
		return audtUpdtTs;
	}
	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
	@Column(name="REC_CHG_IND	")
	public String getRecChgInd() {
		return recChgInd;
	}
	public void setRecChgInd(String recChgInd) {
		this.recChgInd = recChgInd;
	}

}
