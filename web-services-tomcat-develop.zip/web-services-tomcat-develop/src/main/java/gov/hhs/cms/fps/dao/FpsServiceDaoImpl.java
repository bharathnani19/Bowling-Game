package gov.hhs.cms.fps.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Junction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.engine.jdbc.internal.BasicFormatterImpl;
import org.hibernate.sql.JoinType;
import org.hibernate.type.BigDecimalType;
import org.hibernate.type.Type;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Sets;

import gov.hhs.cms.fps.model.AsrAction;
import gov.hhs.cms.fps.model.AsrActivity;
import gov.hhs.cms.fps.model.AsrAlertStatus;
import gov.hhs.cms.fps.model.AsrAlertType;
import gov.hhs.cms.fps.model.AsrDeleteLead;
import gov.hhs.cms.fps.model.AsrGenericCode;
import gov.hhs.cms.fps.model.AsrInvestigation;
import gov.hhs.cms.fps.model.AsrRuling;
import gov.hhs.cms.fps.model.AsrSearchParameter;
import gov.hhs.cms.fps.model.AsrState;
import gov.hhs.cms.fps.model.AsrSummaryBarrier;
import gov.hhs.cms.fps.model.AsrSummaryClaimType;
import gov.hhs.cms.fps.model.AsrSummaryRollupCounts;
import gov.hhs.cms.fps.model.AsrSysTagItem;
import gov.hhs.cms.fps.model.BaseRequest;
import gov.hhs.cms.fps.model.FpsGenericKeyValue;
import gov.hhs.cms.fps.model.FpsUser;
import gov.hhs.cms.fps.model.LdapQuery;
import gov.hhs.cms.fps.model.generated.FpsAlert;
import gov.hhs.cms.fps.model.generated.FpsAsrpt;
import gov.hhs.cms.fps.model.generated.FpsAsrptAlertAsctn;
import gov.hhs.cms.fps.model.generated.FpsAsrptAlertAsctnMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptApsVw;
import gov.hhs.cms.fps.model.generated.FpsAsrptBeneRrbVw;
import gov.hhs.cms.fps.model.generated.FpsAsrptEditSmryVw;
import gov.hhs.cms.fps.model.generated.FpsAsrptEnrlmtAsctnVw;
import gov.hhs.cms.fps.model.generated.FpsAsrptInvstgnStusSmryVw;
import gov.hhs.cms.fps.model.generated.FpsAsrptInvstgtn;
import gov.hhs.cms.fps.model.generated.FpsAsrptListUserJrsdctnDtlVw;
import gov.hhs.cms.fps.model.generated.FpsAsrptLog;
import gov.hhs.cms.fps.model.generated.FpsAsrptLogMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptPrrty;
import gov.hhs.cms.fps.model.generated.FpsAsrptPrrtyMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptPrrtyScreDtlVw;
import gov.hhs.cms.fps.model.generated.FpsAsrptSrcTypeVw;
import gov.hhs.cms.fps.model.generated.FpsAsrptStatMatVw;
import gov.hhs.cms.fps.model.generated.FpsAsrptSummaryAlertsMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptSummaryAsrsMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptSummaryBillingPrvdrsMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptSummaryJurisdictionFilterMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptSummaryRltdPrvdrsMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptSummaryServiceCategoryFilterMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptSummaryServiceSubcategoryFilterMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptSummaryServiceTypeFilterMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptSummarySpecialtiesMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptSummaryStateFilterMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptUser;
import gov.hhs.cms.fps.model.generated.FpsAsrptUserActvty;
import gov.hhs.cms.fps.model.generated.FpsAsrptUserAdminvActn;
import gov.hhs.cms.fps.model.generated.FpsAsrptUserInvstgtn;
import gov.hhs.cms.fps.model.generated.FpsAsrptWithPathToEdu;
import gov.hhs.cms.fps.model.generated.FpsAsrptZoneCostCntVw;
import gov.hhs.cms.fps.model.generated.FpsFdFrdCase;
import gov.hhs.cms.fps.model.generated.FpsMdcdExclusionSearch;
import gov.hhs.cms.fps.model.generated.FpsModel;
import gov.hhs.cms.fps.model.generated.FpsModelMdcd;
import gov.hhs.cms.fps.model.generated.FpsPrvdrAnlys;
import gov.hhs.cms.fps.model.generated.FpsPrvdrAnlysExclusionSearch;
import gov.hhs.cms.fps.model.generated.FpsPrvdrAnlysJurisdiction;
import gov.hhs.cms.fps.model.generated.FpsPrvdrAnlysMdcdJurisdiction;
import gov.hhs.cms.fps.model.generated.FpsPrvdrPrflBlngPrvdr;
import gov.hhs.cms.fps.model.generated.FpsPrvdrPrflDtl;
import gov.hhs.cms.fps.model.generated.FpsRevokedAsrVw;
import gov.hhs.cms.fps.model.generated.FpsUsrGuiPrfrnc;
import gov.hhs.cms.fps.model.generated.VwFpsAsrptIdXwalkSmry;
import gov.hhs.cms.fps.model.generated.VwFpsAsrptListUserJrsdctnDtlVwMdcd;
import gov.hhs.cms.fps.model.generated.VwFpsAsrptSysTag;
import gov.hhs.cms.fps.model.generated.VwFpsPtdAsrSummary;
import gov.hhs.cms.fps.model.okta.OktaGroup;
import gov.hhs.cms.fps.util.FpsDomainObjectConverter;
import gov.hhs.cms.fps.util.FpsEnums;
import gov.hhs.cms.fps.util.FpsEnums.AsrSearchCriteria;
import gov.hhs.cms.fps.util.FpsEnums.ClaimTypeDbEnum;
import gov.hhs.cms.fps.util.FpsEnums.PreSetSearch;
import gov.hhs.cms.fps.util.FpsEnums.UpicMappingEnum;
import gov.hhs.cms.fps.util.LdapUtil;
import gov.hhs.cms.fps.util.NativeSQLOrder;

@Repository("fpsServiceDao")
@PropertySource({ "classpath:application.properties" })
public class FpsServiceDaoImpl extends BaseDao<Integer, FpsAsrpt> implements FpsServiceDao {
	@Autowired
	private Environment env;
	private static Logger logger = Logger.getLogger(FpsServiceDaoImpl.class.getName());

	@Autowired
	private FpsTrackingDao fpsTrackingDao;
	
	@Value("${p1.enabled:false}")
	private String p1EnabledInd;

	@Transactional
	public void getTest() {
	}

	@Override
	@Transactional
	public List<FpsAsrpt> searchAsrCases(BaseRequest request) {
		Criteria baseCriteria = getCurrentSession().createCriteria(FpsAsrpt.class, "report");
		// DetachedCriteria baseCriteria =
		// DetachedCriteria.forClass(FpsAsrpt.class, "report");

		// baseCriteria.createAlias("report.fpsPrvdrZnAsctn", "prvdrZnLookup",
		// JoinType.INNER_JOIN);
		baseCriteria.setMaxResults(1000);

		baseCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		ProjectionList projections = Projections.projectionList();
		baseCriteria.setProjection(projections.add(Projections.distinct(Projections.id())));

		buildCriteria(baseCriteria, request, false);
		if ((request.getParameters() instanceof AsrSearchParameter)) {
			buildCriteriaOrderBy(baseCriteria, (AsrSearchParameter) request.getParameters(), projections);
		} else if (projections != null) {
			baseCriteria.setProjection(projections.add(Projections.property("subjCntrctrName")));
		}

		List<Object[]> baseIds = null;
		try {
			baseIds = baseCriteria.list();
		} catch (HibernateException e) {
			if ((request.getParameters() instanceof AsrSearchParameter)) {
				logger.warning(
						"error for search criteria " + ((AsrSearchParameter) request.getParameters()).toString());
			}
			throw e;
		}
		if ((baseIds == null) || (baseIds.size() == 0)) {
			return new ArrayList<FpsAsrpt>();
		}
		Criteria c = getCurrentSession().createCriteria(FpsAsrpt.class, "report").setFetchMode("report",
				FetchMode.JOIN);

		c.setCacheable(true);
		c.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		List<Object> asrIds = new ArrayList<Object>();
		for (Object[] o : baseIds) {
			asrIds.add(o[0]);
		}
		((AsrSearchParameter) request.getParameters()).setAsrptIds(asrIds);
		if ((request.getParameters() instanceof AsrSearchParameter)) {
			buildCriteriaOrderBy(c, (AsrSearchParameter) request.getParameters(), null);
		}
		c.add(Restrictions.in("report.asrptId", asrIds));

		List<FpsAsrpt> results = c.list();
		logger.fine("returning " + results.size() + " ASR Summary results");
		return results;
	}

	@Override
	@Transactional
	public int searchAsrCasesCount(BaseRequest request) {
		Criteria baseCriteria = getCurrentSession().createCriteria(FpsAsrpt.class, "report");
		// DetachedCriteria baseCriteria =
		// DetachedCriteria.forClass(FpsAsrpt.class, "report");

		// baseCriteria.createAlias("report.fpsPrvdrZnAsctn", "prvdrZnLookup",
		// JoinType.INNER_JOIN);
		// baseCriteria.setMaxResults(1000);

		baseCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		ProjectionList projections = Projections.projectionList();
		baseCriteria.setProjection(projections.add(Projections.distinct(Projections.id())));
		List<?> params = buildCriteria(baseCriteria, request, false);
		if ((request.getParameters() instanceof AsrSearchParameter)) {
			buildCriteriaOrderBy(baseCriteria, (AsrSearchParameter) request.getParameters(), projections);
		} else if (projections != null) {
			baseCriteria.setProjection(projections.add(Projections.property("subjCntrctrName")));
		}
		return baseCriteria.list().size();
	}

	@Override
	@Transactional
	public List<FpsAsrpt> searchAsrCases3(BaseRequest request, int maxResults, int startAt) {
		Criteria baseCriteria = getCurrentSession().createCriteria(FpsAsrpt.class, "report");
		// DetachedCriteria baseCriteria =
		// DetachedCriteria.forClass(FpsAsrpt.class, "report");

		// baseCriteria.createAlias("report.fpsPrvdrZnAsctn", "prvdrZnLookup",
		// JoinType.INNER_JOIN);
		baseCriteria.setMaxResults(maxResults);
		if (startAt > -1) {
			baseCriteria.setFirstResult(startAt);
		}
		String sql = "";
		List<Object> params = new ArrayList<Object>();
		boolean isExport = (request.getParameters() instanceof AsrSearchParameter)
				&& ((AsrSearchParameter) request.getParameters()).isExport();
		if (isExport) {
			sql = "select asrpt_id y0_, asrpt_risk_scre_num, asrpt_cst_amt, rank rownum from fps2.FPS_ZN_TOP_ASR_BY_RANK_COST_MQT where cntrctr_cd = ? ";
			String zone = ((AsrSearchParameter) request.getParameters()).getSubjectJurisdiction();
			params.add(zone);
		} else {
			baseCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			ProjectionList projections = Projections.projectionList();
			baseCriteria.setProjection(projections.add(Projections.distinct(Projections.id())));
			params = buildCriteria(baseCriteria, request, false);
			if ((request.getParameters() instanceof AsrSearchParameter)) {
				buildCriteriaOrderBy(baseCriteria, (AsrSearchParameter) request.getParameters(), projections);
			} else if (projections != null) {
				baseCriteria.setProjection(projections.add(Projections.property("subjCntrctrName")));
			}

			sql = (new BasicFormatterImpl().format((new org.hibernate.loader.criteria.CriteriaJoinWalker(
					(org.hibernate.persister.entity.OuterJoinLoadable) ((org.hibernate.internal.CriteriaImpl) baseCriteria)
							.getSession().getFactory().getEntityPersister(
									((org.hibernate.internal.CriteriaImpl) baseCriteria).getSession().getFactory()
											.getImplementors(((org.hibernate.internal.CriteriaImpl) baseCriteria)
													.getEntityOrClassName())[0]),

					new org.hibernate.loader.criteria.CriteriaQueryTranslator(
							((org.hibernate.internal.CriteriaImpl) baseCriteria).getSession().getFactory(),
							((org.hibernate.internal.CriteriaImpl) baseCriteria),
							((org.hibernate.internal.CriteriaImpl) baseCriteria).getEntityOrClassName(),
							org.hibernate.loader.criteria.CriteriaQueryTranslator.ROOT_SQL_ALIAS),

					((org.hibernate.internal.CriteriaImpl) baseCriteria).getSession().getFactory(),

					(org.hibernate.internal.CriteriaImpl) baseCriteria,

					((org.hibernate.internal.CriteriaImpl) baseCriteria).getEntityOrClassName(),

					((org.hibernate.internal.CriteriaImpl) baseCriteria).getSession().getLoadQueryInfluencers()))
							.getSQLString()));
		}
		String queryTxt = "";
		if (isExport) {
			queryTxt += "with q as ( " + sql;
			if (startAt > -1) {
				queryTxt += "and rank between " + (startAt + 1) + " and " + (startAt + maxResults) + ")";
			} else {
				queryTxt += "and rank <= " + maxResults + ")";

			}
		} else {
			queryTxt = "with q as (  select distinct y0_, asrpt_risk_scre_num, ASRPT_CST_AMT, rownum from (";
			queryTxt += "select  distinct y0_,   asrpt_risk_scre_num,   ASRPT_CST_AMT,   row_number()  "
					+ " over ( order by ASRPT_RISK_SCRE_NUM desc,  ASRPT_CST_AMT desc)   rownum " + " from  (" + sql
					+ ") inner2 ) inner1";
			if (startAt > -1) {
				queryTxt += "where rownum between " + (startAt + 1) + " and " + (startAt + maxResults) + ")";
			} else {
				queryTxt += "where rownum <= " + maxResults + ")";

			}
		}

		queryTxt += " select " +

				" {report.*} " // ,{prvdr.*}, {znAssoc.*}, {riskScore.*} "
				+ " from fps2.FPS_ASRPT report inner join q on report.asrpt_id = q.y0_ "

				+ "	order by  "
				+ "  (coalesce( q.ASRPT_RISK_SCRE_NUM,       0)) desc,     (coalesce( q.ASRPT_CST_AMT ,       0)) desc "
				+ " ";
		SQLQuery query = getCurrentSession().createSQLQuery(queryTxt).addEntity("report", FpsAsrpt.class);
		// .addJoin("prvdr", "report.fpsPrvdr").addJoin("znAssoc",
		// "report.fpsPrvdrZnAsctn").addJoin("riskScore",
		// "znAssoc.fpsZnThresholdRiskScreVw")
		// .addEntity("report", FpsAsrpt.class);

		((Query) query).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		int i = 0;
		for (Object o : params) {
			query.setParameter(i, o);
			i++;
		}

		List<FpsAsrpt> results = new ArrayList<FpsAsrpt>();
		try {
			results = query.list();
		} catch (HibernateException e) {
			if ((request.getParameters() instanceof AsrSearchParameter)) {
				logger.warning(
						"error for search criteria " + ((AsrSearchParameter) request.getParameters()).toString());
			}
			throw e;
		}
		logger.fine("returning " + results.size() + " ASR Summary results");
		return results;
	}

	
	@Override
	@Transactional
	public List<VwFpsAsrptIdXwalkSmry> searchAsrCasesMedicaid(AsrSearchParameter request) {
		Criteria baseCriteria = getCurrentSession().createCriteria(FpsAsrptSummaryAsrsMdcd.class, "report");
		List<Object> params = new ArrayList<Object>();

		baseCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		ProjectionList projections = Projections.projectionList();
		baseCriteria.setProjection(projections.add(Projections.distinct(Projections.id())));
		params = buildCriteriaMedicaid(baseCriteria, request, false);
		buildCriteriaOrderBy(baseCriteria, request, projections);

		List<VwFpsAsrptIdXwalkSmry> results = new ArrayList<VwFpsAsrptIdXwalkSmry>();
		List<FpsAsrptSummaryAsrsMdcd> results2 = new ArrayList<FpsAsrptSummaryAsrsMdcd>();
		String queryTxt = "";
		String sql = (new BasicFormatterImpl().format((new org.hibernate.loader.criteria.CriteriaJoinWalker(
				(org.hibernate.persister.entity.OuterJoinLoadable) ((org.hibernate.internal.CriteriaImpl) baseCriteria)
						.getSession().getFactory().getEntityPersister(
								((org.hibernate.internal.CriteriaImpl) baseCriteria).getSession().getFactory()
										.getImplementors(((org.hibernate.internal.CriteriaImpl) baseCriteria)
												.getEntityOrClassName())[0]),

				new org.hibernate.loader.criteria.CriteriaQueryTranslator(
						((org.hibernate.internal.CriteriaImpl) baseCriteria).getSession().getFactory(),
						((org.hibernate.internal.CriteriaImpl) baseCriteria),
						((org.hibernate.internal.CriteriaImpl) baseCriteria).getEntityOrClassName(),
						org.hibernate.loader.criteria.CriteriaQueryTranslator.ROOT_SQL_ALIAS),

				((org.hibernate.internal.CriteriaImpl) baseCriteria).getSession().getFactory(),

				(org.hibernate.internal.CriteriaImpl) baseCriteria,

				((org.hibernate.internal.CriteriaImpl) baseCriteria).getEntityOrClassName(),

				((org.hibernate.internal.CriteriaImpl) baseCriteria).getSession().getLoadQueryInfluencers()))
						.getSQLString()));
		queryTxt = "with q as (  select distinct y0_, asrpt_risk_scre_num, ASRPT_CST_AMT, rownum from (";
		queryTxt += "select  distinct y0_,   asrpt_risk_scre_num,   ASRPT_CST_AMT,   row_number()  "
				+ " over ( order by ASRPT_RISK_SCRE_NUM desc,  ASRPT_CST_AMT desc)   rownum " + " from  (" + sql
				+ ")inner2) inner1)";

		queryTxt += " select " +

				" {report.*}"//,{medicaid.*}, {medicare.*} "//{riskScore.*} "
				+ " from fps2.VW_FPS_ASRPT_ID_XWALK_SMRY report "
				+ " inner join q on report.MDCD_ASRPT_ID = q.y0_ "

				+ "	order by  "
				+ "  (coalesce( q.ASRPT_RISK_SCRE_NUM,       0)) desc,     (coalesce( q.ASRPT_CST_AMT ,       0)) desc "
				+ " ";
		SQLQuery query = getCurrentSession().createSQLQuery(queryTxt)
				.addEntity("report", VwFpsAsrptIdXwalkSmry.class);
		((Query) query).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		int i = 0;
		for (Object o : params) {
			query.setParameter(i, o);
			i++;
		}
		try {
			results = query.list();
//			for (Object[] temp : tempResults) {
//				FpsAsrptIdXwalk xwalk = (FpsAsrptIdXwalk) temp[0];
//				FpsAsrptSummaryAsrsMdcd mdcd = (FpsAsrptSummaryAsrsMdcd) temp[1];
//				FpsPrvdrAnlys mdcr = (FpsPrvdrAnlys) temp[2];
//				
//			}
		} catch (HibernateException e) {
			logger.warning("error for search criteria " + request.toString());

			throw e;
		}
		logger.fine("returning " + results.size() + " ASR MDCD Summary results");
		return results;
	}
	@Override
	@Transactional
	public List<VwFpsAsrptIdXwalkSmry> searchAsrCasesProviderAnalysis(AsrSearchParameter request) {
		Criteria baseCriteria = getCurrentSession().createCriteria(FpsPrvdrAnlys.class, "report");
		// DetachedCriteria baseCriteria =
		// DetachedCriteria.forClass(FpsAsrpt.class, "report");

		// baseCriteria.createAlias("report.fpsPrvdrZnAsctn", "prvdrZnLookup",
		// JoinType.INNER_JOIN);

		String sql = "";
		List<Object> params = new ArrayList<Object>();

		baseCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		ProjectionList projections = Projections.projectionList();
		baseCriteria.setProjection(projections.add(Projections.distinct(Projections.id())));
		params = buildCriteriaProviderAnalsys(baseCriteria, request, false);
		buildCriteriaOrderBy(baseCriteria, request, projections);

		sql = (new BasicFormatterImpl().format((new org.hibernate.loader.criteria.CriteriaJoinWalker(
				(org.hibernate.persister.entity.OuterJoinLoadable) ((org.hibernate.internal.CriteriaImpl) baseCriteria)
						.getSession().getFactory().getEntityPersister(
								((org.hibernate.internal.CriteriaImpl) baseCriteria).getSession().getFactory()
										.getImplementors(((org.hibernate.internal.CriteriaImpl) baseCriteria)
												.getEntityOrClassName())[0]),

				new org.hibernate.loader.criteria.CriteriaQueryTranslator(
						((org.hibernate.internal.CriteriaImpl) baseCriteria).getSession().getFactory(),
						((org.hibernate.internal.CriteriaImpl) baseCriteria),
						((org.hibernate.internal.CriteriaImpl) baseCriteria).getEntityOrClassName(),
						org.hibernate.loader.criteria.CriteriaQueryTranslator.ROOT_SQL_ALIAS),

				((org.hibernate.internal.CriteriaImpl) baseCriteria).getSession().getFactory(),

				(org.hibernate.internal.CriteriaImpl) baseCriteria,

				((org.hibernate.internal.CriteriaImpl) baseCriteria).getEntityOrClassName(),

				((org.hibernate.internal.CriteriaImpl) baseCriteria).getSession().getLoadQueryInfluencers()))
						.getSQLString()));

		String queryTxt = "";

		queryTxt = "with q as (  select distinct y0_, asrpt_risk_scre_num, ASRPT_CST_AMT, rownum from (";
		queryTxt += "select  distinct y0_,   asrpt_risk_scre_num,   ASRPT_CST_AMT,   row_number()  "
				+ " over ( order by ASRPT_RISK_SCRE_NUM desc,  ASRPT_CST_AMT desc)   rownum " + " from  (" + sql
				+ ") inner2) inner1)";

		queryTxt += " select " +

				" {report.*} " // ,{prvdr.*}, {znAssoc.*}, {riskScore.*} "
				+ " from fps2.VW_FPS_ASRPT_ID_XWALK_SMRY report "
				+ " inner join q on report.MDCR_ASRPT_ID = q.y0_ "
				+ "	order by  "
				+ "  (coalesce( q.ASRPT_RISK_SCRE_NUM,       0)) desc,     (coalesce( q.ASRPT_CST_AMT ,       0)) desc "
				+ " ";
		SQLQuery query = getCurrentSession().createSQLQuery(queryTxt).addEntity("report", VwFpsAsrptIdXwalkSmry.class);
		// .addJoin("prvdr", "report.fpsPrvdr").addJoin("znAssoc",
		// "report.fpsPrvdrZnAsctn").addJoin("riskScore",
		// "znAssoc.fpsZnThresholdRiskScreVw")
		// .addEntity("report", FpsAsrpt.class);
		((Query) query).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		int i = 0;
		for (Object o : params) {
			query.setParameter(i, o);
			i++;
		}

		List<VwFpsAsrptIdXwalkSmry> results = new ArrayList<VwFpsAsrptIdXwalkSmry>();
		try {
			results = query.list();
		} catch (HibernateException e) {
			logger.warning("error for search criteria " + request.toString());

			throw e;
		}
		logger.fine("returning " + results.size() + " ASR Summary results");
		return results;
	}

	private void updateAliases(Criteria c, FpsEnums.AsrSearchCriteria join, List<FpsEnums.AsrSearchCriteria> aliases) {
		if (!aliases.contains(join)) {
			switch (join) {
			case NEEDSZONELOOKUPJOIN:
				c.createAlias("report.fpsStateCntrctrInfo", "lookup", JoinType.INNER_JOIN);
				break;
			case NEEDSUCMVWJOIN:
				c.createAlias("report.fpsPrvdrAnlysUcmItemsVws", "ucmVw", JoinType.LEFT_OUTER_JOIN);
				break;
			case NEEDSMACASCTNJOIN:
				c.createAlias("report.fpsPrvdrNpiMacOrgs", "prvdrMacLookup", JoinType.INNER_JOIN);
				break;
			case NEEDSMACASCTNLEFTJOIN:
				c.createAlias("report.fpsPrvdrNpiMacOrgs", "prvdrMacLookup", JoinType.LEFT_OUTER_JOIN);
				break;
			case NEEDSTPEVWJOIN:
				c.createAlias("report.fpsTrnPrbeEduSmryVws", "tpe", JoinType.INNER_JOIN);
				break;
			case NEEDSASRPTMACASCTNJOIN:
				c.createAlias("report.fpsAsrptMacAsctns", "macLookup", JoinType.INNER_JOIN);
				break;
			case NEEDSPRVDRZONELOOKUPJOIN:
				c.createAlias("report.fpsPrvdrZnAsctn", "prvdrZnLookup", JoinType.LEFT_OUTER_JOIN);
				break;
			case NEEDSPRVDRJOIN:
				c.createAlias("report.fpsPrvdr", "prvdr", JoinType.INNER_JOIN);
				break;
			case NEEDSMODELJOIN:
				c.createAlias("alert.fpsModel", "model", JoinType.INNER_JOIN);
				break;
			case NEEDSPARTDJOIN:
				c.createAlias("report.vwFpsPtdAsrSummarys", "partd", JoinType.INNER_JOIN);
				break;
			case NEEDSALERTJOIN:
				c.createAlias("alertAsctn.fpsAlert", "alert");
				c.setFetchMode("alert", FetchMode.SELECT);
				c.createAlias("report.fpsAsrptAlertAsctns", "alertAsctn");
				c.setFetchMode("alertAsctn", FetchMode.SELECT);
				break;
			case NEEDSALERTREFJOIN:
				c.createAlias("alert.fpsAlertTypeRfrnc", "alertRef", JoinType.INNER_JOIN);
				break;
			case NEEDSALERTSTUSREFJOIN:
				c.createAlias("alert.fpsStusRfrnc", "alertStusRef", JoinType.INNER_JOIN);
				break;
			case NEEDSASRPRRTYJOIN:
				c.createAlias("report.fpsAsrptPrrty", "asrPrrty", JoinType.INNER_JOIN);
				break;
			case NEEDSCLAIMJOIN:

				c.createAlias("alert.fpsAlertClmAsctns", "clmAssoc", JoinType.INNER_JOIN);
				c.createAlias("clmAssoc.fpsClm", "clm", JoinType.INNER_JOIN);
				break;

			case NEEDSBENEJOIN:

				c.createAlias("clm.fpsBene", "bene", JoinType.INNER_JOIN);
				break;
			case NEEDSINVESTJOIN:
				c.createAlias("report.fpsAsrptInvstgtns", "invest", JoinType.INNER_JOIN);
				break;
			case NEEDSINVESTLEFTJOIN:
				c.createAlias("report.fpsAsrptInvstgtns", "investLeft", JoinType.LEFT_OUTER_JOIN);
				break;
			case NEEDSRULINGJOIN:
				c.createAlias("invest.fpsAsrptUserRulngs", "ruling", JoinType.INNER_JOIN);
				c.createAlias("ruling.fpsRulngRfrnc", "rulingRef", JoinType.INNER_JOIN);
				break;
			case NEEDSINVESTACTIONJOIN:
				c.createAlias("invest.fpsAsrptUserAdminvActns", "action", JoinType.INNER_JOIN);
				c.createAlias("action.fpsActnTypeRfrnc", "actionRef", JoinType.INNER_JOIN);

				break;
			case NEEDSINVESTACTIVITYJOIN:
				c.createAlias("invest.fpsAsrptUserActvties", "activity", JoinType.INNER_JOIN);
				c.createAlias("activity.fpsActvtyTypeRfrnc", "activityRef", JoinType.INNER_JOIN);
				break;
			case NEEDSINVESTBARRIERJOIN:
				c.createAlias("invest.fpsAsrptUserActnBrrs", "barrier", JoinType.INNER_JOIN);
				c.createAlias("barrier.fpsActnBrrRfrnc", "barrierRef", JoinType.INNER_JOIN);
				break;
			case NEEDSUSERJOIN:
				c.createAlias("report.fpsAsrptUsers", "user", JoinType.INNER_JOIN);
				break;
			case NEEDSUSEROUTERJOIN:

				c.createAlias("report.fpsAsrptUsers", "userOuter", JoinType.LEFT_OUTER_JOIN);
				break;
			case NEEDSUSERINVESTJOIN:
				c.createAlias("invest.fpsAsrptUserInvstgtns", "userInvest", JoinType.INNER_JOIN);
				break;
			case NEEDSZONETHRESHOLDJOIN:
				c.createAlias("prvdrZnLookup.fpsZnThresholdRiskScreVw", "zoneThresh", JoinType.INNER_JOIN);
				break;
			case NEEDSASRRRBCLMJOIN:
				c.createAlias("report.fpsAsrptBeneRrbVws", "rrb", JoinType.INNER_JOIN);
				break;
			case NEEDSZRLEFTJOIN:
				c.createAlias("report.fpsAsrptZrSmryVw", "zrLeft", JoinType.LEFT_OUTER_JOIN);
				break;
			case NEEDSMATVIEWJOIN:
				c.createAlias("report.fpsAsrptStatMatVw", "matVw", JoinType.INNER_JOIN);
				break;

			case NEEDSPRVDRVIEWJOIN:
				c.createAlias("report.fpsAsrptClmNpiNumsVw", "prvdrVw", JoinType.INNER_JOIN);
				break;
			case NEEDSEDITVIEWJOIN:
				c.createAlias("report.fpsAsrptEditSmryVws", "editsVw", JoinType.INNER_JOIN);
				break;
			case NEEDSUCMASCTNJOIN:
				c.createAlias("report.fpsAsrptUcmAsctns", "ucmAsctn", JoinType.INNER_JOIN);
				break;
			case NEEDSEXCLUSIONJOIN:
				c.createAlias("report.fpsPrvdrAnlysExclusions", "exclusions", JoinType.INNER_JOIN);
				break;
			case NEEDSPROVIDERANALYSISJURISJOIN:
				c.createAlias("report.fpsPrvdrAnlysJurisdictions", "juris", JoinType.INNER_JOIN);
				break;
			case NEEDSACOJOIN:

				c.createAlias("report.fpsPorOrgPrvdrAcoMqts", "aco", JoinType.LEFT_OUTER_JOIN);
				break;
			}
		}
		aliases.add(join);
	}

	@Override
	@Deprecated
	public String assignAsr(int asrptId, String userId, String supervisorId) {
		List<FpsAsrpt> asrs = getCurrentSession().createCriteria(FpsAsrpt.class)
				.add(Restrictions.eqOrIsNull("asrptId", Integer.valueOf(asrptId))).list();
		if ((asrs == null) || (asrs.size() == 0)) {
			return "No ASR found for " + asrptId;
		}
		LdapQuery query = buildBaseQuery();

		List<FpsAsrptUser> oldReportUsers = loadAsrUser(asrptId);
		List<String> foundUsers = new ArrayList<String>();

		query.setFilter("(uid=" + userId + ")");

		List<FpsUser> newFpsUsers = LdapUtil.getOpenAMUser(query);
		FpsUser newFpsUser = (newFpsUsers != null) && (newFpsUsers.size() > 0) ? (FpsUser) newFpsUsers.get(0) : null;

		FpsAsrpt asrpt = null;
		for (FpsAsrptUser oldReportUser : oldReportUsers) {
			if (oldReportUser != null) {
				query.setFilter("(uid=" + oldReportUser.getAplctnUserId() + ")");

				List<FpsUser> fpsUsers = LdapUtil.getOpenAMUser(query);

				FpsUser existingUser = (fpsUsers != null) && (fpsUsers.size() > 0) ? (FpsUser) fpsUsers.get(0) : null;
				if (newFpsUser != null) {
					String existingUserZone = existingUser != null ? existingUser.getBusinessCategory() : null;
					if ((existingUserZone == null) || (existingUserZone.equals(newFpsUser.getBusinessCategory()))) {
						oldReportUser.setActvInd("N");
						oldReportUser.setTrmntnDt(new Date());
						oldReportUser.setAudtUpdtTs(new Date());
						oldReportUser.setAudtUpdtId(supervisorId);
						getCurrentSession().save(oldReportUser);
						foundUsers.add(oldReportUser.getAplctnUserId());
					}
				}
			}
		}
		FpsAsrptUser newReportUser = new FpsAsrptUser();

		newReportUser.setFpsAsrpt((FpsAsrpt) asrs.get(0));

		newReportUser.setAplctnUserId(userId);
		newReportUser.setActvInd("Y");
		newReportUser.setEfctvDt(new Date());
		newReportUser.setFpsVrsnInd("2");
		newReportUser.setAudtInsrtId(supervisorId);
		newReportUser.setAudtInsrtTs(new Date());
		getCurrentSession().save(newReportUser);

		FpsAsrpt asr = (FpsAsrpt) asrs.get(0);
		// FpsAsrptLog log = new FpsAsrptLog();
		// log.setActvtyActnInd("A");
		// log.setAplctnUserId(userId);
		// log.setAsrptLogDt(new Date());
		// log.setAudtInsrtId(supervisorId);
		// log.setAudtInsrtTs(new Date());
		// log.setFpsVrsnInd(asr.getFpsVrsnInd());
		// log.setAsrptId(asr.getAsrptId());
		// if (asr.getAsrptRiskScreNum() != null) {
		// log.setAsrptRiskScre(asr.getAsrptRiskScreNum());
		// }
		String asrptDesc = "ASR " + asr.getSubjId() + ": assigned to " + userId + " by " + supervisorId;
		if (foundUsers.size() > 0) {
			asrptDesc = asrptDesc + ". Unassigned from " + StringUtils.join(foundUsers, ",");
		}
		// log.setAsrptDesc(asrptDesc);
		insertAsrHistory(userId, supervisorId, null, asr.getAsrptId(), asr.getAsrptRiskScreNum(), asrptDesc,
				asr.getFpsVrsnInd(), "A");
		// getCurrentSession().save(log);
		return asrptDesc;
	}

	@Override
	public FpsAsrptInvstgtn addInvestigationLink(AsrInvestigation inv) {
		FpsAsrptInvstgtn asrptInv = new FpsAsrptInvstgtn();
		Integer id = -1;
		List<FpsAsrpt> asrs = null;
		List<FpsAsrptMdcd> mdcdAsrs = null;
		String subjId= "";
		String vrsn = "";
		Double riskScore = Double.valueOf("0");
		FpsAsrptMdcd mdcdAsr = null;
		FpsAsrpt asr = null;
		boolean isMdcd = inv.getProgramType()!= null && "medicaid".equals(inv.getProgramType().toLowerCase());
		if (isMdcd) {
			if (StringUtils.isNotBlank(inv.getSubjId())) {
				
				id = findMdcdAsrIdBySubjId(inv.getSubjId());
				if (id == null) {
					logger.info("No Mdcd ASR found for " + inv.getSubjId());
					return null;
				}
			} else {
				id = inv.getAsrptId();
			}
			mdcdAsrs = getCurrentSession().createCriteria(FpsAsrptMdcd.class)
					.add(Restrictions.eqOrIsNull("asrptId", Integer.valueOf(id))).list();
			if ((mdcdAsrs == null) || (mdcdAsrs.size() == 0)) {
				return null;
			}
			mdcdAsr = (FpsAsrptMdcd) mdcdAsrs.get(0);
			subjId = mdcdAsr.getSubjId();
			vrsn = "2";
			riskScore = mdcdAsr.getAsrptRiskScreNum();
			if (inv.getAsrptId() == 0) {
				inv.setAsrptId(mdcdAsr.getAsrptId());
			}
		
		}else {
			if (StringUtils.isNotBlank(inv.getSubjId())) {
	
				id = findAsrIdBySubjId(inv.getSubjId());
				if (id == null) {
					logger.info("No ASR found for " + inv.getSubjId());
					return null;
				}
			} else {
				id = inv.getAsrptId();
			}
			asrs = getCurrentSession().createCriteria(FpsAsrpt.class)
					.add(Restrictions.eqOrIsNull("asrptId", Integer.valueOf(id))).list();
			if ((asrs == null) || (asrs.size() == 0)) {
				return null;
			}
			asr = (FpsAsrpt) asrs.get(0);
			subjId = asr.getSubjId();
			vrsn = asr.getFpsVrsnInd();
			riskScore = asr.getAsrptRiskScreNum();
			if (inv.getAsrptId() == 0) {
				inv.setAsrptId(asr.getAsrptId());
			}
		}

		
	
		FpsUser loggedInUser = null;

		if (StringUtils.isBlank(inv.getUcmCaseId())) {
			List<FpsUser> fpsUsers = getOpenAMUser(inv.getAssignedUserId());

			loggedInUser = (fpsUsers != null) && (fpsUsers.size() > 0) ? (FpsUser) fpsUsers.get(0) : null;
			if (loggedInUser == null) {
				return null;
			}
		} else {
			loggedInUser = new FpsUser();
			loggedInUser.setBusinessCategory(inv.getAssignedZone());
			loggedInUser.setUserId("UCM");
		}
		
		Integer i = Integer.valueOf(inv.getInvestId());
		if (inv.getInvestId() > 0) {
			asrptInv.setAsrptInvstgtnId(inv.getInvestId());
			asrptInv = (FpsAsrptInvstgtn) getCurrentSession().load(FpsAsrptInvstgtn.class,
					Integer.valueOf(inv.getInvestId()));
			asrptInv.setBpmProcNum(inv.getBpmProcNum());
			asrptInv.setBpmTskId(inv.getTaskId());
			asrptInv.setEfctvDt(inv.getUcmCaseDt());
			asrptInv.setTrmntnDt(inv.getUcmCaseCloseDt());
			asrptInv.setUcmCaseReOpenedDate(inv.getUcmCaseReOpenedDate());
			asrptInv.setUcmCaseReOpenedRationale(inv.getUcmCaseReOpenedRationale());
			asrptInv.setActvInd("Y");
			asrptInv.setAudtUpdtTs(new Date());
			asrptInv.setAudtUpdtId(inv.getUserId());
			asrptInv.setSubStatus(inv.getSubStatus());
			asrptInv.setProgramType(inv.getProgramType());
			asrptInv.setClaimType(inv.getClaimType());
			asrptInv.setStateCd(inv.getStateCd());

			getCurrentSession().update(asrptInv);
		} else {
			asrptInv.setBpmProcNum(inv.getBpmProcNum());
			asrptInv.setBpmTskId(inv.getTaskId());
			asrptInv.setEfctvDt(inv.getUcmCaseDt());
			asrptInv.setTrmntnDt(inv.getUcmCaseCloseDt());
			asrptInv.setUcmCaseReOpenedDate(inv.getUcmCaseReOpenedDate());
			asrptInv.setUcmCaseReOpenedRationale(inv.getUcmCaseReOpenedRationale());
			if (StringUtils.isNotBlank(inv.getUcmState())) {
				if (inv.getUcmState().equals("OPEN")) {
					asrptInv.setStusCd("11");
				}else {
					asrptInv.setStusCd("17");
				}
//				asrptInv.setExtrnlCaseStusDesc(inv.getUcmStatus());
			} else {
				asrptInv.setStusCd("11"); // open
			}
			asrptInv.setInvstgtnTypeCd(inv.getUcmCaseType());
			asrptInv.setExtrnlCaseStusDesc(inv.getUcmStatus());
			String category = StringUtils.contains(inv.getUcmStatus() != null ? inv.getUcmStatus().toLowerCase():"", "lead") ? "2" : "1";
			asrptInv.setInvstgtnCtgryCd(category); // lead
			asrptInv.setCaseClosedRsn(inv.getUcmCaseCloseRsn());
			asrptInv.setAsrptId(inv.getAsrptId());
			asrptInv.setStateCd(inv.getStateCd());
			asrptInv.setAudtInsrtId(inv.getUserId());
			asrptInv.setAudtInsrtTs(new Date());
			if (inv.getUpdateDt() != null) {
				asrptInv.setAudtUpdtId(inv.getUserId());
				asrptInv.setAudtUpdtTs(inv.getUpdateDt());
			}
			asrptInv.setFpsVrsnInd("2");
			asrptInv.setActvInd("Y");
			asrptInv.setExtrnlCaseId(inv.getUcmCaseId());
			asrptInv.setRecChgInd("A");
			asrptInv.setInvstgtnDesc(inv.getEventTrigger());
			asrptInv.setSubStatus(inv.getSubStatus());
			asrptInv.setProgramType(inv.getProgramType());
			asrptInv.setClaimType(inv.getClaimType());
			i = (Integer) getCurrentSession().save(asrptInv);
			asrptInv.setAsrptInvstgtnId(i.intValue());
		}
		if (inv.getAssignees() != null) {
			for (FpsGenericKeyValue kv : inv.getAssignees()){
				FpsAsrptUserInvstgtn userInv = new FpsAsrptUserInvstgtn();
				userInv.setActvInd("Y");
				userInv.setEfctvDt(inv.getUcmCaseDt());
				userInv.setUserRoleName(inv.getUserRole());
				userInv.setFpsVrsnInd("2");
				if (StringUtils.isNotBlank(inv.getUcmCaseId())) {
					userInv.setAsgnedCntrctr(inv.getAssignedZone());
					userInv.setExtrnlCaseId(inv.getUcmCaseId());
		
				} else {
		
					userInv.setAsgnedCntrctr(loggedInUser.getBusinessCategory());
				}
				userInv.setRecChgInd("A");
				userInv.setAplctnSuprUserId(inv.getUserId());
				userInv.setAsgnedUserId(inv.getAssignedUserId());
				userInv.setFpsAsrptInvstgtn(asrptInv);
				userInv.setAudtInsrtId(inv.getUserId());
				userInv.setFpsVrsnInd("2");
				userInv.setAudtInsrtTs(new Date());
		
	
				userInv.setAplctnSuprUserId(kv.getKey());
				userInv.setAsgnedUserId(kv.getKey());
				getCurrentSession().save(userInv);
			
			

			}
		
		}else {
			FpsAsrptUserInvstgtn userInv = new FpsAsrptUserInvstgtn();
			userInv.setActvInd("Y");
			userInv.setEfctvDt(inv.getUcmCaseDt());
			userInv.setUserRoleName(inv.getUserRole());
			userInv.setFpsVrsnInd("2");
			if (StringUtils.isNotBlank(inv.getUcmCaseId())) {
				userInv.setAsgnedCntrctr(inv.getAssignedZone());
				userInv.setExtrnlCaseId(inv.getUcmCaseId());
	
			} else {
	
				userInv.setAsgnedCntrctr(loggedInUser.getBusinessCategory());
			}
			userInv.setRecChgInd("A");
			userInv.setAplctnSuprUserId(inv.getUserId());
			userInv.setAsgnedUserId(inv.getAssignedUserId());
			userInv.setFpsAsrptInvstgtn(asrptInv);
			userInv.setAudtInsrtId(inv.getUserId());
			userInv.setFpsVrsnInd("2");
			userInv.setAudtInsrtTs(new Date());
	

			userInv.setAplctnSuprUserId(inv.getAssignedUserId());
			getCurrentSession().save(userInv);
		}
//		asrptInv.setFpsAsrpt(asr);
		String asrptDesc = "ASR " + subjId + ": Investigation opened by " + inv.getUserId()
				+ " and assigned to " + inv.getAssignedUserId();

		String auditId = "UCM";
		if (inv.getAssignedZone() != null) {
			auditId = inv.getAssignedZone().startsWith("UPIC") ? inv.getUserId() : inv.getUserId() + "_MAC";
		}
		if (isMdcd) {
			asrptInv.setFpsAsrptMdcd(mdcdAsr);
			insertMdcdAsrHistory(inv.getUserId(), auditId, i, id, riskScore, asrptDesc,
					vrsn, "A");
		}else {
			asrptInv.setFpsAsrpt(asr);
			insertAsrHistory(inv.getUserId(), auditId, i, id, riskScore, asrptDesc,
					vrsn, "A");
		}
		return asrptInv;
	}

	@Transactional
	@Override
	public void insertAsrHistory(String userId, String superId, Integer invId, Integer asrId, Double riskScore,
			String text, String version, String action) {
		FpsAsrptLog log = new FpsAsrptLog();
		log.setActvtyActnInd(action);
		log.setAplctnUserId(userId);
		if (invId != null) {
			log.setAsrptInvstgtnId(invId);
		}
		log.setAsrptLogDt(new Date());
		log.setAudtInsrtId(superId);
		log.setAudtInsrtTs(new Date());
		log.setFpsVrsnInd(version);
		if (asrId != null) {
			log.setAsrptId(asrId);
		}
		if (riskScore != null) {
			log.setAsrptRiskScre(riskScore);
		}
		log.setAsrptDesc(text);

		getCurrentSession().save(log);
	}

	@Transactional
	@Override
	public List<FpsAsrptUser> loadAsrUser(int asrptId) {
		List<FpsAsrptUser> users = getCurrentSession().createCriteria(FpsAsrptUser.class)
				.add(Restrictions.eq("fpsAsrpt.asrptId", Integer.valueOf(asrptId)))
				.add(Restrictions.or(Restrictions.eqOrIsNull("actvInd", "Y"), Restrictions.eqOrIsNull("actvInd", null)))
				.list();
		return users;
	}

	@Transactional
	@Override
	public FpsAsrptUser loadAsrUser(int asrptId, String userId) {
		List<FpsAsrptUser> users = getCurrentSession().createCriteria(FpsAsrptUser.class)
				.add(Restrictions.eq("fpsAsrpt.asrptId", Integer.valueOf(asrptId)))
				.add(Restrictions.or(Restrictions.eqOrIsNull("actvInd", "Y"), Restrictions.eqOrIsNull("actvInd", null)))
				.add(Restrictions.eqOrIsNull("aplctnUserId", userId)).list();
		if ((users != null) && (users.size() > 0)) {
			return (FpsAsrptUser) users.get(0);
		}
		return null;
	}

	@Transactional
	@Override
	public List<FpsModel> loadModels(boolean activeOnly) {
		List<FpsModel> models = new ArrayList<FpsModel>();
		Criteria c = getCurrentSession().createCriteria(FpsModel.class, "model");
		if (!activeOnly) {
			c.add(Restrictions.ne("modelActvtyStus", "Active"));
		} else {
			c.add(Restrictions.eq("modelActvtyStus", "Active"));

		}
		c.addOrder(Order.asc("modelBusnsId"));

		models = c.list();

		return models;
	}

	@Transactional
	@Override
	public List<FpsModel> loadAllModels() {
		List<FpsModel> models = new ArrayList<FpsModel>();
		Criteria c = getCurrentSession().createCriteria(FpsModel.class, "model");

		c.addOrder(Order.asc("modelBusnsId"));

		models = c.list();

		return models;
	}
	@Transactional
	@Override
	public List<FpsModelMdcd> loadAllModelsMdcd() {
		List<FpsModelMdcd> models = new ArrayList<FpsModelMdcd>();
		Criteria c = getCurrentSession().createCriteria(FpsModelMdcd.class, "model");

		c.addOrder(Order.asc("modelBusnsId"));

		models = c.list();

		return models;
	}
	@Transactional
	@Override
	public FpsModel loadModelById(int modelId) {
		FpsModel model = new FpsModel();
		Criteria c = getCurrentSession().createCriteria(FpsModel.class, "model");
		c.add(Restrictions.idEq(Integer.valueOf(modelId)));
		c.addOrder(Order.asc("modelBusnsId"));

		model = (FpsModel) c.uniqueResult();

		return model;
	}
	@Transactional
	@Override
	public FpsModelMdcd loadMdcdModelById(int modelId) {
		FpsModelMdcd model = new FpsModelMdcd();
		Criteria c = getCurrentSession().createCriteria(FpsModelMdcd.class, "model");
		c.add(Restrictions.idEq(Integer.valueOf(modelId)));
		c.addOrder(Order.asc("modelBusnsId"));

		model = (FpsModelMdcd) c.uniqueResult();

		return model;
	}
	@Transactional
	public FpsModel loadModelByBusnsId(String modelBusnsId) {
		FpsModel model = new FpsModel();
		Criteria c = getCurrentSession().createCriteria(FpsModel.class, "model");
		c.add(Restrictions.eq("modelBusnsId", modelBusnsId));

		model = (FpsModel) c.uniqueResult();

		return model;
	}
	@Transactional
	public FpsModelMdcd loadMdcdModelByBusnsId(String modelBusnsId) {
		FpsModelMdcd model = new FpsModelMdcd();
		Criteria c = getCurrentSession().createCriteria(FpsModelMdcd.class, "model");
		c.add(Restrictions.eq("modelBusnsId", modelBusnsId));

		model = (FpsModelMdcd) c.uniqueResult();

		return model;
	}
	@Deprecated
	private List<Object> buildCriteria(Criteria c, BaseRequest request, boolean addSuffixes) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat ucmFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		List<Object> params = new ArrayList<Object>();
		boolean hasOrderBy = false;

		List<FpsEnums.AsrSearchCriteria> aliases = new ArrayList<AsrSearchCriteria>();

		if (request.getParameters().getEndTime() != null) {
			try {
				Date d = FpsDomainObjectConverter.convertGmtStringToLocalDate(request.getParameters().getEndTime());
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTJOIN, aliases);
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSRULINGJOIN, aliases);
				params.add(d);
				params.add(d);
				c.add(Restrictions.or(Restrictions.le("alert.alertCreatDt", d),
						Restrictions.le("ruling.audtInsrtTs", d)));
			} catch (ParseException e) {
				params.add(new Date());
				c.add(Restrictions.le("alert.alertCreatDt", new Date()));
			}
		}
		if (request.getParameters().getStartTime() != null) {
			try {
				Date d = FpsDomainObjectConverter.convertGmtStringToLocalDate(request.getParameters().getStartTime());
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTJOIN, aliases);
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSRULINGJOIN, aliases);
				params.add(d);
				params.add(d);
				c.add(Restrictions.or(Restrictions.ge("alert.alertCreatDt", d),
						Restrictions.ge("ruling.audtInsrtTs", d)));
			} catch (ParseException e) {
				params.add(new Date());
				c.add(Restrictions.ge("alert.alertCreatDt", new Date()));
			}
		}
		if ((request.getParameters().getRuling() != null) && (request.getParameters().getRuling().size() > 0)) {
			updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTJOIN, aliases);
			updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSRULINGJOIN, aliases);

			List<String> rulingCds = new ArrayList<String>();
			for (String desc : request.getParameters().getRuling()) {
				rulingCds.add(FpsEnums.RulingType.getValue(desc).getCd());
				params.add(FpsEnums.RulingType.getValue(desc).getCd());
			}
			// params.add(rulingCds);
			c.add(Restrictions.in("rulingRef.rulngCd", rulingCds));
		}
		if (request.getParameters().getWorkloadStatus() != null) {
			updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTJOIN, aliases);
			params.add("11");
			c.add(Restrictions.eq("invest.stusCd", "11"));
		}
		boolean hasValidParams = false;
		if ((request.getParameters() instanceof AsrSearchParameter)) {
			AsrSearchParameter param = (AsrSearchParameter) request.getParameters();
			FpsUser defaultUser = new FpsUser();
			defaultUser.setUserId("NONE");
			defaultUser.setBusinessCategory("NONE");
			FpsUser loggedInUser = null;
			if (StringUtils.isNotBlank(param.getLoggedInUserId())) {
				LdapQuery query = buildBaseQuery();
				query.setFilter("(uid=" + param.getLoggedInUserId() + ")");

				List<FpsUser> fpsUsers = LdapUtil.getOpenAMUser(query);
				if (fpsUsers.size() == 0) {
					logger.fine("Ldap advanced search for " + param.getLoggedInUserId() + " returned " + fpsUsers.size()
							+ " results");
				}
				loggedInUser = fpsUsers != null && fpsUsers.size() > 0 ? fpsUsers.get(0) : null;
			}
			if (loggedInUser == null) {
				loggedInUser = defaultUser;
			}
			logger.fine("using userid = " + loggedInUser.getUserId());
			logger.fine("using userzone = " + loggedInUser.getBusinessCategory());
			updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);

			// search only FPS2-alerted ASRs
			if (param.isFps2Only()) {

				params.add("2");
				c.add(Restrictions.eq("alert.fpsVrsnInd", "2"));
			}
			if ((param.getBarriers() != null) && (param.getBarriers().size() > 0)) {
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTJOIN, aliases);
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTBARRIERJOIN, aliases);
				List<String> barrierCds = new ArrayList<String>();
				for (AsrSummaryBarrier barrier : param.getBarriers()) {
					barrierCds.add(barrier.getBarrierCd());
					params.add(barrier.getBarrierCd());
				}
				// String barrierCdsSql = "'" + StringUtils.join(barrierCds,
				// "','") + "'";
				// params.add(barrierCdsSql);
				c.add(Restrictions.in("barrierRef.actnBrrCd", barrierCds));
			}
			if ((param.getRulings() != null) && (param.getRulings().size() > 0)) {
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTJOIN, aliases);
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSRULINGJOIN, aliases);

				List<String> rulingCds = new ArrayList<String>();
				for (AsrRuling ruling : param.getRulings()) {
					rulingCds.add(ruling.getCode());
					params.add(ruling.getCode());
				}

				DetachedCriteria subqueryRulings = DetachedCriteria.forClass(FpsAsrptInvstgtn.class, "invSub")
						.createAlias("invSub.fpsAsrptUserRulngs", "invSubRulings")
						.createAlias("invSubRulings.fpsRulngRfrnc", "rulingRefSub")
						.setProjection(Projections.projectionList().add(Projections.max("invSubRulings.crntRulngDt"))
								.add(Projections.groupProperty("invSub.asrptInvstgtnId")));
				// params.add(subqueryRulings);
				c.add(Subqueries.propertiesIn(new String[] { "ruling.crntRulngDt", "invest.asrptInvstgtnId" },
						subqueryRulings));
				// String rulingCdSql = "'" + StringUtils.join(rulingCds, "','")
				// + "'";
				// params.add(rulingCdSql);
				c.add(Restrictions.in("rulingRef.rulngCd", rulingCds));

			}
			// deprecated
			if (StringUtils.isNotBlank(param.getAssignedToUserId()) || StringUtils.isNotBlank(param.getAssigned())) {
				if ("unassigned".equals(param.getAssignedToUserId()) || "unassigned".equals(param.getAssigned())) {
					DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrptUser.class, "assignedUserForAsr")
							.createAlias("assignedUserForAsr.fpsAsrpt", "asrForAssignedUser", JoinType.INNER_JOIN)
							// .add(Restrictions.isNotNull("userForAssignedUser.aplctnUserId"))
							.add(Restrictions.ne("assignedUserForAsr.aplctnUserId", "Unassigned"))
							.add(Restrictions.or(Restrictions.ne("assignedUserForAsr.actvInd", "N"),
									Restrictions.isNull("assignedUserForAsr.actvInd")))
							.setProjection(Projections.distinct(Projections.property("asrForAssignedUser.asrptId")));
					params.add("Unassigned");
					params.add("N");
					c.add(Subqueries.propertyNotIn("asrptId", subquery));

					// c.add(Subqueries.propertyIn("asrptId", subquery));

				} else if ("assigned".equals(param.getAssignedToUserId()) || "assigned".equals(param.getAssigned())) {
					DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrpt.class, "asrptForAssignedUser")
							.createAlias("asrptForAssignedUser.fpsAsrptUsers", "userForAssignedUser",
									JoinType.LEFT_OUTER_JOIN)
							.add(Restrictions.isNotNull("userForAssignedUser.aplctnUserId"))
							.add(Restrictions.ne("userForAssignedUser.aplctnUserId", "Unassigned"))
							.add(Restrictions.ne("userForAssignedUser.actvInd", "N"))
							.setProjection(Projections.distinct(Projections.property("asrptForAssignedUser.asrptId")));
					params.add("Unassigned");
					params.add("N");
					// params.add(subquery);
					c.add(Subqueries.propertyIn("asrptId", subquery));
				} else {
					params.add(param.getAssignedToUserId());
					params.add("Y");
					c.add(Restrictions.eq("user.aplctnUserId", param.getAssignedToUserId()));
					c.add(Restrictions.or(Restrictions.eqOrIsNull("user.actvInd", "Y"),
							Restrictions.eqOrIsNull("user.actvInd", null)));
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSUSERJOIN, aliases);
				}

			}
			// deprecated
			if ((StringUtils.isNotBlank(param.getAssignedToFName()))
					|| (StringUtils.isNotBlank(param.getAssignedToLName()))) {
				LdapQuery q = buildBaseQuery();
				String fFilter = null;
				String lFilter = null;
				if (StringUtils.isNotBlank(param.getAssignedToFName())) {
					fFilter = "(givenName=" + param.getAssignedToFName() + ")";
				}
				if (StringUtils.isNotBlank(param.getAssignedToLName())) {
					lFilter = "(surname=" + param.getAssignedToLName() + ")";
				}
				String filter = "";
				if (fFilter != null) {
					if (lFilter != null) {
						filter = "(&" + fFilter + lFilter + ")";
					} else {
						filter = fFilter;
					}
				} else {
					filter = lFilter;
				}
				logger.fine("filter = " + filter);
				q.setFilter(filter);
				List<FpsUser> fpsUsers = LdapUtil.getOpenAMUser(q);
				List<String> userIds = new ArrayList<String>();
				if (fpsUsers.size() == 0) {
					logger.fine("Ldap advanced search by username for " + param.getLoggedInUserId() + " returned "
							+ fpsUsers.size() + " results");
				} else {
					for (FpsUser user : fpsUsers) {

						if (StringUtils.isNotBlank(user.getUserId())) {
							userIds.add(user.getUserId());
							params.add(user.getUserId());
						}
					}

				}
				if (userIds.size() > 0) {
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSUSERJOIN, aliases);
					// params.add("'" + StringUtils.join(userIds, "','")+ "'");
					params.add("Y");
					c.add(Restrictions.in("user.aplctnUserId", userIds));
					c.add(Restrictions.or(Restrictions.eqOrIsNull("user.actvInd", "Y"),
							Restrictions.eqOrIsNull("user.actvInd", null)));

				} else {
					c.add(Restrictions.eq("report.asrptId", -1));
					params.add(-1);

				}
			}
			// Systags
			if ((param.getSysTags() != null) && (param.getSysTags().size() > 0)) {
				DetachedCriteria subquery = DetachedCriteria.forClass(VwFpsAsrptSysTag.class, "systag")

						.setProjection(Projections.distinct(Projections.property("asrptId")));
				List<String> tags = new ArrayList<String>();
				for (AsrSysTagItem tag : param.getSysTags()) {
					tags.add(tag.getSysTagTxt());
					params.add(tag.getSysTagTxt());
				}
				subquery.add(Restrictions.in("sysTagTxt", tags));
				// params.add("'" + StringUtils.join(tags, "','") + "'");

				// params.add(subquery);
				c.add(Subqueries.propertyIn("asrptId", subquery));
			}
			// ASR State
			if ((param.getStates() != null) && (param.getStates().size() > 0)) {
//				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRJOIN, aliases);
//				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRZONELOOKUPJOIN, aliases);
				List<String> states = new ArrayList<String>();
				for (AsrState state : param.getStates()) {
					states.add(state.getCode());
					params.add(state.getCode());
				}
				// String stateSql = "'" + StringUtils.join(states, "','") +
				// "'";
				// params.add(stateSql);
				c.add(Restrictions.in("subjGeoStateCd", states));
			}
			// subject jurisdiction

			// check role for MAC search
			if (StringUtils.isNotBlank(param.getSubjectJurisdiction())) {
				// updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRJOIN,
				// aliases);
				if ("MEDIC".equals(param.getSubjectJurisdiction())) {
					DetachedCriteria partD = DetachedCriteria.forClass(FpsAsrptStatMatVw.class, "claims")
							.add(Restrictions.eq("type", "CLAIM TYPE")).add(Restrictions.eq("value", "D"))
							.setProjection(Projections.distinct(Projections.property("asrptId")));

					params.add("CLAIM TYPE");
					params.add("D");

					c.add(Subqueries.propertyIn("asrptId", partD));
				} else {
					if ("-1".equals(param.getSubjectJurisdiction())) {
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRZONELOOKUPJOIN, aliases);
						c.add(Restrictions.eq("prvdrZnLookup.cntrctrCd", "ZPIC 0"));
						params.add("ZPIC 0");

					} else if (!param.getSubjectJurisdiction().startsWith("U")) {
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSASRPTMACASCTNJOIN, aliases);
						c.add(Restrictions.eq("macLookup.macJurisdiction", param.getSubjectJurisdiction()));
						params.add(param.getSubjectJurisdiction());

					} else {
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRZONELOOKUPJOIN, aliases);
						c.add(Restrictions.eq("prvdrZnLookup.cntrctrCd", param.getSubjectJurisdiction()));
						params.add(param.getSubjectJurisdiction());

					}
				}

			}
			if ((param.getJurisdictions() != null) && (param.getJurisdictions().size() > 0)) {
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRJOIN, aliases);
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRZONELOOKUPJOIN, aliases);
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMACASCTNJOIN, aliases);
				List<String> zoneCds = new ArrayList<String>();
				boolean hasMedic = false;
				for (AsrGenericCode code : param.getJurisdictions()) {
					zoneCds.add(code.getCode());
					if ("MEDIC".equals(code.getCode())) {
						hasMedic = true;
					}

				}
				// if someone is searching on MEDIC, treat it differently
				if (hasMedic) {
					DetachedCriteria partD = DetachedCriteria.forClass(FpsAsrptStatMatVw.class, "claims")
							.add(Restrictions.eq("type", "CLAIM TYPE")).add(Restrictions.eq("value", "D"))
							.setProjection(Projections.distinct(Projections.property("asrptId")));

					params.add("CLAIM TYPE");
					params.add("D");

					// if includes zone criteria other than MEDIC
					if (param.getJurisdictions().size() > 1) {
						c.add(Restrictions.or(Subqueries.propertyIn("asrptId", partD),
								Restrictions.or(Restrictions.in("prvdrZnLookup.cntrctrCd", zoneCds),
										Restrictions.in("macLookup.macJurisdiction", zoneCds))));
						params.addAll(zoneCds);
						params.addAll(zoneCds);
					} else {
						c.add(Subqueries.propertyIn("asrptId", partD));
					}

				} else {
					// standard zone search
					c.add(Restrictions.or(Restrictions.in("prvdrZnLookup.cntrctrCd", zoneCds),
							Restrictions.in("macLookup.macJurisdiction", zoneCds)));
					params.addAll(zoneCds);
					params.addAll(zoneCds);
				}

			}
			// assigned zone
			if (StringUtils.isNotBlank(param.getAssignedZone())
					&& CollectionUtils.isEmpty(param.getLeadInvestigationInd())) { // and
																					// leadinv
																					// flag
																					// not
																					// set
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTJOIN, aliases);
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSUSERINVESTJOIN, aliases);
				params.add(param.getAssignedZone());
				c.add(Restrictions.eq("userInvest.asgnedCntrctr", param.getAssignedZone()));
			}
			// APS
			if (StringUtils.isNotEmpty(param.getApsInd())) {
				hasValidParams = true;
				DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrptApsVw.class, "aps");
				subquery.setProjection(Projections.distinct(Projections.property("asrptId")));
				if ("Yes".equals(param.getApsInd())) {

					c.add(Subqueries.propertyIn("asrptId", subquery));
				} else {
					c.add(Subqueries.propertyNotIn("asrptId", subquery));
				}

			}
			// Part D
			if (StringUtils.isNotEmpty(param.getPartDInd())) {
				hasValidParams = true;
				DetachedCriteria subquery = DetachedCriteria.forClass(VwFpsPtdAsrSummary.class, "partd");
				subquery.setProjection(Projections.distinct(Projections.property("asrptId")));
				if ("Yes".equals(param.getPartDInd())) {

					c.add(Subqueries.propertyIn("asrptId", subquery));
				} else {
					c.add(Subqueries.propertyNotIn("asrptId", subquery));
				}

			}
			// Prioritized for UCM
			if (StringUtils.isNotEmpty(param.getPrioritized())) {
				hasValidParams = true;
				DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrptPrrty.class, "p");
				subquery.setProjection(Projections.distinct(Projections.property("asrptId")));
				subquery.add(Restrictions.eq("p.cntrctrCd", loggedInUser.getBusinessCategory()));
				params.add(loggedInUser.getBusinessCategory());

				if ("Yes".equals(param.getPrioritized())) {

					c.add(Subqueries.propertyIn("asrptId", subquery));
				} else {
					c.add(Subqueries.propertyNotIn("asrptId", subquery));
				}

			}

			// claim type
			if (CollectionUtils.isNotEmpty(param.getClaimTypes())) {
				AsrSummaryClaimType rrbType = new AsrSummaryClaimType();
				rrbType.setClaimTypeCd("RRB");
				if (param.getClaimTypes().contains(rrbType)) {
					DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrptBeneRrbVw.class, "rrb")
							.setProjection(Projections.distinct(Projections.property("asrptId")));

					// params.add(subquery);
					c.add(Subqueries.propertyIn("asrptId", subquery));
				}
				DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrptStatMatVw.class, "claims")
						.add(Restrictions.eq("type", "CLAIM TYPE"))
						.setProjection(Projections.distinct(Projections.property("asrptId")));
				Disjunction claimTypes = Restrictions
						.or(new Criterion[] { Restrictions.eq("asrptId", Integer.valueOf(-1)) });
				params.add("CLAIM TYPE");
				params.add(-1);
				for (AsrSummaryClaimType code : param.getClaimTypes()) {

					String claimType = code.getClaimTypeCd();

					claimTypes.add(Restrictions.eq("value", claimType));

					params.add(claimType);
				}
				subquery.add(claimTypes);

				// params.add(subquery);
				c.add(Subqueries.propertyIn("asrptId", subquery));
			}
			// enrollment ID
			if (StringUtils.isNotEmpty(param.getEnrollmentId())) {
				hasValidParams = true;

				DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrptEnrlmtAsctnVw.class, "enroll");
				subquery.setProjection(Projections.distinct(Projections.property("asrptId")));
				subquery.add(Restrictions.eq("enrlmtId", param.getEnrollmentId()));
				c.add(Subqueries.propertyIn("asrptId", subquery));
				params.add(param.getEnrollmentId());

			}
			// revocation status
			if (StringUtils.isNotEmpty(param.getRevokedInd())) {
				hasValidParams = true;
				DetachedCriteria subquery = DetachedCriteria.forClass(FpsRevokedAsrVw.class, "revoked");
				subquery.setProjection(Projections.distinct(Projections.property("asrptId")));
				if ("Yes".equals(param.getRevokedInd())) {

					c.add(Subqueries.propertyIn("asrptId", subquery));
				} else {
					c.add(Subqueries.propertyNotIn("asrptId", subquery));
				}

			}
			// UCM Case ID
			if (StringUtils.isNotEmpty(param.getUcmCaseId())) {
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTJOIN, aliases);

				params.add(param.getUcmCaseId());
				params.add("A");
				c.add(Restrictions.eq("invest.extrnlCaseId", param.getUcmCaseId()));
				c.add(Restrictions.eq("invest.recChgInd", "A"));

			}
			// UCM ASR ID
			if (StringUtils.isNotEmpty(param.getUcmAsrId())) {

				c.add(Restrictions.eq("ucmAsrId", param.getUcmAsrId()));
				params.add(param.getUcmAsrId());

			}
			// lead/INV
			if (CollectionUtils.isNotEmpty(param.getLeadInvestigationInd())) {
				DetachedCriteria subquery = DetachedCriteria
						.forClass(FpsAsrptInvstgnStusSmryVw.class, "asrptForLeadInv")
						.setProjection(Projections.distinct(Projections.property("asrptId")));
				String userZone = loggedInUser.getBusinessCategory();
				if (userZone != null && (userZone.startsWith("J") || userZone.startsWith("DME"))) {
					userZone = "MAC " + userZone;
				}
				if ("Yes".equals(param.getMyZoneOnlyInd())) {
					subquery.add(Restrictions.or(Restrictions.eq("asrptForLeadInv.openZone", userZone),
							Restrictions.eq("asrptForLeadInv.closedZone", userZone)));
					params.add(loggedInUser.getBusinessCategory());
					params.add(loggedInUser.getBusinessCategory());
				} else if (StringUtils.isNotBlank(param.getAssignedZone())) {
					subquery.add(Restrictions.or(Restrictions.eq("asrptForLeadInv.openZone", param.getAssignedZone()),
							Restrictions.eq("asrptForLeadInv.closedZone", param.getAssignedZone())));
					params.add(param.getAssignedZone());
					params.add(param.getAssignedZone());

				}

				Disjunction leadInvOr = Restrictions
						.or(new Criterion[] { Restrictions.eq("asrptId", Integer.valueOf(-1)) });
				params.add(-1);
				// boolean addOpenStatusY = false;
				// boolean addOpenStatusN = false;
				for (AsrGenericCode code : param.getLeadInvestigationInd()) {

					String leadInvInd = code.getCode();
					leadInvOr.add(Restrictions.eq("asrptForLeadInv.type", leadInvInd));
					params.add(leadInvInd);
					// addOpenStatusY = true;

				}

				subquery.add(leadInvOr);

				// if (addOpenStatus) {
				// params.add("11");
				// }
				// params.add(subquery);
				c.add(Subqueries.propertyIn("asrptId", subquery));
			}
			// alert types (model names)
			if ((param.getAlerts() != null) && (param.getAlerts().size() > 0)) {
				logger.fine("Models coming from Alerts drop down of Custom ASR search" + param.getAlerts().size());
				DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrptAlertAsctn.class, "asrAlerts")
						.createAlias("asrAlerts.fpsAlert", "alerts", JoinType.INNER_JOIN)
						.createAlias("asrAlerts.fpsAsrpt", "asr", JoinType.INNER_JOIN)
						.createAlias("alerts.fpsModel", "model", JoinType.INNER_JOIN)

						.setProjection(Projections.distinct(Projections.property("asr.asrptId")));
				Disjunction modelIdsOr = Restrictions
						.or(new Criterion[] { Restrictions.eq("asr.asrptId", Integer.valueOf(-1)) });
				params.add(-1);
				List<Integer> modelIds = new ArrayList<Integer>();
				for (AsrAlertType alertType : param.getAlerts()) {
					modelIdsOr.add(Restrictions.eq("model.modelId", alertType.getAlertId()));
					modelIds.add(alertType.getAlertId());
					params.add(alertType.getAlertId());
				}
				subquery.add(modelIdsOr);
				// updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN,
				// aliases);
				// updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMODELJOIN,
				// aliases);

				// params.add(StringUtils.join(modelIds, ","));
				// c.add(Restrictions.in("model.modelId", modelIds));
				c.add(Subqueries.propertyIn("asrptId", subquery));

			}
			// ZR Type
			if (param.getZrTypes() != null && param.getZrTypes().size() > 0) {
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSZRLEFTJOIN, aliases);

				Disjunction zrTypes = Restrictions.or(new Criterion[] { Restrictions.eq("zrLeft.asrptId", -1) });
				params.add(-1);
				for (AsrGenericCode code : param.getZrTypes()) {

					String zrType = code.getCode();
					if ("NONE".equals(zrType.toUpperCase())) {
						zrTypes.add(Restrictions.isNull("zrLeft.npiNum"));
					} else if ("YES".equals(zrType.toUpperCase())) {
						zrTypes.add(Restrictions.isNotNull("zrLeft.npiNum"));
					} else {
						zrTypes.add(Restrictions.eq("zrLeft.ucmProcName", zrType));
						params.add(zrType);
					}

				}
				// params.add(subquery);
				c.add(zrTypes);
			}
			// City/State
			if (param.getCityStates() != null && param.getCityStates().size() > 0) {
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMATVIEWJOIN, aliases);

				Conjunction cityStates = Restrictions
						.and(new Criterion[] { Restrictions.eq("matVw.type", "CITYSTATE") });
				params.add("CITYSTATE");
				Disjunction cityStates2 = Restrictions.or(new Criterion[] { Restrictions.eq("matVw.asrptId", -1) });
				params.add(-1);
				for (AsrGenericCode code : param.getCityStates()) {

					String cityState = code.getCode();

					cityStates2.add(Restrictions.eq("matVw.value", cityState));
					params.add(cityState);

				}
				cityStates.add(cityStates2);
				c.add(cityStates);
			}
			// Edits
			if (param.getEdits() != null && param.getEdits().size() > 0) {
				// DetachedCriteria subquery =
				// DetachedCriteria.forClass(FpsAsrptEditSmryVw.class, "edits")
				// .setProjection(Projections.distinct(Projections.property("asrptId")));
				// Disjunction models = Restrictions
				// .or(new Criterion[] { });
				// //params.add(-1);
				// for (AsrGenericCode code : param.getEdits()) {
				//
				// String model = code.getCode();
				//
				// models.add(Restrictions.eq("modelName", model));
				//
				// params.add(model);
				// }
				// subquery.add(models);
				//
				// // params.add(subquery);
				// c.add(Subqueries.propertyIn("asrptId", subquery));
				//
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSEDITVIEWJOIN, aliases);

				Disjunction models = Restrictions.or(new Criterion[] {});

				for (AsrGenericCode code : param.getEdits()) {

					String model = code.getCode();

					models.add(Restrictions.eq("editsVw.modelName", model));

					params.add(model);

				}
				c.add(models);
			}
			// alert status
			if ((param.getAlertStatus() != null) && (param.getAlertStatus().size() > 0)) {
				List<String> statuses = new ArrayList<String>();
				List<String> currentOnly = Arrays.asList(("12"));
				List<String> recentOnly = Arrays.asList(("13"));
				List<String> both = Arrays.asList("13", "12");
				DetachedCriteria currentAlertAsctn = DetachedCriteria
						.forClass(FpsAsrptAlertAsctn.class, "currentAlertAsctn")
						.createAlias("currentAlertAsctn.fpsAlert", "currentAlert")
						.createAlias("currentAlertAsctn.fpsAsrpt", "currentAsrpt")
						.add(Restrictions.eq("currentAlert.alertStusCd", "12"))
						.setProjection(Projections.distinct(Projections.property("currentAsrpt.asrptId")));
				DetachedCriteria recentAlertAsctn = DetachedCriteria
						.forClass(FpsAsrptAlertAsctn.class, "recentAlertAsctn")
						.createAlias("recentAlertAsctn.fpsAlert", "recentAlert")
						.createAlias("recentAlertAsctn.fpsAsrpt", "recentAsrpt")

						.add(Restrictions.eq("recentAlert.alertStusCd", "13"))
						.setProjection(Projections.distinct(Projections.property("recentAsrpt.asrptId")));

				for (AsrAlertStatus alertStatus : param.getAlertStatus()) {
					statuses.add(alertStatus.getCode());
				}
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
				// 14 actually means "suspended/suppressed" but was not used at
				// the time
				// code was developed.
				if (statuses.contains("14") || (statuses.contains("12") && statuses.contains("13"))) {
					params.add("12");
					params.add("13");
					c.add(Subqueries.propertyIn("asrptId", currentAlertAsctn));
					c.add(Subqueries.propertyIn("asrptId", recentAlertAsctn));
				} else if (statuses.contains("12")) {
					params.add("12");
					params.add("13");
					c.add(Subqueries.propertyIn("asrptId", currentAlertAsctn));
					c.add(Subqueries.propertyNotIn("asrptId", recentAlertAsctn));

				} else if (statuses.contains("13")) {
					params.add("12");
					params.add("13");
					c.add(Subqueries.propertyNotIn("asrptId", currentAlertAsctn));
					c.add(Subqueries.propertyIn("asrptId", recentAlertAsctn));

				}
			}
			// preset search flag
			if (StringUtils.isNotBlank(param.getPresetSearchFlag())) {

				Calendar cal30 = Calendar.getInstance();
				cal30.add(Calendar.DATE, -30);
				Calendar cal180 = Calendar.getInstance();
				cal180.add(Calendar.DATE, -180);

				Object presetCol = "";
				String zone = loggedInUser.getBusinessCategory();
				FpsEnums.PreSetSearch pss = FpsEnums.PreSetSearch.getValue(param.getPresetSearchFlag());
				switch (pss) {
				case HIGHRISKASRS:
				case HIGHRISKUN:
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRZONELOOKUPJOIN, aliases);
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
					params.add(cal180);
					c.add(Restrictions.ge("alert.alertCreatDt", cal180));
					params.add(loggedInUser.getBusinessCategory());
					// params.add();
					c.add(Restrictions.eq("prvdrZnLookup.cntrctrCd", loggedInUser.getBusinessCategory()));
					params.add(0.5);
					c.add(Restrictions.gt("asrptRiskScreNum", 0.5));

					DetachedCriteria subqueryNotPriority = DetachedCriteria.forClass(FpsAsrptPrrty.class, "priority")

							.setProjection(Projections.property("priority.asrptId"))
							.add(Restrictions.eq("priority.cntrctrCd", loggedInUser.getBusinessCategory()));
					params.add(loggedInUser.getBusinessCategory());

					c.add(Subqueries.propertyNotIn("asrptId", subqueryNotPriority));
					if (addSuffixes) {
						c.addOrder(Order.desc("asrptRiskScreNum"));
						c.addOrder(Order.desc("asrptCstAmt"));
					}

					hasOrderBy = true;
					break;
				case MYASRS:
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSUSERJOIN, aliases);
					params.add(param.getLoggedInUserId());
					params.add("Y");
					c.add(Restrictions.eq("user.aplctnUserId", param.getLoggedInUserId()));
					c.add(Restrictions.eq("user.actvInd", "Y"));
					break;
				case ZONEASR:
				case ZASR:
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRZONELOOKUPJOIN, aliases);
					params.add(loggedInUser.getBusinessCategory());
					c.add(Restrictions.eq("prvdrZnLookup.cntrctrCd", loggedInUser.getBusinessCategory()));
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
					params.add(cal180);
					c.add(Restrictions.ge("alert.alertCreatDt", cal180));
					break;
				case ZONEWORKLOAD:
				case ZWL:
				case OTHERZONEWORKLOAD:
					String userZone = loggedInUser.getBusinessCategory();
					if (StringUtils.isBlank(userZone)) {
						userZone = "NONE";
					}
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTJOIN, aliases);

					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSUSERINVESTJOIN, aliases);
					params.add("11");

					c.add(Restrictions.eq("invest.stusCd", "11"));

					if (pss.equals(PreSetSearch.OTHERZONEWORKLOAD)) {
						params.add(userZone);
						c.add(Restrictions.ne("userInvest.asgnedCntrctr", userZone));
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRZONELOOKUPJOIN, aliases);
						params.add(loggedInUser.getBusinessCategory());
						c.add(Restrictions.eq("prvdrZnLookup.cntrctrCd", loggedInUser.getBusinessCategory()));

					} else {
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSRULINGJOIN, aliases);
						params.add(userZone);
						c.add(Restrictions.eq("userInvest.asgnedCntrctr", userZone));
						params.add("1");
						params.add("-1");
						c.add(Restrictions.ne("rulingRef.rulngCd", "1"));
						c.add(Restrictions.ne("rulingRef.rulngCd", "-1"));
					}
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
					params.add(cal180);
					c.add(Restrictions.ge("alert.alertCreatDt", cal180));
					break;
				case MYLI:
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTJOIN, aliases);
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSUSERINVESTJOIN, aliases);
					params.add(loggedInUser.getUserId());
					params.add("11");
					c.add(Restrictions.eq("userInvest.asgnedUserId", loggedInUser.getUserId()));
					c.add(Restrictions.eq("invest.stusCd", "11"));
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
					params.add(cal180);
					c.add(Restrictions.ge("alert.alertCreatDt", cal180));
					break;
				case ASR30:
				case MACASR30:
				case MACASR30NOUCM:
				case ASRNOUCM30:
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
					params.add(loggedInUser.getBusinessCategory());

					if (pss.equals(FpsEnums.PreSetSearch.ASR30) || pss.equals(FpsEnums.PreSetSearch.ASRNOUCM30)) {
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRZONELOOKUPJOIN, aliases);

						c.add(Restrictions.eq("prvdrZnLookup.cntrctrCd", loggedInUser.getBusinessCategory()));

						if (pss.equals(FpsEnums.PreSetSearch.ASRNOUCM30)) {
							DetachedCriteria noOpenUCM = DetachedCriteria.forClass(FpsAsrptInvstgtn.class, "openInvest")
									.createAlias("openInvest.fpsAsrptUserInvstgtns", "openUserInv")
									.add(Restrictions.eq("openUserInv.asgnedCntrctr",
											loggedInUser.getBusinessCategory()))
									.add(Restrictions.eq("openInvest.stusCd", "11"))
									.setProjection(Projections.distinct(Projections.property("openInvest.asrptId")));
							// updateAliases(c,
							// FpsEnums.AsrSearchCriteria.NEEDSINVESTLEFTJOIN,
							// aliases);
							params.add(loggedInUser.getBusinessCategory());
							params.add("11");
							// c.add(Restrictions.ne("investLeft.stusCd",
							// "11"));
							c.add(Subqueries.propertyNotIn("asrptId", noOpenUCM));
						}
					} else {
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSASRPTMACASCTNJOIN, aliases);
						c.add(Restrictions.eq("macLookup.macJurisdiction", loggedInUser.getBusinessCategory()));
						c.add(Restrictions.le("report.asrptRiskScreNum", "0.5"));
						params.add("0.5");
						if (pss.equals(FpsEnums.PreSetSearch.MACASR30NOUCM)) {
							DetachedCriteria noOpenUCM = DetachedCriteria.forClass(FpsAsrptInvstgtn.class, "openInvest")
									.add(Restrictions.eq("openInvest.stusCd", "11"))
									.setProjection(Projections.distinct(Projections.property("openInvest.asrptId")));
							// updateAliases(c,
							// FpsEnums.AsrSearchCriteria.NEEDSINVESTLEFTJOIN,
							// aliases);
							params.add("11");
							// c.add(Restrictions.ne("investLeft.stusCd",
							// "11"));
							c.add(Subqueries.propertyNotIn("asrptId", noOpenUCM));
						}
					}
					params.add(cal30.getTime());
					params.add(cal30.getTime());
					c.add(Restrictions.or(Restrictions.ge("alert.alertCreatDt", cal30.getTime()),
							Restrictions.ge("report.asrptCreatDt", cal30.getTime())));
					// c.add(Restrictions.isNull("investLeft.extrnlCaseId"));
					break;

				case ASRNOUCM:
				case MACNOUCM:
				case ASRPRIORITYNOUCM:
				case MACNOUCMCURRENT:

					params.add(loggedInUser.getBusinessCategory());

					if (pss.equals(FpsEnums.PreSetSearch.MACNOUCMCURRENT)
							|| pss.equals(FpsEnums.PreSetSearch.MACNOUCM)) {
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSASRPTMACASCTNJOIN, aliases);
						c.add(Restrictions.eq("macLookup.macJurisdiction", loggedInUser.getBusinessCategory()));
						c.add(Restrictions.le("report.asrptRiskScreNum", "0.5"));
						params.add("0.5");
						// c.add(Restrictions.ne("investLeft.stusCd", "11"));
						DetachedCriteria noOpenUCM = DetachedCriteria.forClass(FpsAsrptInvstgtn.class, "openInvest")
								.add(Restrictions.eq("openInvest.stusCd", "11"))
								.setProjection(Projections.distinct(Projections.property("openInvest.asrptId")));
						// updateAliases(c,
						// FpsEnums.AsrSearchCriteria.NEEDSINVESTLEFTJOIN,
						// aliases);

						// c.add(Restrictions.ne("investLeft.stusCd", "11"));
						c.add(Subqueries.propertyNotIn("asrptId", noOpenUCM));
						params.add("11");
						if (pss.equals(FpsEnums.PreSetSearch.MACNOUCMCURRENT)) {
							updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
							updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTSTUSREFJOIN, aliases);
							c.add(Restrictions.eq("alertStusRef.stusCd", "12"));
							params.add("12");
						}

					} else {
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTLEFTJOIN, aliases);
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRZONELOOKUPJOIN, aliases);
						c.add(Restrictions.eq("prvdrZnLookup.cntrctrCd", loggedInUser.getBusinessCategory()));
						c.add(Restrictions.isNull("investLeft.asrptId"));
						// DetachedCriteria subqueryUcm =
						// DetachedCriteria.forClass(FpsAsrptInvstgtn.class,
						// "ucm").add(Restrictions.isNotNull("ucm.extrnlCaseId"))
						//
						// .setProjection(Projections.property("ucm.asrptId"));
						// // params.add(subqueryRulings);
						// c.add(Subqueries.propertyNotIn( "asrptId" ,
						// subqueryUcm));
						if (pss.equals(FpsEnums.PreSetSearch.ASRPRIORITYNOUCM)) {
							// updateAliases(c,
							// FpsEnums.AsrSearchCriteria.NEEDSASRPRRTYJOIN,
							// aliases);
							DetachedCriteria subqueryPriority = DetachedCriteria
									.forClass(FpsAsrptPrrty.class, "priority")
									.add(Restrictions.eq("priority.cntrctrCd", loggedInUser.getBusinessCategory()))
									.setProjection(Projections.property("priority.asrptId"));
							params.add(loggedInUser.getBusinessCategory());
							c.add(Subqueries.propertyIn("asrptId", subqueryPriority));
						}
						if (pss.equals(FpsEnums.PreSetSearch.ASRUCMNOPRIORITY)) {
							// updateAliases(c,
							// FpsEnums.AsrSearchCriteria.NEEDSASRPRRTYJOIN,
							// aliases);
							DetachedCriteria subqueryPriority = DetachedCriteria
									.forClass(FpsAsrptPrrty.class, "priority")
									.add(Restrictions.eq("priority.cntrctrCd", loggedInUser.getBusinessCategory()))
									.setProjection(Projections.property("priority.asrptId"));
							// params.add(subqueryRulings);
							c.add(Subqueries.propertyNotIn("asrptId", subqueryPriority));
						}

					}
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
					params.add(cal180);
					c.add(Restrictions.ge("alert.alertCreatDt", cal180));
					break;
				case ASRUCMNOPRIORITY:

					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRZONELOOKUPJOIN, aliases);
					params.add(loggedInUser.getBusinessCategory());
					c.add(Restrictions.eq("prvdrZnLookup.cntrctrCd", loggedInUser.getBusinessCategory()));

					DetachedCriteria openUCM = DetachedCriteria.forClass(FpsAsrptInvstgtn.class, "openInvest")
							.createAlias("openInvest.fpsAsrptUserInvstgtns", "openUserInv")
							.add(Restrictions.eq("openInvest.stusCd", "11"))
							.add(Restrictions.eq("openInvest.recChgInd", "A"))
							.add(Restrictions.eq("openUserInv.asgnedCntrctr", loggedInUser.getBusinessCategory()))
							.add(Restrictions.isNotNull("openInvest.extrnlCaseId"))
							.setProjection(Projections.distinct(Projections.property("openInvest.asrptId")));
					// updateAliases(c,
					// FpsEnums.AsrSearchCriteria.NEEDSINVESTLEFTJOIN, aliases);

					// c.add(Restrictions.ne("investLeft.stusCd", "11"));
					c.add(Subqueries.propertyIn("asrptId", openUCM));
					params.add("11");
					params.add("A");
					params.add(loggedInUser.getBusinessCategory());

					DetachedCriteria subqueryPriority = DetachedCriteria.forClass(FpsAsrptPrrty.class, "priority")
							.add(Restrictions.eq("priority.cntrctrCd", loggedInUser.getBusinessCategory()))
							.setProjection(Projections.property("priority.asrptId"));
					// params.add(subqueryRulings);
					c.add(Subqueries.propertyNotIn("asrptId", subqueryPriority));
					params.add(loggedInUser.getBusinessCategory());

					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
					params.add(cal180);
					c.add(Restrictions.ge("alert.alertCreatDt", cal180));
					break;
				// case ASRNOUCM30:
				//
				// updateAliases(c,
				// FpsEnums.AsrSearchCriteria.NEEDSINVESTLEFTJOIN, aliases);
				// updateAliases(c,
				// FpsEnums.AsrSearchCriteria.NEEDSPRVDRZONELOOKUPJOIN,
				// aliases);
				// updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN,
				// aliases);
				// params.add(loggedInUser.getBusinessCategory());
				// params.add(cal.getTime());
				// params.add(cal.getTime());
				// c.add(Restrictions.eq("prvdrZnLookup.cntrctrCd",
				// loggedInUser.getBusinessCategory()));
				// c.add(Restrictions.isNull("investLeft.extrnlCaseId"));
				//
				// c.add(Restrictions.or(Restrictions.ge("alert.alertCreatDt",
				// cal.getTime()),
				// Restrictions.ge("report.asrptCreatDt", cal.getTime())));
				//
				// break;
				case ZWLSUSPCHANGE:
					String userZone2 = loggedInUser.getBusinessCategory();
					if (StringUtils.isBlank(userZone2)) {
						userZone2 = "NONE";
					}
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTJOIN, aliases);
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSRULINGJOIN, aliases);
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSUSERINVESTJOIN, aliases);
					params.add("4");
					params.add(userZone2);
					c.add(Restrictions.eq("rulingRef.rulngCd", "4"));
					c.add(Restrictions.eq("userInvest.asgnedCntrctr", userZone2));
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
					params.add(cal180);
					c.add(Restrictions.ge("alert.alertCreatDt", cal180));
					break;

				case MACRRB:
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSASRPTMACASCTNJOIN, aliases);
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSASRRRBCLMJOIN, aliases);

					params.add(zone);
					c.add(Restrictions.eq("macLookup.macJurisdiction", zone));
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
					params.add(cal30);
					c.add(Restrictions.ge("alert.alertCreatDt", cal30));

					DetachedCriteria noOpenUCMRrb = DetachedCriteria.forClass(FpsAsrptInvstgtn.class, "rrbOpenInvest")
							.createAlias("rrbOpenInvest.fpsAsrptUserInvstgtns", "rrbOpenInvestUser")
							.add(Restrictions.eq("rrbOpenInvestUser.asgnedCntrctr", zone))
							.add(Restrictions.eq("rrbOpenInvest.stusCd", "11"))
							.setProjection(Projections.distinct(Projections.property("rrbOpenInvest.asrptId")));
					params.add(zone);
					params.add("11");

					c.add(Subqueries.propertyNotIn("asrptId", noOpenUCMRrb));

					break;
				case MEDIC:

					DetachedCriteria noOpenUCMMedic = DetachedCriteria
							.forClass(FpsAsrptInvstgtn.class, "medicOpenInvest")
							.createAlias("medicOpenInvest.fpsAsrptUserInvstgtns", "medicOpenInvestUser")
							.add(Restrictions.eq("medicOpenInvestUser.asgnedCntrctr", zone))
							.add(Restrictions.eq("medicOpenInvest.stusCd", "11"))
							.setProjection(Projections.distinct(Projections.property("medicOpenInvest.asrptId")));
					params.add(zone);
					params.add("11");

					DetachedCriteria partD = DetachedCriteria.forClass(FpsAsrptStatMatVw.class, "claims")
							.add(Restrictions.eq("type", "CLAIM TYPE")).add(Restrictions.eq("value", "D"))
							.setProjection(Projections.distinct(Projections.property("asrptId")));

					params.add("CLAIM TYPE");
					params.add("D");

					// params.add(subquery);
					c.add(Subqueries.propertyNotIn("asrptId", noOpenUCMMedic));

					c.add(Subqueries.propertyIn("asrptId", partD));

					break;
				case ASRWITHCPIPRIORITY:
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRZONELOOKUPJOIN, aliases);
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMODELJOIN, aliases);
					params.add(loggedInUser.getBusinessCategory());
					params.add("Y");
					c.add(Restrictions.eq("prvdrZnLookup.cntrctrCd", loggedInUser.getBusinessCategory()));
					c.add(Restrictions.eq("model.priorityInd", "Y"));
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
					params.add(cal180);
					c.add(Restrictions.ge("alert.alertCreatDt", cal180));
					break;

				case ASRSUSPECT:
				case ZWLSUSPECT:
					String userZone3 = loggedInUser.getBusinessCategory();
					if (StringUtils.isBlank(userZone3)) {
						userZone3 = "NONE";
					}
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTJOIN, aliases);
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSRULINGJOIN, aliases);
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSUSERINVESTJOIN, aliases);
					params.add("6");
					params.add(userZone3);
					c.add(Restrictions.eq("rulingRef.rulngCd", "6"));
					c.add(Restrictions.eq("userInvest.asgnedCntrctr", userZone3));
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
					params.add(cal180);
					c.add(Restrictions.ge("alert.alertCreatDt", cal180));
					break;
				case ASRDEFAULT:
					c.setMaxResults(100);
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTSTUSREFJOIN, aliases);
					params.add(loggedInUser.getBusinessCategory());

					if (loggedInUser.getBusinessCategory() == null
							|| loggedInUser.getBusinessCategory().startsWith("UPIC")) {
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRZONELOOKUPJOIN, aliases);

						c.add(Restrictions.eq("prvdrZnLookup.cntrctrCd", loggedInUser.getBusinessCategory()));
						// c.add(Restrictions.ge("report.asrptRiskScreNum",
						// "0.5"));
					} else {
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSASRPTMACASCTNJOIN, aliases);
						c.add(Restrictions.eq("macLookup.macJurisdiction", loggedInUser.getBusinessCategory()));
						// c.add(Restrictions.le("report.asrptRiskScreNum",
						// "0.5"));

					}
					// params.add("0.5");
					Calendar defaultCal = Calendar.getInstance();
					defaultCal.add(Calendar.DATE, -60);
					c.add(Restrictions.gt("alert.alertCreatDt", defaultCal.getTime()));
					c.add(Restrictions.eq("alertStusRef.stusCd", "12"));
					params.add(defaultCal.getTime());
					params.add("12");

					break;
				default:
					params.add(Integer.valueOf(0));
					c.add(Restrictions.eq("asrptId", Integer.valueOf(0)));
				}
			}
			if (param.getCustomClaimLineLevel() != null) {
				FpsEnums.CustomClaimLineLevel cll = FpsEnums.CustomClaimLineLevel
						.getValue(param.getCustomClaimLineLevel());
				if (StringUtils.isBlank(param.getCustomClaimLineLevelParam())) {
					params.add(Integer.valueOf(0));
					c.add(Restrictions.eq("asrptId", Integer.valueOf(0)));
				} else {
					String claimLineLevelCol = "";
					String matViewType = null;
					String prvdrRole = null;
					switch (cll) {
					case ALERTTYPE:
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTREFJOIN, aliases);
						claimLineLevelCol = "alertRef.alertTypeCd";
						break;
					case BENEID:
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMATVIEWJOIN, aliases);

						claimLineLevelCol = "matVw.value";
						matViewType = "CLM HIC NUM";
						break;
					case BENESTATE:
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMATVIEWJOIN, aliases);
						claimLineLevelCol = "matVw.value";
						matViewType = "BENE STATE";
						// new
						break;
					case BILLNPI:
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRVIEWJOIN, aliases);
						claimLineLevelCol = "prvdrVw.prvdrNpiNum";
						prvdrRole = "Billing";

						break;
					case PROCEDURE:
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMATVIEWJOIN, aliases);
						claimLineLevelCol = "matVw.value";
						matViewType = "PROCEDURE";
						break;
					case PROVIDER:
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRJOIN, aliases);
						claimLineLevelCol = "prvdr.prvdrDrvdNpiName";
						break;
					case PTAN:
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMATVIEWJOIN, aliases);
						claimLineLevelCol = "matVw.value";
						matViewType = "PTAN";
						// new
						break;
					case REFERNPI:
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRVIEWJOIN, aliases);
						claimLineLevelCol = "prvdrVw.prvdrNpiNum";
						prvdrRole = "Referring";
						break;
					case SPECIALTY:
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMATVIEWJOIN, aliases);
						claimLineLevelCol = "matVw.value";
						matViewType = "PROVIDER SPECIALTY";
						break;
					case TAXID:
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMATVIEWJOIN, aliases);
						claimLineLevelCol = "matVw.value";
						matViewType = "TAX ID";
						break;
					case HCPCS:
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMATVIEWJOIN, aliases);
						claimLineLevelCol = "matVw.value";
						matViewType = "HCPCS";
						break;
					case DIAGNOSIS:
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMATVIEWJOIN, aliases);
						claimLineLevelCol = "matVw.value";
						matViewType = "DIAGNOSIS CODE";
						break;
					case ENROLLMENT:
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMATVIEWJOIN, aliases);
						claimLineLevelCol = "matVw.value";
						matViewType = "ENROLLMENT ID";
						break;
					default:
						claimLineLevelCol = "asrptId";
					}
					if (StringUtils.isNotBlank(claimLineLevelCol)) {
						switch (cll) {
						case PROVIDER:
							params.add("%" + param.getCustomClaimLineLevelParam() + "%");
							c.add(Restrictions.like(claimLineLevelCol,
									"%" + param.getCustomClaimLineLevelParam() + "%"));
							break;
						case NONE:
							params.add(Integer.valueOf(0));
							c.add(Restrictions.eq(claimLineLevelCol, Integer.valueOf(0)));

						default:
							params.add(param.getCustomClaimLineLevelParam());
							c.add(Restrictions.eq(claimLineLevelCol, param.getCustomClaimLineLevelParam()));
						}
					}
					if (StringUtils.isNotBlank(matViewType)) {
						params.add(matViewType);
						c.add(Restrictions.eq("matVw.type", matViewType));
					}
					if (StringUtils.isNotBlank(prvdrRole)) {
						params.add(prvdrRole);
						c.add(Restrictions.eq("prvdrVw.role", prvdrRole));
					}
				}
			}
			if (StringUtils.isNotBlank(param.getAsrptId())) {
				if (param.getAsrptId().length() < 10) {
					Integer asrptId = Integer.valueOf(0);
					try {
						asrptId = Integer.valueOf(Integer.parseInt(param.getAsrptId()));
					} catch (NumberFormatException localNumberFormatException) {
					}
					params.add(asrptId);
					c.add(Restrictions.eq("asrptId", asrptId));
				} else {
					params.add(param.getAsrptId());
					c.add(Restrictions.eq("subjId", param.getAsrptId()));
				}
			}
			if (StringUtils.isNotBlank(param.getPrvdrName())) {
				c.add(Restrictions.like("prvdr.prvdrDrvdNpiName", "%" + param.getPrvdrName() + "%"));
				params.add("%" + param.getPrvdrName() + "%");
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRJOIN, aliases);
			}
			if (StringUtils.isNotBlank(param.getCreatedMaxDt())) {
				try {
					Date d = format.parse(param.getCreatedMaxDt() + " 00:00:00");
					params.add(d);
					c.add(Restrictions.le("asrptCreatDt", d));
				} catch (ParseException e) {
					logger.log(Level.WARNING, "error parsing date", e);
					params.add(new Date());
					c.add(Restrictions.le("asrptCreatDt", new Date()));
				}
			}
			if (StringUtils.isNotBlank(param.getCreatedMinDt())) {
				try {
					Date d = format.parse(param.getCreatedMinDt() + " 00:00:00");
					params.add(d);
					c.add(Restrictions.ge("asrptCreatDt", d));
				} catch (ParseException e) {
					logger.log(Level.WARNING, "error parsing date", e);
					params.add(new Date());
					c.add(Restrictions.ge("asrptCreatDt", new Date()));
				}
			}
			if (param.getRiskScoreHigh() != null) {
				params.add(param.getRiskScoreHigh());
				c.add(Restrictions.le("asrptRiskScreNum", param.getRiskScoreHigh()));
			}
			if (param.getRiskScoreLow() != null) {
				params.add(param.getRiskScoreLow());
				c.add(Restrictions.ge("asrptRiskScreNum", param.getRiskScoreLow()));
			}
			if (param.getPriorityScoreHigh() != null || param.getPriorityScoreLow() != null) {
				DetachedCriteria priorityScore = DetachedCriteria
						.forClass(FpsAsrptPrrtyScreDtlVw.class, "priorityScore")
						.setProjection(Projections.property("priorityScore.asrptId"));
				if (param.getPriorityScoreHigh() != null) {
					priorityScore.add(Restrictions.le("priorityScore.totalScre", param.getPriorityScoreHigh()));
					params.add(param.getPriorityScoreHigh());

				}
				if (param.getPriorityScoreLow() != null) {
					priorityScore.add(Restrictions.ge("priorityScore.totalScre", param.getPriorityScoreLow()));
					params.add(param.getPriorityScoreLow());

				}
				priorityScore.add(Restrictions.eq("priorityScore.criteriaId", "99"));
				params.add("99");

				c.add(Subqueries.propertyIn("asrptId", priorityScore));
			}
			// CPI priority
			if (param.getModelPriority() != null) {
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMODELJOIN, aliases);

				if ("Yes".equals(param.getModelPriority())) {
					params.add("Y");
					c.add(Restrictions.eq("model.priorityInd", "Y"));
				} else {
					c.add(Restrictions.eq("model.priorityInd", "N"));
					params.add("N");
				}
			}
			// deprecated
			if (param.getLegacyScoreHigh() != null) {
				params.add(param.getLegacyScoreHigh());
				c.add(Restrictions.le("lgcyAsrptPrrtyScreNum", param.getLegacyScoreHigh()));
			}
			// deprecated
			if (param.getLegacyScoreLow() != null) {
				params.add(param.getLegacyScoreLow());
				c.add(Restrictions.ge("lgcyAsrptPrrtyScreNum", param.getLegacyScoreLow()));
			}

			if (addSuffixes) {
				if (param.getCostSortDir() != null) {
					FpsEnums.CostSortDir csd = FpsEnums.CostSortDir.getValue(param.getCostSortDir());
					switch (csd) {
					case H2L:
						c.addOrder(Order.desc("asrptCstAmt"));

						break;
					case L2H:
					default:
						c.addOrder(Order.asc("asrptCstAmt"));

						break;
					}
				} else if (!hasOrderBy) {
					c.addOrder(Order.desc("asrptRiskScreNum"));
					c.addOrder(Order.desc("asrptCstAmt"));
				}
			}
			if ((param.getActions() != null) && (param.getActions().size() > 0)) {
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTJOIN, aliases);
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTACTIONJOIN, aliases);
				List<String> actions = new ArrayList<String>();
				for (AsrAction action : param.getActions()) {
					actions.add(action.getCode());
					params.add(action.getCode());
				}
				// String actionSql = "'" + StringUtils.join(actions, "','") +
				// "'";
				// params.add(actionSql);
				c.add(Restrictions.in("actionRef.actnTypeCd", actions));
			}
			if ((param.getActivities() != null) && (param.getActivities().size() > 0)) {
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTJOIN, aliases);
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTACTIVITYJOIN, aliases);
				List<String> activitites = new ArrayList<String>();
				for (AsrActivity activity : param.getActivities()) {
					activitites.add(activity.getCode());
					params.add(activity.getCode());
				}
				// String activititesSql = "'" + StringUtils.join(activitites,
				// "','") + "'";
				// params.add(activititesSql);
				c.add(Restrictions.in("activityRef.actvtyTypeCd", activitites));
			}
		}
		if (params.size() > 0) {
			hasValidParams = true;
		}
		if (!hasValidParams) {
			params.add(Integer.valueOf(0));
			c.add(Restrictions.eq("asrptId", Integer.valueOf(0)));
		}
		return params;
	}
	private List<Object> buildCriteriaMedicaid(Criteria c, AsrSearchParameter request, boolean addSuffixes) {
		List<Object> params = new ArrayList<Object>();
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat shortFormat = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat ucmFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		boolean hasOrderBy = false;

		List<FpsEnums.AsrSearchCriteria> aliases = new ArrayList<AsrSearchCriteria>();
		// c.createAlias("report.fpsPrvdr", "prvdr", JoinType.LEFT_OUTER_JOIN);

		boolean hasValidParams = false;
		if ((request instanceof AsrSearchParameter)) {
			AsrSearchParameter param = request;
			FpsUser defaultUser = new FpsUser();
		
			FpsUser loggedInUser = null;
			if (StringUtils.isNotBlank(param.getLoggedInUserId())) {
//				LdapQuery query = buildBaseQuery();
//				query.setFilter("(uid=" + param.getLoggedInUserId() + ")");
//				query.setSearchVal(param.getLoggedInUserId());
				List<FpsUser> fpsUsers = LdapUtil.getUser(param.getLoggedInUserId());
				if (fpsUsers.size() == 0) {
					logger.fine("Ldap advanced search for " + param.getLoggedInUserId() + " returned " + fpsUsers.size()
							+ " results");
				}
				loggedInUser = fpsUsers != null && fpsUsers.size() > 0 ? fpsUsers.get(0) : null;
			}
			if (loggedInUser == null) {
				loggedInUser = defaultUser;
			}
			String userZone = loggedInUser.getBusinessCategory();
			if (userZone != null) {
				if (userZone.startsWith("J") || userZone.startsWith("DME")) {
					userZone = "MAC " + userZone;
				}
				if (userZone.startsWith("RRB")) {
					userZone = "RRB";
				}

			}
			String ucmZone = FpsDomainObjectConverter.convertFpsZoneToUcm(loggedInUser);
			// FPS-620
			// avoid returning ASR records with no alerts and no prioritizations
			// (summaryVisibleInd = N)
			// NAPS not valid for medicaid yet
//			DetachedCriteria napSubquery = DetachedCriteria.forClass(FpsAsrptSrcTypeVw.class, "naps");
//			napSubquery.setProjection(Projections.distinct(Projections.property("asrptId")));
//			napSubquery.add(Restrictions.ne("summaryVisibleInd", "N"));
//			params.add("N");
//			c.add(Subqueries.propertyIn("asrptId", napSubquery));

			logger.fine("using userid = " + loggedInUser.getUserId());
			logger.fine("using userzone = " + loggedInUser.getBusinessCategory());
//			updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
			String fullZone = loggedInUser.getBusinessCategory();
			UpicMappingEnum zoneEnum = UpicMappingEnum.getValueFromCd(fullZone);
			if (zoneEnum != UpicMappingEnum.OTHER) {
				fullZone = zoneEnum.getWithSpaces();
			}
			// multiple ASR IDs
			boolean isDbId = false;
			boolean isNpiId = false;
			if (request.getAsrptIds() != null) {
				for (Object o : request.getAsrptIds()) {
					if (o != null && o.toString().length() < 10 && StringUtils.isNumeric(o.toString())) {
						isDbId = true;
					} else {
						isNpiId = true;
					}
					// values over 10 characters are invalid
					if (o != null) {
						if (o.toString().length() > 10) {
							params.add("0");
						} else {
							// values with non alpha characters are invalid
							String clean = o.toString().replaceAll("[^0-9]", "");
							if (clean.length() != 10 && !clean.equals(o.toString())) {
								params.add("0");
							} else {
								params.add(clean);
							}
						}
					}
				}
				c.add(Restrictions.in(isDbId && !isNpiId ? "asrptId" : "subjId", request.getAsrptIds()));
			}
			// billing NPIs
			if (param.getBillingNpis() != null) {
				DetachedCriteria billingCriteria = DetachedCriteria.forClass(FpsAsrptSummaryBillingPrvdrsMdcd.class, "billingNpi")
						.setProjection(Projections.distinct(Projections.property("id.asrptId")));

				List<Object> billinNpis = new ArrayList<Object>();
				for (Object billingNpi : param.getBillingNpis()) {
					billinNpis.add(billingNpi);
					params.add(billingNpi);
				}

				billingCriteria.add(Restrictions.in("id.billingPrvdrNpi", billinNpis));
				c.add(Subqueries.propertyIn("asrptId", billingCriteria));
			}
//			// specialties
			if (param.getSpecialtyCds() != null) {
				DetachedCriteria specialtiesCriteria = DetachedCriteria.forClass(FpsAsrptSummarySpecialtiesMdcd.class, "specialties")
						.setProjection(Projections.distinct(Projections.property("id.asrptId")));

				List<String> specialties = new ArrayList<String>();
				for (AsrGenericCode specialty : param.getSpecialtyCds()) {
					specialties.add(specialty.getCode());
					params.add(specialty.getCode());
				}

				specialtiesCriteria.add(Restrictions.in("id.prvdrSpcltyCd", specialties));
				c.add(Subqueries.propertyIn("asrptId", specialtiesCriteria));
			}
			
			// ASR State
			if ((param.getStates() != null) && (param.getStates().size() > 0)) {
				DetachedCriteria statesCriteria = DetachedCriteria.forClass(FpsAsrptSummaryStateFilterMdcd.class, "states")
						.setProjection(Projections.distinct(Projections.property("id.asrptId")));

				List<String> states = new ArrayList<>();
				for (AsrState state : param.getStates()) {
					states.add(state.getCode());
					params.add(state.getCode());
				}

				statesCriteria.add(Restrictions.in("id.geoMdcdUspsStateCd", states));
				c.add(Subqueries.propertyIn("asrptId", statesCriteria));
			}
			// ASR created dates
			if (StringUtils.isNotBlank(param.getCreatedMaxDt()) || StringUtils.isNotBlank(param.getCreatedMinDt())) {
				c.createAlias("report.fpsAsrptMdcd", "fpsAsrptMdcd");

				if (StringUtils.isNotBlank(param.getCreatedMaxDt())) {
					try {
						Date d = format.parse(param.getCreatedMaxDt() + " 00:00:00");
						params.add(d);
						c.add(Restrictions.le("fpsAsrptMdcd.asrptCreatDt", d));
					} catch (ParseException e) {
						logger.log(Level.WARNING, "error parsing date", e);
						params.add(new Date());
						c.add(Restrictions.le("fpsAsrptMdcd.asrptCreatDt", new Date()));
					}
				}
	
				if (StringUtils.isNotBlank(param.getCreatedMinDt())) {
					try {
						Date d = format.parse(param.getCreatedMinDt() + " 00:00:00");
						params.add(d);
						c.add(Restrictions.ge("fpsAsrptMdcd.asrptCreatDt", d));
					} catch (ParseException e) {
						logger.log(Level.WARNING, "error parsing date", e);
						params.add(new Date());
						c.add(Restrictions.ge("fpsAsrptMdcd.asrptCreatDt", new Date()));
					}
				}

			}
		

		
			// jurisdictions
			if ((param.getJurisdictions() != null) && (param.getJurisdictions().size() > 0)) {

				DetachedCriteria zoneCriteria = DetachedCriteria.forClass(FpsAsrptSummaryJurisdictionFilterMdcd.class, "zoneCriteria")
						.setProjection(Projections.distinct(Projections.property("id.asrptId")));

				List<String> zones = new ArrayList<String>();
				for (AsrGenericCode zone : param.getJurisdictions()) {
					UpicMappingEnum e = UpicMappingEnum.getValueFromCd(zone.getCode());
					zones.add(e.getWithSpaces());
					params.add(e.getWithSpaces());
				}

				zoneCriteria.add(Restrictions.in("id.upicJurisdiction", zones));
				c.add(Subqueries.propertyIn("asrptId", zoneCriteria));

			}
			

			// service type
			if (CollectionUtils.isNotEmpty(param.getMdcdSvcTypes())) {
				DetachedCriteria svcTypeCriteria = DetachedCriteria.forClass(FpsAsrptSummaryServiceTypeFilterMdcd.class, "svcTypeCriteria")
						.setProjection(Projections.distinct(Projections.property("id.asrptId")));

				List<String> svcTypes = new ArrayList<String>();
				for (AsrGenericCode svcType : param.getMdcdSvcTypes()) {
					svcTypes.add(svcType.getCode());
					params.add(svcType.getCode());
				}

				svcTypeCriteria.add(Restrictions.in("id.clmSrvcTypeDesc", svcTypes));
				c.add(Subqueries.propertyIn("asrptId", svcTypeCriteria));
			}
			// service category
			if (CollectionUtils.isNotEmpty(param.getMdcdSvcCats())) {
				DetachedCriteria svcCatCriteria = DetachedCriteria.forClass(FpsAsrptSummaryServiceCategoryFilterMdcd.class, "svcCatCriteria")
						.setProjection(Projections.distinct(Projections.property("id.asrptId")));

				List<String> svcCats = new ArrayList<String>();
				for (AsrGenericCode svcCat : param.getMdcdSvcCats()) {
					svcCats.add(svcCat.getCode());
					params.add(svcCat.getCode());
				}

				svcCatCriteria.add(Restrictions.in("id.clmSrvcCtgryDesc", svcCats));
				c.add(Subqueries.propertyIn("asrptId", svcCatCriteria));
			}	
			// service sub category
			if (CollectionUtils.isNotEmpty(param.getMdcdSvcSubCats())) {
				DetachedCriteria svcSubCatCriteria = DetachedCriteria.forClass(FpsAsrptSummaryServiceSubcategoryFilterMdcd.class, "svcSubCatCriteria")
						.setProjection(Projections.distinct(Projections.property("id.asrptId")));

				List<String> svcSubCats = new ArrayList<String>();
				for (AsrGenericCode svcSubCat : param.getMdcdSvcSubCats()) {
					String code = svcSubCat.getCode();
					if (code.equals("MCO")) code = "Encounter";
					svcSubCats.add(code);
					params.add(code);
				}

				svcSubCatCriteria.add(Restrictions.in("id.clmSrvcSbctgryDesc", svcSubCats));
				c.add(Subqueries.propertyIn("asrptId", svcSubCatCriteria));
			}	
			// roles
			if (CollectionUtils.isNotEmpty(param.getMdcdRoles())) {
				DetachedCriteria rolesCriteria = DetachedCriteria.forClass(FpsAsrptSummaryRltdPrvdrsMdcd.class, "rolesCriteria")
						.setProjection(Projections.distinct(Projections.property("id.asrptId")));

				List<String> roles = new ArrayList<String>();
				for (AsrGenericCode role : param.getMdcdRoles()) {
					roles.add(role.getCode());
					params.add(role.getCode());
				}

				rolesCriteria.add(Restrictions.in("id.npiAlertTypeDesc", roles));
				c.add(Subqueries.propertyIn("asrptId", rolesCriteria));
			}	
			// lead/INV
			if (CollectionUtils.isNotEmpty(param.getLeadInvestigationInd())) {
				hasValidParams = true;
				DetachedCriteria subquery = DetachedCriteria
						.forClass(FpsAsrptInvstgnStusSmryVw.class, "asrptForLeadInv")
						.setProjection(Projections.distinct(Projections.property("asrptId")));
				
				AsrGenericCode noneCode = new AsrGenericCode("None");
				boolean hasOther = !param.getLeadInvestigationInd().contains(noneCode);
				if ("Yes".equals(param.getMyZoneOnlyInd()) && hasOther) {
					subquery.add(Restrictions.or(Restrictions.eq("asrptForLeadInv.openZone", userZone),
							Restrictions.eq("asrptForLeadInv.closedZone", userZone)));
					params.add(userZone);
					params.add(userZone);
				}
				Disjunction leadInvOr = Restrictions.or(new Criterion[] {});
				Disjunction leadInvOrRoot = Restrictions.or(new Criterion[] {});
				Conjunction leadInvOrWithNone = Restrictions.and(new Criterion[] {});
				// boolean addOpenStatusY = false;
				// boolean addOpenStatusN = false;
				boolean hasNone = false;

				for (AsrGenericCode code : param.getLeadInvestigationInd()) {

					String leadInvInd = code.getCode();
					if ("None".equals(leadInvInd)) {
						hasNone = true;
					} else {
						leadInvOr.add(Restrictions.eq("asrptForLeadInv.type", leadInvInd));
						params.add(leadInvInd);
						hasOther = true;
					}
					// addOpenStatusY = true;

				}

				if (hasNone) {
					DetachedCriteria subqueryHasNone = DetachedCriteria
							.forClass(FpsAsrptInvstgtn.class, "asrptForLeadInvNone")
							.createAlias("asrptForLeadInvNone.fpsAsrptUserInvstgtns", "asrptForLeadInvNoneUser")
							.setProjection(Projections.distinct(Projections.property("asrptId")));
					subqueryHasNone.add(Restrictions.isNotNull("asrptForLeadInvNone.extrnlCaseId"));

					if ("Yes".equals(param.getMyZoneOnlyInd())) {
						subqueryHasNone.add(Restrictions.eq("asrptForLeadInvNoneUser.asgnedCntrctr", userZone));
						params.add(userZone);
					}
					leadInvOrWithNone.add(Subqueries.propertyNotIn("asrptId", subqueryHasNone));
					leadInvOrRoot.add(leadInvOrWithNone);

				}
				if (hasOther) {
					subquery.add(leadInvOr);
					leadInvOrRoot.add(Subqueries.propertyIn("asrptId", subquery));

				}
				c.add(leadInvOrRoot);

				// if (addOpenStatus) {
				// params.add("11");
				// }
				// params.add(subquery);
			}

				// UCM Case ID
			if (StringUtils.isNotEmpty(param.getUcmCaseId())) {
				DetachedCriteria subquery = DetachedCriteria
				.forClass(FpsAsrptInvstgtn.class, "asrptForUcmCaseId")
				.setProjection(Projections.distinct(Projections.property("asrptId")));
				subquery.add(Restrictions.eq("asrptForUcmCaseId.extrnlCaseId", param.getUcmCaseId()));
				subquery.add(Restrictions.eq("asrptForUcmCaseId.actvInd", "Y"));
				params.add(param.getUcmCaseId());
				params.add("Y");
				c.add(Subqueries.propertyIn("asrptId", subquery));

			}
			// UCM ASR ID
			if (StringUtils.isNotEmpty(param.getUcmAsrId())) {

				DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrptMdcd.class, "asrpt");
				subquery.setProjection(Projections.distinct(Projections.property("asrptId")));
				subquery.add(Restrictions.eq("asrpt.ucmAsrId", param.getUcmAsrId()));
				params.add(param.getUcmAsrId());

				c.add(Subqueries.propertyIn("asrptId", subquery));

			}
			
			// alert types (model names)
			if ((param.getAlerts() != null) && (param.getAlerts().size() > 0)) {
				DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrptAlertAsctnMdcd.class, "asrAlerts")
						.createAlias("asrAlerts.fpsAlert", "alerts", JoinType.INNER_JOIN)
						.createAlias("asrAlerts.fpsAsrpt", "asr", JoinType.INNER_JOIN)
						.createAlias("alerts.fpsModel", "model", JoinType.INNER_JOIN)

						.setProjection(Projections.distinct(Projections.property("asr.asrptId")));

				
				Conjunction landingQuery = null;
				Disjunction modelIdsOr = Restrictions.or(new Criterion[] {});
//				List<Integer> modelIds = new ArrayList<Integer>();
				for (AsrAlertType alertType : param.getAlerts()) {
					modelIdsOr.add(Restrictions.eq("model.modelId", alertType.getAlertId()));
//					modelIds.add(alertType.getAlertId());
					params.add(alertType.getAlertId());
				}
				if (param.getModelRunDt() != null) {
					landingQuery = Restrictions.and(new Criterion[] {});
					landingQuery.add(modelIdsOr);
					Date d = new Date();
					Calendar cal = Calendar.getInstance();
					try {
						d = shortFormat.parse(param.getModelRunDt() );
						
						cal.setTime(d);
						landingQuery.add(Restrictions.eq("alerts.alertCreatDt", d));

						
					} catch (ParseException e) {
						landingQuery.add(Restrictions.eq("alerts.alertCreatDt",d));
						
					}
					params.add(d);
					
				}
				
				if (landingQuery != null) {
					subquery.add(landingQuery);
	
				}else {
					
					subquery.add(modelIdsOr);
				}
				c.add(Subqueries.propertyIn("asrptId", subquery));
			}
			
			// ZR Type
			if (param.getZrTypes() != null && param.getZrTypes().size() > 0) {
				c.createAlias("report.fpsNpiZrSmrys", "zrStatuses", JoinType.LEFT_OUTER_JOIN);
				List<String> zrTypes = new ArrayList<String>();
				boolean hasNo = false;
				for (AsrGenericCode code : param.getZrTypes()) {
					// Yes
					// Yes - Partial
					// Yes - Full  - Full ZR
					// Yes - Extended					
					params.add(code.getCode());
					zrTypes.add(code.getCode());
					if ("no".equalsIgnoreCase(code.getCode())) {
						hasNo = true;
					}

				}
				if (hasNo) {
					c.add(Restrictions.or(Restrictions.in("zrStatuses.zrTxt", zrTypes), Restrictions.isNull("zrStatuses.zrTxt")));
				}else {
					c.add(Restrictions.in("zrStatuses.zrTxt", zrTypes));
				}
			}

		

			// alert status
			if ((param.getAlertStatus() != null) && (param.getAlertStatus().size() > 0)) {
				List<String> statuses = new ArrayList<String>();

				
				DetachedCriteria alertStatusCriteria = DetachedCriteria.forClass(FpsAsrptSummaryAlertsMdcd.class, "alertStatusCriteria")
						.setProjection(Projections.distinct(Projections.property("id.asrptId")));

				for (AsrAlertStatus alertStatus : param.getAlertStatus()) {
					statuses.add(alertStatus.getCode());
					params.add(alertStatus.getCode());

				}

				alertStatusCriteria.add(Restrictions.in("id.alertStusCd", statuses));
				c.add(Subqueries.propertyIn("asrptId", alertStatusCriteria));

			}
			// asr ID
			if (StringUtils.isNotBlank(param.getAsrptId())) {
				if (param.getAsrptId().length() < 10) {
					Integer asrptId = Integer.valueOf(0);
					try {
						asrptId = Integer.valueOf(Integer.parseInt(param.getAsrptId()));
					} catch (NumberFormatException localNumberFormatException) {
					}
					params.add(asrptId);
					c.add(Restrictions.eq("asrptId", asrptId));
				} else {
					params.add(param.getAsrptId());
					c.add(Restrictions.eq("subjId", param.getAsrptId()));
				}
			}
			// name
			if (StringUtils.isNotBlank(param.getPrvdrName())) {
				c.add(Restrictions.like("subjDsplyName", "%" + param.getPrvdrName() + "%").ignoreCase());
				params.add("%" + param.getPrvdrName().toLowerCase() + "%");

			}
			// risk score high
			if (param.getRiskScoreHigh() != null) {
				params.add(param.getRiskScoreHigh());
				c.add(Restrictions.le("asrptRiskScreNum", param.getRiskScoreHigh()));
			}
			// risk score low
			if (param.getRiskScoreLow() != null) {
				params.add(param.getRiskScoreLow());
				c.add(Restrictions.ge("asrptRiskScreNum", param.getRiskScoreLow()));
			}
			if (param.getAsrCostHigh() != null) {
				params.add(param.getAsrCostHigh());
				c.add(Restrictions.le("asrptCstAmt", param.getAsrCostHigh()));
			}
			if (param.getAsrCostLow() != null) {
				params.add(param.getAsrCostLow());
				c.add(Restrictions.ge("asrptCstAmt", param.getAsrCostLow()));
			}



//			Yes - My Jurisdiction 
//			 No - My Jurisdiction 
//			 Yes - Not My Jurisdiction
//			 No - Not My Jurisdiction
// prioritization types
			if (param.getPrioritizeTypes() != null && param.getPrioritizeTypes().size() > 0) {
				Disjunction prrtyZone = Restrictions.or(new Criterion[] {});
				Disjunction prrtyZoneCntrctrCd = Restrictions.or(new Criterion[] {});

				boolean prrtyMyZoneY = false;
				boolean prrtyMyZoneN = false;
				boolean prrtyOtherZoneY = false;
				boolean prrtyOtherZoneN = false;
				for (AsrGenericCode p : param.getPrioritizeTypes()) {
					if ("60".equals(p.getCode())) {
						DetachedCriteria prrtyByZoneMyY = DetachedCriteria
								.forClass(FpsAsrptPrrtyMdcd.class, "prrtyByZoneMyY")
								.setProjection(Projections.distinct(Projections.property("prrtyByZoneMyY.asrptId")))
								.add(Restrictions.eq("prrtyByZoneMyY.cntrctrCd", loggedInUser.getBusinessCategory()));
						params.add(loggedInUser.getBusinessCategory());
						prrtyZone.add(Subqueries.propertyIn("asrptId", prrtyByZoneMyY));

					} else if ("61".equals(p.getCode())) {
						DetachedCriteria prrtyByZoneMyN = DetachedCriteria
								.forClass(FpsAsrptPrrtyMdcd.class, "prrtyByZoneMyN")
								.setProjection(Projections.distinct(Projections.property("prrtyByZoneMyN.asrptId")))
								.add(Restrictions.eq("prrtyByZoneMyN.cntrctrCd", loggedInUser.getBusinessCategory()));
						params.add(loggedInUser.getBusinessCategory());
						prrtyZone.add(Subqueries.propertyNotIn("asrptId", prrtyByZoneMyN));

					} else if ("62".equals(p.getCode())) {
						DetachedCriteria prrtyByZoneNotMyY = DetachedCriteria
								.forClass(FpsAsrptPrrtyMdcd.class, "prrtyByZoneNotMyY")
								.setProjection(Projections.distinct(Projections.property("prrtyByZoneNotMyY.asrptId")))
								.add(Restrictions.ne("prrtyByZoneNotMyY.cntrctrCd",
										loggedInUser.getBusinessCategory()));
						params.add(loggedInUser.getBusinessCategory());
						prrtyZone.add(Subqueries.propertyIn("asrptId", prrtyByZoneNotMyY));

					} else if ("63".equals(p.getCode())) {
						DetachedCriteria prrtyByZoneNotMyN = DetachedCriteria
								.forClass(FpsAsrptPrrtyMdcd.class, "prrtyByZoneNotMyN")
								.setProjection(Projections.distinct(Projections.property("prrtyByZoneNotMyN.asrptId")))
								.add(Restrictions.ne("prrtyByZoneNotMyN.cntrctrCd",
										loggedInUser.getBusinessCategory()));
						params.add(loggedInUser.getBusinessCategory());
						prrtyZone.add(Subqueries.propertyNotIn("asrptId", prrtyByZoneNotMyN));

					}
				}

				c.add(prrtyZone);

			}

		
			
			// lead indicator
			if (param.getLeadInd() != null) {
				DetachedCriteria exCriteria = DetachedCriteria.forClass(FpsPrvdrAnlysMdcdJurisdiction.class, "leadIndJuris")

						.setProjection(Projections.distinct(Projections.property("leadIndJuris.asrptId")));

				if ("Yes".equals(param.getLeadInd())) {
					exCriteria.add(Restrictions.eq("leadIndJuris.leadInd", "Y"));
					params.add("Y");

				} else {
					DetachedCriteria exCriteriaNo = DetachedCriteria
							.forClass(FpsPrvdrAnlysMdcdJurisdiction.class, "leadIndJurisNo")

							.setProjection(Projections.distinct(Projections.property("leadIndJurisNo.asrptId")));
					exCriteriaNo.add(Restrictions.eq("leadIndJurisNo.leadInd", "N"));
					params.add("N");

					DetachedCriteria exCriteriaYes = DetachedCriteria
							.forClass(FpsPrvdrAnlysMdcdJurisdiction.class, "leadIndJurisNotYes")

							.setProjection(Projections.distinct(Projections.property("leadIndJurisNotYes.asrptId")));

					exCriteriaYes.add(Restrictions.eq("leadIndJurisNotYes.leadInd", "Y"));
					params.add("Y");
					exCriteria.add(Subqueries.propertyIn("asrptId", exCriteriaNo));

					exCriteria.add(Subqueries.propertyNotIn("asrptId", exCriteriaYes));

				}
				c.add(Subqueries.propertyIn("asrptId", exCriteria));

			}
		
		
			// ASR in working set
			if (param.getAsrWorkingSetInd() != null && param.getAsrWorkingSetInd().size() > 0) {
				DetachedCriteria wsCriteria = DetachedCriteria
						.forClass(VwFpsAsrptListUserJrsdctnDtlVwMdcd.class, "workingset")

						.setProjection(Projections.distinct(Projections.property("workingset.asrptId")));
				Disjunction wsCriteriaOr = Restrictions.or(new Criterion[] {});
				for (AsrGenericCode p : param.getAsrWorkingSetInd()) {
					if ("1".equals(p.getCode())) {
						wsCriteriaOr.add(Restrictions.eq("workingset.wsUserId", loggedInUser.getUserId().toLowerCase())
								.ignoreCase());
						params.add(loggedInUser.getUserId().toLowerCase());
					} else if ("2".equals(p.getCode())) {
						wsCriteriaOr.add(Restrictions.and(
								Restrictions.ne("workingset.wsUserId", loggedInUser.getUserId().toLowerCase())
										.ignoreCase(),
								Restrictions.eq("workingset.wsMyJrsdctn", loggedInUser.getBusinessCategory())));
						params.add(loggedInUser.getUserId().toLowerCase());
						params.add(loggedInUser.getBusinessCategory());
					}
				}
				wsCriteria.add(wsCriteriaOr);
				c.add(Subqueries.propertyIn("asrptId", wsCriteria));
			}
			// exclusions
			if (param.getExclusions() != null && param.getExclusions().size() > 0) {
//				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSEXCLUSIONJOIN, aliases);

				DetachedCriteria exCriteria = DetachedCriteria
						.forClass(FpsMdcdExclusionSearch.class, "exclusions")

						.setProjection(Projections.distinct(Projections.property("exclusions.asrptId")));
				Junction exs = null;
				boolean isOr = "Or".equals(param.getExclusionOrInd()) || StringUtils.isBlank(param.getExclusionOrInd());
				if (isOr) {
					exs = Restrictions.or(new Criterion[] {});
				} else {
					exs = Restrictions.and(new Criterion[] {});
				}

				for (AsrGenericCode code : param.getExclusions()) {

					String ex = code.getCode();
					if ("And".equals(param.getExclusionOrInd())) {
						DetachedCriteria exCriteriaAnd = DetachedCriteria
								.forClass(FpsMdcdExclusionSearch.class, "exclusionsAnd")

								.setProjection(Projections.distinct(Projections.property("exclusionsAnd.asrptId")));
						if (ex.startsWith("ASRSET")) {
							// if is my working set 
							if ("ASRSET_MY_WS".equals(ex) ) {
								exCriteriaAnd.add(
										Restrictions.and(Restrictions.eq("exclusionsAnd.exclusionCd", ex), Restrictions
												.eq("exclusionsAnd.cntrctrCd", loggedInUser.getUserId()).ignoreCase()));
								params.add(ex);
								params.add(loggedInUser.getUserId().toLowerCase());
							} else if ("ASRSET_MY_WS_JRSDCTN".equals(ex) ) {
								// if WS is in my jurisdiction

								exCriteriaAnd.add(Restrictions.and(Restrictions.eq("exclusionsAnd.exclusionCd", ex),
										Restrictions.ne("exclusionsAnd.ownerId", loggedInUser.getUserId())
												.ignoreCase(),
										Restrictions.eq("exclusionsAnd.cntrctrCd",
												loggedInUser.getBusinessCategory())));
								params.add(ex);
								params.add(loggedInUser.getUserId().toLowerCase());
								params.add(loggedInUser.getBusinessCategory());
								

							}
						} else {

							exCriteriaAnd.add(Restrictions.eq("exclusionsAnd.exclusionCd", ex));

							params.add(ex);
							if ((ex.equals("ADMIN_ACTION") || ex.equals("CASE_CLOSED") || ex.equals("UCM_CLOSED60") || ex.equals("UCM_OPEN"))
									&& (!"CMS".equals(loggedInUser.getBusinessCategory()) && !FpsDomainObjectConverter
											.isPimascContractor(loggedInUser.getBusinessCategory()))) {
								exCriteriaAnd.add(Restrictions.eq("exclusions.cntrctrCd", fullZone));
								params.add(fullZone);
							}
						}
						// exclusions by zone not yet supported
//						if ("Yes".equals(param.getExclusionMyZoneInd())) {
//
//							Disjunction zones = Restrictions
//									.or(new Criterion[] { Restrictions.eq("exclusionsAnd.cntrctrCd", fullZone),
//											Restrictions.isNull("exclusionsAnd.cntrctrCd") });
//							
//							params.add(fullZone);
//							exCriteriaAnd.add(zones);
//						}
						exCriteria.add(Subqueries.propertyIn("asrptId", exCriteriaAnd));

					} else {

						if (ex.startsWith("ASRSET")) {
							if ("ASRSET_MY_WS".equals(ex) || "ASRSET_MY_EX".equals(ex)) {
								exs.add(Restrictions.and(Restrictions.eq("exclusions.exclusionCd", ex), Restrictions
										.eq("exclusions.cntrctrCd", loggedInUser.getUserId()).ignoreCase()));
								params.add(ex);
								params.add(loggedInUser.getUserId().toLowerCase());
							} else if ("ASRSET_MY_WS_JRSDCTN".equals(ex) || "ASRSET_MY_EX_JRSDCTN".equals(ex)) {
								if ("ASRSET_MY_EX_JRSDCTN".equals(ex)) {
									if ("CMS".equals(loggedInUser.getBusinessCategory()) || FpsDomainObjectConverter
											.isPimascContractor(loggedInUser.getBusinessCategory())) {
										// if I am CMS/PIMASC, don't check zone
										exs.add(Restrictions.and(Restrictions.eq("exclusions.exclusionCd", ex),
												Restrictions.ne("exclusions.ownerId", loggedInUser.getUserId())
														.ignoreCase()));
										params.add(ex);
										params.add(loggedInUser.getUserId().toLowerCase());

									} else {
										// if I am not CMS/PIMASC, check for zone match
										exs.add(Restrictions.and(Restrictions.eq("exclusions.exclusionCd", ex),
												Restrictions.ne("exclusions.ownerId", loggedInUser.getUserId())
														.ignoreCase(),
												Restrictions.eq("exclusions.cntrctrCd",
														loggedInUser.getBusinessCategory()),
												Restrictions.eq("exclusions.publicInd", "Y")));
										params.add(ex);
										params.add(loggedInUser.getUserId().toLowerCase());
										params.add(loggedInUser.getBusinessCategory());
										params.add("Y");
									}
								} else {
									exs.add(Restrictions.and(Restrictions.eq("exclusions.exclusionCd", ex),
											Restrictions.ne("exclusions.ownerId", loggedInUser.getUserId())
													.ignoreCase(),
											Restrictions.eq("exclusions.cntrctrCd",
													loggedInUser.getBusinessCategory())));
									params.add(ex);
									params.add(loggedInUser.getUserId().toLowerCase());
									params.add(loggedInUser.getBusinessCategory());
								}

							}
						} else {
							
							if ((ex.equals("ADMIN_ACTION") || ex.equals("CASE_CLOSED") || ex.equals("UCM_CLOSED60") || ex.equals("UCM_OPEN"))
									&& (!"CMS".equals(loggedInUser.getBusinessCategory()) && !FpsDomainObjectConverter
											.isPimascContractor(loggedInUser.getBusinessCategory()))) {
							
								exs.add(Restrictions.and(Restrictions.eq("exclusions.exclusionCd", ex),
										Restrictions.eq("exclusions.cntrctrCd",
												fullZone)));
								params.add(ex);
								params.add(fullZone);
							}else {
								exs.add(Restrictions.eq("exclusions.exclusionCd", ex));
								params.add(ex);
							}
						}
					}

				}
				if (isOr) {
					exCriteria.add(exs);
					// exclusions by zone not yet supported
//					if ("Yes".equals(param.getExclusionMyZoneInd())) {
//
//						Disjunction zones = Restrictions
//								.or(new Criterion[] { Restrictions.eq("exclusions.cntrctrCd", fullZone),
//										Restrictions.isNull("exclusions.cntrctrCd") });
//						// Restrictions.eq("exclusions.cntrctrCd", fullZone),
//						// Restrictions.isNull("exclusions.cntrctrCd") });
//						params.add(fullZone);
//						exCriteria.add(zones);
//					}

				}
				c.add(Subqueries.propertyNotIn("asrptId", exCriteria));

			}


			if (addSuffixes) {
				if (param.getCostSortDir() != null) {
					FpsEnums.CostSortDir csd = FpsEnums.CostSortDir.getValue(param.getCostSortDir());
					switch (csd) {
					case H2L:
						c.addOrder(Order.desc("asrptCstAmt"));

						break;
					case L2H:
					default:
						c.addOrder(Order.asc("asrptCstAmt"));

						break;
					}
				} else if (!hasOrderBy) {
					c.addOrder(Order.desc("asrptRiskScreNum"));
					c.addOrder(Order.desc("asrptCstAmt"));
				}
			}

			if (params.size() > 0) {
				hasValidParams = true;
			}
			if (!hasValidParams) {
				params.add(Integer.valueOf(0));
				c.add(Restrictions.eq("asrptId", Integer.valueOf(0)));
			}
		}
		return params;


	}
	private List<Object> buildCriteriaProviderAnalsys(Criteria c, AsrSearchParameter request, boolean addSuffixes) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat shortFormat = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat ucmFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		List<Object> params = new ArrayList<Object>();
		boolean hasOrderBy = false;
		boolean p1Enabled = false;
		if (!"true".equals(p1EnabledInd)) {
			FpsUsrGuiPrfrnc p1EnabledIndPref = fpsTrackingDao.loadUserPrefs("FPSP1", "p1EnabledInd");
			p1Enabled = ((p1EnabledIndPref!= null && "true".equals(p1EnabledIndPref.getPrfrncOptions())?true:false));
		}else {
			p1Enabled = (true);
		}

		List<FpsEnums.AsrSearchCriteria> aliases = new ArrayList<AsrSearchCriteria>();
		// c.createAlias("report.fpsPrvdr", "prvdr", JoinType.LEFT_OUTER_JOIN);

		boolean hasValidParams = false;
		if ((request instanceof AsrSearchParameter)) {
			AsrSearchParameter param = request;
			FpsUser defaultUser = new FpsUser();
		
			FpsUser loggedInUser = null;
			if (StringUtils.isNotBlank(param.getLoggedInUserId())) {
//				LdapQuery query = buildBaseQuery();
//				query.setFilter("(uid=" + param.getLoggedInUserId() + ")");
//				query.setSearchVal(param.getLoggedInUserId());
				List<FpsUser> fpsUsers = LdapUtil.getUser(param.getLoggedInUserId());
				if (fpsUsers.size() == 0) {
					logger.fine("Ldap advanced search for " + param.getLoggedInUserId() + " returned " + fpsUsers.size()
							+ " results");
				}
				loggedInUser = fpsUsers != null && fpsUsers.size() > 0 ? fpsUsers.get(0) : null;
			}
			if (loggedInUser == null) {
				loggedInUser = defaultUser;
			}
			String userZone = loggedInUser.getBusinessCategory();
			if (userZone != null) {
				if (userZone.startsWith("J") || userZone.startsWith("DME")) {
					userZone = "MAC " + userZone;
				}
				if (userZone.startsWith("RRB")) {
					userZone = "RRB";
				}

			}
			String ucmZone = FpsDomainObjectConverter.convertFpsZoneToUcm(loggedInUser);
			// FPS-620
			// avoid returning ASR records with no alerts and no prioritizations
			// (summaryVisibleInd = N)
			DetachedCriteria napSubquery = DetachedCriteria.forClass(FpsAsrptSrcTypeVw.class, "naps");
			napSubquery.setProjection(Projections.distinct(Projections.property("asrptId")));
			napSubquery.add(Restrictions.ne("summaryVisibleInd", "N"));
			params.add("N");
			c.add(Subqueries.propertyIn("asrptId", napSubquery));

			logger.fine("using userid = " + loggedInUser.getUserId());
			logger.fine("using userzone = " + loggedInUser.getBusinessCategory());
//			updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
			String fullZone = loggedInUser.getBusinessCategory();
			UpicMappingEnum zoneEnum = UpicMappingEnum.getValueFromCd(fullZone);
			if (zoneEnum != UpicMappingEnum.OTHER) {
				fullZone = zoneEnum.getWithSpaces();
			}
			// multiple ASR IDs
			boolean isDbId = false;
			boolean isNpiId = false;
			if (request.getAsrptIds() != null) {
				for (Object o : request.getAsrptIds()) {
					if (o != null && o.toString().length() < 10 && StringUtils.isNumeric(o.toString())) {
						isDbId = true;
					} else {
						isNpiId = true;
					}
					// values over 10 characters are invalid
					if (o != null) {
						if (o.toString().length() > 10) {
							params.add("0");
						} else {
							// values with non alpha characters are invalid
							String clean = o.toString().replaceAll("[^0-9]", "");
							if (clean.length() != 10 && !clean.equals(o.toString())) {
								params.add("0");
							} else {
								params.add(clean);
							}
						}
					}
				}
				c.add(Restrictions.in(isDbId && !isNpiId ? "asrptId" : "prvdrNpiNum", request.getAsrptIds()));
			}
			// billing NPIs
			if (request.getBillingNpis() != null) {
				for (Object o : request.getBillingNpis()) {
					if (o != null && o.toString().length() < 10 && StringUtils.isNumeric(o.toString())) {
						isDbId = true;
					} else {
						isNpiId = true;
					}
					// values over 10 characters are invalid
					if (o != null) {
						if (o.toString().length() > 10) {
							params.add("0");
						} else {
							// values with non alpha characters are invalid
							String clean = o.toString().replaceAll("[^0-9]", "");
							if (clean.length() != 10 && !clean.equals(o.toString())) {
								params.add("0");
							} else {
								params.add(clean);
							}
						}
					}
				}
				DetachedCriteria subquery = DetachedCriteria.forClass(FpsPrvdrPrflBlngPrvdr.class, "billing");
				subquery.setProjection(Projections.distinct(Projections.property("prvdrNpiNum")));
				subquery.add(Restrictions.in( "clmBlngPrvdrNpiNum", request.getBillingNpis()));
				c.add(Subqueries.propertyIn("prvdrNpiNum", subquery));
			}
			// Part D
			if (StringUtils.isNotEmpty(param.getPartDInd())) {
				hasValidParams = true;
				DetachedCriteria subquery = DetachedCriteria.forClass(VwFpsPtdAsrSummary.class, "partd");
				subquery.setProjection(Projections.distinct(Projections.property("asrptId")));
				if ("Yes".equals(param.getPartDInd())) {

					c.add(Subqueries.propertyIn("asrptId", subquery));
				} else {
					c.add(Subqueries.propertyNotIn("asrptId", subquery));
				}

			}
//			// specialties
			if (param.getSpecialtyCds() != null) {
				DetachedCriteria specialtiesCriteria = DetachedCriteria.forClass(FpsAsrptStatMatVw.class, "specialties")
						.add(Restrictions.eq("type", "PROVIDER SPECIALTY"))
						.setProjection(Projections.distinct(Projections.property("asrptId")));

				params.add("PROVIDER SPECIALTY");
				List<String> specialties = new ArrayList<String>();
				for (AsrGenericCode specialty : param.getSpecialtyCds()) {
					specialties.add(specialty.getCode());
					params.add(specialty.getCode());
				}

				specialtiesCriteria.add(Restrictions.in("value", specialties));
				c.add(Subqueries.propertyIn("asrptId", specialtiesCriteria));
			}
			// UCM ASR ID
			if (StringUtils.isNotEmpty(param.getUcmAsrId())) {

				DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrpt.class, "asrpt");
				subquery.setProjection(Projections.distinct(Projections.property("asrptId")));
				subquery.add(Restrictions.eq("asrpt.ucmAsrId", param.getUcmAsrId()));
				params.add(param.getUcmAsrId());

				c.add(Subqueries.propertyIn("asrptId", subquery));

			}
			// ASR State
			if ((param.getStates() != null) && (param.getStates().size() > 0)) {
				List<String> states = new ArrayList<String>();
				for (AsrState state : param.getStates()) {
					states.add(state.getCode());
					params.add(state.getCode());
				}
				// String stateSql = "'" + StringUtils.join(states, "','") +
				// "'";
				// params.add(stateSql);
				c.add(Restrictions.in("report.prvdrState", states));
			}
			// ASR created dates
			if (StringUtils.isNotBlank(param.getCreatedMaxDt())) {
				try {
					Date d = format.parse(param.getCreatedMaxDt() + " 00:00:00");
					params.add(d);
					c.add(Restrictions.le("asrptCreatDt", d));
				} catch (ParseException e) {
					logger.log(Level.WARNING, "error parsing date", e);
					params.add(new Date());
					c.add(Restrictions.le("asrptCreatDt", new Date()));
				}
			}

			if (StringUtils.isNotBlank(param.getCreatedMinDt())) {
				try {
					Date d = format.parse(param.getCreatedMinDt() + " 00:00:00");
					params.add(d);
					c.add(Restrictions.ge("asrptCreatDt", d));
				} catch (ParseException e) {
					logger.log(Level.WARNING, "error parsing date", e);
					params.add(new Date());
					c.add(Restrictions.ge("asrptCreatDt", new Date()));
				}
			}
			// APS
			if (StringUtils.isNotEmpty(param.getApsInd())) {
				hasValidParams = true;
				DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrptApsVw.class, "aps");
				subquery.setProjection(Projections.distinct(Projections.property("asrptId")));
				if ("Yes".equals(param.getApsInd())) {

					c.add(Subqueries.propertyIn("asrptId", subquery));
				} else {
					c.add(Subqueries.propertyNotIn("asrptId", subquery));
				}

			}

			// dual bene
			if (StringUtils.isNotEmpty(param.getDualBeneInd())) {
				hasValidParams = true;
				DetachedCriteria subquery = DetachedCriteria.forClass(FpsPrvdrPrflDtl.class, "dualbene");
				subquery.setProjection(Projections.distinct(Projections.property("prfldPrvdrNpiNum")));
//				subquery.add(Restrictions.eq("prfldPrvdrTypeTxt", "performing"));
//				params.add("performing");
				if ("Yes".equals(param.getDualBeneInd())) {

					subquery.add(Restrictions.gt("dualElgblBeneCnt", 0.0f));

				} else {
					subquery.add(Restrictions.eq("dualElgblBeneCnt", 0.0f));

				}
				params.add(0.0f);
				c.add(Subqueries.propertyIn("prvdrNpiNum", subquery));

			}
			// subject jurisdiction

			// check role for MAC search
			if (StringUtils.isNotBlank(param.getSubjectJurisdiction())) {
				// updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSPRVDRJOIN,
				// aliases);
				// removed with ASR jurisdiction logic change in PI 23.3.3
//				if ("MEDIC".equals(param.getSubjectJurisdiction())) {
//
//					c.add(Restrictions.eq("partDInd", "Y"));
//					params.add("Y");
//				} else {
					if ("-1".equals(param.getSubjectJurisdiction())) {
						c.add(Restrictions.eq("jurisdiction", "ZPIC 0"));
						params.add("ZPIC 0");

					} else if (!param.getSubjectJurisdiction().startsWith("U")) {
						updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSASRPTMACASCTNJOIN, aliases);
						c.add(Restrictions.eq("macLookup.macJurisdiction", param.getSubjectJurisdiction()));
						params.add(param.getSubjectJurisdiction());

					} else {
						String subjectFullZone = param.getSubjectJurisdiction();
						UpicMappingEnum subjectZoneEnum = UpicMappingEnum
								.getValueFromCd(param.getSubjectJurisdiction());
						if (subjectZoneEnum != UpicMappingEnum.OTHER) {
							subjectFullZone = zoneEnum.getWithSpaces();
						}
						c.add(Restrictions.eq("jurisdiction", subjectFullZone));
						params.add(subjectFullZone);

					}
//				}

			}
			// jurisdictions
			if ((param.getJurisdictions() != null) && (param.getJurisdictions().size() > 0)) {

				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMACASCTNLEFTJOIN, aliases);
				List<String> zoneCds = new ArrayList<String>();
				boolean hasMedic = false;
				for (AsrGenericCode code : param.getJurisdictions()) {
					String dirZone = code.getCode();
					UpicMappingEnum dirZoneEnum = UpicMappingEnum.getValueFromCd(dirZone);
					if (dirZoneEnum != UpicMappingEnum.OTHER) {
						dirZone = dirZoneEnum.getWithSpaces();
					}
					zoneCds.add(dirZone);
					if ("MEDIC".equals(dirZone)) {
						hasMedic = true;
					}

				}
				// if someone is searching on MEDIC, treat it differently
				// removed in PI 23_3 with ASR jurisdiction calculation logic changes.
//				if (hasMedic) {
//					c.add(Restrictions.eq("partDInd", "Y"));
//					params.add("Y");
//
//					// if includes zone criteria other than
//					if (param.getJurisdictions().size() > 1) {
//						c.add(Restrictions.or(Restrictions.in("jurisdiction", zoneCds),
//								Restrictions.in("prvdrMacLookup.macJurisdiction", zoneCds)));
//						params.addAll(zoneCds);
//						params.addAll(zoneCds);
//					}
//
//				} else {
					// standard zone search
					c.add(Restrictions.or(Restrictions.in("jurisdiction", zoneCds),
							Restrictions.in("prvdrMacLookup.macJurisdiction", zoneCds)));
					params.addAll(zoneCds);
					params.addAll(zoneCds);
//				}

			}
			// FPS-29253
			// at risk jurisdictions
			
			if ((param.getAtRiskJrsdctns() != null) && (param.getAtRiskJrsdctns().size() > 0)) {

				List<String> zoneCds = param.getAtRiskJrsdctns()
						.stream()
						.map(AsrGenericCode::getCode)
						.collect(Collectors.toList());

				DetachedCriteria subqueryAtRisk = DetachedCriteria.forClass(FpsAsrptZoneCostCntVw.class, "atRiskJrsdctn")
						.setProjection(Projections.distinct(Projections.property("asrptId")));
				subqueryAtRisk.add(Restrictions.in("cntrctrNm", zoneCds));
				params.addAll(zoneCds);

				if (param.getAtRiskCostHigh() != null) {
					subqueryAtRisk.add(Restrictions.le("clmCost", param.getAtRiskCostHigh()));
					params.add(param.getAtRiskCostHigh());


				}
				if (param.getAtRiskCostLow() != null) {
					subqueryAtRisk.add(Restrictions.ge("clmCost", param.getAtRiskCostLow()));
					params.add(param.getAtRiskCostLow());


				}
				c.add(Subqueries.propertyIn("asrptId", subqueryAtRisk));
				
//							}

			}
			// Phase 1 jurisdictions
			if (p1Enabled && (param.getP1Jurisdictions() != null) && (param.getP1Jurisdictions().size() > 0)) {

				List<String> zoneCds = new ArrayList<String>();
				for (AsrGenericCode code : param.getP1Jurisdictions()) {
					String dirZone = code.getCode();
					UpicMappingEnum dirZoneEnum = UpicMappingEnum.getValueFromCd(dirZone);
					if (dirZoneEnum != UpicMappingEnum.OTHER) {
						dirZone = dirZoneEnum.getWithSpaces();
					}
					zoneCds.add(dirZone);
				

				}

					// standard zone search
					c.add(Restrictions.in("p1Jurisdiction", zoneCds));
					params.addAll(zoneCds);
//				}

			}
			// rulings
			if ((param.getRulings() != null) && (param.getRulings().size() > 0)) {
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTJOIN, aliases);
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSRULINGJOIN, aliases);

				List<String> rulingCds = new ArrayList<String>();
				for (AsrRuling ruling : param.getRulings()) {
					rulingCds.add(ruling.getCode());
					params.add(ruling.getCode());
				}

				DetachedCriteria subqueryRulings = DetachedCriteria.forClass(FpsAsrptInvstgtn.class, "invSub")
						.createAlias("invSub.fpsAsrptUserRulngs", "invSubRulings")
						.createAlias("invSubRulings.fpsRulngRfrnc", "rulingRefSub")
						.setProjection(Projections.projectionList().add(Projections.max("invSubRulings.crntRulngDt"))
								.add(Projections.groupProperty("invSub.asrptInvstgtnId")));
				// params.add(subqueryRulings);
				c.add(Subqueries.propertiesIn(new String[] { "ruling.crntRulngDt", "invest.asrptInvstgtnId" },
						subqueryRulings));
				// String rulingCdSql = "'" + StringUtils.join(rulingCds, "','")
				// + "'";
				// params.add(rulingCdSql);
				c.add(Restrictions.in("rulingRef.rulngCd", rulingCds));

			}

			// claim/asr type
			if (CollectionUtils.isNotEmpty(param.getClaimTypes())) {
				AsrSummaryClaimType rrbType = new AsrSummaryClaimType();
				rrbType.setClaimTypeCd("RRB");
				if (param.getClaimTypes().contains(rrbType)) {
					DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrptBeneRrbVw.class, "rrb")
							.setProjection(Projections.distinct(Projections.property("asrptId")));

					// params.add(subquery);
					c.add(Subqueries.propertyIn("asrptId", subquery));
				}

				Disjunction claimTypes = Restrictions
						.or(new Criterion[] { Restrictions.eq("asrptId", Integer.valueOf(-1)) });
				params.add(-1);
				for (AsrSummaryClaimType code : param.getClaimTypes()) {

					String claimType = code.getClaimTypeCd();
					ClaimTypeDbEnum claimTypeEnum = ClaimTypeDbEnum.valueOf(claimType);
					if (!claimTypeEnum.equals(ClaimTypeDbEnum.NA)) {
						claimTypes.add(Restrictions.eq(claimTypeEnum.getColumn(), "Y"));

						params.add("Y");
					}
				}

				// params.add(subquery);
				c.add(claimTypes);
			}
			// enrollment ID
			if (StringUtils.isNotEmpty(param.getEnrollmentId())) {
				hasValidParams = true;

				DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrptEnrlmtAsctnVw.class, "enroll");
				subquery.setProjection(Projections.distinct(Projections.property("asrptId")));
				subquery.add(Restrictions.eq("enrlmtId", param.getEnrollmentId()));
				c.add(Subqueries.propertyIn("asrptId", subquery));
				params.add(param.getEnrollmentId());

			}
			// revocation status
			if (StringUtils.isNotEmpty(param.getRevokedInd())) {
				hasValidParams = true;

				if ("Yes".equals(param.getRevokedInd())) {

					c.add(Restrictions.eq("revokedInd", "Y"));
					params.add("Y");

				} else {
					c.add(Restrictions.eq("revokedInd", "N"));
					params.add("N");

				}

			}
			// UCM Case ID
			if (StringUtils.isNotEmpty(param.getUcmCaseId())) {
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTJOIN, aliases);
				hasValidParams = true;
				params.add(param.getUcmCaseId());
				params.add("A");
				c.add(Restrictions.eq("invest.extrnlCaseId", param.getUcmCaseId()));
				c.add(Restrictions.eq("invest.recChgInd", "A"));

			}

			// lead/INV
			// lead/INV
			if (CollectionUtils.isNotEmpty(param.getLeadInvestigationInd())) {
				hasValidParams = true;
				DetachedCriteria subquery = DetachedCriteria
						.forClass(FpsAsrptInvstgnStusSmryVw.class, "asrptForLeadInv")
						.setProjection(Projections.distinct(Projections.property("asrptId")));
				
				AsrGenericCode noneCode = new AsrGenericCode("None");
				boolean hasOther = !param.getLeadInvestigationInd().contains(noneCode);
				if ("Yes".equals(param.getMyZoneOnlyInd()) && hasOther) {
					subquery.add(Restrictions.or(Restrictions.eq("asrptForLeadInv.openZone", userZone),
							Restrictions.eq("asrptForLeadInv.closedZone", userZone)));
					params.add(userZone);
					params.add(userZone);
				}
				Disjunction leadInvOr = Restrictions.or(new Criterion[] {});
				Disjunction leadInvOrRoot = Restrictions.or(new Criterion[] {});
				Conjunction leadInvOrWithNone = Restrictions.and(new Criterion[] {});
				// boolean addOpenStatusY = false;
				// boolean addOpenStatusN = false;
				boolean hasNone = false;

				for (AsrGenericCode code : param.getLeadInvestigationInd()) {

					String leadInvInd = code.getCode();
					if ("None".equals(leadInvInd)) {
						hasNone = true;
					} else {
						leadInvOr.add(Restrictions.eq("asrptForLeadInv.type", leadInvInd));
						params.add(leadInvInd);
						hasOther = true;
					}
					// addOpenStatusY = true;

				}

				if (hasNone) {
					DetachedCriteria subqueryHasNone = DetachedCriteria
							.forClass(FpsAsrptInvstgtn.class, "asrptForLeadInvNone")
							.createAlias("asrptForLeadInvNone.fpsAsrptUserInvstgtns", "asrptForLeadInvNoneUser")
							.setProjection(Projections.distinct(Projections.property("asrptId")));
					subqueryHasNone.add(Restrictions.isNotNull("asrptForLeadInvNone.extrnlCaseId"));

					if ("Yes".equals(param.getMyZoneOnlyInd())) {
						subqueryHasNone.add(Restrictions.eq("asrptForLeadInvNoneUser.asgnedCntrctr", userZone));
						params.add(userZone);
					}
					leadInvOrWithNone.add(Subqueries.propertyNotIn("asrptId", subqueryHasNone));
					leadInvOrRoot.add(leadInvOrWithNone);

				}
				if (hasOther) {
					subquery.add(leadInvOr);
					leadInvOrRoot.add(Subqueries.propertyIn("asrptId", subquery));

				}
				c.add(leadInvOrRoot);

				// if (addOpenStatus) {
				// params.add("11");
				// }
				// params.add(subquery);
			}
			// alert types (model names)
			if ((param.getAlerts() != null) && (param.getAlerts().size() > 0)) {
				logger.fine("Models coming from Alerts drop down of Custom ASR search" + param.getAlerts().size());
				DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrptAlertAsctn.class, "asrAlerts")
						.createAlias("asrAlerts.fpsAlert", "alerts", JoinType.INNER_JOIN)
						.createAlias("asrAlerts.fpsAsrpt", "asr", JoinType.INNER_JOIN)
						.createAlias("alerts.fpsModel", "model", JoinType.INNER_JOIN)

						.setProjection(Projections.distinct(Projections.property("asr.asrptId")));
				Conjunction landingQuery = null;
				Disjunction modelIdsOr = Restrictions.or(new Criterion[] {});
//				List<Integer> modelIds = new ArrayList<Integer>();
				for (AsrAlertType alertType : param.getAlerts()) {
					modelIdsOr.add(Restrictions.eq("model.modelId", alertType.getAlertId()));
//					modelIds.add(alertType.getAlertId());
					params.add(alertType.getAlertId());
				}
				if (param.getModelRunDt() != null) {
					landingQuery = Restrictions.and(new Criterion[] {});
					landingQuery.add(modelIdsOr);
					Date d = new Date();
					Calendar cal = Calendar.getInstance();
					try {
						d = shortFormat.parse(param.getModelRunDt() );
						
						cal.setTime(d);
						landingQuery.add(Restrictions.eq("alerts.alertCreatDt", d));

						
					} catch (ParseException e) {
						landingQuery.add(Restrictions.eq("alerts.alertCreatDt",d));
						
					}
					params.add(d);
					
				}
				
				if (landingQuery != null) {
					subquery.add(landingQuery);
	
				}else {
					
					subquery.add(modelIdsOr);
				}
				c.add(Subqueries.propertyIn("asrptId", subquery));

			}
			// Phase 1 alert types (model names)
			if (p1Enabled && (param.getP1Alerts() != null) && (param.getP1Alerts().size() > 0)) {
				DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrptAlertAsctn.class, "p1AsrAlerts")
						.createAlias("p1AsrAlerts.fpsAlert", "p1Alerts", JoinType.INNER_JOIN)
						.createAlias("p1AsrAlerts.fpsAsrpt", "p1Asr", JoinType.INNER_JOIN)
						.createAlias("p1Alerts.fpsModel", "p1Model", JoinType.INNER_JOIN)

						.setProjection(Projections.distinct(Projections.property("p1Asr.asrptId")));
				Conjunction p1Filter = Restrictions.and(new Criterion[] {});;
				p1Filter.add(Restrictions.ilike("p1Model.clmTypeCd", "P1%"));
				params.add("P1%");
				Disjunction modelIdsOr = Restrictions.or(new Criterion[] {});
				for (AsrAlertType alertType : param.getP1Alerts()) {
					modelIdsOr.add(Restrictions.eq("p1Model.modelId", alertType.getAlertId()));
					params.add(alertType.getAlertId());
				}
//				if (param.getModelRunDt() != null) {
//					landingQuery = Restrictions.and(new Criterion[] {});
//					landingQuery.add(modelIdsOr);
//					Date d = new Date();
//					Calendar cal = Calendar.getInstance();
//					try {
//						d = shortFormat.parse(param.getModelRunDt() );
//						
//						cal.setTime(d);
//						landingQuery.add(Restrictions.eq("alerts.alertCreatDt", d));
//
//						
//					} catch (ParseException e) {
//						landingQuery.add(Restrictions.eq("alerts.alertCreatDt",d));
//						
//					}
//					params.add(d);
//					
//				}
				
				p1Filter.add(modelIdsOr);
				subquery.add(p1Filter);
	
			
				c.add(Subqueries.propertyIn("asrptId", subquery));

			}
			// ZR ID
			if (StringUtils.isNotBlank(param.getZrId())) {
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSUCMVWJOIN, aliases);

				c.add(Restrictions.like("ucmVw.zrIds", "%" + param.getZrId() + "%").ignoreCase());
				params.add("%" + param.getZrId() + "%");

			}
			// ZR Type
			if (param.getZrTypes() != null && param.getZrTypes().size() > 0) {
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSUCMVWJOIN, aliases);

				Disjunction zrTypes = Restrictions.or(new Criterion[] {});
				for (AsrGenericCode code : param.getZrTypes()) {

					String zrType = code.getCode();
					zrTypes.add(Restrictions.eq("ucmVw.zrStatuses", zrType));
					params.add(zrType);

				}
				// params.add(subquery);
				c.add(zrTypes);
			}
			// ACO Ind
			if (param.getAcoInd() != null ) {
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSACOJOIN, aliases);

				if ("Y".equals(param.getAcoInd())) {
					c.add(Restrictions.isNotNull("aco.prvdrNpiNum"));
				
				}else {
					c.add(Restrictions.isNull("aco.prvdrNpiNum"));

				
				}
			}
			// Edit ID and edit names
			if (param.getEditId() != null || (param.getEdits() != null && param.getEdits().size() > 0)) {
				DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrptEditSmryVw.class, "editsVw");
				subquery.setProjection(Projections.distinct(Projections.property("editsVw.asrptId")));
				if (param.getEditId() != null) {
					subquery.add(Restrictions.eq("editsVw.editId", param.getEditId()));
					params.add(param.getEditId());
				}
				if (param.getEdits() != null && param.getEdits().size() > 0) {
					Disjunction models = Restrictions.or(new Criterion[] {});

					for (AsrGenericCode code : param.getEdits()) {

						String model = code.getCode();

						models.add(Restrictions.eq("editsVw.modelName", model));

						params.add(model);

					}
					subquery.add(models);
				}
				c.add(Subqueries.propertyIn("asrptId", subquery));

			}
			if (param.getPathToEduInd() != null) {
				DetachedCriteria subquery = DetachedCriteria.forClass(FpsAsrptWithPathToEdu.class, "eduCnt");
				subquery.setProjection(Projections.distinct(Projections.property("eduCnt.asrptId")));
				if ("Y".equals(param.getPathToEduInd())) {
					subquery.add(Restrictions.gt("eduCnt.eduCt", 0));

				}else {
					subquery.add(Restrictions.eq("eduCnt.eduCt", 0));
				}
				params.add(0);
				c.add(Subqueries.propertyIn("asrptId", subquery));
				
			
				

			}
			// alert status
			if ((param.getAlertStatus() != null) && (param.getAlertStatus().size() > 0)) {
				List<String> statuses = new ArrayList<String>();
				params.add("P1%");
				for (AsrAlertStatus alertStatus : param.getAlertStatus()) {
					statuses.add(alertStatus.getCode());
					params.add(alertStatus.getCode());

				}
				// this behavior worked like this from SysR1.0 to SysR5.0, then changed again in
				// SysR15.2
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMODELJOIN, aliases);

				c.add(Restrictions.and(Restrictions.not(Restrictions.ilike("model.clmTypeCd", "P1%")), Restrictions.in("alert.alertStusCd", statuses)));

			}
			// alert status
			if ((param.getP1AlertStatus() != null) && (param.getP1AlertStatus().size() > 0)) {
				List<String> statuses = new ArrayList<String>();
				params.add("P1%");
				for (AsrAlertStatus alertStatus : param.getP1AlertStatus()) {
					statuses.add(alertStatus.getCode());
					params.add(alertStatus.getCode());

				}
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMODELJOIN, aliases);

				c.add(Restrictions.and(Restrictions.ilike("model.clmTypeCd", "P1%"), Restrictions.in("alert.alertStusCd", statuses)));

			}
			// asr ID
			if (StringUtils.isNotBlank(param.getAsrptId())) {
				if (param.getAsrptId().length() < 10) {
					Integer asrptId = Integer.valueOf(0);
					try {
						asrptId = Integer.valueOf(Integer.parseInt(param.getAsrptId()));
					} catch (NumberFormatException localNumberFormatException) {
					}
					params.add(asrptId);
					c.add(Restrictions.eq("asrptId", asrptId));
				} else {
					params.add(param.getAsrptId());
					c.add(Restrictions.eq("prvdrNpiNum", param.getAsrptId()));
				}
			}
			// name
			if (StringUtils.isNotBlank(param.getPrvdrName())) {
				c.add(Restrictions.like("prvdrNm", "%" + param.getPrvdrName() + "%").ignoreCase());
				params.add("%" + param.getPrvdrName().toLowerCase() + "%");

			}
			// risk score high
			if (param.getRiskScoreHigh() != null) {
				params.add(param.getRiskScoreHigh());
				c.add(Restrictions.le("asrptRiskScreNum", param.getRiskScoreHigh()));
			}
			// risk score low
			if (param.getRiskScoreLow() != null) {
				params.add(param.getRiskScoreLow());
				c.add(Restrictions.ge("asrptRiskScreNum", param.getRiskScoreLow()));
			}
			// asr cost
			if (param.getAsrCostHigh() != null) {
				params.add(param.getAsrCostHigh());
				c.add(Restrictions.le("cost", param.getAsrCostHigh()));
			}
			if (param.getAsrCostLow() != null) {
				params.add(param.getAsrCostLow());
				c.add(Restrictions.ge("cost", param.getAsrCostLow()));
			}
			// phase 1 cost
			if (p1Enabled && param.getP1AsrCostHigh() != null) {
				params.add(param.getP1AsrCostHigh());
				c.add(Restrictions.le("p1Cost", param.getP1AsrCostHigh()));
			}
			if (p1Enabled && param.getP1AsrCostLow() != null) {
				params.add(param.getP1AsrCostLow());
				c.add(Restrictions.ge("p1Cost", param.getP1AsrCostLow()));
			}
			
			//priority score
			if (param.getPriorityScoreHigh() != null || param.getPriorityScoreLow() != null) {

				if (param.getPriorityScoreHigh() != null) {
					c.add(Restrictions.le("priorityScore", param.getPriorityScoreHigh()));
					params.add(param.getPriorityScoreHigh());

				}
				if (param.getPriorityScoreLow() != null) {
					c.add(Restrictions.ge("priorityScore", param.getPriorityScoreLow()));
					params.add(param.getPriorityScoreLow());

				}

			}

			// provider analysis search fields
			// actionability
			if (param.getActionability() != null) {
				Disjunction actionability = Restrictions.or(new Criterion[] {});

				for (AsrGenericCode p : param.getActionability()) {
					actionability.add(Restrictions.eq("report.actionability", p.getCode()));
					params.add(p.getCode());
				}
				c.add(actionability);

			}
			// timeliness
			if (param.getTimelinessHigh() != null || param.getTimelinessLow() != null) {
				if (param.getTimelinessHigh() != null) {
					c.add(Restrictions.le("report.timeliness", param.getTimelinessHigh()));
					params.add(param.getTimelinessHigh());

				}
				if (param.getTimelinessLow() != null) {
					c.add(Restrictions.ge("report.timeliness", param.getTimelinessLow()));
					params.add(param.getTimelinessLow());

				}
			}

			// last date of education range
			if (param.getLastEduDtHigh() != null || param.getLastEduDtLow() != null) {
				if (param.getLastEduDtHigh() != null) {
					c.add(Restrictions.le("report.lastEduDt", FpsDomainObjectConverter.convertDateStringToString(param.getLastEduDtHigh())));
					params.add(FpsDomainObjectConverter.convertDateStringToString(param.getLastEduDtHigh()));

				}
				if (param.getLastEduDtLow() != null) {
					c.add(Restrictions.ge("report.lastEduDt", FpsDomainObjectConverter.convertDateStringToString(param.getLastEduDtLow())));
					params.add(FpsDomainObjectConverter.convertDateStringToString(param.getLastEduDtLow()));

				}
			}
			// TPE range
			if (param.getLastTpeEduDtHigh() != null || param.getLastTpeEduDtLow() != null) {
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSTPEVWJOIN, aliases);

				if (param.getLastTpeEduDtHigh() != null) {
					c.add(Restrictions.le("tpe.edctnDt", FpsDomainObjectConverter.convertDateStringToString(param.getLastTpeEduDtHigh())));
					params.add(FpsDomainObjectConverter.convertDateStringToString(param.getLastTpeEduDtHigh()));

				}
				if (param.getLastTpeEduDtLow() != null) {
					c.add(Restrictions.ge("tpe.edctnDt", FpsDomainObjectConverter.convertDateStringToString(param.getLastTpeEduDtLow())));
					params.add(FpsDomainObjectConverter.convertDateStringToString(param.getLastTpeEduDtLow()));

				}
			}
			// late claim date range
			if (param.getLastClmDtHigh() != null || param.getLastClmDtLow() != null) {
				if (param.getLastClmDtHigh() != null) {
					c.add(Restrictions.le("report.lastClmDt", FpsDomainObjectConverter.convertDateStringToString(param.getLastClmDtHigh())));
					params.add(FpsDomainObjectConverter.convertDateStringToString(param.getLastClmDtHigh()));

				}
				if (param.getLastClmDtLow() != null) {
					c.add(Restrictions.ge("report.lastClmDt", FpsDomainObjectConverter.convertDateStringToString(param.getLastClmDtLow())));
					params.add(FpsDomainObjectConverter.convertDateStringToString(param.getLastClmDtLow()));

				}
			}
			// last alert date of service range
			if (param.getLastAlertSvcDtHigh() != null || param.getLastAlertSvcDtLow() != null) {
				if (param.getLastAlertSvcDtHigh() != null) {
					c.add(Restrictions.le("report.lastAlertClmSvcDt", FpsDomainObjectConverter.convertDateStringToString(param.getLastAlertSvcDtHigh())));
					params.add(FpsDomainObjectConverter.convertDateStringToString(param.getLastAlertSvcDtHigh()));

				}
				if (param.getLastAlertSvcDtLow() != null) {
					c.add(Restrictions.ge("report.lastAlertClmSvcDt", FpsDomainObjectConverter.convertDateStringToString(param.getLastAlertSvcDtLow())));
					params.add(FpsDomainObjectConverter.convertDateStringToString(param.getLastAlertSvcDtLow()));

				}
			}
			// Phase 1 last alert date of service range
			if (p1Enabled && (param.getP1LastAlertSvcDtHigh() != null || param.getP1LastAlertSvcDtLow() != null)) {
				if (param.getP1LastAlertSvcDtHigh() != null) {
					c.add(Restrictions.le("report.p1LastAlertClmSvcDt", FpsDomainObjectConverter.convertDateStringToString(param.getP1LastAlertSvcDtHigh())));
					params.add(FpsDomainObjectConverter.convertDateStringToString(param.getP1LastAlertSvcDtHigh()));

				}
				if (param.getP1LastAlertSvcDtLow() != null) {
					c.add(Restrictions.ge("report.p1LastAlertClmSvcDt", FpsDomainObjectConverter.convertDateStringToString(param.getP1LastAlertSvcDtLow())));
					params.add(FpsDomainObjectConverter.convertDateStringToString(param.getP1LastAlertSvcDtLow()));

				}
			}
			// inappropriate billing
			if (param.getInappBillInd() != null) {
				c.add(Restrictions.ge("report.billAfterEduInd", param.getInappBillInd()));
				params.add(param.getInappBillInd());
			}
//			Yes - My Jurisdiction 
//			 No - My Jurisdiction 
//			 Yes - Not My Jurisdiction
//			 No - Not My Jurisdiction
// prioritization types
			if (param.getPrioritizeTypes() != null && param.getPrioritizeTypes().size() > 0) {
				Disjunction prrtyZone = Restrictions.or(new Criterion[] {});
				Disjunction prrtyZoneCntrctrCd = Restrictions.or(new Criterion[] {});

				boolean prrtyMyZoneY = false;
				boolean prrtyMyZoneN = false;
				boolean prrtyOtherZoneY = false;
				boolean prrtyOtherZoneN = false;
				for (AsrGenericCode p : param.getPrioritizeTypes()) {
					if ("60".equals(p.getCode())) {
						DetachedCriteria prrtyByZoneMyY = DetachedCriteria
								.forClass(FpsAsrptPrrty.class, "prrtyByZoneMyY")
								.setProjection(Projections.distinct(Projections.property("prrtyByZoneMyY.asrptId")))
								.add(Restrictions.eq("prrtyByZoneMyY.cntrctrCd", loggedInUser.getBusinessCategory()));
						params.add(loggedInUser.getBusinessCategory());
						prrtyZone.add(Subqueries.propertyIn("asrptId", prrtyByZoneMyY));

					} else if ("61".equals(p.getCode())) {
						DetachedCriteria prrtyByZoneMyN = DetachedCriteria
								.forClass(FpsAsrptPrrty.class, "prrtyByZoneMyN")
								.setProjection(Projections.distinct(Projections.property("prrtyByZoneMyN.asrptId")))
								.add(Restrictions.eq("prrtyByZoneMyN.cntrctrCd", loggedInUser.getBusinessCategory()));
						params.add(loggedInUser.getBusinessCategory());
						prrtyZone.add(Subqueries.propertyNotIn("asrptId", prrtyByZoneMyN));

					} else if ("62".equals(p.getCode())) {
						DetachedCriteria prrtyByZoneNotMyY = DetachedCriteria
								.forClass(FpsAsrptPrrty.class, "prrtyByZoneNotMyY")
								.setProjection(Projections.distinct(Projections.property("prrtyByZoneNotMyY.asrptId")))
								.add(Restrictions.ne("prrtyByZoneNotMyY.cntrctrCd",
										loggedInUser.getBusinessCategory()));
						params.add(loggedInUser.getBusinessCategory());
						prrtyZone.add(Subqueries.propertyIn("asrptId", prrtyByZoneNotMyY));

					} else if ("63".equals(p.getCode())) {
						DetachedCriteria prrtyByZoneNotMyN = DetachedCriteria
								.forClass(FpsAsrptPrrty.class, "prrtyByZoneNotMyN")
								.setProjection(Projections.distinct(Projections.property("prrtyByZoneNotMyN.asrptId")))
								.add(Restrictions.ne("prrtyByZoneNotMyN.cntrctrCd",
										loggedInUser.getBusinessCategory()));
						params.add(loggedInUser.getBusinessCategory());
						prrtyZone.add(Subqueries.propertyNotIn("asrptId", prrtyByZoneNotMyN));

					}
				}

				c.add(prrtyZone);

			}
			// bene count range
			if (param.getBeneCntHigh() != null || param.getBeneCntLow() != null) {
				if (param.getBeneCntHigh() != null) {
					c.add(Restrictions.le("report.beneCnt", param.getBeneCntHigh()));
					params.add(param.getBeneCntHigh());

				}
				if (param.getBeneCntLow() != null) {
					c.add(Restrictions.ge("report.beneCnt", param.getBeneCntLow()));
					params.add(param.getBeneCntLow());

				}
			}
			// claim count range
			if (param.getClmCntHigh() != null || param.getClmCntLow() != null) {
				if (param.getClmCntHigh() != null) {
					c.add(Restrictions.le("report.claimCnt", param.getClmCntHigh()));
					params.add(param.getClmCntHigh());

				}
				if (param.getClmCntLow() != null) {
					c.add(Restrictions.ge("report.claimCnt", param.getClmCntLow()));
					params.add(param.getClmCntLow());

				}
			}
			// submitted payment amount range
			if (param.getSbmtAmtHigh() != null || param.getSbmtAmtLow() != null) {
				if (param.getSbmtAmtHigh() != null) {
					c.add(Restrictions.le("report.submitAmt", param.getSbmtAmtHigh()));
					params.add(param.getSbmtAmtHigh());

				}
				if (param.getSbmtAmtLow() != null) {
					c.add(Restrictions.ge("report.submitAmt", param.getSbmtAmtLow()));
					params.add(param.getSbmtAmtLow());

				}
			}
			// part D submitted payment amount range
			if (param.getSbmtAmtDHigh() != null || param.getSbmtAmtDLow() != null) {
				if (param.getSbmtAmtDHigh() != null) {
					c.add(Restrictions.le("report.submtAmtPtd", param.getSbmtAmtDHigh()));
					params.add(param.getSbmtAmtDHigh());

				}
				if (param.getSbmtAmtDLow() != null) {
					c.add(Restrictions.ge("report.submtAmtPtd", param.getSbmtAmtDLow()));
					params.add(param.getSbmtAmtDLow());

				}
			}
			// Part D total payment range
			if (param.getTotalPymtDHigh() != null || param.getTotalPymtDLow() != null) {
				if (param.getTotalPymtDHigh() != null) {
					c.add(Restrictions.le("report.totalPmtPtd", param.getTotalPymtDHigh()));
					params.add(param.getTotalPymtDHigh());

				}
				if (param.getTotalPymtDLow() != null) {
					c.add(Restrictions.ge("report.totalPmtPtd", param.getTotalPymtDLow()));
					params.add(param.getTotalPymtDLow());

				}
			}
			// total payment range
			if (param.getTotalPymtHigh() != null || param.getTotalPymtLow() != null) {
				if (param.getTotalPymtHigh() != null) {
					c.add(Restrictions.le("report.totalPayment", param.getTotalPymtHigh()));
					params.add(param.getTotalPymtHigh());

				}
				if (param.getTotalPymtLow() != null) {
					c.add(Restrictions.ge("report.totalPayment", param.getTotalPymtLow()));
					params.add(param.getTotalPymtLow());

				}
			}
			// first claim date range
			if (param.getFirstClmDtHigh() != null || param.getFirstClmDtLow() != null) {
				if (param.getFirstClmDtHigh() != null) {
					c.add(Restrictions.le("report.earliestClmDt", FpsDomainObjectConverter.convertDateStringToString(param.getFirstClmDtHigh())));
					params.add(FpsDomainObjectConverter.convertDateStringToString(param.getFirstClmDtHigh()));

				}
				if (param.getFirstClmDtLow() != null) {
					c.add(Restrictions.ge("report.earliestClmDt", FpsDomainObjectConverter.convertDateStringToString(param.getFirstClmDtLow())));
					params.add(FpsDomainObjectConverter.convertDateStringToString(param.getFirstClmDtLow()));

				}
			}
			// provider city
			if (param.getPrvdrCity() != null) {
				c.add(Restrictions.eq("report.prvdrPlaceNm", param.getPrvdrCity()).ignoreCase());
				params.add(param.getPrvdrCity());
			}
			// medicaid
			if (param.getMedicaidInd() != null) {
				c.add(Restrictions.eq("report.medicaidInd", param.getMedicaidInd()));
				params.add(param.getMedicaidInd());
			}
			// enrollment status
			if (param.getEnrollStatus() != null && param.getEnrollStatus().size() > 0) {

				Disjunction enrollStatus = Restrictions
						.or(new Criterion[] { Restrictions.eq("asrptId", Integer.valueOf(-1)) });
				params.add(-1);

				for (AsrGenericCode code : param.getEnrollStatus()) {

					String enrollCd = code.getCode();
					enrollStatus.add(Restrictions.eq("report.enrollmentStusDesc", enrollCd));
					params.add(enrollCd);

				}
				c.add(enrollStatus);
			}
			// MAC IDs
			if (param.getMacIds() != null && param.getMacIds().size() > 0) {
				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMACASCTNJOIN, aliases);
				Disjunction macIds = Restrictions.or(new Criterion[] {});

				for (AsrGenericCode code : param.getMacIds()) {

					String macId = code.getCode();
					macIds.add(Restrictions.eq("prvdrMacLookup.clmCntrctrNum", macId));
					params.add(macId);

				}
				c.add(macIds);
			}
			// CNCs
			if (param.getCncs() != null && param.getCncs().size() > 0) {
				Disjunction cncs = Restrictions.or(new Criterion[] { Restrictions.eq("asrptId", Integer.valueOf(-1)) });
				params.add(-1);

				for (AsrGenericCode code : param.getCncs()) {

					String cnc = code.getCode();
					cncs.add(Restrictions.eq("report.fraudTypeDesc", cnc));
					params.add(cnc);

				}
				c.add(cncs);
			}
			// UCM closed date range
			if (param.getUcmClosedDtHigh() != null || param.getUcmClosedDtLow() != null) {
				if (param.getUcmClosedDtHigh() != null) {
					c.add(Restrictions.le("report.lastEduDt", FpsDomainObjectConverter.convertDateStringToString(param.getUcmClosedDtHigh())));
					params.add(FpsDomainObjectConverter.convertDateStringToString(param.getUcmClosedDtHigh()));

				}
				if (param.getUcmClosedDtLow() != null) {
					c.add(Restrictions.ge("report.lastEduDt", FpsDomainObjectConverter.convertDateStringToString(param.getUcmClosedDtLow())));
					params.add(FpsDomainObjectConverter.convertDateStringToString(param.getUcmClosedDtLow()));

				}

			}
			// lead indicator
			if (param.getLeadInd() != null) {
				DetachedCriteria exCriteria = DetachedCriteria.forClass(FpsPrvdrAnlysJurisdiction.class, "leadIndJuris")

						.setProjection(Projections.distinct(Projections.property("leadIndJuris.asrptId")));

				if ("Yes".equals(param.getLeadInd())) {
					exCriteria.add(Restrictions.eq("leadIndJuris.leadInd", "Y"));
					params.add("Y");

				} else {
					DetachedCriteria exCriteriaNo = DetachedCriteria
							.forClass(FpsPrvdrAnlysJurisdiction.class, "leadIndJurisNo")

							.setProjection(Projections.distinct(Projections.property("leadIndJurisNo.asrptId")));
					exCriteriaNo.add(Restrictions.eq("leadIndJurisNo.leadInd", "N"));
					params.add("N");

					DetachedCriteria exCriteriaYes = DetachedCriteria
							.forClass(FpsPrvdrAnlysJurisdiction.class, "leadIndJurisNotYes")

							.setProjection(Projections.distinct(Projections.property("leadIndJurisNotYes.asrptId")));

					exCriteriaYes.add(Restrictions.eq("leadIndJurisNotYes.leadInd", "Y"));
					params.add("Y");
					exCriteria.add(Subqueries.propertyIn("asrptId", exCriteriaNo));

					exCriteria.add(Subqueries.propertyNotIn("asrptId", exCriteriaYes));

				}
				c.add(Subqueries.propertyIn("asrptId", exCriteria));

			}
			// BIU count
			if (param.getBiuCnt() != null) {
				if (param.getBiuDays() != null && param.getBiuDays() == -1) {
					c.add(Restrictions.ge("report.biuComplaintsCnt", param.getBiuCnt()));
				} else {
					c.add(Restrictions.ge("report.biuComplaints90Cnt", param.getBiuCnt()));

				}
				params.add(param.getBiuCnt());
			}
			// ASR in exclusion set
			if (param.getAsrExclSetInd() != null && param.getAsrExclSetInd().size() > 0) {
				DetachedCriteria wsCriteria = DetachedCriteria
						.forClass(FpsAsrptListUserJrsdctnDtlVw.class, "exworkingset")

						.setProjection(Projections.distinct(Projections.property("exworkingset.asrptId")));
				Disjunction wsCriteriaOr = Restrictions.or(new Criterion[] {});
				for (AsrGenericCode p : param.getAsrExclSetInd()) {
					if ("1".equals(p.getCode())) {
						wsCriteriaOr.add(Restrictions.and(Restrictions
								.eq("exworkingset.exUserId", loggedInUser.getUserId().toLowerCase()).ignoreCase(),
								Restrictions.eq("exworkingset.exItemActvInd", "Y")));
						params.add(loggedInUser.getUserId().toLowerCase());
						params.add("Y");

					} else if ("2".equals(p.getCode())) {
						if ("CMS".equals(fullZone)
								|| FpsDomainObjectConverter.isPimascContractor(loggedInUser.getBusinessCategory())) {
							wsCriteriaOr.add(Restrictions.and(Restrictions
									.ne("exworkingset.exUserId", loggedInUser.getUserId().toLowerCase()).ignoreCase(),
									Restrictions.eq("exworkingset.exItemActvInd", "Y")));
							params.add(loggedInUser.getUserId().toLowerCase());
							params.add("Y");
						} else {
							wsCriteriaOr.add(Restrictions.and(Restrictions.eq("exworkingset.publicInd", "Y"),
									Restrictions.ne("exworkingset.exUserId", loggedInUser.getUserId().toLowerCase())
											.ignoreCase(),
									Restrictions.eq("exworkingset.exMyJrsdctn", loggedInUser.getBusinessCategory()),
									Restrictions.eq("exworkingset.exItemActvInd", "Y")));
							params.add("Y");
							params.add(loggedInUser.getUserId().toLowerCase());
							params.add(loggedInUser.getBusinessCategory());
							params.add("Y");
						}

					}
				}
				wsCriteria.add(wsCriteriaOr);
				c.add(Subqueries.propertyIn("asrptId", wsCriteria));
			}
			// ASR in working set
			if (param.getAsrWorkingSetInd() != null && param.getAsrWorkingSetInd().size() > 0) {
				DetachedCriteria wsCriteria = DetachedCriteria
						.forClass(FpsAsrptListUserJrsdctnDtlVw.class, "workingset")

						.setProjection(Projections.distinct(Projections.property("workingset.asrptId")));
				Disjunction wsCriteriaOr = Restrictions.or(new Criterion[] {});
				for (AsrGenericCode p : param.getAsrWorkingSetInd()) {
					if ("1".equals(p.getCode())) {
						wsCriteriaOr.add(Restrictions.eq("workingset.wsUserId", loggedInUser.getUserId().toLowerCase())
								.ignoreCase());
						params.add(loggedInUser.getUserId().toLowerCase());
					} else if ("2".equals(p.getCode())) {
						wsCriteriaOr.add(Restrictions.and(
								Restrictions.ne("workingset.wsUserId", loggedInUser.getUserId().toLowerCase())
										.ignoreCase(),
								Restrictions.eq("workingset.wsMyJrsdctn", loggedInUser.getBusinessCategory())));
						params.add(loggedInUser.getUserId().toLowerCase());
						params.add(loggedInUser.getBusinessCategory());
					}
				}
				wsCriteria.add(wsCriteriaOr);
				c.add(Subqueries.propertyIn("asrptId", wsCriteria));
			}
			// exclusions
			if (param.getExclusions() != null && param.getExclusions().size() > 0) {
//				updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSEXCLUSIONJOIN, aliases);

				DetachedCriteria exCriteria = DetachedCriteria
						.forClass(FpsPrvdrAnlysExclusionSearch.class, "exclusions")

						.setProjection(Projections.distinct(Projections.property("exclusions.asrptId")));
				Junction exs = null;
				boolean isOr = "Or".equals(param.getExclusionOrInd()) || StringUtils.isBlank(param.getExclusionOrInd());
				if (isOr) {
					exs = Restrictions.or(new Criterion[] {});
				} else {
					exs = Restrictions.and(new Criterion[] {});
				}

				for (AsrGenericCode code : param.getExclusions()) {

					String ex = code.getCode();
					if ("And".equals(param.getExclusionOrInd())) {
						DetachedCriteria exCriteriaAnd = DetachedCriteria
								.forClass(FpsPrvdrAnlysExclusionSearch.class, "exclusionsAnd")

								.setProjection(Projections.distinct(Projections.property("exclusionsAnd.asrptId")));
						if (ex.startsWith("ASRSET")) {
							// if is my working set or is my exclusion set
							if ("ASRSET_MY_WS".equals(ex) || "ASRSET_MY_EX".equals(ex)) {
								exCriteriaAnd.add(
										Restrictions.and(Restrictions.eq("exclusionsAnd.exclusionCd", ex), Restrictions
												.eq("exclusionsAnd.cntrctrCd", loggedInUser.getUserId()).ignoreCase()));
								params.add(ex);
								params.add(loggedInUser.getUserId().toLowerCase());
							} else if ("ASRSET_MY_WS_JRSDCTN".equals(ex) || "ASRSET_MY_EX_JRSDCTN".equals(ex)) {
								// if WS or Exclusion set is in my jurisdiction
								if ("ASRSET_MY_EX_JRSDCTN".equals(ex)) {
									if ("CMS".equals(loggedInUser.getBusinessCategory()) || FpsDomainObjectConverter
											.isPimascContractor(loggedInUser.getBusinessCategory())) {
										// if I am CMS/PIMASC, don't check zone
										exCriteriaAnd
												.add(Restrictions.and(Restrictions.eq("exclusionsAnd.exclusionCd", ex),
														Restrictions
																.ne("exclusionsAnd.ownerId", loggedInUser.getUserId())
																.ignoreCase()));
										params.add(ex);
										params.add(loggedInUser.getUserId().toLowerCase());

									} else {
										// if I am not CMS/PIMASC, check for zone match
										exCriteriaAnd.add(Restrictions.and(
												Restrictions.eq("exclusionsAnd.exclusionCd", ex),
												Restrictions.eq("exclusionsAnd.cntrctrCd",
														loggedInUser.getBusinessCategory()),
												Restrictions.ne("exclusionsAnd.ownerId", loggedInUser.getUserId())
														.ignoreCase(),
												Restrictions.eq("exclusionsAnd.publicInd", "Y")));
										params.add(ex);
										params.add(loggedInUser.getBusinessCategory());
										params.add(loggedInUser.getUserId().toLowerCase());
										params.add("Y");
									}
								} else {
									exCriteriaAnd.add(Restrictions.and(Restrictions.eq("exclusionsAnd.exclusionCd", ex),
											Restrictions.ne("exclusionsAnd.ownerId", loggedInUser.getUserId())
													.ignoreCase(),
											Restrictions.eq("exclusionsAnd.cntrctrCd",
													loggedInUser.getBusinessCategory())));
									params.add(ex);
									params.add(loggedInUser.getUserId().toLowerCase());
									params.add(loggedInUser.getBusinessCategory());
								}

							}
						} else {

							if ((ex.equals("ADMIN_ACTION") || ex.equals("CASE_CLOSED") || ex.equals("UCM_CLOSED60") || ex.equals("UCM_OPEN"))
									&& (!"CMS".equals(loggedInUser.getBusinessCategory()) && !FpsDomainObjectConverter
											.isPimascContractor(loggedInUser.getBusinessCategory()))) {
							
								exCriteriaAnd.add(Restrictions.and(Restrictions.eq("exclusions.exclusionCd", ex),
										Restrictions.eq("exclusions.cntrctrCd",
												fullZone)));
								params.add(ex);
								params.add(fullZone);
							}else {
								exCriteriaAnd.add(Restrictions.eq("exclusions.exclusionCd", ex));
								params.add(ex);
							}
						}
						// exclusions by zone not yet supported
//						if ("Yes".equals(param.getExclusionMyZoneInd())) {
//
//							Disjunction zones = Restrictions
//									.or(new Criterion[] { Restrictions.eq("exclusionsAnd.cntrctrCd", fullZone),
//											Restrictions.isNull("exclusionsAnd.cntrctrCd") });
//							
//							params.add(fullZone);
//							exCriteriaAnd.add(zones);
//						}
						exCriteria.add(Subqueries.propertyIn("asrptId", exCriteriaAnd));

					} else {

						if (ex.startsWith("ASRSET")) {
							if ("ASRSET_MY_WS".equals(ex) || "ASRSET_MY_EX".equals(ex)) {
								exs.add(Restrictions.and(Restrictions.eq("exclusions.exclusionCd", ex), Restrictions
										.eq("exclusions.cntrctrCd", loggedInUser.getUserId()).ignoreCase()));
								params.add(ex);
								params.add(loggedInUser.getUserId().toLowerCase());
							} else if ("ASRSET_MY_WS_JRSDCTN".equals(ex) || "ASRSET_MY_EX_JRSDCTN".equals(ex)) {
								if ("ASRSET_MY_EX_JRSDCTN".equals(ex)) {
									if ("CMS".equals(loggedInUser.getBusinessCategory()) || FpsDomainObjectConverter
											.isPimascContractor(loggedInUser.getBusinessCategory())) {
										// if I am CMS/PIMASC, don't check zone
										exs.add(Restrictions.and(Restrictions.eq("exclusions.exclusionCd", ex),
												Restrictions.ne("exclusions.ownerId", loggedInUser.getUserId())
														.ignoreCase()));
										params.add(ex);
										params.add(loggedInUser.getUserId().toLowerCase());

									} else {
										// if I am not CMS/PIMASC, check for zone match
										exs.add(Restrictions.and(Restrictions.eq("exclusions.exclusionCd", ex),
												Restrictions.ne("exclusions.ownerId", loggedInUser.getUserId())
														.ignoreCase(),
												Restrictions.eq("exclusions.cntrctrCd",
														loggedInUser.getBusinessCategory()),
												Restrictions.eq("exclusions.publicInd", "Y")));
										params.add(ex);
										params.add(loggedInUser.getUserId().toLowerCase());
										params.add(loggedInUser.getBusinessCategory());
										params.add("Y");
									}
								} else {
									exs.add(Restrictions.and(Restrictions.eq("exclusions.exclusionCd", ex),
											Restrictions.ne("exclusions.ownerId", loggedInUser.getUserId())
													.ignoreCase(),
											Restrictions.eq("exclusions.cntrctrCd",
													loggedInUser.getBusinessCategory())));
									params.add(ex);
									params.add(loggedInUser.getUserId().toLowerCase());
									params.add(loggedInUser.getBusinessCategory());
								}

							}
						} else {
							exs.add(Restrictions.eq("exclusions.exclusionCd", ex));
							params.add(ex);
							if ((ex.equals("ADMIN_ACTION") || ex.equals("CASE_CLOSED") || ex.equals("UCM_CLOSED60") || ex.equals("UCM_OPEN"))
									&& (!"CMS".equals(loggedInUser.getBusinessCategory()) && !FpsDomainObjectConverter
											.isPimascContractor(loggedInUser.getBusinessCategory()))) {
								exs.add(Restrictions.eq("exclusions.cntrctrCd", fullZone));
								params.add(loggedInUser.getBusinessCategory());
							}
						}
					}

				}
				if (isOr) {
					exCriteria.add(exs);
					// exclusions by zone not yet supported
//					if ("Yes".equals(param.getExclusionMyZoneInd())) {
//
//						Disjunction zones = Restrictions
//								.or(new Criterion[] { Restrictions.eq("exclusions.cntrctrCd", fullZone),
//										Restrictions.isNull("exclusions.cntrctrCd") });
//						// Restrictions.eq("exclusions.cntrctrCd", fullZone),
//						// Restrictions.isNull("exclusions.cntrctrCd") });
//						params.add(fullZone);
//						exCriteria.add(zones);
//					}

				}
				c.add(Subqueries.propertyNotIn("asrptId", exCriteria));

			}

			// preset search flag
			if (StringUtils.isNotBlank(param.getPresetSearchFlag())) {
				Calendar cal30 = Calendar.getInstance();
				cal30.add(Calendar.DATE, -30);
				Calendar cal180 = Calendar.getInstance();
				cal180.add(Calendar.DATE, -180);

				Object presetCol = "";
				FpsEnums.PreSetSearch pss = FpsEnums.PreSetSearch.getValue(param.getPresetSearchFlag());
				switch (pss) {

				case OTHERZONEWORKLOAD:

					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTJOIN, aliases);

					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSUSERINVESTJOIN, aliases);
					params.add("11");

					c.add(Restrictions.eq("invest.stusCd", "11"));

					if (pss.equals(PreSetSearch.OTHERZONEWORKLOAD)) {
						params.add(ucmZone);
						c.add(Restrictions.ne("userInvest.asgnedCntrctr", ucmZone));
						params.add(fullZone);
						c.add(Restrictions.eq("report.jurisdiction", fullZone));

					}
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
					params.add(cal180);
					c.add(Restrictions.ge("alert.alertCreatDt", cal180));
					break;

				case MACASR30NOUCM:
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
					params.add(loggedInUser.getBusinessCategory());

					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMACASCTNJOIN, aliases);
					c.add(Restrictions.eq("prvdrMacLookup.macJurisdiction", loggedInUser.getBusinessCategory()));
					c.add(Restrictions.le("report.asrptRiskScreNum", "0.5"));
					params.add("0.5");
					if (pss.equals(FpsEnums.PreSetSearch.MACASR30NOUCM)) {
						DetachedCriteria noOpenUCM = DetachedCriteria.forClass(FpsAsrptInvstgtn.class, "openInvest")
								.add(Restrictions.eq("openInvest.stusCd", "11"))
								.setProjection(Projections.distinct(Projections.property("openInvest.asrptId")));
						// updateAliases(c,
						// FpsEnums.AsrSearchCriteria.NEEDSINVESTLEFTJOIN,
						// aliases);
						params.add("11");
						// c.add(Restrictions.ne("investLeft.stusCd",
						// "11"));
						c.add(Subqueries.propertyNotIn("asrptId", noOpenUCM));
					}

					params.add(cal30.getTime());
					params.add(cal30.getTime());
					c.add(Restrictions.or(Restrictions.ge("alert.alertCreatDt", cal30.getTime()),
							Restrictions.ge("report.asrptCreatDt", cal30.getTime())));
					// c.add(Restrictions.isNull("investLeft.extrnlCaseId"));
					break;

				case ASRPRIORITYNOUCM:

					params.add(fullZone);

//					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSINVESTLEFTJOIN, aliases);
					c.add(Restrictions.eq("report.jurisdiction", fullZone));
//					c.add(Restrictions.isNull("investLeft.asrptId"));
//					c.add(Restrictions.isNotNull("investLeft.extrnlCaseId"));

					DetachedCriteria subqueryInvest = DetachedCriteria.forClass(FpsAsrptInvstgtn.class, "investLeft")
							.add(Restrictions.isNotNull("investLeft.extrnlCaseId"))
							.setProjection(Projections.property("investLeft.asrptId"));
					// params.add(loggedInUser.getBusinessCategory());
					c.add(Subqueries.propertyNotIn("asrptId", subqueryInvest));

					if (pss.equals(FpsEnums.PreSetSearch.ASRPRIORITYNOUCM)) {
						// updateAliases(c,
						// FpsEnums.AsrSearchCriteria.NEEDSASRPRRTYJOIN,
						// aliases);
						DetachedCriteria subqueryPriority = DetachedCriteria.forClass(FpsAsrptPrrty.class, "priority")
								.add(Restrictions.eq("priority.cntrctrCd", loggedInUser.getBusinessCategory()))
								.setProjection(Projections.property("priority.asrptId"));
						params.add(loggedInUser.getBusinessCategory());
						c.add(Subqueries.propertyIn("asrptId", subqueryPriority));
					}

					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
					params.add(cal180);
					c.add(Restrictions.ge("alert.alertCreatDt", cal180));
					break;

				case MACRRB:
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSMACASCTNJOIN, aliases);
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSASRRRBCLMJOIN, aliases);

					params.add(loggedInUser.getBusinessCategory());
					c.add(Restrictions.eq("prvdrMacLookup.macJurisdiction", loggedInUser.getBusinessCategory()));
					updateAliases(c, FpsEnums.AsrSearchCriteria.NEEDSALERTJOIN, aliases);
					params.add(cal30);
					c.add(Restrictions.ge("alert.alertCreatDt", cal30));

					DetachedCriteria noOpenUCMRrb = DetachedCriteria.forClass(FpsAsrptInvstgtn.class, "rrbOpenInvest")
							.createAlias("rrbOpenInvest.fpsAsrptUserInvstgtns", "rrbOpenInvestUser")
							.add(Restrictions.eq("rrbOpenInvestUser.asgnedCntrctr", ucmZone))
							.add(Restrictions.eq("rrbOpenInvest.stusCd", "11"))
							.setProjection(Projections.distinct(Projections.property("rrbOpenInvest.asrptId")));
					params.add(ucmZone);
					params.add("11");

					c.add(Subqueries.propertyNotIn("asrptId", noOpenUCMRrb));

					break;
				case MEDIC:

					c.add(Restrictions.eq("partDInd", "Y"));
					params.add("Y");
					DetachedCriteria noOpenUCMMedic = DetachedCriteria
							.forClass(FpsAsrptInvstgtn.class, "medicOpenInvest")
							.createAlias("medicOpenInvest.fpsAsrptUserInvstgtns", "medicOpenInvestUser")
							.add(Restrictions.eq("medicOpenInvestUser.asgnedCntrctr", ucmZone))
							.add(Restrictions.eq("medicOpenInvest.stusCd", "11"))
							.setProjection(Projections.distinct(Projections.property("medicOpenInvest.asrptId")));
					params.add(ucmZone);
					params.add("11");

					// params.add(subquery);
					c.add(Subqueries.propertyNotIn("asrptId", noOpenUCMMedic));

					break;

				default:
					params.add(Integer.valueOf(0));
					c.add(Restrictions.eq("asrptId", Integer.valueOf(0)));
				}
			}

			if (addSuffixes) {
				if (param.getCostSortDir() != null) {
					FpsEnums.CostSortDir csd = FpsEnums.CostSortDir.getValue(param.getCostSortDir());
					switch (csd) {
					case H2L:
						c.addOrder(Order.desc("asrptCstAmt"));

						break;
					case L2H:
					default:
						c.addOrder(Order.asc("asrptCstAmt"));

						break;
					}
				} else if (!hasOrderBy) {
					c.addOrder(Order.desc("asrptRiskScreNum"));
					c.addOrder(Order.desc("asrptCstAmt"));
				}
			}

			if (params.size() > 0) {
				hasValidParams = true;
			}
			if (!hasValidParams) {
				params.add(Integer.valueOf(0));
				c.add(Restrictions.eq("asrptId", Integer.valueOf(0)));
			}
		}
		return params;
	}

	public static void buildCriteriaOrderBy(Criteria c, AsrSearchParameter param, ProjectionList projections) {
		boolean hasOrderBy = false;
		FpsEnums.PreSetSearch pss = FpsEnums.PreSetSearch.getValue(param.getPresetSearchFlag());
		switch (pss) {
		case HIGHRISKASRS:
		case HIGHRISKUN:
			if (projections != null) {
				c.setProjection(projections.add(
						Projections.sqlProjection("coalesce( {alias}.ASRPT_RISK_SCRE_NUM, 0)  as ASRPT_RISK_SCRE_NUM ",
								new String[] { "ASRPT_RISK_SCRE_NUM" }, new Type[] { new BigDecimalType() })));
				c.setProjection(
						projections.add(Projections.sqlProjection("coalesce({alias}.ASRPT_CST_AMT, 0) as ASRPT_CST_AMT",
								new String[] { "ASRPT_CST_AMT" }, new Type[] { new BigDecimalType() })));
			}
			c.addOrder(new NativeSQLOrder("coalesce(  {alias}.ASRPT_RISK_SCRE_NUM, 0)", false));
			hasOrderBy = true;
		}
		if (param.getCostSortDir() != null) {
			hasOrderBy = true;
			if (projections != null) {
				c.setProjection(projections.add(Projections.property("asrptCstAmt")));
			}
			FpsEnums.CostSortDir csd = FpsEnums.CostSortDir.getValue(param.getCostSortDir());
			switch (csd) {
			case H2L:
				c.addOrder(Order.desc("asrptCstAmt"));

				break;
			case L2H:
			default:
				c.addOrder(Order.asc("asrptCstAmt"));

				break;
			}
		} else if (!hasOrderBy) {
			c.addOrder(new NativeSQLOrder("coalesce( {alias}.ASRPT_RISK_SCRE_NUM, 0)", false));

			c.addOrder(new NativeSQLOrder("coalesce( {alias}.ASRPT_CST_AMT , 0)", false));
			if (projections != null) {
				c.setProjection(projections.add(
						Projections.sqlProjection("coalesce( {alias}.ASRPT_RISK_SCRE_NUM, 0)  as ASRPT_RISK_SCRE_NUM ",
								new String[] { "ASRPT_RISK_SCRE_NUM" }, new Type[] { new BigDecimalType() })));
				c.setProjection(
						projections.add(Projections.sqlProjection("coalesce({alias}.ASRPT_CST_AMT, 0) as ASRPT_CST_AMT",
								new String[] { "ASRPT_CST_AMT" }, new Type[] { new BigDecimalType() })));
			}
		}
	}

	@Override
	public void clearCache() {
		Session session = getCurrentSession();
		if (session != null) {
			session.clear();
		}
		getCurrentSession().getSessionFactory().getCache().evictCollectionRegions();
		getCurrentSession().getSessionFactory().getCache().evictDefaultQueryRegion();
		getCurrentSession().getSessionFactory().getCache().evictEntityRegions();
		getCurrentSession().getSessionFactory().getCache().evictQueryRegions();
		getCurrentSession().getSessionFactory().getCache().evictNaturalIdRegions();
	}

	@Override
	public List<Integer> getFidsForAsr(String npi) {
		Long npiLong = Long.parseLong(npi);
		Criteria c = getCurrentSession().createCriteria(FpsFdFrdCase.class, "fid")
				.createAlias("fpsFdFrdSubj", "subj", JoinType.INNER_JOIN)
				.add(Restrictions.eq("subj.fraudSubjNpiNum", npiLong))
				.setProjection(Projections.distinct(Projections.property("fraudInvstgtnNum")));

		return c.list();
	}

	@Override
	public AsrSummaryRollupCounts getAsrSummaryRollupCounts(int asrptId) {
		String sql = " select count(distinct Aplctn_User_Id) , 'user' from fps2.FPS_ASRPT_USER  where ASRPT_ID = :asrptId and ACTV_IND = 'Y'  union  select count( *), 'invest'  from fps2.FPS_ASRPT_INVSTGTN  where ASRPT_ID = :asrptId   union  select count(distinct d.clm_type_cd), 'claimtype' from fps_asrpt a  inner join fps2.fps_asrpt_alert_asctn b on a.asrpt_id = b.asrpt_id  inner join fps2.fps_alert c on b.alert_id = c.alert_id  inner join fps2.fps_model d on c.model_id = d.model_Id  where  a.asrpt_id = :asrptId   union  select 0, 'proc'  from fps2.fps_asrpt a   where a.asrpt_id = :asrptId   union  select count(distinct asgned_cntrctr), 'zone'  from fps2.FPS_ASRPT a inner join fps2.FPS_ASRPT_INVSTGTN b on a.asrpt_id = b.asrpt_id  inner join fps2.fps_asrpt_user_invstgtn c on c.asrpt_invstgtn_id = b.asrpt_invstgtn_id  where  a.asrpt_id = :asrptId  union  select count(distinct c.ACTN_BRR_CD), 'barrier'  from fps2.FPS_ASRPT a inner join fps2.FPS_ASRPT_INVSTGTN b on a.asrpt_id = b.asrpt_id  inner join fps2.fps_asrpt_user_actn_brr c on c.asrpt_invstgtn_id = b.asrpt_invstgtn_id  where  a.asrpt_id = :asrptId and c.ACTN_BRR_CD != '-1'  union  select count(distinct c.ACTN_TYPE_CD), 'action'  from FPS_ASRPT a inner join fps2.FPS_ASRPT_INVSTGTN b on a.asrpt_id = b.asrpt_id  inner join fps2.fps_asrpt_user_Adminv_Actn c on c.asrpt_invstgtn_id = b.asrpt_invstgtn_id  where  a.asrpt_id = :asrptId    union  select 0 , 'spec' from fps2.fps_asrpt a  where a.asrpt_id = :asrptId  union  select count(distinct d.model_busns_id), 'alert'  from fps2.fps_asrpt a  inner join fps2.fps_asrpt_alert_asctn b on a.asrpt_id = b.asrpt_id  inner join fps2.fps_alert c on b.alert_id = c.alert_id  inner join fps2.fps_model d on d.model_id = c.model_id  where a.asrpt_id = :asrptId  union  select count(distinct ACTVTY_TYPE_CD),  'activity'  from fps2.FPS_ASRPT a inner join fps2.FPS_ASRPT_INVSTGTN b on a.asrpt_id = b.asrpt_id  inner join fps2.fps_asrpt_user_actvty c on c.asrpt_invstgtn_id = b.asrpt_invstgtn_id  where  a.asrpt_id = :asrptId ";

		SQLQuery query = getCurrentSession().createSQLQuery(sql);
		query.setParameter("asrptId", Integer.valueOf(asrptId));
		long start1 = System.currentTimeMillis();
		List<Object[]> rows = query.list();
		long end1 = System.currentTimeMillis();
		if ((end1 - start1) / 1000L > 2L) {
			logger.info(asrptId + " query - " + (end1 - start1) / 1000L);
		}
		AsrSummaryRollupCounts roll = new AsrSummaryRollupCounts();
		for (Object[] row : rows) {
			if (row[0] != null) {
				Integer count = (Integer) row[0];
				String type = row[1].toString();
				if ("alert".equals(type)) {
					roll.setAlertCnt(count);
				} else if ("spec".equals(type)) {
					roll.setSpecialtyCnt(count);
				} else if ("action".equals(type)) {
					roll.setActionCnt(count);
				} else if ("barrier".equals(type)) {
					roll.setBarrierCdCnt(count);
				} else if ("zone".equals(type)) {
					roll.setAssignedZoneCnt(count);
				} else if ("invest".equals(type)) {
					roll.setInvestCnt(count);
				} else if ("activity".equals(type)) {
					roll.setActivityCnt(count);
				} else if ("user".equals(type)) {
					roll.setUserCnt(count);
				} else if ("claimtype".equals(type)) {
					roll.setClaimTypeCnt(count);
				} else if ("proc".equals(type)) {
					roll.setProcedureCnt(count);
				}
			}
		}
		return roll;
	}

	private LdapQuery buildBaseQuery() {
		String ldapUser = this.env.getProperty("ldap.user");
		String ldapUrl = this.env.getProperty("ldap.url");
		String ldapPasswordEnc = this.env.getProperty("ldap.password");
		String ldapPassword = new String(Base64.decodeBase64(ldapPasswordEnc.getBytes()));
		String ldapBaseDn = this.env.getProperty("ldap.baseDn");
		LdapQuery query = new LdapQuery();
		query.setUrl(ldapUrl);
		query.setBaseDn(ldapBaseDn);
		query.setPassword(ldapPassword);
		query.setUsername(ldapUser);
		String localMode = this.env.getProperty("ldap.test");
		query.setMode(localMode != null ? "Y" : "N");
		return query;
	}

	@Override
	public List<FpsUser> getOpenAMUser(String userId) {
		if ("true".equals(env.getProperty("okta.enabled"))) {
			logger.fine("searching with okta");
			return getOktaUser(userId);
		}
		logger.fine("searching with openam");
		LdapQuery query = buildBaseQuery();

		query.setFilter("(uid=" + userId + ")");

		List<FpsUser> fpsUsers = null;

		fpsUsers = LdapUtil.getOpenAMUser(query);
		if (fpsUsers.size() == 0) {
			logger.fine("Ldap advanced search for " + userId + " returned " + fpsUsers.size() + " results");
		}
		return fpsUsers;
	}
	@Override
	public OktaGroup getOktaGroupIdFromName(String groupName) {
	

		List<FpsUser> fpsUsers = null;

		OktaGroup gp = LdapUtil.getOktaGroupIdFromName(groupName);
	
		return gp;
	}
	@Override
	public List<FpsUser> getOktaUser(String userId) {
	

		List<FpsUser> fpsUsers = null;

		fpsUsers = LdapUtil.getOktaUser(userId);
		if (fpsUsers.size() == 0) {
			logger.fine("Ldap advanced search for " + userId + " returned " + fpsUsers.size() + " results");
		}
		return fpsUsers;
	}
	@Override
	public List<FpsUser> getOktaGroupByUser(String userId, String groupId) {
		LdapQuery query = buildBaseQuery();
		String filter = "(&(uniqueMember=*" + userId + "*)(cn=" + groupId + "))";
		query.setFilter(filter);
	
		List<FpsUser> fpsUsers = null;
		OktaGroup g = getOktaGroupIdFromName(groupId);
		fpsUsers = LdapUtil.getOktaUsersByGroup(g.getId());
		List<FpsUser> filtered = fpsUsers.stream().filter(user -> user.getUserId().equals(userId))
				.collect(Collectors.toList());

		if (filtered.size() == 0) {
			logger.fine("Ldap advanced search for " + filter + " returned no results");
		} else {
			logger.fine("found " + filtered.size() + " results for " + filter);
		}
		return filtered;
	}
	@Override
	public List<FpsUser> getOktaGroupMembership( String groupId) {
		
		
		List<FpsUser> fpsUsers = null;

		fpsUsers = LdapUtil.getOktaUsersByGroup(groupId);
		

		if (fpsUsers.size() == 0) {
			logger.fine("Ldap advanced search for " + groupId + " returned no results");
		} else {
			logger.fine("found " + fpsUsers.size() + " results for " + groupId);
		}
		return fpsUsers;
	}
	@Override
	public List<FpsUser> getOpenAMGroupByUser(String userId, String groupId) {
		if ("true".equals(env.getProperty("okta.enabled"))) {
			logger.fine("searching with okta");
			return getOktaGroupByUser(userId, groupId);
		}
		logger.fine("searching with openam");
		LdapQuery query = buildBaseQuery();
		String filter = "(&(uniqueMember=*" + userId + "*)(cn=" + groupId + "))";
		query.setFilter(filter);

		List<FpsUser> fpsUsers = null;

		fpsUsers = LdapUtil.getOpenAMGroupByMember(query);

		if (fpsUsers.size() == 0) {
			logger.fine("Ldap advanced search for " + filter + " returned no results");
		} else {
			logger.fine("found " + fpsUsers.size() + " results for " + filter);
		}
		return fpsUsers;
	}

	@Transactional
	@Deprecated
	public String reassignAsr(int asrptId, String userId, String toUserId, String supervisorId) {
		List<FpsAsrpt> asrs = getCurrentSession().createCriteria(FpsAsrpt.class)
				.add(Restrictions.eqOrIsNull("asrptId", Integer.valueOf(asrptId))).list();
		if ((asrs == null) || (asrs.size() == 0)) {
			return "No ASR found for " + asrptId;
		}
		FpsAsrptUser oldReportUser = loadAsrUser(asrptId, userId);
		FpsAsrpt asrpt = null;
		if (oldReportUser != null) {
			asrpt = oldReportUser.getFpsAsrpt();
			oldReportUser.setActvInd("N");
			oldReportUser.setTrmntnDt(new Date());
			oldReportUser.setAudtUpdtTs(new Date());
			oldReportUser.setAudtUpdtId(supervisorId);
			getCurrentSession().update(oldReportUser);
		}
		FpsAsrptUser newReportUser = new FpsAsrptUser();
		if (asrpt == null) {
			asrpt = new FpsAsrpt();
			asrpt.setAsrptId(asrptId);
		}
		newReportUser.setFpsAsrpt(asrpt);

		newReportUser.setAplctnUserId(toUserId);
		newReportUser.setActvInd("Y");
		newReportUser.setEfctvDt(new Date());
		newReportUser.setFpsVrsnInd("2");
		newReportUser.setAudtInsrtId(supervisorId);
		newReportUser.setAudtInsrtTs(new Date());
		getCurrentSession().save(newReportUser);

		FpsAsrpt asr = (FpsAsrpt) asrs.get(0);
		// FpsAsrptLog log = new FpsAsrptLog();
		// log.setActvtyActnInd("A");
		// log.setAplctnUserId(userId);
		// log.setAsrptLogDt(new Date());
		// log.setAudtInsrtId(supervisorId);
		// log.setAudtInsrtTs(new Date());
		// log.setFpsVrsnInd(asr.getFpsVrsnInd());
		// log.setAsrptId(asr.getAsrptId());
		// if (asr.getAsrptRiskScreNum() != null) {
		// log.setAsrptRiskScre(asr.getAsrptRiskScreNum());
		// }
		String asrptDesc = "ASR " + asr.getSubjId() + ": reassigned to " + userId + " by " + supervisorId;
		// log.setAsrptDesc(asrptDesc);
		//
		// getCurrentSession().save(log);
		insertAsrHistory(userId, supervisorId, null, asr.getAsrptId(), asr.getAsrptRiskScreNum(), asrptDesc,
				asr.getFpsVrsnInd(), "A");
		return asrptDesc;
	}

	@Override
	public FpsModel updateModel(FpsModel m) {
		FpsModel model = (FpsModel) getCurrentSession().createCriteria(FpsModel.class)
				.add(Restrictions.eq("modelId", Integer.valueOf(m.getModelId()))).uniqueResult();
		model.setModelDesc(m.getModelDesc());
		model.setModelCmsOwnrName(m.getModelCmsOwnrName());
		model.setOwnrCntctEmailTxt(m.getOwnrCntctEmailTxt());
		model.setOwnrCntctPhneNum(m.getOwnrCntctPhneNum());
		model.setModelActvtyStus(m.getModelActvtyStus());
		model.setAudtUpdtId(m.getAudtUpdtId());
		model.setPriorityInd(m.getPriorityInd());
		// model.setLoopback(m.getLoopback);
		getCurrentSession().merge(model);

		return m;
	}

	@Override
	public FpsAsrpt findAsrBySubjId(String subjId) {
		return (FpsAsrpt) getCurrentSession().createCriteria(FpsAsrpt.class).add(Restrictions.eq("subjId", subjId))
				.uniqueResult();
	}
	@Override
	public FpsAsrptMdcd findMdcdAsrBySubjId(String subjId) {
		return (FpsAsrptMdcd) getCurrentSession().createCriteria(FpsAsrptMdcd.class).add(Restrictions.eq("subjId", subjId))
				.uniqueResult();
	}
	@Override
	public FpsPrvdrAnlys findPrvdrAnlysBySubjId(String subjId) {
		return (FpsPrvdrAnlys) getCurrentSession().createCriteria(FpsPrvdrAnlys.class)
				.add(Restrictions.eq("prvdrNpiNum", subjId)).uniqueResult();
	}

	@Override
	public Integer findAsrIdBySubjId(String subjId) {
		Integer retval = null;

		SQLQuery query = getCurrentSession().createSQLQuery("select asrpt_id from fps2.fps_asrpt where subj_id = :subjId");
		query.setParameter("subjId", subjId);
		retval = (Integer) query.uniqueResult();
		return retval;
	}
	@Override
	public Integer findMdcdAsrIdBySubjId(String subjId) {
		Integer retval = null;

		SQLQuery query = getCurrentSession().createSQLQuery("select asrpt_id from fps2.fps_asrpt_mdcd where subj_id = :subjId");
		query.setParameter("subjId", subjId);
		retval = (Integer) query.uniqueResult();
		return retval;
	}
	@Override
	public void insertAsrHistory(FpsAsrptLog log) {
		getCurrentSession().save(log);

	}

	@Override
	public FpsAsrpt findAsrByAsrId(Integer asrId) {
		return (FpsAsrpt) getCurrentSession().createCriteria(FpsAsrpt.class).add(Restrictions.eq("asrptId", asrId))
				.uniqueResult();
	}

	@Override
	public FpsPrvdrAnlys findPrvdrAnylsByAsrId(Integer asrId) {
		return (FpsPrvdrAnlys) getCurrentSession().createCriteria(FpsPrvdrAnlys.class)
				.add(Restrictions.eq("asrptId", asrId)).uniqueResult();
	}
	@Override
	public FpsAsrptSummaryAsrsMdcd findMdcdSummaryByAsrId(Integer asrId) {
		return (FpsAsrptSummaryAsrsMdcd) getCurrentSession().createCriteria(FpsAsrptSummaryAsrsMdcd.class)
				.add(Restrictions.eq("asrptId", asrId)).uniqueResult();
	}
	@Override
	public FpsAsrptInvstgtn getInvestigationById(int investId) {
		return (FpsAsrptInvstgtn) getCurrentSession().createCriteria(FpsAsrptInvstgtn.class)
				.add(Restrictions.eq("asrptInvstgtnId", investId)).uniqueResult();
	}

	@Transactional
	public <T> T save(T o) {
		getCurrentSession().save(o);
		;
		return o;
	}
	@Transactional
	public <T> void  saveBatch(List<T> o) {
		
		int i = 0;;
		for ( T x : o) {
			try {
			getCurrentSession().save(x);
			}catch (Exception e) {
				
			}
			if ( i % 20 == 0) {
				getCurrentSession().flush();
				getCurrentSession().clear();
			}
			i++;
		}
		
		;
	
		
	}
	@Override
	@Deprecated
	public String softDeleteLead(AsrDeleteLead inv) {
		FpsAsrptInvstgtn invest = (FpsAsrptInvstgtn) getCurrentSession().createCriteria(FpsAsrptInvstgtn.class)
				.add(Restrictions.eq("asrptInvstgtnId", inv.getInvestId())).uniqueResult();
		String userId = inv.getUserId();
		String userZone = inv.getUserZone();
		Integer investId = inv.getInvestId();
		String retval = "Error";
		if (invest != null) {
			// load user
			LdapQuery query = buildBaseQuery();

			query.setFilter("(uid=" + invest.getAudtInsrtId() + ")");

			List<FpsUser> users = LdapUtil.getOpenAMUser(query);
			FpsUser user = (users != null) && (users.size() > 0) ? (FpsUser) users.get(0) : null;
			if (user != null) {
				String createdZone = user.getBusinessCategory();
				if (createdZone == null) {
					logger.warning("User with lead has no OpenAm zone: " + invest.getAudtInsrtId());
				}
				if (createdZone != null && !createdZone.equals(userZone)) {
					retval = "Error deleting lead.  User " + userId + " is in " + userZone + ".  Lead " + investId
							+ " was created by " + user.getUserId() + " in " + user.getBusinessCategory();
					insertAsrHistory(userId, userId, investId, invest.getAsrptId(),
							invest.getFpsAsrpt().getAsrptRiskScreNum(), retval, invest.getFpsVrsnInd(), "A");
					return retval;
				}
			}
			if (invest.getFpsAsrptUserAdminvActns().size() > 0) {
				retval = "Error deleting lead.  Lead " + investId + " has at least one Action";
				insertAsrHistory(userId, userId, investId, invest.getAsrptId(),
						invest.getFpsAsrpt().getAsrptRiskScreNum(), retval, invest.getFpsVrsnInd(), "A");
				return retval;
			}
			if (invest.getFpsAsrptUserRulngs().size() > 0) {
				retval = "Error deleting lead.  Lead " + investId + " has at least one Ruling";
				insertAsrHistory(userId, userId, investId, invest.getAsrptId(),
						invest.getFpsAsrpt().getAsrptRiskScreNum(), retval, invest.getFpsVrsnInd(), "A");
				return retval;
			}
			invest.setRecChgInd("D");
			invest.setActvInd("N");
			invest.setTrmntnDt(new Date());
			invest.setAudtUpdtId(userId);
			invest.setAudtUpdtTs(new Date());
			getCurrentSession().merge(invest);
			String text = "User " + userId + " deleted lead " + investId + " for ASR "
					+ invest.getFpsAsrpt().getSubjId();
			if (StringUtils.isNotBlank(inv.getComments())) {
				text += ". Reason: " + inv.getComments();
			}
			retval = text;
			insertAsrHistory(userId, userId, investId, invest.getAsrptId(), invest.getFpsAsrpt().getAsrptRiskScreNum(),
					text, invest.getFpsVrsnInd(), "D");
		} else {
			retval = "Error deleting lead.  Lead " + investId + "  not found";
		}
		return retval;

	}

	@Override
	public void reassignInvestigation(int invId, String userId) {
		List<FpsUser> fpsUsers = getOpenAMUser(userId);

		FpsUser loggedInUser = null;
		loggedInUser = (fpsUsers != null) && (fpsUsers.size() > 0) ? (FpsUser) fpsUsers.get(0) : null;
		if (loggedInUser == null) {
			return;
		}
		List<FpsAsrptUserInvstgtn> invs = getCurrentSession().createCriteria(FpsAsrptUserInvstgtn.class)
				.add(Restrictions.eqOrIsNull("fpsAsrptInvstgtn.asrptInvstgtnId", Integer.valueOf(invId)))
				.setMaxResults(1).addOrder(Order.desc("audtInsrtTs")).list();
		if ((invs == null) || (invs.size() == 0)) {
			return;
		}
		FpsAsrptUserInvstgtn userInv = (FpsAsrptUserInvstgtn) invs.get(0);
		Integer i = Integer.valueOf(invId);
		String previousAssignedUser = userInv.getAsgnedUserId();
		userInv.setAudtUpdtId(userInv.getAsgnedUserId());

		userInv.setAsgnedUserId(userId);
		userInv.setAsgnedCntrctr(loggedInUser.getBusinessCategory());
		userInv.setAudtUpdtTs(new Date());
		getCurrentSession().save(userInv);

		// FpsAsrptLog log = new FpsAsrptLog();
		// log.setActvtyActnInd("A");
		// log.setAplctnUserId(userInv.getAsgnedUserId());
		// log.setAsrptInvstgtnId(i);
		// log.setAsrptLogDt(new Date());
		// log.setAudtInsrtId(userInv.getAsgnedUserId());
		// log.setAudtInsrtTs(new Date());
		// log.setFpsVrsnInd(userInv.getFpsVrsnInd());
		FpsAsrpt asr = userInv.getFpsAsrptInvstgtn().getFpsAsrpt();
		// log.setAsrptId(asr.getAsrptId());
		// if (asr.getAsrptRiskScreNum() != null) {
		// log.setAsrptRiskScre(asr.getAsrptRiskScreNum());
		// }
		String asrptDesc = "ASR " + asr.getSubjId() + ": Investigation " + invId + " reassigned to " + userId + " from "
				+ previousAssignedUser;
		// log.setAsrptDesc("ASR " + asr.getSubjId() + ": Investigation " +
		// invId + " reassigned to " + userId + " by "
		// + previousAssignedUser);
		insertAsrHistory(userInv.getAsgnedUserId(), userInv.getAsgnedUserId(), i, asr.getAsrptId(),
				asr.getAsrptRiskScreNum(), asrptDesc, asr.getFpsVrsnInd(), "A");
		// getCurrentSession().save(log);
	}

	@Override
	public FpsAlert findHistoricAlert(int modelId, String npi, Date alertDt) {
		Calendar calMinus = Calendar.getInstance();
		calMinus.setTime(alertDt);
		calMinus.set(Calendar.HOUR, 0);
		calMinus.set(Calendar.MINUTE, 0);
		calMinus.set(Calendar.SECOND, 0);

		Calendar calPlus = Calendar.getInstance();
		calPlus.setTime(alertDt);
		calPlus.set(Calendar.HOUR, 23);
		calPlus.set(Calendar.MINUTE, 59);
		calPlus.set(Calendar.SECOND, 59);
		List<FpsAlert> alerts = getCurrentSession().createCriteria(FpsAlert.class).createAlias("fpsModel", "model")
				.add(Restrictions.eq("subjId", npi)).add(Restrictions.eq("model.modelId", modelId))
				.add(Restrictions.eq("alertCreatDt", alertDt)).list();
		if (alerts != null && alerts.size() > 0) {
			return alerts.get(0);
		}
		return null;
	}

	@Override
	public FpsAlert findHistoricAlert(String modelId, String npi, Date alertDt) {
		Calendar calMinus = Calendar.getInstance();
		calMinus.setTime(alertDt);
		calMinus.set(Calendar.HOUR, 0);
		calMinus.set(Calendar.MINUTE, 0);
		calMinus.set(Calendar.SECOND, 0);

		Calendar calPlus = Calendar.getInstance();
		calPlus.setTime(alertDt);
		calPlus.set(Calendar.HOUR, 23);
		calPlus.set(Calendar.MINUTE, 59);
		calPlus.set(Calendar.SECOND, 59);
		List<FpsAlert> alerts = getCurrentSession().createCriteria(FpsAlert.class).createAlias("fpsModel", "model")
				.add(Restrictions.eq("subjId", npi)).add(Restrictions.eq("model.modelBusnsId", modelId))
				.add(Restrictions.eq("alertCreatDt", alertDt)).list();
		if (alerts != null && alerts.size() > 0) {
			return alerts.get(0);
		}
		return null;
	}

	@Override
	public List<FpsUser> getOpenAMUsersByRoleOrAttribute(String roleAttr) {
		if ("true".equals(env.getProperty("okta.enabled"))) {
			logger.info("searching with okta");
			return getOktaGroupMembership(roleAttr);
		}
		logger.info("searching with openam");
		LdapQuery query = buildBaseQuery();
		String filter = "(|(" + roleAttr + "=1)(employeeType=" + roleAttr + "))";
		query.setFilter(filter);
		logger.info("filter = " + filter);
		List<FpsUser> fpsUsers = null;

		fpsUsers = LdapUtil.getOpenAMUser(query);
		if (fpsUsers.size() == 0) {
			logger.fine("Ldap advanced search for role " + roleAttr + " returned " + fpsUsers.size() + " results");
		}
		return fpsUsers;
	}

	@Override
	public List<FpsUser> getOpenAMUsersByRoleOrAttribute(String roleAttr, String zone) {
		List<FpsUser> fpsUsers = null;
		if ("true".equals(env.getProperty("okta.enabled"))) {
			logger.info("searching with okta");
			List<FpsUser> fpsUsersRole = getOktaGroupMembership(roleAttr);;
			logger.info("role list has  " + fpsUsersRole.size());
			OktaGroup g = LdapUtil.getOktaGroupIdFromName("FPSUI Zone " + zone);
			List<FpsUser> fpsUsersZone = g.getId() != null ? getOktaGroupMembership(g.getId()): new ArrayList<FpsUser>();
			logger.info("zone list has  " + fpsUsersZone.size());
			fpsUsers = fpsUsersRole.stream()
						.filter(e -> fpsUsersZone.stream()
								.anyMatch(f -> e.getUserId().equals(f.getUserId()))
								)
						.collect(Collectors.toList());
		}else {
			logger.info("searching with openam");
			LdapQuery query = buildBaseQuery();

			String filter = "(&((businessCategory=" + zone + ")(|(" + roleAttr + "=1)(employeeType=" + roleAttr + "))))";
			query.setFilter(filter);
			logger.info("filter = " + filter);
			fpsUsers = LdapUtil.getOpenAMUser(query);

		}
		
		
		logger.info("final list has  " + fpsUsers.size());
		if (fpsUsers.size() == 0) {
			logger.fine("Ldap advanced search for role " + roleAttr +" and "+zone + " returned " + fpsUsers.size() + " results");
		}
		return fpsUsers;
	}

	@Override
	public Set<Object> verifyAsrs(List<Object> asrptIds) {
		return verifyAsrs(asrptIds, true);
	}

	@Override
	public Set<Object> verifyAsrs(List<Object> asrptIds, boolean returnMissing) {
		List<Object[]> availables = new ArrayList<Object[]>();

		Criteria c2 = getCurrentSession().createCriteria(FpsAsrpt.class, "asr");
		boolean isNpi = true;
		if (asrptIds != null && asrptIds.size() > 0 && asrptIds.get(0).toString().length() < 10) {
			isNpi = false;
		}
		if (isNpi) {
			c2.add(Restrictions.in("asr.subjId", asrptIds));
			c2.setProjection(Projections.property("asr.subjId"));

		} else {
			c2.add(Restrictions.in("asr.asrptId", asrptIds));
			c2.setProjection(Projections.property("asr.asrptId"));

		}
		// FPS-620
		// avoid returning ASR records with no alerts and no prioritizations
		// (summaryVisibleInd = N)
		DetachedCriteria napSubquery = DetachedCriteria.forClass(FpsAsrptSrcTypeVw.class, "naps");
		napSubquery.setProjection(Projections.distinct(Projections.property("asrptId")));
		napSubquery.add(Restrictions.ne("summaryVisibleInd", "N"));

		c2.add(Subqueries.propertyIn("asrptId", napSubquery));
		availables = c2.list();

		Set<Object> availableAsrs = new HashSet<>();
		for (Object o : availables) {
			availableAsrs.add(o);
		}
		// if we want to return the ASRs not found
		if (returnMissing) {
			Set<Object> searchAsrs = new HashSet<>(asrptIds);
			return Sets.difference(searchAsrs, availableAsrs);
		}
		// otherwise return the ASRs that are found
		return availableAsrs;
	}
	@Override
	public Set<Object> verifyMdcdAsrs(List<Object> asrptIds) {
		return verifyMdcdAsrs(asrptIds, true);
	}

	@Override
	public Set<Object> verifyMdcdAsrs(List<Object> asrptIds, boolean returnMissing) {
		List<Object[]> availables = new ArrayList<Object[]>();

		Criteria c2 = getCurrentSession().createCriteria(FpsAsrptMdcd.class, "asr");
		boolean isNpi = true;
		if (asrptIds != null && asrptIds.size() > 0 && asrptIds.get(0).toString().length() < 10) {
			isNpi = false;
		}
		if (isNpi) {
			c2.add(Restrictions.in("asr.subjId", asrptIds));
			c2.setProjection(Projections.property("asr.subjId"));

		} else {
			c2.add(Restrictions.in("asr.asrptId", asrptIds));
			c2.setProjection(Projections.property("asr.asrptId"));

		}
	
		
		availables = c2.list();

		Set<Object> availableAsrs = new HashSet<>();
		for (Object o : availables) {
			availableAsrs.add(o);
		}
		// if we want to return the ASRs not found
		if (returnMissing) {
			Set<Object> searchAsrs = new HashSet<>(asrptIds);
			return Sets.difference(searchAsrs, availableAsrs);
		}
		// otherwise return the ASRs that are found
		return availableAsrs;
	}

	@Override
	public FpsAsrptInvstgtn loadInvestigation(String ucmRecordID, Integer asrptId) {
		List<FpsAsrptInvstgtn> invs =  getCurrentSession().createCriteria(FpsAsrptInvstgtn.class)
				.add(Restrictions.eq("extrnlCaseId", ucmRecordID))
				.add(Restrictions.eq("asrptId", asrptId)).list();
		if (invs != null && invs.size() > 0) {
			return invs.get(0);
		}
		return null;
	}
	
	@Override
	public FpsAsrptInvstgtn loadInvestigationByNpi(String ucmRecordID, String npi, boolean isMdcd) {
		return (FpsAsrptInvstgtn) getCurrentSession().createCriteria(FpsAsrptInvstgtn.class)
				.createAlias(isMdcd? "fpsAsrptMdcd":"fpsAsrpt", "asr")
				.add(Restrictions.eq("extrnlCaseId", ucmRecordID))
				.add(Restrictions.eq("asr.subjId", npi)).uniqueResult();
	}

	@Override
	public void deleteAdminAction(int asrptInvstgtnId, String parentRecord) {
		Query q1 = getCurrentSession().createQuery("update FpsAsrptUserAdminvActn set recChgInd = 'R', actvInd = 'N', audtUpdtTs = :newdate, audtUpdtId = 'UCM' where asrptInvstgtnId = :asrptInvstgtnId and ucmEvntId = :parentRecord");
		q1.setParameter("asrptInvstgtnId", asrptInvstgtnId);
		q1.setParameter("parentRecord", parentRecord);
		int result1 = q1.executeUpdate();
		
	}

	@Override
	public FpsUser getSingleOktaUser(String userId) {
		List<FpsUser> users = getOktaUser(userId);
		if (users != null && users.size() > 0) {
			return users.get(0);
		}
		return null;
	}

	@Override
	public FpsAsrptMdcd findMdcdAsrByAsrId(int asrId) {
		return (FpsAsrptMdcd) getCurrentSession().createCriteria(FpsAsrptMdcd.class).add(Restrictions.eq("asrptId", asrId))
				.uniqueResult();
	}

	@Override
	public void insertMdcdAsrHistory(String userId, String superId, Integer invId, Integer asrId, Double riskScore,
			String text, String version, String action) {
		FpsAsrptLogMdcd log = new FpsAsrptLogMdcd();
		log.setActvtyActnInd(action);
		log.setAplctnUserId(userId);
		if (invId != null) {
			log.setAsrptInvstgtnId(invId);
		}
		log.setAsrptLogTs(new Date());
		log.setAudtInsrtId(superId);
		log.setAudtInsrtTs(new Date());
		if (asrId != null) {
			log.setAsrptId(asrId);
		}
		if (riskScore != null) {
			log.setAsrptRiskScre(riskScore);
		}
		log.setAsrptDesc(text);

		getCurrentSession().save(log);
	}

	@Override
	public FpsAsrptUserAdminvActn findAdminAction(int asrptInvstgtnId, String adminActionId) {
		List<FpsAsrptUserAdminvActn> actions =  getCurrentSession().createCriteria(FpsAsrptUserAdminvActn.class)
			.add(Restrictions.eq("fpsAsrptInvstgtn.asrptInvstgtnId", asrptInvstgtnId))
			.add(Restrictions.eq("ucmEvntId", adminActionId))
			.add(Restrictions.eq("recChgInd", "A"))
			.addOrder(Order.desc("audtInsrtTs"))
		.list();
		if (actions != null && actions.size() > 0) {
			return actions.get(0);
		}
		return null;
	}

	@Override
	public FpsAsrptUserActvty findActivity(int asrptInvstgtnId, String activityId) {
		List<FpsAsrptUserActvty> activties =   getCurrentSession().createCriteria(FpsAsrptUserActvty.class)
				.add(Restrictions.eq("fpsAsrptInvstgtn.asrptInvstgtnId", asrptInvstgtnId))
				.add(Restrictions.eq("ucmEvntId", activityId))
				.add(Restrictions.eq("recChgInd", "A"))
				.addOrder(Order.desc("audtInsrtTs"))
					.list();
		if (activties != null && activties.size() > 0) {
			return activties.get(0);
		}
		return null;
	}


}
