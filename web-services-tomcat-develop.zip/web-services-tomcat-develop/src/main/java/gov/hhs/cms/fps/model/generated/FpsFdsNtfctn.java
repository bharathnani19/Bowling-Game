package gov.hhs.cms.fps.model.generated;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="FPS_FDS_NTFCTN")
public class FpsFdsNtfctn implements Serializable{
	
	private Integer ntfctnId;
	private String fromSysId;
	private String toSysId;
	
	private String rtrvUrlTxt;
	private Date audtInsrtTs;
	private String audtInsrtId;
	private String audtUpdtId;
	private Date audtUpdtTs;
	private Integer evntTransId;
	private Integer ntfctnCnt;
	private String ntfctnSucsflInd;
	private FpsFdsEvntTrans fpsFdsEvntTrans;
	


	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="NTFCTN_ID")
	public Integer getNtfctnId() {
		return ntfctnId;
	}
	public void setNtfctnId(Integer ntfctnId) {
		this.ntfctnId = ntfctnId;
	}
	@Column(name="FROM_SYS_ID")
	public String getFromSysId() {
		return fromSysId;
	}
	public void setFromSysId(String fromSysId) {
		this.fromSysId = fromSysId;
	}
	@Column(name="TO_SYS_ID")
	public String getToSysId() {
		return toSysId;
	}
	public void setToSysId(String toSysId) {
		this.toSysId = toSysId;
	}

	@Column(name="RTRV_URL_TXT")
	public String getRtrvUrlTxt() {
		return rtrvUrlTxt;
	}
	public void setRtrvUrlTxt(String rtrvUrlTxt) {
		this.rtrvUrlTxt = rtrvUrlTxt;
	}
	
	@Column(name = "AUDT_INSRT_ID", nullable = false, length = 128)
	public String getAudtInsrtId() {
		return this.audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_INSRT_TS", nullable = false, length = 26)
	public Date getAudtInsrtTs() {
		return this.audtInsrtTs;
	}

	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	@Column(name = "AUDT_UPDT_ID", length = 128)
	public String getAudtUpdtId() {
		return this.audtUpdtId;
	}

	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_UPDT_TS", nullable = false, length = 26)
	public Date getAudtUpdtTs() {
		return audtUpdtTs;
	}
	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
	@Column(name="EVNT_TRANS_ID")

	public Integer getEvntTransId() {
		return evntTransId;
	}
	public void setEvntTransId(Integer evntTransId) {
		this.evntTransId = evntTransId;
	}
	@Column(name="NTFCTN_CNT")

	public Integer getNtfctnCnt() {
		return ntfctnCnt;
	}
	public void setNtfctnCnt(Integer ntfctnCnt) {
		this.ntfctnCnt = ntfctnCnt;
	}
	@Column(name="NTFCTN_SUCSFL_IND")

	public String getNtfctnSucsflInd() {
		return ntfctnSucsflInd;
	}
	public void setNtfctnSucsflInd(String ntfctnSucsflInd) {
		this.ntfctnSucsflInd = ntfctnSucsflInd;
	}
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "EVNT_TRANS_ID", updatable = false, insertable = false)
	public FpsFdsEvntTrans getFpsFdsEvntTrans() {
		return fpsFdsEvntTrans;
	}
	public void setFpsFdsEvntTrans(FpsFdsEvntTrans fpsFdsEvntTrans) {
		this.fpsFdsEvntTrans = fpsFdsEvntTrans;
	}
	
	
	

}
