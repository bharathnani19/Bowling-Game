package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
@Entity
@Table(name="FPS_ASRPT_USER_RULNG_PRRTY")
public class FpsAsrptUserRulngPrrty implements Serializable {
	
	private FpsAsrptUserRulng fpsAsrptUserRulng;
	private Integer asrptUserRulngId;
	private Integer asrptUserRulingPrrtyId;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private String extrnlPrrtyId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_USER_RULNG_ID", updatable = false, insertable = false)
	public FpsAsrptUserRulng getFpsAsrptUserRulng() {
		return fpsAsrptUserRulng;
	}
	public void setFpsAsrptUserRulng(FpsAsrptUserRulng fpsAsrptUserRulng) {
		this.fpsAsrptUserRulng = fpsAsrptUserRulng;
	}
	@Column(name="ASRPT_USER_RULNG_ID")

	public Integer getAsrptUserRulngId() {
		return asrptUserRulngId;
	}
	public void setAsrptUserRulngId(Integer asrptUserRulngId) {
		this.asrptUserRulngId = asrptUserRulngId;
	}
	@Id
//  @GeneratedValue(strategy=GenerationType.IDENTITY)
	@GeneratedValue(generator = "FpsAsrptUserRulngPrrty_SEQ")
	@SequenceGenerator(name = "FpsAsrptUserRulngPrrty_SEQ", sequenceName = "fps2.fps_asrpt_user_rulng_prrty_asrpt_user_rulng_prrty_id_seq", allocationSize = 20)
	@Column(name="ASRPT_USER_RULNG_PRRTY_ID")
	public Integer getAsrptUserRulingPrrtyId() {
		return asrptUserRulingPrrtyId;
	}
	public void setAsrptUserRulingPrrtyId(Integer asrptUserRulingPrrtyId) {
		this.asrptUserRulingPrrtyId = asrptUserRulingPrrtyId;
	}
	@Column(name="AUDT_INSRT_ID")
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	@Column(name="AUDT_INSRT_TS")
	public Date getAudtInsrtTs() {
		return audtInsrtTs;
	}
	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	@Column(name="EXTRNL_PRRTY_ID")
//	@Transient
	public String getExtrnlPrrtyId() {
		return extrnlPrrtyId;
	}
	public void setExtrnlPrrtyId(String extrnlPrrtyId) {
		this.extrnlPrrtyId = extrnlPrrtyId;
	}

}
