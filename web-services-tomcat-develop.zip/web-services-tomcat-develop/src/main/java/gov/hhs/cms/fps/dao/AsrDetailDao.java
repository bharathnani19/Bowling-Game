package gov.hhs.cms.fps.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import gov.hhs.cms.fps.model.AsrDetailAlert;
import gov.hhs.cms.fps.model.AsrDetailProviderSummary;
import gov.hhs.cms.fps.model.AsrDetailTotalCostZone;
import gov.hhs.cms.fps.model.AsrDetailViewRequest;
import gov.hhs.cms.fps.model.AvailableClaims;
import gov.hhs.cms.fps.model.ClaimsSearchParameter;
import gov.hhs.cms.fps.model.ClaimsSolrStream;
import gov.hhs.cms.fps.model.FpsVisualization;
import gov.hhs.cms.fps.model.FpsVisualizationEdge;
import gov.hhs.cms.fps.model.generated.BaseClaim;
import gov.hhs.cms.fps.model.generated.FpsAlert;
import gov.hhs.cms.fps.model.generated.FpsAlertClmAsctn;
import gov.hhs.cms.fps.model.generated.FpsAsrDetailsPageCounts;
import gov.hhs.cms.fps.model.generated.FpsAsrpt;
import gov.hhs.cms.fps.model.generated.FpsAsrptPrrtyScreDtlVw;
import gov.hhs.cms.fps.model.generated.FpsAsrptRiskScreHstryVw;
import gov.hhs.cms.fps.model.generated.FpsClm;
import gov.hhs.cms.fps.model.generated.FpsCstmTbl;
import gov.hhs.cms.fps.model.generated.FpsCstmTblClmnName;
import gov.hhs.cms.fps.model.generated.FpsCstmTblData;
import gov.hhs.cms.fps.model.generated.FpsCstmTblLabelSnpsht;
import gov.hhs.cms.fps.model.generated.FpsEditNumRfrnc;
import gov.hhs.cms.fps.model.generated.FpsModel;
import gov.hhs.cms.fps.model.generated.FpsPrvdrPrflBlngPrvdr;
import gov.hhs.cms.fps.model.generated.FpsPtdAdhocData;
import gov.hhs.cms.fps.model.generated.FpsPtdOpAdvrsEfct;
import gov.hhs.cms.fps.model.generated.FpsPtdOpBzo;
import gov.hhs.cms.fps.model.generated.FpsPtdOpPrscrbr;
import gov.hhs.cms.fps.model.generated.FpsRcncltnClmline;
import gov.hhs.cms.fps.model.generated.FpsRiskScreRptCardDtl;
import gov.hhs.cms.fps.model.generated.FpsRptCardAttrLabel;
import gov.hhs.cms.fps.model.generated.FpsRptCardDtl;
import gov.hhs.cms.fps.model.generated.FpsRptCardDtlMdcd;
import gov.hhs.cms.fps.model.generated.FpsRptCardLabelSnpSht;
import gov.hhs.cms.fps.model.generated.FpsRptCardRskSnaDtl;
import gov.hhs.cms.fps.model.generated.FpsSplmntlVizDtl;
import gov.hhs.cms.fps.model.generated.FpsSplmntlVizLabelSnpsht;
import gov.hhs.cms.fps.model.generated.VwFpsPtdAsrSummary;
import gov.hhs.cms.fps.util.FpsEnums.SolrClaimType;

public interface AsrDetailDao {

	public FpsAsrpt getAsrDetail(AsrDetailViewRequest paramAsrDetailViewRequest);

	public FpsAsrpt getAsrDetail(List<Integer> paramList, String paramString);



	public List<AsrDetailTotalCostZone> loadTotalCostByZone(int asrptId);
	public List<AsrDetailTotalCostZone> loadP1TotalCostByZone(int asrptId);

	public List<AsrDetailAlert> loadAlertsForProvider(String paramString);
	


	public List<AsrDetailProviderSummary> getAsrProviderSummary(int paramInt);

	public Date getLastAlertDateForAsr(int paramInt);

	public List<FpsRptCardDtl> loadReportCardForModelAndNpi(int paramInt, String paramString);
	public List<FpsRptCardDtl> loadReportCardForModelAndNpi(int paramInt, String paramString, Date runDate);

	public List<FpsRptCardRskSnaDtl> loadSnaReportCardForModelAndNpi(int paramInt, String paramString);
	
	public HashMap<String, String> loadReportCardClaimExistInd(int paramInt, String paramString);

	public FpsAlert loadReportCardMostRecentAlert(FpsRptCardDtl paramFpsRptCardDtl);

	public FpsAlert loadReportCardMostRecentAlert(FpsRptCardRskSnaDtl paramFpsRptCardRskSnaDtl);
	public FpsAlert loadReportCardMostRecentAlert(String npi, Integer modelId, Date runDate);

	public List<FpsRptCardDtl> loadReportCardClaims(int paramInt, String paramString);

	public List<FpsRptCardAttrLabel> loadReportCardLabels(FpsRptCardDtl paramFpsRptCardDtl);

	public List<FpsAlertClmAsctn> loadClaimsForModel(int paramInt, String paramString);

	public Date getLastAlertDateForReportCard(int paramInt, String paramString);
	public Date getLastAlertDateForSnaReportCard(int paramInt, String paramString);

	public List<FpsAlertClmAsctn> loadClaimsForReportCard(Short paramShort, int paramInt);

	public List<FpsAlertClmAsctn> loadClaimsForAsr(int paramInt);

	public List<FpsCstmTbl> loadCustomTablesForModel(String paramString1, String paramString2);

	public List<FpsCstmTblClmnName> loadCustomTablesForModelColumns(String paramString1, String paramString2);

	public List<FpsCstmTblData> loadCustomTablesForModelData(String modelBusnsId, String npi, Date model,
			String cstmTblId);

	public Date getLastAlertDateForCustomTable(String paramString1, String paramString2);
	public List<FpsAlertClmAsctn> loadClaimsForAsr(int asrptId, int i);
	

	FpsPtdAdhocData loadAdHocPartDReport(FpsAsrpt asr, VwFpsPtdAsrSummary summ);

	FpsPtdOpAdvrsEfct loadOAEPartDReport(FpsAsrpt asr, VwFpsPtdAsrSummary summ);

	FpsPtdOpBzo loadOBPartDReport(FpsAsrpt asr, VwFpsPtdAsrSummary summ);

	FpsPtdOpPrscrbr loadOPPartDReport(FpsAsrpt asr, VwFpsPtdAsrSummary summ);

	List<FpsClm> loadClaimsForAsr2(Integer asrptId);

	List<FpsClm> loadClaimsForAsr2(Integer asrptId, int rows,SolrClaimType claimsCollection);
	
	public List<FpsClm> loadClaimsForReportCard2(Short attrSqncNum, int alertId);
	public List<FpsClm> loadClaimsForModel2(int modelId, String npi, boolean isPartD, Integer asrptId, Integer alertId) ;

	FpsAlert loadReportCardMostRecentAlert(String subjId, String modelBusnsId);

	int getReportCardHasClaims(Short attrSqncNum, int alertId);
	
	List<FpsClm> loadClaimsForAsr2(Integer asrptId, int rows,  List<String> claimTypes,
			Date fromDate, Date toDate, List<String> hicns, boolean isLatest, String npi,SolrClaimType claimsCollection);

	List<Date> getReportCardDatesForModel(String model, String npi);

//	List<FpsClm> loadClaimsForAsr2(Integer asrptId, int rows, List<String> claimTypes,
//			Date fromDate, Date toDate, List<String> hicns, boolean isLatest, String npi, int startAt, int maxResults,SolrClaimType claimsCollection);

//	int getClaimCount(Integer asrptId, List<String> claimTypes, Date fromDate, Date toDate,
//			List<String> hicns, boolean isLatest, String npi,SolrClaimType claimsCollection);

	public List<Object[]> getHicnsForASR(int asrptId);

	List<Date> getSnaReportCardDatesForModel(String model, String npi);

	List<FpsRptCardRskSnaDtl> loadSnaReportCardForModelAndNpi(int modelId, String npi, Date runDate);

	List<FpsAsrptPrrtyScreDtlVw> getPriorityScoreForASR(int asrptId);

	public int getAsrIdFromReportCard(short attrSqncNum, int alertId);

	public List<FpsAsrptRiskScreHstryVw> loadRiskScoreTrend(int asrptId);


	List<FpsAsrptRiskScreHstryVw> loadRiskScoreTrend(int asrptId, Date startDt, Date endDt);

	Date getLastAlertDateForModelAndNpi(String modelId, String npi);

	List<FpsAlert> loadAlertsForByModelAndNpi(String model, String npi);
	FpsAlert loadAlertByAlertId(Integer alertId);

	public int getLastAlertForAsrAndModel(int asrptId, int modelId);


	public List<FpsEditNumRfrnc> loadEditInfoByModel(String editNm, Boolean showInactives);
	public List<FpsRcncltnClmline> loadClaimsForNpiAndEdit(String npi, String editNm);

	List<AsrDetailTotalCostZone> loadTotalPaymentByZone(int asrptId);

	public Date getLastAlertDateForAsr(String asrNpi);

	public long getClaimCount(ClaimsSearchParameter param);

	public List<? extends BaseClaim> loadClaimsForAsr2(ClaimsSearchParameter param, int pageSize, int index);

//	public List<? extends BaseClaim> getClaimsForAlertCsv(int modelId, String subjId, Integer asrptId, Integer alertId,
//			boolean equals, int pageSize, int index);
	public List<? extends BaseClaim> getClaimsForAlertCsv(Integer alertId, boolean isPartD, boolean isP1, int pageSize, int index);

//	public long getClaimsForAlertCount(int modelId, String subjId, Integer asrptId, boolean isPartD, int alertId);
	public long getClaimsForAlertCount(int alertId, boolean isPartD, boolean isP1);

//	public long getClaimsForReportCardCount(short attrId, Integer alertId, Integer asrptId, boolean isPartD);
	public long getClaimsForReportCardCount(short attrId, Integer alertId, boolean isPartD, boolean isP1);

//	public List<? extends BaseClaim> getClaimsForReportCardCsv(Short attrSqncNum, int alertId, int asrptId, boolean isPartD,
//			int pageSize, int index);

	public List<? extends BaseClaim> getClaimsForReportCardCsv(Short attrSqncNum, int alertId, boolean isPartD, boolean isP1,
			int pageSize, int index);
	AvailableClaims getAvailableClaimsForAsr(Integer asrptId, String npi);

	ClaimsSolrStream loadVizSharedBenes(FpsModel model, String npi, Date modelRunDt, List<String> relatedNPIs);

	FpsVisualization loadVisualization(String subjId, String modelId, Date modelRunDt);

	List<FpsVisualizationEdge> loadVisualizationDates(String subjId, String modelId, int rows);

	List<FpsVisualizationEdge> loadVisualizationDates(String subjId, String modelId);

	FpsVisualization loadVisualization(String subjId, String modelId);

	FpsVisualization loadHhaVisualization(String subjId, Integer ranking);

	FpsVisualization loadDmeVisualization(String subjId, Integer ranking);

	public String checkForVisualization(String subjId);

	public String checkForDmeVisualization(String subjId);

	public List<Integer> loadAvailableRptCardAttrs(int alertId, boolean isPartD, boolean isP1);

	FpsAsrDetailsPageCounts getAllClaimCount(String npi);

	public List<FpsRiskScreRptCardDtl> loadReportCardContribModelAndNpi(String modelBusnsId, String npi, Date runDate);


	public Date loadReportCardContribMostRecentAlert(String npi, String modelBusnsId);

//	public List<RelatedAsr> loadRelatedAsrs(int asrptId);


	public List<FpsPrvdrPrflBlngPrvdr> getBillingSummary(Integer asrptId);
	public List<FpsSplmntlVizDtl> loadSplmntlVizForModelRun(String modelBusnsId, String npi, Date model,
			Integer splmtnVizId);

	List<FpsSplmntlVizDtl> loadSplmntlVizForModelRun(String modelBusnsId, String npi, Date modelRunDt);

	public Date getLastAlertDateForCustomTableViz(String modelBusnsId, String npi, Integer vizId);
	
	List<FpsRptCardLabelSnpSht> loadReportCardLabelsSnapshot(FpsRptCardDtl rptCardDtl);

	public List<FpsCstmTblLabelSnpsht> loadCustomTablesForModelSnapshot(String modelBusnsId, Date runDate);

	FpsSplmntlVizLabelSnpsht loadSplmntlVizTablesForModelSnapshot(String modelBusnsId, Date runDate,
			Integer splmtlVizId);

}
