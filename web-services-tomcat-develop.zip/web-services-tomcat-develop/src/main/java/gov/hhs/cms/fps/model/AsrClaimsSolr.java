package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;

import org.codehaus.jackson.annotate.JsonAutoDetect;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrClaimsSolr implements Serializable, Comparable<AsrClaimsSolr>{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1412523468117408784L;
	@Id
	//@Field("id")
	private String solrId;
	//@Field("clm_cntrctr_num")
	private String macId;
	//@Field("fps_clm_id")
	private Integer claimId;

	//@Field("clm_id")
	private Integer alertClaimId;
	//@Field("clm_src_type")
	private String claimType;
	
	//@Field("cntrctr_cd")
	private String jurisdiction;
	//@Field("clm_sbmtr_id")
	private String submitterId;
	//@Field("asrpt_id")
	private Integer asrptId;
	//@Field("model_id")
	private Integer modelId;
	//@Field("model_busns_id")
	private String modelBusnsId;
	//@Field("alert_id")
	private Integer alertId;
	//@Field("attr_sqnc_num")
	private Integer attrSqncNum;
	//@Field("clm_rndrg_prvdr_npi_num")
	private String performNpi;
	private String performPtan;
	//@Field("prvdr_drvd_npi_name")
	private String providerName;
	//@Field("clm_rndrg_fed_prvdr_spclty_cd")
	private String performSpecialty;
	//@Field("prvdr_mlg_plc_name")
	private String performPrvdrCity;
	//@Field("prvdr_mlg_state_cd")
	private String performPrvdrStateCd;
	//@Field("prvdr_mlg_zip_cd")
	private String providerZip;
	//@Field("clm_atndg_prvdr_npi_num")
	private String attendNpi;
	private String attendPtan;
	//@Field("clm_atndg_prvdr_npi_name")
	private String attendNpiName;
	//@Field("clm_atndg_fed_prvdr_spclty_cd")
	private String attendSpecialty;
	//@Field("bene_hic_num")
	private String beneId = "";
	//@Field("bene_1st_name")
	private String beneFirstName = "";
	//@Field("bene_last_name")
	private String beneLastName = "";
	//@Field("src_zip_plc_name")
	private String beneCity = "";
	//@Field("bene_line_1_adr")
	private String beneAddress = "";
	//@Field("bene_line_2_adr")
	private String beneAddress2 = "";
	//@Field("clm_bene_state_cd")
	private String beneStateCd = "";
	//@Field("src_zip5_cd")
	private String beneZip = "";
	private Integer age;
	//@Field("bene_brth_dt")
	private Date birthDt;
	//@Field("bene_death_dt")
	private Date deathDt;
	//@Field("bene_dual_mdcr_elgbl_stus_ind")
	private String dualInd = "";
	//@Field("clm_cntl_num")
	private String claimNum;
	//@Field("clm_line_num")
	private Integer claimLineNum;
	//@Field("clm_prcdr_1_cd")
	private String procedure;
	private Integer procTimeHrs;
	//@Field("clm_prncpl_dgns_cd")
	private String diagnosis;
	//@Field("hcpcs_1_mdfr_cd")
	private String mod1;
	//@Field("hcpcs_2_mdfr_cd")
	private String mod2;
	//@Field("hcpcs_3_mdfr_cd")
	private String mod3;
	//@Field("hcpcs_4_mdfr_cd")	
	private String mod4;
	//@Field("hcpcs_5_mdfr_cd")
	private String mod5;
	//@Field("clm_line_from_dt")
	private String lineFromDt;
	//@Field("clm_line_thru_dt")
	private String lineToDt;
	//@Field("clm_from_dt")
	private String claimFromDt;
	//@Field("clm_thru_dt")
	private String claimToDt;
	//@Field("clm_rvw_ind")
	private String claimToReview;
	//@Field("clm_line_srvc_unit_qty")
	private Integer unitsService;
	//@Field("clm_line_tot_chrg_amt")
	private Double lineSubmittedAmt;
	//@Field("clm_line_alowd_chrg_amt")
	private Double lineAllowedAmt;
	//@Field("clm_line_prvdr_pmt_amt")
	private Double lineProviderPaidAmt;
	//@Field("clm_sbmt_chrg_amt")
	private Double claimSubmittedAmt;
	//@Field("clm_alowd_chrg_amt")
	private Double claimAllowedAmt;
	//@Field("clm_prvdr_pmt_amt")
	private Double claimProviderPaidAmt;
	//@Field("clm_prvdr_tax_num")
	private String tinEinOnClaim;
	//@Field("clm_bill_type_cd")
	private String billType;
	//@Field("clm_rev_cntr_cd")
	private String revenueCode;
	//@Field("bene_dual_mdcr_elgbl_stus_ind")
	private String crossoverInd;
	private String alertAttributeName;
	//@Field("clm_rfrg_prvdr_npi_num")
	private String referNpi;
	private String referPtan;
	//@Field("clm_rfrg_prvdr_npi_name")
	private String referNpiName;
	//@Field("clm_rndrg_fed_prvdr_spclty_cd")
	private String referNpiSpecialty;
	//@Field("clm_blg_prvdr_npi_num")
	private String billNpi;
	
	private String billPtan;
	//@Field("clm_atndg_prvdr_npi_name")
	private String billPrvdrName;
	//@Field("bene_phne_num")
	private String benePhone;
	//@Field("clm_mbi")
	private String mbi;
	private String modelString;
	//@Field("clm_dgns_1_cd")
	private String diagnosis1;
	//@Field("clm_dgns_2_cd")
	private String diagnosis2;
	//@Field("clm_pos_cd")
	private String pos;
	//@Field("clm_actv_care_from_dt")
	private String admitDt;
	//@Field("clm_dschrg_dt")
	private String dischargeDt;
	//@Field("clm_pmt_amt")
	private Double paymentAmt;
	//@Field("clm_line_alowd_unit_qty")
	private Double unitsAlwd;
	//@Field("dgns_drg_cd")
	private Integer drg;
	//@Field("clm_line_dgns_cd")
	private String lineDiagnosis;
	//@Field("clm_line_hcpcs_cd")
	private String hcpcsCd;
	//@Field("clm_line_rev_unit_num")
	private Integer lineRevUnitNum;
	public int compareTo(AsrClaimsSolr target) {
		return 0;
	}
	public String getClaimType() {
		return this.claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getMacId() {
		return this.macId;
	}

	public void setMacId(String macId) {
		this.macId = macId;
	}

	public String getJurisdiction() {
		return this.jurisdiction;
	}

	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	public String getSubmitterId() {
		return this.submitterId;
	}

	public void setSubmitterId(String submitterId) {
		this.submitterId = submitterId;
	}

	public String getPerformNpi() {
		return this.performNpi;
	}

	public void setPerformNpi(String performNpi) {
		this.performNpi = performNpi;
	}

	public String getPerformPtan() {
		return this.performPtan;
	}

	public void setPerformPtan(String performPtan) {
		this.performPtan = performPtan;
	}

	public String getProviderName() {
		return this.providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getPerformSpecialty() {
		return this.performSpecialty;
	}

	public void setPerformSpecialty(String performSpecialty) {
		this.performSpecialty = performSpecialty;
	}

	public String getPerformPrvdrCity() {
		return this.performPrvdrCity;
	}

	public void setPerformPrvdrCity(String performPrvdrCity) {
		this.performPrvdrCity = performPrvdrCity;
	}

	public String getPerformPrvdrStateCd() {
		return this.performPrvdrStateCd;
	}

	public void setPerformPrvdrStateCd(String performPrvdrStateCd) {
		this.performPrvdrStateCd = performPrvdrStateCd;
	}

	public String getProviderZip() {
		return this.providerZip;
	}

	public void setProviderZip(String providerZip) {
		this.providerZip = providerZip;
	}

	public String getAttendNpi() {
		return this.attendNpi;
	}

	public void setAttendNpi(String attendNpi) {
		this.attendNpi = attendNpi;
	}

	public String getAttendPtan() {
		return this.attendPtan;
	}

	public void setAttendPtan(String attendPtan) {
		this.attendPtan = attendPtan;
	}

	public String getAttendNpiName() {
		return this.attendNpiName;
	}

	public void setAttendNpiName(String attendNpiName) {
		this.attendNpiName = attendNpiName;
	}

	public String getAttendSpecialty() {
		return this.attendSpecialty;
	}

	public void setAttendSpecialty(String attendSpecialty) {
		this.attendSpecialty = attendSpecialty;
	}

	public String getBeneId() {
		return this.beneId;
	}

	public void setBeneId(String beneId) {
		this.beneId = beneId;
	}

	public String getBeneFirstName() {
		return this.beneFirstName;
	}

	public void setBeneFirstName(String beneFirstName) {
		this.beneFirstName = beneFirstName;
	}

	public String getBeneLastName() {
		return this.beneLastName;
	}

	public void setBeneLastName(String beneLastName) {
		this.beneLastName = beneLastName;
	}

	public String getBeneCity() {
		return this.beneCity;
	}

	public void setBeneCity(String beneCity) {
		this.beneCity = beneCity;
	}

	public String getBeneStateCd() {
		return this.beneStateCd;
	}

	public void setBeneStateCd(String beneStateCd) {
		this.beneStateCd = beneStateCd;
	}

	public String getBeneZip() {
		return this.beneZip;
	}

	public void setBeneZip(String beneZip) {
		this.beneZip = beneZip;
	}

	public Integer getAge() {
		return this.age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public Date getBirthDt() {
		return this.birthDt;
	}

	public void setBirthDt(Date birthDt) {
		this.birthDt = birthDt;
	}

	public Date getDeathDt() {
		return this.deathDt;
	}

	public void setDeathDt(Date deathDt) {
		this.deathDt = deathDt;
	}

	public String getDualInd() {
		return this.dualInd;
	}

	public void setDualInd(String dualInd) {
		this.dualInd = dualInd;
	}

	public String getClaimNum() {
		return this.claimNum;
	}

	public void setClaimNum(String claimNum) {
		this.claimNum = claimNum;
	}

	public Integer getClaimLineNum() {
		return this.claimLineNum;
	}

	public void setClaimLineNum(Integer claimLineNum) {
		this.claimLineNum = Integer.valueOf(claimLineNum);
	}

	public String getProcedure() {
		return this.procedure;
	}

	public void setProcedure(String procedure) {
		this.procedure = procedure;
	}

	public Integer getProcTimeHrs() {
		return this.procTimeHrs;
	}

	public void setProcTimeHrs(Integer procTimeHrs) {
		this.procTimeHrs = Integer.valueOf(procTimeHrs);
	}

	public String getDiagnosis() {
		return this.diagnosis;
	}

	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}

	public String getMod1() {
		return this.mod1;
	}

	public void setMod1(String mod1) {
		this.mod1 = mod1;
	}

	public String getMod2() {
		return this.mod2;
	}

	public void setMod2(String mod2) {
		this.mod2 = mod2;
	}

	public String getMod3() {
		return this.mod3;
	}

	public void setMod3(String mod3) {
		this.mod3 = mod3;
	}

	public String getMod4() {
		return this.mod4;
	}

	public void setMod4(String mod4) {
		this.mod4 = mod4;
	}

	public String getMod5() {
		return this.mod5;
	}

	public void setMod5(String mod5) {
		this.mod5 = mod5;
	}

	public String getLineFromDt() {
		return this.lineFromDt;
	}

	public void setLineFromDt(String lineFromDt) {
		this.lineFromDt = lineFromDt;
	}

	public String getLineToDt() {
		return this.lineToDt;
	}

	public void setLineToDt(String lineToDt) {
		this.lineToDt = lineToDt;
	}

	public String getClaimFromDt() {
		return this.claimFromDt;
	}

	public void setClaimFromDt(String claimFromDt) {
		this.claimFromDt = claimFromDt;
	}

	public String getClaimToDt() {
		return this.claimToDt;
	}

	public void setClaimToDt(String claimToDt) {
		this.claimToDt = claimToDt;
	}

	public String getClaimToReview() {
		return this.claimToReview;
	}

	public void setClaimToReview(String claimToReview) {
		this.claimToReview = claimToReview;
	}

	public Integer getUnitsService() {
		return this.unitsService;
	}

	public void setUnitsService(Integer unitsService) {
		this.unitsService = unitsService;
	}

	public Double getLineSubmittedAmt() {
		return this.lineSubmittedAmt;
	}

	public void setLineSubmittedAmt(Double lineSubmittedAmt) {
		this.lineSubmittedAmt = lineSubmittedAmt;
	}

	public Double getLineAllowedAmt() {
		return this.lineAllowedAmt;
	}

	public void setLineAllowedAmt(Double lineAllowedAmt) {
		this.lineAllowedAmt = lineAllowedAmt;
	}

	public Double getLineProviderPaidAmt() {
		return this.lineProviderPaidAmt;
	}

	public void setLineProviderPaidAmt(Double lineProviderPaidAmt) {
		this.lineProviderPaidAmt = lineProviderPaidAmt;
	}

	public Double getClaimSubmittedAmt() {
		return this.claimSubmittedAmt;
	}

	public void setClaimSubmittedAmt(Double claimSubmittedAmt) {
		this.claimSubmittedAmt = claimSubmittedAmt;
	}

	public Double getClaimAllowedAmt() {
		return this.claimAllowedAmt;
	}

	public void setClaimAllowedAmt(Double claimAllowedAmt) {
		this.claimAllowedAmt = claimAllowedAmt;
	}

	public Double getClaimProviderPaidAmt() {
		return this.claimProviderPaidAmt;
	}

	public void setClaimProviderPaidAmt(Double claimProviderPaidAmt) {
		this.claimProviderPaidAmt = claimProviderPaidAmt;
	}

	public String getTinEinOnClaim() {
		return this.tinEinOnClaim;
	}

	public void setTinEinOnClaim(String tinEinOnClaim) {
		this.tinEinOnClaim = tinEinOnClaim;
	}

	public String getBillType() {
		return this.billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	public String getRevenueCode() {
		return this.revenueCode;
	}

	public void setRevenueCode(String revenueCode) {
		this.revenueCode = revenueCode;
	}

	public String getCrossoverInd() {
		return this.crossoverInd;
	}

	public void setCrossoverInd(String crossoverInd) {
		this.crossoverInd = crossoverInd;
	}

	public String getAlertAttributeName() {
		return this.alertAttributeName;
	}

	public void setAlertAttributeName(String alertAttributeName) {
		this.alertAttributeName = alertAttributeName;
	}

	public String getReferNpi() {
		return this.referNpi;
	}

	public void setReferNpi(String referNpi) {
		this.referNpi = referNpi;
	}

	public String getReferPtan() {
		return this.referPtan;
	}

	public void setReferPtan(String referPtan) {
		this.referPtan = referPtan;
	}

	public String getReferNpiName() {
		return this.referNpiName;
	}

	public void setReferNpiName(String referNpiName) {
		this.referNpiName = referNpiName;
	}

	public String getReferNpiSpecialty() {
		return this.referNpiSpecialty;
	}

	public void setReferNpiSpecialty(String referNpiSpecialty) {
		this.referNpiSpecialty = referNpiSpecialty;
	}

	public String getBillNpi() {
		return this.billNpi;
	}

	public void setBillNpi(String billNpi) {
		this.billNpi = billNpi;
	}

	public String getBillPtan() {
		return this.billPtan;
	}

	public void setBillPtan(String billPtan) {
		this.billPtan = billPtan;
	}

	public String getBillPrvdrName() {
		return this.billPrvdrName;
	}

	public void setBillPrvdrName(String billPrvdrName) {
		this.billPrvdrName = billPrvdrName;
	}

	public String getBeneAddress() {
		return this.beneAddress;
	}

	public void setBeneAddress(String beneAddress) {
		this.beneAddress = beneAddress;
	}

	

	public String getBenePhone() {
		return this.benePhone;
	}

	public void setBenePhone(String benePhone) {
		this.benePhone = benePhone;
	}

	public String getMbi() {
		return mbi;
	}

	public void setMbi(String mbi) {
		this.mbi = mbi;
	}

	public void setModelString(String modelString) {
		this.modelString = modelString;

	}

	public String getModelString() {
		return modelString;
	}

	public Integer getClaimId() {
		return claimId;
	}

	public void setClaimId(Integer claimId) {
		this.claimId = claimId;
	}

	public Integer getAlertClaimId() {
		return alertClaimId;
	}

	public void setAlertClaimId(Integer alertClaimId) {
		this.alertClaimId = alertClaimId;
	}

	public String getDiagnosis1() {
		return diagnosis1;
	}

	public void setDiagnosis1(String diagnosis1) {
		this.diagnosis1 = diagnosis1;
	}

	public String getDiagnosis2() {
		return diagnosis2;
	}

	public void setDiagnosis2(String diagnosis2) {
		this.diagnosis2 = diagnosis2;
	}

	public String getPos() {
		return pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getAdmitDt() {
		return admitDt;
	}

	public void setAdmitDt(String admitDt) {
		this.admitDt = admitDt;
	}

	public String getDischargeDt() {
		return dischargeDt;
	}

	public void setDischargeDt(String dischargeDt) {
		this.dischargeDt = dischargeDt;
	}

	public Double getPaymentAmt() {
		return paymentAmt;
	}

	public void setPaymentAmt(Double paymentAmt) {
		this.paymentAmt = paymentAmt;
	}

	public Double getUnitsAlwd() {
		return unitsAlwd;
	}

	public void setUnitsAlwd(Double unitsAlwd) {
		this.unitsAlwd = unitsAlwd;
	}

	public Integer getDrg() {
		return drg;
	}

	public void setDrg(Integer drg) {
		this.drg = drg;
	}

	public String getLineDiagnosis() {
		return lineDiagnosis;
	}

	public void setLineDiagnosis(String lineDiagnosis) {
		this.lineDiagnosis = lineDiagnosis;
	}

	public String getHcpcsCd() {
		return hcpcsCd;
	}

	public void setHcpcsCd(String hcpcsCd) {
		this.hcpcsCd = hcpcsCd;
	}

	@Override
	public String toString() {
		return "AsrDetailClaimLineItem [claimId=" + claimId + ", alertClaimId=" + alertClaimId + ", claimType="
				+ claimType + ", macId=" + macId + ", jurisdiction=" + jurisdiction + ", submitterId=" + submitterId
				+ ", asrptId=" + asrptId + ", modelId=" + modelId + ", modelBusnsId=" + modelBusnsId + ", alertId="
				+ alertId + ", attrSqncNum=" + attrSqncNum + ", performNpi=" + performNpi + ", performPtan="
				+ performPtan + ", providerName=" + providerName + ", performSpecialty=" + performSpecialty
				+ ", performPrvdrCity=" + performPrvdrCity + ", performPrvdrStateCd=" + performPrvdrStateCd
				+ ", providerZip=" + providerZip + ", attendNpi=" + attendNpi + ", attendPtan=" + attendPtan
				+ ", attendNpiName=" + attendNpiName + ", attendSpecialty=" + attendSpecialty + ", beneId=" + beneId
				+ ", beneFirstName=" + beneFirstName + ", beneLastName=" + beneLastName + ", beneCity=" + beneCity
				+ ", beneAddress=" + beneAddress + ", beneStateCd=" + beneStateCd + ", beneZip=" + beneZip + ", age="
				+ age + ", birthDt=" + birthDt + ", deathDt=" + deathDt + ", dualInd=" + dualInd + ", claimNum="
				+ claimNum + ", claimLineNum=" + claimLineNum + ", procedure=" + procedure + ", procTimeHrs="
				+ procTimeHrs + ", diagnosis=" + diagnosis + ", mod1=" + mod1 + ", mod2=" + mod2 + ", mod3=" + mod3
				+ ", mod4=" + mod4 + ", mod5=" + mod5 + ", lineFromDt=" + lineFromDt + ", lineToDt=" + lineToDt
				+ ", claimFromDt=" + claimFromDt + ", claimToDt=" + claimToDt + ", claimToReview=" + claimToReview
				+ ", unitsService=" + unitsService + ", lineSubmittedAmt=" + lineSubmittedAmt + ", lineAllowedAmt="
				+ lineAllowedAmt + ", lineProviderPaidAmt=" + lineProviderPaidAmt + ", claimSubmittedAmt="
				+ claimSubmittedAmt + ", claimAllowedAmt=" + claimAllowedAmt + ", claimProviderPaidAmt="
				+ claimProviderPaidAmt + ", tinEinOnClaim=" + tinEinOnClaim + ", billType=" + billType
				+ ", revenueCode=" + revenueCode + ", crossoverInd=" + crossoverInd + ", alertAttributeName="
				+ alertAttributeName + ", referNpi=" + referNpi + ", referPtan=" + referPtan + ", referNpiName="
				+ referNpiName + ", referNpiSpecialty=" + referNpiSpecialty + ", billNpi=" + billNpi + ", billPtan="
				+ billPtan + ", billPrvdrName=" + billPrvdrName + ", benePhone=" + benePhone + ", mbi=" + mbi
				+ ", modelString=" + modelString + ", diagnosis1=" + diagnosis1 + ", diagnosis2=" + diagnosis2
				+ ", pos=" + pos + ", admitDt=" + admitDt + ", dischargeDt=" + dischargeDt + ", paymentAmt="
				+ paymentAmt + ", unitsAlwd=" + unitsAlwd + ", drg=" + drg + ", lineDiagnosis=" + lineDiagnosis
				+ ", hcpcsCd=" + hcpcsCd + "]";
	}

	public String getSolrId() {
		return solrId;
	}

	public void setSolrId(String solrId) {
		this.solrId = solrId;
	}

	public Integer getAsrptId() {
		return asrptId;
	}

	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}

	public Integer getModelId() {
		return modelId;
	}

	public void setModelId(Integer modelId) {
		this.modelId = modelId;
	}

	public String getModelBusnsId() {
		return modelBusnsId;
	}

	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}

	public Integer getAlertId() {
		return alertId;
	}

	public void setAlertId(Integer alertId) {
		this.alertId = alertId;
	}

	public Integer getAttrSqncNum() {
		return attrSqncNum;
	}

	public void setAttrSqncNum(Integer attrSqncNum) {
		this.attrSqncNum = attrSqncNum;
	}

	public String getBeneAddress2() {
		return beneAddress2;
	}

	public void setBeneAddress2(String beneAddress2) {
		this.beneAddress2 = beneAddress2;
	}

	public Integer getLineRevUnitNum() {
		return lineRevUnitNum;
	}

	public void setLineRevUnitNum(Integer lineRevUnitNum) {
		this.lineRevUnitNum = lineRevUnitNum;
	}

}
