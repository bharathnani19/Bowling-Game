package gov.hhs.cms.fps.model;

import gov.hhs.cms.fps.model.hub.EventNotification;

public class FpsEventNotification extends EventNotification {
	private Integer eventId;

	public Integer getEventId() {
		return eventId;
	}

	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

}
