package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.codehaus.jackson.annotate.JsonAutoDetect;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.hhs.cms.fps.model.generated.FpsTrnPrbeEdu;
import gov.hhs.cms.fps.util.NAStringSerializer;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailProvider implements Serializable {
	private static final long serialVersionUID = -9160637224324275483L;
	private String npi;
	private FpsGeoProvider address;
	private String providerName;
	private String riskScoreNum;
	private String priorityScoreNum;
	private String prevPriorityScoreNum;
	private String priorityScoreDelta;
	private String totalCost;
	private String totalPmt;
	private int uniqueAlertsCnt;
	private List<AsrSummaryAlert> alerts;
	private String createdDt;
	private String updateDt;
	private String assignedTo;
	private String jurisdiction;
	private String prvdrStateCd;
	private int specialtiesCnt;
	private List<AsrSummarySpecialty> specialties;
	private int benesCnt;
	private List<FpsCommonBeneficiary> benes;
	private int proceduresCnt;
	private List<AsrSummaryProcedure> procedures;
	private int asrProviderCnt;
	private List<AsrDetailProviderSummary> asrProviders;
	private List<AsrDetailProviderSummary> perfProviders;
	private List<AsrDetailProviderSummary> referProviders;
	private List<AsrDetailProviderSummary> attendProviders;
	private List<AsrDetailProviderSummary> billingProviders;
	private int submitterIdCnt;
	private List<AsrProviderSubmitterId> submitterIds;
	private String subjectStateCd;
	private List<AsrProviderRole> subjectRoleCd = new ArrayList<AsrProviderRole>();
	private List<String> roles;
	private int fidNumberCnt;
	private List<AsrFidNumber> fidNumbers;
	private List<UcmCaseData> ucmCaseData;
	private int ucmCaseDataCnt;
	private int biu4WeekCnt;
	private int biu1YearCnt;
	private String inWorkloadDt;
	private String inWorkload;
	private List<AsrSummaryBarrier> barrierToAction;
	private AsrSysTag sysTags = new AsrSysTag();
	private long crossoverLinesCnt;
	private List<FpsCommonPtan> ptans;
	private List<AsrPriorityScore> priorityCriteria;
	private String mac;
	private String riskScore90;
	private String riskScore180;
	private String riskScore365;
	private List<FpsGenericKeyValue> dualBenes;
	private List<FpsGenericKeyValue> topProcCds;
	private List<FpsGenericKeyValue> topHcpcsCds;
	private String zrType;
	private String revocation = "N";
	private String revocationDate;
	private String revocationDesc;
	private String medicaid= "N";
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String ucmAsrId = "N/A";
	private List<AsrGenericCodeDesc> enrollmentIds;
	private String enrollmentId;
	private MedicaidInfo medicaidInfo;
	private String showMacEduReport = "N";
	private String showUpicEduReport = "N";
	private String hasHhaNv = "N";
	private String hasDmeNv = "N";
	private String actionability = "N/A";
	private String timeliness = "N/A";
	private String hasAps = "N";
	private String showChowReport = "N";
	private String hasPartD = "N";
	private String hasRrb = "N";
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String postEdInd = "N";
	private Set<FpsTrnPrbeEdu> tpes;

	private List<ApsRecord> apsRecs = new ArrayList<ApsRecord>();
	private Integer relatedAsrCnt;
	private String nonAlertedPrvdrInd; 
	private String uniqueAlertsNA = "N";
	private String specialtiesNA = "N";
	private String ptansNA = "N";
	private String crossoverNA = "N";
	private String rolesNA = "N";
	private List<AsrContributionScores> contribScores;
	private String riskScoreMethod;
	private List<MdcdEnrollmentIds> mdcdEnrollmentIds;
	private String minRiskScoreInd;
	private String minRiskScoreModelTxt;
	private String acoInd;
	
	// Phase 1
	private String p1TotalCost;
	private String p1Jurisdiction;
	private String p1RiskScore;


	public String getNpi() {
		return this.npi;
	}

	public void setNpi(String npi) {
		this.npi = npi;
	}

	public String getProviderName() {
		return this.providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getRiskScoreNum() {
		return this.riskScoreNum;
	}

	public void setRiskScoreNum(String riskScoreNum) {
		this.riskScoreNum = riskScoreNum;
	}

	public String getTotalCost() {
		return this.totalCost;
	}

	public void setTotalCost(String totalCost) {
		this.totalCost = totalCost;
	}

	public int getUniqueAlertsCnt() {
		return this.uniqueAlertsCnt;
	}

	public void setUniqueAlertsCnt(int uniqueAlertsCnt) {
		this.uniqueAlertsCnt = uniqueAlertsCnt;
	}

	public String getCreatedDt() {
		return this.createdDt;
	}

	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}

	public String getUpdateDt() {
		return this.updateDt;
	}

	public void setUpdateDt(String updateDt) {
		this.updateDt = updateDt;
	}

	public String getAssignedTo() {
		return this.assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public AsrSysTag getSysTags() {
		return this.sysTags;
	}

	public void setSysTags(AsrSysTag sysTags) {
		this.sysTags = sysTags;
	}

	public int getSpecialtiesCnt() {
		return this.specialtiesCnt;
	}

	public void setSpecialtiesCnt(int specialtiesCnt) {
		this.specialtiesCnt = specialtiesCnt;
	}

	public List<AsrSummarySpecialty> getSpecialties() {
		return this.specialties;
	}

	public void setSpecialties(List<AsrSummarySpecialty> specialties) {
		this.specialties = specialties;
	}

	public int getBenesCnt() {
		return this.benesCnt;
	}

	public void setBenesCnt(int benesCnt) {
		this.benesCnt = benesCnt;
	}

	public List<FpsCommonBeneficiary> getBenes() {
		return this.benes;
	}

	public void setBenes(List<FpsCommonBeneficiary> benes) {
		this.benes = benes;
	}

	public int getProceduresCnt() {
		return this.proceduresCnt;
	}

	public void setProceduresCnt(int proceduresCnt) {
		this.proceduresCnt = proceduresCnt;
	}

	public List<AsrSummaryProcedure> getProcedures() {
		return this.procedures;
	}

	public void setProcedures(List<AsrSummaryProcedure> procedures) {
		this.procedures = procedures;
	}

	public int getAsrProviderCnt() {
		return this.asrProviderCnt;
	}

	public void setAsrProviderCnt(int asrProviderCnt) {
		this.asrProviderCnt = asrProviderCnt;
	}

	public List<AsrDetailProviderSummary> getAsrProviders() {
		return this.asrProviders;
	}

	public void setAsrProviders(List<AsrDetailProviderSummary> asrProviders) {
		this.asrProviders = asrProviders;
	}

	public int getSubmitterIdCnt() {
		return this.submitterIdCnt;
	}

	public void setSubmitterIdCnt(int submitterIdCnt) {
		this.submitterIdCnt = submitterIdCnt;
	}

	public List<AsrProviderSubmitterId> getSubmitterIds() {
		return this.submitterIds;
	}

	public void setSubmitterIds(List<AsrProviderSubmitterId> submitterIds) {
		this.submitterIds = submitterIds;
	}

	public String getSubjectStateCd() {
		return this.subjectStateCd;
	}

	public void setSubjectStateCd(String subjectStateCd) {
		this.subjectStateCd = subjectStateCd;
	}

	public List<AsrProviderRole> getSubjectRoleCd() {
		return this.subjectRoleCd;
	}

	public void setSubjectRoleCd(List<AsrProviderRole> subjectRoleCd) {
		this.subjectRoleCd = subjectRoleCd;
	}

	public List<String> getRoles() {
		return this.roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public int getFidNumberCnt() {
		return this.fidNumberCnt;
	}

	public void setFidNumberCnt(int fidNumberCnt) {
		this.fidNumberCnt = fidNumberCnt;
	}

	public List<AsrFidNumber> getFidNumbers() {
		return this.fidNumbers;
	}

	public void setFidNumbers(List<AsrFidNumber> fidNumbers) {
		this.fidNumbers = fidNumbers;
	}

	public List<UcmCaseData> getUcmCaseData() {
		return this.ucmCaseData;
	}

	public void setUcmCaseData(List<UcmCaseData> ucmCaseData) {
		this.ucmCaseData = ucmCaseData;
	}

	public int getBiu4WeekCnt() {
		return this.biu4WeekCnt;
	}

	public void setBiu4WeekCnt(int biu4WeekCnt) {
		this.biu4WeekCnt = biu4WeekCnt;
	}

	public int getBiu1YearCnt() {
		return this.biu1YearCnt;
	}

	public void setBiu1YearCnt(int biu1YearCnt) {
		this.biu1YearCnt = biu1YearCnt;
	}

	public String getInWorkloadDt() {
		return this.inWorkloadDt;
	}

	public void setInWorkloadDt(String inWorkloadDt) {
		this.inWorkloadDt = inWorkloadDt;
	}

	public List<AsrSummaryBarrier> getBarrierToAction() {
		return this.barrierToAction;
	}

	public void setBarrierToAction(List<AsrSummaryBarrier> barrierToAction) {
		this.barrierToAction = barrierToAction;
	}

	public int getUcmCaseDataCnt() {
		return this.ucmCaseDataCnt;
	}

	public void setUcmCaseDataCnt(int ucmCaseDataCnt) {
		this.ucmCaseDataCnt = ucmCaseDataCnt;
	}

	public String getInWorkload() {
		return this.inWorkload;
	}

	public void setInWorkload(String inWorkload) {
		this.inWorkload = inWorkload;
	}

	public String getJurisdiction() {
		return this.jurisdiction;
	}

	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	public List<AsrDetailProviderSummary> getPerfProviders() {
		return this.perfProviders;
	}

	public void setPerfProviders(List<AsrDetailProviderSummary> perfProviders) {
		this.perfProviders = perfProviders;
	}

	public List<AsrDetailProviderSummary> getReferProviders() {
		return this.referProviders;
	}

	public void setReferProviders(List<AsrDetailProviderSummary> referProviders) {
		this.referProviders = referProviders;
	}

	public List<AsrDetailProviderSummary> getAttendProviders() {
		return this.attendProviders;
	}

	public void setAttendProviders(List<AsrDetailProviderSummary> attendProviders) {
		this.attendProviders = attendProviders;
	}

	public List<AsrDetailProviderSummary> getBillingProviders() {
		return this.billingProviders;
	}

	public void setBillingProviders(List<AsrDetailProviderSummary> billingProviders) {
		this.billingProviders = billingProviders;
	}

	public List<AsrSummaryAlert> getAlerts() {
		return this.alerts;
	}

	public void setAlerts(List<AsrSummaryAlert> alerts) {
		this.alerts = alerts;
	}

	public int hashCode() {
		int result = 1;
		result = 31 * result + (this.npi == null ? 0 : this.npi.hashCode());
		result = 31 * result + (this.providerName == null ? 0 : this.providerName.hashCode());
		return result;
	}

	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		AsrDetailProvider other = (AsrDetailProvider) obj;
		if (this.npi == null) {
			if (other.npi != null) {
				return false;
			}
		} else if (!this.npi.equals(other.npi)) {
			return false;
		}
		if (this.providerName == null) {
			if (other.providerName != null) {
				return false;
			}
		} else if (!this.providerName.equals(other.providerName)) {
			return false;
		}
		return true;
	}

	public FpsGeoProvider getAddress() {
		return this.address;
	}

	public void setAddress(FpsGeoProvider address) {
		this.address = address;
	}

	public long getCrossoverLinesCnt() {
		return this.crossoverLinesCnt;
	}

	public void setCrossoverLinesCnt(long crossoverLinesCnt) {
		this.crossoverLinesCnt = crossoverLinesCnt;
	}

	public String getPrvdrStateCd() {
		return this.prvdrStateCd;
	}

	public void setPrvdrStateCd(String prvdrStateCd) {
		this.prvdrStateCd = prvdrStateCd;
	}

	public List<FpsCommonPtan> getPtans() {
		return ptans;
	}

	public void setPtans(List<FpsCommonPtan> ptans) {
		this.ptans = ptans;
	}

	public String getPriorityScoreNum() {
		return priorityScoreNum;
	}

	public void setPriorityScoreNum(String priorityScoreNum) {
		this.priorityScoreNum = priorityScoreNum;
	}

	public List<AsrPriorityScore> getPriorityCriteria() {
		return priorityCriteria;
	}

	public void setPriorityCriteria(List<AsrPriorityScore> priorityCriteria) {
		this.priorityCriteria = priorityCriteria;
	}

	public String getPrevPriorityScoreNum() {
		return prevPriorityScoreNum;
	}

	public void setPrevPriorityScoreNum(String prevPriorityScoreNum) {
		this.prevPriorityScoreNum = prevPriorityScoreNum;
	}

	public String getPriorityScoreDelta() {
		return priorityScoreDelta;
	}

	public void setPriorityScoreDelta(String priorityScoreDelta) {
		this.priorityScoreDelta = priorityScoreDelta;
	}

	public void setMac(String mac) {
		this.mac = mac;
		
	}
	public String getMac() {
		return mac;
		
	}

	public String getRiskScore90() {
		return riskScore90;
	}

	public void setRiskScore90(String riskScore90) {
		this.riskScore90 = riskScore90;
	}

	public String getRiskScore180() {
		return riskScore180;
	}

	public void setRiskScore180(String riskScore180) {
		this.riskScore180 = riskScore180;
	}

	public String getRiskScore365() {
		return riskScore365;
	}

	public void setRiskScore365(String riskScore365) {
		this.riskScore365 = riskScore365;
	}

	public List<FpsGenericKeyValue> getDualBenes() {
		return dualBenes;
	}

	public void setDualBenes(List<FpsGenericKeyValue> dualBenes) {
		this.dualBenes = dualBenes;
	}

	public List<FpsGenericKeyValue> getTopProcCds() {
		return topProcCds;
	}

	public void setTopProcCds(List<FpsGenericKeyValue> topProcCds) {
		this.topProcCds = topProcCds;
	}

	public String getZrType() {
		return zrType;
	}

	public void setZrType(String zrType) {
		this.zrType = zrType;
	}

	public String getRevocation() {
		return revocation;
	}

	public void setRevocation(String revocation) {
		this.revocation = revocation;
	}

	public String getMedicaid() {
		return medicaid;
	}

	public void setMedicaid(String medicaid) {
		this.medicaid = medicaid;
	}

	public String getUcmAsrId() {
		return ucmAsrId;
	}

	public void setUcmAsrId(String ucmAsrId) {
		this.ucmAsrId = ucmAsrId;
	}

	public MedicaidInfo getMedicaidInfo() {
		return medicaidInfo;
	}

	public void setMedicaidInfo(MedicaidInfo medicaidInfo) {
		this.medicaidInfo = medicaidInfo;
	}

	public List<FpsGenericKeyValue> getTopHcpcsCds() {
		return topHcpcsCds;
	}

	public void setTopHcpcsCds(List<FpsGenericKeyValue> topHcpcsCds) {
		this.topHcpcsCds = topHcpcsCds;
	}

	public String getRevocationDate() {
		return revocationDate;
	}

	public void setRevocationDate(String revocationDate) {
		this.revocationDate = revocationDate;
	}

	public String getRevocationDesc() {
		return revocationDesc;
	}

	public void setRevocationDesc(String revocationDesc) {
		this.revocationDesc = revocationDesc;
	}

	public List<AsrGenericCodeDesc> getEnrollmentIds() {
		return enrollmentIds;
	}

	public void setEnrollmentIds(List<AsrGenericCodeDesc> enrollmentIds) {
		this.enrollmentIds = enrollmentIds;
	}


	public String getEnrollmentId() {
		return enrollmentId;
	}

	public void setEnrollmentId(String enrollmentId) {
		this.enrollmentId = enrollmentId;
	}

	public String getShowMacEduReport() {
		return showMacEduReport;
	}

	public void setShowMacEduReport(String showMacEduReport) {
		this.showMacEduReport = showMacEduReport;
	}

	public String getShowUpicEduReport() {
		return showUpicEduReport;
	}

	public void setShowUpicEduReport(String showUpicEduReport) {
		this.showUpicEduReport = showUpicEduReport;
	}

	public String getHasHhaNv() {
		return hasHhaNv;
	}

	public void setHasHhaNv(String hasHhaNv) {
		this.hasHhaNv = hasHhaNv;
	}

	public String getActionability() {
		return actionability;
	}

	public void setActionability(String actionability) {
		this.actionability = actionability;
	}

	public String getTimeliness() {
		return timeliness;
	}

	public void setTimeliness(String timeliness) {
		this.timeliness = timeliness;
	}

	public String getHasAps() {
		return hasAps;
	}

	public void setHasAps(String hasAps) {
		this.hasAps = hasAps;
	}

	public List<ApsRecord> getApsRecs() {
		return apsRecs;
	}

	public void setApsRecs(List<ApsRecord> apsRecs) {
		this.apsRecs = apsRecs;
	}

	public String getShowChowReport() {
		return showChowReport;
	}

	public void setShowChowReport(String showChowReport) {
		this.showChowReport = showChowReport;
	}

	public String getHasPartD() {
		return hasPartD;
	}

	public void setHasPartD(String hasPartD) {
		this.hasPartD = hasPartD;
	}

	public String getHasRrb() {
		return hasRrb;
	}

	public void setHasRrb(String hasRrb) {
		this.hasRrb = hasRrb;
	}

	public String getPostEdInd() {
		return postEdInd;
	}

	public void setPostEdInd(String postEdInd) {
		this.postEdInd = postEdInd;
	}

	public Set<FpsTrnPrbeEdu> getTpes() {
		return tpes;
	}

	public void setTpes(Set<FpsTrnPrbeEdu> tpes) {
		this.tpes = tpes;
	}

	public String getTotalPmt() {
		return totalPmt;
	}

	public void setTotalPmt(String totalPmt) {
		this.totalPmt = totalPmt;
	}

	public Integer getRelatedAsrCnt() {
		return relatedAsrCnt;
	}

	public void setRelatedAsrCnt(Integer relatedAsrCnt) {
		this.relatedAsrCnt = relatedAsrCnt;
	}

	public String getHasDmeNv() {
		return hasDmeNv;
	}

	public void setHasDmeNv(String hasDmeNv) {
		this.hasDmeNv = hasDmeNv;
	}

	public String getNonAlertedPrvdrInd() {
		return nonAlertedPrvdrInd;
	}

	public void setNonAlertedPrvdrInd(String nonAlertedPrvdrInd) {
		this.nonAlertedPrvdrInd = nonAlertedPrvdrInd;
	}

	public String getUniqueAlertsNA() {
		return uniqueAlertsNA;
	}

	public void setUniqueAlertsNA(String uniqueAlertsNA) {
		this.uniqueAlertsNA = uniqueAlertsNA;
	}

	public String getSpecialtiesNA() {
		return specialtiesNA;
	}

	public void setSpecialtiesNA(String specialtiesNA) {
		this.specialtiesNA = specialtiesNA;
	}

	public String getPtansNA() {
		return ptansNA;
	}

	public void setPtansNA(String ptansNA) {
		this.ptansNA = ptansNA;
	}

	public String getCrossoverNA() {
		return crossoverNA;
	}

	public void setCrossoverNA(String crossoverNA) {
		this.crossoverNA = crossoverNA;
	}

	public String getRolesNA() {
		return rolesNA;
	}

	public void setRolesNA(String rolesNA) {
		this.rolesNA = rolesNA;
	}

	public List<AsrContributionScores> getContribScores() {
		return contribScores;
	}

	public void setContribScores(List<AsrContributionScores> contribScores) {
		this.contribScores = contribScores;
	}

	public String getRiskScoreMethod() {
		return riskScoreMethod;
	}

	public void setRiskScoreMethod(String riskScoreMethod) {
		this.riskScoreMethod = riskScoreMethod;
	}

	public List<MdcdEnrollmentIds> getMdcdEnrollmentIds() {
		return mdcdEnrollmentIds;
	}

	public void setMdcdEnrollmentIds(List<MdcdEnrollmentIds> mdcdEnrollmentIds) {
		this.mdcdEnrollmentIds = mdcdEnrollmentIds;
	}

	public String getMinRiskScoreInd() {
		return minRiskScoreInd;
	}

	public void setMinRiskScoreInd(String minRiskScoreInd) {
		this.minRiskScoreInd = minRiskScoreInd;
	}

	public String getMinRiskScoreModelTxt() {
		return minRiskScoreModelTxt;
	}

	public void setMinRiskScoreModelTxt(String minRiskScoreModelTxt) {
		this.minRiskScoreModelTxt = minRiskScoreModelTxt;
	}

	public String getAcoInd() {
		return acoInd;
	}

	public void setAcoInd(String acoInd) {
		this.acoInd = acoInd;
	}

	public String getP1TotalCost() {
		return p1TotalCost;
	}

	public void setP1TotalCost(String p1TotalCost) {
		this.p1TotalCost = p1TotalCost;
	}

	public String getP1Jurisdiction() {
		return p1Jurisdiction;
	}

	public void setP1Jurisdiction(String p1Jurisdiction) {
		this.p1Jurisdiction = p1Jurisdiction;
	}

	public String getP1RiskScore() {
		return p1RiskScore;
	}

	public void setP1RiskScore(String p1RiskScore) {
		this.p1RiskScore = p1RiskScore;
	}





}
