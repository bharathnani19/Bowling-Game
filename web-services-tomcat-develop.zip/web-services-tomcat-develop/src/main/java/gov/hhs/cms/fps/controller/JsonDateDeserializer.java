package gov.hhs.cms.fps.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.Locale;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;
import org.springframework.stereotype.Component;

@Component
public class JsonDateDeserializer extends JsonDeserializer<OffsetDateTime> {
	// ISO 8601
	private static final DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss.SS", Locale.US);
	private static final DateTimeFormatter dateFormatOffset = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSX", Locale.US);

	@Override
	public OffsetDateTime deserialize(JsonParser jsonParser, DeserializationContext deserializationContext)
			throws IOException, JsonProcessingException {
		String withoutColon = jsonParser.getText().replace("+00:00", "+0000");
		
		try {
			OffsetDateTime off = OffsetDateTime.parse(withoutColon, dateFormat);
			return off;
		} catch (DateTimeParseException e) {
			try {
				OffsetDateTime  off = OffsetDateTime.parse(withoutColon, dateFormatOffset);
				return off;
			} catch (DateTimeParseException e2) {
				return null;
			}
		}
	}

	public static void main(String[] args) {
		String input = "2019-12-12 06:03:14.000+0000";

		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSX");
			formatter.withZone(ZoneId.of("UTC"));
			OffsetDateTime off = OffsetDateTime.parse("2019-12-12 06:03:14.000+0000", formatter.withZone(ZoneId.of("UTC")));
			LocalDateTime off3 = LocalDateTime.parse("2019-12-12 06:03:14.000+0000", formatter);
			ZonedDateTime off4 = ZonedDateTime.parse("2019-12-12 06:03:14.000+0000", formatter);
			LocalDate date = LocalDate.parse(input, formatter);
			System.out.println(off.format(formatter));
			System.out.println(Date.from(off.toInstant()));
			OffsetDateTime off2 = OffsetDateTime.ofInstant(off.toInstant(),  ZoneOffset.UTC);
			Date d = Date.from(off2.toInstant());
			d.toInstant().atOffset(ZoneOffset.UTC);
			System.out.println(Date.from(off3.atOffset(ZoneOffset.of("+00:00")).toZonedDateTime().toInstant()));
			System.out.println(Date.from(off2.toInstant()));
			System.out.println(Date.from(off.atZoneSameInstant(ZoneId.of("UTC")).toInstant()));
			System.out.println(Date.from(off4.withZoneSameInstant(ZoneId.of("UTC")).toInstant()));
		} catch (DateTimeParseException exc) {
			System.out.printf("%s is not parsable!%n", input);
			throw exc; // Rethrow the exception.
		}
	}
}
