package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="fps_cstm_tbl_asr_link_mqt")
public class FpsCstmTblAsrLinkMqt implements Serializable {
	private Integer fpsCstmTblDtlId;
	private String modelBusnsId;
	private Date modelRunDt;
	private String npiNum;
	private String cstmTblId;
	private String cstmTblClmnNum;
	private Integer asrptId;
	
	@Id
	@Column(name="FPS_CSTM_TBL_DTL_ID")
	public Integer getFpsCstmTblDtlId() {
		return fpsCstmTblDtlId;
	}
	public void setFpsCstmTblDtlId(Integer fpsCstmTblDtlId) {
		this.fpsCstmTblDtlId = fpsCstmTblDtlId;
	}
	@Id
	@Column(name="MODEL_BUSNS_ID")
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	@Id
	@Column(name="MODEL_RUN_DT")
	public Date getModelRunDt() {
		return modelRunDt;
	}
	public void setModelRunDt(Date modelRunDt) {
		this.modelRunDt = modelRunDt;
	}
	@Id
	@Column(name="NPI_NUM")
	public String getNpiNum() {
		return npiNum;
	}
	public void setNpiNum(String npiNum) {
		this.npiNum = npiNum;
	}
	@Id
	@Column(name="CSTM_TBL_ID")
	public String getCstmTblId() {
		return cstmTblId;
	}
	public void setCstmTblId(String cstmTblId) {
		this.cstmTblId = cstmTblId;
	}
	@Id
	@Column(name="CSTM_TBL_CLMN_NUM")
	public String getCstmTblClmnNum() {
		return cstmTblClmnNum;
	}
	public void setCstmTblClmnNum(String cstmTblClmnNum) {
		this.cstmTblClmnNum = cstmTblClmnNum;
	}
	@Column(name="ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}

}
