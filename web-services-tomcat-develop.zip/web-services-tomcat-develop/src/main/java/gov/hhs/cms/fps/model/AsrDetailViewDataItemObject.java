/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.IOException;
import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import org.codehaus.jackson.map.ObjectMapper;

// TODO: Auto-generated Javadoc
/**
 * The Class AsrDetailViewDataItem.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailViewDataItemObject implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4814390378459093207L;

	private String value;
	private String url;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Override
	public String toString() {

		ObjectMapper mapperObj = new ObjectMapper();

		try {
			// get Employee object as a json string
			String jsonStr = mapperObj.writeValueAsString(this);
			System.out.println(jsonStr);
			return jsonStr;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}

}
