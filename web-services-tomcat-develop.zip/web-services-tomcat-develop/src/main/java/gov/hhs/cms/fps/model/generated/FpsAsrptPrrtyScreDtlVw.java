package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Where;

@Entity
@Table(name="FPS_ASRPT_PRIORITY_SCRE_DTL_VW")

public class FpsAsrptPrrtyScreDtlVw implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8301459288242366724L;

	private int asrptId;
	private int criteriaId;
	private String rangeDesc;
	private int criteriaSortOrder;
	private String criteriaDesc;
//	private BigDecimal criteriaWeight;
	private BigDecimal rangeScre;
	private String asrValue;
	private BigDecimal totalScre;
	private FpsAsrpt fpsAsrpt;
	private String criteriaNm;
	
	@Id
	@Column(name="ASRPT_ID")
	public int getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(int asrptId) {
		this.asrptId = asrptId;
	}

	@Id
	@Column(name="CRITERIA_ID")
	public int getCriteriaId() {
		return criteriaId;
	}
	public void setCriteriaId(int criteriaId) {
		this.criteriaId = criteriaId;
	}
//	@Column(name="RANGE_DESC")
	@Transient
	public String getRangeDesc() {
		return rangeDesc;
	}
	public void setRangeDesc(String rangeDesc) {
		this.rangeDesc = rangeDesc;
	}
	
	
	@ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="ASRPT_ID", referencedColumnName="ASRPT_ID", updatable=false, insertable=false)
	public FpsAsrpt getFpsAsrpt() {
		return fpsAsrpt;
	}
	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
		this.fpsAsrpt = fpsAsrpt;
	}
	@Column(name="CRITERIA_SORT_ORDER")
	public int getCriteriaSortOrder() {
		return criteriaSortOrder;
	}
	public void setCriteriaSortOrder(int criteriaSortOrder) {
		this.criteriaSortOrder = criteriaSortOrder;
	}
	@Column(name="CRITERIA_DESC")
	public String getCriteriaDesc() {
		return criteriaDesc;
	}
	public void setCriteriaDesc(String criteriaDesc) {
		this.criteriaDesc = criteriaDesc;
	}
//	@Column(name="CRITERIA_WEIGHT")
//	public BigDecimal getCriteriaWeight() {
//		return criteriaWeight;
//	}
//	public void setCriteriaWeight(BigDecimal criteriaWeight) {
//		this.criteriaWeight = criteriaWeight;
//	}
	@Column(name="RANGE_SCRE")
	
	public BigDecimal getRangeScre() {
		return rangeScre;
	}
	public void setRangeScre(BigDecimal rangeScre) {
		this.rangeScre = rangeScre;
	}
	@Column(name="ASR_VALUE")
	public String getAsrValue() {
		return asrValue;
	}
	public void setAsrValue(String asrValue) {
		this.asrValue = asrValue;
	}
	@Column(name="TOTAL_SCRE")
	public BigDecimal getTotalScre() {
		return totalScre;
	}
	public void setTotalScre(BigDecimal totalScre) {
		this.totalScre = totalScre;
	}
	@Column(name="CRITERIA_NM")
	public String getCriteriaNm() {
		return criteriaNm;
	}
	public void setCriteriaNm(String criteriaNm) {
		this.criteriaNm = criteriaNm;
	}
}
