/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
// TODO: Auto-generated Javadoc

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import gov.hhs.cms.fps.model.generated.FpsEditNumRfrnc;
import gov.hhs.cms.fps.model.generated.FpsRcncltnClmline;

/**
 * The Class AsrDetailViewResponse.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailViewResponse  implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1766391575720920055L;
	
	/** The transaction ID. */
	private String transactionID;
	
	/** The status. */
	private String status;
	
	/** The response type. */
	private String responseType;
	
	/** The response data. */
	private AsrDetail responseData;
	
	private List<FpsEditNumRfrnc> activeEditInfos;
	private List<FpsEditNumRfrnc> inactiveEditInfos;
	private List<FpsEdit> activeEdits;
	private List<FpsEdit> inactiveEdits;
	private List<FpsRcncltnClmline> editClaims;

	
	/**
	 * Gets the transaction ID.
	 *
	 * @return the transaction ID
	 */
	public String getTransactionID() {
		return transactionID;
	}
	
	/**
	 * Sets the transaction ID.
	 *
	 * @param transactionID the new transaction ID
	 */
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Gets the response type.
	 *
	 * @return the responseType
	 */
	public String getResponseType() {
		return responseType;
	}
	
	/**
	 * Sets the response type.
	 *
	 * @param responseType the responseType to set
	 */
	public void setResponseType(String responseType) {
		this.responseType = responseType;
	}
	
	/**
	 * Gets the response data.
	 *
	 * @return the responseData
	 */
	public AsrDetail getResponseData() {
		return responseData;
	}
	
	/**
	 * Sets the response data.
	 *
	 * @param responseData the responseData to set
	 */
	public void setResponseData(AsrDetail responseData) {
		this.responseData = responseData;
	}


	public List<FpsEditNumRfrnc> getActiveEditInfos() {
		return activeEditInfos;
	}

	public void setActiveEditInfos(List<FpsEditNumRfrnc> activeEditInfos) {
		this.activeEditInfos = activeEditInfos;
	}

	public List<FpsEditNumRfrnc> getInactiveEditInfos() {
		return inactiveEditInfos;
	}

	public void setInactiveEditInfos(List<FpsEditNumRfrnc> inactiveEditInfos) {
		this.inactiveEditInfos = inactiveEditInfos;
	}

	public List<FpsRcncltnClmline> getEditClaims() {
		return editClaims;
	}

	public void setEditClaims(List<FpsRcncltnClmline> editClaims) {
		this.editClaims = editClaims;
	}

	public List<FpsEdit> getActiveEdits() {
		return activeEdits;
	}

	public void setActiveEdits(List<FpsEdit> activeEdits) {
		this.activeEdits = activeEdits;
	}

	public List<FpsEdit> getInactiveEdits() {
		return inactiveEdits;
	}

	public void setInactiveEdits(List<FpsEdit> inactiveEdits) {
		this.inactiveEdits = inactiveEdits;
	}
	
	
}
