package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;

@Entity
@Table(name="FPS_CSTM_TBL_SCNDRY_NPI_RFRNC")
@BatchSize(size = 1000)
public class FpsCstmTblScndryNpiRfrnc implements Serializable{

	private String modelBusnsId;
	private Integer cstmTblId;
	private Integer cstmTblClmnNum;
	
	@Id
	@Column(name="MODEL_BUSNS_ID")
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	@Id
	@Column(name="CSTM_TBL_ID")
	public Integer getCstmTblId() {
		return cstmTblId;
	}
	public void setCstmTblId(Integer cstmTblId) {
		this.cstmTblId = cstmTblId;
	}
	@Id
	@Column(name="CSTM_TBL_CLMN_NUM")
	public Integer getCstmTblClmnNum() {
		return cstmTblClmnNum;
	}
	public void setCstmTblClmnNum(Integer cstmTblClmnNum) {
		this.cstmTblClmnNum = cstmTblClmnNum;
	}
	
	
}
