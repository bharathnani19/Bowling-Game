package gov.hhs.cms.fps.model;

import java.io.Serializable;

public class AvailableClaims implements Serializable {

	private String atRiskInd = "N";
	private String atRiskDInd = "N";
	private String latestInd = "N";
	private String latestDInd = "N";
	
	private String allClaimsInd = "N";
	private String allClaimsDInd = "N";
	private String rrbInd = "N";
	private String atRiskP1Ind = "N";
	private String asrCostP1Ind = "N";
	private String asrCostInd = "N";
	private String asrCostDInd = "N";
	public String getAtRiskInd() {
		return atRiskInd;
	}
	public void setAtRiskInd(String atRiskInd) {
		this.atRiskInd = atRiskInd;
	}
	public String getAtRiskDInd() {
		return atRiskDInd;
	}
	public void setAtRiskDInd(String atRiskDInd) {
		this.atRiskDInd = atRiskDInd;
	}
	public String getLatestInd() {
		return latestInd;
	}
	public void setLatestInd(String latestInd) {
		this.latestInd = latestInd;
	}
	public String getLatestDInd() {
		return latestDInd;
	}
	public void setLatestDInd(String latestDInd) {
		this.latestDInd = latestDInd;
	}
	public String getAllClaimsInd() {
		return allClaimsInd;
	}
	public void setAllClaimsInd(String allClaimsInd) {
		this.allClaimsInd = allClaimsInd;
	}
	public String getAllClaimsDInd() {
		return allClaimsDInd;
	}
	public void setAllClaimsDInd(String allClaimsDInd) {
		this.allClaimsDInd = allClaimsDInd;
	}
	public String getRrbInd() {
		return rrbInd;
	}
	public void setRrbInd(String rrbInd) {
		this.rrbInd = rrbInd;
	}
	public String getAtRiskP1Ind() {
		return atRiskP1Ind;
	}
	public void setAtRiskP1Ind(String atRiskP1Ind) {
		this.atRiskP1Ind = atRiskP1Ind;
	}
	public String getAsrCostP1Ind() {
		return asrCostP1Ind;
	}
	public void setAsrCostP1Ind(String asrCostP1Ind) {
		this.asrCostP1Ind = asrCostP1Ind;
	}
	public String getAsrCostInd() {
		return asrCostInd;
	}
	public void setAsrCostInd(String asrCostInd) {
		this.asrCostInd = asrCostInd;
	}
	public boolean isNoClaims() {
		return "N".equals(asrCostInd)  && "N".equals(asrCostDInd) && "N".equals(asrCostP1Ind) && "N".equals(atRiskP1Ind) && "N".equals(rrbInd) && "N".equals(allClaimsDInd) 
				&& "N".equals(allClaimsInd) && "N".equals(latestDInd) && "N".equals(latestInd)  && "N".equals(atRiskDInd)  && "N".equals(atRiskInd) ;
	}
	public String getAsrCostDInd() {
		return asrCostDInd;
	}
	public void setAsrCostDInd(String asrCostDInd) {
		this.asrCostDInd = asrCostDInd;
	}
	
}
