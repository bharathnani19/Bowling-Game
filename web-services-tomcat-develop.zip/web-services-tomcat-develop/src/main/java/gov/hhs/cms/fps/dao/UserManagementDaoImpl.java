package gov.hhs.cms.fps.dao;

import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.beanutils.PropertyUtilsBean;
import org.springframework.stereotype.Repository;

import gov.hhs.cms.fps.model.generated.FpsPrtlAcsRqst;
import gov.hhs.cms.fps.model.generated.FpsPrtlAcsRqstGrp;
import gov.hhs.cms.fps.model.um.UserManagementRequest;
import gov.hhs.cms.fps.model.um.UserRequestOptionalAccess;

@Repository(value="userManagementDao")
public class UserManagementDaoImpl extends BaseDao<Integer, FpsPrtlAcsRqst> implements UserManagementDao {
	private static Logger logger = Logger.getLogger(UserManagementDaoImpl.class.getName());

	@Override
	public UserManagementRequest saveRequest(UserManagementRequest request) {
		BeanUtilsBean.getInstance().getConvertUtils().register(false, false, 0);
		PropertyUtilsBean p = new PropertyUtilsBean();
		FpsPrtlAcsRqst dbReq = new FpsPrtlAcsRqst();
		try {
			p.copyProperties(dbReq,  request);
			dbReq.setAudtInsrtId(request.getRqstrCmsUserId());
			dbReq.setAudtInsrtTs(new Date());
//			if (request.hasAttributeRequest()){
//				
//			}
			Integer id = (Integer)getCurrentSession().save(dbReq);
			request.setPrtlAcsRqstId(id);
			for (UserRequestOptionalAccess optional : request.getOptionalAccessesDMA()) {
				FpsPrtlAcsRqstGrp group = new FpsPrtlAcsRqstGrp();
				group.setFpsPrtlAcsRqst(dbReq);
				group.setGroupCd(optional.getGroupCd());
				group.setAudtInsrtId(request.getRqstrCmsUserId());
				group.setAudtInsrtTs(new Date());
//				group.setApprovedInd("P");
				getCurrentSession().save(group);
				
			}
			for (UserRequestOptionalAccess optional : request.getOptionalAccessesCOR()) {
				FpsPrtlAcsRqstGrp group = new FpsPrtlAcsRqstGrp();
				group.setFpsPrtlAcsRqst(dbReq);
				group.setGroupCd(optional.getGroupCd());
				group.setAudtInsrtId(request.getRqstrCmsUserId());
				group.setAudtInsrtTs(new Date());
//				group.setApprovedInd("P");
				getCurrentSession().save(group);
				
			}
		} catch (IllegalAccessException e) {
			logger.log(Level.SEVERE, "error populating new UM request object", e);
		} catch (InvocationTargetException e) {
			logger.log(Level.SEVERE, "error populating new UM request object", e);
		} catch (NoSuchMethodException e) {
			logger.log(Level.SEVERE, "error populating new UM request object", e);
		}
		
		return request;
	}

	@Override
	public void updateRequest(FpsPrtlAcsRqst request) throws Exception{
		
			getCurrentSession().update(request);
			for (FpsPrtlAcsRqstGrp optional : request.getFpsPrtlAcsRqstGrps()) {
				
				getCurrentSession().update(optional);
				
			}
		
	}
	@Override
	public UserManagementRequest updateRequest(UserManagementRequest request) {
		BeanUtilsBean.getInstance().getConvertUtils().register(false, false, 0);
		PropertyUtilsBean p = new PropertyUtilsBean();
		logger.info("updating " + request.toString());
		try {
			FpsPrtlAcsRqst dbReq = loadRequest(request.getPrtlAcsRqstId());

			p.copyProperties(dbReq,  request);
			String updateId = request.getLoggedInUserId() != null ? request.getLoggedInUserId() : "SYSTEM";
			dbReq.setAudtUpdtId(updateId);
			dbReq.setAudtUpdtTs(new Date());
			getCurrentSession().update(dbReq);
		} catch (IllegalAccessException e) {
			logger.log(Level.SEVERE, "error populating UM request object for " + request.getPrtlAcsRqstId(), e);
		} catch (InvocationTargetException e) {
			logger.log(Level.SEVERE, "error populating UM request object for " + request.getPrtlAcsRqstId(), e);
		} catch (NoSuchMethodException e) {
			logger.log(Level.SEVERE, "error populating UM request object for " + request.getPrtlAcsRqstId(), e);
		}
		return request;
	}
	@Override
	public FpsPrtlAcsRqst loadRequest(Integer requestId) {
	
		FpsPrtlAcsRqst r =  (FpsPrtlAcsRqst) getCurrentSession().load(FpsPrtlAcsRqst.class, requestId);
		return r;
	}

	@Override
	public List<FpsPrtlAcsRqst> loadRequests() {
		return (List<FpsPrtlAcsRqst>) getCurrentSession().createQuery(" from FpsPrtlAcsRqst where aprvdInd != 'N' order by audtInsrtTs desc").list();
	}

	@Override
	public FpsPrtlAcsRqst loadRequest(String userId) {
		List<FpsPrtlAcsRqst> requests = (List<FpsPrtlAcsRqst>) getCurrentSession().createQuery(" from FpsPrtlAcsRqst where rqstrCmsUserId = :userId order by audtInsrtTs desc").setString("userId", userId).list();
		if (requests != null && requests.size() > 0){
			return requests.get(0);
		}
		return null;
	}
	@Override
	public FpsPrtlAcsRqst loadRequestForNewRequest(String userId) {
		List<FpsPrtlAcsRqst> requests = (List<FpsPrtlAcsRqst>) getCurrentSession().createQuery(" from FpsPrtlAcsRqst where rqstrCmsUserId = :userId order by aprvdInd desc, audtInsrtTs desc").setString("userId", userId).list();
		if (requests != null && requests.size() > 0){
			return requests.get(0);
		}
		return null;
	}

}
