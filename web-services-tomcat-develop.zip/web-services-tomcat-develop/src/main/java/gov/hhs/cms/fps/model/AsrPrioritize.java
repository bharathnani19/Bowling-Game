package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrPrioritize implements Serializable{
	private List<AsrPrioritizeItem> priorities;

	public List<AsrPrioritizeItem> getPriorities() {
		return priorities;
	}

	public void setPriorities(List<AsrPrioritizeItem> priorities) {
		this.priorities = priorities;
	}

	@Override
	public String toString() {
		return "AsrPrioritize [priorities=" + priorities + "]";
	}
	

}
