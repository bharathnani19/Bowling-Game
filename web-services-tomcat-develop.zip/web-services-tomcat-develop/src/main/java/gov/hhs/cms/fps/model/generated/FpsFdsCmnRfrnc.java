package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="FPS_FDS_CMN_RFRNC")
public class FpsFdsCmnRfrnc implements Serializable {
	private String cmnRfrncCd;
	private String ctgryTypeCd;
	private String ctgryTypeDesc;
	private String ctgryTypeValCd;
	private String ctgryTypeValDesc;
	@Id
	@Column(name="CMN_RFRNC_CD")
	public String getCmnRfrncCd() {
		return cmnRfrncCd;
	}
	public void setCmnRfrncCd(String cmnRfrncCd) {
		this.cmnRfrncCd = cmnRfrncCd;
	}
	@Column(name="CTGRY_TYPE_CD")
	public String getCtgryTypeCd() {
		return ctgryTypeCd;
	}
	public void setCtgryTypeCd(String ctgryTypeCd) {
		this.ctgryTypeCd = ctgryTypeCd;
	}
	@Column(name="CTGRY_TYPE_DESC")
	public String getCtgryTypeDesc() {
		return ctgryTypeDesc;
	}
	public void setCtgryTypeDesc(String ctgryTypeDesc) {
		this.ctgryTypeDesc = ctgryTypeDesc;
	}
	@Column(name="CTGRY_TYPE_VAL_CD")
	public String getCtgryTypeValCd() {
		return ctgryTypeValCd;
	}
	public void setCtgryTypeValCd(String ctgryTypeValCd) {
		this.ctgryTypeValCd = ctgryTypeValCd;
	}
	@Column(name="CTGRY_TYPE_VAL_DESC")
	public String getCtgryTypeValDesc() {
		return ctgryTypeValDesc;
	}
	public void setCtgryTypeValDesc(String ctgryTypeValDesc) {
		this.ctgryTypeValDesc = ctgryTypeValDesc;
	}
	

}
