package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailReportCard implements Serializable {

	
	private List<AsrDetailReportCardData> aaMulti = new ArrayList<AsrDetailReportCardData>();
	private List<AsrDetailReportCardData> aaSingle;
	private List<AsrDetailReportCardData> socNet = new ArrayList<AsrDetailReportCardData>();
	private List<AsrDetailReportCardData> predict = new ArrayList<AsrDetailReportCardData>();
	private List<AsrDetailReportCardData> ruleBased = new ArrayList<AsrDetailReportCardData>();
	private List<AsrDetailReportCardData> unknown = new ArrayList<AsrDetailReportCardData>();
	private List<AsrDetailReportCardData> riskScoreRC = new ArrayList<AsrDetailReportCardData>();
	private List<CustomTable> customTables = new ArrayList<CustomTable>();
	private List<CustomTable> customVizTables;
	private String modelBusnsId;
	private String fpsVersionInd;
	private String lookback;
	private String docUrl;
	private String hasMac = "N";
	private String partDClaimInd;
	@JsonIgnore
	private String state;

	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	private List<AsrGenericCode> reportCardDates;
	public List<AsrDetailReportCardData> getAaMulti() {
		return aaMulti;
	}
	public void setAaMulti(List<AsrDetailReportCardData> aaMulti) {
		this.aaMulti = aaMulti;
	}
	public List<AsrDetailReportCardData> getAaSingle() {
		return aaSingle;
	}
	public void setAaSingle(List<AsrDetailReportCardData> aaSingle) {
		this.aaSingle = aaSingle;
	}
	public List<AsrDetailReportCardData> getSocNet() {
		return socNet;
	}
	public void setSocNet(List<AsrDetailReportCardData> socNet) {
		this.socNet = socNet;
	}
	public List<AsrDetailReportCardData> getPredict() {
		return predict;
	}
	public void setPredict(List<AsrDetailReportCardData> predict) {
		this.predict = predict;
	}
	public List<AsrDetailReportCardData> getRuleBased() {
		return ruleBased;
	}
	public void setRuleBased(List<AsrDetailReportCardData> ruleBased) {
		this.ruleBased = ruleBased;
	}
	public List<AsrDetailReportCardData> getUnknown() {
		return unknown;
	}
	public void setUnknown(List<AsrDetailReportCardData> unknown) {
		this.unknown = unknown;
	}
	public List<CustomTable> getCustomTables() {
		return customTables;
	}
	public void setCustomTables(List<CustomTable> customTables) {
		this.customTables = customTables;
	}
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	public String getFpsVersionInd() {
		return fpsVersionInd;
	}
	public void setFpsVersionInd(String fpsVersionInd) {
		this.fpsVersionInd = fpsVersionInd;
	}
	public List<AsrGenericCode> getReportCardDates() {
		return reportCardDates;
	}
	public void setReportCardDates(List<AsrGenericCode> reportCardDates) {
		this.reportCardDates = reportCardDates;
	}
	public String getLookback() {
		return lookback;
	}
	public void setLookback(String lookback) {
		this.lookback = lookback;
	}
	public String getDocUrl() {
		return docUrl;
	}
	public void setDocUrl(String docUrl) {
		this.docUrl = docUrl;
	}
	public String getHasMac() {
		return hasMac;
	}
	public void setHasMac(String hasMac) {
		this.hasMac = hasMac;
	}
	public String getPartDClaimInd() {
		return partDClaimInd;
	}
	public void setPartDClaimInd(String partDClaimInd) {
		this.partDClaimInd = partDClaimInd;
	}
	public List<AsrDetailReportCardData> getRiskScoreRC() {
		return riskScoreRC;
	}
	public void setRiskScoreRC(List<AsrDetailReportCardData> riskScoreRC) {
		this.riskScoreRC = riskScoreRC;
	}
	public List<CustomTable> getCustomVizTables() {
		return customVizTables;
	}
	public void setCustomVizTables(List<CustomTable> customVizTables) {
		this.customVizTables = customVizTables;
	}
}