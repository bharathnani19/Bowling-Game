/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.RandomUtils;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import org.codehaus.jackson.annotate.JsonIgnore;

// TODO: Auto-generated Javadoc
/**
 * The Class AsrDetailMasterAlert.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailMasterAlert implements Serializable, Comparable<AsrDetailMasterAlert> {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 9075788934739863225L;
	private AsrDetailModel models = new AsrDetailModel();
	private int modelId;
	private int asrptId;
	private String currentInd;
	private String recentInd;
	private String priorityInd;
	private String legacyInd;
	private List<AsrDetailReportCard> reportCards = new ArrayList<AsrDetailReportCard>();
	private List<AsrDetailClaimLineItem> claimLines = new ArrayList<AsrDetailClaimLineItem>();
	private List<AsrDetailAlert> alerts = new ArrayList<AsrDetailAlert>();
	private String createdDt;
	private String relCreatedDt;
	private String modDt;
	private Integer legacyScore;
	private BigDecimal riskScore;
	private String derivedZone;
	private String cost;
	private int alertCnt;
	private Date createdDtAsDate;
	private String npi;
	private String modelTypeCd;
	private String hasReportCard;
	@JsonIgnore
	private String modelBusnsId;
	private String lookback;
	private String status;
	private String modelStatus;
	private String showViz;
	private String vizType;
	private Integer alertId;
	private String partDClaimInd;
	private Integer cadence;
	private String state;
	private String mdcdState;
	private String pathToEduInd;
	private BigDecimal sevScore;

	public String getCurrentInd() {
		return currentInd;
	}

	public void setCurrentInd(String currentInd) {
		this.currentInd = currentInd;
	}

	public String getLegacyInd() {
		return legacyInd;
	}

	public void setLegacyInd(String legacyInd) {
		this.legacyInd = legacyInd;
	}

	public List<AsrDetailReportCard> getReportCards() {
		return reportCards;
	}

	public void setReportCards(List<AsrDetailReportCard> reportCards) {
		this.reportCards = reportCards;
	}

	public List<AsrDetailClaimLineItem> getClaimLines() {
		return claimLines;
	}

	public void setClaimLines(List<AsrDetailClaimLineItem> claimLines) {
		this.claimLines = claimLines;
	}

	public String getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}

	public String getModDt() {
		return modDt;
	}

	public void setModDt(String modDt) {
		this.modDt = modDt;
	}

	public Integer getLegacyScore() {
		return legacyScore;
	}

	public void setLegacyScore(Integer legacyScore) {
		this.legacyScore = legacyScore;
	}

	public BigDecimal getRiskScore() {
		return riskScore;
	}

	public void setRiskScore(BigDecimal riskScore) {
		this.riskScore = riskScore;
	}

	public String getDerivedZone() {
		return derivedZone;
	}

	public void setDerivedZone(String derivedZone) {
		this.derivedZone = derivedZone;
	}

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	public int getAlertCnt() {
		return alertCnt;
	}

	public void setAlertCnt(int alertCnt) {
		this.alertCnt = alertCnt;
	}

	public AsrDetailModel getModels() {
		return models;
	}

	public void setModels(AsrDetailModel models) {
		this.models = models;
	}

	@JsonIgnore
	public Date getCreatedDtAsDate() {
		return createdDtAsDate;
	}

	public void setCreatedDtAsDate(Date createdDtAsDate) {
		this.createdDtAsDate = createdDtAsDate;
	}

	public List<AsrDetailAlert> getAlerts() {
		return alerts;
	}

	public void setAlerts(List<AsrDetailAlert> alerts) {
		this.alerts = alerts;
	}

	public int getModelId() {
		return modelId;
	}

	public void setModelId(int modelId) {
		this.modelId = modelId;
	}

	public int getAsrptId() {
		return asrptId;
	}

	public void setAsrptId(int asrptId) {
		this.asrptId = asrptId;
	}

	public String getNpi() {
		return npi;
	}

	public void setNpi(String npi) {
		this.npi = npi;
	}

	public String getModelTypeCd() {
		return modelTypeCd;
	}

	public void setModelTypeCd(String modelTypeCd) {
		this.modelTypeCd = modelTypeCd;
	}

	public String getHasReportCard() {
		return hasReportCard;
	}

	public void setHasReportCard(String hasReportCard) {
		this.hasReportCard = hasReportCard;
	}

	public String getModelBusnsId() {
		return modelBusnsId;
	}

	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}

	public String getRecentInd() {
		return recentInd;
	}

	public void setRecentInd(String recentInd) {
		this.recentInd = recentInd;
	}

	public String getPriorityInd() {
		return priorityInd;
	}

	public void setPriorityInd(String priorityInd) {
		this.priorityInd = priorityInd;
	}

	public String getLookback() {
		return lookback;
	}

	public void setLookback(String lookback) {
		this.lookback = lookback;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getShowViz() {
		return showViz;
	}

	public void setShowViz(String showViz) {
		this.showViz = showViz;
	}

	public String getRelCreatedDt() {
		return relCreatedDt;
	}

	public void setRelCreatedDt(String relCreatedDt) {
		this.relCreatedDt = relCreatedDt;
	}

	public String getVizType() {
		return vizType;
	}

	public void setVizType(String vizType) {
		this.vizType = vizType;
	}

	public String getModelStatus() {
		return modelStatus;
	}

	public void setModelStatus(String modelStatus) {
		this.modelStatus = modelStatus;
	}

	public Integer getAlertId() {
		return alertId;
	}

	public void setAlertId(Integer alertId) {
		this.alertId = alertId;
	}

	public String getPartDClaimInd() {
		return partDClaimInd;
	}

	public void setPartDClaimInd(String partDClaimInd) {
		this.partDClaimInd = partDClaimInd;
	}

	public Integer getCadence() {
		return cadence;
	}

	public void setCadence(Integer cadence) {
		this.cadence = cadence;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getMdcdState() {
		return mdcdState;
	}

	public void setMdcdState(String mdcdState) {
		this.mdcdState = mdcdState;
	}

	@Override
	public int compareTo(AsrDetailMasterAlert alert) {
		int dates = alert.getCreatedDtAsDate().compareTo(this.getCreatedDtAsDate());
		if (dates != 0) {
			return dates;
		}
		int models = this.getModelBusnsId().compareTo(alert.getModelBusnsId());
		if (models == 0 && this.getState() != null) {
			return  this.getState().compareTo(alert.getState());
		}
		return models;
	}
	public String getPathToEduInd() {
		return pathToEduInd;
	}

	public void setPathToEduInd(String pathToEduInd) {
		this.pathToEduInd = pathToEduInd;
	}

	public BigDecimal getSevScore() {
		return sevScore;
	}

	public void setSevScore(BigDecimal sevScore) {
		this.sevScore = sevScore;
	}
}
