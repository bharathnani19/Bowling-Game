package gov.hhs.cms.fps.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import gov.hhs.cms.fps.model.generated.FpsActnBrrRfrnc;
import gov.hhs.cms.fps.model.generated.FpsActnTypeRfrnc;
import gov.hhs.cms.fps.model.generated.FpsActvtyTypeRfrnc;
import gov.hhs.cms.fps.model.generated.FpsAlertTypeRfrnc;
import gov.hhs.cms.fps.model.generated.FpsAsrptStatMatVw;
import gov.hhs.cms.fps.model.generated.FpsCntrctrRfrnc;
import gov.hhs.cms.fps.model.generated.FpsEditNumRfrnc;
import gov.hhs.cms.fps.model.generated.FpsGeoStateRfrnc;
import gov.hhs.cms.fps.model.generated.FpsModel;
import gov.hhs.cms.fps.model.generated.FpsModelMdcd;
import gov.hhs.cms.fps.model.generated.FpsModelSchmRfrnc;
import gov.hhs.cms.fps.model.generated.FpsModelSrvcCtgryRfrnc;
import gov.hhs.cms.fps.model.generated.FpsPrioritizationExclsnCtgryRfrnc;
import gov.hhs.cms.fps.model.generated.FpsPrtlAcsRqstGrpRfrnc;
import gov.hhs.cms.fps.model.generated.FpsPrvdrAnlysExclusionRfrnc;
import gov.hhs.cms.fps.model.generated.FpsPrvdrAnlysExclusionRfrncMdcd;
import gov.hhs.cms.fps.model.generated.FpsPrvdrSpcltyTypeRfrnc;
import gov.hhs.cms.fps.model.generated.FpsRulngRfrnc;
import gov.hhs.cms.fps.model.generated.FpsStateCntrctrInfo;
import gov.hhs.cms.fps.model.generated.FpsStusRfrnc;
import gov.hhs.cms.fps.model.generated.FpsZnRfrnc;
import gov.hhs.cms.fps.util.DbHealthCheckUtil;
import gov.hhs.cms.fps.util.FpsEnums.ModelProgram;
import gov.hhs.cms.fps.util.JurisdictionOrderBy;

@Repository("referenceDataDao")
public class ReferenceDataDaoImpl extends BaseDao<Integer, Object> implements ReferenceDataDao {
	public List<FpsCntrctrRfrnc> loadContractorZones(boolean isMac, boolean isMedic) {
		String order = isMac ? " desc " : " asc" ;
		Criteria c  = getCurrentSession().createCriteria(FpsCntrctrRfrnc.class);
		c.add(Restrictions.in("cntrctrTypeCd", new String[] {"2", "4", "5"}));
		c.addOrder(new JurisdictionOrderBy(isMac, isMedic));
		return c.list();
	}

	public List<FpsCntrctrRfrnc> loadContractorZonesNoMAC() {
		return getCurrentSession().createQuery("from FpsCntrctrRfrnc where cntrctrTypeCd in ( '2', '4') order by cntrctrDesc")
				.list();
	}
	
	public List<FpsCntrctrRfrnc> loadPrioritizeZones() {
		return getCurrentSession().createQuery("from FpsCntrctrRfrnc where cntrctrTypeCd = '2' order by cntrctrDesc")
				.list();
	}

	public List<FpsZnRfrnc> loadZones() {
		return getCurrentSession().createQuery("from FpsZnRfrnc order by znCd").list();
	}


	public List<FpsActnBrrRfrnc> loadBarriers() {
		return getCurrentSession().createQuery("from FpsActnBrrRfrnc order by actnBrrDesc asc").list();
	}

	public List<FpsAlertTypeRfrnc> loadAlertTypes() {
		return getCurrentSession().createQuery("from FpsAlertTypeRfrnc order by alertTypeDesc asc").list();
	}

	public List<FpsModel> loadModels() {
		return getCurrentSession().createQuery("from FpsModel where modelActvtyStus = 'Active' order by lower(modelBusnsId) asc").list();
	}
	public List<FpsModelMdcd> loadMdcdModels() {
		return getCurrentSession().createQuery("from FpsModelMdcd where modelActvtyStus = 'Active' order by lower(modelBusnsId) asc").list();
	}
	@Override
	public List<FpsModelSrvcCtgryRfrnc> loadVmtCategories(ModelProgram pgmType) {
		String sql = "from FpsModelSrvcCtgryRfrnc ";
		if (pgmType != null && (pgmType.equals(ModelProgram.MDCD) || pgmType.equals(ModelProgram.MDCR))) {
			sql+=" where srvcPgmType = '"+pgmType.toString()+"' ";
		}
		sql+="order by lower(srvcCtgry) asc";
		return getCurrentSession().createQuery(sql).list();
	}
	@Override
	public List<FpsModelSchmRfrnc> loadVmtSchemes() {
		return getCurrentSession().createQuery("from FpsModelSchmRfrnc order by lower(srvcSchm) asc").list();
	}
	@Override
	public List<FpsModel> loadNonActiveModels() {
		return getCurrentSession().createQuery("from FpsModel where modelActvtyStus != 'Active' order by lower(modelBusnsId) asc").list();
	}
	@Override
	public List<FpsModel> loadEditModels() {
		return getCurrentSession().createQuery("from FpsEditSmryVw where order by modelName asc").list();
	}
	public List<String> doHealthCheck() {
		List<String> ret = new ArrayList<String>();
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAlert", getCurrentSession()));
//		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAlertClmAsctn", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAsrpt", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAsrptAlertAsctn", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAsrptInvstgtn", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAsrptLog", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAsrptStatMatVw", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAsrptStatRegVw", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAsrptSysTag", getCurrentSession()));
//		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAsrptUser", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAsrptUserActvty", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAsrptUserInvstgtn", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAsrptUserAdminvActn", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAsrptUserRulng", getCurrentSession()));
//		ret.add(DbHealthCheckUtil.doHealthCheck("FpsBene", getCurrentSession()));
//		ret.add(DbHealthCheckUtil.doHealthCheck("FpsFdFrdSubj", getCurrentSession()));
//		ret.add(DbHealthCheckUtil.doHealthCheck("FpsFdFrdCase", getCurrentSession()));
//		ret.add(DbHealthCheckUtil.doHealthCheck("FpsClm", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsCntrctrRfrnc", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsCstmTblClmnName", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsCstmTblData", getCurrentSession()));
//		ret.add(DbHealthCheckUtil.doHealthCheck("FpsFoiaRqst", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsCstmTbl", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsModel", getCurrentSession()));
//		ret.add(DbHealthCheckUtil.doHealthCheck("FpsPtdOpAdvrsEfct", getCurrentSession()));
//		ret.add(DbHealthCheckUtil.doHealthCheck("FpsPtdOpBzo", getCurrentSession()));
//		ret.add(DbHealthCheckUtil.doHealthCheck("FpsPtdOpPrscrbr", getCurrentSession()));
//		ret.add(DbHealthCheckUtil.doHealthCheck("FpsPtdAdhocData", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsPrePymtDnl", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsPrvdr", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsPrvdrZnAsctn", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsRptCardAttrLabel", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsRptCardDtl", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsRptCardRskSnaDtl", getCurrentSession()));
//		ret.add(DbHealthCheckUtil.doHealthCheck("FpsInvstgtnUserNote", getCurrentSession()));
//		ret.add(DbHealthCheckUtil.doHealthCheck("FpsPlndSysOutge", getCurrentSession()));
//		ret.add(DbHealthCheckUtil.doHealthCheck("VwFpsPtdAsrSummary", getCurrentSession()));
//		ret.add(DbHealthCheckUtil.doHealthCheck("VwFpsAsrptSysTag", getCurrentSession()));
//		ret.add(DbHealthCheckUtil.doHealthCheck("FpsZnThresholdRiskScreVw", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAsrptMdcd", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAsrptPrrty", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAsrptPrrtyMdcd", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAsrptLog", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsVlnrbMgmtRqst", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsProdnPrblmRpt", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsAlertMdcd", getCurrentSession()));
		ret.add(DbHealthCheckUtil.doHealthCheck("FpsModelMdcd", getCurrentSession()));

		
		return ret;
	}

	public List<FpsActvtyTypeRfrnc> loadActivities() {
		return getCurrentSession().createQuery("from FpsActvtyTypeRfrnc order by actvtyTypeDesc asc").list();
	}

	public List<FpsActnTypeRfrnc> loadActions() {
		return getCurrentSession().createQuery("from FpsActnTypeRfrnc order by actnTypeDesc asc").list();
	}

	public List<FpsGeoStateRfrnc> loadStates() {
		return getCurrentSession().createQuery("from FpsGeoStateRfrnc order by geoStateName asc").list();
	}

	public List<FpsRulngRfrnc> loadRulings() {
		return getCurrentSession().createQuery("from FpsRulngRfrnc order by rulngDesc asc").list();
	}

	public List<FpsCntrctrRfrnc> loadActualAssignedZones() {
		List<FpsCntrctrRfrnc> items = new ArrayList<FpsCntrctrRfrnc>();
		SQLQuery query = getCurrentSession().createSQLQuery(
				"select distinct asgned_cntrctr, case when cntrctr_desc is not null then cntrctr_desc else asgned_cntrctr end as cntrctr_desc from fps2.fps_asrpt_user_invstgtn a inner join fps2.fps_asrpt_invstgtn b on a.asrpt_invstgtn_id = b.asrpt_invstgtn_id left join fps2.fps_cntrctr_rfrnc c on a.asgned_cntrctr = c.cntrctr_cd "
						+ "where asgned_cntrctr is not null order by cntrctr_desc ");

		List<Object[]> rows = query.list();
		for (Object[] row : rows) {
			FpsCntrctrRfrnc item = new FpsCntrctrRfrnc();
			if (row[0] != null) {
				item.setCntrctrCd(row[0].toString());
				item.setCntrctrDesc(row[1].toString());

				items.add(item);
			}
		}
		return items;
	}

	@Override
	public List<FpsAsrptStatMatVw> loadCityStates() {
		return getCurrentSession().createQuery("from FpsAsrptStatMatVw where type = 'CITYSTATE' order by value")
				.list();
	}

	@Override
	public List<FpsStusRfrnc> loadPrioritizationTypes() {
		return getCurrentSession().createQuery(" from FpsStusRfrnc where stusCtgryName = 'PRRTY_TYPE' order by stusCd")
				.list();
	}

	@Override
	public List<FpsEditNumRfrnc> loadEdits() {
		return getCurrentSession().createQuery(" from FpsEditNumRfrnc where actvInd='Y' order by fpsEditName")
				.list();
	}

	@Override
	public List<FpsPrvdrAnlysExclusionRfrnc> loadExclusions() {
		return getCurrentSession().createQuery(" from FpsPrvdrAnlysExclusionRfrnc  order by exclusionDesc")
				.list();
	}
	@Override
	public List<FpsPrvdrAnlysExclusionRfrncMdcd> loadExclusionsMdcd() {
		return getCurrentSession().createQuery(" from FpsPrvdrAnlysExclusionRfrncMdcd  order by exclusionDesc")
				.list();
	}
	@Override
	public List<FpsPrioritizationExclsnCtgryRfrnc> loadExclusionCategories() {
		return getCurrentSession().createQuery(" from FpsPrioritizationExclsnCtgryRfrnc  order by displayOrder")
				.list();
	}
	
	@Override
	public List<FpsPrvdrSpcltyTypeRfrnc> loadSpecialties() {
		return getCurrentSession().createQuery(" from FpsPrvdrSpcltyTypeRfrnc  order by prvdrSpcltyTypeCd")
				.list();
	}

	@Override
	public List<FpsStateCntrctrInfo> loadStatesForUpic(String upic) {
		return getCurrentSession().createQuery(" from FpsStateCntrctrInfo where upic = :upic order by upic, stateCd")
				.setString("upic", upic)
				.list();
	}

	@Override
	public List<FpsPrtlAcsRqstGrpRfrnc> loadEmlRoles() {
		return getCurrentSession().createQuery("from FpsPrtlAcsRqstGrpRfrnc order by prtlAcsRqstGrpName")
				.list();
	}
}
