package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="fps_aps_watchlist", schema="fps2")
public class FpsApsWatchlistRoot implements Serializable {


	private Integer apsWatchlistId;
	private Integer sbscrptnId;
	private Integer asrptId;
	private Date audtInsrtTs;
	private Date audtUpdtTs;
	private String audtInsrtId;
	private String audtUpdtId;
	private FpsPrvdrAnlys fpsPrvdrAnlys;
	private BigDecimal identityId;
	private BigDecimal identityCrimId;
	private Date updatedDt;
	private Date refreshDt;
	
	public FpsApsWatchlistRoot() {}
	public FpsApsWatchlistRoot(Integer sbscrptnId, Integer asrptId, Date audtInsrtTs, String audtInsrtId,
			BigDecimal identityId, BigDecimal identityCrimId, Date updatedDt, Date refreshDt) {
		this.sbscrptnId = sbscrptnId;
		this.asrptId = asrptId;
		this.audtInsrtTs = audtInsrtTs;
		this.audtInsrtId = audtInsrtId;
		this.identityId = identityId;
		this.identityCrimId = identityCrimId;
		this.updatedDt = updatedDt;
		this.refreshDt = refreshDt;
	}
	@Id
	@Column(name="APS_WATCHLIST_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getApsWatchlistId() {
		return apsWatchlistId;
	}
	public void setApsWatchlistId(Integer apsWatchlistId) {
		this.apsWatchlistId = apsWatchlistId;
	}
	@Column(name="SBSCRPTN_ID")
	public Integer getSbscrptnId() {
		return sbscrptnId;
	}
	public void setSbscrptnId(Integer sbscrptnId) {
		this.sbscrptnId = sbscrptnId;
	}
	@Column(name="ASRPT_ID")

	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	@Column(name="AUDT_INSRT_TS")
	public Date getAudtInsrtTs() {
		return audtInsrtTs;
	}
	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	@Column(name="AUDT_INSRT_ID")

	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	@Column(name="AUDT_UPDT_ID")
	public String getAudtUpdtId() {
		return audtUpdtId;
	}
	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	@Column(name="AUDT_UPDT_TS")
	public Date getAudtUpdtTs() {
		return audtUpdtTs;
	}
	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
	@OneToOne
	@JoinColumn(name="ASRPT_ID", updatable = false, insertable = false)
	public FpsPrvdrAnlys getFpsPrvdrAnlys() {
		return fpsPrvdrAnlys;
	}
	public void setFpsPrvdrAnlys(FpsPrvdrAnlys fpsPrvdrAnlys) {
		this.fpsPrvdrAnlys = fpsPrvdrAnlys;
	}
	@Column(name="IDENTITY_ID")
	public BigDecimal getIdentityId() {
		return identityId;
	}
	public void setIdentityId(BigDecimal identityId) {
		this.identityId = identityId;
	}
	@Column(name="IDENTITY_CRIM_ID")
	public BigDecimal getIdentityCrimId() {
		return identityCrimId;
	}
	public void setIdentityCrimId(BigDecimal identityCrimId) {
		this.identityCrimId = identityCrimId;
	}
	@Column(name="UPDATED_DATE")
	public Date getUpdatedDt() {
		return updatedDt;
	}
	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}
	@Column(name="REFRESH_DT")
	public Date getRefreshDt() {
		return refreshDt;
	}
	public void setRefreshDt(Date refreshDt) {
		this.refreshDt = refreshDt;
	}
}
