package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)

public class ExclusionSet implements Serializable{

	private String userId;
	private List<ExclusionSetItem> exclusions;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public List<ExclusionSetItem> getExclusions() {
		return exclusions;
	}
	public void setExclusions(List<ExclusionSetItem> exclusions) {
		this.exclusions = exclusions;
	}
}
