/*
 * 
 */
package gov.hhs.cms.fps.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.joda.time.DateTime;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gov.hhs.cms.fps.model.FpsUserPreference;
import gov.hhs.cms.fps.model.PortalTrackingResult;
import gov.hhs.cms.fps.model.generated.FpsPortalActvtyHstry;
import gov.hhs.cms.fps.model.generated.FpsPortalSrchHstry;
import gov.hhs.cms.fps.model.generated.FpsUsrGuiPrfrnc;
import gov.hhs.cms.fps.util.FpsDomainObjectConverter;
@Repository("fpsTrackingDao")
public class FpsTrackingDaoImpl extends BaseDao<Integer, Object> implements FpsTrackingDao {

	
	public final String SEARCH_WITHOUT_ZONE = "select new gov.hhs.cms.fps.model.PortalTrackingResult(srcCriteriaList, count(*)) from FpsPortalSrchHstry  where audtInsrtTs > :thedate group by srcCriteriaList";
	public final String SEARCH_WITH_ZONE = "select new gov.hhs.cms.fps.model.PortalTrackingResult(srcCriteriaList, userZnCd,count(*))  from FpsPortalSrchHstry where  audtInsrtTs > :thedate group by srcCriteriaList,userZnCd";
	public final String ACTIVITY_WITHOUT_ZONE = "select new gov.hhs.cms.fps.model.PortalTrackingResult(actvtyPageName, count(*))  from FpsPortalActvtyHstry where  audtInsrtTs > :thedate group by actvtyPageName";
	public final String ACTIVITY_WITH_ZONE = "select new gov.hhs.cms.fps.model.PortalTrackingResult(actvtyPageName, userZnCd, count(*))    from FpsPortalActvtyHstry where audtInsrtTs > :thedate group by actvtyPageName, userZnCd";

	@Override
	@Transactional
	public void logTracking(FpsPortalActvtyHstry h) {
		getCurrentSession().save(h);
		
	}

	@Override
	@Transactional
	public void logSearch(FpsPortalSrchHstry h) {
		getCurrentSession().save(h);
		
	}
	@Override
	public List<PortalTrackingResult> getSearchHistory(boolean withZone) {
		return getSearchHistory(withZone, null);
	}
	@Override
	public List<PortalTrackingResult> getSearchHistory(boolean withZone, Date thedate) {
		//Criteria baseCriteria = getCurrentSession().createCriteria(FpsPortalSrchHstry.class, "s");
		String sql = withZone ? SEARCH_WITH_ZONE : SEARCH_WITHOUT_ZONE;
		Query c = getCurrentSession().createQuery(sql);
		if (thedate == null){
			// defaulting to prior to FPS
			DateTime dt = new DateTime(2000, 1, 1, 0, 0);
			thedate = dt.toDate();
		}
		c.setDate("thedate", thedate);
		return c.list();
	}
	
	@Override
	public List<PortalTrackingResult> getActivityHistory(boolean withZone) {
		// TODO Auto-generated method stub
		String sql = withZone ? ACTIVITY_WITH_ZONE : ACTIVITY_WITHOUT_ZONE;
		return getCurrentSession().createQuery(sql).list();
	}
	@Override
	public List<PortalTrackingResult> getActivityHistory(boolean withZone, Date thedate) {
		// TODO Auto-generated method stub
		String sql = withZone ? ACTIVITY_WITH_ZONE : ACTIVITY_WITHOUT_ZONE;
		Query c = getCurrentSession().createQuery(sql);
		if (thedate == null){
			// defaulting to prior to FPS
			DateTime dt = new DateTime(2000, 1, 1, 0, 0);
			thedate = dt.toDate();
		}
		c.setDate("thedate", thedate);
		return c.list();	}
	@Override
	public FpsUsrGuiPrfrnc saveUserPrefs(FpsUserPreference request) {
		FpsUsrGuiPrfrnc dbPref = loadUserPrefs(request.getUserId(), request.getPrefName(), request.getPrefLbl());
		if (dbPref == null){
			dbPref = new FpsUsrGuiPrfrnc();
			dbPref.setUsrId(request.getUserId());			
			dbPref.setAudtInsrtTs(new Date());
			dbPref.setAudtInsrtId(request.getUserId());
			dbPref.setPrfrncGrp(request.getPrefName());
			dbPref.setPrfrncNm(FpsDomainObjectConverter.clean(request.getPrefLbl()));

		}
		dbPref.setPrfrncOptions(request.getPrefJson());
		dbPref.setAudtUpdtTs(new Date());
		dbPref.setAudtUpdtId(request.getUserId());
		getCurrentSession().saveOrUpdate(dbPref);
		return dbPref;
		
	}
	@Override
	public void clearUserPrefs(String userId, String prefName) {
		FpsUsrGuiPrfrnc dbPref = loadUserPrefs(userId, prefName);
		if (dbPref != null){
			getCurrentSession().delete(dbPref);
		}
		
	}
	@Override
	public FpsUsrGuiPrfrnc loadUserPrefs(String userId, String prefName, String prefLbl) {
		
				
		Criteria c = getCurrentSession().createCriteria(FpsUsrGuiPrfrnc.class, "pref")
		.add(Restrictions.eq("usrId", userId))
		.add(Restrictions.eq("prfrncGrp", prefName));
		if (prefLbl != null) {
			c.add(Restrictions.eq("prfrncNm", prefLbl));

		}
		
		FpsUsrGuiPrfrnc results = (FpsUsrGuiPrfrnc)c.uniqueResult();
		return results;

		
	}
	@Override
	public FpsUsrGuiPrfrnc loadUserPrefs(String userId, String prefName) {
		return loadUserPrefs(userId, prefName, null);

		
	}
	@Override
	public FpsUsrGuiPrfrnc loadUserPrefs(Integer listId) {
		FpsUsrGuiPrfrnc results = (FpsUsrGuiPrfrnc)getCurrentSession().createCriteria(FpsUsrGuiPrfrnc.class, "pref")
		.add(Restrictions.eq("usrGuiPrfrncId", listId)).uniqueResult();
		return results;

		
	}



}
