package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrPrioritizeItem implements Serializable{
	private String asrId;
	private Integer asrDbId;
	private String userId;
	private String zone;
	private String comments;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy/MM/dd", timezone="America/New_York")
	private Date addedDt;
	private String cmsPriorityAsrInd;
	private Integer listItemId;
	private List<AsrPrioritizationModelItem> asrPrioritizationModelItems;
	private String source;
	private String modelList;
	private String programType;
	private String state;
	// -- model name
	// -- model run dt
	public String getAsrId() {
		return asrId;
	}
	public void setAsrId(String asrId) {
		this.asrId = asrId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Integer getAsrDbId() {
		return asrDbId;
	}
	public void setAsrDbId(Integer asrDbId) {
		this.asrDbId = asrDbId;
	}
	public Date getAddedDt() {
		return addedDt;
	}
	public void setAddedDt(Date addedDt) {
		this.addedDt = addedDt;
	}
	@Override
	public String toString() {
		return "{\"" + (asrId != null ? "asrId\":\"" + asrId + "\", \"" : "")
				+ (asrDbId != null ? "asrDbId\":\"" + asrDbId + "\", \"" : "")
				+ (userId != null ? "userId\":\"" + userId + "\", \"" : "")
				+ (zone != null ? "zone\":\"" + zone + "\", \"" : "")
				+ (comments != null ? "comments\":\"" + comments + "\", \"" : "")
				+ (addedDt != null ? "addedDt\":\"" + addedDt + "\", \"" : "")
				+ (cmsPriorityAsrInd != null ? "cmsPriorityAsrInd\":\"" + cmsPriorityAsrInd + "\", \"" : "")
				+ (listItemId != null ? "listItemId\":\"" + listItemId + "\", \"" : "")
				+ (asrPrioritizationModelItems != null
						? "asrPrioritizationModelItems\":\"" + asrPrioritizationModelItems + "\", \""
						: "")
				+ (source != null ? "source\":\"" + source + "\", \"" : "")
				+ (modelList != null ? "modelList\":\"" + modelList + "\", \"" : "")
				+ (programType != null ? "programType\":\"" + programType : "") + "\"}";
	}
	public String getCmsPriorityAsrInd() {
		return cmsPriorityAsrInd;
	}
	public void setCmsPriorityAsrInd(String cmsPriorityAsrInd) {
		this.cmsPriorityAsrInd = cmsPriorityAsrInd;
	}
	public Integer getListItemId() {
		return listItemId;
	}
	public void setListItemId(Integer listItemId) {
		this.listItemId = listItemId;
	}
	public List<AsrPrioritizationModelItem> getAsrPrioritizationModelItems() {
		return asrPrioritizationModelItems;
	}
	public void setAsrPrioritizationModelItems(List<AsrPrioritizationModelItem> asrPrioritizationModelItems) {
		this.asrPrioritizationModelItems = asrPrioritizationModelItems;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getModelList() {
		return modelList;
	}
	public void setModelList(String modelList) {
		this.modelList = modelList;
	}
	
	public String getProgramType() {
		return programType;
	}
	public void setProgramType(String programType) {
		this.programType = programType;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	

}
