package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonFormat;
@JsonIgnoreProperties(ignoreUnknown = true)
@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@org.codehaus.jackson.annotate.JsonAutoDetect(fieldVisibility = org.codehaus.jackson.annotate.JsonAutoDetect.Visibility.ANY, getterVisibility = org.codehaus.jackson.annotate.JsonAutoDetect.Visibility.NONE, setterVisibility = org.codehaus.jackson.annotate.JsonAutoDetect.Visibility.NONE)

public class UcmMedicalReview implements Serializable {

	private String mrRecordNumber;
	private String mrRecordType;
	private String programType;
	private String benefitType;
	private String status;
	private String subStatus;
	private String npi;
	private String parentRecordId;
	//@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd hh:mm:ss.SSSX", timezone="America/New_York")

	private String openDate;
//	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd hh:mm:ss.SSSX", timezone="America/New_York")
	private String closeDate;
//	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd hh:mm:ss.SSSX", timezone="America/New_York")
	private String cancelledDate;
	private BigDecimal denialRate;
	private List<String> denialCodes;
	private List<String> technicalDenials;
	private UcmModelContribution modelContribution;
	public String getMrRecordNumber() {
		return mrRecordNumber;
	}
	public void setMrRecordNumber(String mrRecordNumber) {
		this.mrRecordNumber = mrRecordNumber;
	}
	public String getMrRecordType() {
		return mrRecordType;
	}
	public void setMrRecordType(String mrRecordType) {
		this.mrRecordType = mrRecordType;
	}
	public String getProgramType() {
		return programType;
	}
	public void setProgramType(String programType) {
		this.programType = programType;
	}
	public String getBenefitType() {
		return benefitType;
	}
	public void setBenefitType(String benefitType) {
		this.benefitType = benefitType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSubStatus() {
		return subStatus;
	}
	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}
	public String getNpi() {
		return npi;
	}
	public void setNpi(String npi) {
		this.npi = npi;
	}
	public String getParentRecordId() {
		return parentRecordId;
	}
	public void setParentRecordId(String parentRecordId) {
		this.parentRecordId = parentRecordId;
	}
	public String getOpenDate() {
		return openDate;
	}
	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}
	public String getCloseDate() {
		return closeDate;
	}
	public void setCloseDate(String closeDate) {
		this.closeDate = closeDate;
	}
	public String getCancelledDate() {
		return cancelledDate;
	}
	public void setCancelledDate(String cancelledDate) {
		this.cancelledDate = cancelledDate;
	}
	public BigDecimal getDenialRate() {
		return denialRate;
	}
	public void setDenialRate(BigDecimal denialRate) {
		this.denialRate = denialRate;
	}
	public List<String> getDenialCodes() {
		return denialCodes;
	}
	public void setDenialCodes(List<String> denialCodes) {
		this.denialCodes = denialCodes;
	}
	public List<String> getTechnicalDenials() {
		return technicalDenials;
	}
	public void setTechnicalDenials(List<String> technicalDenials) {
		this.technicalDenials = technicalDenials;
	}
	public UcmModelContribution getModelContribution() {
		return modelContribution;
	}
	public void setModelContribution(UcmModelContribution modelContribution) {
		this.modelContribution = modelContribution;
	}
	@Override
	public String toString() {
		return "UcmMedicalReview [" + (mrRecordNumber != null ? "mrRecordNumber=" + mrRecordNumber + ", " : "")
				+ (mrRecordType != null ? "mrRecordType=" + mrRecordType + ", " : "")
				+ (programType != null ? "programType=" + programType + ", " : "")
				+ (benefitType != null ? "benefitType=" + benefitType + ", " : "")
				+ (status != null ? "status=" + status + ", " : "")
				+ (subStatus != null ? "subStatus=" + subStatus + ", " : "") + (npi != null ? "npi=" + npi + ", " : "")
				+ (parentRecordId != null ? "parentRecordId=" + parentRecordId + ", " : "")
				+ (openDate != null ? "openDate=" + openDate + ", " : "")
				+ (closeDate != null ? "closeDate=" + closeDate + ", " : "")
				+ (cancelledDate != null ? "cancelledDate=" + cancelledDate + ", " : "")
				+ (denialRate != null ? "denialRate=" + denialRate + ", " : "")
				+ (denialCodes != null ? "denialCodes=" + denialCodes + ", " : "")
				+ (technicalDenials != null ? "technicalDenials=" + technicalDenials + ", " : "")
				+ (modelContribution != null ? "modelContribution=" + modelContribution : "") + "]";
	}
	

}
