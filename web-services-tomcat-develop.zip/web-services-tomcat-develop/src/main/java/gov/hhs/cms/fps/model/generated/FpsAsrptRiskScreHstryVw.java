package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="FPS_ASRPT_RISK_SCRE_HSTRY_VW_RPT_VW")
public class FpsAsrptRiskScreHstryVw implements Serializable {

	private int asrptId;
	private String subjId;
	private String cntrctCd;
	private Date riskScreHstryDt;
	private BigDecimal asrptRiskScreNum;
	private BigDecimal priorScore;
	private BigDecimal deltaScore;
	private BigDecimal zoneAverageScore;
	private FpsAsrpt fpsAsrpt;
	
	@Id
	@Column(name="ASRPT_ID")
	public int getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(int asrptId) {
		this.asrptId = asrptId;
	}
	@Column(name="SUBJ_ID")
	public String getSubjId() {
		return subjId;
	}
	public void setSubjId(String subjId) {
		this.subjId = subjId;
	}
	@Column(name="CNTRCTR_CD")
	public String getCntrctCd() {
		return cntrctCd;
	}
	public void setCntrctCd(String cntrctCd) {
		this.cntrctCd = cntrctCd;
	}
	@Id
	@Column(name="RISK_SCRE_HSTRY_DT")
	public Date getRiskScreHstryDt() {
		return riskScreHstryDt;
	}
	public void setRiskScreHstryDt(Date riskScreHstryDt) {
		this.riskScreHstryDt = riskScreHstryDt;
	}
	@Column(name="ASRPT_RISK_SCRE_NUM")
	public BigDecimal getAsrptRiskScreNum() {
		return asrptRiskScreNum;
	}
	public void setAsrptRiskScreNum(BigDecimal asrptRiskScreNum) {
		this.asrptRiskScreNum = asrptRiskScreNum;
	}
	@Column(name="PRIOR_SCORE")
	public BigDecimal getPriorScore() {
		return priorScore;
	}
	public void setPriorScore(BigDecimal priorScore) {
		this.priorScore = priorScore;
	}
	@Column(name="DELTA_SCORE")
	public BigDecimal getDeltaScore() {
		return deltaScore;
	}
	public void setDeltaScore(BigDecimal deltaScore) {
		this.deltaScore = deltaScore;
	}
	@Column(name="ZONE_AVERAGE_SCORE")
	public BigDecimal getZoneAverageScore() {
		return zoneAverageScore;
	}

	public void setZoneAverageScore(BigDecimal zoneAverageScore) {
		this.zoneAverageScore = zoneAverageScore;
	}
	@ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="ASRPT_ID", referencedColumnName="ASRPT_ID", updatable=false, insertable=false)
	public FpsAsrpt getFpsAsrpt() {
		return fpsAsrpt;
	}
	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
		this.fpsAsrpt = fpsAsrpt;
	}
}
