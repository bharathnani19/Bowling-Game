package gov.hhs.cms.fps.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class JsonpAdvice {//extends AbstractJsonpResponseBodyAdvice {
    public JsonpAdvice() {
        //super("callback");
    }
} 