package gov.hhs.cms.fps.model;

import java.util.ArrayList;
import java.util.List;

public class ModelCategory {

	private String cat;
	private String pgm;
	private List<AsrGenericCode> subcats = new ArrayList<AsrGenericCode>();
	
	public ModelCategory(String cat) {
		this.cat = cat;
	}
	public ModelCategory(String cat,List<AsrGenericCode> subcats) {
		this.cat = cat;
		this.subcats = subcats;
	}
	public ModelCategory(String cat,List<AsrGenericCode> subcats, String pgm) {
		this.cat = cat;
		this.subcats = subcats;
		this.pgm = pgm;
	}
	public String getCat() {
		return cat;
	}
	public void setCat(String cat) {
		this.cat = cat;
	}
	public List<AsrGenericCode> getSubcats() {
		return subcats;
	}
	public void setSubcats(List<AsrGenericCode> subcats) {
		this.subcats = subcats;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cat == null) ? 0 : cat.hashCode());
		result = prime * result + ((pgm == null) ? 0 : pgm.hashCode());
		result = prime * result + ((subcats == null) ? 0 : subcats.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ModelCategory other = (ModelCategory) obj;
		if (cat == null) {
			if (other.cat != null)
				return false;
		} else if (!cat.equals(other.cat))
			return false;
		if (pgm == null) {
			if (other.pgm != null)
				return false;
		} else if (!pgm.equals(other.pgm))
			return false;
		if (subcats == null) {
			if (other.subcats != null)
				return false;
		} else if (!subcats.equals(other.subcats))
			return false;
		return true;
	}
	public String getPgm() {
		return pgm;
	}
	public void setPgm(String pgm) {
		this.pgm = pgm;
	}
}
