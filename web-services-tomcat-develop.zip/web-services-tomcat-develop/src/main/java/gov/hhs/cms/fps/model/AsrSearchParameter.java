package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
@JsonInclude(Include.ALWAYS)
public class AsrSearchParameter extends BaseSearchParameter implements Serializable {
	private static final long serialVersionUID = 2319175572547218103L;
	private String customClaimLineLevel;
	private String customClaimLineLevelParam;
	private String presetSearchFlag;
	
	private String assignedZone;
	private boolean export;
	@Deprecated
	private String assignedToUserId;
	
	private String createdMinDt;
	private String createdMaxDt;
	private String costSortDir;
	private String barrierToActionInd;
	private List<AsrDetailModel> models;

	private String loggedInUserId;
	
	private List<AsrRuling> rulings;
	@Deprecated
	private Double legacyScoreHigh;
	@Deprecated
	private Double legacyScoreLow;
	@Deprecated
	private String assignedToFName;
	@Deprecated
	private String assignedToLName;
	private List<AsrAction> actions;
	private List<AsrActivity> activities;
	private List<AsrSysTagItem> sysTags;
	private List<AsrSummaryBarrier> barriers;
	@Deprecated
	private String assigned;
	private String prioritized;
	private List<AsrGenericCode> jurisdictions;
	private List<AsrGenericCode> atRiskJrsdctns;
	private String modelPriority;

	private List<AsrGenericCode> cityStates;


	@JsonIgnore
	private boolean fps2Only;
	private String myZoneOnlyInd;
	
	
	// provider analysis fields
	private String ucmCaseId;
	private String apsInd;
	private String partDInd;
	private List<AsrGenericCode> edits;
	private String ucmAsrId;
	private List<AsrSummaryClaimType> claimTypes;
	private List<AsrGenericCode> zrTypes;
	private List<AsrGenericCode> exclusions;
	private String revokedInd;
	private List<AsrState> states;
	private List<AsrAlertStatus> alertStatus;
	private Double priorityScoreHigh;
	private Double priorityScoreLow;
	private List<AsrGenericCode> leadInvestigationInd;
	private Double riskScoreHigh;
	private Double riskScoreLow;
	private List<AsrAlertType> alerts;
	private String asrptId;
	private String subjectJurisdiction;
	private String prvdrName;
	private List<AsrGenericCode> actionability;
	private Integer timelinessLow;
	private Integer timelinessHigh;
	private String lastEduDtHigh;
	private String lastEduDtLow;
	private String inappBillInd;
	private String medicaidInd;
	private List<AsrGenericCode> prioritizeTypes;
	private Integer asrCostHigh;
	private Integer asrCostLow;
	private Integer atRiskCostHigh;
	private Integer atRiskCostLow;
	private Integer beneCntHigh;
	private Integer beneCntLow;
	private Integer clmCntHigh;
	private Integer clmCntLow;
	private Double sbmtAmtHigh;
	private Double sbmtAmtLow;
	private Double sbmtAmtDHigh;
	private Double sbmtAmtDLow;
	private Double totalPymtHigh;
	private Double totalPymtLow;
	private Double totalPymtDHigh;
	private Double totalPymtDLow;
	private String firstClmDtHigh;
	private String firstClmDtLow;
	private String lastClmDtHigh;
	private String lastClmDtLow;
	private String prvdrCity;
	private List<AsrGenericCode> enrollStatus;
	private List<AsrGenericCode> macIds;
	private List<AsrGenericCode> cncs;
	private String ucmClosedDtHigh;
	private String ucmClosedDtLow;
	private String leadInd;
	private String biuInd;
	private String biu90Ind;
	private String exclusionOrInd;
	private String exclusionMyZoneInd;
	private Integer editId;
	private String enrollmentId;
	private String lastAlertSvcDtHigh;
	private String lastAlertSvcDtLow;
	private String zrId;
	private String searchType;
	private String lastTpeEduDtHigh;
	private String lastTpeEduDtLow;
	
	private Integer biuCnt;
	private Integer biuDays;
	
	private List<AsrGenericCode> asrWorkingSetInd;
	private List<AsrGenericCode> asrExclSetInd;
	private List<Object> asrptIds;
	private List<AsrGenericCode> specialtyCds;
	private String dualBeneInd;
	private String programType = "medicare";
	// medicaid
	private List<AsrGenericCode> mdcdSvcCats;
	private List<AsrGenericCode> mdcdSvcTypes;
	private List<AsrGenericCode> mdcdSvcSubCats;
	private List<Object> billingNpis;

	private List<AsrGenericCode> mdcdRoles;
	
	private String pathToEduInd;
	private String acoInd;
	private String modelRunDt;

	// phase 1
	private List<AsrGenericCode> p1Jurisdictions;
	private String p1LastAlertSvcDtHigh;
	private String p1LastAlertSvcDtLow;
	private Integer p1AsrCostHigh;
	private Integer p1AsrCostLow;
	private List<AsrAlertStatus> p1AlertStatus;
	private List<AsrAlertType> p1Alerts;


	public String getMyZoneOnlyInd() {
		return myZoneOnlyInd;
	}

	public void setMyZoneOnlyInd(String myZoneOnlyInd) {
		this.myZoneOnlyInd = myZoneOnlyInd;
	}

	

	@Override
	public String toString() {
		return "{\""
				+ (customClaimLineLevel != null ? "customClaimLineLevel\":\"" + customClaimLineLevel + "\", \"" : "")
				+ (customClaimLineLevelParam != null
						? "customClaimLineLevelParam\":\"" + customClaimLineLevelParam + "\", \""
						: "")
				+ (presetSearchFlag != null ? "presetSearchFlag\":\"" + presetSearchFlag + "\", \"" : "")
				+ (assignedZone != null ? "assignedZone\":\"" + assignedZone + "\", \"" : "")
				+ (createdMinDt != null ? "createdMinDt\":\"" + createdMinDt + "\", \"" : "")
				+ (createdMaxDt != null ? "createdMaxDt\":\"" + createdMaxDt + "\", \"" : "")
				+ (costSortDir != null ? "costSortDir\":\"" + costSortDir + "\", \"" : "")
				+ (barrierToActionInd != null ? "barrierToActionInd\":\"" + barrierToActionInd + "\", \"" : "")
				+ (models != null ? "models\":\"" + models + "\", \"" : "")
				+ (loggedInUserId != null ? "loggedInUserId\":\"" + loggedInUserId + "\", \"" : "")
				+ (rulings != null ? "rulings\":\"" + rulings + "\", \"" : "")
				+ (actions != null ? "actions\":\"" + actions + "\", \"" : "")
				+ (activities != null ? "activities\":\"" + activities + "\", \"" : "")
				+ (sysTags != null ? "sysTags\":\"" + sysTags + "\", \"" : "")
				+ (barriers != null ? "barriers\":\"" + barriers + "\", \"" : "")
				+ (prioritized != null ? "prioritized\":\"" + prioritized + "\", \"" : "")
				+ (jurisdictions != null ? "jurisdictions\":\"" + jurisdictions + "\", \"" : "")
				+ (modelPriority != null ? "modelPriority\":\"" + modelPriority + "\", \"" : "")
				+ (cityStates != null ? "cityStates\":\"" + cityStates + "\", \"" : "")
				+ (myZoneOnlyInd != null && leadInvestigationInd != null ? "myZoneOnlyInd\":\"" + myZoneOnlyInd + "\", \"" : "")
				+ (ucmCaseId != null ? "ucmCaseId\":\"" + ucmCaseId + "\", \"" : "")
				+ (apsInd != null ? "apsInd\":\"" + apsInd + "\", \"" : "")
				+ (partDInd != null ? "partDInd\":\"" + partDInd + "\", \"" : "")
				+ (edits != null ? "edits\":\"" + edits + "\", \"" : "")
				+ (ucmAsrId != null ? "ucmAsrId\":\"" + ucmAsrId + "\", \"" : "")
				+ (claimTypes != null ? "claimTypes\":\"" + claimTypes + "\", \"" : "")
				+ (zrTypes != null ? "zrTypes\":\"" + zrTypes + "\", \"" : "")
				+ (exclusions != null ? "exclusions\":\"" + exclusions + "\", \"" : "")
				+ (acoInd != null ? "acoInd\":\"" + acoInd + "\", \"" : "")
				+ (revokedInd != null ? "revokedInd\":\"" + revokedInd + "\", \"" : "")
				+ (states != null ? "states\":\"" + states + "\", \"" : "")
				+ (alertStatus != null ? "alertStatus\":\"" + alertStatus + "\", \"" : "")
				+ (priorityScoreHigh != null ? "priorityScoreHigh\":\"" + priorityScoreHigh + "\", \"" : "")
				+ (priorityScoreLow != null ? "priorityScoreLow\":\"" + priorityScoreLow + "\", \"" : "")
				+ (leadInvestigationInd != null ? "leadInvestigationInd\":\"" + leadInvestigationInd + "\", \"" : "")
				+ (riskScoreHigh != null ? "riskScoreHigh\":\"" + riskScoreHigh + "\", \"" : "")
				+ (riskScoreLow != null ? "riskScoreLow\":\"" + riskScoreLow + "\", \"" : "")
				+ (alerts != null ? "alerts\":\"" + alerts + "\", \"" : "")
				+ (asrptId != null ? "asrptId\":\"" + asrptId + "\", \"" : "")
				+ (subjectJurisdiction != null ? "subjectJurisdiction\":\"" + subjectJurisdiction + "\", \"" : "")
				+ (prvdrName != null ? "prvdrName\":\"" + prvdrName + "\", \"" : "")
				+ (actionability != null ? "actionability\":\"" + actionability + "\", \"" : "")
				+ (timelinessLow != null ? "timelinessLow\":\"" + timelinessLow + "\", \"" : "")
				+ (timelinessHigh != null ? "timelinessHigh\":\"" + timelinessHigh + "\", \"" : "")
				+ (lastEduDtHigh != null ? "lastEduDtHigh\":\"" + lastEduDtHigh + "\", \"" : "")
				+ (lastEduDtLow != null ? "lastEduDtLow\":\"" + lastEduDtLow + "\", \"" : "")
				+ (inappBillInd != null ? "inappBillInd\":\"" + inappBillInd + "\", \"" : "")
				+ (medicaidInd != null ? "medicaidInd\":\"" + medicaidInd + "\", \"" : "")
				+ (prioritizeTypes != null ? "prioritizeTypes\":\"" + prioritizeTypes + "\", \"" : "")
				+ (asrCostHigh != null ? "asrCostHigh\":\"" + asrCostHigh + "\", \"" : "")
				+ (asrCostLow != null ? "asrCostLow\":\"" + asrCostLow + "\", \"" : "")
				+ (beneCntHigh != null ? "beneCntHigh\":\"" + beneCntHigh + "\", \"" : "")
				+ (beneCntLow != null ? "beneCntLow\":\"" + beneCntLow + "\", \"" : "")
				+ (clmCntHigh != null ? "clmCntHigh\":\"" + clmCntHigh + "\", \"" : "")
				+ (clmCntLow != null ? "clmCntLow\":\"" + clmCntLow + "\", \"" : "")
				+ (sbmtAmtHigh != null ? "sbmtAmtHigh\":\"" + sbmtAmtHigh + "\", \"" : "")
				+ (sbmtAmtLow != null ? "sbmtAmtLow\":\"" + sbmtAmtLow + "\", \"" : "")
				+ (sbmtAmtDHigh != null ? "sbmtAmtDHigh\":\"" + sbmtAmtDHigh + "\", \"" : "")
				+ (sbmtAmtDLow != null ? "sbmtAmtDLow\":\"" + sbmtAmtDLow + "\", \"" : "")
				+ (totalPymtHigh != null ? "totalPymtHigh\":\"" + totalPymtHigh + "\", \"" : "")
				+ (totalPymtLow != null ? "totalPymtLow\":\"" + totalPymtLow + "\", \"" : "")
				+ (totalPymtDHigh != null ? "totalPymtDHigh\":\"" + totalPymtDHigh + "\", \"" : "")
				+ (totalPymtDLow != null ? "totalPymtDLow\":\"" + totalPymtDLow + "\", \"" : "")
				+ (firstClmDtHigh != null ? "firstClmDtHigh\":\"" + firstClmDtHigh + "\", \"" : "")
				+ (firstClmDtLow != null ? "firstClmDtLow\":\"" + firstClmDtLow + "\", \"" : "")
				+ (lastClmDtHigh != null ? "lastClmDtHigh\":\"" + lastClmDtHigh + "\", \"" : "")
				+ (lastClmDtLow != null ? "lastClmDtLow\":\"" + lastClmDtLow + "\", \"" : "")
				+ (prvdrCity != null ? "prvdrCity\":\"" + prvdrCity + "\", \"" : "")
				+ (enrollStatus != null ? "enrollStatus\":\"" + enrollStatus + "\", \"" : "")
				+ (macIds != null ? "macIds\":\"" + macIds + "\", \"" : "")
				+ (cncs != null ? "cncs\":\"" + cncs + "\", \"" : "")
				+ (ucmClosedDtHigh != null ? "ucmClosedDtHigh\":\"" + ucmClosedDtHigh + "\", \"" : "")
				+ (ucmClosedDtLow != null ? "ucmClosedDtLow\":\"" + ucmClosedDtLow + "\", \"" : "")
				+ (leadInd != null ? "leadInd\":\"" + leadInd + "\", \"" : "")
				+ (biuInd != null ? "biuInd\":\"" + biuInd + "\", \"" : "")
				+ (biu90Ind != null ? "biu90Ind\":\"" + biu90Ind + "\", \"" : "")
				+ (exclusionOrInd != null ? "exclusionOrInd\":\"" + exclusionOrInd + "\", \"" : "")
				+ (exclusionMyZoneInd != null ? "exclusionMyZoneInd\":\"" + exclusionMyZoneInd + "\", \"" : "")
				+ (editId != null ? "editId\":\"" + editId + "\", \"" : "")
				+ (enrollmentId != null ? "enrollmentId\":\"" + enrollmentId + "\", \"" : "")
				+ (lastAlertSvcDtHigh != null ? "lastAlertSvcDtHigh\":\"" + lastAlertSvcDtHigh + "\", \"" : "")
				+ (lastAlertSvcDtLow != null ? "lastAlertSvcDtLow\":\"" + lastAlertSvcDtLow + "\", \"" : "")
				+ (zrId != null ? "zrId\":\"" + zrId + "\", \"" : "")
				+ (searchType != null ? "searchType\":\"" + searchType + "\", \"" : "")
				+ (lastTpeEduDtHigh != null ? "lastTpeEduDtHigh\":\"" + lastTpeEduDtHigh + "\", \"" : "")
				+ (lastTpeEduDtLow != null ? "lastTpeEduDtLow\":\"" + lastTpeEduDtLow + "\", \"" : "")
				+ (biuCnt != null ? "biuCnt\":\"" + biuCnt + "\", \"" : "")
				+ (biuDays != null ? "biuDays\":\"" + biuDays + "\", \"" : "")
				+ (asrWorkingSetInd != null ? "asrWorkingSetInd\":\"" + asrWorkingSetInd + "\", \"" : "")
				+ (asrExclSetInd != null ? "asrExclSetInd\":\"" + asrExclSetInd + "\", \"" : "")
				+ (asrptIds != null ? "asrptIds\":\"" + asrptIds + "\", \"" : "")
				+ (specialtyCds != null ? "specialtyCds\":\"" + specialtyCds + "\", \"" : "")
				+ (dualBeneInd != null ? "dualBeneInd\":\"" + dualBeneInd + "\", \"" : "")
				+ (programType != null ? "programType\":\"" + programType + "\", \"" : "")
				+ (mdcdSvcCats != null ? "mdcdSvcCats\":\"" + mdcdSvcCats + "\", \"" : "")
				+ (mdcdSvcTypes != null ? "mdcdSvcTypes\":\"" + mdcdSvcTypes + "\", \"" : "")
				+ (mdcdSvcSubCats != null ? "mdcdSvcSubCats\":\"" + mdcdSvcSubCats + "\", \"" : "")
				+ (pathToEduInd != null ? "pathToEduInd\":\"" + pathToEduInd + "\", \"" : "")
				+ (modelRunDt != null ? "modelRunDt\":\"" + modelRunDt + "\", \"" : "")
				+ (billingNpis != null ? "billingNpis\":\"" + billingNpis + "\", \"" : "")
				+ (p1AlertStatus != null ? "p1AlertStatus\":\"" + p1AlertStatus + "\", \"" : "")
				+ (p1Alerts != null ? "p1Alerts\":\"" + p1Alerts + "\", \"" : "")
				+ (p1AsrCostHigh != null ? "p1AsrCostHigh\":\"" + p1AsrCostHigh + "\", \"" : "")
				+ (p1AsrCostLow != null ? "p1AsrCostLow\":\"" + p1AsrCostLow + "\", \"" : "")
				+ (atRiskCostHigh != null ? "atRiskCostHigh\":\"" + atRiskCostHigh + "\", \"" : "")
				+ (atRiskCostLow != null ? "atRiskCostLow\":\"" + atRiskCostLow + "\", \"" : "")
				+ (p1Jurisdictions != null ? "p1Jurisdictions\":\"" + p1Jurisdictions + "\", \"" : "")
				+ (atRiskJrsdctns != null ? "atRiskJrsdctns\":\"" + atRiskJrsdctns + "\", \"" : "")
				+ (p1LastAlertSvcDtHigh != null ? "p1LastAlertSvcDtHigh\":\"" + p1LastAlertSvcDtHigh + "\", \"" : "")
				+ (p1LastAlertSvcDtLow != null ? "p1LastAlertSvcDtLow\":\"" + p1LastAlertSvcDtLow + "\", \"" : "")
				+ (mdcdRoles != null ? "mdcdRoles\":\"" + mdcdRoles : "") + "\"}";
	}

	public List<AsrAlertStatus> getAlertStatus() {
		return this.alertStatus;
	}

	public void setAlertStatus(List<AsrAlertStatus> alertStatus) {
		this.alertStatus = alertStatus;
	}

	public String getAsrptId() {
		return this.asrptId;
	}

	public void setAsrptId(String asrptId) {
		this.asrptId = asrptId;
	}

	public String getPrvdrName() {
		return this.prvdrName;
	}

	public void setPrvdrName(String prvdrName) {
		this.prvdrName = prvdrName;
	}

	public String getCreatedMinDt() {
		return this.createdMinDt;
	}

	public void setCreatedMinDt(String createdMinDt) {
		this.createdMinDt = createdMinDt;
	}

	public String getCreatedMaxDt() {
		return this.createdMaxDt;
	}

	public void setCreatedMaxDt(String createdMaxDt) {
		this.createdMaxDt = createdMaxDt;
	}

	public String getCustomClaimLineLevel() {
		return this.customClaimLineLevel;
	}

	public void setCustomClaimLineLevel(String customClaimLineLevel) {
		this.customClaimLineLevel = customClaimLineLevel;
	}

	public String getCustomClaimLineLevelParam() {
		return this.customClaimLineLevelParam;
	}

	public void setCustomClaimLineLevelParam(String customClaimLineLevelParam) {
		this.customClaimLineLevelParam = customClaimLineLevelParam;
	}

	public String getPresetSearchFlag() {
		return this.presetSearchFlag;
	}

	public void setPresetSearchFlag(String presetSearchFlag) {
		this.presetSearchFlag = presetSearchFlag;
	}

	public String getSubjectJurisdiction() {
		return this.subjectJurisdiction;
	}

	public void setSubjectJurisdiction(String subjectJurisdiction) {
		this.subjectJurisdiction = subjectJurisdiction;
	}

	public String getAssignedToUserId() {
		return this.assignedToUserId;
	}

	public void setAssignedToUserId(String assignedToUserId) {
		this.assignedToUserId = assignedToUserId;
	}

	public String getCostSortDir() {
		return this.costSortDir;
	}

	public void setCostSortDir(String costSortDir) {
		this.costSortDir = costSortDir;
	}

	public String getBarrierToActionInd() {
		return this.barrierToActionInd;
	}

	public void setBarrierToActionInd(String barrierToActionInd) {
		this.barrierToActionInd = barrierToActionInd;
	}

	public String getLoggedInUserId() {
		return this.loggedInUserId;
	}

	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}

	public List<AsrDetailModel> getModels() {
		return this.models;
	}

	public void setModels(List<AsrDetailModel> models) {
		this.models = models;
	}

	public List<AsrAlertType> getAlerts() {
		return this.alerts;
	}

	public void setAlerts(List<AsrAlertType> alerts) {
		this.alerts = alerts;
	}

	public String getAssignedZone() {
		return this.assignedZone;
	}

	public void setAssignedZone(String assignedZone) {
		this.assignedZone = assignedZone;
	}

	public List<AsrGenericCode> getLeadInvestigationInd() {
		return this.leadInvestigationInd;
	}

	public void setLeadInvestigationInd(List<AsrGenericCode> leadInvestigationInd) {
		this.leadInvestigationInd = leadInvestigationInd;
	}

	public Double getRiskScoreHigh() {
		return this.riskScoreHigh;
	}

	public void setRiskScoreHigh(Double riskScoreHigh) {
		this.riskScoreHigh = riskScoreHigh;
	}

	public Double getLegacyScoreHigh() {
		return this.legacyScoreHigh;
	}

	public void setLegacyScoreHigh(Double legacyScoreHigh) {
		this.legacyScoreHigh = legacyScoreHigh;
	}

	public List<AsrAction> getActions() {
		return this.actions;
	}

	public void setActions(List<AsrAction> actions) {
		this.actions = actions;
	}

	public List<AsrActivity> getActivities() {
		return this.activities;
	}

	public void setActivities(List<AsrActivity> activities) {
		this.activities = activities;
	}

	public Double getRiskScoreLow() {
		return this.riskScoreLow;
	}

	public void setRiskScoreLow(Double riskScoreLow) {
		this.riskScoreLow = riskScoreLow;
	}

	public Double getLegacyScoreLow() {
		return this.legacyScoreLow;
	}

	public void setLegacyScoreLow(Double legacyScoreLow) {
		this.legacyScoreLow = legacyScoreLow;
	}

	public String getAssignedToFName() {
		return this.assignedToFName;
	}

	public void setAssignedToFName(String assignedToFName) {
		this.assignedToFName = assignedToFName;
	}

	public String getAssignedToLName() {
		return this.assignedToLName;
	}

	public void setAssignedToLName(String assignedToLName) {
		this.assignedToLName = assignedToLName;
	}

	public List<AsrSysTagItem> getSysTags() {
		return this.sysTags;
	}

	public void setSysTags(List<AsrSysTagItem> sysTags) {
		this.sysTags = sysTags;
	}

	public List<AsrState> getStates() {
		return this.states;
	}

	public void setStates(List<AsrState> states) {
		this.states = states;
	}

	public List<AsrRuling> getRulings() {
		return this.rulings;
	}

	public void setRulings(List<AsrRuling> rulings) {
		this.rulings = rulings;
	}

	public List<AsrSummaryBarrier> getBarriers() {
		return barriers;
	}

	public void setBarriers(List<AsrSummaryBarrier> barriers) {
		this.barriers = barriers;
	}

	public String getAssigned() {
		return assigned;
	}

	public void setAssigned(String assigned) {
		this.assigned = assigned;
	}

	public List<AsrSummaryClaimType> getClaimTypes() {
		return claimTypes;
	}

	public void setClaimTypes(List<AsrSummaryClaimType> claimTypes) {
		this.claimTypes = claimTypes;
	}

	public String getPartDInd() {
		return partDInd;
	}

	public void setPartDInd(String partDInd) {
		this.partDInd = partDInd;
	}

	public String getPrioritized() {
		return prioritized;
	}

	public void setPrioritized(String prioritized) {
		this.prioritized = prioritized;
	}

	public List<AsrGenericCode> getJurisdictions() {
		return jurisdictions;
	}

	public void setJurisdictions(List<AsrGenericCode> jurisdictions) {
		this.jurisdictions = jurisdictions;
	}

	public String getModelPriority() {
		return modelPriority;
	}

	public void setModelPriority(String modelPriority) {
		this.modelPriority = modelPriority;
	}

	public Double getPriorityScoreHigh() {
		return priorityScoreHigh;
	}

	public void setPriorityScoreHigh(Double priorityScoreHigh) {
		this.priorityScoreHigh = priorityScoreHigh;
	}

	public Double getPriorityScoreLow() {
		return priorityScoreLow;
	}

	public void setPriorityScoreLow(Double priorityScoreLow) {
		this.priorityScoreLow = priorityScoreLow;
	}

	public List<AsrGenericCode> getCityStates() {
		return cityStates;
	}

	public void setCityStates(List<AsrGenericCode> cityStates) {
		this.cityStates = cityStates;
	}

	public List<AsrGenericCode> getZrTypes() {
		return zrTypes;
	}

	public void setZrTypes(List<AsrGenericCode> zrTypes) {
		this.zrTypes = zrTypes;
	}

	public List<AsrGenericCode> getEdits() {
		return edits;
	}

	public void setEdits(List<AsrGenericCode> edits) {
		this.edits = edits;
	}

	public String getUcmAsrId() {
		return ucmAsrId;
	}

	public void setUcmAsrId(String ucmAsrId) {
		this.ucmAsrId = ucmAsrId;
	}

	public String getUcmCaseId() {
		return ucmCaseId;
	}

	public void setUcmCaseId(String ucmCaseId) {
		this.ucmCaseId = ucmCaseId;
	}

	public String getEnrollmentId() {
		return enrollmentId;
	}

	public void setEnrollmentId(String enrollmentId) {
		this.enrollmentId = enrollmentId;
	}

	public String getRevokedInd() {
		return revokedInd;
	}

	public void setRevokedInd(String revokedInd) {
		this.revokedInd = revokedInd;
	}

	public boolean isFps2Only() {
		return fps2Only;
	}

	public void setFps2Only(boolean fps2Only) {
		this.fps2Only = fps2Only;
	}

	public boolean isExport() {
		return export;
	}

	public void setExport(boolean export) {
		this.export = export;
	}

	public String getApsInd() {
		return apsInd;
	}

	public void setApsInd(String apsInd) {
		this.apsInd = apsInd;
	}

	public List<AsrGenericCode> getActionability() {
		return actionability;
	}

	public void setActionability(List<AsrGenericCode> actionability) {
		this.actionability = actionability;
	}



	public String getLastEduDtHigh() {
		return lastEduDtHigh;
	}

	public void setLastEduDtHigh(String lastEduDtHigh) {
		this.lastEduDtHigh = lastEduDtHigh;
	}

	public String getLastEduDtLow() {
		return lastEduDtLow;
	}

	public void setLastEduDtLow(String lastEduDtLow) {
		this.lastEduDtLow = lastEduDtLow;
	}

	public String getInappBillInd() {
		return inappBillInd;
	}

	public void setInappBillInd(String inappBillInd) {
		this.inappBillInd = inappBillInd;
	}

	public String getMedicaidInd() {
		return medicaidInd;
	}

	public void setMedicaidInd(String medicaidInd) {
		this.medicaidInd = medicaidInd;
	}

	public Integer getBeneCntHigh() {
		return beneCntHigh;
	}

	public void setBeneCntHigh(Integer beneCntHigh) {
		this.beneCntHigh = beneCntHigh;
	}

	public Integer getBeneCntLow() {
		return beneCntLow;
	}

	public void setBeneCntLow(Integer beneCntLow) {
		this.beneCntLow = beneCntLow;
	}

	public Integer getClmCntHigh() {
		return clmCntHigh;
	}

	public void setClmCntHigh(Integer clmCntHigh) {
		this.clmCntHigh = clmCntHigh;
	}

	public Integer getClmCntLow() {
		return clmCntLow;
	}

	public void setClmCntLow(Integer clmCntLow) {
		this.clmCntLow = clmCntLow;
	}

	public Double getSbmtAmtHigh() {
		return sbmtAmtHigh;
	}

	public void setSbmtAmtHigh(Double sbmtAmtHigh) {
		this.sbmtAmtHigh = sbmtAmtHigh;
	}

	public Double getSbmtAmtLow() {
		return sbmtAmtLow;
	}

	public void setSbmtAmtLow(Double sbmtAmtLow) {
		this.sbmtAmtLow = sbmtAmtLow;
	}

	public Double getTotalPymtHigh() {
		return totalPymtHigh;
	}

	public void setTotalPymtHigh(Double totalPymtHigh) {
		this.totalPymtHigh = totalPymtHigh;
	}

	public Double getTotalPymtLow() {
		return totalPymtLow;
	}

	public void setTotalPymtLow(Double totalPymtLow) {
		this.totalPymtLow = totalPymtLow;
	}

	public String getFirstClmDtHigh() {
		return firstClmDtHigh;
	}

	public void setFirstClmDtHigh(String firstClmDtHigh) {
		this.firstClmDtHigh = firstClmDtHigh;
	}

	public String getFirstClmDtLow() {
		return firstClmDtLow;
	}

	public void setFirstClmDtLow(String firstClmDtLow) {
		this.firstClmDtLow = firstClmDtLow;
	}

	public String getPrvdrCity() {
		return prvdrCity;
	}

	public void setPrvdrCity(String prvdrCity) {
		this.prvdrCity = prvdrCity;
	}

	public List<AsrGenericCode> getEnrollStatus() {
		return enrollStatus;
	}

	public void setEnrollStatus(List<AsrGenericCode> enrollStatus) {
		this.enrollStatus = enrollStatus;
	}

	public List<AsrGenericCode> getMacIds() {
		return macIds;
	}

	public void setMacIds(List<AsrGenericCode> macIds) {
		this.macIds = macIds;
	}

	public List<AsrGenericCode> getCncs() {
		return cncs;
	}

	public void setCncs(List<AsrGenericCode> cncs) {
		this.cncs = cncs;
	}

	public String getUcmClosedDtHigh() {
		return ucmClosedDtHigh;
	}

	public void setUcmClosedDtHigh(String ucmClosedDtHigh) {
		this.ucmClosedDtHigh = ucmClosedDtHigh;
	}

	public String getUcmClosedDtLow() {
		return ucmClosedDtLow;
	}

	public void setUcmClosedDtLow(String ucmClosedDtLow) {
		this.ucmClosedDtLow = ucmClosedDtLow;
	}

	public String getLeadInd() {
		return leadInd;
	}

	public void setLeadInd(String leadInd) {
		this.leadInd = leadInd;
	}

	public String getBiuInd() {
		return biuInd;
	}

	public void setBiuInd(String biuInd) {
		this.biuInd = biuInd;
	}

	public String getBiu90Ind() {
		return biu90Ind;
	}

	public void setBiu90Ind(String biu90Ind) {
		this.biu90Ind = biu90Ind;
	}

	public Integer getTimelinessLow() {
		return timelinessLow;
	}

	public void setTimelinessLow(Integer timelinessLow) {
		this.timelinessLow = timelinessLow;
	}

	public Integer getTimelinessHigh() {
		return timelinessHigh;
	}

	public void setTimelinessHigh(Integer timelinessHigh) {
		this.timelinessHigh = timelinessHigh;
	}

	public List<AsrGenericCode> getExclusions() {
		return exclusions;
	}

	public void setExclusions(List<AsrGenericCode> exclusions) {
		this.exclusions = exclusions;
	}

	

	public Double getSbmtAmtDHigh() {
		return sbmtAmtDHigh;
	}

	public void setSbmtAmtDHigh(Double sbmtAmtDHigh) {
		this.sbmtAmtDHigh = sbmtAmtDHigh;
	}

	public Double getSbmtAmtDLow() {
		return sbmtAmtDLow;
	}

	public void setSbmtAmtDLow(Double sbmtAmtDLow) {
		this.sbmtAmtDLow = sbmtAmtDLow;
	}

	public Double getTotalPymtDHigh() {
		return totalPymtDHigh;
	}

	public void setTotalPymtDHigh(Double totalPymtDHigh) {
		this.totalPymtDHigh = totalPymtDHigh;
	}

	public Double getTotalPymtDLow() {
		return totalPymtDLow;
	}

	public void setTotalPymtDLow(Double totalPymtDLow) {
		this.totalPymtDLow = totalPymtDLow;
	}

	public String getLastClmDtHigh() {
		return lastClmDtHigh;
	}

	public void setLastClmDtHigh(String lastClmDtHigh) {
		this.lastClmDtHigh = lastClmDtHigh;
	}

	public String getLastClmDtLow () {
		return lastClmDtLow;
	}

	public void setLastClmDtLow(String lastClmDtLow) {
		this.lastClmDtLow = lastClmDtLow;
	}

	public Integer getEditId() {
		return editId;
	}

	public void setEditId(Integer editId) {
		this.editId = editId;
	}

	public List<AsrGenericCode> getPrioritizeTypes() {
		return prioritizeTypes;
	}

	public void setPrioritizeTypes(List<AsrGenericCode> prioritizeTypes) {
		this.prioritizeTypes = prioritizeTypes;
	}

	public Integer getAsrCostHigh() {
		return asrCostHigh;
	}

	public void setAsrCostHigh(Integer asrCostHigh) {
		this.asrCostHigh = asrCostHigh;
	}

	public Integer getAsrCostLow() {
		return asrCostLow;
	}

	public void setAsrCostLow(Integer asrCostLow) {
		this.asrCostLow = asrCostLow;
	}

	public String getLastAlertSvcDtHigh() {
		return lastAlertSvcDtHigh;
	}

	public void setLastAlertSvcDtHigh(String lastAlertSvcDtHigh) {
		this.lastAlertSvcDtHigh = lastAlertSvcDtHigh;
	}

	public String getLastAlertSvcDtLow() {
		return lastAlertSvcDtLow;
	}

	public void setLastAlertSvcDtLow(String lastAlertSvcDtLow) {
		this.lastAlertSvcDtLow = lastAlertSvcDtLow;
	}

	public String getExclusionOrInd() {
		return exclusionOrInd;
	}

	public void setExclusionOrInd(String exclusionOrInd) {
		this.exclusionOrInd = exclusionOrInd;
	}

	public String getExclusionMyZoneInd() {
		return exclusionMyZoneInd;
	}

	public void setExclusionMyZoneInd(String exclusionMyZoneInd) {
		this.exclusionMyZoneInd = exclusionMyZoneInd;
	}

	public String getZrId() {
		return zrId;
	}

	public void setZrId(String zrId) {
		this.zrId = zrId;
	}

	public String getSearchType() {
		return searchType;
	}

	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}

	public String getLastTpeEduDtHigh() {
		return lastTpeEduDtHigh;
	}

	public void setLastTpeEduDtHigh(String lastTpeEduDtHigh) {
		this.lastTpeEduDtHigh = lastTpeEduDtHigh;
	}

	public String getLastTpeEduDtLow() {
		return lastTpeEduDtLow;
	}

	public void setLastTpeEduDtLow(String lastTpeEduDtLow) {
		this.lastTpeEduDtLow = lastTpeEduDtLow;
	}

	public Integer getBiuCnt() {
		return biuCnt;
	}

	public void setBiuCnt(Integer biuCnt) {
		this.biuCnt = biuCnt;
	}

	public Integer getBiuDays() {
		return biuDays;
	}

	public void setBiuDays(Integer biuDays) {
		this.biuDays = biuDays;
	}

	public List<AsrGenericCode> getAsrWorkingSetInd() {
		return asrWorkingSetInd;
	}

	public void setAsrWorkingSetInd(List<AsrGenericCode> asrWorkingSetInd) {
		this.asrWorkingSetInd = asrWorkingSetInd;
	}

	public List<AsrGenericCode> getAsrExclSetInd() {
		return asrExclSetInd;
	}

	public void setAsrExclSetInd(List<AsrGenericCode> asrExclSetInd) {
		this.asrExclSetInd = asrExclSetInd;
	}
	public List<Object> getAsrptIds() {
		return asrptIds;
	}

	public void setAsrptIds(List<Object> asrptIds) {
		this.asrptIds = asrptIds;
	}


	/**
	 * @return the specialtyCds
	 */
	public List<AsrGenericCode> getSpecialtyCds() {
		return specialtyCds;
	}

	/**
	 * @param specialtyCds the specialtyCds to set
	 */
	public void setSpecialtyCds(List<AsrGenericCode> specialtyCds) {
		this.specialtyCds = specialtyCds;
	}

	public String getDualBeneInd() {
		return dualBeneInd;
	}

	public void setDualBeneInd(String dualBeneInd) {
		this.dualBeneInd = dualBeneInd;
	}

	public String getProgramType() {
		return programType;
	}

	public void setProgramType(String programType) {
		this.programType = programType;
	}

	public List<AsrGenericCode> getMdcdSvcCats() {
		return mdcdSvcCats;
	}

	public void setMdcdSvcCats(List<AsrGenericCode> mdcdSvcCats) {
		this.mdcdSvcCats = mdcdSvcCats;
	}

	public List<AsrGenericCode> getMdcdSvcSubCats() {
		return mdcdSvcSubCats;
	}

	public void setMdcdSvcSubCats(List<AsrGenericCode> mdcdSvcSubCats) {
		this.mdcdSvcSubCats = mdcdSvcSubCats;
	}

	public List<AsrGenericCode> getMdcdRoles() {
		return mdcdRoles;
	}

	public void setMdcdRoles(List<AsrGenericCode> mdcdRoles) {
		this.mdcdRoles = mdcdRoles;
	}

	public List<Object> getBillingNpis() {
		return billingNpis;
	}

	public void setBillingNpis(List<Object> billingNpis) {
		this.billingNpis = billingNpis;
	}

	public List<AsrGenericCode> getMdcdSvcTypes() {
		return mdcdSvcTypes;
	}

	public void setMdcdSvcTypes(List<AsrGenericCode> mdcdSvcTypes) {
		this.mdcdSvcTypes = mdcdSvcTypes;
	}

	public String getPathToEduInd() {
		return pathToEduInd;
	}

	public void setPathToEduInd(String pathToEduInd) {
		this.pathToEduInd = pathToEduInd;
	}

	public String getAcoInd() {
		return acoInd;
	}

	public void setAcoInd(String acoInd) {
		this.acoInd = acoInd;
	}

	public String getModelRunDt() {
		return modelRunDt;
	}

	public void setModelRunDt(String modelRunDt) {
		this.modelRunDt = modelRunDt;
	}

	public List<AsrGenericCode> getP1Jurisdictions() {
		return p1Jurisdictions;
	}

	public void setP1Jurisdictions(List<AsrGenericCode> p1Jurisdictions) {
		this.p1Jurisdictions = p1Jurisdictions;
	}

	public String getP1LastAlertSvcDtHigh() {
		return p1LastAlertSvcDtHigh;
	}

	public void setP1LastAlertSvcDtHigh(String p1LastAlertSvcDtHigh) {
		this.p1LastAlertSvcDtHigh = p1LastAlertSvcDtHigh;
	}

	public String getP1LastAlertSvcDtLow() {
		return p1LastAlertSvcDtLow;
	}

	public void setP1LastAlertSvcDtLow(String p1LastAlertSvcDtLow) {
		this.p1LastAlertSvcDtLow = p1LastAlertSvcDtLow;
	}

	public Integer getP1AsrCostHigh() {
		return p1AsrCostHigh;
	}

	public void setP1AsrCostHigh(Integer p1AsrCostHigh) {
		this.p1AsrCostHigh = p1AsrCostHigh;
	}

	public Integer getP1AsrCostLow() {
		return p1AsrCostLow;
	}

	public void setP1AsrCostLow(Integer p1AsrCostLow) {
		this.p1AsrCostLow = p1AsrCostLow;
	}

	public List<AsrAlertStatus> getP1AlertStatus() {
		return p1AlertStatus;
	}

	public void setP1AlertStatus(List<AsrAlertStatus> p1AlertStatus) {
		this.p1AlertStatus = p1AlertStatus;
	}

	public List<AsrAlertType> getP1Alerts() {
		return p1Alerts;
	}

	public void setP1Alerts(List<AsrAlertType> p1Alerts) {
		this.p1Alerts = p1Alerts;
	}

	public List<AsrGenericCode> getAtRiskJrsdctns() {
		return atRiskJrsdctns;
	}

	public void setAtRiskJrsdctns(List<AsrGenericCode> atRiskJrsdctns) {
		this.atRiskJrsdctns = atRiskJrsdctns;
	}

	public Integer getAtRiskCostHigh() {
		return atRiskCostHigh;
	}

	public void setAtRiskCostHigh(Integer atRiskCostHigh) {
		this.atRiskCostHigh = atRiskCostHigh;
	}

	public Integer getAtRiskCostLow() {
		return atRiskCostLow;
	}

	public void setAtRiskCostLow(Integer atRiskCostLow) {
		this.atRiskCostLow = atRiskCostLow;
	}
	
	public static AsrSearchParameter defaultAtRiskJurisdiction(String jurisdiction) {
		AsrSearchParameter s = new AsrSearchParameter();
		s.setAtRiskJrsdctns(Arrays.asList(new AsrGenericCode(jurisdiction)));
		return s;
	}
}
