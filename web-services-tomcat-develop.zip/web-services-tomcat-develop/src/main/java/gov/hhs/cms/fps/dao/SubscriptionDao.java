package gov.hhs.cms.fps.dao;

import java.util.List;

import gov.hhs.cms.fps.model.generated.FpsFdsNtfctn;
import gov.hhs.cms.fps.model.generated.FpsFdsSbscrptn;
import gov.hhs.cms.fps.model.hub.Event;

public interface SubscriptionDao {

	public FpsFdsSbscrptn saveUpdateSubscription(FpsFdsSbscrptn s);
	public FpsFdsNtfctn insertEventNotification(FpsFdsNtfctn s);
	public List<FpsFdsSbscrptn> getSubscriptions(Event event);
	public List<FpsFdsSbscrptn> getSubscriptions(Object entityId);
	public List<FpsFdsSbscrptn> getSubscriptions(Event event, Object entityId);
	public List<FpsFdsNtfctn> getNewNotifications();
	
}
