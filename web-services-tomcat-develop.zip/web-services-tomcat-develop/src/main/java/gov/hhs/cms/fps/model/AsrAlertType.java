package gov.hhs.cms.fps.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrAlertType implements Serializable {

	private Integer alertId;
	private String alertTypeCd;
	private String alertTypeDesc;
	
	public AsrAlertType() {
		
	}
	public AsrAlertType(Integer alertId) {
		this.alertId = alertId;
	}
	public String getAlertTypeCd() {
		return alertTypeCd;
	}
	public void setAlertTypeCd(String alertTypeCd) {
		this.alertTypeCd = alertTypeCd;
	}
	public String getAlertTypeDesc() {
		return alertTypeDesc;
	}
	public void setAlertTypeDesc(String alertTypeDesc) {
		this.alertTypeDesc = alertTypeDesc;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((alertId == null) ? 0 : alertId.hashCode());
		result = prime * result + ((alertTypeCd == null) ? 0 : alertTypeCd.hashCode());
		result = prime * result + ((alertTypeDesc == null) ? 0 : alertTypeDesc.hashCode());
		return result;
	}

	public Integer getAlertId() {
		return alertId;
	}
	public void setAlertId(Integer alertId) {
		this.alertId = alertId;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AsrAlertType other = (AsrAlertType) obj;
		if (alertId == null) {
			if (other.alertId != null)
				return false;
		} else if (!alertId.equals(other.alertId))
			return false;
		if (alertTypeCd == null) {
			if (other.alertTypeCd != null)
				return false;
		} else if (!alertTypeCd.equals(other.alertTypeCd))
			return false;
		if (alertTypeDesc == null) {
			if (other.alertTypeDesc != null)
				return false;
		} else if (!alertTypeDesc.equals(other.alertTypeDesc))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "AsrAlertType [" + (alertId != null ? "alertId=" + alertId : "") + "]";
	}
	public String toSearchString() {
		return "[" + (alertId != null ? "alertId=" + alertId : "") + "]";
	}
}
