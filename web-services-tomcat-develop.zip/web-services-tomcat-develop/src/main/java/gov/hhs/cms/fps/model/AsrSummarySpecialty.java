/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

// TODO: Auto-generated Javadoc
/**
 * The Class AsrSummarySpecialty.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrSummarySpecialty implements Serializable, Comparable<AsrSummarySpecialty> {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 403268212546292345L;

	/** The specialty type cd. */
	private String specialtyTypeCd;

	/** The specialty type desc. */
	private String specialtyTypeDesc;

	/**
	 * Gets the specialty type cd.
	 *
	 * @return the specialty type cd
	 */
	public String getSpecialtyTypeCd() {
		return specialtyTypeCd;
	}

	/**
	 * Sets the specialty type cd.
	 *
	 * @param specialtyTypeCd the new specialty type cd
	 */
	public void setSpecialtyTypeCd(String specialtyTypeCd) {
		this.specialtyTypeCd = specialtyTypeCd;
	}

	/**
	 * Gets the specialty type desc.
	 *
	 * @return the specialty type desc
	 */
	public String getSpecialtyTypeDesc() {
		return specialtyTypeDesc;
	}

	/**
	 * Sets the specialty type desc.
	 *
	 * @param specialtyTypeDesc the new specialty type desc
	 */
	public void setSpecialtyTypeDesc(String specialtyTypeDesc) {
		this.specialtyTypeDesc = specialtyTypeDesc;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((specialtyTypeCd == null) ? 0 : specialtyTypeCd.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AsrSummarySpecialty other = (AsrSummarySpecialty) obj;
		if (specialtyTypeCd == null) {
			if (other.specialtyTypeCd != null)
				return false;
		} else if (!specialtyTypeCd.equals(other.specialtyTypeCd))
			return false;
		return true;
	}

	public int compareTo(AsrSummarySpecialty target) {
		if (specialtyTypeCd == null ^ target.getSpecialtyTypeCd() == null) {
			return (specialtyTypeCd == null) ? -1 : 1;
		}

		if (specialtyTypeCd == null && target.getSpecialtyTypeCd() == null) {
			return 0;
		}
		return specialtyTypeCd.compareTo(target.getSpecialtyTypeCd());
	}
}
