package gov.hhs.cms.fps.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ws.rs.core.Application;

import org.apache.commons.lang3.StringUtils;
import org.apache.wink.client.ClientConfig;
import org.apache.wink.client.ClientResponse;
import org.apache.wink.client.ClientRuntimeException;
import org.apache.wink.client.Resource;
import org.apache.wink.client.RestClient;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.jaxrs.JacksonJsonProvider;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import gov.hhs.cms.fps.model.AsrDetailClaimLineItem;
import gov.hhs.cms.fps.model.AsrGenericCode;
import gov.hhs.cms.fps.model.AvailableClaims;
import gov.hhs.cms.fps.model.ClaimsSearchParameter;
import gov.hhs.cms.fps.model.ClaimsSolrStream;
import gov.hhs.cms.fps.model.FpsCommonBeneficiary;
import gov.hhs.cms.fps.model.FpsVisualization;
import gov.hhs.cms.fps.model.FpsVisualizationEdge;
import gov.hhs.cms.fps.model.generated.FpsAlert;
import gov.hhs.cms.fps.model.generated.FpsModel;
import gov.hhs.cms.fps.util.CsvHelper;
import gov.hhs.cms.fps.util.FpsCsvStringReader;
import gov.hhs.cms.fps.util.FpsDomainObjectConverter;
import gov.hhs.cms.fps.util.FpsEnums.SolrClaimType;
import gov.hhs.cms.fps.util.FpsUcmJsonReader;

@Repository("solrDao")
public class SolrDaoImpl implements SolrDao {
//	@Autowired
//	private SolrClient solrClient;
	@Autowired
	private Environment env;
	@Value("${solr.collection.claims}")
	private String collClaims;

	@Value("${solr.collection.rawclaims}")
	private String collClaimsRaw;
	@Value("${solr.collection.rawclaims.partd}")
	private String collClaimsRawD;
	@Value("${solr.collection.claims.partd}")
	private String collClaimsPartD;
	@Value("${solr.collection.viz.edges}")
	private String collVizEdges;
	@Value("${solr.collection.viz.nodes}")
	private String collVizNodes;
	@Value("${solr.collection.viz.hha.edges}")
	private String collVizHhaEdges;
	@Value("${solr.collection.viz.hha.nodes}")
	private String collVizHhaNodes;
	@Value("${solr.collection.viz.dme.edges}")
	private String collVizDmeEdges;
	@Value("${solr.collection.viz.dme.nodes}")
	private String collVizDmeNodes;
	@Value("${solr.zk}")
	private String solrZk;
	@Value("${solr.url}")
	private String solrUrl;
	@Autowired
	private AsrDetailDao asrDetailDao;
	@Autowired
	private FpsServiceDao fpsServiceDao;
	@Autowired
	private FpsHubDao fpsHubDao;
	private static final Logger logger = Logger.getLogger(SolrDaoImpl.class.getName());

	@Override
	public List<AsrDetailClaimLineItem> testClaims() {

		Map<String, String> p = new HashMap<String, String>();
		// p.put("fq", "{!join from=clm_id to=clm_id
		// fromIndex="+collClaimsAsr+"}asrpt_id:" + 1);
		p.put("q", "clm_id:*");
		return getClaimsFromSolr(p);
	}

	@Override
	public byte[] getClaimsForAsrCsv(ClaimsSearchParameter param, int maxResults, int startAt) {

		Map<String, String> p = new HashMap<String, String>();
		// p.put("fq", "{!join from=clm_id to=clm_id
		// fromIndex="+collClaimsAsr+"}asrpt_id:" + 1);
		// p.put("q", "clm_id:*");
		String q = buildSolrQuery(param);
		String sort = buildSolrSort("Y".equals(param.getLatest()) || "Y".equals(param.getLatestD()),
				param.getSearchType());
		p.put("q", q);
		p.put("sort", sort);
		String fl = "*,xsl_type:'asr_key',current_date:[value v='"
				+ FpsDomainObjectConverter.convertDateToShortString(new Date()) + "']";
		// raw claims doesn't have asr_key, so we don't want
		// the asrpt_id added to the query
		if (!SolrClaimType.RAW.equals(param.getSearchType()) && !SolrClaimType.PARTDRAW.equals(param.getSearchType())) {
			fl += ",xsl_key:[value v='" + param.getAsrptId() + "']";
		}
		// Part D has no claim type column, so dynamically add it
		if (SolrClaimType.PARTDALERTED.equals(param.getSearchType())
				|| SolrClaimType.PARTDRAW.equals(param.getSearchType())) {
			fl += ",clm_src_type:[value v='D']";
		}
		p.put("fl", fl);
		p.put("rows", maxResults + "");
		p.put("start", startAt + "");
		// getClaimsFromSolrCsvCursor(p, sb, claimCollection, maxResults);
		return getClaimsFromSolrCsvXslt(p, param.getSearchType());
	}

	@Override
	public byte[] getClaimsForAlertCsv(int modelId, String subjId, int asrptId, int alertId, boolean isPartD,
			int maxResults, int startAt) {
		FpsModel model = fpsServiceDao.loadModelById(modelId);
		Map<String, String> p = new HashMap<String, String>();
		String key = asrptId + "\\^" + modelId + "\\^" + subjId;
		p.put("q", "alert_key:*," + key + "*");
		p.put("fl",
				"*,model_name:[value v='" + model.getModelBusnsId() + "'],xsl_key:[value v='" + key
						+ "'],current_date:[value v='" + FpsDomainObjectConverter.convertDateToShortString(new Date())
						+ "'],xsl_type:'alert_key'");
		// p.put("fq", "{!join score=\"none\" from=clm_id to=clm_id fromIndex="
		// + collectionSuffix + "}model_id:" + modelId
		// + " and subj_id:" + subjId + " AND asrpt_id: " + asrptId);
		p.put("fq", "attribute_key:,*" + asrptId + "\\^" + alertId + "*");
		p.put("start", startAt + "");
		p.put("rows", maxResults + "");
		String sort = buildSolrSort(false, isPartD ? SolrClaimType.PARTDALERTED : SolrClaimType.ALERTED);
		p.put("sort", sort);
		// getClaimsFromSolrCsvCursor(p, sb, claimCollection, maxResults);
		return getClaimsFromSolrCsvXslt(p, isPartD ? SolrClaimType.PARTDALERTED : SolrClaimType.ALERTED);
	}

	@Override
	public List<AsrDetailClaimLineItem> getClaimsForAlert(int modelId, String subjId, int asrptId) {
		return getClaimsForAlert(modelId, subjId, asrptId, false);
	}

	@Override
	public List<AsrDetailClaimLineItem> getClaimsForAlert(int modelId, String subjId, int asrptId, boolean isPartD) {
		Map<String, String> p = new HashMap<String, String>();
		int alertId = asrDetailDao.getLastAlertForAsrAndModel(asrptId, modelId);
		String key = asrptId + "\\^" + modelId + "\\^" + subjId;
		String attribute_key = asrptId + "\\^" + alertId;
		p.put("q", "alert_key:,*" + key + "* AND attribute_key:,*" + attribute_key + "*");
		String fl = "*,asrpt_id:[value v='" + asrptId + "'],current_date:[value v='"
				+ FpsDomainObjectConverter.convertDateToShortString(new Date()) + "']";
		if (isPartD) {
			fl += ",clm_src_type:[value v='D']";
		}
		p.put("fl", fl);
		// p.put("fq", "{!join score=\"none\" from=clm_id to=clm_id fromIndex="
		// + collectionSuffix + "}model_id:" + modelId
		// + " and subj_id:" + subjId + " AND asrpt_id: " + asrptId);
		p.put("start", "0");
		p.put("rows", "1000");
		return getClaimsFromSolr(p, isPartD ? SolrClaimType.PARTDALERTED : SolrClaimType.ALERTED);
	}

	@Override
	public List<AsrDetailClaimLineItem> getClaimsForAlert(int modelId, String subjId, int asrptId, int alertId) {
		return getClaimsForAlert(modelId, subjId, asrptId, alertId, false);
	}

	@Override
	public List<AsrDetailClaimLineItem> getClaimsForAlert(int modelId, String subjId, int asrptId, int alertId,
			boolean isPartD) {

		Map<String, String> p = new HashMap<String, String>();
		String key = asrptId + "\\^" + modelId + "\\^" + subjId;
		p.put("q", "alert_key:*," + key + "*");
		p.put("fl", "*,asrpt_id:[value v='" + asrptId + "'],current_date:[value v='"
				+ FpsDomainObjectConverter.convertDateToShortString(new Date()) + "']");
		// p.put("fq", "{!join score=\"none\" from=clm_id to=clm_id fromIndex="
		// + collectionSuffix + "}model_id:" + modelId
		// + " and subj_id:" + subjId + " AND asrpt_id: " + asrptId);
		p.put("fq", "attribute_key:,*" + asrptId + "\\^" + alertId + "*");
		p.put("start", "0");
		p.put("rows", "1000");
		return getClaimsFromSolr(p, isPartD ? SolrClaimType.PARTDALERTED : SolrClaimType.ALERTED);
	}

	@Override
	public List<AsrDetailClaimLineItem> getClaimsForReportCard(short attrSqncNum, int alertId, int asrptId) {
		return getClaimsForReportCard(attrSqncNum, alertId, asrptId, false);
	}

	@Override
	public List<AsrDetailClaimLineItem> getClaimsForReportCard(short attrSqncNum, int alertId, int asrptId,
			boolean isPartD) {
		Map<String, String> p = new HashMap<String, String>();
		String key = asrptId + "\\^" + alertId + "\\^" + attrSqncNum;
		p.put("q", "attribute_key:,*" + key + "*");
		String fl = "*,asrpt_id:[value v='" + asrptId + "'],current_date:[value v='"
				+ FpsDomainObjectConverter.convertDateToShortString(new Date()) + "']";
		if (isPartD) {
			fl += ",clm_src_type:[value v='D']";
		}
		p.put("fl", fl); // p.put("fq", "{!join score=\"none\" from=clm_id
							// to=clm_id fromIndex="
		// + collectionSuffix + "}attr_sqnc_num:" + attrSqncNum
		// + " AND alert_id:" + alertId + " AND asrpt_id: " + asrptId);
		p.put("start", "0");
		p.put("rows", "1000");
		return getClaimsFromSolr(p, isPartD ? SolrClaimType.PARTDALERTED : SolrClaimType.ALERTED);
	}

	@Override
	public byte[] getClaimsForReportCardCsv(short attrSqncNum, int alertId, int asrptId, boolean isPartD, int pageSize,
			int startAt) {
		FpsAlert alert = asrDetailDao.loadAlertByAlertId(alertId);
		Map<String, String> p = new HashMap<String, String>();
		String key = asrptId + "\\^" + alertId + "\\^" + attrSqncNum;
		p.put("q", "attribute_key:,*" + key + "*");
		String fl = "*,model_name:[value v='" + alert.getFpsModel().getModelBusnsId()
				+ "'],xsl_type:'attribute_key',xsl_key:[value v='" + key + "'],current_date:[value v='"
				+ FpsDomainObjectConverter.convertDateToShortString(new Date()) + "']";
		if (isPartD) {
			fl += ",clm_src_type:[value v='D']";
		}
		p.put("fl", fl); // p.put("fq", "{!join score=\"none\" from=clm_id
							// to=clm_id fromIndex="
		// + collectionSuffix + "}attr_sqnc_num:" + attrSqncNum
		// + " AND alert_id:" + alertId + " AND asrpt_id: " + asrptId);
		p.put("start", startAt + "");
		p.put("rows", pageSize + "");
		String sort = buildSolrSort(false, isPartD ? SolrClaimType.PARTDALERTED : SolrClaimType.ALERTED);
		p.put("sort", sort);
		return getClaimsFromSolrCsvXslt(p, isPartD ? SolrClaimType.PARTDALERTED : SolrClaimType.ALERTED);
	}

	@Override
	public List<AsrDetailClaimLineItem> getClaimsForAsr(ClaimsSearchParameter param, int maxResults, int startAt) {
		Map<String, String> p = new HashMap<String, String>();
		// String collectionSuffix = collClaimsAsr + "_" +
		// StringUtils.right(asrptId+"", 1);
		String q = buildSolrQuery(param);

		p.put("q", q);
		p.put("fl", "*,asrpt_id:[value v='" + param.getAsrptId() + "'],current_date:[value v='"
				+ FpsDomainObjectConverter.convertDateToShortString(new Date()) + "']");
		// p.put("fq", "{!join score=\"none\" from=clm_id to=clm_id fromIndex="
		// + collectionSuffix + "}asrpt_id:" + asrptId);

		// p.put("asrs.fl", "asrpt_id, clm_rvw_ind, models");
		// p.put("asrs.q", "clm_id:{!terms f=clm_id v=$row.clm_id}");
		// p.put("asrs.collection", collectionSuffix);
		p.put("start", startAt + "");
		p.put("rows", maxResults + "");
		return getClaimsFromSolr(p);
	}

//	public String buildSolrQuery(List<String> claimTypes, Date fromDate, Date toDate, List<String> hicns,
//			boolean isLatest, String subjId, Integer asrptId, SolrClaimType claimCollection, boolean searchAllNpis, boolean isRrb) {
	public String buildSolrQuery(ClaimsSearchParameter param) {
		List<AsrGenericCode> claimTypeCodes = param.getClaimTypes();
		Date fromDate = param.getFromDt();
		Date toDate = param.getToDt();
		List<FpsCommonBeneficiary> hicnCodes = param.getHicns();
		boolean isLatest = "Y".equals(param.getLatest());
		boolean isLatestD = "Y".equals(param.getLatestD());
		boolean isRrb = "Y".equals(param.getRrb());
		boolean searchAllNpis = "Y".equals(param.getSearchAllRoles());
		String subjId = param.getNpi();
		Integer asrptId = param.getAsrptId();
		SolrClaimType claimCollection = param.getSearchType();

		Map<String, String> params = new HashMap<String, String>();
		String p = "";
		if (fromDate != null) {
			Calendar fromCal = Calendar.getInstance();
			fromCal.setTime(fromDate);
			fromCal.set(Calendar.HOUR_OF_DAY, 0);
			fromCal.set(Calendar.MINUTE, 0);
			fromDate = fromCal.getTime();

		}
		if (toDate != null) {
			Calendar toCal = Calendar.getInstance();
			toCal.setTime(toDate);
			toCal.set(Calendar.HOUR_OF_DAY, 23);
			toCal.set(Calendar.MINUTE, 59);
			toDate = toCal.getTime();

		}
		if (isRrb) {
			params.put("bene_rrb_num", "[* TO *]");
			params.put("-bene_rrb_num", "\"\"");
			params.put("clm_src_type", "B");
			params.put("clm_rndrg_prvdr_npi_num", param.getNpi());
			params.put("clm_cntrctr_num", "00882");
		}
		if (claimTypeCodes != null && claimTypeCodes.size() > 0) {
			List<String> claimTypes = new ArrayList<String>();
			// ignore "D" since there is no clm_src_type column in D claims
			// this is handled via the searchType field
			for (AsrGenericCode claimTypeCode : claimTypeCodes) {
				if ("D".equals(claimTypeCode.getCode())) {
					continue;
				}
				claimTypes.add(claimTypeCode.getCode());
			}
			if (claimTypes.size() > 0) {
				params.put("clm_src_type", "(" + StringUtils.join(claimTypes, " ") + ")");
			}
		}
//		if (hicnCodes != null && hicnCodes.size() > 0) {
//			List<String> hicns = new ArrayList<String>();
//			for (FpsCommonBeneficiary hicnCode : hicnCodes) {
//				hicns.add(hicnCode.getHicn());
//			}
//			params.put("clm_hic_num", "(" + StringUtils.join(hicns, " ") + ")");
//
//		}
		String dateParam = "";
		if (fromDate == null && toDate == null && !isLatest && !isLatestD) {
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.YEAR, -1);
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			Calendar toCal = Calendar.getInstance();
			toCal.set(Calendar.HOUR_OF_DAY, 23);
			toCal.set(Calendar.MINUTE, 59);
			dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(cal.getTime()) + " TO "
					+ FpsDomainObjectConverter.convertDateToSolrString(toCal.getTime()) + "]";
		}
		if (fromDate != null || toDate != null) {
			if (fromDate != null) {
				if (toDate != null) {
					dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(fromDate) + " TO "
							+ FpsDomainObjectConverter.convertDateToSolrString(toDate) + "]";
				} else {
					dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(fromDate) + " TO *]";
				}
			} else {
				dateParam = "[* TO " + FpsDomainObjectConverter.convertDateToSolrString(toDate) + "]";
			}
			params.put("clm_thru_dt", dateParam);

		}
		if (isLatest || isLatestD) {
			Calendar cal = Calendar.getInstance();
			Calendar toCal = Calendar.getInstance();
			if (isLatestD) {
				Date d = getLatestClaimDateForPartD(subjId);
				cal.setTime(d);
				toCal.setTime(d);
			}
			cal.add(Calendar.DAY_OF_YEAR, -90);

			toCal.set(Calendar.HOUR_OF_DAY, 23);
			toCal.set(Calendar.MINUTE, 59);
			dateParam = "[" + FpsDomainObjectConverter.convertDateToSolrString(cal.getTime()) + " TO "
					+ FpsDomainObjectConverter.convertDateToSolrString(toCal.getTime()) + "]";
			params.put("clm_thru_dt", dateParam);
		}
		if (StringUtils.isNotBlank(param.getDiagnosis())) {
			params.put("clm_line_dgns_cd", param.getDiagnosis());
		}
		if (StringUtils.isNotBlank(param.getHcpcs())) {
			params.put("clm_line_hcpcs_cd", param.getHcpcs());
		}
		if (StringUtils.isNotBlank(param.getProcedure())) {
			params.put("clm_prcdr_1_cd", param.getProcedure());
		}
		// default - only alerted claims have asr_key
		if (!SolrClaimType.RAW.equals(claimCollection) && !SolrClaimType.PARTDRAW.equals(claimCollection)) {

			params.put("asr_key", "*," + asrptId + "*");
		}

		int i = 1;
		for (String key : params.keySet()) {
			p += key + ":" + params.get(key);
			if (i < params.keySet().size())
				p += " AND ";
			i++;
		}
		if (searchAllNpis) {
			if (p.length() > 0) {
				p += " AND ";
			}
			p += "  ( clm_rndrg_prvdr_npi_num:" + subjId;
			p += " OR clm_blg_prvdr_npi_num:" + subjId;
			p += " OR clm_rfrg_prvdr_npi_num:" + subjId;
			p += " OR clm_atndg_prvdr_npi_num:" + subjId;
			p += ")";

		}
		// search on HICN and MBI
		if (hicnCodes != null && hicnCodes.size() > 0) {
			List<String> hicns = new ArrayList<String>();
			for (FpsCommonBeneficiary hicnCode : hicnCodes) {
				String hicn = hicnCode.getHicn();
				// replace the wildcard in case anyone is trying that
				hicn = hicn.replace("*", "");
				// escape the bracket since legacy apache wink will choke
				// The bracket is a valid prefix on legacy RRB numbers
				hicn = hicn.replace("{", "*");
				hicns.add(hicn);
			}
			if (p.length() > 0) {
				p += " AND ";
			}

			p += "(clm_hic_num: " + "(" + StringUtils.join(hicns, " ") + ") ";
			// clm_mbi and bene_hic_num does not exist on Part D claims
			if (!SolrClaimType.PARTDALERTED.equals(claimCollection)
					&& !SolrClaimType.PARTDRAW.equals(claimCollection)) {
				p += " OR clm_mbi:" + "(" + StringUtils.join(hicns, " ") + ") ";
				p += "OR  bene_hic_num: " + "(" + StringUtils.join(hicns, " ") + ") ";

			}
			p += ") ";

		}
		// search on multiple diagnosis codes
		if (param.getDiagnosises() != null && param.getDiagnosises().size() > 0) {
			List<String> diagnoses = new ArrayList<String>();
			for (AsrGenericCode diagnosis : param.getDiagnosises()) {

				diagnoses.add(diagnosis.getCode());
			}
			if (p.length() > 0) {
				p += " AND ";
			}

			p += "(clm_line_dgns_cd: " + "(" + StringUtils.join(diagnoses, " ") + ")) ";

		}
		// search on multiple hcpcs codes
		if (param.getHcpcses() != null && param.getHcpcses().size() > 0) {
			List<String> hcpcss = new ArrayList<String>();
			for (AsrGenericCode hcpcs : param.getHcpcses()) {

				hcpcss.add(hcpcs.getCode());
			}
			if (p.length() > 0) {
				p += " AND ";
			}

			p += "(clm_line_hcpcs_cd: " + "(" + StringUtils.join(hcpcss, " ") + ")) ";

		}
		// search on multiple procedure codes
		if (param.getProcedures() != null && param.getProcedures().size() > 0) {
			List<String> procs = new ArrayList<String>();
			for (AsrGenericCode proc : param.getProcedures()) {

				procs.add(proc.getCode());
			}
			if (p.length() > 0) {
				p += " AND ";
			}

			p += "(clm_prcdr_1_cd: " + "(" + StringUtils.join(procs, " ") + ")) ";

		}
		if (SolrClaimType.PARTDRAW.equals(claimCollection)) {
			if (p.length() > 0) {
				p += " AND ";
			}
			p += "  ( prvdr_prscrbng_prvdr_npi_num:" + subjId;
			p += " OR prvdr_srvc_prvdr_npi_num:" + subjId;
			p += ")";

		}

		return p;
	}

	private Date getLatestClaimDateForPartD(String subjId) {
		List<AsrDetailClaimLineItem> claims = new ArrayList<AsrDetailClaimLineItem>();
//		QueryResponse response;
//		try {
//			Map<String, String> p = new HashMap<>();
//			String q = "  ( prvdr_prscrbng_prvdr_npi_num:" + subjId;
//			q += " OR prvdr_srvc_prvdr_npi_num:" + subjId;
//			q += ")";
//			p.put("q", q);
//			p.put("sort", "clm_from_dt desc");
//			p.put("fl", "clm_from_dt");
//			p.put("rows", "1");
//			showParams(p);
//			QueryRequest qr = new QueryRequest(new MapSolrParams(p));
//			// logger.info(qr.getParams().toQueryString());
//			logger.info("query start " + SolrClaimType.PARTDRAW);
//			response = solrClient.query(collClaimsRawD, new MapSolrParams(p), METHOD.GET);
//			logger.info("query complete");
//			// Map<String,Object> debug = response.getDebugMap();
//			// for (String key : debug.keySet()){
//			// logger.info(key + " = " + debug.get(key));
//			// }
//			claims = response.getBeans(AsrDetailClaimLineItem.class);
//		} catch (SolrServerException e) {
//			logger.log(Level.SEVERE, "solr error loading claims", e);
//		} catch (IOException e) {
//			logger.log(Level.SEVERE, "io solr error loading claims", e);
//		}
//		if (claims != null && claims.size() > 0) {
//			return claims.get(0).getClaimFromDtSolr();
//		}
		return new Date();
	}

	public String buildSolrSort(boolean isLatest, SolrClaimType claimCollection) {

		String p = " clm_from_dt desc,clm_thru_dt desc, clm_hic_num asc, id asc";

		return p;
	}

	@Override
	public long getClaimsFromSolrCount(Map<String, String> p, SolrClaimType claimCollection) {
		// p.put("fq", "{!collapse field=clm_id}");
//		p.put("rows", "0");
//		QueryResponse response;
//		showParams(p);
		long retval = -1;
//		String collection = "";
//
//		switch (claimCollection) {
//		case RAW:
//			collection = collClaimsRaw;
//			break;
//		case ALERTED:
//			collection = collClaims;
//			break;
//		case PARTDALERTED:
//			collection = collClaimsPartD;
//			break;
//		case PARTDRAW:
//			collection = collClaimsRawD;
//			break;
//		}
//		logger.info("using collection " + collection);
//		try {
//			logger.info("count for query start ");
//			response = solrClient.query(collection, new MapSolrParams(p));
//			retval = response.getResults().getNumFound();
//			logger.info("count for query complete: " + retval);
//
//		} catch (SolrServerException e) {
//			logger.log(Level.SEVERE, "solr error loading claims count", e);
//		} catch (IOException e) {
//			logger.log(Level.SEVERE, "io solr error loading claims count", e);
//
//		}
		return retval;

	}

	@Override
	public List<AsrDetailClaimLineItem> getClaimsFromSolr(Map<String, String> p) {
		return getClaimsFromSolr(p, SolrClaimType.ALERTED);
	}

	@Override
	public List<AsrDetailClaimLineItem> getClaimsFromSolr(Map<String, String> p, SolrClaimType claimsCollection) {
		// p.put("fq", "{!collapse field=clm_id}");
		// p.put("debug", "all");
		showParams(p);

		List<AsrDetailClaimLineItem> claims = new ArrayList<AsrDetailClaimLineItem>();
//		QueryResponse response;
//		try {
//			QueryRequest qr = new QueryRequest(new MapSolrParams(p));
//			// logger.info(qr.getParams().toQueryString());
//			logger.info("query start " + claimsCollection);
//			String collection = SolrClaimType.PARTDALERTED.equals(claimsCollection) ? collClaimsPartD : collClaims;
//			response = solrClient.query(collection, new MapSolrParams(p), METHOD.GET);
//			logger.info("query complete");
//			// Map<String,Object> debug = response.getDebugMap();
//			// for (String key : debug.keySet()){
//			// logger.info(key + " = " + debug.get(key));
//			// }
//			claims = response.getBeans(AsrDetailClaimLineItem.class);
//		} catch (SolrServerException e) {
//			logger.log(Level.SEVERE, "solr error loading claims", e);
//		} catch (IOException e) {
//			logger.log(Level.SEVERE, "io solr error loading claims", e);
//		}

		return claims;
	}

	@Override
	@Deprecated
	public void getClaimsFromSolrCsv(Map<String, String> params, CsvHelper sb, SolrClaimType claimCollection) {

	}

	@Override
	@Deprecated
	public void getClaimsFromSolrCsvCursor(Map<String, String> p, CsvHelper sb, SolrClaimType claimCollection,
			int pageSize) {

	}

	@Override
	public long getClaimsForAlertCount(int modelId, String subjId, int asrptId, boolean partD) {

		Map<String, String> p = new HashMap<String, String>();
		String key = asrptId + "\\^" + modelId + "\\^" + subjId;
		p.put("q", "alert_key:*," + key + "*");
		// p.put("fq", "{!join score=\"none\" from=clm_id to=clm_id fromIndex="
		// + collectionSuffix + "}model_id:" + modelId
		// + " and subj_id:\"subjId\" AND asrpt_id: " + asrptId);

		return getClaimsFromSolrCount(p, partD ? SolrClaimType.PARTDALERTED : SolrClaimType.ALERTED);

	}

	@Override
	public long getClaimsForReportCardCount(short attrSqncNum, int alertId, int asrptId) {
		return getClaimsForReportCardCount(attrSqncNum, alertId, asrptId, false);
	}

	@Override
	public long getClaimsForReportCardCount(short attrSqncNum, int alertId, int asrptId, boolean partD) {
		Map<String, String> p = new HashMap<String, String>();
		String key = asrptId + "\\^" + alertId + "\\^" + attrSqncNum;
		p.put("q", "attribute_key:,*" + key + "*");
		// p.put("fq", "{!join score=\"none\" from=clm_id to=clm_id fromIndex="
		// + collectionSuffix + "}attr_sqnc_num:" + attrSqncNum
		// + " AND alert_id:" + alertId + " AND asrpt_id: " + asrptId);
		return getClaimsFromSolrCount(p, partD ? SolrClaimType.PARTDALERTED : SolrClaimType.ALERTED);
	}

	@Override
	public long getClaimsForAsrCount(ClaimsSearchParameter param) {
		Map<String, String> p = new HashMap<String, String>();
		// String collectionSuffix = collClaimsAsr + "_" +
		// StringUtils.right(asrptId+"", 1);
		String q = buildSolrQuery(param);
		p.put("q", q);
		p.put("rows", "0");
		p.put("fl", "id");
		// p.put("fq", "{!join score=\"none\" from=clm_id to=clm_id fromIndex="
		// + collectionSuffix + "}asrpt_id:" + asrptId);

		return getClaimsFromSolrCount(p, param.getSearchType());
	}

	@Override
	public AvailableClaims getAvailableClaimsForAsr(Integer asrptId, String npi) {
		AvailableClaims ac = new AvailableClaims();
		ClaimsSearchParameter search = new ClaimsSearchParameter();
		// latest claims
		search.setLatest("Y");
		search.setAsrptId(asrptId);
		search.setNpi(npi);
		search.setSearchAllRoles("Y");
		search.setSearchType(SolrClaimType.RAW);
		long x = getClaimsForAsrCount(search);
		ac.setLatestInd(x > 0 ? "Y" : "N");
		// latest Part D claims

		search = new ClaimsSearchParameter();
		search.setLatestD("Y");
		search.setAsrptId(asrptId);
		search.setNpi(npi);
		search.setSearchType(SolrClaimType.PARTDRAW);
		x = getClaimsForAsrCount(search);
		ac.setLatestDInd(x > 0 ? "Y" : "N");

		// claims at risk
		search = new ClaimsSearchParameter();
		search.setAsrptId(asrptId);
		search.setSearchType(SolrClaimType.ALERTED);
		x = getClaimsForAsrCount(search);
		ac.setAtRiskInd(x > 0 ? "Y" : "N");

		// part D claims at risk
		search = new ClaimsSearchParameter();
		search.setAsrptId(asrptId);
		search.setSearchType(SolrClaimType.PARTDALERTED);
		x = getClaimsForAsrCount(search);
		ac.setAtRiskDInd(x > 0 ? "Y" : "N");

		// all claims
		search.setAsrptId(asrptId);
		search.setSearchType(SolrClaimType.RAW);
		search.setNpi(npi);
		search.setSearchAllRoles("Y");
		x = getClaimsForAsrCount(search);
		ac.setAllClaimsInd(x > 0 ? "Y" : "N");
		// all Part D claims

		search = new ClaimsSearchParameter();
		search.setAsrptId(asrptId);
		search.setSearchType(SolrClaimType.PARTDRAW);
		search.setNpi(npi);
		x = getClaimsForAsrCount(search);
		ac.setAllClaimsDInd(x > 0 ? "Y" : "N");

		// all RRB claims

		search = new ClaimsSearchParameter();
		search.setRrb("Y");
		search.setAsrptId(asrptId);
		search.setNpi(npi);
		search.setSearchType(SolrClaimType.RAW);
		x = getClaimsForAsrCount(search);
		ac.setRrbInd(x > 0 ? "Y" : "N");
		return ac;
	}

	@Override
	@Deprecated
	public List<FpsCommonBeneficiary> getHicnsForASR(int asrptId) {

//		Map<String, String[]> p = new HashMap<String, String[]>();
//
//		p.put("q", new String[] { "asr_key:*," + asrptId + "*" });
//		p.put("fq", new String[] { " {!collapse field=clm_hic_num}" });
//
//		p.put("start", new String[] { "0" });
//		p.put("rows", new String[] { "1000" });
//		p.put("fl", new String[] { "clm_hic_num" });
//		p.put("sort", new String[] { "clm_line_thru_dt desc" });
//		// p.put("sort", new String[]{"clm_hic_num asc"});
//
		List<FpsCommonBeneficiary> hicns = new ArrayList<FpsCommonBeneficiary>();
//		QueryResponse response;
//		try {
//
//			response = solrClient.query(collClaims, new MultiMapSolrParams(p));
//			hicns = response.getBeans(FpsCommonBeneficiary.class);
//		} catch (SolrServerException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

		return hicns;
	}

	private void showParams(Map<String, String> p) {
		for (String key : p.keySet()) {
			logger.info(key + " = " + p.get(key));
		}
	}

	public String getCollClaimsRaw() {
		return collClaimsRaw;
	}

	public void setCollClaimsRaw(String collClaimsRaw) {
		this.collClaimsRaw = collClaimsRaw;
	}

	@Override
	public List<FpsCommonBeneficiary> getHicnsForASR(String subjId) {

		Map<String, String[]> p = new HashMap<String, String[]>();

		p.put("q", new String[] { "clm_rndrg_prvdr_npi_num:" + subjId + "" });
//		p.put("fq", new String[] { " {!collapse field=clm_hic_num}" });

		p.put("start", new String[] { "0" });
		p.put("rows", new String[] { "1000" });
		p.put("fl", new String[] { "clm_hic_num" });
		p.put("sort", new String[] { "clm_line_thru_dt desc" });
		// gets a distinct list
		p.put("group", new String[] { "true" });
		p.put("group.field", new String[] { "clm_hic_num" });
		p.put("group.main", new String[] { "true" });

		// p.put("sort", new String[]{"clm_hic_num asc"});

		List<FpsCommonBeneficiary> hicns = new ArrayList<FpsCommonBeneficiary>();
//		QueryResponse response;
//		try {
//
//			response = solrClient.query(collClaimsRaw, new MultiMapSolrParams(p));
//			hicns = response.getBeans(FpsCommonBeneficiary.class);
//		} catch (SolrServerException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		logger.info("returned hicns: " + hicns.size() + "");
		return hicns;
	}

	public byte[] getClaimsFromSolrCsvXslt(Map<String, String> p, SolrClaimType claimCollection) {

		ClientConfig cc = new ClientConfig();
		String collection = "";

		switch (claimCollection) {
		case RAW:
			collection = collClaimsRaw;
			break;
		case ALERTED:
			collection = collClaims;
			break;
		case PARTDALERTED:
			collection = collClaimsPartD;
			break;
		case PARTDRAW:
			collection = collClaimsRawD;
			break;
		}
		String xslt = SolrClaimType.PARTDALERTED.equals(claimCollection)
				|| SolrClaimType.PARTDRAW.equals(claimCollection) ? "partdclaimsexport.xsl" : "claimsexport.xsl";
		String csvUrl = solrUrl + collection + "/query";
		logger.info("using " + csvUrl);
		Application app = new Application() {
			public Set<Class<?>> getClasses() {
				Set<Class<?>> classes = new HashSet<Class<?>>();
				classes.add(JacksonJsonProvider.class);
				classes.add(FpsUcmJsonReader.class);
				classes.add(FpsCsvStringReader.class);
				return classes;
			}

		};
		cc.applications(app);
		cc.connectTimeout(5000);
		cc.readTimeout(300000);
		// Set<Object> s = new HashSet<Object>();
		// s.add(new JacksonJsonProvider());
		// app.setSingletons(s);
		showParams(p);
		RestClient client = new RestClient(cc);
		Resource r = client.resource(csvUrl);
		String t = null;
		ObjectMapper mapper = new ObjectMapper();

		try {

			long parseStart = System.currentTimeMillis();
			r = r.contentType("application/json").accept("application/json").queryParam("q", p.get("q"))
					.queryParam("wt", "xslt").queryParam("tr", xslt).queryParam("fl", p.get("fl"))
					.queryParam("rows", p.get("rows")).queryParam("start", p.get("start"))
					.queryParam("sort", p.get("sort"));
			if (p.get("fq") != null) {
				r.queryParam("fq", p.get("fq"));
			}
			ClientResponse rs = r.get();
			// logger.info(rs.getClass().getName());
			long endCall = System.currentTimeMillis();
			logger.info("query time = " + ((endCall - parseStart) / 1000));
			long processStart = System.currentTimeMillis();
			String s = (rs.getEntity(String.class));
//			logger.info("result = " + StringUtils.abbreviate(s, 100));
			long end1 = System.currentTimeMillis();
			logger.info("process time = " + ((processStart - end1) / 1000));
			return s.getBytes();

		} catch (ClientRuntimeException ce) {
			logger.log(Level.SEVERE, "Error calling solr", ce);
		} catch (RuntimeException re) {
			logger.log(Level.SEVERE, "Error calling solr2", re);
		}
		return "".getBytes();

	}

	@Override
	public List<AsrDetailClaimLineItem> getClaimsForAsrPartD(Integer asrptId, int maxResults, int startAt) {
		Map<String, String> p = new HashMap<String, String>();
		// String collectionSuffix = collClaimsAsr + "_" +
		// StringUtils.right(asrptId+"", 1);
		ClaimsSearchParameter param = new ClaimsSearchParameter();
		param.setSearchType(SolrClaimType.PARTDALERTED);
		param.setAsrptId(asrptId);
		String q = buildSolrQuery(param);

		// if ()
		p.put("q", q);
		p.put("fl", "*,asrpt_id:[value v='" + asrptId + "'],current_date:[value v='"
				+ FpsDomainObjectConverter.convertDateToShortString(new Date()) + "']");

		p.put("start", startAt + "");
		p.put("rows", maxResults + "");
		return getClaimsFromSolr(p, SolrClaimType.PARTDALERTED);
	}

	@Override
	public FpsVisualization loadVisualization(String subjId, String modelId) {
		return loadVisualization(subjId, modelId, null);
	}

	@Override
	public List<FpsVisualizationEdge> loadVisualizationDates(String subjId, String modelId) {
		return loadVisualizationDates(subjId, modelId, 1);
	}

	@Override
	public List<FpsVisualizationEdge> loadVisualizationDates(String subjId, String modelId, int rows) {
		Map<String, String> maxP = new HashMap<String, String>();
		List<FpsVisualizationEdge> edges = new ArrayList<FpsVisualizationEdge>();

		FpsVisualization viz = new FpsVisualization();
//		QueryResponse response;
//		try {
//
//			// get max model_run_dt
//			maxP.put("fl", "model_run_dt");
//			maxP.put("q", "subj_prvdr_npi:" + subjId + " AND model_busns_id:" + modelId);
//			maxP.put("sort", "model_run_dt desc");
//			maxP.put("rows", rows + "");
//			showParams(maxP);
//
//			logger.info("query max edges date start");
//
//			response = solrClient.query(collVizEdges, new MapSolrParams(maxP), METHOD.GET);
//			// if we didn't find a max date, then return a blank object
//			if (response.getResults() == null || response.getResults().size() == 0) {
//				logger.info("query max edges date complete, no data found");
//				return edges;
//			}
//			edges = response.getBeans(FpsVisualizationEdge.class);
//
//		} catch (SolrServerException e) {
//			logger.log(Level.SEVERE, "solr error loading viz data", e);
//		} catch (IOException e) {
//			logger.log(Level.SEVERE, "io solr error loading viz data", e);
//		}

		return edges;
	}

	@Override
	public FpsVisualization loadVisualization(String subjId, String modelId, Date modelRunDt) {
		// p.put("debug", "all");
		Map<String, String> p = new HashMap<String, String>();
		Map<String, String> maxP = new HashMap<String, String>();
		// showParams(p);

		FpsVisualization viz = new FpsVisualization();
//		QueryResponse response;
//		try {
//
//			Date d = modelRunDt;
//			if (d == null) {
//				logger.info("query max edges date start");
//				List<FpsVisualizationEdge> maxDate = loadVisualizationDates(subjId, modelId);
//				response = solrClient.query(collVizEdges, new MapSolrParams(maxP), METHOD.GET);
//				// if we didn't find a max date, then return a blank object
//				if (maxDate == null || maxDate.size() == 0) {
//					logger.info("query max edges date complete, no data found");
//					return viz;
//				}
//				d = maxDate.get(0).getModelRunDt();
//			}
//			logger.info("query edges start with " + FpsDomainObjectConverter.convertDateToString(d));
//
//			p.put("q", "subj_prvdr_npi:" + subjId + " AND model_busns_id:" + modelId + " AND model_run_dt:\""
//					+ FpsDomainObjectConverter.convertDateToSolrStringGmt(d) + "\"");
//			p.put("rows", "300");
//			showParams(p);
//			response = solrClient.query(collVizEdges, new MapSolrParams(p), METHOD.GET);
//
//			logger.info("query edges complete");
//
//			List<FpsVisualizationEdge> edges = response.getBeans(FpsVisualizationEdge.class);
//			viz.setEdges(edges);
//
//			// p.put("q", "node_id:" + subjId);//+" AND
//			// model_busns_id:"+modelId);
//			List<String> edgeTo = new ArrayList<String>();
//			edgeTo.add(subjId);
//			for (FpsVisualizationEdge edge : edges) {
//				edgeTo.add(edge.getRltdPrvdrNpi());
//			}
//			p.put("q", "npi:(" + StringUtils.join(edgeTo, " ") + ")  AND model_busns_id:" + modelId
//					+ " AND model_run_dt:\"" + FpsDomainObjectConverter.convertDateToSolrStringGmt(d) + "\"");
//			p.put("rows", "300");
//			p.put("fl", "*,subj_prvdr_role:subj_prvdr_type");
//
//			showParams(p);
//			logger.info("query nodes start with " + d);
//			response = solrClient.query(collVizNodes, new MapSolrParams(p), METHOD.GET);
//			logger.info("query nodes complete");
//
//			List<FpsVisualizationNode> nodes = response.getBeans(FpsVisualizationNode.class);
//			viz.setNodes(nodes);
//		} catch (SolrServerException e) {
//			logger.log(Level.SEVERE, "solr error loading viz data", e);
//		} catch (IOException e) {
//			logger.log(Level.SEVERE, "io solr error loading viz data", e);
//		}

		return viz;

	}

	private List<FpsVisualizationEdge> loadHhaEdges(List<FpsVisualizationEdge> srcEdges, int tier, boolean export)
//			throws SolrServerException,
		throws	IOException {
		List<FpsVisualizationEdge> edges = new ArrayList<FpsVisualizationEdge>();
//		List<String> founds = new ArrayList<String>();
//
//		for (FpsVisualizationEdge edge : srcEdges) {
//			Map<String, String> p = new HashMap<String, String>();
//			String to = edge.getTo();
//			if (!founds.contains(to) && (export || (!export && StringUtils.isNumeric(to)))) {
//				// data can contain { since we receive it like that. Just escape it, don't
//				// remove it.
//				founds.add(to.replace("{", "\\{"));
//			}
//		}
//		Map<String, String> p = new HashMap<String, String>();
//// search only NPIs.  Could use "label" but it's currently not index in Solr
//		String exportStr = export ? " " : " AND -label:referring_to_bene  AND dst:/[0-9]+/ AND src:/[0-9]+/";
////		p.put("q", "src:(" + StringUtils.join(founds, " ") + ")" + exportStr + " AND ranking:[" + rankingBucketMin + " TO " + rankingBucketMax+ "]");
//		p.put("q", "src:(" + StringUtils.join(founds, " ") + ")" + exportStr + " AND ranking:[0 TO 66] ");
//		p.put("rows", "2000");
//		p.put("sort", "ranking asc");
//		// the solr ranking is obsolete, so we make our own ranking based on
//		// relationship level.
////		String fl = "*,ranking:[value t=int v=" + (tier > 0 ? tier : 1) + "]";
////		if (!export) {
////			fl += ",label:[value v='']";
////		}
////		p.put("fl", fl);
//
//		showParams(p);
//		QueryResponse response = solrClient.query(collVizHhaEdges, new MapSolrParams(p), METHOD.GET);
//
//		edges = response.getBeans(FpsVisualizationEdge.class);
//		logger.info("edges found for tier " + (tier + 1) + ": " + edges.size());
//		// only load details for 3 levels.
//		if (edges.size() > 0 && tier < 2) {
//			edges.addAll(loadHhaEdges(edges, tier == 0 ? 1 : tier + 1, export));
//
//		}

		return edges;
	}

	@Deprecated
	private List<FpsVisualizationEdge> loadHhaEdgesByLevel(List<FpsVisualizationEdge> srcEdges, int tier, int min,
			int max, boolean export) throws  IOException {

		List<FpsVisualizationEdge> edges = new ArrayList<FpsVisualizationEdge>();
		List<String> founds = new ArrayList<String>();

		/*
		 * for (FpsVisualizationEdge edge : srcEdges) { Map<String, String> p = new
		 * HashMap<String, String>(); String to = edge.getTo(); if (!founds.contains(to)
		 * && (export || (!export && StringUtils.isNumeric(to)))) { // data can contain
		 * { since we receive it like that. Just escape it, don't // remove it.
		 * founds.add(to.replace("{", "\\{")); } } Map<String, String> p = new
		 * HashMap<String, String>(); // search only NPIs. Could use "label" but it's
		 * currently not index in Solr String exportStr = export ? "" :
		 * " AND dst:/[0-9]+/ AND src:/[0-9]+/"; // p.put("q", "src:(" +
		 * StringUtils.join(founds, " ") + ")" + exportStr + " AND ranking:[" +
		 * rankingBucketMin + " TO " + rankingBucketMax+ "]"); p.put("q", "src:(" +
		 * StringUtils.join(founds, " ") + ") " + exportStr + "  AND ranking:[" + min +
		 * " TO " + max + "] and -label:referring_to_bene"); p.put("rows", "1000");
		 * p.put("sort", "ranking asc"); // the solr ranking is obsolete, so we make our
		 * own ranking based on // relationship level. // String fl =
		 * "*,ranking:[value t=int v=" + (tier > 0 ? tier : 1) + "]"; // if (!export) {
		 * // fl += ",label:[value v='']"; // } // p.put("fl", fl);
		 * 
		 * showParams(p); QueryResponse response = solrClient.query(collVizHhaEdges, new
		 * MapSolrParams(p), METHOD.GET);
		 * 
		 * edges = response.getBeans(FpsVisualizationEdge.class);
		 * logger.info("edges found for tier " + (tier + 1) + ": " + edges.size()); //
		 * only load details for 3 levels. if (edges.size() > 0 && tier < 2) {
		 * edges.addAll(loadHhaEdgesByLevel(edges, tier == 0 ? 1 : tier + 1, min, max,
		 * export));
		 * 
		 * }
		 */
		return edges;
	}

	@Override
	public FpsVisualization loadHhaVisualization(String subjId, final Integer ranking) {
		// p.put("debug", "all");
		Map<String, String> p = new HashMap<String, String>();
		// showParams(p);
		final Integer rankingBucketMax = ranking * 22;
		final Integer rankingBucketMin = ranking == 1 ? 1 : ((ranking - 1) * 22) + 1;
		FpsVisualization viz = new FpsVisualization();
//		QueryResponse response;
//		try {
//
//			List<FpsVisualizationEdge> parents = new ArrayList<FpsVisualizationEdge>();
//			FpsVisualizationEdge parent = new FpsVisualizationEdge();
//			parent.setTo(subjId);
//			parents.add(parent);
//			// start with level 0 which is just the ASR NPI
//			// load all edges because the UI needs all edges.
//			List<FpsVisualizationEdge> edges = loadHhaEdges(parents, 0, ranking == -1);
//			// eliminate duplicate edges (based on to/from) as these can clutter the UI
//			// when the same edge is displayed more than once
//			edges = Lists.newArrayList(Sets.newHashSet(edges));
//			// load just the edges for this tier to find the nodes to load.
//			List<FpsVisualizationEdge> rawEdges = edges;
//
//			viz.setEdges(edges);
//
//			List<String> edgeTo = new ArrayList<String>();
//			if (ranking == 1 || ranking == -1) {
//				edgeTo.add(subjId.replace("{", "\\{"));
//			}
//			for (FpsVisualizationEdge edge : edges) {
//				// if edge.getto doesn't exist as a from in edges with lower ranking.
//				edgeTo.add(edge.getTo().replace("{", "\\{"));
//			}
//			// remove duplicates
//			edgeTo = Lists.newArrayList(Sets.newHashSet(edgeTo));
//
//			List<FpsVisualizationNode> nodes = new ArrayList<FpsVisualizationNode>();
//			if (edgeTo.size() > 0) {
//
//				p.put("q",
//						"id:(" + StringUtils.join(
//								(edgeTo.size() > 1024 ? Lists.newArrayList(edgeTo).subList(0, 1024) : edgeTo), " ")
//								+ ")");
//				p.put("fl", "*,subj_prvdr_role:label");
//				p.put("rows", ranking == -1 ? "1024" : "500");
//				showParams(p);
//				logger.info("query hha nodes start with " + ranking);
//				response = solrClient.query(collVizHhaNodes, new MapSolrParams(p), METHOD.POST);
//				logger.info("query hha nodes complete");
//
//				nodes = response.getBeans(FpsVisualizationNode.class);
//
////				nodes = ranking > -1 && nodes.size() > 22 ? nodes.subList(0, 22) : nodes;
//
//				FpsVisualizationNode parentNode = new FpsVisualizationNode();
//				parentNode.setId(subjId);
//				if (!nodes.contains(parentNode) && ranking == 1) {
//					edgeTo.add(subjId);
//					p.put("q", "id:" + subjId);
//					p.put("fl", "*,subj_prvdr_role:label");
//					p.put("rows", "1");
//					showParams(p);
//					logger.info("query parent hha nodes start with " + ranking);
//
//					response = solrClient.query(collVizHhaNodes, new MapSolrParams(p), METHOD.POST);
//					List<FpsVisualizationNode> parentNodes = response.getBeans(FpsVisualizationNode.class);
//					nodes.addAll(parentNodes);
//					logger.info("query parent hha nodes complete");
//				}
//
//			}
//			List<NvUcmSummary> zrData = fpsHubDao.findUcmSummaryForNpis(edgeTo);
//			for (FpsVisualizationNode node : nodes) {
//				NvUcmSummary template = new NvUcmSummary();
//				template.setNpi(node.getNpi());
//				if (zrData.contains(template)) {
//					node.setZr(zrData.get(zrData.indexOf(template)).getZrStatus());
//					node.setInvestigations(zrData.get(zrData.indexOf(template)).getCaseStatus());
//					node.setLeadInd(zrData.get(zrData.indexOf(template)).getLeadInd());
//				}
//
//			}
//			viz.setNodes(nodes);
//		} catch (SolrServerException e) {
//			logger.log(Level.SEVERE, "solr error loading viz hha data", e);
//		} catch (IOException e) {
//			logger.log(Level.SEVERE, "io solr error loading viz hha data", e);
//		}

		return viz;

	}

//	@Override
	public FpsVisualization loadHhaVisualization18(String subjId, final Integer ranking) {
		// p.put("debug", "all");
		Map<String, String> p = new HashMap<String, String>();
		// showParams(p);
		// ranking bucket gets blocks of 22 at a time. 1-22, 23-44, 45-66
		final Integer rankingBucketMax = ranking * 22;
		final Integer rankingBucketMin = ranking == 1 ? 1 : ((ranking - 1) * 22) + 1;
		FpsVisualization viz = new FpsVisualization();
//		QueryResponse response;
//		try {
//
//			p.put("q", "src:" + subjId);
//			p.put("rows", "500");
//			p.put("sort", "ranking asc");
//			showParams(p);
//			response = solrClient.query(collVizHhaEdges, new MapSolrParams(p), METHOD.GET);
//
//			logger.info("query hha edges complete, filtering with ranking (" + ranking + ") and min/max ("
//					+ rankingBucketMin + "/" + rankingBucketMax + ")");
//
//			List<FpsVisualizationEdge> edges = response.getBeans(FpsVisualizationEdge.class);
//			viz.setEdges(edges);
//			Collection<FpsVisualizationEdge> filtered = Collections2.filter(edges,
//					new Predicate<FpsVisualizationEdge>() {
//						@Override
//						public boolean apply(FpsVisualizationEdge edge) {
////					logger.info("checking " + edge.getRanking() +" vs " + rankingBucketMax+"/"+rankingBucketMin+"/"+edge.getLabel());
//							boolean ret = !edge.getLabel().equals("referring_to_bene")
//									&& edge.getRanking() <= rankingBucketMax && edge.getRanking() >= rankingBucketMin;
////					logger.info("adding? " + ret);
//
//							return ret;
//						}
//					});
//			// export gets all nodes, so don't use filtered list.
//			if (ranking > -1) {
//				edges = new ArrayList<FpsVisualizationEdge>(filtered);
//			}
//			// p.put("q", "node_id:" + subjId);//+" AND
//			// model_busns_id:"+modelId);
//			List<String> edgeTo = new ArrayList<String>();
//			if (ranking == 1 || ranking == -1) {
//				edgeTo.add(subjId);
//			}
//			for (FpsVisualizationEdge edge : edges) {
//				edgeTo.add(edge.getTo());
//			}
//			List<FpsVisualizationNode> nodes = new ArrayList<FpsVisualizationNode>();
//			if (edgeTo.size() > 0) {
//				p.put("q", "id:(" + StringUtils.join(edgeTo, " ") + ")");
//				p.put("fl", "*,subj_prvdr_role:label,subj_prvdr_clstr_pct:percent_bene");
//				p.put("rows", "500");
//				showParams(p);
//				logger.info("query hha nodes start with " + ranking);
//				response = solrClient.query(collVizHhaNodes, new MapSolrParams(p), METHOD.GET);
//				logger.info("query hha nodes complete");
//
//				nodes = response.getBeans(FpsVisualizationNode.class);
//			}
//			viz.setNodes(nodes);
//		} catch (SolrServerException e) {
//			logger.log(Level.SEVERE, "solr error loading viz hha data", e);
//		} catch (IOException e) {
//			logger.log(Level.SEVERE, "io solr error loading viz hha data", e);
//		}

		return viz;

	}

	@Override
	public String checkForVisualization(String subjId) {
		// p.put("debug", "all");
		Map<String, String> p = new HashMap<String, String>();

//		QueryResponse response;
		long hits = -1;
//		try {
//
//			p.put("q", "src:" + subjId + " AND ranking:[0 TO 66]");
//			p.put("rows", "0");
//			showParams(p);
//			response = solrClient.query(collVizHhaEdges, new MapSolrParams(p), METHOD.GET);
//
//			hits = response.getResults().getNumFound();
//			logger.info("query hha count complete, found  " + hits);
//
//		} catch (SolrServerException e) {
//			logger.log(Level.SEVERE, "solr error loading viz hha data", e);
//		} catch (SolrException e) {
//			logger.log(Level.SEVERE, "solr communication error loading viz hha data", e);
//		} catch (IOException e) {
//			logger.log(Level.SEVERE, "io solr error loading viz hha data", e);
//		}

		return hits > 0 ? "Y" : "N";

	}

	@Override
	public String checkForDmeVisualization(String subjId) {
		// p.put("debug", "all");
		Map<String, String> p = new HashMap<String, String>();

//		QueryResponse response;
		long hits = -1;
//		try {
//
//			p.put("q", "src:" + subjId + " AND ranking:[0 TO 66]");
//			p.put("rows", "0");
//			showParams(p);
//			response = solrClient.query(collVizDmeEdges, new MapSolrParams(p), METHOD.GET);
//
//			hits = response.getResults().getNumFound();
//			logger.info("query dme count complete, found  " + hits);
//
//		} catch (SolrServerException e) {
//			logger.log(Level.SEVERE, "solr error loading viz dme data", e);
//		} catch (SolrException e) {
//			logger.log(Level.SEVERE, "solr communication error loading viz dme data", e);
//		} catch (IOException e) {
//			logger.log(Level.SEVERE, "io solr error loading viz dme data", e);
//		}

		return hits > 0 ? "Y" : "N";

	}

	@Override
	public ClaimsSolrStream loadVizSharedBenes(FpsModel model, String npi, Date modelRunDt, List<String> relatedNPIs) {
		ClientConfig cc = new ClientConfig();
		String collection = collClaims;

		String csvUrl = solrUrl + collection + "/stream";

		Application app = new Application() {
			public Set<Class<?>> getClasses() {
				Set<Class<?>> classes = new HashSet<Class<?>>();
				classes.add(JacksonJsonProvider.class);
				classes.add(FpsUcmJsonReader.class);
				classes.add(FpsCsvStringReader.class);
				return classes;
			}

		};
		cc.applications(app);
		cc.connectTimeout(5000);
		cc.readTimeout(300000);
		// Set<Object> s = new HashSet<Object>();
		// s.add(new JacksonJsonProvider());
		// app.setSingletons(s);

		RestClient client = new RestClient(cc);
		Resource r = client.resource(csvUrl);
		String t = null;
		ObjectMapper mapper = new ObjectMapper();
		String npiList = StringUtils.join(relatedNPIs, " ");
		String alertKey = "*\\^" + model.getModelId() + "\\^" + npi + "*";
		String post = "unique(innerJoin(" + "search(" + collClaims
				+ ", q=alert_key:#alertKey#, fl=\"clm_mbi,clm_hic_num,clm_bene_state_cd,src_zip5_cd,bene_1st_name,bene_last_name,bene_line_1_adr,bene_line_2_adr,src_zip_plc_name\", sort=\"clm_hic_num asc\",qt=\"/export\"),"
				+ "search(" + collClaims + ", q=clm_rndrg_prvdr_npi_num:(#npiList#) OR "
				+ "	clm_blg_prvdr_npi_num:(#npiList#) OR clm_atndg_prvdr_npi_num:(#npiList#) "
				+ "OR clm_rfrg_prvdr_npi_num:(#npiList#) ,"
				+ " fl=\"clm_hic_num\", sort=\"clm_hic_num asc\",qt=\"/export\"),"
				+ "on=\"clm_hic_num\"),  over=\"clm_hic_num\")";
		String solrDt = "";
		if (modelRunDt == null) {
			List<FpsVisualizationEdge> dates = loadVisualizationDates(npi, model.getModelBusnsId());
			if (dates == null || dates.size() == 0) {
				return new ClaimsSolrStream();

			}
			solrDt = FpsDomainObjectConverter.convertDateToSolrString(dates.get(0).getModelRunDt());
		}
		post = post.replace("#alertKey#", alertKey);
		post = post.replace("#npiList#", npiList);
		logger.info("URL = " + csvUrl);
		logger.info("stream = " + post);
		try {
			long parseStart = System.currentTimeMillis();
			String s = r.contentType("text/plain").accept("text/plain").queryParam("expr", post).get(String.class);
			// logger.info(rs.getClass().getName());
			long endCall = System.currentTimeMillis();
			long processStart = System.currentTimeMillis();
			ClaimsSolrStream css = mapper.readValue(s, ClaimsSolrStream.class);

			long end1 = System.currentTimeMillis();
			return css;

		} catch (ClientRuntimeException ce) {
			ce.printStackTrace();
		} catch (RuntimeException re) {
			re.printStackTrace();
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public FpsVisualization loadDmeVisualization(String subjId, final Integer ranking) {

		// p.put("debug", "all");
		Map<String, String> p = new HashMap<String, String>();
		// showParams(p);
		final Integer rankingBucketMax = ranking * 22;
		final Integer rankingBucketMin = ranking == 1 ? 1 : ((ranking - 1) * 22) + 1;
		FpsVisualization viz = new FpsVisualization();
//		QueryResponse response;
//		try {
//
//			List<FpsVisualizationEdge> parents = new ArrayList<FpsVisualizationEdge>();
//			FpsVisualizationEdge parent = new FpsVisualizationEdge();
//			parent.setTo(subjId);
//			parents.add(parent);
//			// start with level 0 which is just the ASR NPI
//			// load all edges because the UI needs all edges.
//			List<FpsVisualizationEdge> edges = loadDmeEdges(parents, 0, ranking == -1);
//			// eliminate duplicate edges (based on to/from) as these can clutter the UI
//			// when the same edge is displayed more than once
//			edges = Lists.newArrayList(Sets.newHashSet(edges));
//			// load just the edges for this tier to find the nodes to load.
//			List<FpsVisualizationEdge> rawEdges = edges;
//
//			viz.setEdges(edges);
//
//			List<String> edgeTo = new ArrayList<String>();
//			if (ranking == 1 || ranking == -1) {
//				edgeTo.add(subjId.replace("{", "\\{"));
//			}
//			for (FpsVisualizationEdge edge : edges) {
//				// if edge.getto doesn't exist as a from in edges with lower ranking.
//				edgeTo.add(edge.getTo().replace("{", "\\{"));
//				if (edge.getFrom() != null)
//					edgeTo.add(edge.getFrom().replace("{", "\\{"));
//			}
//			// remove duplicates
//			edgeTo = Lists.newArrayList(Sets.newHashSet(edgeTo));
//
//			List<FpsVisualizationNode> nodes = new ArrayList<FpsVisualizationNode>();
//			if (edgeTo.size() > 0) {
//				int start = 0;
//				int cap = 1024;
//				int loaded = 0;
//				// the NPIs in edgeTo may be greater than what is actually in the nodes
//				// collection
//				// so just loop through the expected nodes even if the actual nodes are smaller
//				while (start < edgeTo.size()) {
//					logger.info("start = " + start + ", loaded = " + loaded);
//					p.put("q",
//							"id:(" + StringUtils
//									.join((edgeTo.size() > cap
//											? Lists.newArrayList(edgeTo).subList(start,
//													cap + loaded < edgeTo.size() ? cap + loaded : edgeTo.size())
//											: edgeTo), " ")
//									+ ")");
//					p.put("fl", "*,subj_prvdr_role:label");
//					p.put("rows", ranking == -1 ? "1024" : "500");
//					showParams(p);
//					logger.info("query dme nodes start with " + ranking);
//					response = solrClient.query(collVizDmeNodes, new MapSolrParams(p), METHOD.POST);
//					logger.info("query dme nodes complete");
//
//					nodes.addAll(response.getBeans(FpsVisualizationNode.class));
//					loaded += nodes.size();
//					start += cap + 1;
//				}
//
////				nodes = ranking > -1 && nodes.size() > 22 ? nodes.subList(0, 22) : nodes;
//
//				FpsVisualizationNode parentNode = new FpsVisualizationNode();
//				parentNode.setId(subjId);
//				if (!nodes.contains(parentNode) && ranking == 1) {
//					p.put("q", "id:" + subjId);
//					p.put("fl", "*,subj_prvdr_role:label");
//					p.put("rows", "1");
//					showParams(p);
//					logger.info("query parent dme nodes start with " + ranking);
//
//					response = solrClient.query(collVizDmeNodes, new MapSolrParams(p), METHOD.POST);
//					List<FpsVisualizationNode> parentNodes = response.getBeans(FpsVisualizationNode.class);
//					nodes.addAll(parentNodes);
//					logger.info("query parent dme nodes complete");
//				}
//
//			}
//			List<NvUcmSummary> zrData = fpsHubDao.findUcmSummaryForNpis(edgeTo);
//			for (FpsVisualizationNode node : nodes) {
//				NvUcmSummary template = new NvUcmSummary();
//				template.setNpi(node.getNpi());
//				if (zrData.contains(template)) {
//					node.setZr(zrData.get(zrData.indexOf(template)).getZrStatus());
//					node.setInvestigations(zrData.get(zrData.indexOf(template)).getCaseStatus());
//					node.setLeadInd(zrData.get(zrData.indexOf(template)).getLeadInd());
//				}
//
//			}
//			viz.setNodes(nodes);
//		} catch (SolrServerException e) {
//			logger.log(Level.SEVERE, "solr error loading viz dme data", e);
//		} catch (IOException e) {
//			logger.log(Level.SEVERE, "io solr error loading viz dme data", e);
//		}

		return viz;
	}

	private List<FpsVisualizationEdge> loadDmeEdges(List<FpsVisualizationEdge> srcEdges, int tier, boolean export)
			throws IOException {

		List<FpsVisualizationEdge> edges = new ArrayList<FpsVisualizationEdge>();
		List<String> founds = new ArrayList<String>();

//		for (FpsVisualizationEdge edge : srcEdges) {
//			Map<String, String> p = new HashMap<String, String>();
//			String to = edge.getTo();
//			if (!founds.contains(to) && (export || (!export && StringUtils.isNumeric(to)))) {
//				// data can contain { since we receive it like that. Just escape it, don't
//				// remove it.
//				founds.add(to.replace("{", "\\{"));
//			}
//		}
//		Map<String, String> p = new HashMap<String, String>();
//// search only NPIs.  Could use "label" but it's currently not index in Solr
//		String exportStr = export ? " " : " AND -label:referring_to_bene  AND dst:/[0-9]+/ AND src:/[0-9]+/";
////		p.put("q", "src:(" + StringUtils.join(founds, " ") + ")" + exportStr + " AND ranking:[" + rankingBucketMin + " TO " + rankingBucketMax+ "]");
//		p.put("q", "src:(" + StringUtils.join(founds, " ") + ")" + exportStr + " AND ranking:[0 TO 66] ");
//		p.put("rows", "2000");
//		p.put("sort", "ranking asc");
//		// the solr ranking is obsolete, so we make our own ranking based on
//		// relationship level.
////		String fl = "*,ranking:[value t=int v=" + (tier > 0 ? tier : 1) + "]";
////		if (!export) {
////			fl += ",label:[value v='']";
////		}
////		p.put("fl", fl);
//
//		showParams(p);
//		QueryResponse response = solrClient.query(collVizDmeEdges, new MapSolrParams(p), METHOD.GET);
//
//		edges = response.getBeans(FpsVisualizationEdge.class);
//		logger.info("dme edges found for tier " + (tier + 1) + ": " + edges.size());
//		// if the subject provider is a referring (vs billing) provider
//		// load the tiers above and below that NPI. Otherwise load 2
//		// tiers below.
//		boolean isReferring = false;
//		if (tier == 0) {
//			for (FpsVisualizationEdge edge : edges) {
//				if (edge.getLabel().startsWith("referring")) {
//					isReferring = true;
//					break;
//				}
//			}
//		}
//		if (isReferring) {
//			logger.info("referring dme found, loading one tier above and below");
//			edges.addAll(loadDmeEdgesReverse(edges, -1, false, srcEdges));
//			edges.addAll(loadDmeEdges(edges, 2, export));
//		} else {
//
//			logger.info("billing dme found, two tiers below at tier " + tier);
//
//			if (edges.size() > 0 && tier < 2) {
//				edges.addAll(loadDmeEdges(edges, tier == 0 ? 1 : tier + 1, export));
//
//			}
//		}

		return edges;

	}

	private List<FpsVisualizationEdge> loadDmeEdgesReverse(List<FpsVisualizationEdge> srcEdges, int tier,
			boolean export, List<FpsVisualizationEdge> rootEdges) throws  IOException {

		List<FpsVisualizationEdge> edges = new ArrayList<FpsVisualizationEdge>();
//		List<String> founds = new ArrayList<String>();
//		srcEdges.addAll(rootEdges);
//		for (FpsVisualizationEdge edge : srcEdges) {
//			Map<String, String> p = new HashMap<String, String>();
//			String to = edge.getTo();
//			if (!founds.contains(to) && (export || (!export && StringUtils.isNumeric(to)))) {
//				// data can contain { since we receive it like that. Just escape it, don't
//				// remove it.
//				founds.add(to.replace("{", "\\{"));
//			}
//		}
//		Map<String, String> p = new HashMap<String, String>();
//// search only NPIs.  Could use "label" but it's currently not index in Solr
//		String exportStr = export ? " " : " AND -label:referring_to_bene  AND dst:/[0-9]+/ AND src:/[0-9]+/";
////		p.put("q", "src:(" + StringUtils.join(founds, " ") + ")" + exportStr + " AND ranking:[" + rankingBucketMin + " TO " + rankingBucketMax+ "]");
//		p.put("q", "dst:(" + StringUtils.join(founds, " ") + ")" + exportStr + " AND ranking:[0 TO 66] ");
//		p.put("rows", "2000");
//		p.put("sort", "ranking asc");
//
//		showParams(p);
//		QueryResponse response = solrClient.query(collVizDmeEdges, new MapSolrParams(p), METHOD.GET);
//
//		edges = response.getBeans(FpsVisualizationEdge.class);

		return edges;

	}

}
