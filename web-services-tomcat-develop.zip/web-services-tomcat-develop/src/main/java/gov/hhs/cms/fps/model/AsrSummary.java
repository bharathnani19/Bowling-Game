/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize.Inclusion;

import gov.hhs.cms.fps.model.generated.FpsPrvdrAnlysJurisdiction;
import gov.hhs.cms.fps.util.NAStringSerializer;

// TODO: Auto-generated Javadoc
/**
 * The Class AsrSummary.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrSummary implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6243899877270429019L;

	private String asrAlertStatus;
	
	/** The group npi. */
	private String groupNpi;

	/** The type. */
	private String type;

	/** The system tags. */
	private List<AsrSysTagItem> systemTags;

	/** The claim types. */
	private List<AsrSummaryClaimType> claimTypes;

	/** The cost. */
	private String legacyCost;

	/** The risk score. */
	private String riskScore90;
	private String riskScore180;
	private String riskScore365;
	private String riskScoreTrend;
	private Double prevPriorityScore;

	private Integer legacyScore;

	/** The alert lines cnt. */
	private long alertLinesCnt;

	/** The alerts. */
	private List<AsrSummaryAlert> alerts;

	/** The alerts. */
	private List<AsrSummaryAlert> currentAlerts;
	private List<AsrSummaryAlert> recentAlerts;
	private List<AsrSummaryAlert> priorityAlerts;

	/** The total dual benes cnt. */
	private double totalDualBenesCnt;

	/** The dual bene pct. */
	private Double dualBenePct;

	/** The unique procedures. */
	private Long uniqueProcedures;

	/** The procedures. */
	private List<AsrSummaryProcedure> procedures;

	/** The subject zone cost. */
	private Double subjectZoneCost;
	/** The p1  cost. */
	private String p1Cost;
	/** The assigned zone cd. */
	private List<FpsZone> assignedZoneCds;

	/** The assigned to user id. */
	private String assignedToUserId;

	private List<FpsUser> assignedToUserIds;

	/** The open lead invest ind. */
	private String openLeadInvestInd;
	private List<AsrSummaryLeadInv> openLeadInvest;
	private List<AsrDetailLead> openLeadInvest2;
	private List<AsrDetailUcmEntity> leadInvActions;
	private List<AsrDetailUcmEntity> leadInvActivities;
	private List<AsrDetailUcmEntity> leadInvRatings;
	/** The ptan cnt. */
	private long ptanCnt;

	private String loggedInUserId;

	/** The specialty cnt. */
	private int specialtyCnt;

	/** The specialties. */
	private List<AsrSummarySpecialty> specialties;

	/** The activities. */
	private List<AsrSummaryActivity> activities;

	/** The actions. */
	private List<AsrSummaryAction> actions;

	/** The barried to action cd. */
	private List<AsrSummaryBarrier> barrierToActionCds;

	/** The ruling change reason cd. */
	private List<AsrSummaryRulingChangeReason> rulingChangeReasons;

	/** The not subject change ind. */
	private String notSuspectChangeInd;

	/** The not suspect reason. */
	private String notSuspectReason;

	/** The last update dt. */
	private String lastUpdateDt;

	private Integer userCnt;
	private Integer activityCnt;
	private Integer assignedZoneCnt;
	private Integer barrierCdCnt;
	private Integer alertCnt;
	private Integer actionCnt;
	private Integer investCnt;
	private AsrSummaryPartD partD;
	private String riskScoreModDt;
	private String priorityScoreModDt;
	private List<FpsCommonPtan> ptans;

	private String riskScoreDelta;
	private String priorityScoreDelta;

	private List<AsrPriorityScore> priorityCriteria;

	private List<AsrPrioritizeItem> priorities;

	private List<AsrGenericCode> drugClasses;

	private List<AsrGenericCode> cityStates;

	private Integer cityStateCnt;
	private Integer drugClassCnt;

	private FpsGeoProvider address;

	private String hasPartD = "N";

	private String revocationDate;
	private String revocationDesc;
	private String ucmAsrId = "N/A";
	private String enrollmentId;
	private List<AsrGenericCodeDesc> enrollmentIds;

	private MedicaidInfo medicaidInfo;
	private String aps = "N";
	private String showMacEduReport = "N";
	private String showUpicEduReport = "N";
	private String showChowReport = "N";
	private String nonAlertedPrvdrInd;
	private String riskScoreMethod;

	// provider analysis fields
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	private Date extractDt;
	/** The asr id. */
	private String asrId;
	@JsonSerialize(nullsUsing = NAStringSerializer.class, using = NAStringSerializer.class)
	private String mac;
	@JsonSerialize(nullsUsing = NAStringSerializer.class, using = NAStringSerializer.class)
	private String macCntrctrNum;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private int asrDbid;
	@JsonSerialize(nullsUsing = NAStringSerializer.class, using = NAStringSerializer.class)
	private String clmTypeTxt;
	private String partAInd;
	private String partBInd;
	private String partDInd;
	private String dmeInd;
	/** The name. */
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String name;
	private String revocation = "N";
	private String riskScore;
	private Double priorityScore;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String newAlerts;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String p1NewAlerts;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String agedAlerts;
	private String medicaid = "Y";
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String cost;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String actionability;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String timeliness;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String postEdInd = "Y";
	/** The subject state cd. */
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String subjectStateCd;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	private String relLastAlertDt;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	private String lastAlertDt;
	/** The subject zone cd. */
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String subjectZoneCd;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String p1SubjZoneCd;
	/** The claim lines cnt. */
	private long claimLinesCnt;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String claimLinesDCnt;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String beneDCnt;

	/** The crossover lines cnt. */
	private String crossoverLinesCnt;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	private String createdDt;
	/** The unique alert benes cnt. */
	@JsonSerialize(nullsUsing = NAStringSerializer.class)

	private String uniqueAlertBenesCnt;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String submitAmt;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String totalPayment;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String submitDAmt;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String totalPaymentD;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	private String earliestClmDt;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	private String lastClmDt;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String prvdrState;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String enrollmentStus;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String enrollmentStusDesc;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String prvdrPlaceNm;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	private String lastEduDt;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String billAfterEduInd;
	@JsonSerialize(nullsUsing = NAStringSerializer.class, using = NAStringSerializer.class)
	private String clmCntrctrNum;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String fraudTypeDesc;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String biuCategory;
	private Integer biuComplaintsCnt;
	private Integer biuComplaints90Cnt;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String exclusion;
	private String prioritizedMyZone = "N";
	private String prioritizedOtherZone = "N";
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String ucmCaseStus;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String mostRecentUcmClsdDt;
	private String leadInd;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String ucmSummary;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String zrType;
	@JsonSerialize(nullsUsing = NAStringSerializer.class, using = NAStringSerializer.class)
	private String zrCaseIds;
	@JsonSerialize(nullsUsing = NAStringSerializer.class, using = NAStringSerializer.class)
	private String cncStus;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String ucmCaseIds;
	@JsonSerialize(nullsUsing = NAStringSerializer.class, using = NAStringSerializer.class)
	private String specialtyTxt;

	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	@JsonSerialize(nullsUsing = NAStringSerializer.class, using = NAStringSerializer.class)
	private String lastAlertClmDt;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String prvdrEduProvBy;
	@JsonSerialize(nullsUsing = NAStringSerializer.class, using = NAStringSerializer.class)
	private String topCityStateTxt;
	private Integer listItemId;
	
	@JsonSerialize(nullsUsing = NAStringSerializer.class, using = NAStringSerializer.class)
	private String lastDateOfTpeEducation;
	@JsonSerialize(nullsUsing = NAStringSerializer.class, using = NAStringSerializer.class)

	private String tpeReviewRnd;
	@JsonSerialize(nullsUsing = NAStringSerializer.class, using = NAStringSerializer.class)

	private String tpeEduOffered;
	@JsonSerialize(nullsUsing = NAStringSerializer.class, using = NAStringSerializer.class)

	private String tpeReviewTopic;
	@JsonSerialize(nullsUsing = NAStringSerializer.class, using = NAStringSerializer.class)

	private String tpeRefRsn;

	private Set<FpsPrvdrAnlysJurisdiction> fpsPrvdrAnlysJurisdictions;
	
	private String wsLabel;
	private String exLabel;
	private String hasExclusionHistory;
	
	// medicaid
	@JsonSerialize(nullsUsing = NAStringSerializer.class)

	private String mdcdSpecialty;	
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String mdcdSvcType;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String mdcdSvcSubCat;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String mdcdEnrollmentStatus;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	private String mdcdLastAlertDt;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	private String mdcdLastClmDt;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String mdcdSubmitAmt;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String mdcdTotalPmt;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private Integer mdcdRecipientCnt;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private Integer mdcdClmCnt;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String mdcdBillingNpi;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String mdcdRiskScore;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String mdcdNewAlerts;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String mdcdAgedAlerts;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String mdcdStates;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String pathToEduInd;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String acoInd;
	
	
	
	
	@JsonSerialize(nullsUsing = NAStringSerializer.class)

	private Integer relatedAsrCnt;
	private String dualBeneCntInd;
	
	private String p1RiskScore;
	
	// FPS-29253
	private List<AsrDetailTotalCostZone> atRiskJrsdctns;

	public Integer getUserCnt() {
		return userCnt;
	}

	public void setUserCnt(Integer userCnt) {
		this.userCnt = userCnt;
	}

	public Integer getActivityCnt() {
		return activityCnt;
	}

	public void setActivityCnt(Integer activityCnt) {
		this.activityCnt = activityCnt;
	}

	public Integer getAssignedZoneCnt() {
		return assignedZoneCnt;
	}

	public void setAssignedZoneCnt(Integer assignedZoneCnt) {
		this.assignedZoneCnt = assignedZoneCnt;
	}

	public Integer getBarrierCdCnt() {
		return barrierCdCnt;
	}

	public void setBarrierCdCnt(Integer barrierCdCnt) {
		this.barrierCdCnt = barrierCdCnt;
	}

	public Integer getAlertCnt() {
		return alertCnt;
	}

	public void setAlertCnt(Integer alertCnt) {
		this.alertCnt = alertCnt;
	}

	public Integer getActionCnt() {
		return actionCnt;
	}

	public void setActionCnt(Integer actionCnt) {
		this.actionCnt = actionCnt;
	}

	public Integer getInvestCnt() {
		return investCnt;
	}

	public void setInvestCnt(Integer investCnt) {
		this.investCnt = investCnt;
	}

	public Integer getProcedureCnt() {
		return procedureCnt;
	}

	public void setProcedureCnt(Integer procedureCnt) {
		this.procedureCnt = procedureCnt;
	}

	public Integer getClaimTypeCnt() {
		return claimTypeCnt;
	}

	public void setClaimTypeCnt(Integer claimTypeCnt) {
		this.claimTypeCnt = claimTypeCnt;
	}

	private Integer procedureCnt;
	private Integer claimTypeCnt;

	/**
	 * Gets the asr id.
	 *
	 * @return the asr id
	 */
	public String getAsrId() {
		return asrId;
	}

	/**
	 * Sets the asr id.
	 *
	 * @param asrId the new asr id
	 */
	public void setAsrId(String asrId) {
		this.asrId = asrId;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the group npi.
	 *
	 * @return the group npi
	 */
	public String getGroupNpi() {
		return groupNpi;
	}

	/**
	 * Sets the group npi.
	 *
	 * @param groupNpi the new group npi
	 */
	public void setGroupNpi(String groupNpi) {
		this.groupNpi = groupNpi;
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Gets the system tags.
	 *
	 * @return the system tags
	 */
	public List<AsrSysTagItem> getSystemTags() {
		return systemTags;
	}

	/**
	 * Sets the system tags.
	 *
	 * @param systemTags the new system tags
	 */
	public void setSystemTags(List<AsrSysTagItem> systemTags) {
		this.systemTags = systemTags;
	}

	/**
	 * Gets the claim types.
	 *
	 * @return the claim types
	 */
	public List<AsrSummaryClaimType> getClaimTypes() {
		return claimTypes;
	}

	/**
	 * Sets the claim types.
	 *
	 * @param claimTypes the new claim types
	 */
	public void setClaimTypes(List<AsrSummaryClaimType> claimTypes) {
		this.claimTypes = claimTypes;
	}

	/**
	 * Gets the claim lines cnt.
	 *
	 * @return the claim lines cnt
	 */
	public long getClaimLinesCnt() {
		return claimLinesCnt;
	}

	/**
	 * Sets the claim lines cnt.
	 *
	 * @param claimLinesCnt the new claim lines cnt
	 */
	public void setClaimLinesCnt(long claimLinesCnt) {
		this.claimLinesCnt = claimLinesCnt;
	}

	/**
	 * Gets the crossover lines cnt.
	 *
	 * @return the crossover lines cnt
	 */
	public String getCrossoverLinesCnt() {
		return crossoverLinesCnt;
	}

	/**
	 * Sets the crossover lines cnt.
	 *
	 * @param crossoverLinesCnt the new crossover lines cnt
	 */
	public void setCrossoverLinesCnt(String crossoverLinesCnt) {
		this.crossoverLinesCnt = crossoverLinesCnt;
	}

	/**
	 * Gets the cost.
	 *
	 * @return the cost
	 */
	public String getCost() {
		return cost;
	}

	/**
	 * Sets the cost.
	 *
	 * @param cost the new cost
	 */
	public void setCost(String cost) {
		this.cost = cost;
	}

	/**
	 * Gets the risk score.
	 *
	 * @return the risk score
	 */
	public String getRiskScore() {
		return riskScore;
	}

	/**
	 * Sets the risk score.
	 *
	 * @param riskScore the new risk score
	 */
	public void setRiskScore(String riskScore) {
		this.riskScore = riskScore;
	}

	/**
	 * Gets the alert lines cnt.
	 *
	 * @return the alert lines cnt
	 */
	public long getAlertLinesCnt() {
		return alertLinesCnt;
	}

	/**
	 * Sets the alert lines cnt.
	 *
	 * @param alertLinesCnt the new alert lines cnt
	 */
	public void setAlertLinesCnt(long alertLinesCnt) {
		this.alertLinesCnt = alertLinesCnt;
	}

	/**
	 * Gets the alerts.
	 *
	 * @return the alerts
	 */
	public List<AsrSummaryAlert> getAlerts() {
		return alerts;
	}

	/**
	 * Sets the alerts.
	 *
	 * @param alerts the new alerts
	 */
	public void setAlerts(List<AsrSummaryAlert> alerts) {
		this.alerts = alerts;
	}

	/**
	 * Gets the unique alert benes cnt.
	 *
	 * @return the unique alert benes cnt
	 */
	public String getUniqueAlertBenesCnt() {
		return uniqueAlertBenesCnt;
	}

	/**
	 * Sets the unique alert benes cnt.
	 *
	 * @param uniqueAlertBenesCnt the new unique alert benes cnt
	 */
	public void setUniqueAlertBenesCnt(String uniqueAlertBenesCnt) {
		this.uniqueAlertBenesCnt = uniqueAlertBenesCnt;
	}

	/**
	 * Gets the total dual benes cnt.
	 *
	 * @return the total dual benes cnt
	 */
	public double getTotalDualBenesCnt() {
		return totalDualBenesCnt;
	}

	/**
	 * Sets the total dual benes cnt.
	 *
	 * @param totalDualBenesCnt the new total dual benes cnt
	 */
	public void setTotalDualBenesCnt(double totalDualBenesCnt) {
		this.totalDualBenesCnt = totalDualBenesCnt;
	}

	/**
	 * Gets the dual bene pct.
	 *
	 * @return the dual bene pct
	 */
	public Double getDualBenePct() {
		return dualBenePct;
	}

	/**
	 * Sets the dual bene pct.
	 *
	 * @param dualBenePct the new dual bene pct
	 */
	public void setDualBenePct(Double dualBenePct) {
		this.dualBenePct = dualBenePct;
	}

	/**
	 * Gets the unique procedures.
	 *
	 * @return the unique procedures
	 */
	public Long getUniqueProcedures() {
		return uniqueProcedures;
	}

	/**
	 * Sets the unique procedures.
	 *
	 * @param uniqueProcedures the new unique procedures
	 */
	public void setUniqueProcedures(Long uniqueProcedures) {
		this.uniqueProcedures = uniqueProcedures;
	}

	/**
	 * Gets the procedures.
	 *
	 * @return the procedures
	 */
	public List<AsrSummaryProcedure> getProcedures() {
		return procedures;
	}

	/**
	 * Sets the procedures.
	 *
	 * @param procedures the new procedures
	 */
	public void setProcedures(List<AsrSummaryProcedure> procedures) {
		this.procedures = procedures;
	}

	/**
	 * Gets the subject state cd.
	 *
	 * @return the subject state cd
	 */
	public String getSubjectStateCd() {
		return subjectStateCd;
	}

	/**
	 * Sets the subject state cd.
	 *
	 * @param subjectStateCd the new subject state cd
	 */
	public void setSubjectStateCd(String subjectStateCd) {
		this.subjectStateCd = subjectStateCd;
	}

	/**
	 * Gets the subject zone cd.
	 *
	 * @return the subject zone cd
	 */
	public String getSubjectZoneCd() {
		return subjectZoneCd;
	}

	/**
	 * Sets the subject zone cd.
	 *
	 * @param subjectZoneCd the new subject zone cd
	 */
	public void setSubjectZoneCd(String subjectZoneCd) {
		this.subjectZoneCd = subjectZoneCd;
	}

	/**
	 * Gets the subject zone cost.
	 *
	 * @return the subject zone cost
	 */
	public Double getSubjectZoneCost() {
		return subjectZoneCost;
	}

	/**
	 * Sets the subject zone cost.
	 *
	 * @param subjectZoneCost the new subject zone cost
	 */
	public void setSubjectZoneCost(Double subjectZoneCost) {
		this.subjectZoneCost = subjectZoneCost;
	}

	/**
	 * Gets the assigned zone cd.
	 *
	 * @return the assigned zone cd
	 */
	public List<FpsZone> getAssignedZoneCds() {
		return assignedZoneCds;
	}

	/**
	 * Sets the assigned zone cd.
	 *
	 * @param assignedZoneCds the new assigned zone cd
	 */
	public void setAssignedZoneCds(List<FpsZone> assignedZoneCds) {
		this.assignedZoneCds = assignedZoneCds;
	}

	/**
	 * Gets the assigned to user id.
	 *
	 * @return the assigned to user id
	 */
	public String getAssignedToUserId() {
		return assignedToUserId;
	}

	/**
	 * Sets the assigned to user id.
	 *
	 * @param assignedToUserId the new assigned to user id
	 */
	public void setAssignedToUserId(String assignedToUserId) {
		this.assignedToUserId = assignedToUserId;
	}

	/**
	 * Gets the open lead invest ind.
	 *
	 * @return the open lead invest ind
	 */
	public String getOpenLeadInvestInd() {
		return openLeadInvestInd;
	}

	/**
	 * Sets the open lead invest ind.
	 *
	 * @param openLeadInvestInd the new open lead invest ind
	 */
	public void setOpenLeadInvestInd(String openLeadInvestInd) {
		this.openLeadInvestInd = openLeadInvestInd;
	}

	/**
	 * Gets the ptan cnt.
	 *
	 * @return the ptan cnt
	 */
	public long getPtanCnt() {
		return ptanCnt;
	}

	/**
	 * Sets the ptan cnt.
	 *
	 * @param ptanCnt the new ptan cnt
	 */
	public void setPtanCnt(long ptanCnt) {
		this.ptanCnt = ptanCnt;
	}

	/**
	 * Gets the specialty cnt.
	 *
	 * @return the specialty cnt
	 */
	public int getSpecialtyCnt() {
		return specialtyCnt;
	}

	/**
	 * Sets the specialty cnt.
	 *
	 * @param specialtyCnt the new specialty cnt
	 */
	public void setSpecialtyCnt(int specialtyCnt) {
		this.specialtyCnt = specialtyCnt;
	}

	/**
	 * Gets the specialties.
	 *
	 * @return the specialties
	 */
	public List<AsrSummarySpecialty> getSpecialties() {
		return specialties;
	}

	/**
	 * Sets the specialties.
	 *
	 * @param specialties the new specialties
	 */
	public void setSpecialties(List<AsrSummarySpecialty> specialties) {
		this.specialties = specialties;
	}

	/**
	 * Gets the activities.
	 *
	 * @return the activities
	 */
	public List<AsrSummaryActivity> getActivities() {
		return activities;
	}

	/**
	 * Sets the activities.
	 *
	 * @param activities the new activities
	 */
	public void setActivities(List<AsrSummaryActivity> activities) {
		this.activities = activities;
	}

	/**
	 * Gets the actions.
	 *
	 * @return the actions
	 */
	public List<AsrSummaryAction> getActions() {
		return actions;
	}

	/**
	 * Sets the actions.
	 *
	 * @param actions the new actions
	 */
	public void setActions(List<AsrSummaryAction> actions) {
		this.actions = actions;
	}

	/**
	 * Gets the barried to action cd.
	 *
	 * @return the barried to action cd
	 */
	public List<AsrSummaryBarrier> getBarrierToActionCds() {
		return barrierToActionCds;
	}

	/**
	 * Sets the barried to action cd.
	 *
	 * @param barrierToActionCds the new barried to action cd
	 */
	public void setBarrierToActionCds(List<AsrSummaryBarrier> barrierToActionCds) {
		this.barrierToActionCds = barrierToActionCds;
	}

	/**
	 * Gets the ruling change reason cd.
	 *
	 * @return the ruling change reason cd
	 */
	public List<AsrSummaryRulingChangeReason> getRulingChangeReasons() {
		return rulingChangeReasons;
	}

	/**
	 * Sets the ruling change reason cd.
	 *
	 * @param rulingChangeReasons the new ruling change reason cd
	 */
	public void setRulingChangeReasons(List<AsrSummaryRulingChangeReason> rulingChangeReasons) {
		this.rulingChangeReasons = rulingChangeReasons;
	}

	/**
	 * Gets the not subject change ind.
	 *
	 * @return the not subject change ind
	 */
	public String getNotSuspectChangeInd() {
		return notSuspectChangeInd;
	}

	/**
	 * Sets the not subject change ind.
	 *
	 * @param notSuspectChangeInd the new not subject change ind
	 */
	public void setNotSuspectChangeInd(String notSuspectChangeInd) {
		this.notSuspectChangeInd = notSuspectChangeInd;
	}

	/**
	 * Gets the not suspect reason.
	 *
	 * @return the not suspect reason
	 */
	public String getNotSuspectReason() {
		return notSuspectReason;
	}

	/**
	 * Sets the not suspect reason.
	 *
	 * @param notSuspectReason the new not suspect reason
	 */
	public void setNotSuspectReason(String notSuspectReason) {
		this.notSuspectReason = notSuspectReason;
	}

	/**
	 * Gets the last update dt.
	 *
	 * @return the last update dt
	 */
	public String getLastUpdateDt() {
		return lastUpdateDt;
	}

	/**
	 * Sets the last update dt.
	 *
	 * @param lastUpdateDt the new last update dt
	 */
	public void setLastUpdateDt(String lastUpdateDt) {
		this.lastUpdateDt = lastUpdateDt;
	}

	/**
	 * Gets the created dt.
	 *
	 * @return the created dt
	 */
	public String getCreatedDt() {
		return createdDt;
	}

	/**
	 * Sets the created dt.
	 *
	 * @param createdDt the new created dt
	 */
	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}

	public List<AsrSummaryLeadInv> getOpenLeadInvest() {
		return openLeadInvest;
	}

	public void setOpenLeadInvest(List<AsrSummaryLeadInv> openLeadInvest) {
		this.openLeadInvest = openLeadInvest;
	}

	public String getLoggedInUserId() {
		return loggedInUserId;
	}

	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}

	public int getAsrDbid() {
		return asrDbid;
	}

	public void setAsrDbid(int asrDbid) {
		this.asrDbid = asrDbid;
	}

	public Integer getLegacyScore() {
		return legacyScore;
	}

	public void setLegacyScore(Integer legacyScore) {
		this.legacyScore = legacyScore;
	}

	public List<FpsUser> getAssignedToUserIds() {
		return assignedToUserIds;
	}

	public void setAssignedToUserIds(List<FpsUser> assignedToUserIds) {
		this.assignedToUserIds = assignedToUserIds;
	}

	public String getLegacyCost() {
		return legacyCost;
	}

	public void setLegacyCost(String legacyCost) {
		this.legacyCost = legacyCost;
	}

	public List<AsrSummaryAlert> getCurrentAlerts() {
		return currentAlerts;
	}

	public void setCurrentAlerts(List<AsrSummaryAlert> currentAlerts) {
		this.currentAlerts = currentAlerts;
	}

	public List<AsrPrioritizeItem> getPriorities() {
		return priorities;
	}

	public void setPriorities(List<AsrPrioritizeItem> priorities) {
		this.priorities = priorities;
	}

	public String getAsrAlertStatus() {
		return asrAlertStatus;
	}

	public void setAsrAlertStatus(String asrAlertStatus) {
		this.asrAlertStatus = asrAlertStatus;
	}

	public AsrSummaryPartD getPartD() {
		return partD;
	}

	public void setPartD(AsrSummaryPartD partD) {
		this.partD = partD;
	}

	public String getMac() {
		return mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}

	public String getRiskScoreModDt() {
		return riskScoreModDt;
	}

	public void setRiskScoreModDt(String riskScoreModDt) {
		this.riskScoreModDt = riskScoreModDt;
	}

	public List<FpsCommonPtan> getPtans() {
		return ptans;
	}

	public void setPtans(List<FpsCommonPtan> ptans) {
		this.ptans = ptans;
	}

	public String getRiskScoreDelta() {
		return riskScoreDelta;
	}

	public void setRiskScoreDelta(String riskScoreDelta) {
		this.riskScoreDelta = riskScoreDelta;
	}

	public List<AsrSummaryAlert> getRecentAlerts() {
		return recentAlerts;
	}

	public void setRecentAlerts(List<AsrSummaryAlert> recentAlerts) {
		this.recentAlerts = recentAlerts;
	}

	public List<AsrSummaryAlert> getPriorityAlerts() {
		return priorityAlerts;
	}

	public void setPriorityAlerts(List<AsrSummaryAlert> priorityAlerts) {
		this.priorityAlerts = priorityAlerts;
	}

	public String getPriorityScoreModDt() {
		return priorityScoreModDt;
	}

	public void setPriorityScoreModDt(String priorityScoreModDt) {
		this.priorityScoreModDt = priorityScoreModDt;
	}

	public String getPriorityScoreDelta() {
		return priorityScoreDelta;
	}

	public void setPriorityScoreDelta(String priorityScoreDelta) {
		this.priorityScoreDelta = priorityScoreDelta;
	}

	public Double getPriorityScore() {
		return priorityScore;
	}

	public void setPriorityScore(Double priorityScore) {
		this.priorityScore = priorityScore;
	}

	public List<AsrPriorityScore> getPriorityCriteria() {
		return priorityCriteria;
	}

	public void setPriorityCriteria(List<AsrPriorityScore> priorityCriteria) {
		this.priorityCriteria = priorityCriteria;
	}

	public String getRiskScore90() {
		return riskScore90;
	}

	public void setRiskScore90(String riskScore90) {
		this.riskScore90 = riskScore90;
	}

	public String getRiskScore180() {
		return riskScore180;
	}

	public void setRiskScore180(String riskScore180) {
		this.riskScore180 = riskScore180;
	}

	public String getRiskScore365() {
		return riskScore365;
	}

	public void setRiskScore365(String riskScore365) {
		this.riskScore365 = riskScore365;
	}

	public String getRiskScoreTrend() {
		return riskScoreTrend;
	}

	public void setRiskScoreTrend(String riskScoreTrend) {
		this.riskScoreTrend = riskScoreTrend;
	}

	public Double getPrevPriorityScore() {
		return prevPriorityScore;
	}

	public void setPrevPriorityScore(Double prevPriorityScore) {
		this.prevPriorityScore = prevPriorityScore;
	}

	public List<AsrGenericCode> getDrugClasses() {
		return drugClasses;
	}

	public void setDrugClasses(List<AsrGenericCode> drugClasses) {
		this.drugClasses = drugClasses;
	}

	public List<AsrGenericCode> getCityStates() {
		return cityStates;
	}

	public void setCityStates(List<AsrGenericCode> cityStates) {
		this.cityStates = cityStates;
	}

	public String getZrType() {
		return zrType;
	}

	public void setZrType(String zrType) {
		this.zrType = zrType;
	}

	public Integer getDrugClassCnt() {
		return drugClassCnt;
	}

	public void setDrugClassCnt(Integer drugClassCnt) {
		this.drugClassCnt = drugClassCnt;
	}

	public Integer getCityStateCnt() {
		return cityStateCnt;
	}

	public void setCityStateCnt(Integer cityStateCnt) {
		this.cityStateCnt = cityStateCnt;
	}

	public FpsGeoProvider getAddress() {
		return address;
	}

	public void setAddress(FpsGeoProvider address) {
		this.address = address;
	}

	public String getRevocation() {
		return revocation;
	}

	public void setRevocation(String revocation) {
		this.revocation = revocation;
	}

	public String getMedicaid() {
		return medicaid;
	}

	public void setMedicaid(String medicaid) {
		this.medicaid = medicaid;
	}

	public String getUcmAsrId() {
		return ucmAsrId;
	}

	public void setUcmAsrId(String ucmAsrId) {
		this.ucmAsrId = ucmAsrId;
	}

	public MedicaidInfo getMedicaidInfo() {
		return medicaidInfo;
	}

	public void setMedicaidInfo(MedicaidInfo medicaidInfo) {
		this.medicaidInfo = medicaidInfo;
	}

	public String getRevocationDate() {
		return revocationDate;
	}

	public void setRevocationDate(String revocationDate) {
		this.revocationDate = revocationDate;
	}

	public String getRevocationDesc() {
		return revocationDesc;
	}

	public void setRevocationDesc(String revocationDesc) {
		this.revocationDesc = revocationDesc;
	}

	public List<AsrGenericCodeDesc> getEnrollmentIds() {
		return enrollmentIds;
	}

	public void setEnrollmentIds(List<AsrGenericCodeDesc> enrollmentIds) {
		this.enrollmentIds = enrollmentIds;
	}

	public String getRelLastAlertDt() {
		return relLastAlertDt;
	}

	public void setRelLastAlertDt(String relLastAlertDt) {
		this.relLastAlertDt = relLastAlertDt;
	}

	public String getLastAlertDt() {
		return lastAlertDt;
	}

	public void setLastAlertDt(String lastAlertDt) {
		this.lastAlertDt = lastAlertDt;
	}

	public String getEnrollmentId() {
		return enrollmentId;
	}

	public void setEnrollmentId(String enrollmentId) {
		this.enrollmentId = enrollmentId;
	}

	public List<AsrDetailLead> getOpenLeadInvest2() {
		return openLeadInvest2;
	}

	public void setOpenLeadInvest2(List<AsrDetailLead> openLeadInvest2) {
		this.openLeadInvest2 = openLeadInvest2;
	}

	public List<AsrDetailUcmEntity> getLeadInvActivities() {
		return leadInvActivities;
	}

	public void setLeadInvActivities(List<AsrDetailUcmEntity> leadInvActivities) {
		this.leadInvActivities = leadInvActivities;
	}

	public List<AsrDetailUcmEntity> getLeadInvActions() {
		return leadInvActions;
	}

	public void setLeadInvActions(List<AsrDetailUcmEntity> leadInvActions) {
		this.leadInvActions = leadInvActions;
	}

	public List<AsrDetailUcmEntity> getLeadInvRatings() {
		return leadInvRatings;
	}

	public void setLeadInvRatings(List<AsrDetailUcmEntity> leadInvRatings) {
		this.leadInvRatings = leadInvRatings;
	}

	public String getActionability() {
		return actionability;
	}

	public void setActionability(String actionability) {
		this.actionability = actionability;
	}

	public String getTimeliness() {
		return timeliness;
	}

	public void setTimeliness(String timeliness) {
		this.timeliness = timeliness;
	}

	public String getAps() {
		return aps;
	}

	public void setAps(String aps) {
		this.aps = aps;
	}

	public String getShowMacEduReport() {
		return showMacEduReport;
	}

	public void setShowMacEduReport(String showMacEduReport) {
		this.showMacEduReport = showMacEduReport;
	}

	public String getShowUpicEduReport() {
		return showUpicEduReport;
	}

	public void setShowUpicEduReport(String showUpicEduReport) {
		this.showUpicEduReport = showUpicEduReport;
	}

	public String getShowChowReport() {
		return showChowReport;
	}

	public void setShowChowReport(String showChowReport) {
		this.showChowReport = showChowReport;
	}

	public String getHasPartD() {
		return hasPartD;
	}

	public void setHasPartD(String hasPartD) {
		this.hasPartD = hasPartD;
	}

	public Date getExtractDt() {
		return extractDt;
	}

	public void setExtractDt(Date extractDt) {
		this.extractDt = extractDt;
	}

	public String getClmTypeTxt() {
		return clmTypeTxt;
	}

	public void setClmTypeTxt(String clmTypeTxt) {
		this.clmTypeTxt = clmTypeTxt;
	}

	public String getPartAInd() {
		return partAInd;
	}

	public void setPartAInd(String partAInd) {
		this.partAInd = partAInd;
	}

	public String getPartBInd() {
		return partBInd;
	}

	public void setPartBInd(String partBInd) {
		this.partBInd = partBInd;
	}

	public String getPartDInd() {
		return partDInd;
	}

	public void setPartDInd(String partDInd) {
		this.partDInd = partDInd;
	}

	public String getDmeInd() {
		return dmeInd;
	}

	public void setDmeInd(String dmeInd) {
		this.dmeInd = dmeInd;
	}

	public String getNewAlerts() {
		return newAlerts;
	}

	public void setNewAlerts(String newAlerts) {
		this.newAlerts = newAlerts;
	}

	public String getAgedAlerts() {
		return agedAlerts;
	}

	public void setAgedAlerts(String agedAlerts) {
		this.agedAlerts = agedAlerts;
	}

	public String getSubmitAmt() {
		return submitAmt;
	}

	public void setSubmitAmt(String submitAmt) {
		this.submitAmt = submitAmt;
	}

	public String getTotalPayment() {
		return totalPayment;
	}

	public void setTotalPayment(String totalPayment) {
		this.totalPayment = totalPayment;
	}

	public String getEarliestClmDt() {
		return earliestClmDt;
	}

	public void setEarliestClmDt(String earliestClmDt) {
		this.earliestClmDt = earliestClmDt;
	}

	public String getLastClmDt() {
		return lastClmDt;
	}

	public void setLastClmDt(String lastClmDt) {
		this.lastClmDt = lastClmDt;
	}

	public String getPrvdrState() {
		return prvdrState;
	}

	public void setPrvdrState(String prvdrState) {
		this.prvdrState = prvdrState;
	}


	public String getPrvdrPlaceNm() {
		return prvdrPlaceNm;
	}

	public void setPrvdrPlaceNm(String prvdrPlaceNm) {
		this.prvdrPlaceNm = prvdrPlaceNm;
	}

	public String getLastEduDt() {
		return lastEduDt;
	}

	public void setLastEduDt(String lastEduDt) {
		this.lastEduDt = lastEduDt;
	}

	public String getBillAfterEduInd() {
		return billAfterEduInd;
	}

	public void setBillAfterEduInd(String billAfterEduInd) {
		this.billAfterEduInd = billAfterEduInd;
	}

	public String getClmCntrctrNum() {
		return clmCntrctrNum;
	}

	public void setClmCntrctrNum(String clmCntrctrNum) {
		this.clmCntrctrNum = clmCntrctrNum;
	}

	public String getFraudTypeDesc() {
		return fraudTypeDesc;
	}

	public void setFraudTypeDesc(String fraudTypeDesc) {
		this.fraudTypeDesc = fraudTypeDesc;
	}

	public String getBiuCategory() {
		return biuCategory;
	}

	public void setBiuCategory(String biuCategory) {
		this.biuCategory = biuCategory;
	}

	public Integer getBiuComplaintsCnt() {
		return biuComplaintsCnt;
	}

	public void setBiuComplaintsCnt(Integer biuComplaintsCnt) {
		this.biuComplaintsCnt = biuComplaintsCnt;
	}

	public Integer getBiuComplaints90Cnt() {
		return biuComplaints90Cnt;
	}

	public void setBiuComplaints90Cnt(Integer biuComplaints90Cnt) {
		this.biuComplaints90Cnt = biuComplaints90Cnt;
	}

	public String getExclusion() {
		return exclusion;
	}

	public void setExclusion(String exclusion) {
		this.exclusion = exclusion;
	}

	public String getPrioritizedMyZone() {
		return prioritizedMyZone;
	}

	public void setPrioritizedMyZone(String prioritizedMyZone) {
		this.prioritizedMyZone = prioritizedMyZone;
	}

	public String getPrioritizedOtherZone() {
		return prioritizedOtherZone;
	}

	public void setPrioritizedOtherZone(String prioritizedOtherZone) {
		this.prioritizedOtherZone = prioritizedOtherZone;
	}

	public String getUcmCaseStus() {
		return ucmCaseStus;
	}

	public void setUcmCaseStus(String ucmCaseStus) {
		this.ucmCaseStus = ucmCaseStus;
	}

	public String getMostRecentUcmClsdDt() {
		return mostRecentUcmClsdDt;
	}

	public void setMostRecentUcmClsdDt(String mostRecentUcmClsdDt) {
		this.mostRecentUcmClsdDt = mostRecentUcmClsdDt;
	}

	public String getLeadInd() {
		return leadInd;
	}

	public void setLeadInd(String leadInd) {
		this.leadInd = leadInd;
	}

	public String getUcmSummary() {
		return ucmSummary;
	}

	public void setUcmSummary(String ucmSummary) {
		this.ucmSummary = ucmSummary;
	}

	public String getZrCaseIds() {
		return zrCaseIds;
	}

	public void setZrCaseIds(String zrCaseIds) {
		this.zrCaseIds = zrCaseIds;
	}

	public Set<FpsPrvdrAnlysJurisdiction> getFpsPrvdrAnlysJurisdictions() {
		return fpsPrvdrAnlysJurisdictions;
	}

	public void setFpsPrvdrAnlysJurisdictions(Set<FpsPrvdrAnlysJurisdiction> fpsPrvdrAnlysJurisdictions) {
		this.fpsPrvdrAnlysJurisdictions = fpsPrvdrAnlysJurisdictions;
	}

	public String getCncStus() {
		return cncStus;
	}

	public void setCncStus(String cncStus) {
		this.cncStus = cncStus;
	}

	public String getUcmCaseIds() {
		return ucmCaseIds;
	}

	public void setUcmCaseIds(String ucmCaseIds) {
		this.ucmCaseIds = ucmCaseIds;
	}

	public String getEnrollmentStus() {
		return enrollmentStus;
	}

	public void setEnrollmentStus(String enrollmentStus) {
		this.enrollmentStus = enrollmentStus;
	}

	public String getClaimLinesDCnt() {
		return claimLinesDCnt;
	}

	public void setClaimLinesDCnt(String claimLinesDCnt) {
		this.claimLinesDCnt = claimLinesDCnt;
	}

	public String getBeneDCnt() {
		return beneDCnt;
	}

	public void setBeneDCnt(String beneDCnt) {
		this.beneDCnt = beneDCnt;
	}

	public String getSubmitDAmt() {
		return submitDAmt;
	}

	public void setSubmitDAmt(String submitDAmt) {
		this.submitDAmt = submitDAmt;
	}

	public String getTotalPaymentD() {
		return totalPaymentD;
	}

	public void setTotalPaymentD(String totalPaymentD) {
		this.totalPaymentD = totalPaymentD;
	}

	public String getSpecialtyTxt() {
		return specialtyTxt;
	}

	public void setSpecialtyTxt(String specialtyTxt) {
		this.specialtyTxt = specialtyTxt;
	}

	public String getLastAlertClmDt() {
		return lastAlertClmDt;
	}

	public void setLastAlertClmDt(String lastAlertClmDt) {
		this.lastAlertClmDt = lastAlertClmDt;
	}

	public String getPrvdrEduProvBy() {
		return prvdrEduProvBy;
	}

	public void setPrvdrEduProvBy(String prvdrEduProvBy) {
		this.prvdrEduProvBy = prvdrEduProvBy;
	}

	public String getTopCityStateTxt() {
		return topCityStateTxt;
	}

	public void setTopCityStateTxt(String topCityStateTxt) {
		this.topCityStateTxt = topCityStateTxt;
	}

	public String getMacCntrctrNum() {
		return macCntrctrNum;
	}

	public void setMacCntrctrNum(String macCntrctrNum) {
		this.macCntrctrNum = macCntrctrNum;
	}

	public Integer getListItemId() {
		return listItemId;
	}

	public void setListItemId(Integer listItemId) {
		this.listItemId = listItemId;
	}

	public String getEnrollmentStusDesc() {
		return enrollmentStusDesc;
	}

	public void setEnrollmentStusDesc(String enrollmentStusDesc) {
		this.enrollmentStusDesc = enrollmentStusDesc;
	}

	public String getPostEdInd() {
		return postEdInd;
	}

	public void setPostEdInd(String postEdInd) {
		this.postEdInd = postEdInd;
	}

	public String getLastDateOfTpeEducation() {
		return lastDateOfTpeEducation;
	}

	public void setLastDateOfTpeEducation(String lastDateOfTpeEducation) {
		this.lastDateOfTpeEducation = lastDateOfTpeEducation;
	}

	public String getTpeReviewRnd() {
		return tpeReviewRnd;
	}

	public void setTpeReviewRnd(String tpeReviewRnd) {
		this.tpeReviewRnd = tpeReviewRnd;
	}

	public String getTpeEduOffered() {
		return tpeEduOffered;
	}

	public void setTpeEduOffered(String tpeEduOffered) {
		this.tpeEduOffered = tpeEduOffered;
	}

	public String getTpeReviewTopic() {
		return tpeReviewTopic;
	}

	public void setTpeReviewTopic(String tpeReviewTopic) {
		this.tpeReviewTopic = tpeReviewTopic;
	}

	public String getTpeRefRsn() {
		return tpeRefRsn;
	}

	public void setTpeRefRsn(String tpeRefRsn) {
		this.tpeRefRsn = tpeRefRsn;
	}

	public String getWsLabel() {
		return wsLabel;
	}

	public void setWsLabel(String wsLabel) {
		this.wsLabel = wsLabel;
	}

	public String getExLabel() {
		return exLabel;
	}

	public void setExLabel(String exLabel) {
		this.exLabel = exLabel;
	}

	public String getHasExclusionHistory() {
		return hasExclusionHistory;
	}

	public void setHasExclusionHistory(String hasExclusionHistory) {
		this.hasExclusionHistory = hasExclusionHistory;
	}

	public Integer getRelatedAsrCnt() {
		return relatedAsrCnt;
	}

	public void setRelatedAsrCnt(Integer relatedAsrCnt) {
		this.relatedAsrCnt = relatedAsrCnt;
	}

	public String getNonAlertedPrvdrInd() {
		return nonAlertedPrvdrInd;
	}

	public void setNonAlertedPrvdrInd(String nonAlertedPrvdrInd) {
		this.nonAlertedPrvdrInd = nonAlertedPrvdrInd;
	}

	public String getDualBeneCntInd() {
		return dualBeneCntInd;
	}

	public void setDualBeneCntInd(String dualBeneCntInd) {
		this.dualBeneCntInd = dualBeneCntInd;
	}

	public String getRiskScoreMethod() {
		return riskScoreMethod;
	}

	public void setRiskScoreMethod(String riskScoreMethod) {
		this.riskScoreMethod = riskScoreMethod;
	}

	public String getMdcdSpecialty() {
		return mdcdSpecialty;
	}

	public void setMdcdSpecialty(String mdcdSpecialty) {
		this.mdcdSpecialty = mdcdSpecialty;
	}

	public String getMdcdSvcType() {
		return mdcdSvcType;
	}

	public void setMdcdSvcType(String mdcdSvcType) {
		this.mdcdSvcType = mdcdSvcType;
	}

	public String getMdcdSvcSubCat() {
		return mdcdSvcSubCat;
	}

	public void setMdcdSvcSubCat(String mdcdSvcSubCat) {
		this.mdcdSvcSubCat = mdcdSvcSubCat;
	}

	public String getMdcdEnrollmentStatus() {
		return mdcdEnrollmentStatus;
	}

	public void setMdcdEnrollmentStatus(String mdcdEnrollmentStatus) {
		this.mdcdEnrollmentStatus = mdcdEnrollmentStatus;
	}

	public String getMdcdLastAlertDt() {
		return mdcdLastAlertDt;
	}

	public void setMdcdLastAlertDt(String mdcdLastAlertDt) {
		this.mdcdLastAlertDt = mdcdLastAlertDt;
	}

	public String getMdcdLastClmDt() {
		return mdcdLastClmDt;
	}

	public void setMdcdLastClmDt(String mdcdLastClmDt) {
		this.mdcdLastClmDt = mdcdLastClmDt;
	}

	public String getMdcdSubmitAmt() {
		return mdcdSubmitAmt;
	}

	public void setMdcdSubmitAmt(String mdcdSubmitAmt) {
		this.mdcdSubmitAmt = mdcdSubmitAmt;
	}

	public String getMdcdTotalPmt() {
		return mdcdTotalPmt;
	}

	public void setMdcdTotalPmt(String mdcdTotalPmt) {
		this.mdcdTotalPmt = mdcdTotalPmt;
	}

	public Integer getMdcdRecipientCnt() {
		return mdcdRecipientCnt;
	}

	public void setMdcdRecipientCnt(Integer mdcdRecipientCnt) {
		this.mdcdRecipientCnt = mdcdRecipientCnt;
	}

	public Integer getMdcdClmCnt() {
		return mdcdClmCnt;
	}

	public void setMdcdClmCnt(Integer mdcdClmCnt) {
		this.mdcdClmCnt = mdcdClmCnt;
	}

	public String getMdcdBillingNpi() {
		return mdcdBillingNpi;
	}

	public void setMdcdBillingNpi(String mdcdBillingNpi) {
		this.mdcdBillingNpi = mdcdBillingNpi;
	}

	public String getMdcdRiskScore() {
		return mdcdRiskScore;
	}

	public void setMdcdRiskScore(String mdcdRiskScore) {
		this.mdcdRiskScore = mdcdRiskScore;
	}

	public String getMdcdNewAlerts() {
		return mdcdNewAlerts;
	}

	public void setMdcdNewAlerts(String mdcdNewAlerts) {
		this.mdcdNewAlerts = mdcdNewAlerts;
	}

	public String getMdcdAgedAlerts() {
		return mdcdAgedAlerts;
	}

	public void setMdcdAgedAlerts(String mdcdAgedAlerts) {
		this.mdcdAgedAlerts = mdcdAgedAlerts;
	}

	public String getMdcdStates() {
		return mdcdStates;
	}

	public void setMdcdStates(String mdcdStates) {
		this.mdcdStates = mdcdStates;
	}

	public String getPathToEduInd() {
		return pathToEduInd;
	}

	public void setPathToEduInd(String pathToEduInd) {
		this.pathToEduInd = pathToEduInd;
	}

	public String getAcoInd() {
		return acoInd;
	}

	public void setAcoInd(String acoInd) {
		this.acoInd = acoInd;
	}

	public String getP1Cost() {
		return p1Cost;
	}

	public void setP1Cost(String p1Cost) {
		this.p1Cost = p1Cost;
	}

	public String getP1NewAlerts() {
		return p1NewAlerts;
	}

	public void setP1NewAlerts(String p1NewAlerts) {
		this.p1NewAlerts = p1NewAlerts;
	}

	public String getP1RiskScore() {
		return p1RiskScore;
	}

	public void setP1RiskScore(String p1RiskScore) {
		this.p1RiskScore = p1RiskScore;
	}

	public String getP1SubjZoneCd() {
		return p1SubjZoneCd;
	}

	public void setP1SubjZoneCd(String p1SubjZoneCd) {
		this.p1SubjZoneCd = p1SubjZoneCd;
	}

	public List<AsrDetailTotalCostZone> getAtRiskJrsdctns() {
		return atRiskJrsdctns;
	}

	public void setAtRiskJrsdctns(List<AsrDetailTotalCostZone> atRiskJrsdctns) {
		this.atRiskJrsdctns = atRiskJrsdctns;
	}

}
