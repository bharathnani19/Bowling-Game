import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import  moment from 'moment';

export function  getIds(ids: string) {
    return ids
        ?.split(/[\s,]+/g)
        .map((x) => x.trim())
        .filter(Boolean);
}
export const formatMessage = (template: string, data: Record<string, any>) => {
    return template.replace(/{(\w+)}/g, (match, key) => {
        return key in data ? data[key] : match;
    });
}

export function minMaxValidator(minKey: string, maxKey: string, errorKey: string): ValidatorFn {
    return (group: AbstractControl): ValidationErrors | null => {
      const minCtrl = group.get(minKey);
      const maxCtrl = group.get(maxKey);
  
      if (!minCtrl || !maxCtrl) return null;
  
      const min = minCtrl.value;
      const max = maxCtrl.value;
  
      if (minCtrl.hasError(errorKey)) {
        const { [errorKey]: _, ...rest } = minCtrl.errors || {};
        minCtrl.setErrors(Object.keys(rest).length ? rest : null);
      }
  
      if (maxCtrl.hasError(errorKey)) {
        const { [errorKey]: _, ...rest } = maxCtrl.errors || {};
        maxCtrl.setErrors(Object.keys(rest).length ? rest : null);
      }
  
      if (min != null && max != null && min > max) {
        minCtrl.setErrors({ ...(minCtrl.errors || {}), [errorKey]: true });
        maxCtrl.setErrors({ ...(maxCtrl.errors || {}), [errorKey]: true });
  
        return { [errorKey]: true };
      }
  
      return null;
    };
  }
  export function dateRangeValidator(minDateKey: string, maxDateKey: string, errorKey: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const startDateControl = control.get(minDateKey);
      const endDateControl = control.get(maxDateKey);
    
      if (!startDateControl || !endDateControl || !startDateControl.value || !endDateControl.value) {
        return null;
      }
    
      const startDate = new Date(startDateControl.value);
      const endDate = new Date(endDateControl.value);
    
      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime()) || startDate > endDate) {
        startDateControl.setErrors({ ...(startDateControl.errors || {}), [errorKey]: true });
        endDateControl.setErrors({ ...(endDateControl.errors || {}), [errorKey]: true });
        return { [errorKey]: true };
      }
    
      // Return null if valid
      return null;
  
    };
  }

  
export const max50Lines = (key:string='',errorKey = 'max50'): ValidatorFn =>
  (c: AbstractControl) => {
    const count = (c.get(key)?.value || '').split('\n').filter(Boolean).length;
    return count > 50 ? { [errorKey]: true } : null;
  };

export const dateRangeLastOneYearValidator = (
	startKey: string,
	endKey: string,
	errorKey: string
): ValidatorFn => (g: AbstractControl) => {
	const startCtrl = g.get(startKey);
	const endCtrl = g.get(endKey);

	if (!startCtrl?.value || !endCtrl?.value) return null;

	const s = moment(startCtrl.value);
	const e = moment(endCtrl.value);
	const today = moment();
	const min = today.clone().subtract(365, 'days');

	const invalid =
		!s.isValid() ||
		!e.isValid() ||
		s.isBefore(min, 'day') ||
		e.isBefore(min, 'day') ||
		s.isAfter(e, 'day');

	[startCtrl, endCtrl].forEach(ctrl =>
		ctrl.setErrors(invalid ? { ...(ctrl.errors || {}), [errorKey]: true } : null)
	);

	return invalid ? { [errorKey]: true } : null;
};
  export function tenDigitPerLineValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!control.value || typeof control.value !== 'string') return null;
      const value = control.value.trim();
      const regex = /^(\d{10})(\n\d{10})*$/;
      return regex.test(value) ? null : { invalidTenDigitLines: true };
    };
  }
  export function biuSearchValidator(biuComplaintsKey: string, biuComplaintDaysKey: string, biuComplaintsErrorKey: string, biuComplaintDaysErrorKey:string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const biuComplaints = control.get(biuComplaintsKey);
      const biuComplaintDays = control.get(biuComplaintDaysKey);
      const biuComplaintsPopulated = biuComplaints?.value && biuComplaints?.value > 0;
      const biuComplaintDaysPopulated = biuComplaintDays?.value && biuComplaintDays?.value.length > 0;
      if ((!biuComplaintsPopulated && !biuComplaintDaysPopulated) || (biuComplaintsPopulated && biuComplaintDaysPopulated) ) {
        biuComplaints?.setErrors(null); 
        biuComplaintDays?.setErrors(null);
        return null;
      }
      if (!biuComplaintsPopulated && biuComplaintDaysPopulated ){
          biuComplaints?.setErrors({ ...(biuComplaints.errors || {}), [biuComplaintsErrorKey]: true });
          return { [biuComplaintsErrorKey]: true };
      }
      if (biuComplaintsPopulated && !biuComplaintDaysPopulated ){
          biuComplaintDays?.setErrors({ ...(biuComplaints.errors || {}), [biuComplaintDaysErrorKey]: true });
          return {[biuComplaintDaysErrorKey]: true };
      }
      return null;
     
    }
  };