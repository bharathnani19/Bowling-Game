import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { distinctUntilChanged, map } from 'rxjs/operators';

export interface LoaderState {
  show: boolean;
  message?: string;
}

/**
 * Simple global loader service.
 *
 * Usage in a component template:
 * <app-loader [show]="loader.show$ | async" [message]="loader.message$ | async"></app-loader>
 */
@Injectable({ providedIn: 'root' })
export class LoaderService {
  private stateSubject = new BehaviorSubject<LoaderState>({ show: false });
  readonly state$: Observable<LoaderState> = this.stateSubject.asObservable();

  // Convenience streams
  readonly show$: Observable<boolean> = this.state$.pipe(
    map((s) => s.show),
    distinctUntilChanged()
  );
  readonly message$: Observable<string | undefined> = this.state$.pipe(
    map((s) => s.message),
    distinctUntilChanged()
  );

  show(message?: string): void {
    this.stateSubject.next({ show: true, message });
  }

  hide(): void {
    this.stateSubject.next({ show: false, message: undefined });
  }

  setMessage(message?: string): void {
    const current = this.stateSubject.value;
    this.stateSubject.next({ ...current, message });
  }

  toggle(message?: string): void {
    const current = this.stateSubject.value;
    this.stateSubject.next({
      show: !current.show,
      message: message !== undefined ? message : current.message,
    });
  }

  // synchronous access if needed
  get value(): LoaderState {
    return this.stateSubject.value;
  }
}
