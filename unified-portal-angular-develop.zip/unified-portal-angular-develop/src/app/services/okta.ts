import { Injectable, signal } from '@angular/core';
import { OktaAuth } from '@okta/okta-auth-js';

import { environment } from '../environments/environment.shared';
import { User } from '../models/user.model';
import { allRoleTypes } from '../utilities/constants';

@Injectable({
  providedIn: 'root',
})
export class OktaService {
  user = signal<User>({});
  userInfo = signal<any>(null);
  isAuthenticated = signal(false);
  defaultAsrView = signal('medicare');

  private logoutInProgress = false;

  readonly oktaAuth = new OktaAuth({
    clientId: environment.extended.okta.clientId,
    issuer: environment.extended.okta.issuer,
    redirectUri: environment.extended.okta.redirectUri,
    postLogoutRedirectUri: environment.extended.okta.postLogoutRedirectUri,

    scopes: ['openid', 'email', 'profile', 'offline_access'],

    pkce: true,

    tokenManager: {
      storage: 'localStorage',

      autoRenew: true,

      autoRemove: true,
    },
  });

  async loadUser(): Promise<void> {
    if (this.logoutInProgress) {
      return;
    }

    try {
      const authenticated = await this.oktaAuth.isAuthenticated();

      if (this.logoutInProgress) {
        return;
      }

      this.isAuthenticated.set(authenticated);

      if (!authenticated) {
        this.clearLocalUser();
        return;
      }

      const userInfo = await this.oktaAuth.getUser();

      if (this.logoutInProgress) {
        return;
      }

      const userData: User = {};

      userData.groups = (userInfo['groups'] as string[]) || [];

      this.userInfo.set(userInfo);

      userData.userDisplayName = userInfo.name;
      userData.oktaDetails = userInfo;

      userData.rolesArray = [];
      userData.userAttrArray = [];
      userData.zonesArray = [];

      const groupsArray: string[] = (userInfo['groups'] as string[]) || [];

      for (const groupObj of groupsArray) {
        if (groupObj.includes('FPSUI Role')) {
          userData.rolesArray.push(groupObj.replace('FPSUI Role', '').trim());
        }

        if (groupObj.includes('FPSUI Zone')) {
          userData.zonesArray.push(groupObj.replace('FPSUI Zone', '').trim());
        }

        if (groupObj.includes('FPSUI Attrib')) {
          userData.userAttrArray.push(groupObj.replace('FPSUI Attrib', '').trim());
        }

        if (groupObj.includes('FPSUI EML')) {
          userData.userAttrArray.push(groupObj.replace('FPSUI', '').trim());
        }
      }

      if (localStorage.getItem('firstTimeVisit') === null) {
        localStorage.setItem('firstTimeVisit', 'true');
      }

      if (!userData.rolesArray || userData.rolesArray.length === 0) {
        window.location.href = environment.umLink;

        return;
      }

      userData.rolesStr = userData.rolesArray.toString();

      userData.oldOrganizationVal = userData.zonesArray[0];

      if (userData.oldOrganizationVal === 'UPIC 1') {
        userData.organization = 'UPIC MW';
      } else if (userData.oldOrganizationVal === 'UPIC 2') {
        userData.organization = 'UPIC NE';
      } else if (userData.oldOrganizationVal === 'UPIC 3') {
        userData.organization = 'UPIC W';
      } else if (userData.oldOrganizationVal === 'UPIC 4') {
        userData.organization = 'UPIC SW';
      } else if (userData.oldOrganizationVal === 'UPIC 5') {
        userData.organization = 'UPIC SE';
      } else {
        userData.organization = userData.oldOrganizationVal;
      }

      userInfo['organization'] = userData.organization as any;

      this.userInfo.set(userInfo);

      if (userData.userAttrArray.length > 0) {
        userData.showAttributes = true;

        userData.attributes = userData.userAttrArray.toString();
      } else {
        userData.showAttributes = false;
      }

      if (
        userData.groups.includes(allRoleTypes.ROLE_MAC) ||
        userData.groups.includes(allRoleTypes.ZONE_MEDIC)
      ) {
        userData['disableMedicaid'] = true;
        userData['disableMedicaidMAC'] = true;
      } else {
        userData['disableMedicaid'] = false;
        userData['disableMedicaidMAC'] = false;
      }

      if (userData.groups.includes(allRoleTypes.ROLE_MAC)) {
        userData['macUser'] = true;
      }

      this.user.set(userData);
    } catch (error: any) {
      
      if (
        this.logoutInProgress ||
        error?.errorCode === 'invalid_token' ||
        error?.status === 401 ||
        error?.message?.includes('revoked')
      ) {
        await this.oktaAuth.tokenManager.clear();

        this.clearLocalUser();

        return;
      }

      throw error;
    }
  }

  async signIn(): Promise<void> {
    this.logoutInProgress = false;

    await this.oktaAuth.signInWithRedirect();
  }

  async signOut(): Promise<void> {
    if (this.logoutInProgress) {
      return;
    }

    this.logoutInProgress = true;

    this.clearLocalUser();

    try {
      await this.oktaAuth.signOut({
        postLogoutRedirectUri: environment.extended.okta.postLogoutRedirectUri,

        revokeAccessToken: true,
        revokeRefreshToken: true,
        clearTokensBeforeRedirect: true,
      });
    } catch (error) {
      console.error('Okta logout failed:', error);

      await this.oktaAuth.tokenManager.clear();

      window.location.href = environment.extended.okta.postLogoutRedirectUri;
    }
  }

  private clearLocalUser(): void {
    this.user.set({});
    this.userInfo.set(null);
    this.isAuthenticated.set(false);
  }
}
