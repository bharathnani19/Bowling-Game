import { OktaService } from "./okta";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../environments/environment.shared';
import { Observable, of } from 'rxjs';
import { formatMessage } from '../utilities/utils';
import moment from 'moment';

@Injectable({
    providedIn: 'root'
  })
  export class UtilService {
    constructor(private http: HttpClient, private okta: OktaService) {}

    public logSla(userId:string, eventType:string, zone:string): Observable<any> {
        const slaLoggingEnabled:boolean = environment.extended.slaLoggingEnabled;
        if (!slaLoggingEnabled){
          return of({
            'status': 'complete'
          })
        }
        const date = moment();
        const formattedDate = date.format('MMMM DD, YYYY hh:mm:ss a');

        const slaPayload = "SLA Metrics Entry. Type = " + eventType + ", Time = "
        + formattedDate + ", User = " + userId + ", Zone = "
        + zone;
        const payload = {sourcetype:"_json", source:"app-log", index:"main","event":{env:environment.extended.env, timestamp:formattedDate, message: slaPayload}}
        console.log(' SLA ' );
        console.log( payload);
        
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Splunk '+ environment.extended.splunkToken
          }),
          withCredentials: false 
        };
        return this.http.post<any>(
          environment.extended.splunkUrl,
          payload,
          httpOptions
         );
      }
      public getSlaToken():string{
        return crypto.randomUUID();
      }
  }
