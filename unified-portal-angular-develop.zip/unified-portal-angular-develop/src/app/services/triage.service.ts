import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../environments/environment.shared';
import { forkJoin, Observable } from 'rxjs';
import { formatMessage } from '../utilities/utils';
import { OktaService } from './okta';

@Injectable({
  providedIn: 'root',
})
export class TriageService {
  constructor(
    private http: HttpClient,
    private okta: OktaService,
  ) {}

  get userId() {
    return this.okta.user().oktaDetails?.preferred_username;
  }

  public retrieveUserPrefs(): Observable<{ medicare: any; medicaid: any }> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const req = (type: string) =>
      this.http.get<any>(
        formatMessage(environment.wsUrls.retrieveUserPrefs, {
          userId: this.userId,
          type,
        }),
        { headers },
      );

    return forkJoin({
      medicare: req('sumTableCols'),
      medicaid: req('sumTableColsMDCD'),
    });
  }

  public updatePreference(val: string, isMedicare: boolean): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.post<any>(
      environment.wsUrls.saveUserPrefs,
      {
        userId: this.userId,
        prefName: isMedicare ? 'sumTableCols' : 'sumTableColsMDCD',
        prefJson: JSON.stringify(val),
      },
      { headers },
    );
  }

  public getWorkingSet(): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const req = (searchType: string) =>
      this.http.get<any>(
        formatMessage(environment.wsUrls.getAddToExistInputVals, {
          userId: this.userId,
          searchType,
        }),
        { headers },
      );

    return forkJoin([req(''), req('mdcd/')]);
  }

  public getAddToExistInputVals(): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.get<any>(
      formatMessage(environment.wsUrls.getAddToExistInputVals, {
        userId: this.userId?.toUpperCase(),
        searchType: '',
      }),
      { headers },
    );
  }

  public checkExistingWorkingSetNames(isMedicare: boolean): Observable<any[]> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const asrType = isMedicare ? '' : 'mdcd/';
    return this.http.get<any[]>(
      formatMessage(environment.wsUrls.checkExistName, {
        asrType,
        userId: this.userId,
        workbenchType: 'asr',
      }),
      { headers },
    );
  }

  public createWorkingSet(
    listName: string,
    listItems: Array<{ asrptId: string }>,
    isMedicare: boolean,
  ): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const asrType = isMedicare ? '' : 'mdcd/';
    const fpsPrioritizationList: any = {
      audtInsrtId: this.userId,
      listNm: listName,
      cmtTxt: '',
      fpsPrioritizationListItems: listItems,
    };

    if (!isMedicare) {
      fpsPrioritizationList.listType = 'WORKINGMDCD';
    }

    return this.http.post<any>(
      formatMessage(environment.wsUrls.createWorkingSet, { asrType }),
      fpsPrioritizationList,
      { headers },
    );
  }

  public addToExistingWorkingSet(
    workItemId: string,
    asrptIds: number[],
    isMedicare: boolean,
  ): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const asrType = isMedicare ? '' : 'mdcd/';
    const payload = {
      asrptIds: (asrptIds || []).filter((id: number) => Number.isFinite(id)),
    };

    return this.http.post<any>(
      formatMessage(environment.wsUrls.addToExistingWorkingSet, {
        asrType,
        workItemId,
        userId: this.userId,
      }),
      payload,
      { headers },
    );
  }

  public searchWorkbenchItem(
    workItemId: string,
    options?: { type?: string; asrType?: string },
  ): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    const type = String(options?.type || '').toLowerCase();

    if (type === 'list') {
      const asrType = options?.asrType === 'MDCD' ? 'mdcd/' : '';
      return this.http.get<any>(
        formatMessage(environment.wsUrls.workbenchListById, {
          asrType,
          workItemId,
          userId: this.userId,
        }),
        { headers },
      );
    }

    return this.http.get<any>(
      formatMessage(environment.wsUrls.workbenchItemSearch, {
        workItemId,
        userId: this.userId,
      }),
      { headers },
    );
  }

  public getAsrInfoModelData(
    asrType: 'medicare' | 'medicaid' = 'medicare',
    modelId:string,
    modelDate:string
  ): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const endpoint =environment.wsUrls.infoModel;
    const [month, date,year] = modelDate.split('-');

    return this.http.post<any>(
      formatMessage(endpoint, {
        type: asrType=='medicaid'? '/mdcd' : '',
        modelId,
        modelDate : `${year}-${month}-${date}`,
        userId:this.userId
      }),{},
      { headers },
    );
  }

  public getAsrDetailsData(
    asrId: string,
    searchType: string,
    asrType: 'medicare' | 'medicaid' = 'medicare',
  ): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const endpoint =
      asrType === 'medicaid'
        ? environment.wsUrls.getMdcdAsrDetails
        : environment.wsUrls.getAsrDetails;

    return this.http.get<any>(
      formatMessage(endpoint, {
        asrId,
        searchType,
        userId: this.userId,
      }),
      { headers },
    );
  }

  public getP1CostDetails(asrId: string): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const endpoint = environment.wsUrls.getP1costDeails;

    return this.http.get<any>(
      formatMessage(endpoint, {
        asrId,
        userId: this.userId,
      }),
      { headers },
    );
  }

  public removeFromWorkingSet(workItemId: string, asrptIds: number[]): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const payload = {
      asrptIds: (asrptIds || []).filter((id: number) => Number.isFinite(id)),
    };

    return this.http.put<any>(
      formatMessage(environment.wsUrls.removeFromWorkingSet, {
        workItemId,
        userId: this.userId,
      }),
      payload,
      { headers },
    );
  }

  public getPrioritizeForUCMTableData(searchType: string, selectedRows: any[]): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<any>(
      formatMessage(environment.wsUrls.getPrioritizeForUCMTableData, {
        searchType: searchType === 'medicare' ? '' : 'mdcd/',
      }),
      {
        loggedInUserId: this.userId?.toUpperCase(),
        programType: searchType,
        asrptIds: selectedRows.map((row) => row.asrDbid),
      },
      { headers },
    );
  }

  public getPriorUcmZones(): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.get<any>(
      formatMessage(environment.wsUrls.getPriorUcmZones, {
        userId: this.userId?.toUpperCase(),
      }),
      { headers },
    );
  }

  public prioritizeASRsForUCM(data: any): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<any>(
      formatMessage(environment.wsUrls.prioritizeASRsForUCM, {}),
      {
        ...data,
      },
      { headers },
    );
  }
}
