import { Injectable, OnDestroy } from '@angular/core';

import { MatDialog, MatDialogRef, MatDialogState } from '@angular/material/dialog';

import { fromEvent, merge, Subscription, throttleTime } from 'rxjs';

import { OktaService } from './okta';

import { environment } from '../environments/environment.shared';

import { SessionInactiveModalComponent } from '../modules/core/session-timeout/session-timeout';

@Injectable({
  providedIn: 'root',
})
export class SessionService implements OnDestroy {
  private dialogRef?: MatDialogRef<SessionInactiveModalComponent>;

  private readonly LAST_ACTIVITY_KEY = 'lastPageActivity';

  private readonly SESSION_TIMEOUT_KEY = 'idleTimeExp';

  private readonly LAST_RENEW_STAMP_KEY = 'LAST_RENEW_STAMP';

  /*
   * 30 minutes total inactivity.
   */
  private readonly SESSION_TIMEOUT_DURATION = 30 * 60 * 1000;

  /*
   * Show modal with 5 minutes remaining.
   */
  private readonly REMINDER_TIME = 5 * 60 * 1000;

  /*
   * Check every 10 seconds.
   */
  private readonly SESSION_CHECK_INTERVAL = 10 * 1000;

  private sessionIntervalId?: ReturnType<typeof setInterval>;

  private activitySubscription?: Subscription;

  private blockSessionActivity = false;

  private renewInProgress = false;

  private monitoringStarted = false;

  private logoutInProgress = false;

  private readonly memoryStore = new Map<string, string>();

  constructor(
    private readonly dialog: MatDialog,
    private readonly okta: OktaService,
  ) {}

  /*
   * Called after authentication succeeds.
   */
  startSessionTimeout(): void {
    if (this.monitoringStarted) {
      return;
    }

    console.log('Starting session timeout monitoring');

    this.monitoringStarted = true;

    this.blockSessionActivity = false;
    this.renewInProgress = false;
    this.logoutInProgress = false;

    this.safeSet(this.LAST_RENEW_STAMP_KEY, Date.now().toString());

    this.resetIdleTimeout();

    this.trackUserActivity();

    this.startSessionInterval();

    void this.checkIdleTimeExpiration();
  }

  stopSessionTimeout(): void {
    this.stopSessionMonitoring();

    this.blockSessionActivity = true;

    this.renewInProgress = false;

    this.safeRemove(this.LAST_ACTIVITY_KEY);

    this.safeRemove(this.SESSION_TIMEOUT_KEY);

    this.safeRemove(this.LAST_RENEW_STAMP_KEY);

    if (this.isDialogOpen()) {
      this.dialogRef?.close();
    }

    this.dialogRef = undefined;
  }

  private resetIdleTimeout(): void {
    if (this.blockSessionActivity) {
      return;
    }

    const now = Date.now();

    const expirationTime = now + this.SESSION_TIMEOUT_DURATION;

    this.safeSet(this.LAST_ACTIVITY_KEY, now.toString());

    this.safeSet(this.SESSION_TIMEOUT_KEY, expirationTime.toString());

    console.log('Idle timer reset.', {
      warningAt: new Date(expirationTime - this.REMINDER_TIME).toLocaleTimeString(),

      expiresAt: new Date(expirationTime).toLocaleTimeString(),
    });
  }

  private trackUserActivity(): void {
    const activityEvents = merge(
      fromEvent(document, 'click'),
      fromEvent(document, 'keydown'),
      fromEvent(document, 'mousemove'),
      fromEvent(document, 'touchstart'),
      fromEvent(document, 'scroll'),
    ).pipe(throttleTime(1000));

    this.activitySubscription = activityEvents.subscribe(() => {
      if (this.blockSessionActivity) {
        return;
      }

      this.resetIdleTimeout();
    });
  }

  private startSessionInterval(): void {
    if (this.sessionIntervalId) {
      clearInterval(this.sessionIntervalId);
    }

    this.sessionIntervalId = setInterval(() => {
      void this.checkIdleTimeExpiration();
    }, this.SESSION_CHECK_INTERVAL);
  }

  private async checkIdleTimeExpiration(): Promise<void> {
    if (!this.monitoringStarted || this.logoutInProgress || this.renewInProgress) {
      return;
    }

    const sessionRefreshed = await this.refreshSessionIfUserRecentlyActive();

    if (sessionRefreshed) {
      return;
    }

    const sessionTimeoutValue = this.safeGet(this.SESSION_TIMEOUT_KEY);

    if (!sessionTimeoutValue) {
      this.resetIdleTimeout();

      return;
    }

    const expirationTime = Number(sessionTimeoutValue);

    if (!Number.isFinite(expirationTime)) {
      this.resetIdleTimeout();

      return;
    }

    const now = Date.now();

    const reminderStartTime = expirationTime - this.REMINDER_TIME;

    if (now >= expirationTime) {
      this.blockSessionActivity = true;

      if (this.isDialogActive()) {
        if (this.isDialogOpen()) {
          this.dialogRef?.close('logout');
        }

        return;
      }

      await this.logout();

      return;
    }

    /*
     * User has entered the final five-minute
     * warning period.
     */
    if (now >= reminderStartTime && !this.isDialogActive()) {
      this.showSessionExpirationDialog(expirationTime);

      return;
    }
  }

  private async refreshSessionIfUserRecentlyActive(): Promise<boolean> {
    if (this.blockSessionActivity || this.isDialogActive()) {
      return false;
    }

    const lastActivityValue = this.safeGet(this.LAST_ACTIVITY_KEY);

    if (!lastActivityValue) {
      return false;
    }

    const lastActivityTime = Number(lastActivityValue);

    if (!Number.isFinite(lastActivityTime)) {
      return false;
    }

    const now = Date.now();

    const minutesSinceActivity = (now - lastActivityTime) / 60000;

    if (minutesSinceActivity >= 5) {
      return false;
    }

    const lastRenewValue = this.safeGet(this.LAST_RENEW_STAMP_KEY);

    let minutesSinceRenew = Number.POSITIVE_INFINITY;

    if (lastRenewValue) {
      const lastRenewTime = Number(lastRenewValue);

      if (Number.isFinite(lastRenewTime)) {
        minutesSinceRenew = (now - lastRenewTime) / 60000;
      }
    }

    if (minutesSinceRenew <= 2) {
      return false;
    }

    const renewed = await this.renewOktaSession();

    if (!renewed) {
      return false;
    }

    this.safeSet(this.LAST_RENEW_STAMP_KEY, now.toString());

    return true;
  }

  private showSessionExpirationDialog(expirationTime: number): void {
    if (this.isDialogOpen()) {
      return;
    }

    console.log('Opening session expiration dialog');

    /*
     * Prevent clicking inside the modal
     * from counting as user activity.
     */
    this.blockSessionActivity = true;

    this.dialogRef = this.dialog.open(SessionInactiveModalComponent, {
      data: {
        expirationTime,
      },

      disableClose: true,

      autoFocus: true,

      restoreFocus: true,
    });

    this.dialogRef.afterClosed().subscribe((result: string | undefined) => {
      this.dialogRef = undefined;

      void this.handleDialogResult(result);
    });
  }

  private async handleDialogResult(result: string | undefined): Promise<void> {
    if (result === 'extend') {
      this.blockSessionActivity = false;

      // Extend the app-level idle window immediately to avoid logout races
      // while token renewal is still in flight.
      this.resetIdleTimeout();

      await this.extendSession();

      return;
    }

    if (result === 'logout') {
      await this.logout();

      return;
    }

    this.blockSessionActivity = false;
  }

  /*
   * STAY CONNECTED
   */
  private async extendSession(): Promise<void> {
    console.log('Stay Connected selected');

    const renewed = await this.renewOktaSession();

    if (!renewed) {
      console.warn('Token renewal failed. Redirecting user to sign-in to re-establish session.');

      this.blockSessionActivity = true;
      this.stopSessionMonitoring();
      await this.okta.signIn();

      return;
    }

    this.blockSessionActivity = false;

    this.safeSet(this.LAST_RENEW_STAMP_KEY, Date.now().toString());

    console.log('Session extended successfully');
  }

  private async renewOktaSession(): Promise<boolean> {
    if (this.renewInProgress) {
      return false;
    }

    this.renewInProgress = true;

    try {
      const tokenApi = this.okta.oktaAuth.token as any;

      if (typeof tokenApi.renewTokens === 'function') {
        try {
          const renewedTokens = await tokenApi.renewTokens();

          if (renewedTokens) {
            this.okta.oktaAuth.tokenManager.setTokens(renewedTokens);

            console.log('Okta token renewal completed successfully via renewTokens');

            return true;
          }
        } catch (renewTokensError) {
          console.warn('renewTokens failed. Falling back to tokenManager renew.', renewTokensError);
        }
      }

      const tokens = await this.okta.oktaAuth.tokenManager.getTokens();

      if (!tokens.accessToken && !tokens.idToken && !tokens.refreshToken) {
        console.warn('No Okta tokens found in token manager. Attempting silent token recovery.');

        return await this.trySilentTokenRecovery();
      }

      console.log('Renewing Okta access token', {
        hasAccessToken: !!tokens.accessToken,

        hasIdToken: !!tokens.idToken,

        hasRefreshToken: !!tokens.refreshToken,
      });

      if (tokens.accessToken) {
        await this.okta.oktaAuth.tokenManager.renew('accessToken');
      }

      if (tokens.idToken) {
        try {
          await this.okta.oktaAuth.tokenManager.renew('idToken');
        } catch (idTokenError) {
          console.warn('ID token renewal failed:', idTokenError);
        }
      }

      const updatedTokens = await this.okta.oktaAuth.tokenManager.getTokens();

      if (updatedTokens.accessToken || updatedTokens.idToken) {
        console.log('Okta token renewal completed successfully');

        return true;
      }

      return await this.trySilentTokenRecovery();
    } catch (error) {
      console.error('Okta access token renewal failed:', error);

      return await this.trySilentTokenRecovery();
    } finally {
      this.renewInProgress = false;
    }
  }

  private async trySilentTokenRecovery(): Promise<boolean> {
    const tokenApi = this.okta.oktaAuth.token as any;

    try {
      if (typeof tokenApi.renewTokens === 'function') {
        const renewedTokens = await tokenApi.renewTokens();

        if (renewedTokens) {
          this.okta.oktaAuth.tokenManager.setTokens(renewedTokens);
          return true;
        }
      }

      if (typeof tokenApi.getWithoutPrompt === 'function') {
        const response = await tokenApi.getWithoutPrompt({
          scopes: environment.extended.okta.scopes,
        });

        const recoveredTokens = response?.tokens ?? response;

        if (recoveredTokens) {
          this.okta.oktaAuth.tokenManager.setTokens(recoveredTokens);
          return true;
        }
      }

      const authenticated = await this.okta.oktaAuth.isAuthenticated();
      return authenticated;
    } catch (error) {
      console.warn('Silent token recovery failed.', error);
      return false;
    }
  }

  private isDialogOpen(): boolean {
    return this.dialogRef?.getState() === MatDialogState.OPEN;
  }

  private isDialogActive(): boolean {
    const dialogState = this.dialogRef?.getState();

    return dialogState === MatDialogState.OPEN || dialogState === MatDialogState.CLOSING;
  }

  async logout(): Promise<void> {
    if (this.logoutInProgress) {
      return;
    }

    this.logoutInProgress = true;

    this.blockSessionActivity = true;

    if (this.isDialogOpen()) {
      this.dialogRef?.close();
    }

    this.stopSessionMonitoring();

    this.safeRemove(this.LAST_ACTIVITY_KEY);

    this.safeRemove(this.SESSION_TIMEOUT_KEY);

    this.safeRemove(this.LAST_RENEW_STAMP_KEY);

    console.log('Session timeout logout triggered');

    await this.okta.signOut();
  }

  private stopSessionMonitoring(): void {
    if (this.sessionIntervalId) {
      clearInterval(this.sessionIntervalId);

      this.sessionIntervalId = undefined;
    }

    this.activitySubscription?.unsubscribe();

    this.activitySubscription = undefined;

    this.monitoringStarted = false;
  }

  private safeSet(key: string, value: string): void {
    try {
      localStorage.setItem(key, value);

      return;
    } catch {}

    try {
      sessionStorage.setItem(key, value);

      return;
    } catch {}

    this.memoryStore.set(key, value);
  }

  private safeGet(key: string): string | null {
    try {
      const value = localStorage.getItem(key);

      if (value !== null) {
        return value;
      }
    } catch {}

    try {
      const value = sessionStorage.getItem(key);

      if (value !== null) {
        return value;
      }
    } catch {}

    return this.memoryStore.get(key) ?? null;
  }

  private safeRemove(key: string): void {
    try {
      localStorage.removeItem(key);
    } catch {}

    try {
      sessionStorage.removeItem(key);
    } catch {}

    this.memoryStore.delete(key);
  }

  ngOnDestroy(): void {
    this.stopSessionMonitoring();
  }
}
