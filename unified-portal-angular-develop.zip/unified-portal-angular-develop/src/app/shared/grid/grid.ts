import { Component, Input } from '@angular/core';

@Component({
  selector: 'grid',
  templateUrl: './grid.html',
  styleUrl: './grid.scss',
  standalone: false,
})
export class GridComponent {
 
}
