import { Component, Inject } from '@angular/core';

@Component({
  selector: 'biu-summary',
  templateUrl: './biu-summary.html',
  styleUrl: './biu-summary.scss',
  standalone: false
})
export class BiuSummaryComponent {
  biuSummary: string;
  day90Cnt: number;
  totalCnt: number;
 
  constructor(@Inject('componentData') public data: any) {
    this.biuSummary = this.data.biuSummary;
    this.totalCnt = this.data.totalCnt;
    this.day90Cnt = this.data.day90Cnt;
  }
}
