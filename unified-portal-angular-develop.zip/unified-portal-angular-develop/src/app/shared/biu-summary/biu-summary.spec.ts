import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BiuSummary } from './biu-summary';

describe('BiuSummary', () => {
  let component: BiuSummary;
  let fixture: ComponentFixture<BiuSummary>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BiuSummary]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BiuSummary);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
