import { Directive, TemplateRef, Input } from '@angular/core';

@Directive({
  selector: '[appCellTemplate]',
  standalone: false,
})
export class CellTemplateDirective {
  @Input('appCellTemplate') name!: string;
  constructor(public templateRef: TemplateRef<any>) {}
}
