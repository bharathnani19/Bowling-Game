import {
  Component,
  Input,
  Output,
  EventEmitter,
  ContentChildren,
  QueryList,
  AfterContentInit,
  AfterViewInit,
  ViewChild,
  OnChanges,
  SimpleChanges,
  ElementRef,
} from '@angular/core';

import { MatTable, MatTableDataSource } from '@angular/material/table';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatMenuTrigger } from '@angular/material/menu';
import { SelectionModel } from '@angular/cdk/collections';
import { CellTemplateDirective } from './cell.directive';

@Component({
  selector: 'app-table',
  templateUrl: './table.html',
  styleUrls: ['./table.scss'],
  standalone: false,
})
export class TableComponent implements AfterContentInit, AfterViewInit, OnChanges {
  @Input() data: any[] = [];
  @Input() hideAction: boolean = false;
  @Input() clearRowSelection: any;
  @Input() footerText: string = '';
  @ViewChild('myTable', { read: ElementRef }) tableEle!: ElementRef;

  _columns: any[] = [];
  tempColumns: any[] = [];
  private visibleColumns: any[] = [];

  @Input()
  set columns(value: any[]) {
    this._columns = (value ?? []).map((c) => ({
      ...c,
      visible: c.visible ?? true,
    }));

    this.tempColumns = this._columns.map((col) => ({ ...col }))?.filter((c) => c.label);
    this.selectAll = this.tempColumns.every((c) => c.visible);

    this.updateDisplayedColumns();
    this.setupCustomFilter();
  }

  @Input() pageSize = 10;
  @Input() pageSizeOptions: number[] = [10, 25, 50, 100];
  @Input() isLoading = false;
  @Input() title?: string;
  @Input() caption?: string;
  @Input() tableName?: string;
  @Input() enableSearch: boolean = false;
  @Input() tableClass?: string;
  @Input() showAction: boolean = true;
  @Input() freezeHeader: boolean = false;
  @Input() showPaginator: boolean = true;
  @Input() tableWrapperClass?: string = 'ip-pane__table-wrapper';
  @Input() printOptions?: {
    fontSize?: number;
    orientation?: 'portrait' | 'landscape';
    compact?: boolean;
  };
  @Input() tableHeaderStyle: string = '';
  @Input() tableHeight: string = '80vh';
  @Input() enableScroll: boolean = false;
  @Input() enableSelectAll: boolean = false;
  private _enableRowSelection = false;

  @Input()
  set enableRowSelection(val: boolean) {
    this._enableRowSelection = !!val;
    this.updateDisplayedColumns();
  }
  get enableRowSelection(): boolean {
    return this._enableRowSelection;
  }

  @Input() tableId?: string = 'test_table_id';

  @Input() charLimit: number = 1000;
  private expandedCells = new Set<string>();

  @Output() rowClick = new EventEmitter<any>();
  @Output() rowSelectionChange = new EventEmitter<any>();
  @Output() customEvent = new EventEmitter<{ action: string; data: any }>();

  dataSource = new MatTableDataSource<any>([]);
  private fullData: any[] = [];
  private filteredData: any[] = [];
  private sortedData: any[] = [];

  pageIndex = 0;
  totalRows = 0;
  searchText = '';
  displayedColumns: string[] = [];
  showSearch = false;

  selectAll: boolean = true;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatTable) table!: MatTable<any>;
  @ViewChild(MatMenuTrigger) columnMenuTrigger!: MatMenuTrigger;

  @ViewChild('printableTable', { static: false }) printableTable!: ElementRef;

  @ContentChildren(CellTemplateDirective)
  templates!: QueryList<CellTemplateDirective>;
  templateMap: Record<string, any> = {};

  selection = new SelectionModel<any>(true, []);

  constructor(private elementRef: ElementRef) {}

  private cellId(rowIndex: number, colKey: string): string {
    return `${rowIndex}__${colKey}`;
  }

  isExpanded(rowIndex: number, colKey: string): boolean {
    return this.expandedCells.has(this.cellId(rowIndex, colKey));
  }

  toggleExpand(evt: MouseEvent, rowIndex: number, colKey: string): void {
    // IMPORTANT: stop row click when clicking show more/less
    evt.stopPropagation();

    const id = this.cellId(rowIndex, colKey);
    if (this.expandedCells.has(id)) this.expandedCells.delete(id);
    else this.expandedCells.add(id);
  }

  // Safe cell text
  getCellText(row: any, key: string): string {
    const v = row?.[key];
    return v !== null && v !== undefined && v !== '' ? String(v) : '-';
  }

  ngAfterContentInit(): void {
    this.templates?.forEach((t) => (this.templateMap[t.name] = t.templateRef));

    this.updateDisplayedColumns();
    // this.dataSource = new MatTableDataSource(this.data);

    // 508
    setTimeout(() => {
      const buttons = document.querySelectorAll(
        '.mat-mdc-paginator button, .mat-mdc-paginator mat-select',
      );
      buttons.forEach((btn) => btn.setAttribute('tabindex', '0'));
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['data']) {
      this.fullData = this.data || [];
      this.filteredData = this.fullData;
      this.sortedData = this.filteredData;
      this.totalRows = this.sortedData.length;
      this.pageIndex = 0;
      this.loadPage();
    }

    if (changes['clearRowSelection'] && this.clearRowSelection) {
      this.selection.clear();
    }
  }

  ngAfterViewInit(): void {
    this.tempColumns = this._columns.map((col) => ({ ...col })).filter((c) => c.label);
    this.selectAll = this.tempColumns.every((c) => c.visible);

    this.setupCustomFilter();
    this.setupCustomSort();

    this.sort.sortChange.subscribe(() => {
      this.pageIndex = 0;
      this.applyClientSort();
    });
  }

  refreshSticky() {
    this.table.updateStickyColumnStyles();
    this.table.updateStickyHeaderRowStyles();
  }

  private setupCustomFilter(): void {
    this.visibleColumns = this._columns.filter((c: any) => c.visible);

    this.dataSource.filterPredicate = (data: any, filter: string) => {
      if (!filter) return true;

      return this.visibleColumns.some((col: any) => {
        const value = data[col.key];
        if (value === null || value === undefined) return false;
        return String(value).toLowerCase().includes(filter);
      });
    };
  }

  private defaultSort(valueA: any, valueB: any): number {
    if (valueA == null && valueB == null) return 0;
    if (valueA == null) return -1;
    if (valueB == null) return 1;

    if (typeof valueA === 'string' && typeof valueB === 'string') {
      return valueA.localeCompare(valueB);
    }

    return valueA < valueB ? -1 : valueA > valueB ? 1 : 0;
  }

  private setupCustomSort(): void {
    this.dataSource.sortData = (data: any[], sort: MatSort) => {
      const active = sort.active;
      const direction = sort.direction;

      if (!active || direction === '') return data;

      const column = this._columns.find((c: any) => c.key === active);

      return data.slice().sort((a, b) => {
        let result = 0;

        if (column?.sortFn) {
          result = column.sortFn(a, b);
        } else {
          result = this.defaultSort(a[active], b[active]);
        }

        return direction === 'asc' ? result : -result;
      });
    };
  }

  trackByColumnKey = (_: number, col: any) => col.key;

  trackByRow = (index: number, row: any) =>
    row?.asrptId ?? row?.asrDbid ?? row?.asrId ?? row?.id ?? index;

  onColumnVisibilityChange(_col: any): void {
    this.updateDisplayedColumns();
    this.setupCustomFilter();
  }

  toggleColumn(col: { visible: boolean; key: string; label: string }, _event?: any) {
    col.visible = !col.visible;
    this.onColumnVisibilityChange(col);
  }

  isAllSelected(): boolean {
    const pageRows = this.dataSource.data || [];
    return pageRows.length > 0 && pageRows.every((row) => this.selection.isSelected(row));
  }

  isSomeSelected(): boolean {
    const pageRows = this.dataSource.data || [];
    return pageRows.some((row) => this.selection.isSelected(row)) && !this.isAllSelected();
  }

  toggleAllRows(): void {
    const pageRows = this.dataSource.data || [];

    if (this.isAllSelected()) {
      pageRows.forEach((row) => this.selection.deselect(row));
    } else {
      pageRows.forEach((row) => this.selection.select(row));
    }

    this.emitSelection();
  }

  toggleRow(row: any): void {
    this.selection.toggle(row);
    this.emitSelection();
  }

  emitSelection(): void {
    this.rowSelectionChange.emit(this.selection.selected);
  }

  stopRowClick(event: Event): void {
    event.stopPropagation();
  }

  openColumnMenu() {
    this.tempColumns = this._columns.map((col) => ({ ...col }));
  }

  applyColumnChanges() {
    this._columns = this.tempColumns.map((col) => ({
      ...col,
      visible: col.visible ?? true,
    }));

    this.updateDisplayedColumns();
    this.setupCustomFilter();

    if (this.searchText) {
      this.applySearch({ target: { value: this.searchText } });
    } else {
      this.loadPage();
    }

    this.columnMenuTrigger.closeMenu();
  }

  resetColumnChanges() {
    this._columns = this._columns.map((col) => ({ ...col, visible: true }));
    this.tempColumns = this._columns.map((col) => ({ ...col }));
    this.selectAll = true;

    this.updateDisplayedColumns();
    this.setupCustomFilter();

    if (this.searchText) {
      this.applySearch({ target: { value: this.searchText } });
    } else {
      this.loadPage();
    }

    this.columnMenuTrigger.closeMenu();
  }

  saveUserprefs() {
    const columnsToSave = this.tempColumns.filter((o) => !o.visible).map((o) => o.key);
    this.customEvent.emit({
      action: 'saveUserPref',
      data: { columns: columnsToSave },
    });
    this.applyColumnChanges();
  }

  clearColumnChanges() {
    this.resetColumnChanges();
    this.saveUserprefs();
  }

  toggleSearch() {
    this.showSearch = true;
    setTimeout(() => {
      const input = document.querySelector('.search-field input') as HTMLInputElement;
      input?.focus();
    }, 50);
  }

  closeSearch(): void {
    this.showSearch = false;
    this.searchText = '';
    this.filteredData = this.fullData;
    this.sortedData = this.filteredData;
    this.totalRows = this.sortedData.length;
    this.pageIndex = 0;
    this.loadPage();
  }

  applySearch(event: any): void {
    this.searchText = event.target.value.trim().toLowerCase();
    this.pageIndex = 0;

    if (!this.searchText) {
      this.filteredData = this.fullData;
    } else {
      const visibleColumns = this._columns.filter((c: any) => c.visible);

      this.filteredData = this.fullData.filter((row) =>
        visibleColumns.some((col: any) => {
          const value = row?.[col.key];
          return value != null && String(value).toLowerCase().includes(this.searchText);
        }),
      );
    }
    this.sortedData = this.filteredData;
    this.totalRows = this.sortedData.length;
    this.applyClientSort(false);
  }

  private applyClientSort(resetPage: boolean = true): void {
    const active = this.sort?.active;
    const direction = this.sort?.direction;

    if (!active || !direction) {
      this.sortedData = this.filteredData;
    } else {
      const column = this._columns.find((c: any) => c.key === active);

      this.sortedData = [...this.filteredData].sort((a, b) => {
        let result = 0;

        if (column?.sortFn) {
          result = column.sortFn(a, b);
        } else {
          result = this.defaultSort(a[active], b[active]);
        }

        return direction === 'asc' ? result : -result;
      });
    }

    this.totalRows = this.sortedData.length;

    if (resetPage) {
      this.pageIndex = 0;
    }

    this.loadPage();
  }

  private updateDisplayedColumns(): void {
    const visibleColumns = (this._columns || [])
      .filter((c: any) => c.visible)
      .map((c: any) => c.key);

    this.displayedColumns = this.enableRowSelection
      ? ['select', ...visibleColumns]
      : visibleColumns;
  }

  onRowClick(row: any): void {
    this.rowClick.emit(row);
  }

  private loadPage(): void {
    const start = this.pageIndex * this.pageSize;
    const end = start + this.pageSize;

    this.dataSource.data = this.sortedData.slice(start, end);
    if (this.table) {
      this.table.renderRows();
    }
  }

  onPageChange(event: PageEvent): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.loadPage();
  }

  onSelectAllChange(_event: any) {
    this.tempColumns.forEach((col: any) => {
      col['visible'] = this.selectAll;
    });
  }

  onColumnChange(col: any, val: any) {
    col.visible = val;
    this.selectAll = this.tempColumns.every((col) => col.visible);
  }

  toggleSelectAll(event: any): void {
    event.preventDefault();
    event.stopPropagation();

    this.selectAll = !this.selectAll;
    this.onSelectAllChange(this.selectAll);
  }

  // -----------------------------
  // PRINTING
  // -----------------------------
  private getPrintableTableHtml(): string | null {
    const wrapperEl = this.printableTable?.nativeElement as HTMLElement | undefined;
    if (!wrapperEl) {
      console.error('printableTable ViewChild not found');
      return null;
    }

    const clonedWrapper = wrapperEl.cloneNode(true) as HTMLElement;
    const table = clonedWrapper.querySelector('table');

    if (!table) {
      console.error('No <table> element found inside #printable-table');
      return null;
    }

    return table.outerHTML;
  }

  async printTable(): Promise<void> {
    if (this.printOptions) {
      return this.printTable2(
        this.printOptions.fontSize,
        this.printOptions.orientation,
        this.printOptions.compact,
      );
    }

    const printContents = this.getPrintableTableHtml();
    if (!printContents) return;

    const popupWin = window.open('', '_blank', 'top=0,left=0,height=800,width=1000');
    if (!popupWin) {
      console.error('Failed to open print window');
      return;
    }

    popupWin.document.open();
    popupWin.document.write(`
      <html>
        <head>
          <title>${this.title || 'Table'}</title>
          <style>
            @page { margin: 10mm; }
            body { font-family: Arial, sans-serif; padding: 16px; background: #ffffff; margin: 0; }
            table { width: 100%; border-collapse: collapse; }
            th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; }
            th { background-color: #f3f4f6; font-weight: 600; }
            th svg, th button { display: none !important; }
            td button { border: none; background: none; }
          </style>
        </head>
        <body onload="window.print(); window.close();">
          ${printContents}
        </body>
      </html>
    `);
    popupWin.document.close();
  }

  async printTable2(
    fontSize?: number,
    orientation?: 'portrait' | 'landscape',
    compact?: boolean,
  ): Promise<void> {
    const printContents = this.getPrintableTableHtml();
    if (!printContents) return;

    const isCompact = compact !== undefined ? compact : true;
    const pageOrientation = orientation || 'landscape';

    let bodyFontSize: number;
    let tableFontSize: number;
    let headerFontSize: number;
    let cellPadding: string;
    let bodyPadding: string;

    if (fontSize !== undefined) {
      bodyFontSize = fontSize;
      tableFontSize = fontSize - 1;
      headerFontSize = fontSize;
      cellPadding = isCompact ? '2px 4px' : '4px 8px';
      bodyPadding = isCompact ? '8px' : '16px';
    } else if (isCompact) {
      bodyFontSize = 9;
      tableFontSize = 8;
      headerFontSize = 9;
      cellPadding = '2px 4px';
      bodyPadding = '8px';
    } else {
      bodyFontSize = 12;
      tableFontSize = 12;
      headerFontSize = 12;
      cellPadding = '4px 8px';
      bodyPadding = '16px';
    }

    const popupWin = window.open('', '_blank', 'top=0,left=0,height=800,width=1000');
    if (!popupWin) {
      console.error('Failed to open print window');
      return;
    }

    popupWin.document.open();
    popupWin.document.write(`
      <html>
        <head>
          <title>${this.title || 'Table'}</title>
          <style>
            @page { size: ${pageOrientation}; margin: 10mm; }
            body {
              font-family: Arial, sans-serif;
              font-size: ${bodyFontSize}px;
              padding: ${bodyPadding};
              background: #ffffff;
              margin: 0;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              font-size: ${tableFontSize}px;
              table-layout: auto;
            }
            th, td {
              border: 1px solid #ccc;
              padding: ${cellPadding};
              text-align: left;
              word-wrap: break-word;
              max-width: 150px;
              font-size: ${tableFontSize}px;
            }
            th {
              background-color: #f3f4f6;
              font-weight: 600;
              font-size: ${headerFontSize}px;
            }
            th svg, th button { display: none !important; }
            td button { border: none; background: none; font-size: ${tableFontSize}px; }
          </style>
        </head>
        <body onload="window.print(); window.close();">
          ${printContents}
        </body>
      </html>
    `);
    popupWin.document.close();
  }

  // -----------------------------
  // EXPORT
  // -----------------------------
  exportToExcel(): void {
    const wrapperEl = this.printableTable?.nativeElement as HTMLElement;

    if (!wrapperEl) {
      console.error('printableTable not found');
      return;
    }

    const table = wrapperEl.querySelector('table');

    if (!table) {
      console.error('table not found inside printableTable');
      return;
    }

    const visibleCols = (this._columns || []).filter((c: any) => c.visible);
    const rows = Array.from(table.querySelectorAll('tr'));

    const csvContent = rows
      .map((tr: any, rowIndex: number) => {
        let cells = Array.from(tr.querySelectorAll('th, td'));

        // remove select checkbox column from export
        if (this.enableRowSelection && cells.length > visibleCols.length) {
          cells = cells.slice(1);
        }

        return cells
          .map((cell: any, cellIndex: number) => {
            let text = (cell.innerText || cell.textContent || '').trim().replace(/\s+/g, ' ');

            // add tooltip only for header row
            if (rowIndex === 0) {
              const col = visibleCols[cellIndex];
              if (col?.tooltip) {
                text = `${col.label} - ${col.tooltip}`;
              }
            }

            return `"${text.replace(/"/g, '""')}"`;
          })
          .join(',');
      })
      .join('\n');

    const blob = new Blob(['\ufeff' + csvContent], {
      type: 'text/csv;charset=utf-8;',
    });

    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = `${this.tableName || 'table-csv'}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    URL.revokeObjectURL(url);
  }
}
