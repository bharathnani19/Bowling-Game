import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormControl, Validators } from '@angular/forms';
import { HomePageService } from '../../../services/homepage.service';
import { ToastService } from '../../../services/toaster.service';

export interface RenameDialogData {
  title?: string;
  label?: string;
  data?: any;
  cancelText?: string;
  submitText?: string;
}

@Component({
  selector: 'app-criminal-detail-dialog',
  templateUrl: './criminal-detail-dialog.html',
  styleUrl: './criminal-detail-dialog.scss',
  standalone: false,
})
export class CriminalDetailDialogComponent {
  nameCtrl!: FormControl;
  data: any;
  errorMsg: string = '';
  isSubmitting: boolean = false;
  constructor(
    public dialogRef: MatDialogRef<CriminalDetailDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public _data: RenameDialogData,
    private _homeService: HomePageService,
    private _toaster: ToastService
  ) {
    this.data = _data.data;

    this.nameCtrl = new FormControl(this.data?.['listNm'] || '', [Validators.required]);
  }

  cancel() {
    this.dialogRef.close(null);
  }

  submit() {
    if (this.nameCtrl.invalid) return;

    this.errorMsg = '';
    const newName = this.nameCtrl.value?.trim();

    const workbenchType = this.data.listType === 'Working Set' ? 'lists' : 'searches';
    const asrType = this.data.asrType === 'MDCR' ? '' : 'mdcd/';

    if (this.data.nameList.includes(newName)) {
      this.errorMsg = 'Search already exists.';
      return;
    }
    this.isSubmitting = true;
    this.nameCtrl.disable();
    this._homeService
      .renameWorkbench(
        {
          listNm: newName,
          prioritizationListId: this.data.listId,
          listType: this.data.listType,
        },
        workbenchType
      )
      .subscribe({
        next: () => {
          this.dialogRef.close(true);
          this._toaster.success('List successfully renamed');
          this.isSubmitting = false;
        },
        error: (err) => {
          this.errorMsg = 'Rename List failed due to' + err.status;
          this.isSubmitting = false;
          this.nameCtrl.enable();
        },
      });
  }
}
