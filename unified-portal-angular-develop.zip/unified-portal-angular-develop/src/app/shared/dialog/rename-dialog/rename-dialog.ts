import { Component, ElementRef, inject, Inject, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormControl, Validators } from '@angular/forms';
import { HomePageService } from '../../../services/homepage.service';
import { ToastService } from '../../../services/toaster.service';
import { LoaderService } from '../../../services/loader.service';

export interface RenameDialogData {
  title?: string;
  label?: string;
  data?: any;
  cancelText?: string;
  submitText?: string;
}

@Component({
  selector: 'app-rename-dialog',
  templateUrl: './rename-dialog.html',
  styleUrl: './rename-dialog.scss',
  standalone: false,
})
export class RenameDialogComponent {
  dialogRef  = inject(MatDialogRef<RenameDialogComponent>);
  nameCtrl!: FormControl;
  data: any;
  errorMsg: string = '';
  isSubmitting: boolean = false;
  @ViewChild('errorLive') errorLive?: ElementRef<HTMLElement>;

  constructor(
    // public dialogRef: MatDialogRef<RenameDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public _data: RenameDialogData,
    private _homeService: HomePageService,
    private _toaster: ToastService,
     private loader: LoaderService,
  ) {
    this.data = _data.data;

    this.nameCtrl = new FormControl(this.data?.['listNm'] || '', [Validators.required]);
  }

  cancel() {
    this.dialogRef.close(null);
  }

  submit() {
   
    if (this.nameCtrl.invalid) return;

    this.errorMsg = '';
    const newName = this.nameCtrl.value?.trim();

    const workbenchType = this.data.listType === 'Working Set' ? 'lists' : 'searches';
    const asrType = this.data.asrType === 'MDCR' ? '' : 'mdcd/';

    if (this.data.nameList.includes(newName)) {
      this.errorMsg = 'Name already exists.';
      return;
    }
     this.loader.show();
    this.nameCtrl.disable();
    this._homeService
      .renameWorkbench(
        {
          listNm: newName,
          prioritizationListId: this.data.listId,
          listType: this.data.listType,
        },
        workbenchType
      )
      .subscribe({
        next: () => {
          this.dialogRef.close(true);
          this._toaster.success('List successfully renamed');
           this.loader.hide();
        },
        error: (err) => {
          this.errorMsg = 'Rename List failed due to' + err.status;
           this.loader.hide();
          this.nameCtrl.enable();
        },
      });
      
  }
}
