import {
  AfterViewInit,
  Component,
  ElementRef,
  HostBinding,
  Inject,
  Injector,
  Input,
} from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ComponentType } from '@angular/cdk/portal';

export interface CommonDialogData {
  title?: string;
  dialogId?: string;
  info?: string;
  warningMessage?: string;
  component: ComponentType<any>; // <-- dynamic component
  componentData?: any;
  enableAction?: boolean; // <-- data passed to component
  enableClose?: boolean; // <-- data passed to component
}

@Component({
  selector: 'app-common-dialog',
  standalone: false,
  templateUrl: './common-dialog.html',
  styleUrl: './common-dialog.scss',
})
export class CommonDialogComponent {
  @HostBinding('attr.id') id: string | null = null;
  childInjector!: Injector;
  constructor(
    public dialogRef: MatDialogRef<CommonDialogComponent>,
    private el: ElementRef,
    @Inject(MAT_DIALOG_DATA) public data: CommonDialogData,
  ) {
    this.childInjector = Injector.create({
      providers: [{ provide: 'componentData', useValue: this.data.componentData }],
    });
    this.id = data.dialogId || null;
  }
}
