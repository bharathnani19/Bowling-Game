import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { HomePageService } from '../../../services/homepage.service';

@Component({
  selector: 'app-model-detail-dialog',
  templateUrl: './model-detail.html',
  styleUrls: ['./model-detail.scss'],
  standalone: false,
})
export class ModelDetailDialogComponent {
  selectedInfoTabIndex: number = 0;
  tableClass?: string;
  data: any = {};
  tab1Label: string = 'Active';
  tab1Info: string = 'Active models';
  tab2Label: string = 'Inactive';
  tab2Info: string = 'Inactive models';
  printOptions = { fontSize: 10, orientation: 'landscape' as const, compact: true };

  constructor(
    public dialogRef: MatDialogRef<ModelDetailDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public dataIn: { vulnerabilityType: string; tab1Data: any[]; tab2Data: any[]},
    private _homeService: HomePageService
  ) {
    this.data = dataIn;
  }

  // edit or model dialog
  get vulnerabilityType() {
    return this.data.vulnerabilityType === 'edit' ? 'edit' : (this.data.vulnerabilityType === 'medicaid' ? 'medicaid' : 'medicare');
  }

  // no search for Edit dialog
  get enableSearch() {
    return this.data.vulnerabilityType === 'edit' ? false : true;
  }

  get dialogTitle() {
    return this.data.vulnerabilityType === 'edit' ? 'Edit Details' : 'All Model Details';
  }

  get inactiveTabLabel() {
    return this.data.vulnerabilityType === 'edit' ? 'Inactive' : 'Inactive/Decommissioned';
  }


}
