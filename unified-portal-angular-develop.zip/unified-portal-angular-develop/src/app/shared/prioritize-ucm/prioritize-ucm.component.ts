import { Component, Inject } from '@angular/core';
import { FormControl, NgForm } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { OktaService } from '../../services/okta';
import { TriageService } from '../../services/triage.service';
import { MatDialog } from '@angular/material/dialog';
import { ToastService } from '../../services/toaster.service';
import { HttpErrorResponse } from '@angular/common/http';

export class CustomErrorStateMatcher implements ErrorStateMatcher {
  constructor(private hasError: () => boolean) {}

  isErrorState(control: FormControl | null, form: NgForm | null): boolean {
    return this.hasError();
  }
}

@Component({
  selector: 'app-prioritize-ucm-table',
  templateUrl: './prioritize-ucm.component.html',
  styleUrls: ['./prioritize-ucm.component.scss'],
  standalone: false,
})
export class PrioritizeUcmTableComponent {
  rowData: any[] = [];
  columns: any[] = [];
  tableName: string = '';
  tableId: string = '';
  isLoading = false;
  pageSize = 10;

  constructor(
    @Inject('componentData') public data: any,
    private _oktaService: OktaService,
    private _triageService: TriageService,
    private _matDialog: MatDialog,
    private _toaster: ToastService,
  ) {
    this._initData();
  }

  private _initData() {
    this.rowData = this.data?.rowData.map((o: any) => {
      let preSelected: any = [];

      if (o.alerts && o.alerts.length === 1 && o.alerts[0].disabled !== 'true') {
        preSelected = [o.alerts[0]];
      }

      const row = {
        ...o,
        comment: '',
        selectedAlerts: preSelected,
        selectedStates: [],
        showAlertError: false,
        showCommentError: false,
        showStateError: false,
      };

      row.alertMatcher = new CustomErrorStateMatcher(() => row.showAlertError);
      row.stateMatcher = new CustomErrorStateMatcher(() => row.showStateError);
      row.commentMatcher = new CustomErrorStateMatcher(() => row.showCommentError);

      // If one alert is pre-selected and it has only one state
      if (preSelected.length === 1 && preSelected[0].states?.length === 1) {
        row.selectedStates = [preSelected[0].states[0]];
      }

      return row;
    });

    this.columns = this.data?.columns || [];
    this.tableName = this.data?.tableName || 'Details Table';
    this.tableId = this.data?.tableId || 'detailsTable';
  }

  // Get states dynamically based on selected alerts
  getStatesForRow(row: any) {
    if (!row.selectedAlerts || row.selectedAlerts.length === 0) {
      return [];
    }
    const states = row.selectedAlerts.map((alert: any) => alert.states || []).flat();

    return states;

    // Optional: remove duplicates by modelLabel
    return Array.from(new Map(states.map((s: any) => [s.modelLabel, s])).values());
  }

  // Triggered when alerts selection changes
  onAlertChange(row: any) {
    const validStates = this.getStatesForRow(row);

    // Remove states no longer valid
    row.selectedStates = (row.selectedStates || []).filter((s: any) =>
      validStates.some((vs: any) => vs.modelLabel === s.modelLabel),
    );
  }

  /**
   * VALIDATION LOGIC
   */
  private validateRows(): boolean {
    let isValid = true;

    this.rowData.forEach((row) => {
      row.showAlertError = false;
      row.showCommentError = false;
      row.showStateError = false;

      const hasAlerts = row.alerts && row.alerts.length > 0;
      const hasSelectedAlerts = row.selectedAlerts && row.selectedAlerts.length > 0;
      const hasSelectedStates = row.selectedStates && row.selectedStates.length > 0;
      const hasComment = row.comment && row.comment.trim().length > 0;
      const availableStates = this.getStatesForRow(row);
      const hasStates = availableStates.length > 0;

      // Rule 1: If alerts exist → must select at least one
      if (hasAlerts && !hasSelectedAlerts) {
        row.showAlertError = true;
        isValid = false;
      }

      // Rule 2: If no alerts → comment required
      if (!hasAlerts && !hasComment) {
        row.showCommentError = true;
        isValid = false;
      }

      // Rule 3: If states exist → must select at least one
      if (hasStates && !hasSelectedStates) {
        row.showStateError = true;
        isValid = false;
      }
    });

    return isValid;
  }

  /**
   * PAYLOAD BUILDING
   */
  private buildPayload() {
    return {
      priorities: this.rowData.map((row) => {
        const items =
          row.alerts?.map((alert: any) => {
            const isSelected = row.selectedAlerts?.some(
              (sel: any) => sel.modelBusnsId === alert.modelBusnsId && sel.status === alert.status,
            );
            if (this.data.programType !== 'medicare')
              alert.states = alert.states.filter((s: any) =>
                row.selectedStates.some((o: any) => o.modelLabel === s.modelLabel),
              );
              delete alert['showClaimsLinkInd'];
            return {
              ...alert,
              ...(isSelected ? { prioritizedInd: 'Y' } : {}),
            };
          }) || [];

        return {
          asrDbId: `${row.asrptId}`,
          zone: this._oktaService.user().oldOrganizationVal,
          userId: this._oktaService.user().oktaDetails?.preferred_username,
          programType: this.data.programType,
          comments: row.comment,
          asrPrioritizationModelItems: items,
        };
      }),
    };
  }

  priortizeforUCM() {
    if (this.data.programType !== 'medicare') {
      const allValid = this.rowData.every((e: any) => {
        return e.alerts?.some((alert: any) => alert.states?.length > 0);
      });

      if (!allValid) {
        this._toaster.error(
          'Prioritization to UCM can only be done for models that have alerted in a states within your jurisdiction',
        );
        return;
      }
    }

    const isValid = this.validateRows();

    if (!isValid) {
      console.log('Validation failed');
      this._toaster.error('Please correct the errors before continuing.');
      return;
    }

    const payload = this.buildPayload();

    this._triageService.prioritizeASRsForUCM(payload).subscribe(
      (res: any) => {
        this._toaster.success('ASRs successfully Prioritized for UCM.');
        this._matDialog.closeAll();
      },
      (error: HttpErrorResponse) => {
        this._toaster.error('Prioritize ASRs for UCM failed due to ' + error.status);
      },
    );
  }

  closepriortizeforUCM() {
    this._matDialog.closeAll();
  }
}
