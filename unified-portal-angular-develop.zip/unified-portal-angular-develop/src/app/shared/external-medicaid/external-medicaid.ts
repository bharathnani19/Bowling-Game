import { Component, Inject } from '@angular/core';
import { ExternalMedicaid } from '../../modules/asr-detail/model';

@Component({
  selector: 'external-medicaid',
  templateUrl: './external-medicaid.html',
  styleUrl: './external-medicaid.scss',
  standalone: false

})
export class ExternalMedicaidComponent {
  summaryData: ExternalMedicaid;
  columns: any[];
  tableName: string;
  tableId: string;
  isLoading = false;
  pageSize = 10;

  constructor(@Inject('componentData') public data: any) {
    this.summaryData = data.summaryData ;
    this.columns = this.data?.columns || [];
    this.tableName = this.data?.tableName || 'Details Table';
    this.tableId = this.data?.tableId || 'detailsTable';
  }
}
