import { Component, Input } from '@angular/core';

export interface DetailCardItem {
  label: string;
  value: string | number | null | undefined;
  colSpan?: number;
}

export interface DetailCardChild {
  title: string;
  columns?: number;
  items: DetailCardItem[];
}

export interface DetailCardSection {
  title: string;
  children: DetailCardChild[];
}

export interface DetailCard {
  title: string;
  height?: string;
  sections: DetailCardSection[];
}

@Component({
  selector: 'detail-card',
  standalone: false,
  template: `
    <div class="detail-card">
      <div class="detail-card__header">
        {{ data.title }}
      </div>

      <div class="detail-card__body">
        <ng-container *ngFor="let section of data.sections">
          <h3 class="section-title">{{ section.title }}</h3>

          <ng-container *ngFor="let child of section.children">
            @if (child.title) {
              <h4 class="child-title">{{ child.title }}</h4>
            }

            <div
              class="detail-grid"
              [style.grid-template-columns]="
                'repeat(' + (child.columns || 4) + ', minmax(0, 1fr))'
              "
            >
              <div
                *ngFor="let item of child.items"
                class="detail-item"
                [style.grid-column]="'span ' + (item.colSpan || 1)"
              >
                <div class="detail-item__label">
                  {{ item.label }}
                </div>

                <div class="detail-item__value">
                  {{ displayValue(item.value) }}
                </div>
              </div>
            </div>
          </ng-container>
        </ng-container>
      </div>
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        height: 100%;
        min-height: 0;
        overflow: hidden;
      }

      .detail-card {
        display: flex;
        flex-direction: column;
        height: 100%;
        min-height: 0;
        border-radius: 8px;
        overflow: hidden;
        border: 1px solid #50526d;
        background: #44455f;
        color: #fff;
      }

      .detail-card__header {
        flex-shrink: 0;
        padding: 12px 16px;
        background: #2d2f48;
        font-size: 15px;
        font-weight: 600;
      }

      .detail-card__body {
        flex: 1 1 auto;
        min-height: 0;
        padding: 16px;
        overflow-y: auto;
      }

      .section-title {
        margin: 20px 0 12px;
        font-size: 15px;
        font-weight: 600;
      }

      .section-title:first-child {
        margin-top: 0;
      }

      .child-title {
        margin: 0 0 12px;
        font-size: 14px;
        font-weight: 600;
        color: rgba(255, 255, 255, 0.85);
      }

      .detail-grid {
        display: grid;
        gap: 20px;
        margin-bottom: 24px;
      }

      .detail-item {
        min-width: 0;
      }

      .detail-item__label {
        margin-bottom: 4px;
        font-size: 14px;
        font-weight: 500;
        color: rgba(255, 255, 255, 0.7);
      }

      .detail-item__value {
        font-size: 12px;
        word-break: break-word;
      }

      @media (max-width: 768px) {
        .detail-grid {
          grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
        }
      }

      @media (max-width: 576px) {
        .detail-grid {
          grid-template-columns: 1fr !important;
        }
      }
    `,
  ],
})
export class DetailCardComponent {
  @Input({ required: true })
  data!: DetailCard;

  displayValue(value: string | number | null | undefined): string | number {
    return value === null || value === undefined || value === '' ? '-' : value;
  }
}