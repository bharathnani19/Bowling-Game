export class User {
  attributes?: string;
  organization?: string;
  oldOrganizationVal?: string;
  groups?: string[];
  userHasEditsRole?: boolean;
  rolesArray?: any[];
  userAttrArray?: any[];
  zonesArray?: any[];
  userDisplayName?: string;
  rolesStr?: string;
  showAttributes?: boolean;
  oktaDetails?: any;
  preferred_username?: string;
  userRequest?:string;
  disableMedicaid?:boolean;
  disableMedicaidMAC?:boolean;
  macUser?:boolean;
}
