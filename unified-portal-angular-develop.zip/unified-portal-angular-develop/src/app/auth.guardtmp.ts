import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { OktaService } from './services/okta';
import { SessionService } from './services/session-timeout-service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {

  constructor(
    private okta: OktaService,
    private router: Router,
    private sessionService:SessionService
  ) { }

  private getBaseHref(): string {
    const baseHref = document.querySelector('base')?.getAttribute('href')?.trim() || '/';

    if (baseHref === '.' || baseHref === './') {
      return '/';
    }

    return baseHref.endsWith('/') ? baseHref.slice(0, -1) : baseHref;
  }

  async canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean> {

    const hasCallbackParams =
      window.location.search.includes('code=') ||
      window.location.search.includes('state=');

    if (hasCallbackParams) {
      const { tokens } = await this.okta.oktaAuth.token.parseFromUrl();
      this.okta.oktaAuth.tokenManager.setTokens(tokens);

      const originalUri = await this.okta.oktaAuth.getOriginalUri();
      this.okta.oktaAuth.removeOriginalUri();

      this.router.navigateByUrl(originalUri || this.getBaseHref());
      this.sessionService.startSessionTimeout();
      
      return false;
    }

    const authenticated = await this.okta.oktaAuth.isAuthenticated();

    if (!authenticated) {
      await this.okta.oktaAuth.setOriginalUri(state.url);
      await this.okta.oktaAuth.signInWithRedirect();
      return false;
    }

    await this.okta.loadUser();
    return true;
  }

}
