import { Component, Input } from '@angular/core';
import {
  MEDICAID_ALERT_DLG_COLUMNS,
  MEDICAID_ALERTS_HISTORY_COLUMNS,
  MEDICAID_ASR_HISTORY_COLUMNS,
  MODEL_GUIDANCE_COLUMNS,
} from '../../column-config';
import { AsrDetails } from '../../model';
import { MatDialog } from '@angular/material/dialog';
import { AsrDetailsService } from '../../../../services/asr-details.service';
import { LoaderService } from '../../../../services/loader.service';
import { ToastService } from '../../../../services/toaster.service';
import { OktaService } from '../../../../services/okta';
import { ASRDetailsTableComponent } from '../../asr-detail-table/asr-detail-table';
import { CommonDialogComponent } from '../../../../shared/dialog/common-dialog/common-dialog';

@Component({
  selector: 'medicaid-history',
  templateUrl: './medicaid-history.html',
  styleUrls: ['../../asr-detail.scss'],
  standalone: false,
})
export class MedicaidHistoryComponent {
  @Input() asrDetails: AsrDetails | null = null;
  selectedTabIndex: any;
  asrHistoryColumns = MEDICAID_ASR_HISTORY_COLUMNS;
  asrAlertsColumns = MEDICAID_ALERTS_HISTORY_COLUMNS;
  historyAlertsData: any[] = [];

  constructor(
    public dialog: MatDialog,
    private _detailsService: AsrDetailsService,
    private _loader: LoaderService,
    private _toaster: ToastService,
    public okta: OktaService,
  ) {}

  onAlertsTab() {
    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicaid', 'HALERTS', String(this.asrDetails?.mdcdAsrDbId ?? '0'))
      .subscribe({
        next: (res: any) => {
          this.historyAlertsData = res?.responseData?.oldAlert || [];
          this._loader.hide();
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(`Error loading Alerts data to ${err?.status || 'error'}`);
        },
      });
  }

  openTableDialog(data: any, width: string = '80%') {
    this.dialog.open(CommonDialogComponent, {
      width,
      data: {
        ...data,
      },
      panelClass: 'ip-dialog-panel',
    });
  }

  openModels(row: any) {
    this.openTableDialog(
      {
        title: 'Models',
        info: "This table displays the selected model's details. To obtain an available Model Guidance document, select the model name hyperlink.",
        dialogId: 'modalsModal',
        componentData: {
          rowData: [row?.models],
          columns: MODEL_GUIDANCE_COLUMNS,
          tableName: 'Models Table',
          tableId: 'ModalsTable',
          componentId: 'Modals',
        },
        panelClass: 'ip-dialog-panel',
        component: ASRDetailsTableComponent,
        enableClose: true,
      },
      '80%',
    );
  }
  onViewAlerts(row: any) {
    row.alerts = row.alerts?.map((alert: any) => ({
      ...alert,
      asrDbId: row.asrptId,
      modelId: row?.models?.modelId,
    }));
    const title = 'Alerts Model – ' + row.modelBusnsId;
    this.openTableDialog(
      {
        title: title,
        info: 'The table below provides the details associated with each alert, or each time the ASR ID was identified during a model run. To learn about the information contained within the table below, hover over the information indicators.',
        dialogId: 'alertsModal',
        componentData: {
          rowData: row?.alerts,
          columns: MEDICAID_ALERT_DLG_COLUMNS,
          asrDetails: this.asrDetails,
          tableName: 'Alerts Table',
          tableId: 'AlertsTable',
          componentId: 'Alerts',
        },
        panelClass: 'ip-dialog-panel',
        component: ASRDetailsTableComponent,
        enableClose: true,
      },
      '80%',
    );
  }
}
