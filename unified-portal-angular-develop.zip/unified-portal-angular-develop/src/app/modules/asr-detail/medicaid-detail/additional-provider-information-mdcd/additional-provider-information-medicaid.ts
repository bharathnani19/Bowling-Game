import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { AsrDetails } from '../../model';
import { OktaService } from '../../../../services/okta';
import { AsrDetailsService } from '../../../../services/asr-details.service';
import { LoaderService } from '../../../../services/loader.service';
import { ToastService } from '../../../../services/toaster.service';
import {
  ASR_EXTERNAL_MEDICAID_COLUMNS,
  ASR_MDCD_ENROLLMENT_COLUMNS,
  ASR_PRIORITIZATION_SUMMARY_MEDICAID_COLUMNS,
  ASR_SPECIALTY_COLUMNS,
} from '../../../asr-detail/column-config';
import { ASRDetailsTableComponent } from '../../asr-detail-table/asr-detail-table';
import { ExternalMedicaidComponent } from '../../../../shared/external-medicaid/external-medicaid';
import { MatDialog } from '@angular/material/dialog';
import { CommonDialogComponent } from '../../../../shared/dialog/common-dialog/common-dialog';

@Component({
  selector: 'additional-provider-information-medicaid',
  templateUrl: './additional-provider-information-medicaid.html',
  styleUrls: ['../../asr-detail.scss'],
  standalone: false,
})
export class AdditionalProviderInformationMedicaidComponent {
  @Input() asrDetails!: AsrDetails | null;

  constructor(
    public okta: OktaService,
    public dialog: MatDialog,
    private _detailsService: AsrDetailsService,
    private _loader: LoaderService,
    private _toaster: ToastService,
  ) {}

  openTableDialog(data: any, width: string = '80%') {
    this.dialog.open(CommonDialogComponent, {
      width,
      data: {
        ...data,
      },
      panelClass: 'ip-dialog-panel',
    });
  }

  openPrioritizationPopup() {
    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicaid', 'priority', this.asrDetails?.provider?.npi ?? 'none')
      .subscribe({
        next: (res: any) => {
          const priorities = res?.responseData?.priorities || [];
          this._loader.hide();

          this.openTableDialog(
            {
              title: 'Prioritized',
              info: 'The below table displays the ASR&#39;s prioritization details including the user, jurisdiction, and prioritized date.',
              dialogId: 'prvdrPrioritizedModal',
              componentData: {
                rowData: priorities,
                columns: ASR_PRIORITIZATION_SUMMARY_MEDICAID_COLUMNS,
                tableName: 'Prioritization Table',
                tableId: 'prvdrPrioritizedTable',
              },
              panelClass: 'ip-dialog-panel',
              component: ASRDetailsTableComponent,
              enableClose: true
            },
            //,
            //'90%',
          );
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(
            `Unable to load ASR prioritization data to ${err?.status || 'error'}`,
          );
        },
      });
  }

  openSpecialtiesPopup() {
    this.openTableDialog(
      {
        title: 'Medicaid Alerted ASR Specialty',
        info: 'The below table displays the specialty codes associated with the ASR ID&#39;s claims at risk.',
        dialogId: 'specialtiesModal',
        componentData: {
          rowData: this.asrDetails?.provider?.specialties,
          columns: ASR_SPECIALTY_COLUMNS,
          tableName: 'ASR Specialty',
          tableId: 'specialtiesTable',
        },
        panelClass: 'ip-dialog-panel',
        component: ASRDetailsTableComponent,
        enableClose: true
      },
      //,
      //'90%',
    );
  }
  openEnrollmentPopup() {
    this._loader.show();
    this.openTableDialog(
      {
        title: 'Associated Enrollment IDs',
        info: "The below table displays the Medicaid ID, State, Enrollment Status, Effective Date, and Termination Date for the billing provider that indicated that ASR's NPI as the admitting, billing, home health, operating, prescribing, referring, prescription dispensing, servicing, supervising, or other providers in the claims data.",
        dialogId: 'medicaidEnrollmentIdModal',
        componentData: {
          rowData: this.asrDetails?.provider?.mdcdEnrollmentIds,
          columns: ASR_MDCD_ENROLLMENT_COLUMNS,
          tableName: 'Enrollment ID Table',
          tableId: 'medicaidEnrollmentIdModalTable',
        },
        panelClass: 'ip-dialog-panel',
        component: ASRDetailsTableComponent,
        enableClose: true
      },
      //,
      //'90%',
    );
    this._loader.hide();
  }
  openExternalMedicaidPopup() {
    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicaid', 'medicaid', this.asrDetails?.provider?.npi ?? 'none')
      .subscribe({
        next: (res: any) => {
          const data = res?.responseData?.provider?.medicaidInfo || {};
          this._loader.hide();

          this.openTableDialog(
            {
              title: 'Medicaid Details',
              dialogId: 'medicaidModalMDCD',
              componentData: {
                summaryData: data,
                columns: ASR_EXTERNAL_MEDICAID_COLUMNS,
                tableName: 'Medicaid Table',
                tableId: 'medicaidModalTable',
              },
              panelClass: 'ip-dialog-panel',
              component: ExternalMedicaidComponent,
              enableClose: true
            },
            //,
            //'90%',
          );
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(
            `Unable to load ASR external medicaid data to ${err?.status || 'error'}`,
          );
        },
      });
  }
}
