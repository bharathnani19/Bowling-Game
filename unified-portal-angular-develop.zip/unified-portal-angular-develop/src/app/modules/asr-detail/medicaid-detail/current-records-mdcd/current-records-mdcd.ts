import { Component, Input, OnChanges } from '@angular/core';
import {
  MEDICAID_ALERTS_COLUMNS_MDCD,
  MEDICAID_ALERT_DLG_COLUMNS,
  PHASE1_ALERTS_COLUMNS,
  EDITS_COLUMNS,
  MODEL_GUIDANCE_COLUMNS,
  MEDICAID_LEADS_COLUMNS,
  MEDICAID_SUPPORTING_DATA_COLUMNS,
} from '../../column-config';
import { AsrDetails } from '../../model';
import { MatDialog } from '@angular/material/dialog';
import { CommonDialogComponent } from '../../../../shared/dialog/common-dialog/common-dialog';
import { ASRDetailsTableComponent } from '../../asr-detail-table/asr-detail-table';
import { FileUploadService } from '../../../../services/file-upload.service';
import { LoaderService } from '../../../../services/loader.service';
import { ToastService } from '../../../../services/toaster.service';
import { ReportCardsComponent } from '../../medicare-detail/current-records/report-cards/report-cards.component';

@Component({
  selector: 'current-records-mdcd',
  templateUrl: './current-records-mdcd.html',
  styleUrls: ['../../asr-detail.scss'],
  standalone: false,
})
export class CurrentRecordsMDCDComponent implements OnChanges {
  @Input() asrDetails: AsrDetails | null = null;

  constructor(
    public dialog: MatDialog,
    private _fileService: FileUploadService,
    private _loader: LoaderService,
    private _toaster: ToastService,
  ) {}

  alertColumns = MEDICAID_ALERTS_COLUMNS_MDCD.map((column: any) => ({ ...column }));
  p1AlertColumns = PHASE1_ALERTS_COLUMNS.map((column: any) => ({ ...column }));
  editColumns = EDITS_COLUMNS.map((column: any) => ({ ...column }));
  leadsInvColumns = MEDICAID_LEADS_COLUMNS.map((column: any) => ({ ...column }));
  mdcdTotalPaymentColumns = MEDICAID_SUPPORTING_DATA_COLUMNS;
  selectedTabIndex: any;
  mdcdStateSet = new Set<string>();

  ngOnChanges(): void {
    this.mdcdStateSet = new Set(this.asrDetails?.mdcdUserStates?.map((x) => x.state) ?? []);
  }

  canExportClaimLines(row: any): boolean {
    return this.mdcdStateSet.has(row.state);
  }

  openTableDialog(data: any, width: string = '80%') {
    this.dialog.open(CommonDialogComponent, {
      width,
      data: {
        ...data,
      },
      panelClass: 'ip-dialog-panel',
    });
  }

  openModels(row: any) {
    this.openTableDialog(
      {
        title: 'Models',
        info: "This table displays the selected model's details. To obtain an available Model Guidance document, select the model name hyperlink.",
        dialogId: 'modalsModal',
        componentData: {
          rowData: [row?.models],
          columns: MODEL_GUIDANCE_COLUMNS,
          tableName: 'Models Table',
          tableId: 'ModalsTable',
          componentId: 'Modals',
        },
        panelClass: 'ip-dialog-panel',
        component: ASRDetailsTableComponent,
        enableClose: true,
      },
      '80%',
    );
  }

  onExportClaimLines(row: any) {
    this._loader.show();
    this._fileService
      .downloadClaimsDocument({
        asrId: `${row?.asrptId}`,
        npi: `${row?.asrptId}`,
        modelId: `${row?.alertId}`,
        fileName: 'alert-claims-export.csv',
        pType: row?.partDClaimInd,
        state: row?.mdcdState,
      })
      .subscribe({
        next: (res: any) => {
          this._loader.hide();
        },
        error: (err: any) => {
          this._loader.hide();
          console.log('(current-records-mdcd) onExportClaimLines error:', err);
          this._toaster.error('Unable to download document due to ' + err.status);
        },
      });
  }

  onViewAlerts(row: any) {
    row.alerts = row.alerts?.map((alert: any) => ({
      ...alert,
      asrDbId: row.asrptId,
      modelId: row?.models?.modelId,
    }));
    const title = 'Alerts Model – ' + row.modelBusnsId;
    this.openTableDialog(
      {
        title: title,
        info: 'The table below provides the details associated with each alert, or each time the ASR ID was identified during a model run. To learn about the information contained within the table below, hover over the information indicators.',
        dialogId: 'alertsModal',
        componentData: {
          rowData: row?.alerts,
          columns: MEDICAID_ALERT_DLG_COLUMNS,
          asrDetails: this.asrDetails,
          tableName: 'Alerts Table',
          tableId: 'AlertsTable',
          componentId: 'Alerts',
          type: 'MDCD'
        },
        panelClass: 'ip-dialog-panel',
        component: ASRDetailsTableComponent,
        enableClose: true,
        
      },
      '80%',
    );
  }

  onViewReportCard(row: any) {
    const reportCardRow = {
      ...row,
      modelId: row?.modelId ?? row?.alertId,
      npi: row?.npi ?? this.asrDetails?.provider?.npi ?? row?.asrptId,
      type: 'medicaid',
    };

    this.openTableDialog(
      {
        title: 'Report Cards',
        info: 'Report Cards provide the alert and model attribution details associated with the ASR ID. The report card layout and associated tables vary by model and model table; however, the report card section of the model guidance document associated with the select model provides further details regarding the displayed report card. To learn about the information and functions contained within the report card, hover over the information indicators below.',
        dialogId: 'reportCardsModal',
        componentData: {
          rowData: [reportCardRow, this.asrDetails, 'medicaid'],
        },
        panelClass: 'ip-dialog-panel',
        component: ReportCardsComponent,
        enableClose: true,
      },
      '80%',
    );
  }
}
