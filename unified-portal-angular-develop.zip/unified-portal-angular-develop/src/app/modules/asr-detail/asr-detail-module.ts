import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AsrDetailRoutingModule } from './asr-detail-routing-module';
import { AsrDetailComponent } from './asr-detail';
import { SharedModule } from '../../shared/shared.module';
import { MaterialModule } from '../../shared/material.module';
import { ProviderSummaryComponent } from './medicare-detail/provider-summary/provider-summary';
import { AdditionalProviderInformationComponent } from './medicare-detail/additional-provider-information/additional-provider-information';
import { CurrentRecordsComponent } from './medicare-detail/current-records/current-records';
import { SupportingDataComponent } from './medicare-detail/supporting-data/supporting-data';
import { MedicareHistoryComponent } from './medicare-detail/medicare-history/medicare-history';
import { ProviderSummaryMedicaidComponent } from './medicaid-detail/provider-summary-medicaid/provider-summary-medicaid';
import { AdditionalProviderInformationMedicaidComponent } from './medicaid-detail/additional-provider-information-mdcd/additional-provider-information-medicaid';
import { CurrentRecordsMDCDComponent } from './medicaid-detail/current-records-mdcd/current-records-mdcd';
import { MedicaidHistoryComponent } from './medicaid-detail/medicaid-history-mdcd/medicaid-history';
import {
  AsrDetailLinkPipe,
  DynamicPipe,
  RiskScorePipe,
  YesNoPipe,
} from '../../shared/custom-pipes';
import { ASRDetailsTableComponent } from './asr-detail-table/asr-detail-table';
import { BiuSummaryComponent } from '../../shared/biu-summary/biu-summary';
import { ExternalMedicaidComponent } from '../../shared/external-medicaid/external-medicaid';
import { EditsComponent } from './medicare-detail/current-records/edits/edits';
import { LeadsComponent } from './medicare-detail/current-records/Leads/leads';
import { LeadDetailComponent } from './medicare-detail/current-records/Leads/lead-detail/lead-detail.component';
import { ReportCardsComponent } from './medicare-detail/current-records/report-cards/report-cards.component';
import { RiskScoreExplComponent } from './medicare-detail/supporting-data/risk-score-expl/risk-score-expl';
import { PriorityScoreComponent } from './medicare-detail/supporting-data/priority-score/priority-score';
import { TpeComponent } from './medicare-detail/supporting-data/tpe/tpe';
import { RiskScoreTrendingComponent } from './medicare-detail/supporting-data/risk-score-trending/risk-score-trending';
import { TopFiveCodesComponent } from './medicare-detail/supporting-data/top-five-codes/top-five-codes';
import { DualEligBenesComponent } from './medicare-detail/supporting-data/dual-elig-benes/dual-elig-benes';
import { GoogleMapsModule } from '@angular/google-maps';
import { ClaimsComponent } from './medicare-detail/current-records/claims/claims';
import { ClaimsMdcdComponent } from './medicare-detail/current-records/claims/claims-mdcd';
import { AsrGoogleMapModalComponent } from './asr-google-map-modal/asr-google-map-modal';
import { VisualizationDialogComponent } from './visualization/visualization';

const COMPONENTS = [
  AsrDetailComponent,
  ProviderSummaryComponent,
  AdditionalProviderInformationComponent,
  CurrentRecordsComponent,
  SupportingDataComponent,
  MedicareHistoryComponent,
  ProviderSummaryMedicaidComponent,
  AdditionalProviderInformationMedicaidComponent,
  CurrentRecordsMDCDComponent,
  MedicaidHistoryComponent,
  ASRDetailsTableComponent,
  BiuSummaryComponent,
  ExternalMedicaidComponent,
  EditsComponent,
  LeadsComponent,
  LeadDetailComponent,
  ReportCardsComponent,
  RiskScoreExplComponent,
  PriorityScoreComponent,
  RiskScoreTrendingComponent,
  TpeComponent,
  TopFiveCodesComponent,
  DualEligBenesComponent,
  ClaimsComponent,
  VisualizationDialogComponent,
  ClaimsMdcdComponent,
  AsrGoogleMapModalComponent,
];

const PIPES = [RiskScorePipe, YesNoPipe, DynamicPipe, AsrDetailLinkPipe];

@NgModule({
  declarations: [...COMPONENTS],
  
  imports: [
    CommonModule,
    AsrDetailRoutingModule,
    SharedModule,
    MaterialModule,
    GoogleMapsModule,
    ...PIPES,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AsrDetailModule {}
