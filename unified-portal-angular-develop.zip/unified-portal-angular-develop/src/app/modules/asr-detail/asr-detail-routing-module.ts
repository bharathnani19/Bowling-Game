import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AsrDetailComponent } from './asr-detail';

const routes: Routes = [
  {
    path:'',
    component: AsrDetailComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AsrDetailRoutingModule { }
