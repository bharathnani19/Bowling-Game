import {
  CommonModule,
  DOCUMENT,
} from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  effect,
  HostListener,
  inject,
  input,
  output,
  signal,
  viewChild,
  WritableSignal,
  untracked,
} from '@angular/core';
import { firstValueFrom } from 'rxjs';

import {
  AsrAddress,
  AsrMapBeneficiary,
  AsrMapMessageType,
  AsrMapProvider}  from '../model';
import { AsrGoogleMapApiService } from '../../../services/asr-google-map-api.service';
import { GoogleMapsLoaderService } from '../../../services/google-maps-loader.service';
import { environment } from '../../../environments/environment.shared';
import { MAT_DIALOG_DATA, MatDialogActions, MatDialogContent, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { OktaService } from '../../../services/okta';
import { User } from '../../../models/user.model';

type GoogleGeometryResult = {
  geometry: {
    location: unknown;
  };
};

type GoogleMapLike = {
  setCenter(location: unknown): void;
  getStreetView(): {
    setPosition(position: unknown): void;
    setPov(pov: { heading: number; pitch: number }): void;
    getVisible(): boolean;
    setVisible(visible: boolean): void;
  };
};

declare const google: any;
type AsrGoogleMapDialogData = {
  asrptId: number | string;
  modelId: number ;
  modelMode: boolean;
  providerAddr: any;


};
@Component({
  selector: 'asr-google-map-modal',
  standalone: false,
  templateUrl: './asr-google-map-modal.html',
  styleUrl: './asr-google-map-modal.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AsrGoogleMapModalComponent {
  readonly open = input(false);
  readonly restUrl = environment.appUrl;
  readonly asrptId = input.required<number | string>();
  readonly userId = "NA";
  readonly googleMapsApiKey = "AIzaSyA5gM3U4DrN5D04D6678Ma_Vf37ybnDv1s";
  readonly closed = output<void>();
  readonly modelId = input<number>();
  readonly providerAddr = input<any>();


  protected readonly mapCanvas = viewChild<ElementRef<HTMLDivElement>>('mapCanvas');
  protected readonly busy = signal(false);
  protected readonly message = signal<string | null>(null);
  protected readonly messageType = signal<AsrMapMessageType | null>(null);
  protected readonly resetCoolingDown = signal(false);
  protected readonly addCoolingDown = signal(false);
  protected readonly resultsIndex = signal(0);

  private readonly document = inject(DOCUMENT);
  private readonly api = inject(AsrGoogleMapApiService);
  private readonly mapsLoader = inject(GoogleMapsLoaderService);
  private readonly dialogRef = inject(MatDialogRef<AsrGoogleMapModalComponent>, {
    optional: true,
  });
  private readonly dialogData = inject<AsrGoogleMapDialogData | null>(MAT_DIALOG_DATA, {
    optional: true,
  });
  private readonly openInProgress = signal(false);

  private map?: GoogleMapLike;
  private geocoder?: any;
  private providerLocation?: unknown;
  private providerMarker?: any;
  private beneficiaryMarkers: any[] = [];
  private beneficiaryLines: any[] = [];
  user!:User;

  constructor(public okta: OktaService,) {
    this.user = this.okta.user();
    if (!this.dialogRef || !this.dialogData) {
      throw new Error('AsrGoogleMapModalComponent must be opened via MatDialog with data.');
    }

    void this.initializeAndLoad();
  }



  protected async resetMap(): Promise<void> {
    if (this.busy() || this.resetCoolingDown()) {
      return;
    }

    this.startCooldown(this.resetCoolingDown);
    this.resultsIndex.set(0);
    await this.initializeAndLoad();
  }

  protected async addTenBeneficiaries(): Promise<void> {
    if (this.busy() || this.addCoolingDown()) {
      return;
    }

    this.startCooldown(this.addCoolingDown);

    const nextResultsIndex = this.resultsIndex() + 1;

    this.busy.set(true);
    this.clearMessage();

    try {
      const response = await firstValueFrom(
    
        this.api.getAsrMapsInfo(
          this.getAsrptId() ?? 0,
          nextResultsIndex,
          this.user.oktaDetails.preferred_username!
          
        ) 
      
        
      );

      const benes = response.responseData.provider.benes ?? [];

      if (!benes.length) {
        this.message.set('There are no more results to display on the map.');
        this.messageType.set('info');
        return;
      }

      this.resultsIndex.set(nextResultsIndex);
      await this.addBeneficiaryMarkers(benes);
    } catch (error) {
      this.setError(this.formatRestError(error));
    } finally {
      this.busy.set(false);
    }
  }

  protected closeModal(): void {
    this.dialogRef?.close();
  }

  protected closeOnBackdrop(event: MouseEvent): void {
    if (event.target === event.currentTarget) {
      this.closeModal();
    }
  }

  private async initializeAndLoad(): Promise<void> {
    if (this.openInProgress() ) {
      return;
    }

    this.openInProgress.set(true);
    this.busy.set(true);
    this.clearMessage();

    try {
      await this.mapsLoader.load(this.googleMapsApiKey);
      await this.waitForCanvas();
      this.initializeMap();
      if (!this.getModelId()){
        const response = await firstValueFrom(
              this.api.getAsrMapsInfo(
            this.getAsrptId() ?? 0 ,
            this.resultsIndex(),
            this.user.oktaDetails.preferred_username!
            
        ));
         await this.renderAsrLevelMap(response.responseData.provider)
      }else{
        const response = await firstValueFrom(
          this.api.getModelBenes(
           this.getModelId() ?? 0,
          this.getAsrptId() ?? 0         
          
          )
        );
        await this.renderModelLevelMap(response)

      }
   
       
    } catch (error) {
      this.setError(this.formatRestError(error));
    } finally {
      this.busy.set(false);
      this.openInProgress.set(false);
    }
  }

  private initializeMap(): void {
    const canvas = this.mapCanvas()?.nativeElement;

    if (!canvas) {
      throw new Error('Google map canvas is not available.');
    }
    if (typeof google?.maps?.Map !== 'function') {
      throw new Error(
        'Google Maps JavaScript API is not fully initialized. Ensure googleMapsApiUrl targets https://maps.googleapis.com/maps/api/js.',
      );
    }

    this.map = new google.maps.Map(canvas, {
      zoom: 4,
      streetViewControl: true,
    });
    google.maps.event.trigger(this.map, 'resize');
    this.geocoder = new google.maps.Geocoder();
    this.providerLocation = undefined;

    if (this.providerMarker) {
      this.providerMarker.setMap(null);
      this.providerMarker = undefined;
    }

    this.clearBeneficiaryArtifacts();
  }

  private async renderAsrLevelMap(provider: AsrMapProvider): Promise<void> {
    if (!this.map || !this.geocoder) {
      throw new Error('Google Maps is not initialized.');
    }

    const providerAddress = this.formatStreetAddress(provider.address);
    const providerResult = await this.geocodeAddress(providerAddress);

    if (!providerResult) {
      this.setError(
        'Unable to render map because Google does not recognize the provider address.',
      );
      return;
    }

    this.providerLocation = providerResult.geometry.location;
    this.map.setCenter(providerResult.geometry.location);
    this.providerMarker = this.createProviderMarker(provider.address, providerResult);
    await this.addBeneficiaryMarkers(provider.benes ?? []);
  }
private async renderModelLevelMap(beneficiaries: AsrAddress[]): Promise<void> {
    if (!this.map || !this.geocoder) {
      throw new Error('Google Maps is not initialized.');
    }

    const providerAddress = this.formatStreetAddress(this.getProviderAddress());
    const providerResult = await this.geocodeAddress(providerAddress);

    if (!providerResult) {
      this.setError(
        'Unable to render map because Google does not recognize the provider address.',
      );
      return;
    }

    this.providerLocation = providerResult.geometry.location;
    this.map.setCenter(providerResult.geometry.location);
    this.providerMarker = this.createProviderMarker(this.getProviderAddress(), providerResult);
    const convertedBenes: AsrMapBeneficiary[] = beneficiaries.map((bene: AsrAddress) => ({
          address: {address1: bene.address1, address2:bene.address2, firstName: bene.firstName, lastName:bene.lastName,city:bene.city, state:bene.state, zip:bene.zip }
      }));
    await this.addBeneficiaryMarkers(convertedBenes ?? []);
  }
  private async addBeneficiaryMarkers(beneficiaries: AsrMapBeneficiary[]): Promise<void> {
    if (!this.map || !this.providerLocation) {
      return;
    }

    for (const beneficiary of beneficiaries) {
      const beneficiaryAddress = this.formatStreetAddress(beneficiary.address);
      const geocodeResult = await this.geocodeAddress(beneficiaryAddress);

      if (!geocodeResult) {
        continue;
      }

      const marker = new google.maps.Marker ({
        position: geocodeResult.geometry.location,
        map: this.map,
        title: beneficiaryAddress,
      });

      const infoWindow = new google.maps.InfoWindow({
        content: this.buildBeneficiaryInfoContent(
          beneficiary.address,
          geocodeResult.geometry.location,
        ),
      });

      marker.addListener('click', () => {
        infoWindow.open(this.map as any, marker);
      });

      const polyline = new google.maps.Polyline({
        path: [this.providerLocation, geocodeResult.geometry.location],
        geodesic: true,
        strokeColor: '#000000',
        strokeOpacity: 1,
        strokeWeight: 2,
      });

      polyline.setMap(this.map);
      this.beneficiaryMarkers.push(marker);
      this.beneficiaryLines.push(polyline);
    }
  }

  private createProviderMarker(address: AsrAddress, result: GoogleGeometryResult): any {
    const marker = new google.maps.Marker ({
      position: result.geometry.location,
      map: this.map,
      title: this.formatStreetAddress(address),
      icon: 'https://mts.googleapis.com/vt/icon/name=icons/spotlight/spotlight-waypoint-a.png&text=P&psize=16&font=fonts/Roboto-Regular.ttf&color=ff333333&ax=44&ay=48&scale=1',
    });

    const infoWindow = new google.maps.InfoWindow({
      content: this.buildProviderInfoContent(address, result.geometry.location),
    });

    marker.addListener('click', () => {
      infoWindow.open(this.map as any, marker);
    });

    return marker;
  }

  private buildProviderInfoContent(address: AsrAddress, position: unknown): HTMLElement {
    const rows: Array<[string, string]> =
      address.lastName == null && address.firstName == null
        ? [
            ['Group Name', address.prvdrNm ?? 'N/A'],
            ['Last Name', 'N/A'],
            ['First Name', 'N/A'],
          ]
        : [
            ['Group Name', 'N/A'],
            ['Last Name', address.lastName ?? 'N/A'],
            ['First Name', address.firstName ?? 'N/A'],
          ];

    rows.push(['Provider NPI', address.npi ?? 'N/A']);
    rows.push(['Street Address', address.address1 ?? 'N/A']);
    rows.push(['City', address.city ?? 'N/A']);
    rows.push(['State', address.state ?? 'N/A']);
    rows.push(['Zip Code', address.zip ?? 'N/A']);
    let paramRows: [string, string][] = [];
    paramRows.push
    return this.buildInfoContent('Provider', rows, position);
  }

  private buildBeneficiaryInfoContent(address: AsrAddress, position: unknown): HTMLElement {
    return this.buildInfoContent(
      'Beneficiary',
      [
        ['First Name', address.firstName ?? 'N/A'],
        ['Last Name', address.lastName ?? 'N/A'],
        ['Bene ID', address.hicn ?? address.id ?? 'N/A'],
        ['Street Address', address.address1 ?? 'N/A'],
        ['City', address.city ?? 'N/A'],
        ['State', address.state ?? 'N/A'],
        ['Zip Code', address.zip ?? 'N/A'],
      ],
      position,
    );
  }

  private buildInfoContent(
    title: string,
    rows: Array<[string, string]>,
    position: unknown,
  ): HTMLElement {
    const wrapper = this.document.createElement('div');
    wrapper.className = 'map-info-window';

    const titleRow = this.document.createElement('p');
    const titleStrong = this.document.createElement('strong');
    titleStrong.textContent = title;
    titleRow.appendChild(titleStrong);
    wrapper.appendChild(titleRow);

    for (const [label, value] of rows) {
      const row = this.document.createElement('p');
      const labelStrong = this.document.createElement('strong');
      labelStrong.textContent = `${label}:`;
      row.appendChild(labelStrong);
      row.appendChild(this.document.createTextNode(` ${value}`));
      wrapper.appendChild(row);
    }

    const streetViewButton = this.document.createElement('button');
    streetViewButton.type = 'button';
    streetViewButton.className = 'map-link-button';
    streetViewButton.textContent = 'Street View';
    streetViewButton.addEventListener('click', () => this.toggleStreetView(position));
    wrapper.appendChild(streetViewButton);

    return wrapper;
  }

  private toggleStreetView(position: unknown): void {
    if (!this.map) {
      return;
    }

    const panorama = this.map.getStreetView();
    panorama.setPosition(position);
    panorama.setPov({ heading: 265, pitch: 0 });
    panorama.setVisible(!panorama.getVisible());
  }

  private clearBeneficiaryArtifacts(): void {
    for (const marker of this.beneficiaryMarkers) {
      marker.setMap(null);
    }

    for (const line of this.beneficiaryLines) {
      line.setMap(null);
    }

    this.beneficiaryMarkers = [];
    this.beneficiaryLines = [];
  }

  private async geocodeAddress(address: string): Promise<GoogleGeometryResult | null> {
    if (!this.geocoder || !address.trim()) {
      return null;
    }

    return new Promise<GoogleGeometryResult | null>((resolve) => {
      this.geocoder.geocode({ address }, (results: GoogleGeometryResult[], status: string) => {
        if (status === 'OK' && results.length) {
          resolve(results[0]);
          return;
        }

        resolve(null);
      });
    });
  }

  private formatStreetAddress(address: AsrAddress): string {
    return [address.address1, address.city, address.state, address.zip]
      .filter((value) => value != null && String(value).trim().length > 0)
      .join(', ');
  }

  private formatRestError(error: unknown): string {
    const message = (error as { error?: { message?: string }; message?: string })?.error?.message;

    if (message) {
      return `Unable to retrieve maps data due to ${message}`;
    }

    const fallback = (error as { message?: string })?.message;
    return `Unable to retrieve maps data due to ${fallback ?? 'an unexpected error.'}`;
  }

  private clearMessage(): void {
    this.message.set(null);
    this.messageType.set(null);
  }

  private setError(message: string): void {
    this.message.set(message);
    this.messageType.set('error');
  }

  private startCooldown(target: WritableSignal<boolean>): void {
    target.set(true);
    window.setTimeout(() => target.set(false), 5000);
  }

  private async waitForCanvas(): Promise<void> {
    for (let attempt = 0; attempt < 20; attempt += 1) {
      if (this.mapCanvas()?.nativeElement) {
        return;
      }

      await this.nextTick();
    }

    throw new Error('Google map canvas did not render.');
  }

  private nextTick(): Promise<void> {
    return new Promise((resolve) => window.setTimeout(resolve, 0));
  }
  


  private getAsrptId(): number | string | undefined{
    return this.dialogData?.asrptId;
  }
   private getModelId(): number | undefined {
    return this.dialogData?.modelId ;
  }

  public isModelMode(): boolean  {
    return this.dialogData?.modelMode || false ;
  } 
  public getProviderAddress(): any  {
    return this.dialogData?.providerAddr ;
  } 
}