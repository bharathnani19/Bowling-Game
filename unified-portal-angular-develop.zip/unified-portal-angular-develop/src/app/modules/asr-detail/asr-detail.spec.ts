import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Title } from '@angular/platform-browser';
import { AsrDetailComponent } from './asr-detail';

describe('AsrDetailComponent', () => {
  let component: AsrDetailComponent;
  let fixture: ComponentFixture<AsrDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AsrDetailComponent],
      providers: [Title]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AsrDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
