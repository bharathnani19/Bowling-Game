export const ALERTS_COLUMNS_MDCR = [
  {
    key: 'map',
    label: 'Map',
    sortable: false,
    custom: true,
    tooltip:
      'This column provides a hyperlink to a function that displays a graphical representation of the ASR and beneficiaries identified from the alerting or claims at-risk data.',
  },
  {
    key: 'models',
    label: 'Model',
    sortable: true,
    sortFn: (a: any, b: any) => (a.models.modelName ?? '').localeCompare(b.models.modelName ?? ''),
    custom: true,
    tooltip:
      'This column displays the name of the model that created the alert for the ASR ID. To view the model details, select the model name.',
  },
  {
    key: 'pathToEduInd',
    label: 'Path to Education',
    sortable: true,
    custom: true,
    tooltip:
      'This column displays “Yes” or “No” to indicate if the ASR has alerted in the past 180 days on a model flagged for having a known Path to Education.',
  },
  {
    key: 'showViz',
    label: 'Provider Network',
    sortable: true,
    custom: true,
    tooltip:
      'This column provides a hyperlink to a visualization tool that shows the network mapping of the ASR alerted provider, related providers, and related beneficiaries for the identified model.',
  },
  {
    key: 'modelStatus',
    label: 'Model Status',
    sortable: true,
    tooltip:
      'This column displays the model status associated with the indicated model for the ASR ID.',
  },
  {
    key: 'status',
    label: 'Alert Status',
    sortable: true,
    tooltip:
      'This column displays the alert status associated with the indicated model for the ASR ID. A "New" status indicates the model identified the ASR ID and created an alert during the most recent model run or in the last 30 days. An "Aged" status indicates the model identified the ASR ID did not alert in the most recent model run or last alerted between 31 and 180 days ago.',
  },
  {
    key: 'relCreatedDt',
    label: 'Latest Alert Created Date',
    sortable: true,
    custom: true,
    tooltip:
      'This column displays the timeframe since the ASR last alerted for any model. To review the actual alert date, hover over the timeframe displayed.',
  },
  {
    key: 'lookback',
    label: 'Look Back Period',
    sortable: true,
    tooltip:
      'This column displays the claim field and timeframe the model utilized to analyze claims.',
  },
  {
    key: 'riskScore',
    label: 'Risk Score',
    sortable: true,
    custom: true,
    tooltip:
      "This column displays the Risk Score associated with the model's alert. It is derived from the model's attributes using machine learning techniques.",
  },
  {
    key: 'cost',
    label: 'Cost',
    sortable: true,
    tooltip:
      'This column displays the total amount paid for all claims at risk associated with the ASR ID for the last year.',
  },
  {
    key: 'reportCard',
    label: 'Report Card',
    sortable: false,
    custom: true,
    tooltip:
      "This column provides a hyperlink to the alert's report card that provides details on each attribution for the identified model.",
  },
  {
    key: 'alerts',
    label: 'Alerts',
    sortable: true,
    custom: true,
    tooltip:
      'This column displays the number of alerts, or each time the ASR ID was identified during a model run. To view details associated with each alert, select the number hyperlink.',
  },
  {
    key: 'claimLines',
    label: 'Claim Lines',
    sortable: false,
    custom: true,
    tooltip:
      'This column provides a button to download the first 100K claims at risk lines associated with the identified model latest alert, in descending order.',
  },
  {
    key: 'derivedZone',
    label: 'Derived Jurisdiction',
    sortable: true,
    tooltip:
      'This column displays the derived UPIC jurisdiction based on the claims at risk tied to the alert.',
  },
];

export const ALERT_DLG_COLUMNS = [
  {
    key: 'status',
    label: 'Status',
    sortable: true,
    tooltip:
      'This column displays the alert status associated with the indicated model for the ASR ID. From the "Current" section, a "New" status indicates an alert created during the most recent model run or in the last 30 days. An "Aged" status indicates an alert created between 31 and 180 days ago. From the "History" section, an "Aged" status indicates an alert created over 181 days ago.',
  },
  {
    key: 'hasReportCard',
    label: 'Report Card',
    sortable: true,
    custom: true,
    tooltip:
      "This column provides a hyperlink to the alert's report card that provides details on each attribution for the identified model.",
  },
  {
    key: 'claimLines',
    label: 'Claim Lines',
    sortable: true,
    custom: true,
    tooltip:
      'This column provides a hyperlink to the first 100k claims at risk lines associated with the alert for the identified model. Claim lines related to an Alert with a create date over five years ago are greyed out.',
  },
  {
    key: 'createDt',
    label: 'Latest Alert Create Date',
    sortable: true,
    tooltip:
      'This column displays the timeframe since the ASR last alerted for any model. To review the actual alert date in YYYY/MM/DD format, hover over the timeframe displayed.',
  },
  {
    key: 'riskScore',
    label: 'Risk Score',
    sortable: true,
    custom: true,
    tooltip:
      "This column displays the Risk Score associated with the model's alert. It is derived from the model's attributes using machine learning techniques. For more details, please see the Enhanced Risk Score Explainability portion located in the Machine Learning 101 section of the support portal.",
  },
  {
    key: 'derivedZone',
    label: 'Derived Jurisdiction',
    sortable: true,
    tooltip: 'This column displays the UPIC assigned jurisdiction.',
  },
  {
    key: 'cost',
    label: 'Cost',
    sortable: true,
    tooltip:
      'This column displays the total amount paid for all claims at risk associated with the ASR ID for the last year.',
  },
];

export const PHASE1_ALERT_DLG_COLUMNS = [
  {
    key: 'status',
    label: 'Status',
    sortable: true,
    tooltip:
      "This column displays the alert status associated with the indicated model for the ASR ID. A  'New' status indicates the model identified the ASR ID and created an alert during the most recent model run or in the last 14 days. An  'Aged' status indicates the model that identified the ASR ID did not alert in the most recent model run or last alerted for the model identified between 15 and 30 days ago.",
  },
  {
    key: 'hasReportCard',
    label: 'Report Card',
    sortable: true,
    custom: true,
    tooltip:
      "This column provides a hyperlink to the Phase 1 alert's report card that provides details on each attribution for the identified model.",
  },
  {
    key: 'claimLines',
    label: 'Claim Lines',
    sortable: true,
    custom: true,
    tooltip:
      'This column provides a button to the first 100k claims at risk lines associated with the alert for the identified model. Claim lines related to an Alert with a create date over 30 days will not be available.',
  },
  {
    key: 'relCreatedDt',
    label: 'Alert Create Date',
    sortable: true,
    tooltip:
      'This column displays the timeframe since the ASR last alerted for a Phase 1 model. To review the actual alert date, hover over the timeframe displayed.',
  },
  {
    key: 'derivedZone',
    label: 'Phase 1 Derived Jurisdiction',
    sortable: true,
    tooltip:
      'This column displays the derived Phase 1 UPIC jurisdiction based on the Phase 1 claims at risk tied to the alert.',
  },
  {
    key: 'cost',
    label: 'Phase 1 Cost',
    sortable: true,
    tooltip:
      "This column displays the provider's total submitted claims amount for the claims-at-risk for the specified Phase 1 alert.",
  },
];

export const PHASE1_ALERTS_COLUMNS = [
  {
    key: 'models',
    label: 'Model',
    sortable: true,
    sortFn: (a: any, b: any) => (a.models.modelName ?? '').localeCompare(b.models.modelName ?? ''),
    custom: true,
    tooltip:
      'This column displays the name of the model that created the alert for the ASR ID. To view the model details, select the model name.',
  },
  {
    key: 'modelStatus',
    label: 'Model Status',
    sortable: true,
    tooltip:
      'This column displays the model status associated with the indicated model for the ASR ID.',
  },
  {
    key: 'status',
    label: 'Alert Status',
    sortable: true,
    tooltip:
      'This column displays the alert status associated with the indicated model for the ASR ID. A "New" status indicates the model identified the ASR ID and created an alert during the most recent model run or in the last 14 days. An "Aged" status indicates the model that identified the ASR ID did not alert in the most recent model run or last alerted between 15 and 30 days ago.',
  },
  {
    key: 'relCreatedDt',
    label: 'Latest Alert Created Date',
    sortable: true,
    custom: true,
    tooltip:
      'This column displays the timeframe since the ASR last alerted for a Phase 1 model. To review the actual alert date, hover over the timeframe displayed.',
  },
  {
    key: 'lookback',
    label: 'Look Back Period',
    sortable: true,
    tooltip:
      'This column displays the claim field and timeframe the model utilized to analyze claims.',
  },
  {
    key: 'phase1RiskScore',
    label: 'Phase 1 Risk Score',
    sortable: true,
    custom: true,
    tooltip: '',
  },
  {
    key: 'cost',
    label: 'Phase 1 Cost',
    sortable: true,
    tooltip:
      "This column displays the provider's total submitted claims amount for the claims-at-risk for the specified Phase 1 alert.",
  },
  {
    key: 'reportCard',
    label: 'Report Card',
    sortable: false,
    custom: true,
    tooltip:
      "This column provides a hyperlink to the Phase 1 alert's report card that provides details on each attribution for the identified model.",
  },
  {
    key: 'alerts',
    label: 'Phase 1 Alerts',
    sortable: true,
    custom: true,
    tooltip:
      'This column displays the number of alerts, or each time the ASR ID was identified during a model run. To view details associated with each alert, select the number hyperlink.',
  },
  {
    key: 'claimLines',
    label: 'Claim Lines',
    sortable: false,
    custom: true,
    tooltip:
      'This column provides a button to the first 100k claims at risk lines associated with the alert for the identified model. Claim lines related to an Alert with a create date over 30 days will not be available.',
  },
  {
    key: 'derivedZone',
    label: 'Phase 1 Derived Jurisdiction',
    sortable: true,
    tooltip:
      'This column displays the derived Phase 1 UPIC jurisdiction based on the Phase 1 claims at risk tied to the alert.',
  },
];
export const EDIT_INFO_COLUMNS = [
  {
    key: 'fpsEditNum',
    label: 'Edit Number',
    sortable: true,
  },
  {
    key: 'fpsEditName',
    label: 'Edit Name',
    sortable: true,
  },
  {
    key: 'echimpNum',
    label: 'eChimp Number',
    sortable: true,
  },
  {
    key: 'editDesc',
    label: 'Description',
    sortable: true,
    custom: true,
  },
  {
    key: 'editActnType',
    label: 'Type of Edit Action',
    sortable: true,
  },
  {
    key: 'lineOfBusns',
    label: 'Line of Business',
    sortable: true,
  },
  {
    key: 'hstry',
    label: 'History',
    sortable: true,
  },
  {
    key: 'hstryLkbckPrd',
    label: 'History Look-back Period',
    sortable: true,
  },
];
export const EDITS_CLAIMS_COLUMNS = [
  { key: 'enhncmtId', label: 'Enhancement ID', toolTip: 'Enhancement ID', sortable: true },
  { key: 'enhncmtTime', label: 'Enhancement Time', toolTip: 'Enhancement Time', sortable: true },
  { key: 'clmId', label: 'Claim ID', toolTip: 'Claim ID', sortable: true },
  { key: 'srvcLineNum', label: 'Service Line Num', toolTip: 'Service Line Num', sortable: true },
  { key: 'cntrctNum', label: 'Contract', toolTip: 'Contract', sortable: true },
  { key: 'filName', label: 'File Name', toolTip: 'File Name', sortable: true },
  { key: 'clmTypeCd', label: 'Claim Type', toolTip: 'Claim Type', sortable: true },
  { key: 'prvdrNpiNum', label: 'Provider NPI', toolTip: 'Provider NPI', sortable: true },
  { key: 'prvdrPtanNum', label: 'Provider PTAN', toolTip: 'Provider PTAN', sortable: true },
  { key: 'prvdrTinNum', label: 'Provider TIN', toolTip: 'Provider TIN', sortable: true },
  { key: 'prvdrSpclty1Cd', label: 'Prov Spec CD', toolTip: 'Prov Spec CD', sortable: true },
  { key: 'prvdrReimbrsmtAmt', label: 'Prov Reimb Amt', toolTip: 'Prov Reimb Amt', sortable: true },
  { key: 'prvdrZipCd', label: 'Provider Zip', toolTip: 'Provider Zip', sortable: true },
  { key: 'atndgNpiNum', label: 'Attend NPI', toolTip: 'Attend NPI', sortable: true },
  { key: 'atndgNpiPtanNum', label: 'Attend PTAN', toolTip: 'Attend PTAN', sortable: true },
  { key: 'atndgNpiTinNum', label: 'Attend TIN', toolTip: 'Attend TIN', sortable: true },
  {
    key: 'ordrgPrvdrPecosStusTxt',
    label: 'Ord Prv PECOS Status',
    toolTip: 'Ord Prv PECOS Status',
    sortable: true,
  },
  { key: 'sbmtrId', label: 'Submitter ID', toolTip: 'Submitter ID', sortable: true },
  {
    key: 'sbmtrEntId',
    label: 'Submitter Entity ID',
    toolTip: 'Submitter Entity ID',
    sortable: true,
  },
  { key: 'blgNpiNum', label: 'Bill NPI', toolTip: 'Bill NPI', sortable: true },
  { key: 'blgNpiPtanNum', label: 'Bill PTAN', toolTip: 'Bill PTAN', sortable: true },
  { key: 'prvdrName', label: 'Provider Name', toolTip: 'Provider Name', sortable: true },
  {
    key: 'prvdrSpcltyCd',
    label: 'Provider Specialty',
    toolTip: 'Provider Specialty',
    sortable: true,
  },
  {
    key: 'prvdrTxnmyName',
    label: 'Provider Taxonomy',
    toolTip: 'Provider Taxonomy',
    sortable: true,
  },
  {
    key: 'prvdrLine1Adr',
    label: 'Provider Address 1',
    toolTip: 'Provider Address 1',
    sortable: true,
  },
  { key: 'prvdrCityName', label: 'Provider City', toolTip: 'Provider City', sortable: true },
  { key: 'prvdrStateName', label: 'Provider State', toolTip: 'Provider State', sortable: true },
  {
    key: 'prvdrRfrncZipCd',
    label: 'Provider Zip from Ref',
    toolTip: 'Provider Zip from Ref',
    sortable: true,
  },
  { key: 'prvdrLatTxt', label: 'Provider Lat', toolTip: 'Provider Lat', sortable: true },
  { key: 'prvdrLonTxt', label: 'Provider Long', toolTip: 'Provider Long', sortable: true },
  { key: 'rfrgPrvdrName', label: 'Refer Name', toolTip: 'Refer Name', sortable: true },
  { key: 'rfrgPrvdrNpiNum', label: 'Refer NPI', toolTip: 'Refer NPI', sortable: true },
  { key: 'rfrgPrvdrPtanNum', label: 'Refer PTAN', toolTip: 'Refer PTAN', sortable: true },
  {
    key: 'rfrgPrvdrSpcltyCd',
    label: 'Refer Specialty',
    toolTip: 'Refer Specialty',
    sortable: true,
  },
  {
    key: 'rfrgPrvdrLine1Adr',
    label: 'Refer Address 1',
    toolTip: 'Refer Address 1',
    sortable: true,
  },
  { key: 'rfrgPrvdrCityName', label: 'Refer City', toolTip: 'Refer City', sortable: true },
  { key: 'rfrgPrvdrStateCd', label: 'Refer State', toolTip: 'Refer State', sortable: true },
  { key: 'rfrgPrvdrZipCd', label: 'Refer Zip', toolTip: 'Refer Zip', sortable: true },
  { key: 'rfrgPrvdrLatTxt', label: 'Refer Lat', toolTip: 'Refer Lat', sortable: true },
  { key: 'rfrgPrvdrLonTxt', label: 'Refer Long', toolTip: 'Refer Long', sortable: true },
  { key: 'beneHicnNum', label: 'Bene HICN', toolTip: 'Bene HICN', sortable: true },
  { key: 'bene1stName', label: 'Bene First Name', toolTip: 'Bene First Name', sortable: true },
  { key: 'beneLastName', label: 'Bene Last Name', toolTip: 'Bene Last Name', sortable: true },
  { key: 'beneBirthDt', label: 'Bene DOB', toolTip: 'Bene DOB', sortable: true },
  { key: 'beneDeathDt', label: 'Bene DOD', toolTip: 'Bene DOD', sortable: true },
  {
    key: 'beneAgeSrvcName',
    label: 'Bene Age Service',
    toolTip: 'Bene Age Service',
    sortable: true,
  },
  { key: 'beneLine1Adr', label: 'Bene Address 1', toolTip: 'Bene Address 1', sortable: true },
  { key: 'beneLine2Adr', label: 'Bene Address 2', toolTip: 'Bene Address 2', sortable: true },
  { key: 'beneCityName', label: 'Bene City', toolTip: 'Bene City', sortable: true },
  { key: 'beneStateCd', label: 'Bene State', toolTip: 'Bene State', sortable: true },
  { key: 'beneZipCd', label: 'Bene Zip', toolTip: 'Bene Zip', sortable: true },
  { key: 'beneLatTxt', label: 'Bene Lat', toolTip: 'Bene Lat', sortable: true },
  { key: 'beneLonTxt', label: 'Bene Long', toolTip: 'Bene Long', sortable: true },
  { key: 'beneReprsntedInd', label: 'Bene Rep Ind', toolTip: 'Bene Rep Ind', sortable: true },
  {
    key: 'srvcFacZipCd',
    label: 'Service Facility Zip',
    toolTip: 'Service Facility Zip',
    sortable: true,
  },
  { key: 'srvcChrgAmt', label: 'Service Charge', toolTip: 'Service Charge', sortable: true },
  { key: 'reimbrsmtAmt', label: 'Reimb Amt', toolTip: 'Reimb Amt', sortable: true },
  { key: 'mdcrPymtAmt', label: 'Medicare Pay Amt', toolTip: 'Medicare Pay Amt', sortable: true },
  { key: 'alowdChrgAmt', label: 'Allow Chg Amt', toolTip: 'Allow Chg Amt', sortable: true },
  { key: 'stmtFromDt', label: 'Statement From Dt', toolTip: 'Statement From Dt', sortable: true },
  { key: 'stmtThruDt', label: 'Statement Thru Dt', toolTip: 'Statement Thru Dt', sortable: true },
  { key: 'blgTypeName', label: 'Bill Type', toolTip: 'Bill Type', sortable: true },
  { key: 'revCd', label: 'Revenue CD', toolTip: 'Revenue CD', sortable: true },
  { key: 'srvcFromDt', label: 'Service From Dt', toolTip: 'Service From Dt', sortable: true },
  { key: 'srvcLineThruDt', label: 'Service Thru Dt', toolTip: 'Service Thru Dt', sortable: true },
  { key: 'plcOdSrvcCd', label: 'Place Serv CD', toolTip: 'Place Serv CD', sortable: true },
  { key: 'posZipCd', label: 'Place Serv Zip', toolTip: 'Place Serv Zip', sortable: true },
  { key: 'unitName', label: 'Units', toolTip: 'Units', sortable: true },
  {
    key: 'srvcLineQlfyrNum',
    label: 'Service Line Qual',
    toolTip: 'Service Line Qual',
    sortable: true,
  },
  { key: 'prcdrCd', label: 'Proc CD', toolTip: 'Proc CD', sortable: true },
  { key: 'prcdr1MdfrTxt', label: 'Proc Modifier 1', toolTip: 'Proc Modifier 1', sortable: true },
  { key: 'prcdr2MdfrTxt', label: 'Proc Modifier 2', toolTip: 'Proc Modifier 2', sortable: true },
  { key: 'prcdr3MdfrTxt', label: 'Proc Modifier 3', toolTip: 'Proc Modifier 3', sortable: true },
  { key: 'prcdr4MdfrTxt', label: 'Proc Modifier 4', toolTip: 'Proc Modifier 4', sortable: true },
  { key: 'prcdr5MdfrTxt', label: 'Proc Modifier 5', toolTip: 'Proc Modifier 5', sortable: true },
  { key: 'prcdrTime', label: 'Proc Time', toolTip: 'Proc Time', sortable: true },
  { key: 'dgns1Cd', label: 'Diag CD 1', toolTip: 'Diag CD 1', sortable: true },
  { key: 'dgns2Cd', label: 'Diag CD 2', toolTip: 'Diag CD 2', sortable: true },
  { key: 'dgns3Cd', label: 'Diag CD 3', toolTip: 'Diag CD 3', sortable: true },
  { key: 'dgns4Cd', label: 'Diag CD 4', toolTip: 'Diag CD 4', sortable: true },
  { key: 'dgns5Cd', label: 'Diag CD 5', toolTip: 'Diag CD 5', sortable: true },
  { key: 'dgns6Cd', label: 'Diag CD 6', toolTip: 'Diag CD 6', sortable: true },
  { key: 'dgns7Cd', label: 'Diag CD 7', toolTip: 'Diag CD 7', sortable: true },
  { key: 'dgns8Cd', label: 'Diag CD 8', toolTip: 'Diag CD 8', sortable: true },
  { key: 'zpicCd', label: 'ZPIC', toolTip: 'ZPIC', sortable: true },
  {
    key: 'clmBeneLine1Adr',
    label: 'Claim Bene Addr 1',
    toolTip: 'Claim Bene Addr 1',
    sortable: true,
  },
  {
    key: 'clmBeneLine2Adr',
    label: 'Claim Bene Addr 2',
    toolTip: 'Claim Bene Addr 2',
    sortable: true,
  },
  { key: 'clmBeneCityName', label: 'Claim Bene City', toolTip: 'Claim Bene City', sortable: true },
  { key: 'clmBeneStateCd', label: 'Claim Bene State', toolTip: 'Claim Bene State', sortable: true },
  { key: 'clmBeneZipCd', label: 'Claim Bene Zip', toolTip: 'Claim Bene Zip', sortable: true },
  { key: 'clmBeneLatTxt', label: 'Claim Bene Lat', toolTip: 'Claim Bene Lat', sortable: true },
  { key: 'clmBeneLonTxt', label: 'Claim Bene Long', toolTip: 'Claim Bene Long', sortable: true },
  { key: 'acrtnDt', label: 'Accretion Date', toolTip: 'Accretion Date', sortable: true },
  { key: 'condCd', label: 'Condition Codes', toolTip: 'Condition Codes', sortable: true },
  { key: 'clmRcptDt', label: 'Claim Recpt Dt', toolTip: 'Claim Recpt Dt', sortable: true },
  { key: 'transId', label: 'Tran ID', toolTip: 'Tran ID', sortable: true },
  { key: 'admsnDt', label: 'Admission Dt', toolTip: 'Admission Dt', sortable: true },
  { key: 'dschrgDt', label: 'Discharge Dt', toolTip: 'Discharge Dt', sortable: true },
  { key: 'srvcTypeCd', label: 'Type of Service', toolTip: 'Type of Service', sortable: true },
  { key: 'cllSubAmt', label: 'Claim Ln Sub Amt', toolTip: 'Claim Ln Sub Amt', sortable: true },
  { key: 'hippsCd', label: 'Apc Hipps CD', toolTip: 'Apc Hipps CD', sortable: true },
  { key: 'ptntStusTxt', label: 'Pat Status', toolTip: 'Pat Status', sortable: true },
  { key: 'hospPrdNum', label: 'Hosp Period', toolTip: 'Hosp Period', sortable: true },
  { key: 'hospUsedDayNum', label: 'Hosp Used Days', toolTip: 'Hosp Used Days', sortable: true },
  { key: 'prmryDgnsCd', label: 'Prim Diag CD', toolTip: 'Prim Diag CD', sortable: true },
  { key: 'actnCd', label: 'Action Code', toolTip: 'Action Code', sortable: true },
  { key: 'entTypeCd', label: 'Entity Type Code', toolTip: 'Entity Type Code', sortable: true },
  { key: 'dualStusInd', label: 'Dual Status Ind', toolTip: 'Dual Status Ind', sortable: true },
  {
    key: 'scndryPyrId',
    label: 'Secondary Payer IDS',
    toolTip: 'Secondary Payer IDS',
    sortable: true,
  },
  { key: 'crossOvrInd', label: 'Xover Ind', toolTip: 'Xover Ind', sortable: true },
  { key: 'crossOvrDstntnId', label: 'Xover Dest ID', toolTip: 'Xover Dest ID', sortable: true },
  {
    key: 'crossOvrDstntnTransId',
    label: 'Xover Dest Trans',
    toolTip: 'Xover Dest Trans',
    sortable: true,
  },
  { key: 'srgryCd', label: 'Surg CD', toolTip: 'Surg CD', sortable: true },
  { key: 'initlEnrlmtDt', label: 'Initl Enrlmt Dt', toolTip: 'Initl Enrlmt Dt', sortable: true },
];
export const EDITS_COLUMNS = [
  {
    key: 'lastDetectedDenialDt',
    label: 'Last Detection Denial/Rejection Date',
    sortable: true,
    tooltip:
      'This column displays the date the Edit last had activity for claims submitted by the subject NPI.',
  },
  {
    key: 'alertName',
    label: 'Edit Name',
    sortable: true,
    custom: true,
    linkTemplate: 'editInfoLink',
    tooltip:
      'This column displays the short name of the FPS edit that alerted for the ASR ID. To view the edit details, select the edit name.',
  },
  {
    key: 'firstDetectedDenialDt',
    label: 'First Detection Denial/Rejection Date',
    sortable: true,
    tooltip: 'This column displays the date the Edit first denied/rejected a claim.',
  },
  {
    key: 'numClaimsDenied',
    label: '# Of Claims Denied/Rejected',
    sortable: true,
    custom: true,
    linkTemplate: 'editClaimsLink',
    tooltip:
      'This column displays the number of header claims denied/rejected for the associated Edit and ASR ID.',
  },
  {
    key: 'totalDeniedPaymentsClaimsAmt',
    label: 'Total Denied/Rejected Claims Payment',
    sortable: true,
    tooltip: 'This column displays the total billed amount for the denied/rejected header claims.',
  },
  {
    key: 'numLineItemsDenied',
    label: '# Of Line Items Denied/Rejected',
    sortable: true,

    tooltip:
      'This column displays the number of claim lines denied/rejected for the associated Edit and ASR ID.',
  },
  {
    key: 'totalDeniedPaymentsLinesAmt',
    label: 'Total Denied/Rejected Lines Payments',
    sortable: true,
    tooltip: 'This column displays the total billed amount for the denied/rejected claim lines.',
  },
  {
    key: 'numProcCodes',
    label: '# Of Procedure Codes',
    sortable: true,
    tooltip:
      'This column displays the number of unique procedure codes billed for the denied/rejected claim lines.',
  },
];

export const LEADS_INVESTIGATIONS_COLUMNS = [
  {
    key: 'id',
    label: 'ID',
    sortable: true,
    tooltip:
      'This column displays the UCM lead or investigation number associated with the ASR ID. To view additional lead or investigation details, select the ID hyperlink.',
    custom: true,
  },
  {
    key: 'category',
    label: 'Category',
    sortable: true,
    tooltip: 'This column displays if the ID number is either a lead or an investigation.',
  },
  {
    key: 'status',
    label: 'Status',
    sortable: true,
    tooltip: 'This column displays if the lead or investigation is open or closed.',
  },
  {
    key: 'assignedTo',
    label: 'Assigned To',
    sortable: true,
    tooltip: 'This column displays the name of the end-user assigned to the lead or investigation.',
  },
  {
    key: 'createdDt',
    label: 'Create Date',
    sortable: true,
    tooltip: 'This column displays the date and time of the lead or investigation creation.',
  },
  {
    key: 'modDt',
    label: 'Mod Date',
    sortable: true,
    tooltip: 'This column displays the date and time that the lead or investigation was modified.',
  },
  {
    key: 'activities',
    label: 'Activities',
    sortable: true,
    tooltip:
      'This column displays the total number of activities logged for the lead or investigation.',
  },
  {
    key: 'actions',
    label: 'Actions',
    sortable: true,
    tooltip:
      'This column displays the total number of actions logged for the lead or investigation.',
  },
  {
    key: 'ruling',
    label: 'Ruling',
    sortable: true,
    tooltip: 'This column displays the current FPS ruling for the lead or investigation.',
  },
  {
    key: 'subRuling',
    label: 'Ruling Reasons',
    sortable: true,
    tooltip: 'This column displays the FPS sub-ruling for the lead or investigation.',
  },
];

export const ASR_RISK_EXPLAINABILITY_COLUMNS = [
  {
    key: 'modelNm',
    label: 'Model Name',
    sortable: true,
    tooltip: 'This column displays the name of the model associated with the ASR.',
  },
  {
    key: 'modelRiskScore',
    label: 'Alert Risk Score',
    sortable: true,
    custom: true,
    linkTemplate: 'reportCardLink',
    tooltip:
      'This column displays the risk score associated with the alert generated by the model.',
  },
  {
    key: 'contribScorePct',
    label: 'Contribution factor to ASR Risk Score',
    sortable: true,
    tooltip:
      'This column displays the contribution percentage of the model toward the overall ASR Risk Score.',
  },
];

export const PRIORITY_SCORE_COLUMNS = [
  {
    key: 'criteriaNm',
    label: 'Criteria',
    sortable: true,
    custom: true,
    linkTemplate: 'openReportLink',
  },
  {
    key: 'criteriaDesc',
    label: 'Description',
    sortable: true,
  },
  {
    key: 'criteriaVal',
    label: 'ASR Value',
    sortable: true,
  },
];

export const TPE_COLUMNS = [
  {
    key: 'ptan',
    label: 'PTAN',
    sortable: true,
    tooltip: 'This column displays the PTAN associated with the TPE data.',
  },
  {
    key: 'macRvwRsnDesc',
    label: 'Review Reason',
    sortable: true,
    tooltip: 'This column displays the reason why the MAC is conducting review of this provider.',
  },
  {
    key: 'cartRvwTopicDesc',
    label: 'Review Topic',
    sortable: true,
    tooltip: 'This column displays the appropriate CART topic code description.',
  },
  {
    key: 'tpeRnd',
    label: 'Review Round',
    sortable: true,
    tooltip: 'This column displays the probe cycle.',
  },
  {
    key: 'intraProbeEdctnOfrd',
    label: 'TPE Offered',
    sortable: true,
    tooltip: 'This column indicates if Intra-Probe Education was offered.',
  },
  {
    key: 'intraProbeEdctnAcptd',
    label: 'TPE Accepted',
    sortable: true,
    tooltip: 'This column indicates if Intra-Probe Education was accepted.',
  },

  {
    key: 'intraProbeEdctn1Dt',
    label: '1st Education Date',
    sortable: true,
    tooltip:
      'This column displays the 1st date that the Intra-Probe Education was provided in YYYY/MM/DD format.',
  },
  {
    key: 'intraProbeEdctn1Desc',
    label: '1st Education Type',
    sortable: true,
    tooltip:
      'This column displays the method description used to provide the 1st Intra-Probe Education.',
  },

  {
    key: 'intraProbeEdctn2Dt',
    label: '2nd Education Date',
    sortable: true,
    tooltip:
      'This column displays the 2nd date that the Intra-Probe Education was provided in YYYY/MM/DD format.',
  },
  {
    key: 'intraProbeEdctn2Desc',
    label: '2nd Education Type',
    sortable: true,
    tooltip:
      'This column displays the method description used to provide the 2nd Intra-Probe Education.',
  },

  {
    key: 'intraProbeEdctn3Dt',
    label: '3rd Education Date',
    sortable: true,
    tooltip:
      'This column displays the 3rd date that the Intra-Probe Education was provided in YYYY/MM/DD format.',
  },
  {
    key: 'intraProbeEdctn3Desc',
    label: '3rd Education Type',
    sortable: true,
    tooltip:
      'This column displays the method description used to provide the 3rd Intra-Probe Education.',
  },

  {
    key: 'intraProbeEdctn4Dt',
    label: '4th Education Date',
    sortable: true,
    tooltip:
      'This column displays the 4th date that the Intra-Probe Education was provided in YYYY/MM/DD format.',
  },
  {
    key: 'intraProbeEdctn4Desc',
    label: '4th Education Type',
    sortable: true,
    tooltip:
      'This column displays the method description used to provide the 4th Intra-Probe Education.',
  },

  {
    key: 'intraProbeEdctn5Dt',
    label: '5th Education Date',
    sortable: true,
    tooltip:
      'This column displays the 5th date that the Intra-Probe Education was provided in YYYY/MM/DD format.',
  },
  {
    key: 'intraProbeEdctn5Desc',
    label: '5th Education Type',
    sortable: true,
    tooltip:
      'This column displays the method description used to provide the 5th Intra-Probe Education.',
  },

  {
    key: 'postProbeEdctnOfrd',
    label: 'Post Education Offered',
    sortable: true,
    tooltip: 'This column indicates if Post Probe Education was offered.',
  },
  {
    key: 'postProbeEdctnActpd',
    label: 'Post Education Accepted',
    sortable: true,
    tooltip: 'This column indicates if Post Probe Education was accepted.',
  },
  {
    key: 'postProbeEdctnDt',
    label: 'Post Education Date',
    sortable: true,
    tooltip:
      'This column displays the date that the Post Probe Education was provided in YYYY/MM/DD format.',
  },
  {
    key: 'postProbeEdctnDesc',
    label: 'Post Education Type',
    sortable: true,
    tooltip:
      'This column displays the method description used to provide the Post Probe Education.',
  },

  {
    key: 'edctnDnlRsn1Desc',
    label: 'Most Common Denial Reason',
    sortable: true,
    tooltip:
      "This column displays the most common denial reason code description for the provider's denied claims.",
  },
  {
    key: 'edctnDnlRsn2Desc',
    label: '2nd Most Common Denial Reason',
    sortable: true,
    tooltip:
      "This column displays the 2nd most common denial reason code description for the provider's denied claims.",
  },
  {
    key: 'edctnDnlRsn3Desc',
    label: '3rd Most Common Denial Reason',
    sortable: true,
    tooltip:
      "This column displays the 3rd most common denial reason code description for the provider's denied claims.",
  },

  {
    key: 'edctnDnlRateIncrInd',
    label: 'Previous Education Successful',
    sortable: true,
    tooltip:
      'This column indicates if the previous education was successful and displays N/A if the TPE review round is 1.',
  },

  {
    key: 'rfrlToDesc',
    label: 'Referral Destination',
    sortable: true,
    tooltip: 'This column displays the TPE data referral destination description.',
  },
  {
    key: 'rfrlRsnDesc',
    label: 'Referral Reason',
    sortable: true,
    tooltip: 'This column displays the TPE data referral reason description.',
  },

  {
    key: 'cmtTxt',
    label: 'Comments',
    sortable: true,
    tooltip: 'This column displays TPE data comments.',
  },
  {
    key: 'ctrctrId',
    label: 'MAC Contractor ID',
    sortable: true,
    tooltip: 'This column displays the TPE data contractor identification.',
  },
];

export const DUAL_ELIGIBLE_BENEFICIARIES_COLUMNS = [
  {
    key: 'key',
    label: 'Description',
    sortable: false,
  },
  {
    key: 'value',
    label: 'Value',
    sortable: false,
  },
];

export const TOP_HCPCS_ICD_COLUMNS = [
  {
    key: 'key',
    label: 'Rank',
    sortable: false,
  },
  {
    key: 'value',
    label: 'Code',
    sortable: false,
  },
  {
    key: 'desc',
    label: 'Description',
    sortable: false,
  },
  {
    key: 'amt',
    label: 'Payment',
    sortable: false,
  },
];

export const ASR_HISTORY_COLUMNS = [
  {
    key: 'userName',
    label: 'User Name',
    sortable: true,
    tooltip:
      "This column displays the end user's ID or the system name that generated the identified transaction.",
  },
  {
    key: 'eventDt',
    label: 'Event Date',
    sortable: true,
    tooltip: 'This column displays the date and time the identified transaction occurred.',
  },
  {
    key: 'riskScore',
    label: 'Risk Score',
    sortable: true,
    formatPipe: 'riskScore',
    tooltip:
      'This column displays the risk score associated with the ASR ID. It is derived utilizing the methodology displayed in the ASR Risk Score Methodology column. For more details, please see the Enhanced Risk Score Explainability section located in the Machine Learning 101 section of the Support Portal and in the Provider Info section and in the model report card on the ASR Details page. To access the Risk Score Trending Report, navigate to the Risk Score Trending tab.',
  },
  {
    key: 'description',
    label: 'Description',
    sortable: true,
    tooltip: 'This column displays a description of the transaction that occurred.',
  },
  {
    key: 'comments',
    label: 'Comments',
    sortable: true,
    tooltip:
      'This column displays comments entered by the end-user or a standard system message generated by the system for the identified transaction.',
  },
];

export const NOTES_COLUMNS = [
  {
    key: 'leaderInvId',
    label: 'Lead/Investigation ID',
    sortable: true,
    tooltip:
      'This column displays the FPS2 legacy lead or investigation number associated with the ASR ID.',
  },
  {
    key: 'userId',
    label: 'User',
    sortable: true,
    tooltip: "This column displays the end user's FPS ID that generated the note.",
  },
  {
    key: 'eventDt',
    label: 'Date',
    sortable: true,
    tooltip: 'This column displays the date and time that FPS recorded the note.',
  },
  {
    key: 'note',
    label: 'Note',
    sortable: true,
    tooltip: 'This column displays the note or comment entered by the specific end-user ID.',
  },
];

export const ALERTS_HISTORY_COLUMNS = [
  {
    key: 'models',
    label: 'Model',
    sortable: true,
    custom: true,
    sortFn: (a: any, b: any) => (a.models.modelName ?? '').localeCompare(b.models.modelName ?? ''),
    tooltip: 'This column displays the name of the model that created the alert for the ASR ID.',
  },
  {
    key: 'modelStatus',
    label: 'Model Status',
    sortable: true,
    tooltip:
      'This column displays the model status associated with the indicated model for the ASR ID.',
  },
  {
    key: 'status',
    label: 'Alert Status',
    sortable: true,
    tooltip:
      'This column displays the alert status associated with the indicated model for the ASR ID. An "Aged" status indicates the model identified the ASR ID did not alert in the most recent model run or last alerted for the identified model between 31 and 180 days ago.',
  },
  {
    key: 'relCreatedDt',
    label: 'Latest Alert Created Date',
    custom: true,
    sortable: true,
    tooltip:
      'This column displays the timeframe since the ASR last alerted for any model. To review the actual alert date, hover over the timeframe displayed.',
  },
  {
    key: 'lookback',
    label: 'Look Back Period',
    sortable: true,
    tooltip:
      'This column displays the claim field and timeframe the model utilized to analyze claims.',
  },
  {
    key: 'alerts',
    label: 'Alerts',
    sortable: true,
    custom: true,
    tooltip:
      'This column displays the number of alerts, or each time the ASR ID was identified during a model run. To view details associated with each alert, select the number hyperlink.',
  },
  {
    key: 'derivedZone',
    label: 'Derived Jurisdiction',
    sortable: true,
    tooltip:
      'This column displays the derived UPIC jurisdiction based on the claims at risk tied to the alert.',
  },
];

export const PHASE1_ALERTS_HISTORY_COLUMNS = [
  {
    key: 'models',
    label: 'Model',
    sortable: true,
    custom: true,
    sortFn: (a: any, b: any) => (a.models.modelName ?? '').localeCompare(b.models.modelName ?? ''),
    tooltip:
      'This column displays the name of the Phase 1 model that created the alert for the ASR ID.',
  },
  {
    key: 'modelStatus',
    label: 'Model Status',
    sortable: true,
    tooltip:
      'This column displays the model status associated with the indicated Phase 1 model for the ASR ID.',
  },
  {
    key: 'status',
    label: 'Alert Status',
    sortable: true,
    tooltip:
      "This column displays the alert status associated with the indicated Phase 1 model for the ASR ID. An 'Aged' status indicates the model that identified the ASR ID did not alert in the most recent model run or last alerted for the identified model 15 or more days ago.",
  },
  {
    key: 'relCreatedDt',
    label: 'Latest Alert Created Date',
    sortable: true,
    custom: true,
    tooltip:
      'This column displays the time since the ASR last alerted for the indicated Phase 1 model.',
  },
  {
    key: 'lookback',
    label: 'Look Back Period',
    sortable: true,
    tooltip:
      'This column displays the claim field and timeframe the Phase 1 model utilized to analyze claims.',
  },
  {
    key: 'alerts',
    label: 'Phase 1 Alerts',
    sortable: true,
    custom: true,
    tooltip:
      'This column displays the number of alerts, or each time the ASR ID was identified during a model run. To view details associated with each alert, select the number hyperlink.',
  },
  {
    key: 'derivedZone',
    label: 'Phase 1 Derived Jurisdiction',
    sortable: true,
    tooltip:
      'This column displays the derived Phase 1 UPIC jurisdiction based on the Phase 1 claims at risk tied to the alert.',
  },
];

export const LEADS_HISTORY_COLUMNS = [
  {
    key: 'id',
    label: 'ID',
    sortable: true,
    custom: true,
    tooltip:
      'This column displays the FPS2 Legacy Lead or Investigation number associated with the ASR ID. To view additional lead or investigation details, select the ID hyperlink.',
  },
  {
    key: 'category',
    label: 'Category',
    sortable: true,
    tooltip: 'This column displays if the ID number is either a lead or an investigation.',
  },
  {
    key: 'status',
    label: 'Status',
    sortable: true,
    tooltip:
      'This column displays if the FPS2 Legacy Lead or Investigation is closed or moved to UCM.',
  },
  {
    key: 'assignedTo',
    label: 'Assigned To',
    sortable: true,
    tooltip:
      'This column displays the name of the end-user assigned to the FPS2 Legacy Lead or Investigation.',
  },
  {
    key: 'createdDt',
    label: 'Create Date',
    sortable: true,
    tooltip:
      'This column displays the date and time of the FPS2 Legacy Lead or Investigation creation.',
  },
  {
    key: 'modDt',
    label: 'Mod Date',
    sortable: true,
    tooltip:
      'This column displays the date and time that the FPS2 Legacy Lead or Investigation was last modified.',
  },
  {
    key: 'activities',
    label: 'Activities',
    sortable: true,
    tooltip:
      'This column displays the total number of activities logged for the FPS2 Legacy Lead or Investigation.',
  },
  {
    key: 'actions',
    label: 'Actions',
    sortable: true,
    tooltip:
      'This column displays the total number of actions logged for the FPS2 Legacy Lead or Investigation.',
  },
  {
    key: 'ruling',
    label: 'Ruling',
    sortable: true,
    tooltip:
      'This column displays the most recent FPS ruling that was logged for FPS2 Legacy Lead or Investigation.',
  },
  {
    key: 'subRuling',
    label: 'Ruling Reasons',
    sortable: true,
    tooltip:
      'This column displays the most recent FPS sub-ruling that was logged for the FPS2 Legacy Lead or Investigation.',
  },
];

export const MEDICAID_ALERTS_COLUMNS_MDCD = [
  {
    key: 'models',
    label: 'Medicaid Model',
    sortable: true,
    sortFn: (a: any, b: any) => (a.models.modelName ?? '').localeCompare(b.models.modelName ?? ''),
    custom: true,
    tooltip:
      'This column displays the name of the model that created the alert for the ASR ID. To view the model details, select the model name.',
  },
  {
    key: 'state',
    label: 'Medicaid Alerted State',
    sortable: true,
    tooltip: 'This column displays the state with Medicaid alerts associated with the ASR ID.',
  },
  {
    key: 'modelStatus',
    label: 'Model Status',
    sortable: true,
    tooltip:
      'This column displays the model status associated with the indicated model for the ASR ID.',
  },
  {
    key: 'status',
    label: 'Alert Status',
    sortable: true,
    tooltip:
      'This column displays the alert status associated with the indicated model for the ASR ID. From the \'Current\' section, a "New" status indicates an alert created during the most recent model run or in the last 90 days. An "Aged" status indicates an alert created between 91 and 365 days ago. From the \'History\' section, an "Aged" status indicates an alert created over 365 days ago.',
  },
  {
    key: 'relCreatedDt',
    label: 'Medicaid Latest Alert Created Date',
    sortable: true,
    custom: true,
    tooltip:
      'This column displays the timeframe since the ASR last alerted for any Medicaid model. To review the actual alert date, hover over the timeframe displayed.',
  },
  {
    key: 'lookback',
    label: 'Look Back Period',
    sortable: true,
    tooltip:
      'This column displays the claim field and timeframe the model utilized to analyze claims.',
  },
  {
    key: 'riskScore',
    label: 'Medicaid Risk Score',
    sortable: true,
    custom: true,
    tooltip: "This column displays the Medicaid ASR Risk Score associated with the model's alert.",
  },
  {
    key: 'sevScore',
    label: 'Medicaid Severity Score',
    sortable: true,
    custom: true,
    tooltip:
      "This column displays the Medicaid Severity Score used to help inform the risk level associated with the model's alert. Each alert is assigned a score from 0 to 1. For more details, please see the Medicaid Severity Score section located in the Alerts and Models section of the Support Portal.",
  },
  {
    key: 'cost',
    label: 'Cost',
    sortable: true,
    tooltip:
      "This column displays the total amount paid for all claims at risk associated with the ASR ID for the last year. The 'Cost' column displays N/A if the provider has an alert in a state outside of the end-user's jurisdiction. The end-user will not be able to export financial information for a Medicaid Alerted State outside of the end-user's jurisdiction.",
  },
  {
    key: 'reportCard',
    label: 'Report Card',
    sortable: false,
    custom: true,
    tooltip:
      "This column provides a hyperlink to the alert's report card that provides details on each attribution for the identified model.",
  },
  {
    key: 'alerts',
    label: 'Alerts',
    sortable: true,
    custom: true,
    tooltip:
      'This column displays the number of alerts, or each time the ASR ID was identified during a model run. To view details associated with each alert, select the number hyperlink.',
  },
  {
    key: 'claimLines',
    label: 'Claim Lines',
    sortable: false,
    custom: true,
    tooltip:
      'This column provides a button to download the first 100K claims at risk lines associated with the identified model latest alert, in descending order.',
  },
  {
    key: 'derivedZone',
    label: 'Derived Jurisdiction',
    sortable: true,
    tooltip: 'This column displays the UPIC assigned jurisdiction.',
  },
];

export const MEDICAID_ALERT_DLG_COLUMNS = [
  {
    key: 'status',
    label: 'Status',
    sortable: true,
    tooltip:
      'This column displays the alert status associated with the indicated model for the ASR ID. From the \'Current\' section, a "New" status indicates an alert created during the most recent model run or in the last 90 days. An "Aged" status indicates an alert created between 91 and 365 days ago. From the \'History\' section, an "Aged" status indicates an alert created over 365 days ago.',
  },
  {
    key: 'hasReportCard',
    label: 'Report Card',
    sortable: false,
    custom: true,
    tooltip:
      "This column provides a hyperlink to the alert's report card that provides details on each attribution for the identified model.",
  },
  {
    key: 'claimLines',
    label: 'Claim Lines',
    sortable: false,
    custom: true,
    tooltip:
      'This column provides a hyperlink to the first 1,000 claims at risk lines associated with the alert for the identified model. Claim lines related to an Alert with a create date over five years ago are grayed out.',
  },
  {
    key: 'state',
    label: 'Medicaid Alerted State',
    sortable: true,
    tooltip: 'This column displays the state with Medicaid alerts associated with the ASR ID.',
  },
  {
    key: 'createDt',
    label: 'Medicaid Latest Alert Created Date',
    sortable: true,
    tooltip:
      'This column displays the timeframe since the ASR last alerted for any model. To review the actual alert date in YYYY/MM/DD format, hover over the timeframe displayed.',
  },
  {
    key: 'riskScore',
    label: 'Medicaid Risk Score',
    sortable: true,
    custom: true,
    tooltip: 'This column displays the Medicaid ASR Risk Score associated with the ASR ID.',
  },
  {
    key: 'sevScore',
    label: 'Medicaid Severity Score',
    sortable: true,
    custom: true,
    tooltip:
      "This column displays the Medicaid Severity Score used to help inform the risk level associated with the model's alert. Each alert is assigned a score from 0 to 1. For more details, please see the Medicaid Severity Score section located in the Alerts and Models section of the Support Portal.",
  },
  {
    key: 'derivedZone',
    label: 'Derived Jurisdiction',
    sortable: true,
    tooltip: 'This column displays the UPIC assigned jurisdiction.',
  },
  {
    key: 'cost',
    label: 'Cost',
    sortable: true,
    tooltip:
      "This column displays the total amount paid for all claims at risk associated with the ASR ID for the last year. The 'Cost' column displays N/A if the provider has an alert in a state outside of the end-user's jurisdiction. The end-user will not be able to export financial information for a Medicaid Alerted State outside of the end-user's jurisdiction.",
  },
];

export const MEDICAID_LEADS_COLUMNS = [
  {
    key: 'id',
    label: 'ID',
    sortable: true,
    custom: true,
    tooltip:
      'This column displays the UCM lead or investigation number associated with the ASR ID. To view additional lead or investigation details, select the ID hyperlink.',
  },
  {
    key: 'category',
    label: 'Category',
    sortable: true,
    tooltip: 'This column displays if the ID number is either a lead or an investigation.',
  },
  {
    key: 'state',
    label: 'Medicaid Alerted State',
    sortable: true,
    tooltip: 'This column displays the state with Medicaid alerts associated with the ASR ID.',
  },
  {
    key: 'status',
    label: 'Status',
    sortable: true,
    tooltip: 'This column displays if the lead or investigation is open or closed.',
  },
  {
    key: 'assignedTo',
    label: 'Assigned To',
    sortable: true,
    tooltip: 'This column displays the name of the end-user assigned to the lead or investigation.',
  },
  {
    key: 'createdDt',
    label: 'Create Date',
    sortable: true,
    tooltip: 'This column displays the date and time of the lead or investigation creation.',
  },
  {
    key: 'modDt',
    label: 'Mod Date',
    sortable: true,
    tooltip: 'This column displays the date and time that the lead or investigation was modified.',
  },
  {
    key: 'activities',
    label: 'Activities',
    sortable: true,
    tooltip:
      'This column displays the total number of activities logged for the lead or investigation.',
  },
  {
    key: 'actions',
    label: 'Actions',
    sortable: true,
    tooltip:
      'This column displays the total number of actions logged for the lead or investigation.',
  },
  {
    key: 'ruling',
    label: 'Ruling',
    sortable: true,
    tooltip: 'This column displays the current FPS ruling for the lead or investigation.',
  },
  {
    key: 'subRuling',
    label: 'Ruling Reasons',
    sortable: true,
    tooltip: 'This column displays the FPS sub-ruling for the lead or investigation.',
  },
];

export const MEDICAID_SUPPORTING_DATA_COLUMNS = [
  {
    key: 'modelNm',
    label: 'Model Name',
    sortable: true,
    tooltip: 'This column displays the name of the Medicaid model associated with ASR ID.',
  },
  {
    key: 'states',
    label: 'Medicaid Alerted States',
    sortable: true,
    tooltip:
      'This column displays all states with Medicaid alerts associated with the ASR ID. This column is updated from the last model run.',
  },
  {
    key: 'role',
    label: 'Medicaid Alerted Provider Role',
    sortable: true,
    tooltip:
      'This column displays the provider role from the header and/or claim line that the model alerted on.',
  },
  {
    key: 'billingNpi',
    label: 'Medicaid Alerted Billing Provider NPI',
    sortable: true,
    tooltip:
      "This column displays the Billing Provider NPIs corresponding to the associated ASR ID if the ASR's NPI is listed as the Rendering NPI, Attending NPI, or the same as the Billing NPI for claims at risk. The data contained within this table is updated from the last model run.",
  },
  {
    key: 'svcCat',
    label: 'Medicaid Alerted Service Category',
    sortable: true,
    tooltip: 'This column displays the Service Category from the alerted claims at risk.',
  },
  {
    key: 'mcoSubmitAmt',
    label: 'MCO Alerted Submitted Amount',
    sortable: true,
    tooltip:
      'This column displays the total amount submitted by the ASR alerted provider for MCO alerted claims.',
  },
  {
    key: 'mcoTotalPmt',
    label: 'MCO Alerted Total Payment',
    sortable: true,
    tooltip:
      'This column displays the total amount paid to the ASR alerted provider for MCO alerted claims.',
  },
  {
    key: 'mcoPlan',
    label: 'MCO Alerted Total Payment Plan',
    sortable: true,
    tooltip: 'This column displays the MCO plan name and plan ID for the ASR alerted provider.',
  },
  {
    key: 'mcoRecipCnt',
    label: 'Medicaid Alerted Recipient by MCO',
    sortable: true,
    tooltip:
      'This column displays the number of unique Medicaid recipients that the ASR alerted provider was paid for MCO alerted claims.',
  },
  {
    key: 'ffsSubmitAmt',
    label: 'FFS Alerted Submitted Amount',
    sortable: true,
    tooltip:
      'This column displays the total amount submitted by the ASR alerted provider for FFS alerted claims.',
  },
  {
    key: 'ffsTotalPmt',
    label: 'FFS Alerted Total Payment',
    sortable: true,
    tooltip:
      'This column displays the total amount paid to the ASR alerted provider for FFS alerted claims.',
  },
  {
    key: 'ffsRecipCnt',
    label: 'Medicaid Alerted Recipient by FFS',
    sortable: true,
    tooltip:
      'This column displays the number of unique Medicaid recipients that the ASR alerted provider was paid for based on FFS alerted claims.',
  },
];

export const MEDICAID_ASR_HISTORY_COLUMNS = [
  {
    key: 'userName',
    label: 'User Name',
    sortable: true,
    tooltip:
      "This column displays the end user's ID or the system name that generated the identified transaction.",
  },
  {
    key: 'eventDt',
    label: 'Event Date',
    sortable: true,
    tooltip: 'This column displays the date and time the identified transaction occurred.',
  },
  {
    key: 'riskScore',
    label: 'Medicaid Risk Score',
    sortable: true,
    tooltip: 'This column displays the Medicaid ASR Risk Score associated with the ASR ID.',
    formatPipe: 'riskScore',
  },
  {
    key: 'description',
    label: 'Description',
    sortable: true,
    tooltip: 'This column displays a description of the transaction that occurred.',
  },
  {
    key: 'comments',
    label: 'Comments',
    sortable: true,
    tooltip:
      'This column displays comments entered by the end-user or a standard system message generated by the system for the identified transaction.',
  },
];

export const MEDICAID_ALERTS_HISTORY_COLUMNS = [
  {
    key: 'models',
    label: 'Medicaid Model',
    sortable: true,
    sortFn: (a: any, b: any) => (a.models.modelName ?? '').localeCompare(b.models.modelName ?? ''),
    custom: true,
    tooltip: 'This column displays the name of the model that created the alert for the ASR ID.',
  },
  {
    key: 'state',
    label: 'Medicaid Alerted State',
    sortable: true,
    tooltip: 'This column displays the state with Medicaid alerts associated with the ASR ID.',
  },
  {
    key: 'modelStatus',
    label: 'Model Status',
    sortable: true,
    tooltip:
      'This column displays the model status associated with the indicated model for the ASR ID.',
  },
  {
    key: 'status',
    label: 'Alert Status',
    sortable: true,
    tooltip:
      'This column displays the alert status associated with the indicated model for the ASR ID. An "Aged" status indicates the model identified the ASR ID last alerted for the identified model between 91 and 365 days ago.',
  },
  {
    key: 'relCreatedDt',
    label: 'Medicaid Latest Alert Created Date',
    sortable: true,
    custom: true,
    tooltip:
      'This column displays the timeframe since the ASR last alerted for any Medicaid models.',
  },
  {
    key: 'lookback',
    label: 'Look Back Period',
    sortable: true,
    tooltip:
      'This column displays the claim field and timeframe the model utilized to analyze claims.',
  },
  {
    key: 'alerts',
    label: 'Alerts',
    sortable: true,
    custom: true,
    tooltip:
      'This column displays the number or alerts, or each time the ASR ID was identified during a model run. To view details associated with each alert, select the number hyperlink.',
  },
  {
    key: 'derivedZone',
    label: 'Derived Jurisdiction',
    sortable: true,
    tooltip: 'This column displays the UPIC assigned jurisdiction.',
  },
];

export const Prioritize_Columns = [
  {
    key: 'npi',
    label: 'ASR ID',
    sortable: true,
  },
  {
    key: 'providerName',
    label: 'Provider Name',
    sortable: true,
  },
  {
    key: 'alerts',
    label: 'Alerts',
    custom: true,
    tooltip:
      'This column displays a list of model names that the associated ASR ID has alerted on within the last 180 days. Selection of the models that led to prioritization is required.',
  },
  {
    key: 'comments',
    label: 'Comments',
    custom: true,
    tooltip:
      'This column provides the ability to enter a comment for the associated ASR and is required for ASRs with no alerts within the last 180 days.',
  },
];

export const Prioritize_MDCD_Columns = [
  {
    key: 'npi',
    label: 'ASR ID',
    sortable: true,
  },
  {
    key: 'providerName',
    label: 'Provider Name',
    sortable: true,
  },
  {
    key: 'alerts',
    label: 'Alerts',
    custom: true,
    tooltip:
      "This column displays a list of Medicaid model names that the associated ASR ID has alerted on within the last 365 days, whether that model alerted in state within that user's jurisdiction or not. Selection of the models that led to prioritization is required.",
  },
  {
    key: 'states',
    label: 'Medicaid Alerted States',
    custom: true,
    tooltip:
      "This column displays a list of states and the associated Medicaid model name selected in the 'Alerts' column that the associated ASR ID has alerted on within the last 365 days. Only the alerted states within the end user's jurisdiction are listed for selection to prioritize to UCM. Selection of a state for each model selected is required for prioritization.",
  },
  {
    key: 'comments',
    label: 'Comments',
    custom: true,
    tooltip:
      'This column provides the ability to enter a comment for the associated ASR and is required for ASRs with no alerts within the last 365 days.',
  },
];

export const ASR_PRIORITIZATION_SUMMARY_MEDICARE_COLUMNS = [
  { key: 'userId', label: 'User ID', sortable: true },
  { key: 'zone', label: 'Jurisdiction', sortable: true },
  { key: 'addedDt', label: 'Date ASR Prioritized', sortable: true },
  { key: 'modelList', label: 'Alerts', sortable: true },
  { key: 'comments', label: 'Comments', sortable: true },
  { key: 'cmsPriorityAsrInd', label: 'Prioritized by CPI', sortable: true },
  { key: 'source', label: 'Source', sortable: true },
];
export const ASR_PRIORITIZATION_SUMMARY_MEDICAID_COLUMNS = [
  { key: 'userId', label: 'User ID', sortable: true },
  { key: 'state', label: 'State', sortable: true },
  { key: 'zone', label: 'Jurisdiction', sortable: true },
  { key: 'addedDt', label: 'Date ASR Prioritized', sortable: true },
  { key: 'modelList', label: 'Alerts', sortable: true },
  { key: 'comments', label: 'Comments', sortable: true },
  { key: 'source', label: 'Source', sortable: true },
];
export const ASR_EXTERNAL_MEDICAID_COLUMNS = [
  { key: 'attrDef', label: 'Attribute Defintion', sortable: true },
  { key: 'threshold', label: 'Threshold Criteria Met', custom: true, sortable: true },
  { key: 'prvdrVal', label: 'Provider Value', sortable: true },
  { key: 'attrThresh', label: 'Attribute Threshold', sortable: true },
  { key: 'stateMedian', label: 'State Median', sortable: true },
  { key: 'statePct', label: 'State Percentage', sortable: true },
];
export const ASR_UNIQUE_ALERTS_COLUMNS = [
  { key: 'alertTypeCd', label: 'Model Name', sortable: true },
];
export const ASR_PROVIDER_ROLES_COLUMNS = [
  { key: 'roleCd', label: 'Role Description', sortable: true },
];
export const ASR_SPECIALTY_COLUMNS = [
  { key: 'specialtyTypeCd', label: 'Code', sortable: true },
  { key: 'specialtyTypeDesc', label: 'Description', sortable: true },
];
export const ASR_PTAN_COLUMNS = [
  { key: 'ptan', label: 'PTAN', sortable: true },
  { key: 'type', label: 'PTAN Type', sortable: true },
];
export const ASR_ENROLLMENT_COLUMNS = [
  { key: 'code', label: 'Enrollment ID', sortable: true },
  { key: 'desc', label: 'Enrollment Status', sortable: true },
];
export const ASR_MDCD_ENROLLMENT_COLUMNS = [
  { key: 'mdcdId', label: 'Medicaid ID', sortable: true },
  { key: 'state', label: 'State', sortable: true },
  { key: 'status', label: 'Enrollment Status', sortable: true },
  { key: 'efctvDt', label: 'Effective Date', sortable: true },
  { key: 'termDt', label: 'Termination Date', sortable: true },
];
export const ASR_BILLING_NPIS_COLUMNS = [
  { key: 'modelBusnsId', label: 'Model', sortable: true },
  { key: 'npiAlertTypeCd', label: 'Alerted Provider Type', sortable: true },
  {
    key: 'clmBlngPrvdrNpiNum',
    label: 'Alerted Billing NPI',
    sortable: true,
    custom: true,
    linkTemplate: 'billSummaryNpiLink',
  },
  { key: 'rltdPrvdrName', label: 'Billing Provider Name', sortable: true },
  { key: 'clmSrcType', label: 'Claim Type', sortable: true },
  { key: 'upicJrsdctn', label: 'Jurisdiction', sortable: true },
  { key: 'clmSbmtAmt', label: 'Submitted Amount', sortable: true, formatPipe: 'currencyPipe' },
  { key: 'clmPmtAmt', label: 'Total Payment', sortable: true, formatPipe: 'currencyPipe' },
  { key: 'clmBeneCnt', label: 'Bene Count', sortable: true },
];
export const ASR_CRIMINAL_SUMMARY_COLUMNS = [
  {
    key: 'businessName',
    label: 'Name',
    sortable: true,
    custom: true,
    linkTemplate: 'apsDetailLink',
  },
  { key: 'charge', label: 'Charge', sortable: true },
  { key: 'chargeDate', label: 'Charge Date', sortable: true },
  { key: 'chargeType', label: 'Charge Type', sortable: true },
  { key: 'county', label: 'County', sortable: true },
  { key: 'courtName', label: 'Court Name', sortable: true },
  { key: 'courtJurisdiction', label: 'Court Jurisdiction', sortable: true },
  { key: 'crimSource', label: 'Crime Source', sortable: true },
  { key: 'disposition', label: 'Disposition', sortable: true },
  { key: 'dispositionDate', label: 'Disposition Date', sortable: true },
  { key: 'incarcerationDate', label: 'Incarceration Date', sortable: true },
  { key: 'sentence', label: 'Sentence', sortable: true },
  { key: 'sentenceDate', label: 'Sentence Date', sortable: true },
  { key: 'state', label: 'State', sortable: true },
  { key: 'updateDt', label: 'Updated Date', sortable: true },
];

export const ASR_RELATED_ASR_COLUMNS = [
  { key: 'npi', label: 'ASR ID', sortable: true, custom: true, linkTemplate: 'relatedASRnpi' },
  { key: 'name', label: 'Name', sortable: true },
  { key: 'relationships', label: 'Relationship Type', sortable: true },
  { key: 'riskScore', label: 'Risk Score', sortable: true },
  { key: 'priorityScore', label: 'Priority Score', sortable: true },
  { key: 'asrCost', label: 'ASR Cost', sortable: true },
  { key: 'newModels', label: 'New Alerts', sortable: true },
  { key: 'agedModels', label: 'Aged Alerts', sortable: true },
];

export const ASR_JURISDICTION_COLUMNS = [
  { key: 'zone', label: 'Jurisdiction', sortable: true },
  { key: 'totalCost', label: 'Total Payment', sortable: true },
  { key: 'totalClaimLines', label: 'Number of Claim Lines', sortable: true },
];

export const ASR_COST_COLUMNS = [
  { key: 'zone', label: 'Jurisdiction', sortable: true },
  { key: 'totalCost', label: 'ASR Cost', sortable: true },
  { key: 'totalClaimLines', label: 'Number of Claim Lines', sortable: true },
];

export const ASR_PHASE1_JURISDICTION_COLUMNS = [
  {
    key: 'zone',
    label: 'Phase 1 Jurisdiction',
    sortable: true,
    tooltip:
      'This column shall display each UPIC Jurisdiction with claims at risk associated with all model alerts created within the last 14 days for the ASR.',
  },
  {
    key: 'totalCost',
    label: 'Phase 1 ASR Cost',
    sortable: true,
    sorter: 'numericWithNaText',
    tooltip:
      'This column shall display the total submitted amount for claims at risk associated with the Jurisdiction. Field will display as a numerical value up to 2 decimal places.',
  },
  {
    key: 'totalClaimLines',
    label: 'Phase 1 Number of Claims',
    sortable: true,
    tooltip:
      'This column shall display the total submitted claims at risk associated with the Jurisdiction. Field will display as a numerical value.',
  },
];

export const ASR_MEDICAID_MODEL_COLUMNS = [
  {
    key: 'modelNm',
    label: 'Model Name',
    sortable: true,
    tooltip: 'This column displays the name of the Medicaid model associated with ASR ID.',
  },
  {
    key: 'states',
    label: 'Medicaid Alerted State(s)',
    sortable: true,
    tooltip:
      'This column displays all states with Medicaid alerts associated with the ASR ID. This column is updated from the last model run.',
  },
  {
    key: 'role',
    label: 'Medicaid Alerted Provider Role',
    sortable: true,
    sorter: 'numericWithNaText',
    tooltip:
      'This column displays the provider role from the header and/or claim line that the model alerted on.',
  },
  {
    key: 'billingNpi',
    label: 'Medicaid Alerted Billing Provider NPI',
    sortable: true,
    tooltip:
      "This column displays the Billing Provider NPI(s) corresponding to the associated ASR ID if the ASR's NPI is listed as the Rendering NPI, Attending NPI, or the same as the Billing NPI for claims at risk. The data is updated from the last model run.",
  },
  {
    key: 'svcCat',
    label: 'Medicaid Alerted Service Category',
    sortable: true,
    tooltip: 'This column displays the Service Category from the alerted claims at risk.',
  },
  {
    key: 'mcoSubmitAmt',
    label: 'MCO Alerted Submitted Amount',
    sortable: true,
    tooltip:
      'This column displays the total amount submitted by the ASR alerted provider for MCO alerted claims.',
  },
  {
    key: 'mcoTotalPmt',
    label: 'MCO Alerted Total Payment',
    sortable: true,
    tooltip:
      'This column displays the total amount paid to the ASR alerted provider for MCO alerted claims.',
  },
  {
    key: 'mcoPlan',
    label: 'MCO Alerted Total Payment Plan',
    sortable: true,
    tooltip: 'This column displays the MCO plan name and plan ID for the ASR alerted provider.',
  },
  {
    key: 'mcoRecipCnt',
    label: 'Medicaid Alerted Recipient by MCO',
    sortable: true,
    tooltip:
      'This column displays the number of unique Medicaid recipients that the ASR alerted provider was paid for MCO alerted claims.',
  },
  {
    key: 'ffsSubmitAmt',
    label: 'FFS Alerted Submitted Amount',
    sortable: true,
    tooltip:
      'This column displays the total amount submitted by the ASR alerted provider for FFS alerted claims.',
  },
  {
    key: 'ffsTotalPmt',
    label: 'FFS Alerted Total Payment',
    sortable: true,
    tooltip:
      'This column displays the total amount paid to the ASR alerted provider for FFS alerted claims.',
  },
  {
    key: 'ffsRecipCnt',
    label: 'Medicaid Alerted Recipient by FFS',
    sortable: true,
    tooltip:
      'This column displays the number of unique Medicaid recipients that the ASR alerted provider was paid for based on FFS alerted claims.',
  },
];

export const MODEL_GUIDANCE_COLUMNS = [
  {
    key: 'modelName',
    label: 'Model Name',
    sortable: true,
    custom: true,
  },
  {
    key: 'type',
    label: 'Model Type',
    sortable: true,
  },
  {
    key: 'lookback',
    label: 'Look Back Period',
    sortable: true,
  },
  {
    key: 'claimType',
    label: 'Claim Types',
    sortable: true,
  },
  {
    key: 'version',
    label: 'Model Version Number',
    sortable: true,
  },
  {
    key: 'activeStatus',
    label: 'Model Status',
    sortable: true,
  },
  {
    key: 'statusDt',
    label: 'Model Status Update Date',
    sortable: true,
  },
  {
    key: 'cadence',
    label: 'Cadence',
    sortable: true,
    custom: true,
  },
  {
    key: 'ownerName',
    label: "Model Owner's Name",
    sortable: true,
  },
  {
    key: 'ownerEmail',
    label: "Model Owner's E-mail",
    sortable: true,
  },
  {
    key: 'ownerPhone',
    label: "Model Owner's Phone Number",
    sortable: true,
  },
  {
    key: 'implDt',
    label: 'Date Implemented',
    sortable: true,
  },
  {
    key: 'updateDt',
    label: 'Date Modified',
    sortable: true,
  },
  {
    key: 'modelDesc',
    label: 'Model Description',
    sortable: true,
  },
  {
    key: 'fpsVersion',
    label: 'FPS Version',
    sortable: true,
  },
];

export const REVOCATION_COLUMNS = [
  {
    key: 'revocationDate',
    label: 'Effective Date',
    sortable: true,
  },
  {
    key: 'revocationDesc',
    label: 'Description',
    sortable: true,
  },
];

export const LEADS_ACTIVITY_COLUMNS = [
  {
    key: 'userId',
    label: 'User Name',
    sortable: true,
  },
  {
    key: 'desc',
    label: 'Activity',
    sortable: true,
  },
  {
    key: 'eventDt',
    label: 'Date of Event',
    sortable: true,
  },
];

export const LEADS_RULING_COLUMNS = [
  {
    key: 'userId',
    label: 'User Name',
    sortable: true,
  },
  {
    key: 'desc',
    label: 'Ruling',
    sortable: true,
  },
  {
    key: 'eventDt',
    label: 'Date of Event',
    sortable: true,
  },
];

export const LEADS_ACTIONS_COLUMNS = [
  {
    key: 'userId',
    label: 'User Name',
    sortable: true,
  },
  {
    key: 'desc',
    label: 'Action',
    sortable: true,
  },
  {
    key: 'eventDt',
    label: 'Date of Event',
    sortable: true,
  },
];

export const LEADS_BACTIONS_COLUMNS = [
  {
    key: 'userId',
    label: 'User Name',
    sortable: true,
  },
  {
    key: 'desc',
    label: 'Barrier to Action',
    sortable: true,
  },
  {
    key: 'eventDt',
    label: 'Date of Event',
    sortable: true,
  },
];

export const LEADS_RATE_COLUMNS = [
  {
    key: 'userId',
    label: 'User Name',
    sortable: true,
  },
  {
    key: 'modelNm',
    label: 'Model Name',
    sortable: true,
  },
  {
    key: 'rating',
    label: 'Rating',
    sortable: true,
  },
  {
    key: 'eventDt',
    label: 'Modification Date',
    sortable: true,
  },
];

export const REPORT_CARD_COLUMNS = [
  {
    key: 'drill',
    label: 'Drill',
    custom: true,
    sortable: true,
    tooltip:
      "A 'Yes' displayed in this column indicates that a subset of claims is available to download, up to 100K in descending order, which contributed to the provider alerting for the attribute threshold. To download the associated claims, select the 'Yes' button.",
  },
  {
    key: 'mdcdId',
    label: 'Medicaid ID',
    sortable: true,
  },
  {
    key: 'state',
    label: 'State',
    sortable: true,
  },
  {
    key: 'attrDef',
    label: 'Attribute Definition',
    sortable: true,
  },
  {
    key: 'overThreshold',
    label: 'Threshold Criteria Met',
    custom: true,
    sortable: true,
  },
  {
    key: 'providerValue',
    label: 'Provider Value',
    sortable: true,
  },
  {
    key: 'zoneThreshold',
    label: 'Attribute Threshold',
    sortable: true,
  },
  {
    key: 'nationalMed',
    label: 'National Median',
    sortable: true,
  },
  {
    key: 'zoneMed',
    label: 'Inv. Median',
    sortable: true,
  },
  {
    key: 'macMed',
    label: 'MAC Median',
    sortable: true,
  },
  {
    key: 'providerNatRank',
    label: 'Provider National Rank',
    sortable: true,
  },
  {
    key: 'provderZoneRank',
    label: 'Provider Inv. Rank',
    sortable: true,
  },
  {
    key: 'macPctl',
    label: 'Provider MAC Rank',
    sortable: true,
  },
];

export const REPORT_CARD_COLUMNS_MDCD = [
  {
    key: 'drill',
    label: 'Drill',
    custom: true,
    sortable: true,
    tooltip:
      "A 'Yes' displayed in this column indicates that a subset of claims is available to download, up to 100K in descending order, which contributed to the provider alerting for the attribute threshold. To download the associated claims, select the 'Yes' button.",
  },
  {
    key: 'mdcdId',
    label: 'Medicaid ID',
    sortable: true,
  },
  {
    key: 'state',
    label: 'State',
    sortable: true,
  },
  {
    key: 'attrDef',
    label: 'Attribute Definition',
    sortable: true,
  },
  {
    key: 'overThreshold',
    label: 'Threshold Criteria Met',
    custom: true,
    sortable: true,
  },
  {
    key: 'providerValue',
    label: 'Provider Value',
    sortable: true,
  },
  {
    key: 'zoneThreshold',
    label: 'Attribute Threshold',
    sortable: true,
  },
  {
    key: 'nationalMed',
    label: 'State Median',
    sortable: true,
  },
  {
    key: 'zoneMed',
    label: 'Zone Median',
    sortable: true,
  },
  {
    key: 'macMed',
    label: 'MAC Median',
    sortable: true,
  },
  {
    key: 'providerNatRank',
    label: 'State Rank',
    sortable: true,
  },
  {
    key: 'provderZoneRank',
    label: 'Zone Rank',
    sortable: true,
  },
  {
    key: 'macPctl',
    label: 'Provider MAC Rank',
    sortable: true,
  },
];

export const SNA_REPORT_CARD_COLUMNS = [
  {
    key: 'drill',
    label: 'Drill',
    custom: true,
    sortable: true,
    tooltip:
      "A 'Yes' displayed in this column indicates that a subset of claims is available to download, up to 100K in descending order, which contributed to the provider alerting for the attribute threshold. To download the associated claims, select the 'Yes' button.",
  },
  {
    key: 'relatedPrvdrNpi',
    label: 'Related Provider NPI',
    sortable: true,
  },
  {
    key: 'relatedPrvdrName',
    label: 'Related Provider Name',
    sortable: true,
  },
  {
    key: 'subjPrvdrBeneCnt',
    label: 'Subject Provider # of Benes',
    sortable: true,
  },
  {
    key: 'relatedPrvdrBeneCnt',
    label: 'Related Provider # of Benes',
    sortable: true,
  },
  {
    key: 'sharedBeneCnt',
    label: '# of Shared Benes',
    sortable: true,
  },
  {
    key: 'subjectPrvdrSharedBenePct',
    label: 'Subject Provider % Shared Benes',
    sortable: true,
  },
  {
    key: 'relatedPrvdrSharedBenePct',
    label: 'Related Provider % Shared Benes',
    sortable: true,
  },
  {
    key: 'riskRelationshipRsn',
    label: 'Risk Relationship Reason',
    sortable: true,
  },
  {
    key: 'pecosRltnshp',
    label: 'PECOS Relationship between Subject and Related Providers',
    sortable: true,
  },
  {
    key: 'rltdPrvdrNum',
    label: 'Number of Total Related Providers',
    sortable: true,
  },
  {
    key: 'badRltdPrvdrNum',
    label: 'Number of Suspect Related Providers',
    sortable: true,
  },
  {
    key: 'badRltdPrvdrPct',
    label: 'Percentage of Suspect Related Providers',
    sortable: true,
  },
];

export const SNA_REPORT_CARD_COLUMNS_MDCD = [
  {
    key: 'drill',
    label: 'Drill',
    custom: true,
    sortable: true,
    tooltip:
      "A 'Yes' displayed in this column indicates that a subset of claims is available to download, up to 100K in descending order, which contributed to the provider alerting for the attribute threshold. To download the associated claims, select the 'Yes' button.",
  },
  {
    key: 'relatedPrvdrNpi',
    label: 'Related Provider NPI',
    sortable: true,
  },
  {
    key: 'relatedPrvdrName',
    label: 'Related Provider Name',
    sortable: true,
  },
  {
    key: 'rltdPrvdrType',
    label: 'Related Provider Type',
    sortable: true,
  },
  {
    key: 'subjPrvdrBeneCnt',
    label: 'Subject Provider # of Receipients',
    sortable: true,
  },
  {
    key: 'relatedPrvdrBeneCnt',
    label: 'Related Provider # of Receipients',
    sortable: true,
  },
  {
    key: 'sharedBeneCnt',
    label: '# of Shared Receipients',
    sortable: true,
  },
  {
    key: 'subjectPrvdrSharedBenePct',
    label: 'Subject Provider % Shared Receipients',
    sortable: true,
  },
  {
    key: 'relatedPrvdrSharedBenePct',
    label: 'Related Provider % Shared Receipients',
    sortable: true,
  },
  {
    key: 'riskRelationshipRsn',
    label: 'Risk Relationship Reason',
    sortable: true,
  },
  {
    key: 'pecosRltnshp',
    label: 'PECOS Relationship between Subject and Related Providers',
    sortable: true,
  },
  {
    key: 'rltdPrvdrNum',
    label: 'Number of Total Related Providers',
    sortable: true,
  },
  {
    key: 'badRltdPrvdrNum',
    label: 'Number of Suspect Related Providers',
    sortable: true,
  },
  {
    key: 'badRltdPrvdrPct',
    label: 'Percentage of Suspect Related Providers',
    sortable: true,
  },
];

export const PREDICTIVE_REPORT_CARD_COLUMNS = [
  {
    key: 'drill',
    label: 'Drill',
    custom: true,
    sortable: true,
    tooltip:
      "A 'Yes' displayed in this column indicates that a subset of claims is available to download, up to 100K in descending order, which contributed to the provider alerting for the attribute threshold. To download the associated claims, select the 'Yes' button.",
  },
  {
    key: 'attrDef',
    label: 'Attribute Definition',
    sortable: true,
  },
  {
    key: 'overThreshold',
    label: 'Threshold Criteria Met',
    // custom: true,
    sortable: true,
  },
  {
    key: 'providerValue',
    label: 'Provider Value',
    sortable: true,
  },
  {
    key: 'zoneThreshold',
    label: 'Attribute Threshold',
    sortable: true,
  },
  {
    key: 'nationalMed',
    label: 'National Median',
    sortable: true,
  },
  {
    key: 'zoneMed',
    label: 'Inv. Median',
    sortable: true,
  },
  {
    key: 'macMed',
    label: 'MAC Median',
    sortable: true,
  },
  {
    key: 'providerNatRank',
    label: 'Provider National Rank',
    sortable: true,
  },
  {
    key: 'provderZoneRank',
    label: 'Provider Inv. Rank',
    sortable: true,
  },
  {
    key: 'macPctl',
    label: 'Provider MAC Rank',
    sortable: true,
  },
  {
    key: 'contribToAlertPriority',
    label: 'Contribution to Alert Priority',
    sortable: true,
  },
];

export const PREDICTIVE_REPORT_CARD_COLUMNS_MDCD = [
  {
    key: 'drill',
    label: 'Drill',
    custom: true,
    sortable: true,
    tooltip:
      "A 'Yes' displayed in this column indicates that a subset of claims is available to download, up to 100K in descending order, which contributed to the provider alerting for the attribute threshold. To download the associated claims, select the 'Yes' button.",
  },
  {
    key: 'mdcdId',
    label: 'Medicaid ID',
    sortable: true,
  },
  {
    key: 'state',
    label: 'State',
    sortable: true,
  },
  {
    key: 'attrDef',
    label: 'Attribute Definition',
    sortable: true,
  },
  {
    key: 'overThreshold',
    label: 'Threshold Criteria Met',
    custom: true,
    sortable: true,
  },
  {
    key: 'providerValue',
    label: 'Provider Value',
    sortable: true,
  },
  {
    key: 'zoneThreshold',
    label: 'Attribute Threshold',
    sortable: true,
  },
  {
    key: 'nationalMed',
    label: 'State Median',
    sortable: true,
  },
  {
    key: 'zoneMed',
    label: 'Zone Median',
    sortable: true,
  },
  {
    key: 'providerNatRank',
    label: 'State Rank',
    sortable: true,
  },
  {
    key: 'provderZoneRank',
    label: 'Provider Inv. Rank',
    sortable: true,
  },
  {
    key: 'contribToAlertPriority',
    label: 'Contribution Score',
    sortable: true,
  },
];

export const ERS_REPORT_CARD_COLUMNS = [
  {
    key: 'attrIndex',
    label: 'Attribute Index',
    sortable: true,
    tooltip: 'This column displays the contribution ID.',
  },
  {
    key: 'attrRank',
    label: 'Attribute Rank',
    sortable: true,
    tooltip:
      'By default, this column displays the attributes ranked from the greatest positive impact to the least positive impact to the model risk score. The higher the positive contribution value, the higher the ranking. The lower the negative contribution value, the lower the ranking. Example: 10, 9, 5, 2, -1, -3, -5, -10. See Enhanced Risk Score Explainability in the Machine Learning 101 section of the support portal for details.',
  },
  {
    key: 'contribDef',
    label: 'Contribution Definition',
    sortable: true,
    tooltip:
      "This column displays the contributing attribute description. The Intercept indicates the model's baseline risk contribution. If the Intercept is the only record that displays, then the algorithm deferred to the model baseline risk for the provider.",
  },
  {
    key: 'contribType',
    label: 'Contribution Type',
    sortable: true,
    tooltip:
      'This column displays whether the contributing attribute came from an existing FPS model or was an external attribute from the Enhanced Risk Score.',
  },
  {
    key: 'contribImpact',
    label: 'Attribute Impact Simplified',
    sortable: true,
    tooltip:
      'This column indicates if the attribute contributes to an increase or a decrease in model risk score. This value does NOT indicate a change in contribution from the previous risk score run result.',
  },
  {
    key: 'contribVal',
    label: 'Attribute Contribution',
    sortable: true,
    tooltip:
      "This column displays the coefficient value of attributes contributing to the provider's model risk score. The coefficient value indicates how the attribute contributes to the model risk score. Negative numbers pull the model risk score down and positive numbers pull the model risk score up. The larger the number, regardless of being positive or negative, the more influence there is on the risk score. See Enhanced Risk Score Explainability in the Machine Learning 101 section of the support portal for details.",
  },
  {
    key: 'prvdrErsVal',
    label: 'Provider Value',
    sortable: true,
  },
  {
    key: 'alertedPrvdrPct',
    label: 'Alerted Provider Percentile',
    sortable: true,
    tooltip:
      "This column displays the provider's attribute percentile among other providers alerting on this model.",
  },
];
