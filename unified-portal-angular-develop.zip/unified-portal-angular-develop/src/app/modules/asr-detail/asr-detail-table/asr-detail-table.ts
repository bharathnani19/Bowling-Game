import { Component, Inject, OnChanges } from '@angular/core';
import { ToastService } from '../../../services/toaster.service';
import { LoaderService } from '../../../services/loader.service';
import { FileUploadService } from '../../../services/file-upload.service';
import { CommonDialogComponent } from '../../../shared/dialog/common-dialog/common-dialog';
import { MatDialog } from '@angular/material/dialog';
import { ReportCardsComponent } from '../medicare-detail/current-records/report-cards/report-cards.component';
import { AsrDetails } from '../model';

@Component({
  selector: 'app-asr-detail-table',
  templateUrl: './asr-detail-table.html',
  standalone: false,
})
export class ASRDetailsTableComponent {
  rowData: any[];
  columns: any[];
  tableName: string;
  tableId: string;
  isLoading = false;
  pageSize = 10;
  componentId: string;
  enableSearch = true;
  tableHeight = 'auto';
  asrDetails: AsrDetails | null;
  mdcdStateSet = new Set<string>();

  constructor(
    @Inject('componentData') public data: any,
    public dialog: MatDialog,
    private _toaster: ToastService,
    private fileService: FileUploadService,
    private _loader: LoaderService,
  ) {
    this.rowData = this.data?.rowData || [];
    this.columns = this.data?.columns || [];
    this.tableName = this.data?.tableName || 'Details Table';
    this.tableId = this.data?.tableId || 'detailsTable';
    this.tableHeight = this.data?.tableHeight || 'auto';
    this.componentId = this.data?.componentId || 'componentId';
    this.asrDetails = this.data?.asrDetails || null;
     this.mdcdStateSet = new Set(this.asrDetails?.mdcdUserStates?.map((x) => x.state) ?? []);
  }

  

  canExportClaimLines(row: any): boolean {
    if(this.data.type == 'MDCD') {
      return this.mdcdStateSet.has(row.state);
    }
    else return true
    
  }

  generateAsrDetailLink(templateName: string, row: any): string {
    //asrDetailBillSummary
    return '';
  }

  openDetails(row: any, asrType: string = 'medicare') {
    let asrId = String(row?.blngAsrptId || '').trim();

    if (!asrId) {
      asrId = String(row?.npi || '').trim();
    }

    if (!asrId) {
      this._toaster.error('Unable to load details. Missing ASR ID.');
      return;
    }

    window.open(
      `/FPS2UnifiedPortal/Investigative/Details?asrId=${asrId}&viewParam=${asrType}`,
      '_blank',
    );
  }

  downloadModel(docFile: string): void {
    this._loader.show();

    this.fileService.downloadLegacyDocument(docFile).subscribe({
      next: () => {
        this._loader.hide();
      },
      error: (err) => {
        this._loader.hide();
        this._toaster.error('Unable to download document due to ' + err.status);
      },
    });
  }

  onExportClaimLines(row: any) {
    this._loader.show();
    this.fileService
      .downloadClaimsDocument({
        asrId: `${row?.asrDbId}`,
        npi: `${row?.asrDbId}`,
        modelId: row?.alertId,
        fileName: 'alert-claims-export.csv',
        pType: row.partDClaimInd,
        state: row?.mdcdState,
      })
      .subscribe({
        next: (res: any) => {
          this._loader.hide();
        },
        error: (err: any) => {
          this._loader.hide();
          console.log('(asr-detail-table) onExportClaimLines error:', err);
        },
      });
  }

  private getReportCardRow(row: any): any {
    const reportCardType = row?.mdcdState != null ? 'medicaid' : 'medicare';
    return {
      ...row,
      modelId: row?.modelId,
      npi: this.asrDetails?.provider?.npi,
      state: row?.state ?? row?.mdcdState,
      type: reportCardType,
      insertDt: row.createDt,
    };
  }

  onViewReportCard(row: any) {
    const reportCardRow = this.getReportCardRow(row);
    this.dialog.open(CommonDialogComponent, {
      width: '80%',
      data: {
        title: 'Report Cards',
        info: 'Report Cards provide the alert and model attribution details associated with the ASR ID. The report card layout and associated tables vary by model and model table; however, the report card section of the model guidance document associated with the select model provides further details regarding the displayed report card. To learn about the information and functions contained within the report card, hover over the information indicators below.',
        dialogId: 'reportCardsModal',
        componentData: {
          rowData: [reportCardRow, this.asrDetails, reportCardRow.type],
        },
        panelClass: 'ip-dialog-panel',
        component: ReportCardsComponent,
        enableClose: true,
      },
      panelClass: 'ip-dialog-panel',
    });
  }
}
