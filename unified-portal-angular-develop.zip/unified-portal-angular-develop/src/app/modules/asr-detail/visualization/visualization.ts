import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  Inject,
  Input,
  OnDestroy,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Network, DataSet } from 'vis-network/standalone';
import { DetailCard } from '../../../shared/detail-card/detail-card';
import { LoaderService } from '../../../services/loader.service';
import { ToastService } from '../../../services/toaster.service';
import { AsrDetailsService } from '../../../services/asr-details.service';
import { AsrDetails } from '../model';

const VIZEXPORTMAP: any = {
  HHA: 'hhavizexport',
  DME: 'dmevizexport',
  VIZ: 'vizexport',
};

@Component({
  selector: 'app-visualization-dialog',
  standalone: false,
  templateUrl: './visualization.html',
  styleUrls: ['../../../shared/dialog/common-dialog/common-dialog.scss', 'visualization.scss'],
})
export class VisualizationDialogComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('networkContainer', { static: true })
  networkContainer!: ElementRef<HTMLDivElement>;

  @Output() exportViz = new EventEmitter<void>();
  @Output() addConnections = new EventEmitter<void>();

  network!: Network;
  nodesDS!: DataSet<any>;
  edgesDS!: DataSet<any>;

  attributes: any[] = [];
  allNodes: any[] = [];
  allEdges: any[] = [];

  hiddenAttributes = new Set<string>();

  selectedNodes: any[] = [];
  selectedEdges: any[] = [];

  dataUrl = '';
  vizTypeParam = 'sna';

  cardData: DetailCard = {
    title: 'Properties',
    height: '100%',
    sections: [],
  };

  constructor(
    public dialogRef: MatDialogRef<VisualizationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _loader: LoaderService,
    private _toaster: ToastService,
    private _detailsService: AsrDetailsService,
  ) {}

  ngOnInit(): void {
    this.attributes = this.data?.attributes || [];
    this.allNodes = [...(this.data?.nodes || [])];
    this.allEdges = [...(this.data?.edges || [])];
    this.vizTypeParam = this.data?.vizType || 'sna';
    this.buildCardData();
  }

  private hasValue(value: any): boolean {
    return value !== null && value !== undefined && value !== '';
  }

  private visibleItems(items: { label: string; value: any }[]): { label: string; value: any }[] {
    return items.filter((item) => this.hasValue(item.value));
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      if (this.allNodes.length && this.allEdges.length) {
        this.createNetwork(this.allNodes, this.allEdges);
      }
    });
  }

  createNetwork(nodesData: any[], edgesData: any[]): void {
    if (this.network) {
      this.network.destroy();
    }

    this.nodesDS = new DataSet(
      nodesData.map((node: any) => ({
        ...node,
        id: node.id,
        label: node.label,
        title: node.title?.replace(/<br\s*\/?>/gi, '\n'),
      })),
    );

    this.edgesDS = new DataSet(
      edgesData.map((edge: any) => ({
        ...edge,
        id: edge.id,
        from: edge.from,
        to: edge.to,
        title: edge.title?.replace(/<br\s*\/?>/gi, '\n'),
      })),
    );

    const options: any = {
      layout: {
        improvedLayout: false,
      },
      physics: {
        maxVelocity: 25,
        minVelocity: 5,
        stabilization: {
          enabled: true,
          iterations: 1000,
          updateInterval: 500,
          onlyDynamicEdges: false,
        },
      },
      nodes: {
        shape: 'dot',
        shapeProperties: {
          interpolation: false,
        },
        scaling: {
          min: 10,
          max: 30,
        },
      },
      edges: {
        labelHighlightBold: true,
        width: 1.25,
      },
      interaction: {
        hover: true,
        hoverConnectedEdges: true,
        multiselect: true,
        selectable: true,
        navigationButtons: false,
      },
    };

    this.network = new Network(
      this.networkContainer.nativeElement,
      {
        nodes: this.nodesDS,
        edges: this.edgesDS,
      },
      options,
    );

    this.network.fit();

    this.changeNodeSize();
    this.network.once('stabilizationIterationsDone', () => {
      this.network.fit({
        animation: false,
      });
    });

    this.network.on('click', (params: any) => {
      this.selectedNodes = params.nodes?.length ? this.nodesDS.get(params.nodes) : [];

      this.selectedEdges = params.edges?.length ? this.edgesDS.get(params.edges) : [];

      this.buildCardData();
    });

    this.network.on('afterDrawing', (ctx: CanvasRenderingContext2D) => {
      this.dataUrl = ctx.canvas.toDataURL('image/png');
    });
  }

  onAttributeChange(attribute: any, checked: boolean): void {
    if (checked) {
      this.hiddenAttributes.add(attribute.name);
      this.hideAttributeNodes(attribute);
    } else {
      this.hiddenAttributes.delete(attribute.name);
      this.showAttributeNodes(attribute);
    }

    this.selectedNodes = [];
    this.selectedEdges = [];
    this.buildCardData();
  }

  hideAttributeNodes(attribute: any): void {
    const nodeIds = this.getAttributeNodeIds(attribute);
    this.nodesDS.remove([...nodeIds]);
  }

  showAttributeNodes(attribute: any): void {
    const nodeIds = this.getAttributeNodeIds(attribute);

    const nodesToAdd = this.allNodes.filter((node) => {
      return nodeIds.has(node.id) && !this.isNodeHiddenByAnotherAttribute(node.id);
    });

    this.nodesDS.add(nodesToAdd);
    this.changeNodeSize();
  }

  isNodeHiddenByAnotherAttribute(nodeId: string): boolean {
    return this.attributes.some((attr) => {
      if (!this.hiddenAttributes.has(attr.name)) {
        return false;
      }

      return this.getAttributeNodeIds(attr).has(nodeId);
    });
  }

  getAttributeNodeIds(attribute: any): Set<string> {
    return new Set((attribute?.npis || []).map((npi: any) => npi.code));
  }

  changeNodeSize(): void {
    const blueNodes = this.nodesDS.get({
      filter: (item: any) => {
        return (
          item.color === 'blue' ||
          item.color === 'Blue' ||
          item.color?.background === 'blue' ||
          item.color?.background === 'Blue'
        );
      },
    });

    blueNodes.forEach((node: any) => {
      node.size = 15;
      this.nodesDS.update(node);
    });
  }

  addNetVizNodes(nodes: any[]): void {
    this.nodesDS.add(nodes);
    this.changeNodeSize();
  }

  onAddConnectionsClick(): void {
    this.addConnections.emit();
  }

  onExportClick(): void {
    this._loader.show();

    const vizType = VIZEXPORTMAP[this.data.vizType] ?? 'vizexport';

    this._detailsService
      .getVizExportData({
        asrId: this.data.asrDetails?.provider?.npi || '',
        vizType,
        modelId: this.data?.modelData?.modelBusnsId,
      })
      .subscribe({
        next: (res) => {
          this._loader.hide();
          console.log(res.headers.keys());

          console.log('Content-Disposition:', res.headers.get('Content-Disposition'));

          console.log('content-disposition:', res.headers.get('content-disposition'));

          const blob = res.body;
          if (!blob) {
            this._toaster.error('Export failed. No file returned.');
            return;
          }

          const contentDisposition = res.headers.get('Content-Disposition');
          const fileName = this.getFileNameFromHeader(contentDisposition);

          const url = window.URL.createObjectURL(blob);
          const link = document.createElement('a');

          link.href = url;
          link.download = fileName;
          document.body.appendChild(link);
          link.click();

          document.body.removeChild(link);
          window.URL.revokeObjectURL(url);
        },
        error: (err) => {
          this._loader.hide();
          this._toaster.error('Visualization export failed due to ' + err.status);
        },
      });
  }

  private getFileNameFromHeader(headerVal: string | null): string {
    if (!headerVal) {
      return 'provider-network-visualization.xlsx';
    }

    const match = headerVal.match(/filename\*?=(?:UTF-8'')?["\[]?([^";\]]+)/i);

    if (match?.[1]) {
      return decodeURIComponent(match[1].replace(/"/g, '').trim());
    }

    return 'provider-network-visualization.xlsx';
  }

  private csvSafe(value: any): string {
    return String(value ?? '').replace(/"/g, '""');
  }

  onSaveClick(): void {
    if (!this.dataUrl) return;

    const link = document.createElement('a');
    link.download = 'viz_export.png';
    link.href = this.dataUrl;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  onPrintClick(): void {
    const canvas = this.networkContainer.nativeElement.querySelector('canvas');

    if (!canvas) return;

    const imageUrl = canvas.toDataURL('image/png');

    const printWindow = window.open('', '_blank');

    if (!printWindow) return;

    printWindow.document.write(`
    <html>
      <head>
        <title>Provider Network Visualization</title>
        <style>
          @page {
            size: landscape;
            margin: 10mm;
          }

          html,
          body {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
          }

          body {
            display: flex;
            align-items: center;
            justify-content: center;
          }

          img {
            width: 100%;
            height: auto;
            max-height: 95vh;
            object-fit: contain;
          }
        </style>
      </head>
      <body>
        <img src="${imageUrl}" />
        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
              window.close();
            }, 300);
          };
        </script>
      </body>
    </html>
  `);

    printWindow.document.close();
  }

  buildCardData(): void {
    this.cardData = {
      title: 'Properties',
      height: '100%',
      sections: [
        {
          title: 'Node Info:',
          children: this.selectedNodes.length
            ? this.selectedNodes.map((node, index) => ({
                title: `Node #${index + 1}`,
                columns: 3,
                items: this.getNodeInfo(node),
              }))
            : [
                {
                  title: '',
                  columns: 3,
                  items: [],
                },
              ],
        },
        {
          title: 'Edge Info:',
          children: this.selectedEdges.length
            ? this.selectedEdges.map((edge, index) => ({
                title: `Edge #${index + 1}`,
                columns: 3,
                items: this.getEdgeInfo(edge),
              }))
            : [
                {
                  title: '',
                  columns: 3,
                  items: [],
                },
              ],
        },
      ],
    };
  }

  getNodeInfo(node: any): { label: string; value: any }[] {
    if (this.vizTypeParam === 'hha') {
      return this.visibleItems([
        { label: 'Provider NPI', value: node.npi },
        { label: 'Provider Name', value: node.prvdrNm },
        { label: 'Provider Total Payment', value: node.totalPymt },
        { label: 'Latest Alert Status', value: node.alertStatus },
        { label: 'Leads/Investigation Status', value: node.investigations },
        { label: 'Latest Alert Create Date', value: node.lastAlertDt },
        { label: 'Zone Restriction', value: node.zr },
      ]);
    }

    if (this.vizTypeParam === 'dme') {
      return this.visibleItems([
        { label: 'Provider NPI', value: node.npi },
        { label: 'Provider Name', value: node.prvdrNm },
        { label: 'Latest Alert Status', value: node.alertStatus },
        { label: 'Investigation/Case Status', value: node.investigations },
        { label: 'Lead Indicator', value: node.leadInd },
        { label: 'Latest Alert Create Date', value: node.lastAlertDt },
        { label: 'Zone Restriction', value: node.zr },
      ]);
    }

    return this.visibleItems([
      { label: 'Provider NPI', value: node.npi },
      { label: 'Provider Name', value: node.prvdrNm },
      { label: 'Provider Type', value: node.subjPrvdrRole },
      { label: 'Alert Cost', value: node.alertCstAmt },
    ]);
  }

  getEdgeInfo(edge: any): { label: string; value: any }[] {
    const clusterSize = edge.clstrSize ?? '';
    const edgeWeight = edge.weight ? `$${edge.weight}` : '';

    if (this.vizTypeParam === 'hha') {
      return this.visibleItems([
        { label: 'Total Payment Amount', value: edgeWeight },
        { label: '# of Shared Benes', value: clusterSize },
        { label: '% of Shared Benes', value: edge.subjPrvdrClstrPct },
      ]);
    }

    if (this.vizTypeParam === 'dme') {
      return this.visibleItems([
        { label: 'Total Paid Amount', value: edgeWeight },
        { label: '# of Shared Benes', value: clusterSize },
        { label: '% of Shared Benes', value: edge.subjPrvdrClstrPct },
      ]);
    }

    return this.visibleItems([
      { label: 'Related Provider NPI', value: edge.rltdPrvdrNpi },
      { label: 'Related Provider Name', value: edge.rltdNpiName },
      { label: 'Related Provider Type', value: edge.rltdPrvdrRole },
      { label: 'Subject Provider NPI', value: edge.subjPrvdrNpi },
      { label: 'Subject Provider Name', value: edge.subjNpiName },
      { label: 'Subject Provider Type', value: edge.subjPrvdrRole },
      { label: '# of Shared Benes', value: clusterSize },
      { label: '% of Shared Benes', value: edge.subjPrvdrClstrPct },
      {
        label: 'PECOS Relationship between Subject and Related Providers',
        value: edge.pecosRltnshp,
      },
      { label: 'Number of Total Related Providers', value: edge.rltdPrvdrNum },
      { label: 'Number of Suspect Related Providers', value: edge.badRltdPrvdrNum },
      { label: 'Percentage of Suspect Related Providers', value: edge.badRltdPrvdrPct },
    ]);
  }

  ngOnDestroy(): void {
    if (this.network) {
      this.network.destroy();
    }
  }
}
