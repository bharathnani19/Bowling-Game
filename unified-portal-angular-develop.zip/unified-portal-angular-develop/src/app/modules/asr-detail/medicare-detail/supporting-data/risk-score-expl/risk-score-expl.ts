import { Component, Input } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

import { OktaService } from '../../../../../services/okta';
import { ASR_RISK_EXPLAINABILITY_COLUMNS } from '../../../column-config';
import { AsrDetails, ContribScore } from '../../../model';
import { CommonDialogComponent } from '../../../../../shared/dialog/common-dialog/common-dialog';
import { ReportCardsComponent } from '../../current-records/report-cards/report-cards.component';

@Component({
  selector: 'app-risk-score-expl',
  templateUrl: './risk-score-expl.html',
  styleUrl: '../../../asr-detail.scss',
  standalone: false,

})
export class RiskScoreExplComponent {

  @Input() contribScores: ContribScore[] = [];
  @Input() riskScoreNum: string="";
  @Input() minRiskScoreInd: string="";
  @Input() minRiskScoreModelTxt: string="";
  @Input() asrDetails: AsrDetails | null = null;
  
  overallRiskScoreNum:string = "N/A";
  asrRiskColumns =  ASR_RISK_EXPLAINABILITY_COLUMNS.map((column: any) => ({ ...column }));
  
  asrRiskData:any;
 constructor(
    public dialog: MatDialog,
    public okta: OktaService,
  ) {}

  ngOnInit() {

    //this.updateOverallRiskScore();
   
  }
  updateOverallRiskScore(){
      var tempRskScoreNo = "N/A";
						
      if (this.riskScoreNum != null && !isNaN(parseFloat(this.riskScoreNum)) ) {
        let riskScoreNumVal = parseFloat(this.riskScoreNum);
        if(riskScoreNumVal > .99) {
          tempRskScoreNo = '> 0.99';
        } else if(riskScoreNumVal < 0.01) {
          tempRskScoreNo = '< 0.01';
        } else {
          tempRskScoreNo = parseFloat(this.riskScoreNum).toFixed(2);
        }
      }
      this.overallRiskScoreNum = tempRskScoreNo;
  }
  ngOnChanges (){
    this.updateOverallRiskScore();
  }
  getFooterText(): string {
    return 'Overall ASR Risk Score = ' + this.overallRiskScoreNum;
  }
    onViewReportCard( row: any) {
      row.type = 'medicare';
      row.npi = this.asrDetails?.provider?.npi;
     this.openTableDialog(
        {
          title: 'Report Cards',
          info: 'Report Cards provide the alert and model attribution details associated with the ASR ID. The report card layout and associated tables vary by model and model table; however, the report card section of the model guidance document associated with the select model provides further details regarding the displayed report card. To learn about the information and functions contained within the report card, hover over the information indicators below.',
          dialogId: 'reportCardsModal',
          componentData: {
            rowData: [row, this.asrDetails, 'medicare'],
          },
          panelClass: 'ip-dialog-panel',
          component: ReportCardsComponent,
          enableClose: true,
        },
        '80%',
      );
    }

      openTableDialog(data: any, width: string = '80%') {
        this.dialog.open(CommonDialogComponent, {
          width,
          data: {
            ...data,
          },
          panelClass: 'ip-dialog-panel',
        });
      }
}
