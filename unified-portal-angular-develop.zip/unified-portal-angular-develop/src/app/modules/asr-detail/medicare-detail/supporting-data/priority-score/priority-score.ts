import { Component, effect, Input } from '@angular/core';
import { PRIORITY_SCORE_COLUMNS } from '../../../column-config';
import { MatDialog } from '@angular/material/dialog';
import { AsrDetailsService } from '../../../../../services/asr-details.service';
import { LoaderService } from '../../../../../services/loader.service';
import { OktaService } from '../../../../../services/okta';
import { ToastService } from '../../../../../services/toaster.service';
import { AsrPriorityScore } from '../../../model';
import { environment } from '../../../../../environments/environment.shared';
import { User } from '../../../../../models/user.model';
import { allRoleTypes } from '../../../../../utilities/constants';
@Component({
  selector: 'app-priority-score',
  standalone: false,
  templateUrl: './priority-score.html',
  styleUrl: '../../../asr-detail.scss'
})
export class PriorityScoreComponent {

  @Input() asrId: string = "";
  providerCriteria:AsrPriorityScore[] = [];
  actionability:string="N/A";
  timeliness: string="N/A";
  priorityColumns = PRIORITY_SCORE_COLUMNS;
  postEdInd: string="N";
  priorityScoreNum: string="N/A";
  @Input() showUpicEduReport: string="N";
  hideFromMacs: boolean = false;
  user!:User;
  
 constructor(
    public dialog: MatDialog,
    private _detailsService: AsrDetailsService,
    private _loader: LoaderService,
    private _toaster: ToastService,
    public okta: OktaService,
  ) {
    effect(() => {
      this.user = this.okta.user();
    });
  }

  ngOnInit() {
    this.hideFromMacs= !!(
          this.user?.groups?.includes(allRoleTypes.ROLE_MAC) ||
          this.user?.groups?.includes(allRoleTypes.ZONE_MEDIC));
    
    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicare', 'prscore',this.asrId ?? '0')
      .subscribe({
        next: (res: any) => {
          this.providerCriteria = res?.responseData?.provider?.priorityCriteria || [];
          this.actionability = res?.responseData?.provider?.actionability;
          this.timeliness = res?.responseData?.provider?.timeliness;
          this.postEdInd = res?.responseData?.provider?.postEdInd;
          this.priorityScoreNum = res?.responseData?.provider?.priorityScoreNum;
          this._loader.hide();

        
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(
            `Error loading Priority Score data to ${err?.status || 'error'}`,
          );
        },
      });

     
   
  }
  openReportLink(report:string) {
    //trackUserActivity('RPTPE', null);
    let url:string = environment.tableauProviderEducation;
    if (report === 'Change in Ownership'){
      url = environment.tableauChow;
    }
    window.open(url + this.asrId);
  }

  isLinkableCriteria(value: any) {
    return value === 'Change in Ownership' || value === 'Prior Education';
  }
  getFooterText(): string {
    return 'Priority Score = ' + (this.priorityScoreNum === undefined ? "N/A" : this.priorityScoreNum);
  }
}
