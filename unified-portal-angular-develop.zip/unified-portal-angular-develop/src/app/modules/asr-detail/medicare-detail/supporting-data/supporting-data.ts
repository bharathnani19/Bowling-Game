import { Component, effect, input, Input, OnInit } from '@angular/core';

import { AsrDetails } from '../../model';

@Component({
  selector: 'supporting-data',
  templateUrl: './supporting-data.html',
  styleUrls: ['../../asr-detail.scss'],
  standalone: false,
})
export class SupportingDataComponent  {
  asrDetails =  input.required<AsrDetails | null>();
  selectedTabIndex: any;
  constructor() {
    effect(() => {
     this.setDefaultTab();
    });
  }
  ngOnChanges(){
    console.log("resetting setDefaultTab()");
    this.setDefaultTab();

  }
  setDefaultTab(){
     if (this.asrDetails()?.provider?.contribScores?.length === 0 ){
        this.selectedTabIndex = 1;
     } else{
      this.selectedTabIndex = 0;
     }
  }

}
