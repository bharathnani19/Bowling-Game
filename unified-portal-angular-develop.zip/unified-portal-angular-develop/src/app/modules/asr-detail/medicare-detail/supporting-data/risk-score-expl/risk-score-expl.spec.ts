import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RiskScoreExpl } from './risk-score-expl';

describe('RiskScoreExpl', () => {
  let component: RiskScoreExpl;
  let fixture: ComponentFixture<RiskScoreExpl>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RiskScoreExpl]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RiskScoreExpl);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
