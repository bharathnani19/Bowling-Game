import { Component, effect, Input } from '@angular/core';
import { TPE_COLUMNS } from '../../../column-config';
import { MatDialog } from '@angular/material/dialog';
import { User } from '../../../../../models/user.model';
import { AsrDetailsService } from '../../../../../services/asr-details.service';
import { LoaderService } from '../../../../../services/loader.service';
import { OktaService } from '../../../../../services/okta';
import { ToastService } from '../../../../../services/toaster.service';
import { allRoleTypes } from '../../../../../utilities/constants';
import { Tpe } from '../../../model';

@Component({
  selector: 'app-tpe',
  standalone: false,
  templateUrl: './tpe.html',
  styleUrl: './tpe.scss',
})
export class TpeComponent {
  tpeColumns = TPE_COLUMNS;

  @Input() asrId: string = "";
  tpes:Tpe[]=[];
  user!:User;
  
 constructor(
    public dialog: MatDialog,
    private _detailsService: AsrDetailsService,
    private _loader: LoaderService,
    private _toaster: ToastService,
    public okta: OktaService,
  ) {
    effect(() => {
      this.user = this.okta.user();
    });
  }

  ngOnInit() {
   
    
    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicare', 'tpe',this.asrId ?? '0')
      .subscribe({
        next: (res: any) => {
          this.tpes = res?.responseData?.tpes || [];
       
          this._loader.hide();

        
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(
            `Error loading TPE data to ${err?.status || 'error'}`,
          );
        },
      });

     
   
  }
}
