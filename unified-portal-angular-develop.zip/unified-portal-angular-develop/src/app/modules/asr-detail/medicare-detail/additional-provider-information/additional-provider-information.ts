import { Component, Input, OnInit } from '@angular/core';
import { AsrDetails, AsrProvider } from '../../model';
import { AsrDetailsService } from '../../../../services/asr-details.service';
import { OktaService } from '../../../../services/okta';
import { LoaderService } from '../../../../services/loader.service';
import { ToastService } from '../../../../services/toaster.service';
import {
  ASR_BILLING_NPIS_COLUMNS,
  ASR_CRIMINAL_SUMMARY_COLUMNS,
  ASR_ENROLLMENT_COLUMNS,
  ASR_EXTERNAL_MEDICAID_COLUMNS,
  ASR_PRIORITIZATION_SUMMARY_MEDICARE_COLUMNS,
  ASR_PROVIDER_ROLES_COLUMNS,
  ASR_PTAN_COLUMNS,
  ASR_RELATED_ASR_COLUMNS,
  ASR_SPECIALTY_COLUMNS,
  ASR_UNIQUE_ALERTS_COLUMNS,
  REVOCATION_COLUMNS,
} from '../../../asr-detail/column-config';
import { ASRDetailsTableComponent } from '../../asr-detail-table/asr-detail-table';
import { CommonDialogComponent } from '../../../../shared/dialog/common-dialog/common-dialog';
import { BiuSummaryComponent } from '../../../../shared/biu-summary/biu-summary';
import { ExternalMedicaidComponent } from '../../../../shared/external-medicaid/external-medicaid';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'additional-provider-information',
  templateUrl: './additional-provider-information.html',
  styleUrls: ['../../asr-detail.scss'],
  standalone: false,
})
export class AdditionalProviderInformationComponent implements OnInit {
  @Input() asrDetails!: AsrDetails | null;
  providerPaneObj?: AsrProvider;

  constructor(
    public okta: OktaService,
    public dialog: MatDialog,
    private _detailsService: AsrDetailsService,
    private _loader: LoaderService,
    private _toaster: ToastService,
  ) {}

  ngOnInit() {
    //this.providerPaneObj = this.asrDetails?.provider ;
  }

  openTableDialog(data: any, width: string = '80%') {
    this.dialog.open(CommonDialogComponent, {
      width,
      data: {
        ...data,
      },
      panelClass: 'ip-dialog-panel',
    });
  }

  openRevocationModal() {
    const revocationArray = [
      {
        revocationDate: this.asrDetails?.provider?.revocationDate,
        revocationDesc: this.asrDetails?.provider?.revocationDesc,
      },
    ];
    this.openTableDialog(
      {
        title: 'Revocations',
        dialogId: 'revocationsModal',
        componentData: {
          rowData: revocationArray,
          columns: REVOCATION_COLUMNS,
          tableName: 'Revocations Table',
          tableId: 'revocationsTable',
        },
        panelClass: 'ip-dialog-panel',
        component: ASRDetailsTableComponent,
         enableClose: true
      },
      //,
      //'90%',
    );
  }

  openPrioritizationPopup() {
    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicare', 'priority', this.asrDetails?.provider?.npi ?? 'none')
      .subscribe({
        next: (res: any) => {
          const priorities = res?.responseData?.priorities || [];
          this._loader.hide();

          this.openTableDialog(
            {
              title: 'Prioritized',
              info: "The below table displays the ASR's prioritization details including the user, jurisdiction, and prioritized date.",
              dialogId: 'prvdrPrioritizedModal',
              componentData: {
                rowData: priorities,
                columns: ASR_PRIORITIZATION_SUMMARY_MEDICARE_COLUMNS,
                tableName: 'Prioritization Table',
                tableId: 'prvdrPrioritizedTable',
              },
              panelClass: 'ip-dialog-panel',
              component: ASRDetailsTableComponent,
              enableClose: true
            },
            //,
            //'90%',
          );
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(
            `Unable to load ASR prioritization data to ${err?.status || 'error'}`,
          );
        },
      });
  }
  openNonAlertedPopup() {
    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('naps', 'naps', this.asrDetails?.provider?.npi ?? 'none')
      .subscribe({
        next: (res: any) => {
          const data = res?.responseData?.napParents || '';
          this._loader.hide();

          this.openTableDialog(
            {
              title: 'Associated Alerted Provider',
              info: "The table below displays the Associated Alerted Provider in which the Non-Alerting provider derived from. To view the associated alerted provider's ASR Details page, select the ASR ID.",
              dialogId: 'prvdrNonAlertModal',
              componentData: {
                rowData: data,
                columns: ASR_RELATED_ASR_COLUMNS,
                tableName: 'Non-Alerted ASRs Table',
                tableId: 'prvdrNonAlertTable',
              },
              panelClass: 'ip-dialog-panel',
              component: ASRDetailsTableComponent,
              enableClose: true

            },
            //,
            //'90%',
          );
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(
            `Unable to load ASR non-alerted provider data to ${err?.status || 'error'}`,
          );
        },
      });
  }

  openComplaintsPopup() {
    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicare', 'systags', this.asrDetails?.provider?.npi ?? '')
      .subscribe({
        next: (res: any) => {
          const data = res?.responseData?.biuSummary || '';
          this._loader.hide();

          this.openTableDialog(
            {
              title: 'Complaints (Total Number)',
              info: 'This table displays the total number of complaints reported by the Beneficiary Integrity Unit (BIU), the number of complaints reported by the BIU in the last 90 days and the BIU Summary.',
              dialogId: 'complaintsModal',
              componentData: {
                biuSummary: data.biuSummary,
                totalCnt: data.totalCnt,
                day90Cnt: data.day90Cnt,
              },
              panelClass: 'ip-dialog-panel',
              component: BiuSummaryComponent,
              enableClose: true

            },
            //,
            //'90%',
          );
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(`Unable to load ASR complaints data to ${err?.status || 'error'}`);
        },
      });
  }
  openRelatedAsrsPopup() {
    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicare', 'relatedAsrs', this.asrDetails?.provider?.npi ?? 'none')
      .subscribe({
        next: (res: any) => {
          const data = res?.responseData?.relatedAsrs || [];
          this._loader.hide();

          this.openTableDialog(
            {
              title: 'Related ASRs',
              info: "The table below displays the related ASR alerted providers based on claims data. Due to Part D models only alerting on prescribing providers, the Part D claims data will not be included in the related providers' logic. To view the related provider's ASR Details page, select the ASR ID.",
              dialogId: 'relatedAsrsModal',
              componentData: {
                rowData: data,
                columns: ASR_RELATED_ASR_COLUMNS,
                tableName: 'Related ASRs',
                tableId: 'relatedAsrsTable',
              },
              panelClass: 'ip-dialog-panel',
              component: ASRDetailsTableComponent,
              enableClose: true
            },
            //,
            //'90%',
          );
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(`Unable to load ASR related ASR data to ${err?.status || 'error'}`);
        },
      });
  }
  openExternalMedicaidPopup() {
    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicare', 'medicaid', this.asrDetails?.provider?.npi ?? 'none')
      .subscribe({
        next: (res: any) => {
          const data = res?.responseData?.provider?.medicaidInfo || {};
          this._loader.hide();

          this.openTableDialog(
            {
              title: 'Medicaid Details',
              dialogId: 'medicaidModal',
              componentData: {
                summaryData: data,
                columns: ASR_EXTERNAL_MEDICAID_COLUMNS,
                tableName: 'Medicaid Table',
                tableId: 'medicaidModalTable',
              },
              panelClass: 'ip-dialog-panel',
              component: ExternalMedicaidComponent,
              enableClose: true
            },
            //,
            //'90%',
          );
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(
            `Unable to load ASR external Medicaid data to ${err?.status || 'error'}`,
          );
        },
      });
  }
  openCriminalPopup() {
    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicare', 'aps', this.asrDetails?.provider?.npi ?? 'none')
      .subscribe({
        next: (res: any) => {
          const data = res?.responseData?.aps || [];
          this._loader.hide();

          this.openTableDialog(
            {
              title: 'Criminal Details',
              info: 'This table provides details of the crime (per APS data) committed by the provider or PECOS identified owner.',
              dialogId: 'criminalModal',
              componentData: {
                rowData: data,
                columns: ASR_CRIMINAL_SUMMARY_COLUMNS,
                tableName: 'Criminal Details',
                tableId: 'criminalTable',
              },
              panelClass: 'ip-dialog-panel',
              component: ASRDetailsTableComponent,
              enableClose: true
            },
            //,
            //'90%',
          );
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(
            `Unable to load ASR prioritization data to ${err?.status || 'error'}`,
          );
        },
      });
  }
  openBillingSummaryPopup() {
    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicare', 'billsumm', this.asrDetails?.provider?.npi ?? 'none')
      .subscribe({
        next: (res: any) => {
          const data = res?.responseData?.billSummary || [];
          this._loader.hide();

          this.openTableDialog(
            {
              title: 'Billing NPIs',
              info: "This table displays the Billing Provider NPIs corresponding to the associated ASR ID if the ASR's NPI is listed as the Rendering NPI, Attending NPI, or the same as the Billing NPI for claims at risk. The data contained within this table is updated from the last model run. If the Billing NPI is an ASR, the Jurisdiction displayed is the ASR UPIC Jurisdiction associated with claims at risk. If the Billing NPI is not an ASR, the Jurisdiction displayed is the UPIC Jurisdiction associated with all claims.",
              dialogId: 'medicareViewBillingNPIModal',
              componentData: {
                rowData: data,
                columns: ASR_BILLING_NPIS_COLUMNS,
                tableName: 'View Billing NPI Table',
                tableId: 'medicareViewBillingNPIModalTable',
              },
              panelClass: 'ip-dialog-panel',
              component: ASRDetailsTableComponent,
              enableClose: true
            },
            //,
            //'90%',
          );
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(
            `Unable to load ASR prioritization data to ${err?.status || 'error'}`,
          );
        },
      });
  }
  openProviderRolesPopup() {
    this.openTableDialog(
      {
        title: 'Roles',
        info: 'The below table displays the list of roles associated with the ASR ID based on claims at-risk data.',
        dialogId: 'prvdrRolesModal',
        componentData: {
          rowData: this.asrDetails?.provider?.subjectRoleCd,
          columns: ASR_PROVIDER_ROLES_COLUMNS,
          tableName: 'Provider Pane Roles Table',
          tableId: 'prvdrPaneRolesTable',
        },
        panelClass: 'ip-dialog-panel',
        component: ASRDetailsTableComponent,
        enableClose: true
      },
      //,
      //'90%',
    );
  }
  openPtansPopup() {
    this.openTableDialog(
      {
        title: 'PTANs',
        info: 'The below table displays the list of PTANs associated with the ASR ID.',
        dialogId: 'prvdrPtanModal',
        componentData: {
          rowData: this.asrDetails?.provider?.ptans,
          columns: ASR_PTAN_COLUMNS,
          tableName: 'Provider Pane PTAN Table',
          tableId: 'prvdrPanePtanTable',
        },
        panelClass: 'ip-dialog-panel',
        component: ASRDetailsTableComponent,
        enableClose: true
      },
      //,
      //'90%',
    );
  }
  openSpecialtiesPopup() {
    this.openTableDialog(
      {
        title: 'ASR Specialty',
        info: "The below table displays the specialty codes associated with the ASR ID's claims at risk.",
        dialogId: 'specialtiesModal',
        componentData: {
          rowData: this.asrDetails?.provider?.specialties,
          columns: ASR_SPECIALTY_COLUMNS,
          tableName: 'ASR Specialty',
          tableId: 'specialtiesTable',
        },
        panelClass: 'ip-dialog-panel',
        component: ASRDetailsTableComponent,
        enableClose: true
      },
      //,
      //'90%',
    );
  }
  openEnrollmentPopup() {
    this._loader.show();
    this.openTableDialog(
      {
        title: 'Associated Enrollment IDs',
        info: 'The below table displays the Enrollment IDs and Enrollment Status of enrollments associated to the ASR Id.',
        dialogId: 'enrollmentIdModal',
        componentData: {
          rowData: this.asrDetails?.provider?.enrollmentIds,
          columns: ASR_ENROLLMENT_COLUMNS,
          tableName: 'Enrollment ID Table',
          tableId: 'enrollmentIdModalTable',
        },
        panelClass: 'ip-dialog-panel',
        component: ASRDetailsTableComponent,
        enableClose: true
      },
      //,
      //'90%',
    );
    this._loader.hide();
  }
  openUniqueAlertsPopup() {
    this.openTableDialog(
      {
        title: 'Unique Alerts',
        info: 'The below table displays a list of models that alerted for the ASR ID.',
        dialogId: 'prvdrPrioritizedModel',
        componentData: {
          rowData: this.asrDetails?.provider?.alerts,
          columns: ASR_UNIQUE_ALERTS_COLUMNS,
          tableName: 'Unique Alerts',
          tableId: 'prvdrPrioritizedTable',
        },
        panelClass: 'ip-dialog-panel',
        component: ASRDetailsTableComponent,
        enableClose: true
      },
      //,
      //'90%',
    );
  }
}
