import { Component, Input, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
  Validators,
} from '@angular/forms';
import {
  FileUploadService,
  OpenClaimsDocumentParams,
} from '../../../../../services/file-upload.service';
import { LoaderService } from '../../../../../services/loader.service';
import { ToastService } from '../../../../../services/toaster.service';
import { dateRangeLastOneYearValidator, dateRangeValidator } from '../../../../../utilities/utils';

@Component({
  selector: 'app-claims',
  templateUrl: './claims.html',
  styleUrls: ['./claims.scss', '../../../asr-detail.scss'],
  standalone: false,
})
export class ClaimsComponent implements OnInit {
  @Input() asrDetails: any;

  form!: FormGroup;
  submitted: boolean = false;
  disablephase1CostSrchBtn = false;
  disablephase1ClmSrchBtn = false;
  disableRrbSrchBtn = false;
  disablePartDSrchBtn = false;
  disablePartDLatestBtn = false;
  disableClmSrchBtn = false;
  disableAtRiskBtn = false;
  disableLatestClmBtn = false;

  disablePartA = false;
  disablePartB = false;
  disablePartD = false;
  disableDme = false;

  constructor(
    protected fb: FormBuilder,
    protected _fileUplaodService: FileUploadService,
    protected _loader: LoaderService,
    protected _toaster: ToastService,
  ) {}

  ngOnInit(): void {
    this.buildForm();
    this.initializeDisableFlags();
    this.hideShowClaimCheckVals('allClaimsVal');
  }

  protected buildForm(): void {
    this.form = this.fb.group(
      {
        radioResult: ['allClaimsVal'],

        partA: [false],
        partB: [false],
        partD: [false],
        dme: [false],

        startDate: [''],
        endDate: [''],
        beneficiaries: ['', this.maxLinesValidator(50, 'hicnlineserror')],
        diagnosis: ['', this.maxLinesValidator(50, 'diaglineserror')],
        hcpcs: ['', this.maxLinesValidator(50, 'hcpcserror')],
        icd: ['', this.maxLinesValidator(50, 'icderror')],
      },
      {
        validators: [
          this.claimTypeValidator(),
          dateRangeValidator('startDate', 'endDate', 'isDateValid'),
          dateRangeLastOneYearValidator('startDate', 'endDate', 'isOneYearRangeDateValid'),
        ],
      },
    );

    this.form.get('partA')?.valueChanges.subscribe(() => this.checkClaimType());
    this.form.get('partB')?.valueChanges.subscribe(() => this.checkClaimType());
    this.form.get('partD')?.valueChanges.subscribe(() => this.checkClaimType());
    this.form.get('dme')?.valueChanges.subscribe(() => this.checkClaimType());
  }

  protected initializeDisableFlags(): void {
    const claims = this.asrDetails?.availableClaims ?? {};
    const claimTypes: string[] = this.asrDetails?.claimTypes ?? [];
    const provider = this.asrDetails?.provider ?? this.asrDetails?.providerPaneObj ?? {};

    this.disablephase1ClmSrchBtn = claims.atRiskP1Ind === 'N';
    this.disablephase1CostSrchBtn = claims.asrCostP1Ind === 'N';

    const hasA = claimTypes.includes('A');
    const hasB = claimTypes.includes('B');
    const hasD = claimTypes.includes('D');
    const hasDME = claimTypes.includes('DME');

    if (!hasA && !hasB && !hasD && !hasDME) {
      this.disableAtRiskBtn = true;
      this.disableLatestClmBtn = true;
      this.disableClmSrchBtn = true;
    } else if (!hasA && !hasB && !hasDME && hasD) {
      this.disableAtRiskBtn = true;
    }

    if (this.asrDetails.availableClaims.latestInd == 'Y') {
      // enable the Latest Claims button
      this.disableLatestClmBtn = false;
    } else {
      // disable the Latest Claims button
      this.disableLatestClmBtn = true;
    }

    if (!hasD) {
      this.disablePartDSrchBtn = true;
      this.disablePartDLatestBtn = true;
    }
    if (this.asrDetails.availableClaims.latestDInd == 'Y') {
      // enable the Part D Latest Claims button
      this.disablePartDLatestBtn = false;
    } else {
      // disable the Part D Latest Claims button
      this.disablePartDLatestBtn = true;
    }

    if (provider.hasRrb === 'N') {
      this.disableRrbSrchBtn = true;
    }
  }

  hideShowClaimCheckVals(radioType: string): void {
    const claims = this.asrDetails?.availableClaims ?? {};

    this.form.patchValue(
      {
        partA: false,
        partB: false,
        partD: false,
        dme: false,
      },
      { emitEvent: false },
    );

    if (radioType === 'allClaimsVal') {
      this.disablePartA = claims.allClaimsInd !== 'Y';
      this.disablePartB = claims.allClaimsInd !== 'Y';
      this.disableDme = claims.allClaimsInd !== 'Y';
      this.disablePartD = claims.allClaimsDInd !== 'Y';
    } else if (radioType === 'claimsAtRiskVal') {
      this.disablePartA = claims.atRiskInd !== 'Y';
      this.disablePartB = claims.atRiskInd !== 'Y';
      this.disableDme = claims.atRiskInd !== 'Y';
      this.disablePartD = claims.atRiskDInd !== 'Y';
    } else {
      this.disablePartA = false;
      this.disablePartB = false;
      this.disableDme = false;
      this.disablePartD = true;
    }

    this.disableClmSrchBtn =
      this.disablePartA && this.disablePartB && this.disableDme && this.disablePartD;

    this.applyClaimTypeDisableStates();
    this.updateDependentTextFields();
    this.form.markAsDirty();
    this.form.updateValueAndValidity();
  }

  checkClaimType(): void {
    const partA = this.form.get('partA')?.value === true;
    const partB = this.form.get('partB')?.value === true;
    const partD = this.form.get('partD')?.value === true;
    const dme = this.form.get('dme')?.value === true;
    const radio = this.form.get('radioResult')?.value;

    if (partD) {
      this.disablePartA = true;
      this.disablePartB = true;
      this.disableDme = true;
    } else if (partA || partB || dme) {
      this.disablePartD = true;
    } else {
      this.hideShowClaimCheckVals(radio);
      return;
    }

    this.applyClaimTypeDisableStates();
    this.updateDependentTextFields();
    this.form.updateValueAndValidity();
  }

  protected updateDependentTextFields(): void {
    const partA = this.form.get('partA')?.value === true;
    const partB = this.form.get('partB')?.value === true;
    const partD = this.form.get('partD')?.value === true;
    const dme = this.form.get('dme')?.value === true;
    const radio = this.form.get('radioResult')?.value;

    const disableDiagnosis =
      (partA && !partB && !dme && !partD) || (partD && !partB && !dme && !partA);

    const disableHcpcs = partD && !partB && !dme && !partA;

    const disableIcd = radio === 'phase1Claims' || (!partA && (partB || dme || partD));

    this.setControlDisabled('diagnosis', disableDiagnosis);
    this.setControlDisabled('hcpcs', disableHcpcs);
    this.setControlDisabled('icd', disableIcd);
  }

  protected applyClaimTypeDisableStates(): void {
    this.setControlDisabled('partA', this.disablePartA);
    this.setControlDisabled('partB', this.disablePartB);
    this.setControlDisabled('partD', this.disablePartD);
    this.setControlDisabled('dme', this.disableDme);
  }

  protected setControlDisabled(controlName: string, disabled: boolean): void {
    const control = this.form.get(controlName);
    if (!control) return;

    if (disabled) {
      control.disable({ emitEvent: false });
    } else {
      control.enable({ emitEvent: false });
    }
  }

  resetForm(): void {
    this.form.reset(
      {
        radioResult: 'allClaimsVal',
        partA: false,
        partB: false,
        partD: false,
        dme: false,
        startDate: '',
        endDate: '',
        beneficiaries: '',
        diagnosis: '',
        hcpcs: '',
        icd: '',
      },
      { emitEvent: false },
    );
    this.submitted = false;

    this.hideShowClaimCheckVals('allClaimsVal');
    this.form.markAsPristine();
    this.form.markAsUntouched();
    this.form.updateValueAndValidity();
  }

  get isSearchDisabled(): boolean {
    if (!this.form) {
      return true;
    }

    const selectedRadio = this.form.get('radioResult')?.value;
    const claims = this.asrDetails?.availableClaims ?? {};

    if (selectedRadio === 'phase1Claims') {
      return claims.atRiskP1Ind === 'N';
    }

    return this.disablePartA && this.disablePartB && this.disableDme && this.disablePartD;
  }

  get today() {
    const date = new Date();
    return date.toISOString().split('T')[0];
  }

  getParams(pType: string): OpenClaimsDocumentParams {
    return {
      asrId: this.asrDetails.asrDbId,
      fileName: this.asrDetails.provider.providerName + '_' + this.today + '_claimsExport.csv',
      modelId: '',
      npi: this.asrDetails.provider.npi,
      pType,
    };
  }

  protected export(type: string): void {
    this._loader.show();
    const params = {};
    this._fileUplaodService.downloadClaimsDocument(this.getParams(type)).subscribe({
      next: (res: any) => {
        this._loader.hide();
      },
      error: (err: any) => {
        this._loader.hide();
        this._toaster.error('Unable to download document due to ' + err.status);
      },
    });
  }

  protected exportLatest(type: string, isSubmit: boolean = false): void {
    if (isSubmit) {
      this.submitted = true;
    }

    if (isSubmit && this.form.invalid) {
      this.form.markAllAsTouched();
      this._toaster.error('Please update all invalid form fields.');
      return;
    }

    this._loader.show();

    const formValue = this.form.getRawValue();

    let payload: any;

    if (!isSubmit) {
      payload = {
        npi: this.asrDetails.provider.npi,
        fromDt: null,
        toDt: null,
        claimTypes: null,
        hicns: null,
        latest: type === 'latest' ? 'Y' : 'N',
        rrb: type === 'rrb' ? 'Y' : 'N',
        latestD: type === 'latestD' ? 'Y' : 'N',
      };
    } else {
      payload = {
        npi: this.asrDetails.provider.npi,
        asrptId: this.asrDetails.asrDbId,
        fromDt: formValue.startDate || null,
        toDt: formValue.endDate || null,
        claimTypes: null,
        hicns: null,
        hcpcses: null,
        procedures: null,
        diagnosises: null,
        latest: 'N',
        rrb: 'N',
        latestD: 'N',
        searchType: null,
      };

      if (formValue.radioResult === 'allClaimsVal') {
        payload.searchType = formValue.partD ? 'PARTDRAW' : 'RAW';
      } else if (formValue.radioResult === 'claimsAtRiskVal') {
        payload.searchType = formValue.partD ? 'PARTDALERTED' : 'ALERTED';
      } else if (formValue.radioResult === 'phase1Claims') {
        payload.searchType = 'P1ALERTED';
      }

      const claimTypes: any[] = [];

      if (formValue.partA) claimTypes.push({ code: 'A' });
      if (formValue.partB) claimTypes.push({ code: 'B' });
      if (formValue.partD) claimTypes.push({ code: 'D' });
      if (formValue.dme) claimTypes.push({ code: 'DME' });

      payload.claimTypes = claimTypes.length ? claimTypes : null;
      payload.hcpcses = this.convertToCodeArray(formValue.hcpcs);
      payload.procedures = this.convertToCodeArray(formValue.icd);
      payload.diagnosises = this.convertToCodeArray(formValue.diagnosis);
      payload.hicns = this.convertToHicnArray(formValue.beneficiaries, 'beneficiaries');
    }

    this._fileUplaodService.downloadClaimsDocPost(this.getParams('latest'), payload).subscribe({
      next: () => {
        this._loader.hide();
      },
      error: (err: any) => {
        this._loader.hide();
        this._toaster.error('Unable to download document due to ' + err.status);
      },
    });
  }

  protected convertToHicnArray(value: string, label: string): any[] | null {
    if (!value?.trim()) {
      return null;
    }

    const lines = value
      .split('\n')
      .map((x: string) => x.trim())
      .filter(Boolean);

    if (lines.length > 50) {
      this._toaster.error(`Maximum 50 ${label} allowed`);
      return null;
    }

    return lines.map((hicn: string) => ({
      hicn,
    }));
  }

  protected convertToCodeArray(value: string): any[] | null {
    if (!value?.trim()) {
      return null;
    }

    const lines = value
      .split('\n')
      .map((x: string) => x.trim())
      .filter(Boolean);

    if (lines.length > 50) {
      this._toaster.error('Maximum 50 entries allowed');
      return null;
    }

    return lines.map((code: string) => ({
      code,
    }));
  }

  protected claimTypeValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const group = control as FormGroup;
      const partA = group.get('partA')?.value === true;
      const partB = group.get('partB')?.value === true;
      const partD = group.get('partD')?.value === true;
      const dme = group.get('dme')?.value === true;

      return partA || partB || partD || dme ? null : { claimTypeRequired: true };
    };
  }

  protected maxLinesValidator(maxLines: number, errorKey: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = control.value;

      if (!value) return null;

      const lines = String(value)
        .split(/\r?\n/)
        .map((x) => x.trim())
        .filter(Boolean);

      return lines.length > maxLines ? { [errorKey]: true } : null;
    };
  }
}
