import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Edits } from './edits';

describe('Edits', () => {
  let component: Edits;
  let fixture: ComponentFixture<Edits>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Edits]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Edits);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
