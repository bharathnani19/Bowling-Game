import { Component, Input, OnInit } from '@angular/core';
import { LEADS_INVESTIGATIONS_COLUMNS, MEDICAID_LEADS_COLUMNS } from '../../../column-config';
import { MatDialog } from '@angular/material/dialog';
import { AsrDetailsService } from '../../../../../services/asr-details.service';
import { LoaderService } from '../../../../../services/loader.service';
import { ToastService } from '../../../../../services/toaster.service';
import { ModelDetailDialogComponent } from '../../../../../shared/dialog/model-detail/model-detail';
import { HomePageService } from '../../../../../services/homepage.service';
import { CommonDialogComponent } from '../../../../../shared/dialog/common-dialog/common-dialog';
import { ASRDetailsTableComponent } from '../../../asr-detail-table/asr-detail-table';
import { OktaService } from '../../../../../services/okta';
import { environment } from '../../../../../environments/environment.shared';
import { LeadDetailComponent } from './lead-detail/lead-detail.component';
@Component({
  selector: 'app-leads',
  templateUrl: './leads.html',
  standalone: false,
})
export class LeadsComponent implements OnInit {
  @Input() asrId: string = '';
  @Input() type: string = '';
  leadsInvColumns: any[] = [];

  asrLeadData: any[] = [];
  activeEditInfos: any[] = [];
  inactiveEditInfos: any[] = [];

  constructor(
    public dialog: MatDialog,
    private _detailsService: AsrDetailsService,
    private _loader: LoaderService,
    private _toaster: ToastService,
    public okta: OktaService,
  ) {}

  ngOnInit() {
    this._loader.show();
    this.leadsInvColumns =
      this.type === 'medicare' ? LEADS_INVESTIGATIONS_COLUMNS : MEDICAID_LEADS_COLUMNS;
    this.updateLeadsData();
  }
  updateLeadsData(){
    this._detailsService.getAsrDetailsChildData(this.type, 'leads', this.asrId ?? '0').subscribe({
      next: (res: any) => {
        this.asrLeadData = res?.responseData?.leads || [];
        this._loader.hide();
      },
      error: (err: any) => {
        this._loader.hide();
        this._toaster.error(`Error loading Leads data to ${err?.status || 'error'}`);
      },
       });
  }
  ngOnChanges(){
    console.log("refreshing leads data");
    this.updateLeadsData();
  }
  getLeadId(row: any): string {
    return row?.ucmId || row?.id || '';
  }

  shouldShowLeadLink(row: any): boolean {
    const macUser = this.okta.user().macUser;

    if (row?.ucmId) {
      const invType = row.ucmId.substring(0, 3);

      if (macUser) {
        return invType === 'MPP';
      }

      return true;
    }

    return !macUser;
  }

  viewLead(row: any): void {
    const leadId = this.getLeadId(row);

    if (!leadId) {
      return;
    }

    this.dialog.open(CommonDialogComponent, {
      width: '60%',
      data: {
        title: 'UCM Case Record Information',
        info: 'The table below displays case details associated with the selected UCM Case ID.',
        dialogId: 'Leads Detail Model',
        componentData: {
          rowData: row,
        },
        panelClass: 'ip-dialog-panel',
        component: LeadDetailComponent,
        enableClose: true,
      },
    });
  }
}
