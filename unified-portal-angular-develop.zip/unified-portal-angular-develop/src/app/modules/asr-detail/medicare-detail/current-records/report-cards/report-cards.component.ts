import { Component, Inject, OnInit, signal } from '@angular/core';
import { AsrDetailsService } from '../../../../../services/asr-details.service';
import { LoaderService } from '../../../../../services/loader.service';
import { ToastService } from '../../../../../services/toaster.service';
import { environment } from '../../../../../environments/environment.shared';
import {
  PREDICTIVE_REPORT_CARD_COLUMNS,
  PREDICTIVE_REPORT_CARD_COLUMNS_MDCD,
  REPORT_CARD_COLUMNS,
  REPORT_CARD_COLUMNS_MDCD,
  SNA_REPORT_CARD_COLUMNS,
  SNA_REPORT_CARD_COLUMNS_MDCD,
  ERS_REPORT_CARD_COLUMNS,
} from '../../../column-config';
import { OktaService } from '../../../../../services/okta';
import { FileUploadService } from '../../../../../services/file-upload.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'report-cards',
  templateUrl: './report-cards.component.html',
  styleUrls: ['../../../asr-detail.scss'],
  standalone: false,
  styles: [
    `
      ::ng-deep .report-card {
        max-height: calc(100vh - 290px);
        scrollbar-width: thin;
      }

      .mat-mdc-button-disabled {
        cursor: not-allowed !important;
        background-color: #a8a8a8 !important;
      }
    `,
  ],
})
export class ReportCardsComponent implements OnInit {
  asrType: any;
  reportCardPopupData: any;

  hidefromMacs: boolean = false;

  rowData: any;
  asrDetail: any;
  showMppINV: boolean = true;
  ucmData: any;
  customTables = signal<any[]>([]);
  customVizTables = signal<any[]>([]);
  isRuleBased = false;
  isPredictive = false;
  isSna = false;
  isMedicare = false;
  viewReportCardAsML = false;
  customvizImgSrc!: string;
  customvizImgType!: string;
  customVizTablesImageArray: any;

  constructor(
    @Inject('componentData') public data: any,
    private _detailsService: AsrDetailsService,
    private _loader: LoaderService,
    private _toaster: ToastService,
    private _okta: OktaService,
    private _fileService: FileUploadService,
    private route: ActivatedRoute,
  ) {
    this.rowData = this.data?.rowData[0] || {};
    this.asrDetail = this.data?.rowData[1] || {};
    this.asrType = this.data?.rowData[2] || '';
    this.hidefromMacs = !!this._okta.user().macUser;
    this.isMedicare = this.asrType === 'medicare';
  }

  selectedTabIndex = 0;
  reportCardData: any[] = [];
  riskScoreRCData: any[] = [];
  showEnhancedTab = false;
  isReportCardReady = false;
  reportCardTableKey = 0;
  reportCardColumns: any[] = [];
  enhancedTabColumns = ERS_REPORT_CARD_COLUMNS;

  private mapCustomTableData(tables: any[]): any[] {
    return (tables || []).map((table: any) => {
      const columns = (table.columns || []).map((col: any) => ({
        key: String(col.columnIndex),
        label: col.columnName,
        visible: true,
        sortable: false,
      }));

      const data = (table.dataRows || []).map((row: any) => {
        const rowObj: any = {};

        (row.data || []).forEach((cell: any) => {
          rowObj[String(cell.columnIndex)] = cell.columnData;
        });

        return rowObj;
      });

      return {
        ...table,
        columns,
        data,
      };
    });
  }
  private mapTableData(data: any[], columns: any[]): any[] {
    return (data || []).map((row: any) => {
      const mappedRow: any = {};

      columns.forEach((col: any) => {
        mappedRow[col.key] = row[col.key] ?? '';
      });

      return mappedRow;
    });
  }
  private applyReportCardColumnRules(columns: any[], res: any): any[] {
    const hasMac = String(res?.hasMac ?? '')
      .trim()
      .toUpperCase();
    const partDClaimInd = String(res?.partDClaimInd ?? '')
      .trim()
      .toUpperCase();
    const activeType = String(this.rowData?.type || '')
      .trim()
      .toLowerCase();

    const hiddenKeys = new Set<string>();

    if (activeType === 'medicare') {
      hiddenKeys.add('mdcdId');
      hiddenKeys.add('state');
    }

    if (!hasMac || hasMac === 'N') {
      hiddenKeys.add('macMed');
      hiddenKeys.add('macPctl');
    }

    if (partDClaimInd === 'Y') {
      hiddenKeys.add('zoneMed');
      hiddenKeys.add('macMed');
      hiddenKeys.add('provderZoneRank');
      hiddenKeys.add('macPctl');
    }

    return columns.filter((col: any) => !hiddenKeys.has(col.key));
  }
  private getBaseReportCardColumns(): any[] {
    const modelTypeCd = String(this.rowData?.modelTypeCd || '');
    const isMedicaid = String(this.rowData?.type || '') === 'medicaid';

    if (this.viewReportCardAsML || modelTypeCd === '3') {
      const columns = isMedicaid
        ? PREDICTIVE_REPORT_CARD_COLUMNS_MDCD
        : PREDICTIVE_REPORT_CARD_COLUMNS;
      return columns.map((column: any) => ({ ...column }));
    }

    if (modelTypeCd === '4') {
      const columns = isMedicaid ? SNA_REPORT_CARD_COLUMNS_MDCD : SNA_REPORT_CARD_COLUMNS;
      return columns.map((column: any) => ({ ...column }));
    }

    const columns = isMedicaid ? REPORT_CARD_COLUMNS_MDCD : REPORT_CARD_COLUMNS;
    return columns.map((column: any) => ({ ...column }));
  }

  get selectedReportCardRow(): any {
    if (this.isRuleBased) return this.reportCardPopupData?.ruleBased?.[0];
    if (this.isSna) return this.reportCardPopupData?.socNet?.[0];
    if (this.isPredictive) return this.reportCardPopupData?.predictive?.[0];

    return null;
  }

  get showReportCardHeader(): boolean {
    return this.isRuleBased || this.isSna || this.isPredictive;
  }

  get modelAttributeButtonId(): string {
    if (this.isSna) return 'modAttrSnaBtn';
    if (this.isPredictive) return 'modAttrPredictBtn';
    return 'modAttrRuleBasedBtn';
  }

  private getReportCardRows(res: any): any[] {
    const modelTypeCd = String(this.rowData?.modelTypeCd || '');

    if (modelTypeCd === '5') {
      this.isRuleBased = true;

      return res.ruleBased || [];
    }

    if (modelTypeCd === '3') {
      this.isPredictive = true;

      return res.predict || [];
    }

    if (['6', '7', '8'].includes(modelTypeCd)) {
      return res.aaMulti || [];
    }

    if (modelTypeCd === '4') {
      this.isSna = true;
      return res.socNet || [];
    }

    return [];
  }

  showPrvdrEduAttrReport() {
    const url = environment.tableauProviderEduAttr + this.reportCardPopupData?.ruleBased[0]?.npi;
    window.open(url);
  }

  showAttrComparisonRpt() {
    const url = environment.tableauModelAttr + this.reportCardPopupData?.ruleBased[0]?.npi;
    window.open(url);
  }

  loadDocument(filename: any) {
    this._loader.show();
    this._fileService.downloadLegacyDocument(this.reportCardPopupData?.docUrl).subscribe({
      next: (res: any) => {
        this._loader.hide();
      },
      error: (err: any) => {
        this._loader.hide();
        this._toaster.error(
          'Unable to download ' + this.reportCardPopupData?.docUrl + ' due to ' + err.status + '.',
        );
      },
    });
  }

  drillExport(row: any): void {
    const fileName = 'alert-claims-export';
    const userId = this._okta.user()?.oktaDetails?.preferred_username ?? '';
    const type =
      String(this.reportCardPopupData?.partDClaimInd ?? '')
        .trim()
        .toUpperCase() === 'Y'
        ? 'claimsd'
        : 'claims';
    const programType: 'medicare' | 'medicaid' =
      String(this.rowData?.type ?? '').toLowerCase() === 'medicaid' ? 'medicaid' : 'medicare';

    const modelId = String(this.rowData?.modelId ?? row?.modelId ?? '').trim();
    const attrNum = String(row?.attrSqncNum ?? row?.attrNum ?? '').trim();
    const state =
      programType === 'medicaid'
        ? String(
            row?.mdcdState ?? row?.state ?? this.rowData?.mdcdState ?? this.rowData?.state ?? '',
          ).trim()
        : '';

    if (!modelId || !attrNum || (programType === 'medicaid' && !state)) {
      this._toaster.error('Unable to download alert-claims-export due to missing drill details.');
      return;
    }

    this._loader.show();

    const params = {
      asrId: row.asrptId,
      userId,
      type,
      fileName,
      npi: String(row?.npi ?? this.rowData?.npi ?? '').trim(),
      modelId,
      state,
      attrNum,
      programType,
    };

    this._fileService.downloadDrillReport(params).subscribe({
      next: (res: any) => {
        this._loader.hide();
      },
      error: (err: any) => {
        this._loader.hide();
        this._toaster.error('Unable to download alert-claims-export due to ' + err.status + '.');
      },
    });
  }

  initVizTabData(tab: any) {
    this._detailsService
      .getVizReportCardData({
        modelId: tab.modelBusnsId,
        npi: this.rowData.npi,
        tableId: tab.tableId,
        isMedicare: this.isMedicare,
        state: this.rowData?.state,
      })
      .subscribe({
        next: (res: any) => {
          this.customVizTablesImageArray = res.customVizTables[0];

          this.customvizImgSrc = this.customVizTablesImageArray.dataRows[0].data[0].columnImgSrc;
          this.customvizImgType =
            this.customVizTablesImageArray.dataRows[0].data[0].columnImgSrcType;
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error('Unable to load Viz Report Cards due to ' + err.status);
        },
      });
  }

  ngOnInit() {
    this._loader.show();
    this._detailsService.getReportCards(this.rowData).subscribe({
      next: (res: any) => {
        this.reportCardPopupData = res;
        const baseColumns = this.getBaseReportCardColumns();

        this.reportCardColumns = this.applyReportCardColumnRules(baseColumns, res);

        this.reportCardData = this.mapTableData(
          this.getReportCardRows(res),
          this.reportCardColumns,
        );

        this.getReportCardRows(res).forEach((o, i) => {
          this.reportCardData[i].attrSqncNum = o.attrSqncNum;
          this.reportCardData[i].modelId = o.modelId;
          this.reportCardData[i].npi = o.npi;
          this.reportCardData[i].mdcdState = o.mdcdState;
        });

        this.reportCardTableKey++;
        this.customTables.set(this.mapCustomTableData(res.customTables || []));
        this.customVizTables.set(this.mapCustomTableData(res.customVizTables || []));

        this.riskScoreRCData = res.riskScoreRC || [];
        this.showEnhancedTab = this.riskScoreRCData.length > 0;

        this.selectedTabIndex = 0;
        this.isReportCardReady = true;
        this._loader.hide();
      },
      error: (err: any) => {
        this._loader.hide();
        this._toaster.error('Unable to Report Cards due to ' + err.status);
      },
    });
    const value = this.route.snapshot.queryParamMap.get('viewReportCardAsML');
    this.viewReportCardAsML = value === 'true';
  }
  //   trackUserActivity('BPMINVEST', null);
}
