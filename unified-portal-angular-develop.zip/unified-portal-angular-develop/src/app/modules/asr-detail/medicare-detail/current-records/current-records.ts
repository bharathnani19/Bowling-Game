import { Component, Inject, Input, OnChanges, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import {
  ALERTS_COLUMNS_MDCR,
  PHASE1_ALERTS_COLUMNS,
  EDITS_COLUMNS,
  LEADS_INVESTIGATIONS_COLUMNS,
  MODEL_GUIDANCE_COLUMNS,
  ALERT_DLG_COLUMNS,
  PHASE1_ALERT_DLG_COLUMNS,
} from '../../column-config';
import { AsrDetails } from '../../model';
import { MatDialog } from '@angular/material/dialog';
import { CommonDialogComponent } from '../../../../shared/dialog/common-dialog/common-dialog';
import { ASRDetailsTableComponent } from '../../asr-detail-table/asr-detail-table';
import { FileUploadService } from '../../../../services/file-upload.service';
import { LoaderService } from '../../../../services/loader.service';
import { ToastService } from '../../../../services/toaster.service';
import { AsrDetailsService } from '../../../../services/asr-details.service';
import { ReportCardsComponent } from './report-cards/report-cards.component';
import { AsrGoogleMapModalComponent } from '../../asr-google-map-modal/asr-google-map-modal';
import { VisualizationDialogComponent } from '../../visualization/visualization';

@Component({
  selector: 'current-records',
  templateUrl: './current-records.html',
  styleUrls: ['../../asr-detail.scss'],
  standalone: false,
})
export class CurrentRecordsComponent implements OnChanges {
  @Input() asrDetails: AsrDetails | null = null;

  constructor(
    public dialog: MatDialog,
    private _fileService: FileUploadService,
    private _loader: LoaderService,
    private _toaster: ToastService,
    private _detailsService: AsrDetailsService,
  ) {}
  alertColumns = ALERTS_COLUMNS_MDCR.map((column: any) => ({ ...column }));
  p1AlertColumns = PHASE1_ALERTS_COLUMNS.map((column: any) => ({ ...column }));
  editColumns = EDITS_COLUMNS.map((column: any) => ({ ...column }));
  leadsInvColumns = LEADS_INVESTIGATIONS_COLUMNS.map((column: any) => ({ ...column }));
  selectedTabIndex: any;
  asrLeadsData: any;

  ngOnChanges() {
    if (
      this.asrDetails?.masterAlert.length == 0 &&
      this.asrDetails?.currentP1Alert.length == 0 &&
      this.asrDetails?.hasInv == 'Y'
    ){
      this.selectedTabIndex = 4;
    }
    if (this.asrDetails?.masterAlert && this.asrDetails?.masterAlert.length > 0){
       this.selectedTabIndex = 0;

    }else if (this.asrDetails?.currentP1Alert && this.asrDetails?.currentP1Alert.length > 0)
    {
      this.selectedTabIndex = 1;
    }
  }

  openTableDialog(data: any, width: string = '80%') {
    this.dialog.open(CommonDialogComponent, {
      width,
      data: {
        ...data,
      },
      panelClass: 'ip-dialog-panel',
    });
  }
  openModelMap(row: any) {
    this.dialog.open(AsrGoogleMapModalComponent, {
      autoFocus: false,
      restoreFocus: true,
      width: '80%',
      maxWidth: '100%',
      panelClass: 'ip-dialog-panel',
      data: {
        asrptId: row.asrptId,
        modelId: row.modelId,
        modelMode: true,
        providerAddr: this.asrDetails?.provider.address,
      },
    });
  }
  openModels(row: any) {
    this.openTableDialog(
      {
        title: 'Models',
        info: "This table displays the selected model's details. To obtain an available Model Guidance document, select the model name hyperlink.",
        dialogId: 'modalsModal',
        componentData: {
          rowData: [row?.models],
          columns: MODEL_GUIDANCE_COLUMNS,
          tableName: 'Models Table',
          tableId: 'ModalsTable',
          componentId: 'Modals',
        },
        panelClass: 'ip-dialog-panel',
        component: ASRDetailsTableComponent,
        enableClose: true,
      },
      '80%',
    );
  }

  onExportClaimLines(row: any) {
    this._loader.show();
    this._fileService
      .downloadClaimsDocument({
        asrId: `${this.asrDetails?.asrDbId}`,
        npi: `${this.asrDetails?.asrDbId}`,
        modelId: row.alertId,
        fileName: 'alert-claims-export.csv',
        pType: row.partDClaimInd,
      })
      .subscribe({
        next: (res: any) => {
          this._loader.hide();
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error('Unable to download document due to ' + err.status);
        },
      });
  }

  onViewAlerts(row: any, alertType: 'alerts' | 'p1Alerts') {
    row.alerts = row.alerts?.map((alert: any) => ({
      ...alert,
      asrDbId: row.asrptId,
      modelId: row?.models?.modelId,
    }));
    const columns = alertType === 'p1Alerts' ? PHASE1_ALERT_DLG_COLUMNS : ALERT_DLG_COLUMNS;
    const title = 'Alerts Model – ' + row.modelBusnsId;
    this.openTableDialog(
      {
        title: title,
        info: 'The table below provides the details associated with each alert, or each time the ASR ID was identified during a model run. To learn about the information contained within the table below, hover over the information indicators.',
        dialogId: 'alertsModal',
        componentData: {
          rowData: row?.alerts,
          columns,
          asrDetails: this.asrDetails,
          tableName: 'Alerts Table',
          tableId: 'AlertsTable',
          componentId: 'Alerts',
        },
        panelClass: 'ip-dialog-panel',
        component: ASRDetailsTableComponent,
        enableClose: true,
      },
      '80%',
    );
  }

  onViewReportCard(row: any) {
    row.type = 'medicare';
    this.openTableDialog(
      {
        title: 'Report Cards',
        info: 'Report Cards provide the alert and model attribution details associated with the ASR ID. The report card layout and associated tables vary by model and model table; however, the report card section of the model guidance document associated with the select model provides further details regarding the displayed report card. To learn about the information and functions contained within the report card, hover over the information indicators below.',
        dialogId: 'reportCardsModal',
        componentData: {
          rowData: [row, this.asrDetails, 'medicare'],
        },
        panelClass: 'ip-dialog-panel',
        component: ReportCardsComponent,
        enableClose: true,
      },
      '80%',
    );
  }

  viewNetworkViz(row: any) {
    const vizTypeMap: any = { HHA: 'hhaviz', DME: 'dmeviz' };
    this._loader.show();
    this._detailsService
      .getVizData({
        asrId: this.asrDetails?.provider.npi || '',
        vizType: vizTypeMap[row.vizType] || 'viz',
        modelId: row.models.modelName,
      })
      .subscribe({
        next: (res: any) => {
          this._loader.hide();
          this.dialog.open(VisualizationDialogComponent, {
            width: '80vw',
            data: {
              nodes: res.nodes,
              edges: res.edges,
              attributes: res.attributes,
              modelData: row,
              enableClose: true,
              vizType: row.vizType,
              asrDetails: this.asrDetails,
            },
          });
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error('Unable to load due to ' + err.status);
        },
      });
  }
}
