import { Component, Input, OnInit } from '@angular/core';
import {   EDIT_INFO_COLUMNS, EDITS_COLUMNS ,EDITS_CLAIMS_COLUMNS} from '../../../column-config';
import { MatDialog } from '@angular/material/dialog';
import { AsrDetailsService } from '../../../../../services/asr-details.service';
import { LoaderService } from '../../../../../services/loader.service';
import { ToastService } from '../../../../../services/toaster.service';
import { ModelDetailDialogComponent } from '../../../../../shared/dialog/model-detail/model-detail';
import { HomePageService } from '../../../../../services/homepage.service';
import { CommonDialogComponent } from '../../../../../shared/dialog/common-dialog/common-dialog';
import { ASRDetailsTableComponent } from '../../../asr-detail-table/asr-detail-table';
import { OktaService } from '../../../../../services/okta';
import { environment } from '../../../../../environments/environment.shared';
@Component({
  selector: 'app-edits',
  templateUrl: './edits.html',
  styleUrl: './edits.scss',
  standalone: false
})
export class EditsComponent  implements OnInit{
@Input() asrId: string = "";
editColumns = EDITS_COLUMNS.map((column: any) => ({ ...column }));
asrEditData:any[] = [];
activeEditInfos:any[] = [];
inactiveEditInfos:any[] = [];

  constructor(
    public dialog: MatDialog,
    private _detailsService: AsrDetailsService,
    private _loader: LoaderService,
    private _toaster: ToastService,
    private _homeService: HomePageService,
    public okta: OktaService,
  ) {}

  ngOnInit() {
       this._loader.show();
        this._detailsService
          .getAsrDetailsChildData('medicare', 'edits',this.asrId ?? '0')
          .subscribe({
            next: (res: any) => {
              this.asrEditData = res?.responseData?.edits || [];
              this._loader.hide();
    
            
            },
            error: (err: any) => {
              this._loader.hide();
              this._toaster.error(
                `Error loading Edits data to ${err?.status || 'error'}`,
              );
            },
          });

      this._homeService.getEditInfoData().subscribe({
        next: (res: any) => {
          this.activeEditInfos = res.activeEditInfos || [];
          this.inactiveEditInfos = res.inactiveEditInfos || [];
          
        },
        error: (err) => {
          this._toaster.error(err.message);
        },
      });
    

   
  }
    openAllEditsDetailDialog() {
      const dialogRef = this.dialog.open(ModelDetailDialogComponent, {
        width: '80%',
        maxWidth: '100%',
        data: { vulnerabilityType: 'edit', tab1Data:this.activeEditInfos, tab2Data: this.inactiveEditInfos},
        panelClass: 'ip-dialog-panel'
      });
      dialogRef.afterClosed().subscribe((result) => {
        if (result) {
          console.log('Dialog closed with result:', result);
        }
      });
    }
    downloadEditClaims(row:any){
         this._loader.show();
        this._detailsService
          .getEditClaims(row.alertName, this.okta.user().oktaDetails?.preferred_username,this.asrId)
          .subscribe({
            next: (res: any) => {
              let editClaims = res?.editClaims || [];
               const dialogRef = this.dialog.open(CommonDialogComponent, {
                width: '80%',
                maxWidth: '100%',
                data: {  
                      title: 'Edit Claims Denied',
                      info: "",
                      dialogId: 'claimsDeniedModal',
                      componentData: {
                        rowData: editClaims,
                        columns: EDITS_CLAIMS_COLUMNS,
                        tableName: 'Edit Claims Denied Table',
                        tableId: 'claimsDeniedTable',
                      },
                      panelClass: 'ip-dialog-panel',
                      component: ASRDetailsTableComponent,
                      enableClose: true
                    }
              });
              this._loader.hide();
    
            
            },
            error: (err: any) => {
              this._loader.hide();
              this._toaster.error(
                `Error loading Edits data to ${err?.status || 'error'}`,
              );
            },
          });
    }
     openEditDetailDialog(editName:string) {
      let thisEdit = this.activeEditInfos.find(e=> e.fpsEditName === editName);
      if (thisEdit === undefined){
        thisEdit = this.inactiveEditInfos.find(e=> e.fpsEditName === editName);
      }
      const dialogRef = this.dialog.open(CommonDialogComponent, {
        width: '80%',
        maxWidth: '100%',
        data: {  
              title: 'Edit Details',
              info: "Select to view the edit details.",
              dialogId: 'editInfoModal',
              componentData: {
                rowData: new Array(1).fill(thisEdit),
                columns: EDIT_INFO_COLUMNS,
                tableName: 'Edit Details',
                tableId: 'asrDetailEditDetailTable',
              },
              panelClass: 'ip-dialog-panel',
              component: ASRDetailsTableComponent,
              enableClose: true
            }
      });
      dialogRef.afterClosed().subscribe((result) => {
        if (result) {
          console.log('Dialog closed with result:', result);
        }
      });
    }
     showEditTrendReport() {
        window.open(environment.tableauEditTrend + this.asrId);
      }
  
}
