import { Component, OnChanges, SimpleChanges } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
} from '@angular/forms';
import {
  FileUploadService,
  OpenClaimsDocumentParams,
} from '../../../../../services/file-upload.service';
import { LoaderService } from '../../../../../services/loader.service';
import { ToastService } from '../../../../../services/toaster.service';
import { dateRangeLastOneYearValidator, dateRangeValidator } from '../../../../../utilities/utils';
import { ClaimsComponent } from './claims';


interface MedicaidClaimsSearchPayload {
  npi: string;
  asrptId: any;
  fromDt: any | null;
  toDt: any | null;
  // claimTypes: any[] | null;
  hicns: any[] | null;
  hcpcses: any[] | null;
  procedures: any[] | null;
  diagnosises: any[] | null;
  latest: 'Y' | 'N';
  rrb: 'Y' | 'N';
  // latestD: 'Y' | 'N';
  searchType: string | null;
  mdcdStates: any[] | null;
  mdcdSvcSubCats: any[] | null;
  mdcdSvcCats: any[] | null;
}

@Component({
  selector: 'app-claims-mdcd',
  templateUrl: './claims-mdcd.html',
  styleUrls: ['./claims.scss', '../../../asr-detail.scss'],
  standalone: false,
})
export class ClaimsMdcdComponent extends ClaimsComponent implements OnChanges {
  private readonly programType: 'medicaid' = 'medicaid';

  disableMco = false;
  disableFfs = false;
  disableInstitutional = false;
  disableProfessional = false;
  disableDrug = false;
  disableDental = false;
  disableNonClaim = false;
  disableOther = false;

  constructor(
    fb: FormBuilder,
    fileUploadService: FileUploadService,
    loader: LoaderService,
    toaster: ToastService,
  ) {
    super(fb, fileUploadService, loader, toaster);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (!changes['asrDetails'] || !this.form) {
      return;
    }

    this.initializeDisableFlags();
    this.hideShowClaimCheckVals('allClaimsVal');
  }

  get medicaidAlertedStateOptions(): string[] {
    const mdcdUserStates = this.asrDetails?.mdcdUserStates;
    const states = Array.isArray(mdcdUserStates)
      ? mdcdUserStates
          .map((mdcdUserState) => String(mdcdUserState?.state ?? '').trim())
          .filter((state) => state.length > 0)
      : [];

    return Array.from(new Set<string>(states)).sort();
  }

  protected override buildForm(): void {
    this.form = this.fb.group(
      {
        mco: [false],
        ffs: [false],

        institutional: [false],
        professional: [false],
        drug: [false],
        dental: [false],
        dme: [false],
        nonClaim: [false],
        other: [false],

        startDate: [''],
        endDate: [''],
        medicaidAlertedStates: [[]],

        recipients: ['', this.maxLinesValidator(50, 'recipientlineserror')],
        diagnosis: ['', this.maxLinesValidator(50, 'diaglineserror')],
        hcpcs: ['', this.maxLinesValidator(50, 'hcpcserror')],
        icd: ['', this.maxLinesValidator(50, 'icderror')],

      },
      {
        validators: [
          this.mdcdSvcCatsValidator(),
          dateRangeValidator('startDate', 'endDate', 'isDateValid'),
          dateRangeLastOneYearValidator('startDate', 'endDate', 'isOneYearRangeDateValid')
        ],
      },
    );

    this.form.get('institutional')?.valueChanges.subscribe(() => this.checkClaimType());
    this.form.get('professional')?.valueChanges.subscribe(() => this.checkClaimType());
    this.form.get('drug')?.valueChanges.subscribe(() => this.checkClaimType());
    this.form.get('dental')?.valueChanges.subscribe(() => this.checkClaimType());
    this.form.get('dme')?.valueChanges.subscribe(() => this.checkClaimType());
    this.form.get('nonClaim')?.valueChanges.subscribe(() => this.checkClaimType());
    this.form.get('other')?.valueChanges.subscribe(() => this.checkClaimType());
  }

  protected override initializeDisableFlags(): void {
    if (!this.asrDetails) {
      this.disableAtRiskBtn = true;
      this.disableMco = true;
      this.disableFfs = true;
      this.disableInstitutional = true;
      this.disableProfessional = true;
      this.disableDrug = true;
      this.disableDental = true;
      this.disableDme = true;
      this.disableNonClaim = true;
      this.disableOther = true;
      this.disableClmSrchBtn = true;
      return;
    }

    const claims = this.asrDetails?.availableClaims ?? {};
    const claimTypes = this.getMedicaidClaimTypes();

    const hasInstitutional = claimTypes.includes('INSTNL');
    const hasProfessional = claimTypes.includes('PRFNL');
    const hasDrug = claimTypes.includes('DRUG');
    const hasDental = claimTypes.includes('DENTAL');
    const hasDme = claimTypes.includes('DME');
    const hasNonClaim = claimTypes.includes('NONCLM');
    const hasOther = claimTypes.includes('Other');

    this.disableAtRiskBtn = claims.atRiskInd === 'N' || claims.noClaims === true;
    this.disableMco = false;
    this.disableFfs = false;
    this.disableInstitutional = !hasInstitutional;
    this.disableProfessional = !hasProfessional;
    this.disableDrug = !hasDrug;
    this.disableDental = !hasDental;
    this.disableDme = !hasDme;
    this.disableNonClaim = !hasNonClaim;
    this.disableOther = !hasOther;

    const allServiceSubCategoriesDisabled = this.disableMco && this.disableFfs;
    const allServiceCategoriesDisabled =
      this.disableInstitutional &&
      this.disableProfessional &&
      this.disableDrug &&
      this.disableDental &&
      this.disableDme &&
      this.disableNonClaim &&
      this.disableOther;

    this.disableClmSrchBtn = allServiceSubCategoriesDisabled || allServiceCategoriesDisabled;
  }

  override hideShowClaimCheckVals(_radioType: string): void {
    this.applyMedicaidDisableStates();
    this.updateDependentTextFields();
    this.form.markAsDirty();
    this.form.updateValueAndValidity();
  }

  override checkClaimType(): void {
    this.updateDependentTextFields();
    this.form.updateValueAndValidity();
  }

  protected override updateDependentTextFields(): void {
    this.setControlDisabled('diagnosis', false);
    this.setControlDisabled('hcpcs', false);
    this.setControlDisabled('icd', false);
    this.setControlDisabled('recipients', false);
  }

  override resetForm(): void {
    this.form.reset(
      {
        dme: false,
        startDate: '',
        endDate: '',
        recipients: '',
        diagnosis: '',
        hcpcs: '',
        icd: '',
        mco: false,
        ffs: false,
        institutional: false,
        professional: false,
        drug: false,
        dental: false,
        nonClaim: false,
        other: false,
        medicaidAlertedStates: [],
      },
      { emitEvent: false },
    );
    this.submitted = false;

    this.hideShowClaimCheckVals('allClaimsVal');
    this.form.markAsPristine();
    this.form.markAsUntouched();
    this.form.updateValueAndValidity();
  }

  override get isSearchDisabled(): boolean {
    return this.disableClmSrchBtn;
  }

  override getParams(pType: string): OpenClaimsDocumentParams {
    return {
      ...super.getParams(pType),
      programType: this.programType,
      asrId: String(this.asrDetails.mdcdAsrDbId)
    };
  }

  override export(type: string): void {
    this._loader.show();
    this._fileUplaodService.downloadClaimsDocument(this.getParams(type)).subscribe({
      next: (res: any) => {
        this._loader.hide();
      },
      error: (err: any) => {
        this._loader.hide();
        this._toaster.error('Unable to download document due to ' + err.status);
      },
    });
  }

  protected override exportLatest(type: string, isSubmit: boolean = false): void {
    if (isSubmit) {
      this.submitted = true;
    }

    if (isSubmit && this.form.invalid) {
      this.form.markAllAsTouched();
      this._toaster.error('Please update all invalid form fields.');
      return;
    }

    this._loader.show();

    const formValue = this.form.getRawValue();

    let payload: any;

    if (!isSubmit) {
      payload = {
        npi: this.asrDetails.provider.npi,
        fromDt: null,
        toDt: null,
        claimTypes: null,
        hicns: null,
        latest: type === 'latest' ? 'Y' : 'N',
        rrb: type === 'rrb' ? 'Y' : 'N',
        latestD: type === 'latestD' ? 'Y' : 'N',
      };
    } else {
      const mdcdStates = formValue.medicaidAlertedStates ?? [];
      const mdcdSvcSubCats: any[] = [];

      if (formValue.mco) {
        mdcdSvcSubCats.push({ code: 'ENCTR' });
      }

      if (formValue.ffs) {
        mdcdSvcSubCats.push({ code: 'FFS' });
      }

      const mdcdSvcCats: any[] = [];

      if (formValue.institutional) {
        mdcdSvcCats.push({ code: 'INSTNL' });
      }

      if (formValue.professional) {
        mdcdSvcCats.push({ code: 'PRFNL' });
      }

      if (formValue.drug) {
        mdcdSvcCats.push({ code: 'DRUG' });
      }

      if (formValue.dental) {
        mdcdSvcCats.push({ code: 'DENTAL' });
      }

      if (formValue.other) {
        mdcdSvcCats.push({ code: 'Other' });
      }

      if (formValue.dme) {
        mdcdSvcCats.push({ code: 'DME' });
      }

      if (formValue.nonClaim) {
        mdcdSvcCats.push({ code: 'NONCLM' });
      }
      payload = {
        npi: this.asrDetails.provider.npi,
        asrptId: String(this.asrDetails.mdcdAsrDbId),
        fromDt: formValue.startDate || null,
        toDt: formValue.endDate || null,
        hicns: this.convertToHicnArray(formValue.recipients, 'recipients'),
        hcpcses: this.convertToCodeArray(formValue.hcpcs),
        procedures: this.convertToCodeArray(formValue.icd),
        diagnosises: this.convertToCodeArray(formValue.diagnosis),
        latest: 'N',
        rrb: 'N',
        searchType: 'ALERTED',
        mdcdStates: mdcdStates.length ? mdcdStates.map((code: string) => ({ code })) : null,
        mdcdSvcCats: mdcdSvcCats.length ? mdcdSvcCats : null,
        mdcdSvcSubCats: mdcdSvcSubCats.length ? mdcdSvcSubCats : null,
      } as MedicaidClaimsSearchPayload;
    }

    this._fileUplaodService.downloadClaimsDocPost(this.getParams(type), payload).subscribe({
      next: () => {
        this._loader.hide();
      },
      error: (err: any) => {
        this._loader.hide();
        this._toaster.error('Unable to download document due to ' + err.status);
      },
    });
  }

  private mdcdSvcCatsValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const group = control as FormGroup;

      const hasMdcdSvcSubCat =
        group.get('mco')?.value === true || group.get('ffs')?.value === true;
      const hasMdcdSvcCat =
        group.get('institutional')?.value === true ||
        group.get('professional')?.value === true ||
        group.get('drug')?.value === true ||
        group.get('dental')?.value === true ||
        group.get('dme')?.value === true ||
        group.get('nonClaim')?.value === true ||
        group.get('other')?.value === true;

      const errors: ValidationErrors = {};

      if (!hasMdcdSvcSubCat) {
        errors['mdcdSvcSubCatsRequired'] = true;
      }

      if (!hasMdcdSvcCat) {
        errors['mdcdSvcCatsRequired'] = true;
      }

      return Object.keys(errors).length ? errors : null;
    };
  }

  private applyMedicaidDisableStates(): void {
    this.setControlDisabled('mco', this.disableMco);
    this.setControlDisabled('ffs', this.disableFfs);
    this.setControlDisabled('institutional', this.disableInstitutional);
    this.setControlDisabled('professional', this.disableProfessional);
    this.setControlDisabled('drug', this.disableDrug);
    this.setControlDisabled('dental', this.disableDental);
    this.setControlDisabled('dme', this.disableDme);
    this.setControlDisabled('nonClaim', this.disableNonClaim);
    this.setControlDisabled('other', this.disableOther);
  }

  private getMedicaidClaimTypes(): string[] {
    const totalPayments = this.asrDetails?.mdcdTotalPayments;
    const claimTypes = Array.isArray(totalPayments)
      ? totalPayments.flatMap((payment: any): string[] =>
          String(payment?.svcCat ?? '')
            .split(',')
            .map((svcCat) => this.normalizeMedicaidClaimType(svcCat))
            .filter(Boolean),
        )
      : [];
    console.log('>>> claimTypes:',claimTypes);
    return Array.from(new Set<string>(claimTypes));
  }

  private normalizeMedicaidClaimType(claimType: string): string {
    const normalized = claimType.trim().toUpperCase().replace(/[\s_-]/g, '');

    switch (normalized) {
      case 'INSTITUTIONAL':
      case 'INSTNL':
        return 'INSTNL';
      case 'PROFESSIONAL':
      case 'PRFNL':
        return 'PRFNL';
      case 'DRUG':
        return 'DRUG';
      case 'DENTAL':
        return 'DENTAL';
      case 'DME':
        return 'DME';
      case 'NONCLAIM':
      case 'NONCLM':
        return 'NONCLM';
      case 'OTHER':
        return 'Other';
      default:
        return 'Other';
    }
  }
}
