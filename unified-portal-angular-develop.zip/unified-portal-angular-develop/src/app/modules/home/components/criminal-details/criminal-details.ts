import { Component, Inject } from '@angular/core';

@Component({
  selector: 'criminal-detail',
  templateUrl: './criminal-details.html',
  standalone: false,
})
export class CriminalDetailComponent {
  rowData: any;
  columns: any;
  isLoading: boolean = false;
  pageSize: number = 10;
  enableSearch: boolean = true;
  constructor(@Inject('componentData') public data: any) {
    this.rowData = this.data.rowData;
    this.columns = this.data.columns;
  }

  onRowClick(e: any) {}
}
