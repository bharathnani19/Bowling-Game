import { Component, effect, inject, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { OktaService } from '../../services/okta';
import { Card } from '../../shared/interface';
import { HomePageService } from '../../services/homepage.service';
import { ToastService } from '../../services/toaster.service';
import { MatDialog } from '@angular/material/dialog';
import { RenameDialogComponent } from '../../shared/dialog/rename-dialog/rename-dialog';
import { ConfirmationDialogComponent } from '../../shared/dialog/confirmation-dialog/confirmation-dialog';
import { SharedUserDialogComponent } from '../../shared/dialog/share-workbench/share-workbench';
import { LoaderService } from '../../services/loader.service';
import { MyReportsDialogComponent } from '../../shared/dialog/my-reports/my-reports';
import { CommonDialogComponent } from '../../shared/dialog/common-dialog/common-dialog';
import { CriminalDetailComponent } from './components/criminal-details/criminal-details';
import { CRIMINAL_COLUMNS } from './column-config';
import { ApsDialogComponent } from '../../shared/dialog/aps-dialog/aps-dialog';
import { forkJoin, Observable } from 'rxjs';
import { UtilService } from '../../services/util.service';
import { allRoleTypes } from '../../utilities/constants';
import { User } from '../../models/user.model';
import { SearchService } from '../../services/search.service';
import { Router } from '@angular/router';
import { CustomSearchDialogComponent } from '../../shared/dialog/custom-search-dialog/custom-search-dialog';

@Component({
  selector: 'app-home',
  templateUrl: './home.html',
  styleUrl: './home.scss',
  standalone: false,
})
export class HomeComponent implements OnInit {
  dialog = inject(MatDialog);

  defaultAsrView: string = '';

  selectedTabIndex: number = 0;
  selectedInfoTabIndex: number = 0;
  isLoading: boolean = true;
  isWatchlistLoading: boolean = true;
  isInfoLoading: boolean = true;
  isReportsLoading: boolean = true;
  isUserRequestsLoading: boolean = true;
  isEditInfoLoading: boolean = true;
  hasUserRequestsAccess: boolean = false;
  user!: User;
  showInfoButtons: boolean = true;

  //Workbench Data

  workbenchCard: Card = {
    title: 'My Workbench',
    hoverText:
      'This table provides access to your saved working sets and searches. Hover over the column indicators to learn more about what is being displayed and what functions are available.',
  };
  workbenchActionsExport = (row: any) => {
    const actions: string[] = [];
    const isOwner = row?.ownerNm === this.okta.user().userDisplayName;

    if (isOwner) {
      if (row.listType === 'Exclusion Set') {
        actions.push(row.publicInd === 'N' ? 'Public' : 'Private');
      } else if (row.listType === 'PIC Exclusion Set') {
        // none
      } else if (row.listType === 'Saved Search') {
        actions.push('Delete', 'Edit');
      } else {
        actions.push('Rename', 'Delete');
      }
    } else {
      if (row.listType === 'Saved Search' || row.listType === 'Working Set') {
        actions.push('Archive');
      }
    }

    return actions.join(' | ');
  };

  workbenchColumnsMDCR = [
    {
      key: 'listNm',
      label: 'Name',
      custom: true,
      sortable: true,
      tooltip:
        'This column displays the name of the item that was entered by the user. Select the name to view the ASRs contained within or render the search query.',
    },
    {
      key: 'listType',
      label: 'Type',
      sortable: true,
      tooltip:
        'This column indicates if the type is a working set, saved search, or exclusion set.',
    },
    {
      key: 'listCnt',
      label: 'ASRs in List',
      sortable: true,
      tooltip:
        "This column displays the number of unique ASRs contained within the working set or exclusion set. Note: This shall display 'N/A' for saved searches.",
    },
    {
      key: 'createDt',
      label: 'Created Date',
      sortable: true,
      tooltip: 'This column displays the date that the item was created.',
    },
    // {
    //   key: 'sharedInd',
    //   label: 'Shared',
    //   sortable: true,
    //   tooltip:
    //     "This column displays a 'Y' if the item has been shared and an 'N' if the item has not been shared.",
    // },
    {
      key: 'ownerNm',
      label: 'Owner',
      sortable: true,
      tooltip: 'This column displays the name of the end-user who created the item.',
    },
    {
      key: 'actions',
      label: 'Actions',
      sortable: false,
      custom: true,
      tooltip:
        "This column provides the ability to perform actions specific to the item's type.  Hover over an action to find out more.",
      exportValue: this.workbenchActionsExport,
    },
  ];

  workbenchColumnsMDCD = [
    {
      key: 'listNm',
      label: 'Name',
      custom: true,
      sortable: true,
      tooltip:
        'This column displays the name of the item that was entered by the user. Select the name to view the ASRs contained within or render the search query.',
    },
    {
      key: 'listType',
      label: 'Type',
      sortable: true,
      tooltip: 'This column indicates if the type is a working set, saved search.',
    },
    {
      key: 'listCnt',
      label: 'ASRs in List',
      sortable: true,
      tooltip:
        'This column displays the number of unique ASRs contained within the working set. Note: This shall display N/A for saved searches.',
    },
    {
      key: 'createDt',
      label: 'Created Date',
      sortable: true,
      tooltip: 'This column displays the date that the item was created.',
    },
    // {
    //   key: 'sharedInd',
    //   label: 'Shared',
    //   sortable: true,
    //   tooltip:
    //     "This column displays a 'Y' if the item has been shared and an 'N' if the item has not been shared.",
    // },
    {
      key: 'ownerNm',
      label: 'Owner',
      sortable: true,
      tooltip: 'This column displays the name of the end-user who created the item.',
    },
    {
      key: 'actions',
      label: 'Actions',
      sortable: false,
      custom: true,
      tooltip:
        "This column provides the ability to perform actions specific to the item's type.  Hover over an action to find out more.",
      exportValue: this.workbenchActionsExport,
    },
  ];

  workbenchMDCRData = [];

  workbenchMDCDData = [];

  //Watch list data
  watchListCard: Card = {
    tableId: 'watchlistTable',
    title: 'Watch List',
    hoverText:
      'This section provides a table to view alerted providers in your jurisdiction with data changes that may require further review.',
  };

  watchlistColumns = [
    {
      key: 'createDt',
      label: 'Updated Date',
      custom: true,
      sortable: true,
      tooltip:
        "This column indicates when an alerted provider was placed on the Watch List due to a change in their APS Criminal Data that is available for review within the last 30 days. Clicking on the 'Updated Date' hyperlink will display the Criminal Details pop-up.",
    },
    {
      key: 'subjId',
      label: 'ASR ID',
      custom: true,
      sortable: true,
    },
    {
      key: 'name',
      label: 'Name',
      sortable: true,
    },
    {
      key: 'newAlerts',
      label: 'New Alerts',
      sortable: true,
    },
    {
      key: 'agedAlerts',
      label: 'Aged Alerts',
      sortable: true,
    },
    {
      key: 'lastAlertCreateDt',
      label: 'Latest Alert Create Date',
      sortable: true,
    },
    {
      key: 'prioritizeMine',
      label: 'Prioritized - My Jurisdiction',
      sortable: true,
    },
    {
      key: 'prioritizeOther',
      label: 'Prioritized - Not My Jurisdiction',
      sortable: true,
    },
  ];

  watchlistData = [];

  // Info section Data
  infoCard: Card = {
    title: 'Info',
    hoverText:
      "This table provides a high-level overview of Models activity. To obtain an available Model Guidance document, select the Model Name hyperlink. The 'All Model Details' hyperlink provides complete details regarding Active, Inactive, and Decommissioned models. On the Medicare tab, select Edits for edit activity including the denial or rejection of payment before claim finalization for the subject of the ASR ID. The Medicaid tab does not include FPS Edits activity.",
  };

  modelsMDCR = [];
  modelsMDCD = [];
  inactiveModelsMDCR = [];
  inactiveModelsMDCD = [];
  activeEditInfos = [];
  inactiveEditInfos = [];

  // Reports section
  reportsCard: Card = {
    tableId: 'myReportsTable',
    title: 'Reports',
    hoverText:
      "This section provides links to 'Favorite' Tableau reports. To view a report, select a report name. A subset of reports will display by default. To choose Tableau reports to add to your favorites, select the 'Manage Favorites' hyperlink.",
  };

  reportsColumns = [
    {
      key: 'rptNm',
      label: 'Report Name',
      sortable: true,
      custom: true,
    },
  ];
  reportsData = [];

  // User Requests section
  userRequestsCard: Card = {
    tableId: 'userRequestsTable',
    title: 'User Requests',
  };
  userRequestsData = [];
  userRequestsColumns = [
    {
      key: 'userName',
      label: 'User Name',
      sortable: true,
      custom: true,
    },
    {
      key: 'requestDt',
      label: 'Submitted',
      sortable: true,
    },
    {
      key: 'status',
      label: 'Status',
      sortable: true,
    },
  ];

  // Page Methods
  constructor(
    private title: Title,
    public okta: OktaService,
    private _homeService: HomePageService,
    private toaster: ToastService,
    private loader: LoaderService,
    private utilService: UtilService,
    private _searchService: SearchService,
    private router: Router,
  ) {
    this.title.setTitle('Investigative Portal');
    effect(() => {
      this.user = this.okta.user();
      this.hasUserRequestsAccess = !!(
        this.user?.groups?.includes(allRoleTypes.UM_IO_APPROVER) ||
        this.user?.groups?.includes(allRoleTypes.ROLE_PRIORITY_SUP) ||
        this.user?.groups?.includes(allRoleTypes.UM_MASTER_APPROVER) ||
        this.user?.groups?.includes(allRoleTypes.UM_DMA_APPROVER)
      );
      this.selectedTabIndex =
        this.okta.defaultAsrView() === 'medicare' || this.okta.user().disableMedicaid ? 0 : 1;
      this.selectedInfoTabIndex =
        this.okta.defaultAsrView() === 'medicare' || this.okta.user().disableMedicaidMAC ? 0 : 1;
    });
  }

  ngOnInit(): void {
    // move to okta user class

    this.initializeHomePage();
  }

  private initializeHomePage() {
    const slaToken = this.utilService.getSlaToken();
    this.utilService
      .logSla(
        this.okta.user().oktaDetails?.preferred_username!!,
        'Landing Page Load - Start: ' + slaToken,
        this.okta.user().organization!,
      )
      .subscribe({
        // this.utilService.logSla('testuser', 'Landing Page Load - Start: ' + slaToken,'testzone').subscribe({
        next: (results) => {},
        error: (err) => {
          // This block runs if any of the observables error
          console.error(err);
        },
      });
    forkJoin([
      this._fetchWorkbenchData(),
      this._fetchWatchlistData(),
      this._fetchLandingPageData(),
      this._fetchReportsData(),
      this._fetchEditsInfoData(),
    ]).subscribe({
      next: (results) => {},
      error: (err) => {
        // This block runs if any of the observables error
        console.error(err);
      },
      complete: () => {
        this.utilService
          .logSla(
            this.okta.user().oktaDetails?.preferred_username!!,
            'Landing Page Load - End: ' + slaToken,
            this.okta.user().organization!,
          )
          .subscribe({
            // this.utilService.logSla('testuser', 'Landing Page Load - End: ' + slaToken,'testzone').subscribe({
            next: (results) => {},
            error: (err) => {
              // This block runs if any of the observables error
              console.error(err);
            },
          });
      },
    });

    // TODO
    // end logging to splunk
  }
  private _refreshTable(section: string) {
    switch (section) {
      case 'workbench':
        this._fetchWorkbenchData();

        break;
      case 'reports':
        this._fetchReportsData();
        break;
      default:
        break;
    }
  }
  private _fetchWatchlistData(): Promise<any> {
    this.isWatchlistLoading = true;
    return new Promise((resolve, reject) => {
      this._homeService.getWatchListData().subscribe({
        next: (res: any) => {
          this.watchlistData = res.watchlists[0].items;
          this.isWatchlistLoading = false;
          resolve('test');
        },
        error: (err) => {
          this.toaster.error(err.message);
          this.isWatchlistLoading = false;
          resolve('test');
        },
      });
    });
  }

  private _fetchReportsData(): Promise<any> {
    this.isReportsLoading = true;
    return new Promise((resolve, reject) => {
      this._homeService.getReportsData().subscribe({
        next: (res: any) => {
          this.reportsData = res.reports;
          this.isReportsLoading = false;
          resolve('test');
        },
        error: (err) => {
          this.toaster.error(err.message);
          this.isReportsLoading = false;
          resolve('test');
        },
      });
    });
  }

  private _fetchWorkbenchData(): Promise<any> {
    this.isLoading = true;
    return new Promise((resolve, reject) => {
      this._homeService.getWorkbenchData().subscribe({
        next: (res: any) => {
          this.workbenchMDCRData = res.workbenchLists;
          this.workbenchMDCDData = res.workbenchMdcdLists;
          this.isLoading = false;
          resolve('test');
        },
        error: (err) => {
          this.toaster.error(err.message);
          this.isLoading = false;
          resolve('test');
        },
      });
    });
  }

  private _fetchLandingPageData(): Promise<any> {
    this.isInfoLoading = true;
    this.isUserRequestsLoading = true;
    return new Promise((resolve, reject) => {
      this._homeService.getLandingPageData().subscribe({
        next: (res: any) => {
          this.modelsMDCR = res.models;
          this.modelsMDCD = res.modelsMdcd;
          this.inactiveModelsMDCR = res.nonActiveModels;
          this.inactiveModelsMDCD = res.nonActiveModelsMdcd;
          this.userRequestsData = res.requests;
          this.isInfoLoading = false;
          this.isUserRequestsLoading = false;
          resolve('test');
        },
        error: (err) => {
          this.toaster.error(err.message);
          this.isInfoLoading = false;
          resolve('test');
        },
      });
    });
  }

  private _fetchEditsInfoData(): Promise<any> {
    this.isEditInfoLoading = true;
    return new Promise((resolve, reject) => {
      this._homeService.getEditInfoData().subscribe({
        next: (res: any) => {
          this.activeEditInfos = res.activeEditInfos || [];
          this.inactiveEditInfos = res.inactiveEditInfos || [];
          this.isEditInfoLoading = false;
          resolve('test');
        },
        error: (err) => {
          this.toaster.error(err.message);
          resolve('test');
        },
      });
    });
  }

  workbenchItemClicked(row: any) {
    const workItemId = String(row?.listId || '').trim();
    const userId = this.okta.user().oktaDetails?.preferred_username || row?.ownerId;
    let workItemType = 'list';
    if (row?.listType === 'Saved Search') {
      workItemType = 'search';
    } else if (row?.listType === 'Exclusion Set') {
      workItemType = 'exclusion';
    } else if (row?.listType === 'PIC Exclusion Set') {
      workItemType = 'picexclusion';
    }
    if (!workItemId || !userId) {
      this.toaster.error('Unable to open selected workbench item.');
      return;
    }
    if (workItemType === 'search') {
      this.executeSearch(workItemId, row?.listNm);
    } else {
      this.router.navigate(['/Investigative/Triage'], {
        queryParams: {
          type: workItemType,
          workItemId: workItemId,
          asrType: row?.asrType,
          listName: row?.listNm,
        },
      });
      this.loader.show();
    }
  }

  onRowClick(e: any) {}

  isOwner(row: any): boolean {
    return row?.ownerNm === this.okta.user().userDisplayName;
  }

  rename(row: any) {
    this.openRenameDialog(row);
  }
  delete(row: any) {
    const confirmDialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: {
        message: `Are you sure you want to delete this ${row.listType} - ${row.listNm}?`,
        confirmText: 'Delete',
      },
    });
    confirmDialogRef.afterClosed().subscribe((result) => {
      if (result.confirmed) {
        this.loader.show();
        this._homeService.deleteWorkbench(row).subscribe({
          next: (res: any) => {
            this.toaster.success('List successfully deleted');
            this._refreshTable('workbench');
            this.loader.hide();
          },
          error: (err) => {
            this.toaster.error(err.message);
            this.loader.hide();
          },
        });
      }
    });
  }
  share(row: any) {
    this.loader.show();
    this._homeService.sharableUsers(row).subscribe({
      next: (res: any) => {
        this.loader.hide();
        this.openShareWorkbenchDialog(res, row);
      },
    });
  }

  editSavedSearch(row: any) {
    this.dialog.open(CustomSearchDialogComponent, {
      panelClass: 'ip-dialog-panel',
      width: '60%',
      data: {
        mode: 'modifySavedSearch',
        selectedTabIndex: 0,
        ASRType: row?.asrType === 'MDCD' ? 1 : 0,
        savedSearchName: row?.listNm,
        savedSearchId: row?.listId,
      },
    });
  }

  private parseJsonSafely(value: any): any {
    if (!value) return null;
    if (typeof value === 'object') return value;
    if (typeof value !== 'string') return null;

    try {
      return JSON.parse(value);
    } catch {
      return null;
    }
  }

  makePublicPrivate(row: any) {
    const actionBool = row.publicInd === 'Y' ? 'false' : 'true';
    const confirmDialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: {
        message: `Are you sure you want to change the Exclusion Set visibility to ${
          actionBool === 'true' ? 'public' : 'private'
        }?`,
        confirmText: 'Update',
      },
    });
    confirmDialogRef.afterClosed().subscribe((result) => {
      if (result.confirmed) {
        this.loader.show();
        this._homeService.updatePubPrivAction(actionBool).subscribe({
          next: (res: any) => {
            this.toaster.success('List successfully archived');
            this._refreshTable('workbench');
            this.loader.hide();
          },
          error: (err) => {
            this.toaster.error(err.message);
            this.loader.hide();
          },
        });
      }
    });
  }

  archive(row: any) {
    const confirmDialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: {
        message: `Are you sure you want to archive the ${row.listType} -${row.listNm}?`,
        confirmText: 'Archive',
      },
    });
    confirmDialogRef.afterClosed().subscribe((result) => {
      if (result.confirmed) {
        this.loader.show();
        this._homeService.archive(row).subscribe({
          next: (res: any) => {
            this.toaster.success('List successfully archived');
            this._refreshTable('workbench');
            this.loader.hide();
          },
          error: (err) => {
            this.loader.hide();
            this.toaster.error(err.message);
          },
        });
      }
    });
  }

  openShareWorkbenchDialog(res: any, rowData: any) {
    const dialogRef = this.dialog.open(SharedUserDialogComponent, {
      width: '900px',
      data: {
        ...res,
        rowData,
      },
    });
  }

  openRenameDialog(row: any) {
    const list = row.asrType === 'MDCR' ? this.workbenchMDCRData : this.workbenchMDCDData;
    const data = {
      ...row,
      nameList: list.filter((o) => o['listType'] === row.listType).map((o) => o['listNm']),
    };
    const dialogRef = this.dialog.open(RenameDialogComponent, {
      width: '600px',
      data: {
        title: 'Rename ' + row.listType,
        label: 'Name',
        data,
        cancelText: 'Cancel',
        submitText: 'Save',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this._refreshTable('workbench');
        console.log('New Name:', result);
      }
    });
  }

  APSSubscribe() {
    const dialogRef = this.dialog.open(ApsDialogComponent);
    dialogRef.afterClosed().subscribe((result: any) => {
      if (result?.confirmed) {
        this.loader.show();
        this._homeService.APSSubscribe(result.value).subscribe({
          next: () => {
            this.loader.hide();

            const successMessage = result.value
              ? 'You have successfully subscribed to the Watch List.'
              : 'You have successfully unsubscribed to the Watch List.';

            // Allow dialog/loader overlays to settle so screen readers announce
            // the snackbar message consistently.
            setTimeout(() => {
              this.toaster.success(successMessage);
            }, 150);
          },
          error: (err: any) => {
            this.loader.hide();
            setTimeout(() => {
              this.toaster.error(`Watch List Subscription failed due to ${err.status}`);
            }, 150);
          },
        });
      }
    });
  }

  openCriminalDetail(row: any) {
    this.loader.show();

    this._homeService.getCriminalDetails(row).subscribe({
      next: (res: any) => {
        const rowData = (res.responseData.aps || [])?.map((o: any) => {
          o['businessName'] = `${o.firstName} ${o.lastName}`;
          return o;
        });
        this.loader.hide();

        const dialogInfo = {
          title: 'Criminal Detail',
          info: 'This table provides details of the crime (per APS data) committed by the provider or PECOS identified owner.',
          componentData: {
            rowData,
            columns: CRIMINAL_COLUMNS,
          },
          panelClass: 'ip-dialog-panel',
          component: CriminalDetailComponent,
        };

        this.openTableDialog(dialogInfo);
      },
    });
  }
  openTableDialog(data: any, width: string = '80%') {
    const dialogRef = this.dialog.open(CommonDialogComponent, {
      width,
      data: {
        ...data,
      },
      panelClass: 'ip-dialog-panel',
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this._refreshTable('workbench');
        console.log('New Name:', result);
      }
    });
  }

  openMyReportsDialog() {
    this.loader.show();
    this._homeService.getAvailableReports().subscribe({
      next: (res: any) => {
        this.loader.hide();
        const dialogRef = this.dialog.open(MyReportsDialogComponent, {
          width: '1000px',
          maxWidth: '100%',
          data: res.reports,
          panelClass: 'ip-dialog-panel',
        });
        dialogRef.afterClosed().subscribe((res) => {
          if (res) {
            this._refreshTable('reports');
            console.log('New Name:', res);
          }
        });
      },
      error: (err: any) => {
        this.loader.hide();
      },
    });
  }
  openLandingReport(url: string) {
    window.open(url, 'new');
    // track logging
  }

  private executeSearch(searchId: string, searchName: string): void {
    this.loader.show();
    this._searchService.getEditedSearchCriteria(searchId).subscribe({
      next: (searchCriteria: any) => {
        const payload = this._searchService.json2Payload(searchCriteria?.prefJson);

        this._searchService.customSearch(payload).subscribe((res: any) => {
          const responseData =
            payload?.programType === 'medicare' ? res.responseData : res.responseDataMdcd;
          if (!responseData?.length) {
            this.toaster.info('No matching records found.');
            this.loader.hide();
            return;
          }

          this._searchService.searchData.set({
            data: res,
            filter: null,
            programType: payload?.programType,
            savedSearchName: searchName,
            savedSearchId: searchId,
            prefJson: this._searchService.payload2Json(payload),
          });
          this.loader.hide();
          this.router.navigate(['/Investigative/Triage']);
        });
      },
      error: () => {
        this.toaster.error('Unable to load saved search criteria.');
        return;
      },
    });
  }
}
