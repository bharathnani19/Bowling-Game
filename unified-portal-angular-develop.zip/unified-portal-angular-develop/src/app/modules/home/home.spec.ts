import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { of } from 'rxjs';
import { HomeComponent } from './home';
import { HomePageService } from '../../services/homepage.service';
import { OktaService } from '../../services/okta';
import { ToastService } from '../../services/toaster.service';
import { UtilService } from '../../services/util.service';
import { Title } from '@angular/platform-browser';
import { LoaderService } from '../../services/loader.service';
import { SearchService } from '../../services/search.service';
import { Router } from '@angular/router';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;

  beforeEach(async () => {
    const homePageServiceMock = jasmine.createSpyObj('HomePageService', [
      'getWorkbenchData', 
      'getWatchListData', 
      'getLandingPageData', 
      'getReportsData',
      'getEditInfoData',
      'searchWorkbenchItem'
    ]);
    homePageServiceMock.getWorkbenchData.and.returnValue(of({ workbenchLists: [], workbenchMdcdLists: [] }));
    homePageServiceMock.getWatchListData.and.returnValue(of({ watchlistData: [] }));
    homePageServiceMock.getLandingPageData.and.returnValue(of({ landingPageData: [] }));
    homePageServiceMock.getReportsData.and.returnValue(of({ reportsData: [] }));
    homePageServiceMock.getEditInfoData.and.returnValue(of({ editInfoData: [] }));
    homePageServiceMock.searchWorkbenchItem.and.returnValue(of({ responseData: [] }));
    const oktaServiceMock = jasmine.createSpyObj('OktaService', ['user', 'defaultAsrView']);
    oktaServiceMock.user.and.returnValue({ disableMedicaid: false, disableMedicare: false });
    oktaServiceMock.defaultAsrView.and.returnValue('defaultView');
    const toastServiceMock = jasmine.createSpyObj('ToastService', ['error', 'success', 'info']);
    const utilServiceMock = jasmine.createSpyObj('UtilService', ['formatDate', 'getSlaToken', 'logSla']);
    utilServiceMock.getSlaToken.and.returnValue('mock-token');
    utilServiceMock.logSla.and.returnValue(of({}));
    const loaderServiceMock = jasmine.createSpyObj('LoaderService', ['show', 'hide']);
    const searchServiceMock = jasmine.createSpyObj('SearchService', ['clearSearchData', 'customSearch']);
    searchServiceMock.searchData = { set: jasmine.createSpy('set') };
    const routerMock = jasmine.createSpyObj('Router', ['navigate']);

    await TestBed.configureTestingModule({
      declarations: [HomeComponent],
      providers: [
        Title,
        { provide: HomePageService, useValue: homePageServiceMock },
        { provide: OktaService, useValue: oktaServiceMock },
        { provide: ToastService, useValue: toastServiceMock },
        { provide: UtilService, useValue: utilServiceMock },
        { provide: LoaderService, useValue: loaderServiceMock },
        { provide: SearchService, useValue: searchServiceMock },
        { provide: Router, useValue: routerMock }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
