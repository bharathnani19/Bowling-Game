import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SessionInactiveModalComponent } from './session-timeout';

describe('SessionInactiveModalComponent', () => {
  let component: SessionInactiveModalComponent;
  let fixture: ComponentFixture<SessionInactiveModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SessionInactiveModalComponent],
      providers: [
        { provide: MatDialogRef, useValue: { close: jasmine.createSpy('close') } },
        { provide: MAT_DIALOG_DATA, useValue: { timer: 60 } }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SessionInactiveModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
