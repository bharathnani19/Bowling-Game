import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { SavedSearchComponent } from './saved-search-component';
import { HomePageService } from '../../../../services/homepage.service';
import { ToastService } from '../../../../services/toaster.service';

describe('SavedSearchComponent', () => {
  let component: SavedSearchComponent;
  let fixture: ComponentFixture<SavedSearchComponent>;

  beforeEach(async () => {
    const homePageServiceMock = jasmine.createSpyObj('HomePageService', ['getSavedSearches']);
    const toastServiceMock = jasmine.createSpyObj('ToastService', ['error', 'success']);

    await TestBed.configureTestingModule({
      declarations: [SavedSearchComponent],
      imports: [ReactiveFormsModule],
      providers: [
        { provide: HomePageService, useValue: homePageServiceMock },
        { provide: ToastService, useValue: toastServiceMock }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SavedSearchComponent);
    component = fixture.componentInstance;
    // Don't call detectChanges to avoid Material select form control initialization
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
