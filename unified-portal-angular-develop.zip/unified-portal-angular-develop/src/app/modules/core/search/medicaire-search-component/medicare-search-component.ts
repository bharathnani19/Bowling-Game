import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { HomePageService } from '../../../../services/homepage.service';
import { ToastService } from '../../../../services/toaster.service';
import { OktaService } from '../../../../services/okta';
import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import moment from 'moment';
import {
  biuSearchValidator,
  dateRangeValidator,
  minMaxValidator,
  tenDigitPerLineValidator,
  getIds,
} from '../../../../utilities/utils';
import { SearchLookup } from '../../../../shared/interface';
type Option = { code: string; label?: string };
@Component({
  selector: 'app-medicare-search-component',
  templateUrl: './medicare-search-component.html',
  styleUrl: './medicare-search-component.scss',
  standalone: false,
})
export class MedicareSearchComponent implements OnInit {
  @Input() searchLookups: SearchLookup | any = {};
  @Input() selectedValues: any = {};
  form!: FormGroup;
  actionabilities: any[] = [];
  alertStatuses!: Option[];
  atRiskJurisdictions: Option[] = [
    { code: 'UPIC 1', label: 'UPIC MW' },
    { code: 'UPIC 2', label: 'UPIC NE' },
    { code: 'UPIC 3', label: 'UPIC W' },
    { code: 'UPIC 4', label: 'UPIC SW' },
    { code: 'UPIC 5', label: 'UPIC SE' },
    { code: 'RRB SMAC', label: 'RRB SMAC' },
    { code: 'MEDIC', label: 'MEDIC' },
  ];
  private readonly verifyErrorKeys = ['asriderror', 'asrformaterror', 'asrverifyerror'];
  constructor(
    private fb: FormBuilder,
    private _homeService: HomePageService,
    private _toaster: ToastService,
  ) {}
  ngOnInit(): void {
    this.initOptions();
    this.initForm();

    //if (this.initData?.initialValues) {
    //   this.form.patchValue(this.initData.initialValues);
    // }
  }

  compareByCodeOrValue(a: any, b: any): boolean {
    if (a === b) return true;
    if (!a || !b) return false;
    if (a.code != null && b.code != null) return a.code === b.code;
    if (a.key != null && b.key != null) return a.key === b.key;
    return false;
  }
  getFormPairMax(variableRoot: String): any {
    return this.form.get(variableRoot + 'Max')?.value;
  }
  private initOptions(): void {
    this.alertStatuses = [
      { code: '12', label: 'New' },
      { code: '13', label: 'Aged' },
    ];

    this.actionabilities = [
      { code: 'Highly Likely' },
      { code: 'Somewhat Likely' },
      { code: 'Less Likely' },
    ];
  }
  private initForm(): void {
    this.form = this.fb.group(
      {
        // Frequently Used
        asrptIds: [null, [tenDigitPerLineValidator()]],
        alerts: [null],
        alertStatus: [null],
        jurisdictions: [null],
        billingNpis: [null, [tenDigitPerLineValidator()]],

        // ASR Information
        prvdrName: [null],
        atRiskJrsdctns: [null],
        atRiskCostMin: [{ value: null, disabled: true }],
        atRiskCostMax: [{ value: null, disabled: true }],
        enrollStatus: [null],
        actionability: [null],
        riskScoreLow: [null],
        riskScoreHigh: [null],
        priorityScoreLow: [null],
        priorityScoreHigh: [null],
        createdDtMin: [null],
        createdDtMax: [null],
        biuComplaints: [null],
        biuComplaintDays: [null],
        tpeLastEduDtMin: [null],
        tpeLastEduDtMax: [null],
        lastEduDtMin: [null],
        lastEduDtMax: [null],
        ruling: [null],
        asrCostMin: [null],
        asrCostMax: [null],
        lastAlertClmDtMin: [null],
        lastAlertClmDtMax: [null],
        modelSchemes: [null],

        // Phase 1 ASR Information
        p1ModelSchemes: [null],
        p1Alerts: [null],
        p1AlertStatus: [null],
        p1Jurisdictions: [null],
        p1AsrCostMin: [null],
        p1AsrCostMax: [null],

        // Claims Information
        claimType: [null],
        dualBeneInd: [null],
        clmSbtDtMin: [null],
        clmSbtDtMax: [null],
        submittedAmtMin: [null],
        submittedAmtMax: [null],
        totalPayMin: [null],
        totalPayMax: [null],
        submittedAmtDMin: [null],
        submittedAmtDMax: [null],

        // Investigation Information
        zoneRestrict: [null],
        leadInvStatus: [null],
        myZoneOnlyInd: [null],
        priorUcm: [null],
        leadInd: [null],
        ucmAsrId: [null],
        ucmCaseId: [null],
        // Exclusions
        exclusions: [null],
        exclusionsInd: [null],
      },

      {
        validators: [
          minMaxValidator('riskScoreLow', 'riskScoreHigh', 'riskRangeInvalid'),
          minMaxValidator('priorityScoreLow', 'priorityScoreHigh', 'priorityRangeInvalid'),
          minMaxValidator('asrCostMin', 'asrCostMax', 'asrCostRangeInvalid'),
          minMaxValidator('atRiskCostMin', 'atRiskCostMax', 'atRiskCostRangeInvalid'),
          minMaxValidator('p1AsrCostMin', 'p1AsrCostMax', 'p1AsrCostRangeInvalid'),
          minMaxValidator('submittedAmtMin', 'submittedAmtMax', 'submittedAmtMinRangeInvalid'),
          minMaxValidator('totalPayMin', 'totalPayMax', 'totalPayRangeInvalid'),
          minMaxValidator('submittedAmtDMin', 'submittedAmtDMax', 'submittedAmtDRangeInvalid'),
          dateRangeValidator('tpeLastEduDtMin', 'tpeLastEduDtMax', 'tpeLastEduDtRangeInvalid'),
          dateRangeValidator('createdDtMin', 'createdDtMax', 'createdDtRangeInvalid'),
          dateRangeValidator('lastEduDtMin', 'lastEduDtMax', 'lastEduDtRangeInvalid'),
          dateRangeValidator(
            'lastAlertClmDtMin',
            'lastAlertClmDtMax',
            'lastAlertClmDtRangeInvalid',
          ),
          dateRangeValidator('clmSbtDtMin', 'clmSbtDtMax', 'clmSbtDtRangeInvalid'),
          biuSearchValidator(
            'biuComplaints',
            'biuComplaintDays',
            'missingBiuComplaints',
            'missingBiuComplaintDays',
          ),
        ],
      },
    );
    this.form.get('atRiskJrsdctns')?.valueChanges.subscribe((jurisdictions: string[] | null) => {
      this.updateAtRiskCostControls(jurisdictions);
    });
    this.form.patchValue(this.selectedValues);
  }

  private updateAtRiskCostControls(jurisdictions: string[] | null): void {
    const minCost = this.form.get('atRiskCostMin');
    const maxCost = this.form.get('atRiskCostMax');

    if (jurisdictions?.length) {
      minCost?.enable({ emitEvent: false });
      maxCost?.enable({ emitEvent: false });
      return;
    }

    minCost?.reset(null, { emitEvent: false });
    maxCost?.reset(null, { emitEvent: false });
    minCost?.disable({ emitEvent: false });
    maxCost?.disable({ emitEvent: false });
  }

  verifyAsrIds(): void {
    const asrControl = this.form.get('asrptIds');
    const clearValidationFlags = () => {
      const errors = { ...(asrControl?.errors ?? {}) };
      this.verifyErrorKeys.forEach((key) => delete errors[key]);
      asrControl?.setErrors(Object.keys(errors).length ? errors : null);
    };

    const setValidationFlag = (key: string) => {
      asrControl?.setErrors({ ...(asrControl?.errors ?? {}), [key]: true });
    };

    const raw = String(asrControl?.value ?? '');
    const ids = raw
      .split(/[\s,]+/g)
      .map((x) => x.trim())
      .filter(Boolean);

    clearValidationFlags();

    if (!ids.length) {
      this._toaster.error('Please enter ASRs to verify.');
      return;
    }

    const invalidIds = ids.filter((id) => !/^\d{10}$/.test(id));

    if (invalidIds.length) {
      setValidationFlag('asrformaterror');
      const message = `The following NPI has an incorrect format: ${invalidIds.join(', ')}`;
      this._toaster.error(message);
      return;
    }

    if (ids.length > 200) {
      setValidationFlag('asriderror');
      this._toaster.error('Number of ASRs exceeds the limit of 200.');
      return;
    }

    this._homeService.verifyASRs(ids, 0).subscribe({
      next: (res: any) => {
        const respDataArray = res?.responseData ?? res?.data?.responseData ?? [];

        if (!respDataArray.length) {
          clearValidationFlags();
          this._toaster.success('An ASR exists for all NPIs entered.');
          return;
        }

        const asrMsg = respDataArray
          .map((item: any) => item?.asrId)
          .filter(Boolean)
          .join(', ');

        this._toaster.error(
          `The following NPIs do not have an existing ASR: ${asrMsg || 'Unknown'}`,
        );
        setValidationFlag('asrverifyerror');
      },
      error: (err: any) => {
        setValidationFlag('asrverifyerror');
        this._toaster.error(
          `ASR verification failed due to ${err?.status ?? 'an unexpected error'}`,
        );
      },
    });
  }

  allowOnlyDigit(event: Event) {
    const textarea = event.target as HTMLTextAreaElement;

    // Allow digits and newline only
    const filtered = textarea.value.replace(/[^\d\n]/g, '');

    if (textarea.value !== filtered) {
      textarea.value = filtered;
      this.form.get('asrptIds')?.setValue(filtered, { emitEvent: false });
    }
  }
  /** Clear all criteria */
  clearForm(): void {
    this.form.reset();
  }

  get isFormValid(): boolean {
    return this.form.valid;
  }

  populate(payload: any, data: any = {}): any {
    if (!payload || typeof payload !== 'object') {
      return;
    }

    const toDate = (value: any): Date | null => {
      if (!value) return null;

      if (typeof value === 'string') {
        const m = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
        if (m) {
          const [, y, mo, d] = m;
          const localDate = new Date(Number(y), Number(mo) - 1, Number(d));
          return Number.isNaN(localDate.getTime()) ? null : localDate;
        }
      }

      const parsed = new Date(value);
      return Number.isNaN(parsed.getTime()) ? null : parsed;
    };

    data.actionability = payload.actionability?.map((x: any) => ({ code: x?.code })) ?? null;
    data.alerts = payload.alerts?.map((x: any) => x?.alertId).filter((x: any) => x != null) ?? null;
    data.alertStatus = payload.alertStatus?.map((x: any) => ({ code: x?.code })) ?? null;
    data.asrCostMax = payload.asrCostHigh ?? null;
    data.asrCostMin = payload.asrCostLow ?? null;   
    data.atRiskCostMax = payload.atRiskCostHigh ?? null;
    data.atRiskCostMin = payload.atRiskCostLow ?? null;
    data.atRiskJrsdctns = payload.atRiskJrsdctns?.map((x: any) => x?.code).filter((x: any) => x != null) ?? null;
    data.asrptIds = payload.asrptIds ?? null;
    data.billingNpis = payload.billingNpis ?? null;
    data.biuComplaints = payload.biuCnt ?? null;
    data.biuComplaintDays = payload.biuDays ?? null;
    data.claimType =payload.claimTypes?.map((x: any) => x?.claimTypeCd).filter((x: any) => x != null) ?? null;
    data.clmSbtDtMin = toDate(payload.lastClmDtLow);
    data.clmSbtDtMax = toDate(payload.lastClmDtHigh);
    data.createdDtMin = toDate(payload.createdMinDt);
    data.createdDtMax = toDate(payload.createdMaxDt);
    data.dualBeneInd = payload.dualBeneInd ?? null;
    data.enrollStatus = payload.enrollStatus?.map((x: any) => ({ code: x?.code })) ?? null;
    data.exclusionsInd = payload.exclusionOrInd ?? null;
    data.exclusions = payload.exclusions?.map((x: any) => x?.code).filter((x: any) => x != null) ?? null;
    data.jurisdictions = payload.jurisdictions?.map((x: any) => x?.code).filter((x: any) => x != null) ?? null;
    data.lastAlertClmDtMin = toDate(payload.lastAlertSvcDtLow);
    data.lastAlertClmDtMax = toDate(payload.lastAlertSvcDtHigh);
    data.modelSchemes = payload.modelSchemes
      ?.map((x: any) => typeof x === 'string' ? x : x?.code)
      .filter((x: any) => x != null) ?? null;
    data.lastEduDtMin = toDate(payload.lastEduDtLow);
    data.lastEduDtMax = toDate(payload.lastEduDtHigh);
    data.leadInd = payload.leadInd ?? null;
    data.leadInvStatus = payload.leadInvestigationInd?.map((x: any) => x?.code).filter((x: any) => x != null) ?? null;
    data.myZoneOnlyInd = payload.myZoneOnlyInd === 'Yes';
    data.p1Alerts = payload.p1Alerts?.map((x: any) => x?.alertId).filter((x: any) => x != null) ?? null;
    data.p1ModelSchemes = payload.p1ModelSchemes
      ?.map((x: any) => typeof x === 'string' ? x : x?.code)
      .filter((x: any) => x != null) ?? null;
    data.p1AlertStatus = payload.p1AlertStatus?.map((x: any) => ({ code: x?.code })) ?? null;
    data.p1AsrCostMax = payload.p1AsrCostHigh ?? null;
    data.p1AsrCostMin = payload.p1AsrCostLow ?? null;
    data.p1Jurisdictions = payload.p1Jurisdictions?.map((x: any) => x?.code).filter((x: any) => x != null) ?? null;
    data.priorityScoreHigh = payload.priorityScoreHigh ?? null;
    data.priorityScoreLow = payload.priorityScoreLow ?? null;
    data.priorUcm = payload.prioritizeTypes?.map((x: any) => x?.code).filter((x: any) => x != null) ?? null;
    data.prvdrName = payload.prvdrName ?? null;
    data.riskScoreLow = payload.riskScoreLow ?? null;
    data.riskScoreHigh = payload.riskScoreHigh ?? null;
    data.ruling = payload.rulings?.map((x: any) => ({ code: x?.code })) ?? null;
    data.submittedAmtMin = payload.sbmtAmtLow ?? null;
    data.submittedAmtMax = payload.sbmtAmtHigh ?? null;
    data.submittedAmtDMin = payload.totalPymtLow ?? null;    // ?? payload.sbmtAmtDLow
    data.submittedAmtDMax = payload.totalPymtHigh ?? null;   // ?? payload.sbmtAmtDHigh
    data.tpeLastEduDtMin = toDate(payload.lastTpeEduDtLow);
    data.tpeLastEduDtMax = toDate(payload.lastTpeEduDtHigh);
    // data.totalPayMin = payload.totalPymtLow ?? null;      // correct mapping?
    // data.totalPayMax = payload.totalPymtHigh ?? null;     // correct mapping?
    data.ucmAsrId = payload.ucmAsrId ?? null;
    data.ucmCaseId = payload.ucmCaseId ?? null;
    data.zoneRestrict = payload.zrTypes?.map((x: any) => x?.code).filter((x: any) => x != null) ?? null;

    this.form.patchValue(data, { emitEvent: false });
    this.updateAtRiskCostControls(data.atRiskJrsdctns);
  }
  
  prepSubmit(): any {
    const asrControl = this.form.get('asrptIds');
    const asrErrors = asrControl?.errors ?? {};
    const hasVerifyError = this.verifyErrorKeys.some((key) => !!asrErrors[key]);

    if (hasVerifyError) {
      this._toaster.error('Please resolve ASR verification errors before searching.');
      asrControl?.markAsDirty();
      asrControl?.markAsTouched();
      return;
    }

    if (this.form.invalid) {
      this._toaster.error('Please correct the search form field errors.');
      this.form.markAllAsDirty();
      return;
    }
    const data = this.form.value;
    const payload = {
      asrptIds: typeof data.asrptIds === 'object' ? data.asrptIds : getIds(data.asrptIds),
      billingNpis:
        typeof data.billingNpis === 'object' ? data.billingNpis : getIds(data.billingNpis),
      alerts: data.alerts?.map((alertId: any) => ({ alertId })) ?? null,
      alertStatus: data.alertStatus?.map((o: any) => ({ code: o.code })) ?? null,
      jurisdictions: data.jurisdictions?.map((code: any) => ({ code })) ?? null,
      modelSchemes: data.modelSchemes?.map((code: string) => ({ code })) ?? null,
      p1Alerts: data.p1Alerts?.map((alertId: any) => ({ alertId: `${alertId}` })) ?? null,
      p1ModelSchemes: data.p1ModelSchemes?.map((code: string) => ({ code })) ?? null,
      p1AlertStatus: data.p1AlertStatus?.map((o: any) => ({ code: o.code })) ?? null,
      p1Jurisdictions: data.p1Jurisdictions?.map((code: any) => ({ code })) ?? null,
      createdMinDt: data.createdDtMin ? moment(data.createdDtMin).format('YYYY-MM-DD') : null,
      createdMaxDt: data.createdDtMax ? moment(data.createdDtMax).format('YYYY-MM-DD') : null,
      lastTpeEduDtLow: data.tpeLastEduDtMin
        ? moment(data.tpeLastEduDtMin).format('YYYY-MM-DD')
        : null,
      lastTpeEduDtHigh: data.tpeLastEduDtMax
        ? moment(data.tpeLastEduDtMax).format('YYYY-MM-DD')
        : null,
      lastEduDtLow: data.lastEduDtMin ? moment(data.lastEduDtMin).format('YYYY-MM-DD') : null,
      lastEduDtHigh: data.lastEduDtMax ? moment(data.lastEduDtMax).format('YYYY-MM-DD') : null,
      lastClmDtLow: data.clmSbtDtMin ? moment(data.clmSbtDtMin).format('YYYY-MM-DD') : null,
      lastClmDtHigh: data.clmSbtDtMax ? moment(data.clmSbtDtMax).format('YYYY-MM-DD') : null,
      riskScoreLow: data.riskScoreLow,
      riskScoreHigh: data.riskScoreHigh,
      priorityScoreLow: data.priorityScoreLow,
      priorityScoreHigh: data.priorityScoreHigh,
      asrCostLow: data.asrCostMin,
      asrCostHigh: data.asrCostMax,
      atRiskJrsdctns: data.atRiskJrsdctns?.map((code: any) => ({ code })) ?? null,
      atRiskCostLow: data.atRiskCostMin,
      atRiskCostHigh: data.atRiskCostMax,
      lastAlertSvcDtLow: data.lastAlertClmDtMin
        ? moment(data.lastAlertClmDtMin).format('YYYY-MM-DD')
        : null,
      lastAlertSvcDtHigh: data.lastAlertClmDtMax
        ? moment(data.lastAlertClmDtMax).format('YYYY-MM-DD')
        : null,
      p1AsrCostHigh: data.p1AsrCostMax,
      p1AsrCostLow: data.p1AsrCostMin,
      sbmtAmtLow: data.submittedAmtMin,
      sbmtAmtHigh: data.submittedAmtMax,
      totalPymtLow: data.totalPayMin,
      totalPymtHigh: data.totalPayMax,
      totalPymtDLow: data.submittedAmtDMin,
      totalPymtDHigh: data.submittedAmtDMax,

      // ASR Information
      prvdrName: data.prvdrName,
      enrollStatus: data.enrollStatus?.map((o: any) => ({ code: o.code })) ?? null,
      actionability: data.actionability?.map((o: any) => ({ code: o.code })) ?? null,
      biuCnt:
        data.biuComplaints !== null && data.biuComplaints !== undefined && data.biuComplaints !== ''
          ? String(data.biuComplaints)
          : null,
      biuDays: data.biuComplaintDays,
      rulings: data.ruling?.map((o: any) => ({ code: o.code })) ?? null,

      // Claims Information
      claimTypes: data.claimType?.map((o: any) => ({ claimTypeCd: o })) ?? null,
      dualBeneInd: data.dualBeneInd,

      // Investigation Information
      zrTypes: data.zoneRestrict?.map((o: any) => ({ code: o })) ?? null,
      leadInvestigationInd: data.leadInvStatus?.map((o: any) => ({ code: o })) ?? null,
      myZoneOnlyInd: data.myZoneOnlyInd ? 'Yes' : 'No',
      prioritizeTypes: data.priorUcm?.map((o: any) => ({ code: `${o}` })) ?? null,
      leadInd: data.leadInd,
      ucmAsrId: data.ucmAsrId,
      ucmCaseId: data.ucmCaseId,
      // Exclusions
      exclusions: data.exclusions?.map((o: any) => ({ code: o })) ?? null,
      exclusionOrInd: data.exclusionsInd,
    };

    console.log('Search payload:', payload);

    return payload;
  }
}
