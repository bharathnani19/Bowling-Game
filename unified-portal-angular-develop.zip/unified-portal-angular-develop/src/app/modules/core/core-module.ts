import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header';
import { LandingComponent } from './landing/landing';
import { AppRoutingModule } from '../../app-routing.module';
import { RouterModule } from '@angular/router';
import { LayoutComponent } from './layout/layout';
import { MaterialModule } from '../../shared/material.module';
import { SessionInactiveModalComponent } from './session-timeout/session-timeout';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AppLoaderComponent } from '../../shared/app-loader/app-loader';

const COMPONENTS = [
  HeaderComponent,
  LandingComponent,
  SessionInactiveModalComponent,
  LayoutComponent,
  AppLoaderComponent,
];

@NgModule({
  declarations: [...COMPONENTS],
  imports: [
    CommonModule,
    AppRoutingModule,
    RouterModule,
    HttpClientModule,
    MaterialModule,
    FormsModule,
  ],
  exports: [...COMPONENTS],
})
export class CoreModule {}
