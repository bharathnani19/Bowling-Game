import {
  Component,
  effect,
  ElementRef,
  EventEmitter,
  HostListener,
  OnInit,
  Output,
  signal,
} from '@angular/core';
import { OktaService } from '../../../services/okta';
import { allRoleTypes, navigationTypes } from '../../../utilities/constants';
import { environment } from '../../../environments/environment.shared';
import { User } from '../../../models/user.model';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { HomePageService } from '../../../services/homepage.service';
import { FileUploadService } from '../../../services/file-upload.service';
import { ToastService } from '../../../services/toaster.service';
import { CustomSearchDialogComponent } from '../../../shared/dialog/custom-search-dialog/custom-search-dialog';
import { SearchLookup } from '../../../shared/interface';
import { LoaderService } from '../../../services/loader.service';
import { SearchService } from '../../../services/search.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.html',
  styleUrl: './header.scss',
  standalone: false,
})
export class HeaderComponent implements OnInit {
  isAuthenticated: boolean = false;

  hideMenu: boolean = false;
  defaultAsrView: string = '';
  searchVal = '';
  constructor(
    private router: Router,
    private route: ActivatedRoute,

    public dialog: MatDialog,

    private fileService: FileUploadService,
    private homePageService: HomePageService,
    private eRef: ElementRef,
    public okta: OktaService,
    private toaster: ToastService,
    private _loader: LoaderService,
    private _searchService: SearchService,
  ) {
    effect(() => {
      this.user = this.okta.user();
    });
    this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        const firstChild = this.route.firstChild;
        firstChild?.data.subscribe((data: any) => {
          this.hideMenu = data['hideMenu'] || false;
          this.activeLink = data.activeLink || false;
        });
      }
    });
  }
  @Output() showLink = new EventEmitter<string>();
  formattedNotifications: any[] = [];
  user!: User;
  notificationList: any[] = [];
  systemMessages: any;
  searchRefData: any = {};
  notificationCount = 0;
  upHomeUrl = environment.upHome;
  vulMgmtUrl = environment.vulMgmt;
  editInqUrl = environment.editInq;
  adminUrl = environment.admin;
  userMgmtUrl = environment.umLink;
  emlurl = environment.emlLink;
  reportUrl = environment.extended.tableauBase;
  wsHost = environment.wsHost;
  appUrl = environment.appUrl;
  activeLink: boolean = false;
  showMoreSystemMessageTxt: boolean[] = [];
  msgCount: number = 0;

  currentOpen: string | null = null;

  //508 purpose
  onDefaultViewRowKeydown(event: KeyboardEvent, selectEl: HTMLSelectElement): void {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      event.stopPropagation();

      setTimeout(() => {
        if (selectEl) {
          selectEl.focus();
        }
      });
    }
  }

  async ngOnInit(): Promise<void> {
    this.isAuthenticated = await this.okta.oktaAuth.isAuthenticated();

    this.homePageService.getHomePageToolbar().subscribe((response) => {
      this.systemMessages = response.messages || [];
      this.msgCount = response.newSysMsgCt;
      this.defaultAsrView = response.defaultAsrView || 'medicare';
      this.okta.defaultAsrView.set(this.defaultAsrView);
    });

    this.homePageService.getAsrSearchRefdata().subscribe({
      next: (res: SearchLookup) => {
        Object.assign(this.searchRefData, res);
      },
    });

    this.homePageService.getSavedSearchRefdata().subscribe({
      next: (res: SearchLookup) => {
        this.searchRefData.saved = res;
      },
    });
  }

  onViewChange(value: string) {
    this.homePageService.updatePreference(value, 'defaultAsrView').subscribe({
      next: () => {
        this.okta.defaultAsrView.set(value);
        this.toaster.success('Default ASR view preference successfully saved.');
      },
      error: (err) => {
        this.toaster.error('Default ASR view preference not saved due to ' + err.message);
      },
    });
  }

  skipToMainContent() {
    const element = document.getElementById('main-content');
    if (element) {
      element.focus();
    }
  }

  selectKeyword(selectedVal: string) {
    const url = this.router.serializeUrl(
      this.router.createUrlTree(['eml/form'], {
        queryParams: { recordId: selectedVal },
      }),
    );
  }

  home() {
    this.router.navigate(['/']);
  }

  vulnerabilityManagement(): void {
    window.open(this.vulMgmtUrl);
  }

  investigativePortal() {
    this.router.navigate(['/Investigative']);
  }

  editInquiries() {
    window.open(this.editInqUrl);
  }

  support() {
    window.location.href = this.adminUrl;
  }

  userManagement() {
    window.open(this.userMgmtUrl + '/#/list');
  }

  eml() {
    window.open(this.emlurl);
  }

  toggleDropdown(name: string) {
    this.currentOpen = this.currentOpen === name ? null : name;
  }

  @HostListener('document:click', ['$event'])
  clickOutside(event: MouseEvent) {
    const target = event.target as HTMLElement;
    if (!this.eRef.nativeElement.contains(target) && !target.classList.contains('show-toggle')) {
      this.currentOpen = null;
    }
  }

  openExternalLink(link: string) {
    this.currentOpen = null;
    let url = '';
    if (link === 'lms') {
      url = environment?.extended.trainingUrls?.lms ?? '';
    }
    if (link === 'reports') {
      url = this.reportUrl + '/projects';
    }
    if (link === 'userSupportPortal') {
      url = this.appUrl + '/UserSupportPortal/';
    }
    // if (link === 'schdule') {
    //   this.openLink('./assets/pdfs/fpstrainingschdule.pdf', navigationTypes.WINDOWOPEN);
    // }
    // if (link === 'lmsuser') {
    //   this.openLink('./assets/pdfs/Accel_LMS_Quick_User_Guide.pdf', navigationTypes.WINDOWOPEN);
    // }
    if (link === 'releasenotes') {
      this.openLink('./assets/pdfs/Release_Notes.pdf', navigationTypes.WINDOWOPEN);
    }
    if (url.length > 0) {
      window.open(url, '_blank');
    }
  }

  markMsgsAsReadByUser() {}

  downloadTrainingDoc(name: string): void {
    this.currentOpen = null;
    this._loader.show();
    this.fileService.downloadTrainingDocs(name).subscribe({
      next: (res: any) => {
        this._loader.hide();
      },
      error: (err: any) => {
        this._loader.hide();
        this.toaster.error('Unable to download document due to' + err.status);
      },
    });
  }

  toggleSystemMessageList(i: any) {
    this.showMoreSystemMessageTxt[i] = !this.showMoreSystemMessageTxt[i];
  }

  newRequest() {
    window.open(environment.newUserRoleRequestUrl, '_blank');
  }

  isValidNotificationList(list: any): boolean {
    return Array.isArray(list) && list.length > 0;
  }

  async logout() {
    console.log('logout triggered!');
    this.okta.signOut();
  }

  handleKeydown(event: KeyboardEvent, context: string): void {
    if (event.key === 'Enter' || event.key === ' ') {
      if (context === 'releasenotes') {
        this.openExternalLink('releasenotes');
      } else {
        // this.openLink(context, navigationTypes.WINDOWHREF)
      }
    }
  }
  isMacMedic(): boolean {
    return !!(
      this.user?.groups?.includes(allRoleTypes.ROLE_MAC) ||
      this.user?.groups?.includes(allRoleTypes.ZONE_MEDIC)
    );
  }
  isAuthorizedEndUser(): boolean {
    return !!(
      this.user?.groups?.includes(allRoleTypes.ROLE_INQUIRY) ||
      this.user?.groups?.includes(allRoleTypes.ROLE_PRIORITY_SUP) ||
      this.user?.groups?.includes(allRoleTypes.ROLE_MAC) ||
      this.user?.groups?.includes(allRoleTypes.ROLE_ADMIN)
    );
  }

  hasVulnerabilityManagementAccess(): boolean {
    return (
      this.isAuthorizedEndUser() &&
      !!(
        this.user?.groups?.includes(allRoleTypes.VM_ADMIN) ||
        this.user?.groups?.includes(allRoleTypes.VM_CREATE) ||
        this.user?.groups?.includes(allRoleTypes.VM_READ) ||
        this.user?.groups?.includes(allRoleTypes.VM_UPDATE)
      )
    );
  }

  hasEditInquiriesAccess(): boolean {
    return (
      this.isAuthorizedEndUser() &&
      !!(
        this.user?.groups?.includes(allRoleTypes.EI_ADMIN) ||
        this.user?.groups?.includes(allRoleTypes.EI_READ) ||
        this.user?.groups?.includes(allRoleTypes.EI_WRITE)
      )
    );
  }

  hasUserManagementAccess(): boolean {
    return (
      this.isAuthorizedEndUser() &&
      !!(
        this.user?.groups?.includes(allRoleTypes.UM_IO_APPROVER) ||
        this.user?.groups?.includes(allRoleTypes.UM_DMA_APPROVER) ||
        this.user?.groups?.includes(allRoleTypes.UM_MASTER_APPROVER) ||
        this.user?.groups?.includes(allRoleTypes.UM_MAC_APPROVER)
      )
    );
  }

  hasEditDevelopmentGuideAccess(): boolean {
    return (
      this.isAuthorizedEndUser() &&
      !!(
        this.user?.groups?.includes(allRoleTypes.EDITS_MANAGER) ||
        this.user?.groups?.includes(allRoleTypes.EDITS_DEVELOPER) ||
        this.user?.groups?.includes(allRoleTypes.DMA) ||
        this.user?.groups?.includes(allRoleTypes.DISM)
      )
    );
  }

  hasEMLAccess(): boolean {
    return (
      this.isAuthorizedEndUser() &&
      !!(
        this.user?.groups?.includes(allRoleTypes.MODEL_MANAGER) ||
        this.user?.groups?.includes(allRoleTypes.MODEL_DEVELOPER) ||
        this.user?.groups?.includes(allRoleTypes.DMA) ||
        this.user?.groups?.includes(allRoleTypes.DISM) ||
        this.user?.groups?.includes(allRoleTypes.SYS_MAINTAIN) ||
        this.user?.groups?.includes(allRoleTypes.EDITS_MANAGER) ||
        this.user?.groups?.includes(allRoleTypes.MODEL_OPS)
      )
    );
  }

  hasAdminAccess(): boolean {
    return this.isAuthorizedEndUser() && !!this.user?.groups?.includes(allRoleTypes.ROLE_ADMIN);
  }

  async openLink(link: string, type?: string, target?: any) {
    //  await this.navigationService.navigateWithCheck(link, type, target);
  }

  skipToMain(event: Event): void {
    event.preventDefault();

    const mainEl =
      (document.querySelector('main[role="main"]') as HTMLElement) || (document.getElementById('main-content') as HTMLElement) ||
      (document.getElementById('fps-home-main') as HTMLElement | null);

    if (mainEl) {
      if (!mainEl.hasAttribute('tabindex')) {
        mainEl.setAttribute('tabindex', '-1');
      }
      mainEl.focus({ preventScroll: false });
    }
  }

  openCustomSearch() {
    this.dialog.open(CustomSearchDialogComponent, {
      panelClass: 'ip-dialog-panel',
      width: '60%',
      data: {
        mode: 'newSearch',
        refData: this.searchRefData,
      },
    });
  }

  checkAsrId() {
    const val = this.searchVal;
    const regex = /^[0-9]{10}$/;
    if (!regex.test(val)) return;

    const payload: any = {};
    payload.asrptId = val;
    payload.searchType = 'QUICK'; //pass QUICK to denote a quick search
    payload.programType = this.okta.defaultAsrView();
    this._loader.show();
    this._searchService.customSearch(payload).subscribe((res: any) => {
      let type, asrId;
      if (res.responseData.length && res.responseDataMdcd.length) {
        type = payload.programType;
        asrId = type === 'medicare' ? res.responseData[0].asrDbid : res.responseDataMdcd[0].asrDbid;
      } else if (res.responseData.length) {
        type = 'medicare';
        asrId = res.responseData[0].asrDbid;
      } else if (res.responseDataMdcd.length) {
        type = 'medicaid';
        asrId = res.responseDataMdcd[0].asrDbid;
      } else {
        this._loader.hide();
        this.toaster.error('No ASR Found for ' + val);
        return;
      }
      this._loader.hide();
      this.router.navigate(['Investigative/Details'], {
        queryParams: {
          asrId: asrId,
          viewParam: type,
        },
      });
      console.log(res);
    });
  }
}
