import { Component, OnInit } from '@angular/core';
import { OktaService } from '../../../services/okta';
import { HomePageService } from '../../../services/homepage.service';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Title } from '@angular/platform-browser';


@Component({
  selector: 'app-landing',
  templateUrl: './landing.html',
  styleUrl: './landing.scss',
  standalone: false,
})
export class LandingComponent implements OnInit {
  homepageTiles: any[] = [];
  cols = 4;
  isLoading = true;

  constructor(
    private title: Title,
    public okta: OktaService,
    private homePageService: HomePageService,
    private breakpointObserver: BreakpointObserver
  ) {
     this.title.setTitle('FPS');
  }

  ngOnInit(): void {
    this.fetchHomeTile();

    this.breakpointObserver
      .observe([
        Breakpoints.XSmall,
        Breakpoints.Small,
        Breakpoints.Medium,
        Breakpoints.Large,
        Breakpoints.XLarge,
      ])
      .subscribe((state) => {
        if (state.breakpoints[Breakpoints.XSmall]) {
          this.cols = 1;
        } else if (state.breakpoints[Breakpoints.Small]) {
          this.cols = 2;
        } else if (state.breakpoints[Breakpoints.Medium]) {
          this.cols = 3;
        } else {
          this.cols = 4;
        }
      });
  }

  fetchHomeTile(): void {
    this.isLoading = true;

    this.homePageService.getHomeTiles().subscribe({
      next: (response) => {
        this.homepageTiles = response.homepageTiles || [];
        this.isLoading = false;
      },
      error: () => {
        this.homepageTiles = [];
        this.isLoading = false;
      },
    });
  }

  trackUserActivity(type: string): void {
    // Will update later
  }
}
