export const MEDICARE_COLUMNS = [
  {
    key: 'asrId',
    label: 'ASR ID',
    custom: true,
    sortable: true,
    tooltip:
      "This column displays the FPS Alert Summary Record (ASR) ID, which is also the Provider's NPI number.",
    sticky: true,
  },
  {
    key: 'name',
    label: 'Name',
    custom: false,
    sortable: true,
    tooltip: "This column displays the Provider's name associated with the ASR ID.",
    sticky: true,
  },
  {
    key: 'clmTypeTxt',
    label: 'ASR Type',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the claim type associated with the ASR alerted provider based on a rolling 12 months of all claims data with the billing NPI for Part A and DME and rendering NPI for Part B. The data contained within this table is updated weekly.',
  },
  {
    key: 'specialtyTxt',
    label: 'ASR Specialty',
    custom: false,
    sortable: true,
    tooltip:
      "This column displays the specialty codes associated with the ASR ID's claims at risk.",
  },
  {
    key: 'enrollmentStus',
    label: 'Provider Enrollment Status',
    custom: false,
    sortable: true,
    tooltip:
      "This column displays the ASR's most recent enrollment status ID by the effective date listed in PECOS.",
  },
  {
    key: 'enrollmentStusDesc',
    label: 'Provider Enrollment Status Description',
    custom: false,
    sortable: true,
    tooltip:
      "This column displays the ASR's most recent enrollment status ID description by the effective date listed in PECOS.",
  },
  {
    key: 'p1NewAlerts',
    label: 'Phase 1 New Alerts',
    custom: false,
    sortable: true,
    tooltip:
      "A model's name displayed in this column indicates an alert was created for the ASR ID based on the provider's submitted claims data during the most recent model run or in the timeframe indicated by the modeler for a new status (e.g., 14 days)",
  },
  {
    key: 'p1Cost',
    label: 'Phase 1 ASR Cost',
    custom: true,
    sortable: true,
    tooltip:
      'This column displays the total submitted amount based on claims-at-risk for Phase 1 alerts within the last 14 days and is updated daily.',
  },
  {
    key: 'p1SubjZoneCd',
    label: 'Phase 1 Jurisdiction',
    custom: false,
    sortable: true,
    tooltip:
      "This column displays the UPIC Jurisdiction assigned the ASR for Phase 1. ASR's that have a Phase 1 alert 14 days or older will display 'N/A' for the Jurisdiction.",
  },
  {
    key: 'revocation',
    label: 'Revocation',
    custom: true,
    sortable: true,
    tooltip:
      "This column indicates the Provider's revocation status per the Provider Enrollment, Chain, and Ownership System (PECOS) and is updated weekly. Review additional vocation details by navigation to the ASR Details page and clicking on the 'Yes' hyperlink in the Additional Provider Information section.",
  },
  {
    key: 'wsLabel',
    label: 'Working Set',
    custom: true,
    sortable: true,
    tooltip:
      "This column displays 'Yes' to indicate if the ASR is in a working set owned by you, owned by someone in your jurisdiction, or both. A 'No' displayed in this column indicates the ASR is not in your working set and is not in a working set owned by someone in your jurisdiction.",
  },
  {
    key: 'lastClmDt',
    label: 'Last Claim Submitted Date',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the date that the ASR alerted provider last submitted a Part A, B or DME claim based on all claims. The data contained within this table is updated weekly.',
  },
  {
    key: 'lastAlertClmDt',
    label: 'Last Alerted Claim Date of Service',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the latest from date of service based on claims at risk. The data contained within this table is updated weekly.',
  },
  {
    key: 'lastEduDt',
    label: 'Last Date of Education',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the latest date recorded in UCM that the ASR alerted provider was educated.',
  },
  {
    key: 'prvdrEduProvBy',
    label: 'Last Education Provided By',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the contractor that provided the latest education to the ASR alerted provider.',
  },
  {
    key: 'tpeReviewRnd',
    label: 'TPE Review Round',
    custom: false,
    sortable: true,
    tooltip: 'This column displays the probe cycle.',
  },
  {
    key: 'tpeEduOffered',
    label: 'TPE Education Offered',
    custom: false,
    sortable: true,
    tooltip:
      'Accepted displayed in this column indicates that the subject NPI was offered and accepted TPE Intra-Probe Education, Not Accepted indicates that the subject NPI was offered but did not accept TPE Intra-Probe Education, Not Offered indicates the subject NPI was not offered TPE Intra-Probe Education, No Response indicates that the subject NPI was offered but did not respond to TPE Intra-Probe Education, and N/A indicates the subject NPI does not have associated TPE data. See ASR Details page for full details.',
  },
  {
    key: 'lastDateOfTpeEducation',
    label: 'Last Date of TPE Education',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the latest date the ASR alerted provider received TPE. To access the full TPE details, navigate to the TPE tab on the ASR Details page.',
  },
  {
    key: 'tpeReviewTopic',
    label: 'TPE Review Topic',
    custom: false,
    sortable: true,
    tooltip:
      "This column displays the topics included in the ASR alerted provider's TPE education. To access the full TPE details, navigate to the TPE tab on the ASR Details page.",
  },
  {
    key: 'tpeRefRsn',
    label: 'TPE Referral Reason',
    custom: false,
    sortable: true,
    tooltip: 'This column displays the TPE data referral reason description.',
  },
  {
    key: 'postEdInd',
    label: 'Post-Ed 90 Day Flag',
    custom: false,
    sortable: true,
    tooltip:
      "This column utilizes a machine learning algorithm to display a 'Y' if the subject NPI continued the same billing pattern 90 days after the last date of education, an 'N' if the subject NPI did not continue the same billing pattern 90 days after the last date of education, or 'New Alert' if the provider has significantly changed their billing behavior; however, the provider began alerting on a model for which they had no alert history prior to the education date. If the subject NPI's last date of education is less than 90 days ago '< 90 days' will display and if the subject NPI has not received education the column will display 'N/A'. See the Support Portal regarding an 'Untestable' flag.",
  },
  {
    key: 'acoInd',
    label: 'ACO',
    custom: false,
    sortable: true,
    tooltip:
      'A "Y" displayed in this column indicates the ASR is a member of an Accountable Care Organization (ACO) and an "N" displayed in this column indicates the ASR is not a member of an ACO.',
  },
  {
    key: 'submitAmt',
    label: 'Submitted Amount',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the total amount submitted by the ASR alerted provider based on all claims for Part A, B and DME for a rolling one year timeframe. The data contained within this table is updated weekly.',
  },
  {
    key: 'totalPayment',
    label: 'Total Payment',
    custom: false,
    sortable: true,
    tooltip:
      'The column displays the total payment amount paid based on Part A, B, and DME all claims for a rolling one year timeframe and is updated weekly.',
  },
  {
    key: 'uniqueAlertBenesCnt',
    label: 'Bene Count',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the number of unique beneficiaries that the ASR alerted provider was paid for based on all claims for Part A, B and DME for a rolling one year timeframe. The data contained within this table is updated weekly.',
  },
  {
    key: 'viewBillingNPI',
    label: 'Billing NPIs',
    custom: true,
    sortable: true,
    tooltip:
      "This column displays the Billing Provider NPIs corresponding to the associated ASR ID if the ASR's NPI is listed as the Rendering NPI, Attending NPI, or the same as the Billing NPI for claims at risk. The data contained within this table is updated from the last model run. If the Billing NPI is an ASR, the Jurisdiction displayed is the ASR UPIC Jurisdiction associated with claims at risk. If the Billing NPI is not an ASR, the Jurisdiction displayed is the UPIC Jurisdiction associated with all claims.",
  },
  {
    key: 'claimLinesCnt',
    label: 'Claim Count',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the number of unique claims the ASR alerted provider was paid for based on all claims for Part A, B and DME for a rolling one year timeframe. The data contained within this table is updated weekly.',
  },
  {
    key: 'earliestClmDt',
    label: 'Earliest Claim during Report Timeframe',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the date that the ASR alerted provider first submitted a claim based on all claims for Part A, B and DME for a rolling one year timeframe. The data contained within this table is updated weekly.',
  },
  {
    key: 'submitDAmt',
    label: 'Submitted Amount Part D',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the total amount submitted by the ASR alerted provider based on all claims for Part D for a rolling one year timeframe. The data contained within this table is updated weekly.',
  },
  {
    key: 'totalPaymentD',
    label: 'Total Payment – Part D',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the total amount paid based on Part A, B, and DME all claims for a rolling one year timeframe and is updated weekly.',
  },
  {
    key: 'beneDCnt',
    label: 'Bene Count – Part D',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the number of unique beneficiaries that the ASR alerted provider was paid for based on all claims for Part D for a rolling one year timeframe. The data contained within this table is updated weekly.',
  },
  {
    key: 'claimLinesDCnt',
    label: 'Claim Count – Part D',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the number of unique claims the ASR alerted provider was paid for based on all claims for Part D for a rolling one year timeframe. The data contained within this table is updated weekly.',
  },
  {
    key: 'riskScore',
    label: 'Risk Score',
    custom: true,
    sortable: true,
    tooltip:
      'This column displays the risk score associated with the ASR ID. It is derived utilizing the methodology displayed in the ASR Risk Score Methodology column. For more details, please see the Enhanced Risk Score Explainability section located in the Machine Learning 101 section of the Support Portal and in the Provider Info section and in the model report card on the ASR Details page. To access the Risk Score Trending Report, navigate to the Risk Score Trending tab.',
  },
  {
    key: 'riskScoreMethod',
    label: 'ASR Risk Score Methodology',
    custom: false,
    sortable: true,
    tooltip:
      "This column displays the method used to calculate the ASR Risk Score. 'Legacy' indicates the ASR Risk Score was calculated utilizing statistical methods. 'Enhanced' indicates the ASR Risk Score was calculated utilizing Machine Learning logic. 'Enhanced - Min. Risk Rule' indicates that the ASR Minimum Risk Rule was used. See the Support Portal for more details.",
  },
  {
    key: 'priorityScore',
    label: 'Priority Score',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the priority score associated with the ASR ID. To access the priority score criteria and the individual criteria score, navigate to the ASR details page and select the Priority Score tab.',
  },
  {
    key: 'actionability',
    label: 'Actionability',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the likelihood that an ASR will result in an administrative action based on the Priority Score criteria results. To access the priority score criteria and the individual criteria score, navigate to the ASR Details page and select the priority score hyperlink in the provider info pane.',
  },
  {
    key: 'timeliness',
    label: 'Timeliness',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the approximate timeframe it will take for the ASR to result in an administrative action based on machine learning.',
  },
  {
    key: 'pathToEduInd',
    label: 'Path to Education',
    custom: true,
    sortable: true,
    tooltip:
      "This column displays 'Yes' or 'No' to indicate if the ASR has alerted in the past 180 days on a model flagged for having a known Path to Education.",
  },
  {
    key: 'newAlerts',
    label: 'New Alerts',
    custom: false,
    sortable: true,
    tooltip:
      "A model's name displayed in this column indicates an alert was created for the ASR ID during the most recent model run or in the last 30 days.",
  },
  {
    key: 'agedAlerts',
    label: 'Aged Alerts',
    custom: false,
    sortable: true,
    tooltip:
      "A model's name displayed in this column indicates the ASR ID did not alert in the most recent model run or last alerted for the identified model between 31 and 180 days ago. A blank column or no model name indicates the ASR ID does not have an alert that meets the aged criteria.",
  },
  {
    key: 'relLastAlertDt',
    label: 'Latest Alert Created Date',
    custom: true,
    sortable: true,
    tooltip:
      'This column displays the timeframe since the ASR last alerted for any model. To review the actual alert date, hover over the timeframe displayed.',
  },
  {
    key: 'cost',
    label: 'ASR Cost',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the total amount paid based on claims-at-risk for alerts within the last 180 days and is updated weekly.',
  },
  {
    key: 'subjectStateCd',
    label: 'Provider Practice State',
    custom: false,
    sortable: true,
    tooltip:
      "This column displays the Provider's practice state per the Provider Enrollment, Chain, and Ownership System (PECOS) and is updated weekly.",
  },
  {
    key: 'prvdrPlaceNm',
    label: 'Provider Practice City',
    custom: false,
    sortable: true,
    tooltip:
      "This column displays the Provider's practice city per the Provider Enrollment, Chain, and Ownership System (PECOS) and is updated weekly.",
  },
  {
    key: 'topCityStateTxt',
    label: 'Claim Top City and State',
    custom: false,
    sortable: true,
    tooltip:
      "This column displays the ASR's top 5 cities and states by total paid amount. The cities and states are derived from the ASR's practice location listed in the claims at risk data for Part A and Part B providers and the Beneficiaries' location listed in the claims data for DME suppliers. The top city and state will not display if the ASR has not alerted in the last 180 days.",
  },
  {
    key: 'relatedAsrCnt',
    label: 'Number of Related ASRs',
    custom: false,
    sortable: true,
    tooltip:
      "This column displays the number of related ASR alerted providers based on claims data. Due to Part D models only alerting on prescribing providers, the Part D claims data will not be included in the related providers' logic. To view the related providers and their relationship type, navigate to the ASR Details page and select the Number of Related ASRs hyperlink in the Provider Info pane.",
  },
  {
    key: 'biuComplaints90Cnt',
    label: 'Total BIU Complaint Count last 90 Days',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the number of complaints reported by the Beneficiary Integrity Unit (BIU) system tag in the last 90 days.',
  },
  {
    key: 'biuComplaintsCnt',
    label: 'Total BIU Complaints Count',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the total number of complaints reported by the Beneficiary Integrity Unit (BIU) system tag.',
  },
  {
    key: 'biuCategory',
    label: 'BIU Summary',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays a summary of complaint details reported by the Beneficiary Integrity Unit (BIU) system tag.',
  },
  {
    key: 'cncStus',
    label: 'Subject PBNR Status',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the ASR alerted providers PBNR status.This data is refreshed from OnePI weekly.',
  },
  {
    key: 'zrType',
    label: 'ZR Status',
    custom: false,
    sortable: true,
    tooltip: "This column displays the ASR's Zone Restriction (ZR) status recorded in UCM.",
  },
  {
    key: 'prioritizedMyZone',
    label: 'Prioritized – My Jurisdiction',
    custom: true,
    sortable: true,
    tooltip:
      "'Yes' displayed in this column indicates a prioritized ASR in your jurisdiction, and 'No' indicates an ASR not prioritized in your jurisdiction.  To access UCM prioritization details, navigate to the ASR Details page and select the 'Yes' hyperlink.",
  },
  {
    key: 'prioritizedOtherZone',
    label: 'Prioritized – Not My Jurisdiction',
    custom: true,
    sortable: true,
    tooltip:
      "'Yes' displayed in this column indicates a prioritized ASR not in your jurisdiction, and 'No' indicates an ASR not prioritized not in your jurisdiction.  To access UCM prioritization details, navigate to the ASR Details page and select the 'Yes' hyperlink.”",
  },
  {
    key: 'dualBeneCntInd',
    label: 'Dual Eligible Bene',
    custom: false,
    sortable: true,
    tooltip:
      "This column displays the count of dual-eligible (Medicare and Medicaid) beneficiaries that the ASR alerted provider submitted claims for in the last year based on all claims data. The column will display a '0' if the alerted ASR provider has no dual-eligible beneficiaries.",
  },
  {
    key: 'nonAlertedPrvdrInd',
    label: 'Non-Alerted ASR',
    custom: true,
    sortable: true,
    tooltip:
      "'Yes' displayed in this column indicates the ASR type is FPS related. 'No' in this column indicates the ASR's type is Alerted.",
  },
  {
    key: 'medicaid',
    label: 'External Medicaid Alert',
    custom: true,
    sortable: true,
    tooltip:
      "This column indicates if a provider is identified outside the FPS system as potentially risky in Medicaid state claims data.  To review the Medicaid risky behavior details, navigate to the Medicare ASR Details page and select the 'Yes' hyperlink.",
  },
  {
    key: 'subjectZoneCd',
    label: 'Jurisdiction',
    custom: false,
    sortable: true,
    tooltip:
      "This column displays the UPIC and MEDIC Jurisdiction assigned to the ASR. ASR's that have an alert 181 days or older will display 'N/A' for the Jurisdiction.",
  },
  {
    key: 'mac',
    label: 'MAC Jurisdiction',
    custom: false,
    sortable: true,
    tooltip: 'This column displays the MAC Jurisdiction assigned to the ASR.',
  },
  {
    key: 'macCntrctrNum',
    label: 'MAC Contractor IDs',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the MAC contractor IDs based on all claims for Part A, B and DME for a rolling one year timeframe. The data contained within this table is updated weekly.',
  },
  {
    key: 'ucmCaseStus',
    label: 'UCM Record Status',
    custom: false,
    sortable: true,
    tooltip: 'This column displays the most recent record status listed in UCM.',
  },
  {
    key: 'leadInd',
    label: 'Lead Indicator',
    custom: true,
    sortable: true,
    tooltip:
      "This column displays 'Yes' if there is an open lead in UCM or 'No' if there is not an open lead in UCM.",
  },
  {
    key: 'mostRecentUcmClsdDt',
    label: 'Most Recent UCM Closed Date',
    custom: false,
    sortable: true,
    tooltip: 'This column displays the latest date that an investigation was closed in UCM.',
  },
  {
    key: 'ucmCaseIds',
    label: 'UCM Case IDs',
    custom: false,
    sortable: true,
    tooltip: 'This column displays all case IDs listed in UCM.',
  },
  {
    key: 'ucmSummary',
    label: 'UCM Summary',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays all administrative actions and associated effective dates per UCM.',
  },
  {
    key: 'crossoverLinesCnt',
    label: '#Xover Lines',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the number of alerting claims at risk lines for the ASR ID that cross over to a secondary payer.',
  },
  {
    key: 'createdDt',
    label: 'Created',
    custom: false,
    sortable: true,
    tooltip: 'This column displays the date and time that FPS created the ASR.',
  },
];

export const MEDICAID_COLUMNS = [
  {
    key: 'asrId',
    label: 'ASR ID',
    custom: true,
    sortable: true,
    tooltip:
      "This column displays the FPS Alert Summary Record (ASR) ID, which is also the Provider's NPI number.",
    sticky: true,
  },
  {
    key: 'name',
    label: 'Name',
    custom: false,
    sortable: true,
    tooltip: "This column displays the Provider's name associated with the ASR ID.",
    sticky: true,
  },
  {
    key: 'mdcdSvcSubCat',
    label: 'Medicaid Alerted Service Subcategory',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the claim type associated with the ASR alerted provider based on 90 days of claims at risk data for MCO and FFS. The data contained within this table is updated with each model run.',
  },
  {
    key: 'mdcdSpecialty',
    label: 'Medicaid Alerted ASR Specialty',
    custom: false,
    sortable: true,
    tooltip:
      "This column displays the specialty codes associated with the ASR ID's claims at risk.",
  },
  {
    key: 'enrollmentStus',
    label: 'Provider Enrollment Status',
    custom: false,
    sortable: true,
    tooltip:
      "This column displays the ASR's most recent enrollment status ID by the effective date listed in PECOS.",
  },
  {
    key: 'enrollmentStusDesc',
    label: 'Provider Enrollment Status Description',
    custom: false,
    sortable: true,
    tooltip:
      "This column displays the ASR's most recent enrollment status ID description by the effective date listed in PECOS.",
  },
  {
    key: 'enrollmentStusLink',
    label: 'Medicaid Provider Enrollment Status',
    custom: true,
    sortable: true,
    tooltip:
      'This column displays the Medicaid ID, State, Enrollment Status Description, Effective Date and Termination Date for each state listed in the Medicaid Provider Segment Source of data from the states. For providers that have no termination date, the date will display as 9999/12/31.',
  },
  {
    key: 'wsLabel',
    label: 'Working Set',
    custom: true,
    sortable: true,
    tooltip:
      "This column displays 'Yes' to indicate if the ASR is in a working set owned by you, owned by someone in your jurisdiction, or both. A 'No' displayed in this column indicates the ASR is not in your working set and is not in a working set owned by someone in your jurisdiction.",
  },
  {
    key: 'lastClmDt',
    label: 'Medicaid Last Alerted Claim Date of Service',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the latest from date of service based on claims at risk. The data contained in the column is updated quarterly.',
  },
  {
    key: 'mdcdSubmitAmt',
    label: 'Medicaid Alerted Submitted Amount',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the total amount submitted by the ASR alerted provider based on alerted claims at risk from the last model run.',
  },
  {
    key: 'mdcdTotalPmt',
    label: 'Medicaid Alerted Total Payment',
    custom: true,
    sortable: true,
    tooltip:
      'This column displays the total amount paid to the ASR alerted provider based on alerted claims at risk from the last model run.',
  },
  {
    key: 'mdcdRecipientCnt',
    label: 'Medicaid Alerted Recipient Count',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the number of unique Medicaid recipients that the ASR alerted provider was paid for based on alerted claims at risk.',
  },
  {
    key: 'mdcdClmCnt',
    label: 'Medicaid Alerted Claim Count',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays the number of unique Medicaid claims the ASR alerted provider was paid for based on alerted claims at risk from the last model run.',
  },
  {
    key: 'mdcdBillingNpi',
    label: 'Medicaid Alerted Billing Provider NPI',
    custom: false,
    sortable: true,
    tooltip:
      "This column displays the Billing Provider NPIs corresponding to the associated ASR ID if the ASR's NPI is listed as the Rendering NPI, Attending NPI, or the same as the Billing NPI for claims at risk. The data contained within this table is updated from the last model run.",
  },
  {
    key: 'mdcdRiskScore',
    label: 'Medicaid Risk Score',
    custom: false,
    sortable: true,
    tooltip: 'This column displays the Medicaid ASR Risk Score associated with the ASR ID.',
  },
  {
    key: 'mdcdNewAlerts',
    label: 'Medicaid New Alerts',
    custom: false,
    sortable: true,
    tooltip:
      "A model's name displayed in this column indicates an alert was created for the ASR ID during the most recent model run or within the last 90 days.",
  },
  {
    key: 'mdcdAgedAlerts',
    label: 'Medicaid Aged Alerts',
    custom: false,
    sortable: true,
    tooltip:
      "A model's name displayed in this column indicates the ASR ID did not alert in the most recent model run or last alerted for the identified model between 91 and 365 days ago. A blank column or no model name indicates the ASR ID does not have an alert that meets the aged criteria.",
  },
  {
    key: 'relLastAlertDt',
    label: 'Medicaid Latest Alert Created Date',
    custom: true,
    sortable: true,
    tooltip:
      'This column displays the timeframe since the ASR last alerted for any Medicaid model. To review the actual alert date, hover over the timeframe displayed.',
  },
  {
    key: 'zrType',
    label: 'ZR Status',
    custom: false,
    sortable: true,
    tooltip: "This column displays the ASR's Zone Restriction (ZR) status recorded in UCM.",
  },
  {
    key: 'medicaid',
    label: 'External Medicaid Alert',
    custom: true,
    sortable: true,
    tooltip:
      "This column indicates if a provider is identified outside the FPS system as potentially risky in Medicaid state claims data.  To review the Medicaid risky behavior details, navigate to the Medicaid ASR Details page and select the 'Yes' hyperlink.",
  },
  {
    key: 'mdcdStates',
    label: 'Medicaid Alerted States',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays all states with Medicaid alerts associated with the ASR ID. This column is updated from the last model run.',
  },
  {
    key: 'ucmCaseStus',
    label: 'UCM Record Status',
    custom: false,
    sortable: true,
    tooltip: 'This column displays the most recent record status listed in UCM.',
  },
  {
    key: 'leadInd',
    label: 'Lead Indicator',
    custom: true,
    sortable: true,
    tooltip:
      "This column displays 'Yes' if there is an open lead in UCM or 'No' if there is not an open lead in UCM.",
  },
  {
    key: 'mostRecentUcmClsdDt',
    label: 'Most Recent UCM Closed Date',
    custom: false,
    sortable: true,
    tooltip: 'This column displays the latest date that an investigation was closed in UCM.',
  },
  {
    key: 'ucmCaseIds',
    label: 'UCM Case IDs',
    custom: false,
    sortable: true,
    tooltip: 'This column displays all case IDs listed in UCM.',
  },
  {
    key: 'ucmSummary',
    label: 'UCM Summary',
    custom: false,
    sortable: true,
    tooltip:
      'This column displays all administrative actions and associated effective dates per UCM.',
  },
];

export const BILLING_NPI_COLUMNS = [
  { key: 'modelBusnsId', label: 'Model', sortable: true },
  { key: 'npiAlertTypeCd', label: 'Alerted Provider Type', sortable: true },
  { key: 'clmBlngPrvdrNpiNum', label: 'Alerted Billing NPI', sortable: true, custom: true },
  { key: 'rltdPrvdrName', label: 'Billing Provider Name', sortable: true },
  { key: 'clmSrcType', label: 'Claim Type', sortable: true },
  { key: 'upicJrsdctn', label: 'Jurisdiction', sortable: true },
  { key: 'clmSbmtAmt', label: 'Submitted Amount', sortable: true },
  { key: 'clmPmtAmt', label: 'Total Payment', sortable: true },
  { key: 'clmBeneCnt', label: 'Bene Count', sortable: true },
];

export const P1_COST_COLUMNS = [
  {
    key: 'zone',
    label: 'Phase 1 Jurisdiction',
    sortable: true,
    tooltip:
      'This column shall display each UPIC Jurisdiction with claims at risk associated with all model alerts created within the last 14 days for the ASR.',
  },
  {
    key: 'totalCost',
    label: 'Phase 1 ASR Cost',
    sortable: true,
    tooltip:
      'This column shall display the total submitted amount for claims at risk associated with the Jurisdiction. Field will display as a numerical value up to 2 decimal places.',
  },
  {
    key: 'totalClaimLines',
    label: 'Phase 1 Number of Claims',
    sortable: true,
    tooltip:
      'This column shall display the total submitted claims at risk associated with the Jurisdiction. Field will display as a numerical value.',
  },
];

export const ENROLLMENT_ID_COLUMNS = [
  { key: 'mdcdId', label: 'Medicaid ID', sortable: true },
  { key: 'state', label: 'State', sortable: true },
  { key: 'status', label: 'Enrollment Status', sortable: true },
  { key: 'efctvDt', label: 'Effective Date', sortable: true },
  { key: 'termDt', label: 'Termination Date', sortable: true },
];

export const MDCD_TOTAL_PAYMENT_COLUMNS = [
  {
    key: 'modelNm',
    label: 'Model Name',
    sortable: true,
    tooltip: 'This column displays the name of the Medicaid model associated with ASR ID.',
  },
  {
    key: 'states',
    label: 'Medicaid Alerted States',
    sortable: true,
    tooltip:
      'This column displays all states with Medicaid alerts associated with the ASR ID. This column is updated from the last model run.',
  },
  {
    key: 'role',
    label: 'Medicaid Alerted Provider Role',
    sortable: true,
    tooltip:
      'This column displays the provider role from the header and/or claim line that the model alerted on.',
  },
  {
    key: 'billingNpi',
    label: 'Medicaid Alerted Billing Provider NPI',
    sortable: true,
    tooltip:
      "This column displays the Billing Provider NPIs corresponding to the associated ASR ID if the ASR's NPI is listed as the Rendering NPI, Attending NPI, or the same as the Billing NPI for claims at risk. The data contained within this table is updated from the last model run.",
  },
  {
    key: 'svcCat',
    label: 'Medicaid Alerted Service Category',
    sortable: true,
    tooltip: 'This column displays the Service Category from the alerted claims at risk.',
  },
  {
    key: 'mcoSubmitAmt',
    label: 'MCO Alerted Submitted Amount',
    sortable: true,
    tooltip:
      'This column displays the total amount submitted by the ASR alerted provider for MCO alerted claims.',
  },
  {
    key: 'mcoTotalPmt',
    label: 'MCO Alerted Total Payment',
    sortable: true,
    tooltip:
      'This column displays the total amount paid to the ASR alerted provider for MCO alerted claims.',
  },
  {
    key: 'mcoPlan',
    label: 'MCO Alerted Total Payment Plan',
    sortable: true,
    tooltip: 'This column displays the MCO plan name and plan ID for the ASR alerted provider.',
  },
  {
    key: 'mcoRecipCnt',
    label: 'Medicaid Alerted Recipient by MCO',
    sortable: true,
    tooltip:
      'This column displays the number of unique Medicaid recipients that the ASR alerted provider was paid for MCO alerted claims.',
  },
  {
    key: 'ffsSubmitAmt',
    label: 'FFS Alerted Submitted Amount',
    sortable: true,
    tooltip:
      'This column displays the total amount submitted by the ASR alerted provider for FFS alerted claims.',
  },
  {
    key: 'ffsTotalPmt',
    label: 'FFS Alerted Total Payment',
    sortable: true,
    tooltip:
      'This column displays the total amount paid to the ASR alerted provider for FFS alerted claims.',
  },
  {
    key: 'ffsRecipCnt',
    label: 'Medicaid Alerted Recipient by FFS',
    sortable: true,
    tooltip:
      'This column displays the number of unique Medicaid recipients that the ASR alerted provider was paid for based on FFS alerted claims.',
  },
];

export const Prioritize_Columns = [
  {
    key: 'npi',
    label: 'ASR ID',
    sortable: true,
  },
  {
    key: 'providerName',
    label: 'Provider Name',
    sortable: true,
  },
  {
    key: 'alerts',
    label: 'Alerts',
    custom: true,
    tooltip:
      'This column displays a list of model names that the associated ASR ID has alerted on within the last 180 days. Selection of the models that led to prioritization is required.',
  },
  {
    key: 'comments',
    label: 'Comments',
    custom: true,
    tooltip:
      'This column provides the ability to enter a comment for the associated ASR and is required for ASRs with no alerts within the last 180 days.',
  },
];

export const Prioritize_MDCD_Columns = [
  {
    key: 'npi',
    label: 'ASR ID',
    sortable: true,
  },
  {
    key: 'providerName',
    label: 'Provider Name',
    sortable: true,
  },
  {
    key: 'alerts',
    label: 'Alerts',
    custom: true,
    tooltip:
      "This column displays a list of Medicaid model names that the associated ASR ID has alerted on within the last 365 days, whether that model alerted in state within that user's jurisdiction or not. Selection of the models that led to prioritization is required.",
  },
  {
    key: 'states',
    label: 'Medicaid Alerted States',
    custom: true,
    tooltip:
      "This column displays a list of states and the associated Medicaid model name selected in the 'Alerts' column that the associated ASR ID has alerted on within the last 365 days. Only the alerted states within the end user's jurisdiction are listed for selection to prioritize to UCM. Selection of a state for each model selected is required for prioritization.",
  },
  {
    key: 'comments',
    label: 'Comments',
    custom: true,
    tooltip:
      'This column provides the ability to enter a comment for the associated ASR and is required for ASRs with no alerts within the last 365 days.',
  },
];

