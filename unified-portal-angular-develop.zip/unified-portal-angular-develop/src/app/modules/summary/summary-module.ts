import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SummaryRoutingModule } from './summary-routing-module';
import { SummaryComponent } from './summary';
import { SharedModule } from "../../shared/shared.module";
import { MaterialModule } from '../../shared/material.module';
import { SummaryDetailsTableComponent } from './components/summary-details-table/summary-details-table';


const BASECOMPONENT = [
  SummaryComponent,
  SummaryDetailsTableComponent,
]

@NgModule({
  declarations: [...BASECOMPONENT],
  imports: [
    CommonModule,
    SummaryRoutingModule,
    SharedModule,
    MaterialModule,
]
})
export class SummaryModule { }
