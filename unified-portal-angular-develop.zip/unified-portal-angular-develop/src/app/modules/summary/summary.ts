import { Component, effect, QueryList, ViewChildren, viewChildren } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Card } from '../../shared/interface';
import { OktaService } from '../../services/okta';
import { TriageService } from '../../services/triage.service';
import { ActivatedRoute, NavigationEnd, NavigationStart, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { CustomSearchDialogComponent } from '../../shared/dialog/custom-search-dialog/custom-search-dialog';
import { LoaderService } from '../../services/loader.service';
import { allRoleTypes } from '../../utilities/constants';
import { allOrgTypes } from '../../utilities/constants';
import { User } from '../../models/user.model';
import { TableComponent } from '../../shared/table/table';
import { filter } from 'rxjs';
import { SearchService } from '../../services/search.service';
import { ToastService } from '../../services/toaster.service';
import { AddWorkingSetDialogComponent } from '../../shared/dialog/add-working-set-dialog/add-working-set-dialog';
import { AddExistingWorkingSetDialogComponent } from '../../shared/dialog/add-existing-working-set-dialog/add-existing-working-set-dialog';
import { ConfirmationDialogComponent } from '../../shared/dialog/confirmation-dialog/confirmation-dialog';
import { CommonDialogComponent } from '../../shared/dialog/common-dialog/common-dialog';
import {
  BILLING_NPI_COLUMNS,
  ENROLLMENT_ID_COLUMNS,
  MDCD_TOTAL_PAYMENT_COLUMNS,
  MEDICAID_COLUMNS,
  MEDICARE_COLUMNS,
  P1_COST_COLUMNS,
  Prioritize_Columns,
  Prioritize_MDCD_Columns,
} from './column-config';
import { SummaryDetailsTableComponent } from './components/summary-details-table/summary-details-table';
import { SaveSearchDialogComponent } from '../../shared/dialog/save-search-dialog/save-search-dialog';
import { PrioritizeUcmTableComponent } from '../../shared/prioritize-ucm/prioritize-ucm.component';

interface userPrefs {
  medicare: userPrefsObj;
  medicaid: userPrefsObj;
}

interface userPrefsObj {
  userId: string;
  prefName: string;
  prefJson: string;
}

interface StateData {
  responseData: any[];
  responseDataMdcd: any[];
  mdcdPrrtyEnabledInd: 'Y' | 'N';
  transactionId: string;
}

@Component({
  selector: 'app-summary',
  standalone: false,
  templateUrl: './summary.html',
  styleUrl: './summary.scss',
})
export class SummaryComponent {
  medicareColumns = MEDICARE_COLUMNS.map((column: any) => ({ ...column }));
  medicaidColumns = MEDICAID_COLUMNS.map((column: any) => ({ ...column }));

  userPrefs?: userPrefs;
  isActionMenuOpen: any;
  selectAllCheckbox: boolean = false;
  selectedMedicareRows: any[] = [];
  selectedMedicaidRows: any[] = [];
  medicareData: any[] = [];
  medicaidData: any[] = [];
  selectedTabIndex: number = 0;
  isLoading: boolean = true;
  searchRefData: any;
  stateData?: StateData;
  selectedSearchFilter: any;
  selectedSearchAsJson: any;
  selectedSearchProgramType: string = 'medicare';
  selectedWorkbenchType: string = '';
  selectedWorkbenchId: string = '';
  selectedWorkbenchName: string = '';
  selectedSavedSearchName: string = '';
  selectedSavedSearchId: string = '';
  user!: User;
  canPrioritize: boolean = false;
  workingSetData: any;
  isQpFetchInProgress: boolean = false;
  clearTrigger = 0;
  @ViewChildren('apptable') tables!: QueryList<TableComponent>;

  constructor(
    private title: Title,
    public okta: OktaService,
    private _triageService: TriageService,
    private route: ActivatedRoute,
    private router: Router,
    public dialog: MatDialog,
    private _loader: LoaderService,
    private _searchService: SearchService,
    private _toaster: ToastService,
  ) {
    this._setTriageTitle('Search Results');
    this._initData();
    const qp = this.route.snapshot.queryParams;

    // Use query parameters to execute saved search
    if (qp['workItemId'] || qp['model']) {
      this._fetchDataFromQp(qp);
    } else {
      // Found data from previous search
      if (this._searchService.searchData()) {
        const searchdata = this._searchService.searchData();

        // Change to bookmarkable URL (since previous data is from a SAVED-SEARCH)
        if (searchdata?.savedSearchId) {
          this.router.navigate(['/Investigative/Triage'], {
            queryParams: {
              type: 'search',
              workItemId: searchdata?.savedSearchId,
              asrType: searchdata?.programType === 'medicare' ? 'MDCR' : 'MDCD',
              listName: searchdata?.savedSearchName,
            },
          });
        }
      }

      // No search data found, go back to main route/page
      else {
        this._loader.hide();
        this.router.navigate(['/Investigative']);
        return;
      }
    }

    effect(() => {
      this.user = this.okta.user();
      this.canPrioritize = !!this.user?.groups?.includes(allRoleTypes.ROLE_PRIORITY_SUP);
      this.setData();
    });
  }

  setData() {
    if (!this._searchService.searchData()) return;
    const searchdata = this._searchService.searchData();
    this._setSelectedTabIndex(searchdata);
    this.medicareData = searchdata?.data?.responseData || [];
    this.medicaidData = searchdata?.data?.responseDataMdcd || [];
    this.selectedSearchFilter = searchdata.filter;
    this.selectedSearchAsJson = searchdata.prefJson;
    this.selectedSearchProgramType = String(searchdata?.programType || 'medicare').toLowerCase();
    this.selectedSavedSearchName = searchdata?.savedSearchName;
    this.selectedSavedSearchId = searchdata?.savedSearchId;

    this._setTriageTitle('Search Results');
    this._searchService.clearSearchData();
  }

  private _fetchDataFromQp(qp: any) {
    this.isQpFetchInProgress = true;
    this.selectedWorkbenchType = String(qp?.type || '').toLowerCase();
    this.selectedWorkbenchId = String(qp?.workItemId || '').trim();
    this.selectedWorkbenchName = String(qp?.listName || '').trim();
    this._setTriageTitle('Search Results');
    this._setSelectedTabIndex({programType : qp['asrType']})
    this._loader.show();
    let obs;
    if (qp['model']) {
      obs = this._triageService.getAsrInfoModelData(qp?.asrType, qp['model'], qp['runDt']);
    } else
      obs = this._triageService.searchWorkbenchItem(qp.workItemId, {
        type: qp?.type,
        asrType: qp?.asrType,
      });
    obs.subscribe({
      next: (res: any) => {
        const responseListName = String(res?.listNm || '').trim();
        this._setTriageTitle(responseListName || 'Search Results');
        this.selectedTabIndex = ['medicaid','MDCD'].includes(qp.asrType) ? 1 : 0;
        this.medicareData = res?.responseData || [];
        this.medicaidData = res?.responseDataMdcd || [];
        this.isQpFetchInProgress = false;
        this._loader.hide();
      },
      error: (err) => {
        this.isQpFetchInProgress = false;
        this._loader.hide();
        console.error(err);
      },
    });
  }

  private _setSelectedTabIndex(searchdata: any) {
    const programType = String(searchdata?.programType || '').toLowerCase();
    const isMedicaid = programType === 'medicaid';
    this.selectedTabIndex = isMedicaid && !this.okta.user()?.disableMedicaid ? 1 : 0;
  }

  get hideExistingWorkingSetBtn(): boolean {
    return this._getCurrentWorkingSets().length === 0;
  }

  get showRemoveFromWorkingSetBtn(): boolean {
    return this.selectedWorkbenchType === 'list';
  }

  get currerntSelectedRows() {
    return this.selectedTabIndex ? this.selectedMedicaidRows : this.selectedMedicareRows;
  }

  get asrType(): string {
    return this.selectedTabIndex === 1 ? 'medicaid' : 'medicare';
  }

  private _initData() {
    this._getPreferance();
    this._loader.show();
    this._getWorkingSet();
  }

  private _getWorkingSet() {
    this._triageService.getWorkingSet().subscribe((res: any) => {
      this.workingSetData = res;
    });
  }

  private _getPreferance() {
    this._triageService.retrieveUserPrefs().subscribe((res: userPrefs) => {
      this.userPrefs = res;
      this._setColumns();
    });
  }

  private _setColumns() {
    const MDCRcolumnsToHide = JSON.parse(this.userPrefs?.medicare.prefJson || '[]');
    const MDCDcolumnsToHide = JSON.parse(this.userPrefs?.medicaid.prefJson || '[]');

    this.medicareColumns.map((o: any) => {
      if (MDCRcolumnsToHide.includes(o.key)) o['visible'] = false;
      return o;
    });
    this.medicaidColumns.map((o: any) => {
      if (MDCDcolumnsToHide.includes(o.key)) o['visible'] = false;
      return o;
    });
    this.isLoading = false;
    if (!this.isQpFetchInProgress) {
      this._loader.hide();
    }
  }

  onTabChange(e: any) {
    setTimeout(() => {
      const table = this.tables.get(e.index);
      table?.refreshSticky();
    }, 100);
  }

  onCustomEvent(e: { action: string; data: any }) {
    if (e.action == 'saveUserPref') {
      this._triageService.updatePreference(e.data.columns, this.selectedTabIndex === 0).subscribe();
    }
  }

  openBillingNpiDialog(row: any) {
    const asrId = String(row?.asrId || '').trim();
    if (!asrId) {
      this._toaster.error('Unable to load Billing NPI details. Missing ASR ID.');
      return;
    }

    const asrType = this.selectedTabIndex === 1 ? 'medicaid' : 'medicare';
    const billingNpiColumns = BILLING_NPI_COLUMNS.map((column: any) => ({
      ...column,
      custom: !!column.custom || column.key === 'clmSbmtAmt' || column.key === 'clmPmtAmt',
    }));
    this._loader.show();
    this._triageService.getAsrDetailsData(asrId, 'BILLSUMM', asrType).subscribe({
      next: (res: any) => {
        const rowData = res?.responseData?.billSummary || [];
        this._loader.hide();

        this.openTableDialog(
          {
            title: 'Billing NPIs',
            info: 'This table displays the Billing Provider NPIs corresponding to the associated ASR ID if the ASR’s NPI is listed as the Rendering NPI, Attending NPI, or the same as the Billing NPI for claims at risk. The data contained within this table is updated from the last model run. If the Billing NPI is an ASR, the Jurisdiction displayed is the ASR UPIC Jurisdiction associated with claims at risk. If the Billing NPI is not an ASR, the Jurisdiction displayed is the UPIC Jurisdiction associated with all claims.',
            componentData: {
              rowData,
              columns: billingNpiColumns,
              tableName: 'Billing NPIs Table',
              tableId: 'billingNpiTable',
            },
            panelClass: 'ip-dialog-panel',
            component: SummaryDetailsTableComponent,
            enableClose: true,
          },
          '90%',
        );
      },
      error: (err: any) => {
        this._loader.hide();
        this._toaster.error(`Unable to load Billing NPI details due to ${err?.status || 'error'}`);
      },
    });
  }

  openPhase1ASRCostDialog(row: any) {
    const asrId = String(row?.asrId || '').trim();
    if (!asrId) {
      this._toaster.error('Unable to load Phase 1 ASR Cost details. Missing ASR ID.');
      return;
    }

    this._loader.show();
    this._triageService.getP1CostDetails(asrId).subscribe({
      next: (res: any) => {
        const rowData = res?.responseData?.billSummary || [];
        this._loader.hide();

        this.openTableDialog(
          {
            title: 'Phase 1 ASR Cost by Jurisdiction',
            info: 'This table displays the Phase 1 ASR cost submitted amount for the ASR alerted provider per UPIC jurisdiction. The ASR cost amount is based on claims-at-risk for alerts within the last 14 days and is updated daily.',
            componentData: {
              rowData,
              columns: P1_COST_COLUMNS,
              tableName: 'Phase 1 ASR Cost Table',
              tableId: 'phase1AsrCostTable',
            },
            panelClass: 'ip-dialog-panel',
            component: SummaryDetailsTableComponent,
            enableClose: true,
          },
          '90%',
        );
      },
      error: (err: any) => {
        this._loader.hide();
        this._toaster.error(
          `Unable to load Phase 1 ASR Cost details due to ${err?.status || 'error'}`,
        );
      },
    });
  }

  openEnrollmentInfoDialog(row: any) {
    const asrId = String(row?.asrId || '').trim();
    if (!asrId) {
      this._toaster.error('Unable to load enrollment details. Missing ASR ID.');
      return;
    }

    this._loader.show();
    this._triageService.getAsrDetailsData(asrId, 'init', 'medicaid').subscribe({
      next: (res: any) => {
        const providerData = res?.responseData?.provider;
        const rowData = this._extractEnrollmentRows(providerData);
        this._loader.hide();

        this.openTableDialog(
          {
            title: 'Associated Enrollment IDs',
            info: 'The below table displays the Medicaid ID, State, Enrollment Status, Effective Date, and Termination Date for the billing provider that indicated that ASR’s NPI as the admitting, billing, home health, operating, prescribing, referring, prescription dispensing, servicing, supervising, or other providers in the claims data.',
            componentData: {
              rowData,
              columns: ENROLLMENT_ID_COLUMNS,
              tableName: 'Enrollment ID Table',
              tableId: 'enrollmentIdTable',
            },
            panelClass: 'ip-dialog-panel',
            component: SummaryDetailsTableComponent,
            enableClose: true,
          },
          '70%',
        );
      },
      error: (err: any) => {
        this._loader.hide();
        this._toaster.error(`Unable to load enrollment details due to ${err?.status || 'error'}`);
      },
    });
  }

  openMdcdTotalPaymentDialog(row: any) {
    const asrDbid = String(row?.asrDbid || '').trim();
    if (!asrDbid) {
      this._toaster.error(
        'Unable to load Medicaid Alerted Total Payment details. Missing ASR DBID.',
      );
      return;
    }

    this._loader.show();
    this._triageService.getAsrDetailsData(asrDbid, 'MDCDTOTALPYMT', 'medicaid').subscribe({
      next: (res: any) => {
        const rowData = res?.responseData?.mdcdTotalPayments || [];
        this._loader.hide();

        this.openTableDialog(
          {
            title: 'Medicaid Alerted Total Payment',
            info: 'This table displays the total amount paid to the ASR alerted provider based on alerted claims at risk from the last model run. Medicaid data displayed in the Total payment table does not include all claims and only displays information related to the Alerting Model/Alerting Claims. Provider Roles are displayed per the claim header and/or claim line that the model alerted on.',
            warningMessage:
              "In the Medicaid Alerted Total Payment table if a provider has an alert in a state outside of the end-user's jurisdiction all information except financials displays. N/A is displayed in columns with amounts outside of the end-user's jurisdiction and for columns in which there is no data to display. The end-user will not be able to export any claims for financial information for a Medicaid Alerted State outside of the end-user's jurisdiction.",
            componentData: {
              rowData,
              columns: MDCD_TOTAL_PAYMENT_COLUMNS,
              tableName: 'Medicaid Alerted Total Payment Table',
              tableId: 'mdcdTotalPaymentTable',
            },
            panelClass: 'ip-dialog-panel',
            component: SummaryDetailsTableComponent,
            enableClose: true,
          },
          '90%',
        );
      },
      error: (err: any) => {
        this._loader.hide();
        this._toaster.error(
          `Unable to load Medicaid Alerted Total Payment details due to ${err?.status || 'error'}`,
        );
      },
    });
  }

  private _extractEnrollmentRows(providerData: any): any[] {
    const possibleLists = [
      providerData?.enrollmentIds,
      providerData?.mdcdEnrollmentIds,
      providerData?.medicaidEnrollmentIds,
      providerData?.medicaidEnrollments,
      providerData?.enrollmentInfo,
      providerData?.enrollment,
      providerData,
    ];

    const rawRows = possibleLists.find((value) => Array.isArray(value)) || [];

    return (rawRows as any[]).map((row: any) => ({
      mdcdId: row?.mdcdId ?? row?.medicaidId ?? row?.medicaidID ?? '',
      state: row?.state ?? row?.stateCd ?? row?.stateCode ?? '',
      status: row?.status ?? row?.enrollmentStatus ?? row?.enrollmentStusDesc ?? '',
      efctvDt: row?.efctvDt ?? row?.effectiveDate ?? '',
      termDt: row?.termDt ?? row?.terminationDate ?? '',
    }));
  }

  openTableDialog(data: any, width: string = '80%') {
    this.dialog.open(CommonDialogComponent, {
      width,
      data: {
        ...data,
      },
      panelClass: 'ip-dialog-panel',
    });
  }

  triageCard: Card = {
    title: 'ASR Triage – Search Results',
    hoverText:
      'This table provides a list of ASRs and a summary of their details based on the initiated search or selected working set. To learn more about the specific ASR details displayed in the table columns and the functionalities available, hover over the buttons or information indicators.',
  };

  openCustomSearch() {
    this.dialog.open(CustomSearchDialogComponent, {
      panelClass: 'ip-dialog-panel',
      width: '60%',
      data: {
        mode: !this.selectedSavedSearchId ? 'modifyUnsavedSearch' : 'modifySavedSearch',
        selectedTabIndex: 0,
        ASRType: this.selectedSearchProgramType === 'medicaid' ? 1 : 0,
        selectedSearchFilter: this.selectedSearchFilter,
        savedSearchName: this.selectedSavedSearchName,
        savedSearchId: this.selectedSavedSearchId,
      },
    });
  }

  saveSearch() {
    this.dialog.open(SaveSearchDialogComponent, {
      panelClass: 'ip-dialog-panel',
      width: '60%',
      data: {
        programType: this.selectedSearchProgramType,
        selectedSearchAsJson: this.selectedSearchAsJson,
      },
    });
  }

  openAddToNewWorkingSetDialog() {
    const selectedRows = this.currerntSelectedRows || [];
    if (!selectedRows.length) {
      this._toaster.error('Please select at least one ASR.');
      return;
    }

    const isMedicare = this.selectedTabIndex === 0;
    const listItems = selectedRows
      .map((row: any) => ({ asrptId: String(row?.asrDbid || '').trim() }))
      .filter((item: { asrptId: string }) => !!item.asrptId);

    if (!listItems.length) {
      this._toaster.error('Unable to create Working Set. Selected rows are invalid.');
      return;
    }

    const dialogRef = this.dialog.open(AddWorkingSetDialogComponent, {
      width: '600px',
      data: {
        title: 'Add to New Working Set',
        instruction: 'Complete the field below, then click Add.',
        label: 'Working Set Name *',
        cancelText: 'Cancel',
        submitText: 'Add',
        isMedicare,
        listItems,
      },
    });

    dialogRef.afterClosed().subscribe((created: boolean) => {
      if (created) {
        this._getWorkingSet();
      }
    });
  }

  openAddToExistingWorkingSetDialog() {
    const selectedRows = this.currerntSelectedRows || [];
    if (!selectedRows.length) {
      this._toaster.error('Please select at least one ASR.');
      return;
    }

    const isMedicare = this.selectedTabIndex === 0;
    const asrptIds = this._extractAsrptIds(selectedRows);

    if (!asrptIds.length) {
      this._toaster.error('Unable to add to Working Set. Selected rows are invalid.');
      return;
    }

    this._loader.show();
    this._triageService.getWorkingSet().subscribe({
      next: (res: any) => {
        this.workingSetData = res;
        const workingSets = this._getCurrentWorkingSets();

        this._loader.hide();

        if (!workingSets.length) {
          this._toaster.info('No existing working sets found.');
          return;
        }

        const dialogRef = this.dialog.open(AddExistingWorkingSetDialogComponent, {
          width: '600px',
          data: {
            title: 'Add to Existing Working Set',
            instruction: 'Complete the field below, then click Add.',
            label: 'Working Set Name',
            cancelText: 'Cancel',
            submitText: 'Add',
            isMedicare,
            asrptIds,
            workingSets,
          },
        });

        dialogRef.afterClosed().subscribe((updated: boolean) => {
          if (updated) {
            this._getWorkingSet();
          }
        });
      },
      error: (err: any) => {
        this._loader.hide();
        this._toaster.error(`Unable to load Working Sets due to ${err?.status || 'error'}`);
      },
    });
  }

  private _getCurrentWorkingSets(): Array<{ listId: string; listNm: string }> {
    const sets =
      this.selectedTabIndex === 0 ? this.workingSetData?.[0] || [] : this.workingSetData?.[1] || [];

    return (sets || [])
      .map((ws: any) => ({
        listId: String(ws?.listId || '').trim(),
        listNm: String(ws?.listNm || '').trim(),
      }))
      .filter((ws: { listId: string; listNm: string }) => !!ws.listId && !!ws.listNm);
  }

  openRemoveFromWorkingSetDialog() {
    const selectedRows = this.currerntSelectedRows || [];
    if (!selectedRows.length) {
      this._toaster.error('Please select at least one ASR.');
      return;
    }

    const workItemId = String(this.selectedWorkbenchId || '').trim();
    if (!workItemId) {
      this._toaster.error('Unable to remove from Working Set. Missing Working Set ID.');
      return;
    }

    const asrptIds = this._extractAsrptIds(selectedRows);

    if (!asrptIds.length) {
      this._toaster.error('Unable to remove from Working Set. Selected rows are invalid.');
      return;
    }

    const confirmDialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: {
        message: 'Are you sure you want to remove the selected ASRs from this Working Set?',
        cancelText: 'Cancel',
        confirmText: 'Remove',
        title: 'Remove from Working Set',
      },
    });

    confirmDialogRef.afterClosed().subscribe((result: any) => {
      if (!result?.confirmed) return;

      this._loader.show();
      this._triageService.removeFromWorkingSet(workItemId, asrptIds).subscribe({
        next: () => {
          this._toaster.success('Selected ASRs removed from Working Set.');
          this.selectedMedicareRows = [];
          this.selectedMedicaidRows = [];
          this.clearTrigger++;
          this._fetchDataFromQp({
            workItemId,
            type: this.selectedWorkbenchType,
            asrType: this.selectedTabIndex === 1 ? 'MDCD' : 'MDCR',
          });
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(`Remove from Working Set failed due to ${err?.status || 'error'}`);
        },
      });
    });
  }

  openPrioritizeDialog() {
    const selectedRows = this.currerntSelectedRows ?? [];

    if (
      this.user?.groups?.includes(allOrgTypes.MEDIC) &&
      selectedRows.some((row) => row.hasPartD === 'N')
    ) {
      this._toaster.error(
        'The prioritization of this ASR is not permitted because the ASR is not associated with Part D claims.',
      );
      return;
    }

    this._triageService.getPriorUcmZones().subscribe({
      next: (res: any) => {
        const zones = res?.responseData || [];
      },
    });
    this._loader.show();
    const asrType = this.selectedTabIndex === 1 ? 'medicaid' : 'medicare';
    this._triageService.getPrioritizeForUCMTableData(asrType, selectedRows).subscribe({
      next: (res: any) => {
        this._loader.hide();
        const rowData = res || [];

        const isMdcd = this.selectedTabIndex === 0 ? false : true;

        this.openTableDialog(
          {
            title: 'Prioritize for UCM',
            info: isMdcd
              ? 'Indicate Model and State and Confirm to Prioritize ASR.'
              : 'Indicate Model and Confirm to Prioritize ASR.',
            warningMessage: isMdcd
              ? 'By prioritizing ASRs, they will be sent to the UCM FPS queue for processing. Complete the fields below, then click Prioritize. Prioritization can only be applied to models that have triggered alerts in states within your jurisdiction.'
              : 'By prioritizing ASRs, they will be sent to the UCM FPS queue for processing. Complete the fields below, then click Prioritize.',
            componentData: {
              rowData,
              columns: isMdcd ? Prioritize_MDCD_Columns : Prioritize_Columns,
              tableName: 'Prioritize Table',
              tableId: isMdcd ? 'prioritizeMdcdTable' : 'prioritizeTable',
              programType: asrType,
            },
            panelClass: 'ip-dialog-panel',
            component: PrioritizeUcmTableComponent,
          },
          '90%',
        );
      },
      error: () => {
        this._loader.hide();
      },
    });
  }

  onMedicareRowSelection(rows: any) {
    this.selectedMedicareRows = rows;
  }

  onMedicaidRowSelection(rows: any) {
    this.selectedMedicaidRows = rows;
  }

  hasPositivePayment(value: any): boolean {
    const amount = Number(String(value ?? '').replace(/[$,]/g, ''));
    return Number.isFinite(amount) && amount > 0;
  }

  formatRiskScore(value: any): string {
    if (value !== null && value !== undefined && value !== '' && value !== 'N/A') {
      const numericValue = parseFloat(value);
      if (Number.isNaN(numericValue)) {
        return '';
      }

      if (numericValue > 0.99) {
        return '> 0.99';
      }

      if (numericValue < 0.01) {
        return '< 0.01';
      }

      return numericValue.toFixed(2);
    }

    if (value === 'N/A') {
      return 'N/A';
    }

    return '';
  }

  formatYesNo(value: string): string {
    if (value === null || value === undefined || value === '') return '';
    if (value === 'N/A') return value;
    return value.replace(/^(Y|N)/, (match: string) => (match === 'Y' ? 'Yes' : 'No'));
  }

  private _setTriageTitle(titleSuffix: string) {
    const suffix = (titleSuffix || 'Search Results').trim();
    const fullTitle = `ASR Triage – ${suffix}`;
    this.triageCard.title = fullTitle;
    this.title.setTitle(fullTitle);
  }

  private _extractAsrptIds(rows: any[]): number[] {
    return (rows || [])
      .map((row: any) => {
        const raw = row?.asrptId ?? row?.asrDbid ?? row?.asrptid ?? row?.asrPtId;
        const id = Number(raw);
        return Number.isFinite(id) ? id : null;
      })
      .filter((id: number | null): id is number => id !== null);
  }

  openDetails(row: any) {
    const asrId = String(row?.asrDbid || '').trim();
    if (!asrId) {
      this._toaster.error('Unable to load details. Missing ASR ID.');
      return;
    }
    window.open(
      `/FPS2UnifiedPortal/Investigative/Details?asrId=${asrId}&viewParam=${this.asrType}`,
      '_blank',
    );
  }
}
