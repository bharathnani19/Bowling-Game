export const ws_host = 'http://dcatdata0.awscloud.cms.local:9082/FPS2UnifiedPortal';
export const app_url = 'http://localhost:9080';

export const environmentExtended = {
  wsHost: ws_host,
  appUrl: app_url,
  production: false,
  appBaseHref: '/',
  env: 'dev',
  okta: {
    issuer: 'https://test.idp.idm.cms.gov/oauth2/ausbbjql1yRIpm9yt297',
    clientId: '0oabbjqacsMm5sZO2297',
    redirectUri: 'http://localhost:9080/FPS2UnifiedPortal/',
    postLogoutRedirectUri: 'http://localhost:9080/FPS2UnifiedPortal/',

    scopes: ['openid', 'email', 'profile', 'offline_access'],
    state: 'fps-auth-state', // used to validate the OAuth response
    devMode: true,
  },
  trainingUrls: { lms: 'https://impl.idp.idm.cms.gov/app/cms-impl_cpiifislearningeps_1/exk12kj4ft0stuiZp298/sso/saml' },
  tableauBase: 'https://cloud.fpsreports.cmsnet/t/Prod',
  tableauProviderEduAttr : "https://cloud.fpsreports.cmsnet/t/Prod/views/ProviderEducationandModelAttribute/ProviderEducationandModelAttributeReport?NPI=",
  tableauModelAttr :  "https://cloud.fpsreports.cmsnet/t/Prod/views/ModelAttributeComparisonReport/ModelAttributeComparisonReport-TabularList?NPI=",
  slaLoggingEnabled: false,
  splunkUrl:'',
  splunkToken: ''
};
