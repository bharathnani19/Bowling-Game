export const ws_host = 'https://cloud.fpsportalmodeldev.cms.cmsval/fps';
export const app_url = 'https://cloud.fpsportalmodeldev.cms.cmsval';
export const environmentExtended = {
  wsHost: ws_host,
  appUrl: app_url,
  production: false,
  env: 'mte',
  appBaseHref: '/',
  okta: {
    pkce: true,
    issuer: 'https://impl.idp.idm.cms.gov/oauth2/ausc24l2w5nTQczdY297',
    clientId: '0oac24ih3eJjmcmlk297',
    redirectUri: 'https://cloud.fpsportalmodeldev.cms.cmsval/FPS2UnifiedPortal/',
    postLogoutRedirectUri: 'https://cloud.fpsportalmodeldev.cms.cmsval/FPS2UnifiedPortal/',

    scopes: ['openid', 'email', 'profile', 'offline_access'],
    tokenManager: {
      autoRenew: true,
      autoRemove: true,
    },
  },
  trainingUrls: { lms: 'https://impl.idp.idm.cms.gov/app/cms-impl_cpiifislearningeps_1/exk12kj4ft0stuiZp298/sso/saml' },
  tableauBase: 'https://cloud.fpsreportsmodeldev.cms.cmsval/t/MTE',
  tableauProviderEduAttr : "https://cloud.fpsreportsmodeldev.cms.cmsval/t/MTE/views/ProviderEducationandModelAttribute/ProviderEducationandModelAttributeReport?NPI=",
  tableauModelAttr :  "https://cloud.fpsreportsmodeldev.cms.cmsval/t/MTE/views/ModelAttributeComparisonReport/ModelAttributeComparisonReport-TabularList?NPI=",
  slaLoggingEnabled: false,
  splunkUrl:'',
  splunkToken: ''
};
