export const ws_host = 'http://dcatdata0.awscloud.cms.local:9082/fps';
export const app_url = 'http://localhost:9080';

export const environmentExtended = {
  wsHost: ws_host,
  appUrl: app_url,
  production: false,
  env: 'local',
  appBaseHref: '/',
  okta: {
    issuer: 'https://test.idp.idm.cms.gov/oauth2/ausbbjql1yRIpm9yt297',
    clientId: '0oabbjqacsMm5sZO2297',
    redirectUri: 'http://localhost:9080/unified-portal/',
    postLogoutRedirectUri: 'http://localhost:9080/unified-portal/',

    scopes: ['openid', 'email', 'profile', 'offline_access'],
    state: 'fps-auth-state',
    devMode: true,
  },
  trainingUrls: {
    lms: 'https://impl.idp.idm.cms.gov/app/cms-impl_cpiifislearningeps_1/exk12kj4ft0stuiZp298/sso/saml',
  },
  tableauBase: 'http://dtab1.awscloud.cms.local:8000/#/',
  tableauProviderEduAttr : "http://dtab1.awscloud.cms.local:8000/#/views/ProviderEducation/ProviderEducationandModelAttributeReport?NPI=",
  tableauModelAttr :  "http://dtab1.awscloud.cms.local:8000/#/views/ModelAttributeComparisonReport/ModelAttributeComparisonReport-TabularList?NPI=",
  slaLoggingEnabled: false,
  splunkUrl:'',
  splunkToken: ''
};
