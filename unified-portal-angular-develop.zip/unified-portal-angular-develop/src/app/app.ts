import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';

import { OktaService } from './services/okta';

import { SessionService } from './services/session-timeout-service';

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  styleUrl: './app.scss',
  standalone: false,
})
export class AppComponent implements OnInit {
  private callbackInProgress = false;

  constructor(
    private readonly okta: OktaService,
    private readonly router: Router,
    private readonly sessionService: SessionService,
  ) {}

  async ngOnInit(): Promise<void> {
    if (!this.okta.oktaAuth.isLoginRedirect()) {
      await this.redirectLegacyRoutes();
    }

    await this.initializeAuthentication();
  }

  private async redirectLegacyRoutes(): Promise<void> {
    const path = window.location.pathname || '';
    const search = window.location.search || '';

    if (/\/iphome$/i.test(path)) {
      await this.router.navigateByUrl('/Investigative', { replaceUrl: true });
      return;
    }

    if (/\/asrdetails$/i.test(path) || /\/asrdetails\//i.test(path)) {
      await this.router.navigateByUrl(this.buildDetailsTargetFromQuery(search), {
        replaceUrl: true,
      });
      return;
    }

    // Safety fallback for hash-style legacy links.
    const hash = window.location.hash || '';
    if (hash.startsWith('#/IPHome')) {
      await this.router.navigateByUrl('/Investigative', { replaceUrl: true });
      return;
    }

    if (hash.startsWith('#/ASRDetails')) {
      const queryStart = hash.indexOf('?');
      const rawQuery = queryStart >= 0 ? `?${hash.substring(queryStart + 1)}` : '';
      await this.router.navigateByUrl(this.buildDetailsTargetFromQuery(rawQuery), {
        replaceUrl: true,
      });
    }
  }

  private buildDetailsTargetFromQuery(search: string): string {
    const params = new URLSearchParams(search.startsWith('?') ? search.substring(1) : search);
    const asrId =
      params.get('asrDetailsParam') || params.get('asrRptCardIdParam') || params.get('asrId') || '';
    const viewParam = params.get('viewParam') || params.get('viewParm') || 'medicare';

    if (!asrId) {
      return `/Investigative?viewParam=${encodeURIComponent(viewParam)}`;
    }

    return `/Investigative/Details?asrId=${encodeURIComponent(asrId)}&viewParam=${encodeURIComponent(viewParam)}`;
  }

  private async initializeAuthentication(): Promise<void> {
    if (!this.okta.oktaAuth.isLoginRedirect()) {
      return;
    }

    if (this.callbackInProgress) {
      return;
    }

    this.callbackInProgress = true;

    try {
      console.log('Processing Okta login callback');

     
      const transaction = await this.okta.oktaAuth.token.parseFromUrl();
      const tokens = transaction.tokens;

      console.log('Okta callback tokens:', {
        accessToken: !!tokens.accessToken,
        idToken: !!tokens.idToken,
        refreshToken: !!tokens.refreshToken,
      });

      this.okta.oktaAuth.tokenManager.setTokens(tokens);

      const storedTokens = await this.okta.oktaAuth.tokenManager.getTokens();
      if (!storedTokens.accessToken || !storedTokens.idToken) {
        throw new Error('Okta callback did not return the required access and ID tokens.');
      }

      console.log('Okta tokens stored successfully');

      const originalUri = this.okta.oktaAuth.getOriginalUri() || '/';
      this.okta.oktaAuth.removeOriginalUri();

      this.sessionService.startSessionTimeout();
      await this.router.navigateByUrl(originalUri);
    } catch (error) {
      console.error('Okta callback processing failed:', error);

      this.sessionService.stopSessionTimeout();
      await this.okta.oktaAuth.tokenManager.clear();
    } finally {
      this.callbackInProgress = false;
    }
  }
}
