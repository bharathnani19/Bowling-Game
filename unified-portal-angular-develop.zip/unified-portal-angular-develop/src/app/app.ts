import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';

import { OktaService } from './services/okta';

import { SessionService } from './services/session-timeout-service';

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  styleUrl: './app.scss',
  standalone: false,
})
export class AppComponent implements OnInit {
  private callbackInProgress = false;

  constructor(
    private readonly okta: OktaService,
    private readonly router: Router,
    private readonly sessionService: SessionService,
  ) {}

  async ngOnInit(): Promise<void> {
    await this.initializeAuthentication();
  }

  private async initializeAuthentication(): Promise<void> {
    if (!this.okta.oktaAuth.isLoginRedirect()) {
      return;
    }

    if (this.callbackInProgress) {
      return;
    }

    this.callbackInProgress = true;

    try {
      console.log('Processing Okta login callback');

     
      const transaction = await this.okta.oktaAuth.token.parseFromUrl();

      const tokens = transaction.tokens;

      console.log('Okta callback tokens:', {
        accessToken: !!tokens.accessToken,

        idToken: !!tokens.idToken,

        refreshToken: !!tokens.refreshToken,
      });

     
      this.okta.oktaAuth.tokenManager.setTokens(tokens);

      const storedTokens = await this.okta.oktaAuth.tokenManager.getTokens();

      if (!storedTokens.accessToken || !storedTokens.idToken) {
        throw new Error('Okta callback did not return the required access and ID tokens.');
      }

      
      console.log('Okta tokens stored successfully');

      const originalUri = this.okta.oktaAuth.getOriginalUri() || '/';

      this.okta.oktaAuth.removeOriginalUri();

     
      this.sessionService.startSessionTimeout();

    
      await this.router.navigateByUrl(originalUri);
    } catch (error) {
      
      console.error('Okta callback processing failed:', error);

      this.sessionService.stopSessionTimeout();

      await this.okta.oktaAuth.tokenManager.clear();
    } finally {
      this.callbackInProgress = false;
    }
  }
}
